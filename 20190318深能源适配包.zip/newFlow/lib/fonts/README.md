# Font Icon 命名规范

- 名称应该是具体的，不带感情色彩的。（即像什么就叫什么）
- line 表示线条 icon
- square 表示直角
- circle 表示圆角
- up down left right 表示方向
- 修饰词统一作为后缀出现

示例：

```md
权重： 名称 > 方向 > 线条 > 直角/圆角
arrow-right-l-s
```
