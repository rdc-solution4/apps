/******************\u4EE5\u4E0B\u51E0\u4E2A\u51FD\u6570\u5B9E\u73B0\u52A8\u6001\u8868\u683C\u8868\u5934\u7684\u7ED8\u5236\uFF0C\u589E\u52A0\u884C\uFF0C\u5220\u9664\u884C\u4EE5\u53CA\u884C\u5E8F\u53F7\u7684\u8BBE\u7F6E********************/

/***********************************************
\u529F\u80FD\uFF1A\u7ED8\u5236\u52A8\u6001\u8868\u683C\u7684\u8868\u5934
\u53C2\u6570\u5F62\u5982\uFF1AA:B:C:D
A\uFF1A\u6807\u9898\uFF1BB\uFF1A\u8868\u683C\u5BBD\uFF1BC\uFF1A\u5BF9\u9F50\u65B9\u5F0F\uFF1BD\uFF1A\u64CD\u4F5C
***********************************************/	
function createDT(){
	var editIndex = queryValue.indexOf("&isedited=")+10;
	var isEdited = queryValue.substring(editIndex,editIndex+1);
	var tmpLen;
	if(isEdited!="1") tmpLen=2;
	else tmpLen=1;
	
	var arrType;
	var argLen = arguments.length;
	var idNo = arguments[argLen-1];
	var tbInfo;
	if(idNo == "1"){
		tbInfo = "<div style='text-align:center;font-size:18px'><b>OGSM\u5B8C\u6210\u60C5\u51B5</b></div>";
		strHTML = "<table border=0 id=tReview" + idNo + " width=100% cellspacing=1 cellpadding=3 bgcolor=#BBBBBB><tr><td bgcolor=#f7f7f7 align=center colspan=9>"+ tbInfo +"</td></tr><tr><td bgcolor=#f7f7f7 width=2% nowrap>\u5E8F\u53F7</td>";
	}else{
		tbInfo = "<div style='text-align:center;font-size:18px'><b>KPI\u5B8C\u6210\u60C5\u51B5</b></div>";
		strHTML = "<table border=0 id=tReview" + idNo + " width=100% cellspacing=1 cellpadding=3 bgcolor=#BBBBBB><tr><td bgcolor=#f7f7f7 align=center colspan=14>"+ tbInfo +"</td></tr><tr><td bgcolor=#f7f7f7 width=2% nowrap>\u5E8F\u53F7</td>";
	}
	
	for(var i=0;i<argLen-tmpLen;i++){
		arrType = arguments[i].split(":");
		strHTML +="<td bgcolor=#f7f7f7";
		if(arrType.length>1)
			strHTML +=" width=\"" + arrType[1] + "\"";
		if(arrType.length>2)
			if(arrType[2] != "")
				strHTML +=" align=\"" + arrType[2] + "\"";
		if(arrType.length>3)
			strHTML +=" Opration=\"" + arrType[3] + "\"";
		strHTML +=">" + arrType[0] + "</td>";
	}
	strHTML += "</tr></table>";

	document.write(strHTML);
}

/***********************************************
\u529F\u80FD\uFF1A\u5728\u8868\u683C\u6700\u540E\u4E00\u884C\u589E\u52A0\u4E00\u884C
***********************************************/
function addRow(flag){	
	var objTable;
	var exampleTable;
	
	objTable = getObjTable("tReview",flag);
	exampleTable = getObjTable("exampleRow",flag);

	objTable.insertRow();
	r = objTable.rows.length-1;
	for(var i = 0;i < objTable.rows[1].cells.length;i++){
		objTable.rows[r].insertCell();	
		objTable.rows[r].cells[i].bgColor="#ffffff";
		objTable.rows[r].cells[i].innerHTML = exampleTable.rows[0].cells[i].innerHTML;
	}
	
	setNo(objTable);
}

/***********************************************
\u529F\u80FD\uFF1A\u81EA\u52A8\u586B\u5199\u8868\u683C\u5E8F\u53F7
***********************************************/
function setNo(objTable){
	for(var i=2;i<objTable.rows.length;i++){	
		var j = i - 1;
		objTable.rows[i].cells[0].innerHTML = "<center>" + j + "</center>";
		objTable.rows[i].cells[0].bgColor = "#f7f7f7";
	}
}

/*******************\u4EE5\u4E0B\u51E0\u4E2A\u51FD\u6570\u4E3A\u4FDD\u5B58\u52A8\u6001\u8868\u683C\u6570\u636E\u3001\u663E\u793A\u52A8\u6001\u8868\u683C\u6570\u636E\u53CA\u5176\u4ED6\u529F\u80FD\u5B9E\u73B0\u7684\u516C\u7528\u51FD\u6570*******************/

/***********************************************
\u529F\u80FD\uFF1A\u83B7\u53D6\u9F20\u6807\u5F53\u524D\u64CD\u4F5C\u7684\u8868\u683C\u884C\u53F7
***********************************************/
function getEventIndex(){
	var oa = window.event.srcElement;
	var otr = oa.parentElement;
	while(otr && otr.tagName && otr.tagName!="TR")
		otr = otr.parentElement;
	r = otr.rowIndex;
	return r;
}

/***********************************************
\u529F\u80FD\uFF1A\u83B7\u53D6\u9F20\u6807\u5F53\u524D\u64CD\u4F5C\u7684\u8868\u683C\u5217\u53F7
***********************************************/
function getEventIndex1(){
	var oa = window.event.srcElement;
	var otr = oa.parentElement;
	while(otr && otr.tagName && otr.tagName!="TR")
		otr = otr.parentElement;
	r = otr.cellIndex;
	return r;
}

/***********************************************
\u529F\u80FD\uFF1A\u83B7\u53D6\u6240\u6709\u9700\u8981\u5C55\u793A\u7684\u57DF\u7684\u57DF\u540D\u3002\u5982\u679C\u9700\u8981\u6309\u7167\u4E0D\u540C\u6761\u4EF6\u663E\u793A\u4E0D\u540C\u7684\u5217\uFF0C\u9664\u4E86\u9700\u8981\u91CD\u65B0\u753B\u8868\u5934\u5916\u8FD8\u9700\u8981\u6539\u5199\u6B64\u5904
***********************************************/
function getFields(flag){
	var arrFieldName;
	if(flag == "1")
		arrFieldName = new Array("CF_T_P9502__ZZHROGSMOBJ1_All","CF_T_P9502__ZZHROGSMGOAL1_All","CF_T_P9502__ZZHROGSMSTR1_All","CF_T_P9502__ZZHROGSMEA1_All","CF_T_P9502__ZZHROGSMDEPC1_All","CF_F_YJ11_All","CF_F_YJ12_All");	
	else
		arrFieldName = new Array("CF_T_P9501__ZZHRKPIDIMC1_All","CF_T_P9501__ZZHRKPITERM1_All","CF_T_P9501__ZZHRKPICAL1_All","CF_T_P9501__ZZHRKPIDEPC1_All","CF_T_P9501__ZZHRKPITYPEC1_All","CF_T_P9501__ZZHRKPIWEIGHT1_All","CF_T_P9501__ZZHRLAST1_All","CF_T_P9501__ZZHRKPITARGET1_All","CF_T_P9501__ZZHRKPIRSPC1_All","CF_F_YJ21_All","CF_F_YJ22_All");	
	
	return arrFieldName;
}

/***********************************************
\u529F\u80FD\uFF1A\u521B\u5EFA\u4E00\u4E2A\u4E8C\u7EF4\u6570\u7EC4,\u53C2\u6570arr\u662F\u4E00\u4E2A\u5143\u7D20\u4E3A\u8868\u683C\u57DF\u540D\u7684\u6570\u7EC4
***********************************************/
function createArray(arr){
	var baseArray = new Array();
	for(var i = 0;i < arr.length; i++){
		baseArray[arr[i]] = new Array(); //\u6570\u7EC4\u7684\u4E0B\u6807\u4E3A\u57DF\u540D\u79F0\uFF0C\u7528\u6765\u6807\u8BB0\u67D0\u57DF\u7684\u4E00\u7EC4\u503C
	}
	return baseArray;
}

/************************\u4EE5\u4E0B\u51E0\u4E2A\u51FD\u6570\u7528\u4E8E\u663E\u793A\u52A8\u6001\u8868\u683C\u7684\u6570\u636E************************/

/*********************************************************
\u529F\u80FD\uFF1A\u8868\u5355load\u65F6\u7684\u5165\u53E3\u51FD\u6570
**********************************************************/
function onloadform(){
	var cells;
	var arrFieldName;
	var arrData;
	var objTable;
	
	for(var flag = 1;flag < 3;flag++){
		objTable = getObjTable("tReview",flag);
		cells = objTable.rows[1].cells;
		arrFieldName = getFields(flag);
		//\u628A\u8868\u683C\u57DF\u540D\u5217\u8868\u5199\u5230\u8868\u683C\u7684\u5355\u5143\u683C\u5C5E\u6027\u91CC\u9762
		for(var i = 0; i < cells.length-1; i++){
			cells[i+1].FieldName = arrFieldName[i];
		}
		//\u628A\u6240\u6709\u7684\u57DF\u7684\u503C\u7EC4\u6210\u4E00\u4E2A\u4E8C\u7EF4\u6570\u7EC4
		arrData = initData(arrFieldName);
		setData(arrData,arrFieldName,objTable,flag);
	}
}

/***********************************************
\u529F\u80FD\uFF1A\u628A\u591A\u503C\u57DF\u7684\u503C\u8F6C\u5316\u6210\u4E3A\u6570\u7EC4\uFF0C\u53C2\u6570arrNames\u662F\u4E00\u4E2A\u5143\u7D20\u4E3A\u8868\u683C\u57DF\u540D\u7684\u6570\u7EC4
***********************************************/
function initData(arrNames){
	//arrArray\u662F\u4E00\u4E2A\u4E8C\u7EF4\u6570\u7EC4\uFF0C\u5176\u4E0B\u6807\u4E3A\u57DF\u7684\u540D\u79F0
	arrArray = createArray(arrNames);
	for(var i=0;i<arrNames.length;i++){
		arrArray[arrNames[i]] = getTE(arrNames[i]);
	}
	return arrArray;
}

/***********************************************
\u529F\u80FD\uFF1A\u83B7\u53D6\u591A\u503C\u57DF\u7684\u503C\uFF0C\u6309\u7167\u5206\u9694\u7B26\u7EC4\u6210\u6210\u4E3A\u4E00\u4E2A\u6570\u7EC4\uFF0C\u5E76\u8FD4\u56DE
***********************************************/
function getTE(strField){
	//alert(strField);
	var ote = document.forms[0].elements[strField];
	//alert(ote);
	if(!ote || !ote.value) return null;
	
	var arrValue = ote.value.split("*&^");
	
	for(var i = 0; i < arrValue.length; i++){
		if(trim(arrValue[i])=="\u25B2")			
			arrValue[i]="";
	}
	return arrValue;
}

/***********************************************
\u529F\u80FD\uFF1A\u628A\u83B7\u53D6\u5230\u7684\u4E8C\u7EF4\u6570\u7EC4\u7684\u503C\u5206\u522B\u586B\u5145\u5230\u6BCF\u4E00\u4E2A\u5355\u5143\u683C\u4E2D
***********************************************/
function setData(arrArray,arrFieldName,objTable,flag){
	var editIndex = queryValue.indexOf("&isedited=")+10;
	var isEdited = queryValue.substring(editIndex,editIndex+1);

	var otd,otdhead;
	var oField;
	var no;

	if(S_IsEdited){
		if(arrFieldName[0] && arrArray[arrFieldName[0]] && arrArray[arrFieldName[0]].length){
			for(var k = 0; k < arrArray[arrFieldName[0]].length; k++)
				addRow(flag);
			for(var j=1;j<objTable.rows[1].cells.length;j++){ //\u5FAA\u73AF\uFF1A\u7B2C\u4E00\u884C\u7B2C\u4E00\u4E2A\u57DF\uFF0C\u7B2C\u4E8C\u884C\u7B2C\u4E00\u4E2A\u57DF....\u7B2C\u4E00\u884C\u7B2C\u4E8C\u4E2A\u57DF\uFF0C\u7B2C\u4E8C\u884C\u7B2C\u4E8C\u4E2A\u57DF...
				otdhead = objTable.rows[1].cells[j];		//i\u8868\u793A\u884C,j\u8868\u793A\u5217\uFF08\u6216\u57DF\u7684\u5E8F\u53F7\uFF09
				//alert(otdhead.FieldName);
				if(otdhead.FieldName!=null && otdhead.FieldName!=""){
					for(var i = 2;i < objTable.rows.length;i++){
						otd = objTable.rows[i].cells[j];
						tmpField = otd.firstChild;
						var fieldType = tmpField.tagName.toLowerCase();
						switch (fieldType){
							case "select":
								for(var r = 0 ; r <= tmpField.length-1;r++)
									if(trim(tmpField.options[r].text) == trim(arrArray[otdhead.FieldName][i-1]))
										tmpField.options[r].selected = true;
								break;
							default:
								if(otd.all.F_TmpInput){
									if(arrArray[otdhead.FieldName] && arrArray[otdhead.FieldName][i-2])
										otd.all.F_TmpInput.value = trim(arrArray[otdhead.FieldName][i-2]).replace(/#\$\%/g,"\r\n");  //\u6CE8\u610F\u662F\u51CF2
									else otd.all.F_TmpInput.value = "";
								}else{
									otd.all.F_TmpInput.value = "";
								}					
						}
						//\u63A7\u5236\u90E8\u5206\u6D41\u7A0B\u5206\u6570\u548C\u610F\u89C1\u4E0D\u53EF\u7F16\u8F91
						if(flag==1){
							if(vStatus!="1" && objTable.rows[i].cells[6]){
								objTable.rows[i].cells[6].firstChild.firstChild.readOnly = true;
								objTable.rows[i].cells[6].firstChild.firstChild.className = "textdocnone";
								//if(S_IsEdited && vStatus!="1") objTable.rows[i].cells[7].style.display="none";
							}
							if(vStatus!="2" && objTable.rows[i].cells[7]){
								objTable.rows[i].cells[7].firstChild.firstChild.readOnly = true;
								objTable.rows[i].cells[7].firstChild.firstChild.className = "textdocnone";
							}
						}
						if(flag==2){
							if(vStatus!="1" && objTable.rows[i].cells[10]){
								objTable.rows[i].cells[10].firstChild.firstChild.readOnly = true;
								objTable.rows[i].cells[10].firstChild.firstChild.className = "textdocnone";
								//if(S_IsEdited && vStatus!="1") objTable.rows[i].cells[12].style.display="none";
							}
							if(vStatus!="2" && objTable.rows[i].cells[11]){
								objTable.rows[i].cells[11].firstChild.firstChild.readOnly = true;
								objTable.rows[i].cells[11].firstChild.firstChild.className = "textdocnone";
							}
						}
					}
				}	
			}
		}
	}else{
		if(arrFieldName[0] && arrArray[arrFieldName[0]] && arrArray[arrFieldName[0]].length)
			for(var k = 0; k < arrArray[arrFieldName[0]].length; k++){
				objTable.insertRow();
				d = objTable.rows.length-1;
				no = d-1;
				objTable.rows[d].insertCell();
				objTable.rows[d].cells[0].bgColor = "#f7f7f7";
				objTable.rows[d].cells[0].innerHTML = "<center>" + no+ "</center>";
				for(var r= 0;r < arrFieldName.length;r++){
					objTable.rows[d].insertCell();
					a = objTable.rows[d].cells.length-1;
					objTable.rows[d].cells[a].bgColor = "#ffffff";
					if(arrFieldName && arrFieldName[a-1] && arrArray[arrFieldName[a-1]] && arrArray[arrFieldName[a-1]][d-2])
						objTable.rows[d].cells[a].innerHTML = "<p align=center>"+trim(arrArray[arrFieldName[a-1]][d-2])+"</p>"; //\u6CE8\u610F\u662F\u51CF2
					else
						objTable.rows[d].cells[a].innerHTML = "<p align=center>"+""+"</p>"; //\u6CE8\u610F\u662F\u51CF2
				}
		}
	}
}

/****************\u4EE5\u4E0B\u51E0\u4E2A\u51FD\u6570\u7528\u4E8E\u8868\u5355\u63D0\u4EA4\u65F6\u4FDD\u5B58\u52A8\u6001\u8868\u683C\u7684\u6570\u636E*****************/

/*********************************************************
\u529F\u80FD\uFF1A\u8868\u5355\u63D0\u4EA4\u65F6\u6267\u884C\u7684\u5165\u53E3\u51FD\u6570
**********************************************************/
function submitform(){
	var objTable;
	var cells;
	for(var flag = 1;flag < 3;flag++){
		objTable = getObjTable("tReview",flag);
		cells = objTable.rows[1].cells;
		
		//\u83B7\u53D6\u57DF\u540D\u5217\u8868
		var arrFieldName = getFields(flag);
		//\u4E3A\u6BCF\u5217\u8D4B\u4E00\u4E2A\u5BF9\u5E94\u7684\u57DF\u540D\u503C\u5C5E\u6027
		for(var i = 0; i < cells.length-2; i++){
			cells[i+1].FieldName = arrFieldName[i];
			//alert(arrFieldName[i]);
		}

		saveData(arrFieldName,objTable);
	}
}

/***********************************************
\u529F\u80FD\uFF1A\u83B7\u53D6\u5355\u5143\u683C\u7684\u503C\uFF0C\u5B58\u5230\u4E8C\u7EF4\u6570\u7EC4\u4E2D
***********************************************/
function saveData(arrNames,objTable){
	var cell;		//\u6BCF\u4E00\u4E2A\u5355\u5143\u683C\u5BF9\u8C61
	var cellhead;	//\u6BCF\u4E00\u4E2A\u5355\u5143\u683C\u5BF9\u5E94\u7684\u5934\u884C\u5BF9\u8C61\uFF0C\u7B2C\u4E00\u884C\u8BB0\u5F55\u4E86\u8BE5\u5217\u7684\u5C5E\u6027
	var arrValue;	//\u4E34\u65F6\u6570\u7EC4\uFF0C\u51FD\u6570\u8FD4\u56DE\u503C
	var fieldType;
	var tmpField;
	arrArray = createArray(arrNames);
	
	//\u4EE5\u5217\u5FAA\u73AF\uFF0C\u4E8C\u7EF4\u6570\u7EC4\u7684\u7B2C\u4E00\u4E2A\u4E0B\u6807
	for(var j = 1;j <objTable.rows[1].cells.length-1; j++){
		cellhead = objTable.rows[1].cells[j];
		if(cellhead.FieldName!=null && cellhead.FieldName!="" && cellhead.FieldWidth!="0"){
			arrValue = new Array();		
			//\u4EE5\u884C\u5FAA\u73AF\uFF0C\u4E8C\u7EF4\u6570\u7EC4\u7684\u7B2C\u4E8C\u4E2A\u4E0B\u6807
			for(var i = 2;i < objTable.rows.length; i++){
				cell = objTable.rows[i].cells[j];
				tmpField = cell.firstChild;
				var fieldType = tmpField.tagName.toLowerCase();
				switch (fieldType){ 
					case "select":
						arrValue[arrValue.length] = tmpField.options[tmpField.selectedIndex].text;
					break;
			
					default:
						if(cell.all.F_TmpInput){
							if(cell.all.F_TmpInput.value!=""){
								arrValue[arrValue.length] = cell.all.F_TmpInput.value.replace(/\r\n/g,"#$%");
							}else{
								arrValue[arrValue.length] = "\u25B2";
							}
						}
				}
			}
			arrArray[cellhead.FieldName] = arrValue;
			document.forms[0].elements[cellhead.FieldName].value = arrValue.join("*&^");
		}
	}
}

/***********************************************
\u529F\u80FD\uFF1A\u83B7\u53D6\u8868\u683C\u5BF9\u8C61
***********************************************/
function getObjTable(idText,flag){
	var tId;
	var objTable;
	
	tId = idText + flag;
	objTable = document.getElementById(tId);
	
	return objTable;
}


/*******\u4EE5\u4E0B\u51FD\u65700302\u672A\u4F7F\u7528********/

//\u4EE5\u4E0B\u662F\u5B50\u8868\u5355\u4F7F\u7528\u5230\u7684\u903B\u8F91\u529F\u80FD\u51FD\u6570
/***********************************************
\u529F\u80FD\uFF1A\u6D6E\u70B9\u578B\u6570\u636E\u7684\u68C0\u6D4B\uFF0C\u4E0D\u5408\u6CD5\u5219\u8F6C\u6362\u4E3A\u5408\u6CD5(\u6D6E\u70B9\u578B)
***********************************************/
function checkFloat(obj){
	var str_tmp;
	var str_val="";
	for (var i=0;i<obj.value.length;i++){
		str_tmp=obj.value.substring(i,i+1);		
	 if ( (str_tmp>="0" && str_tmp<="9") || (str_tmp=="." && obj.value.indexOf(".")!=0) || str_tmp == "-")
			str_val+=str_tmp
	}
	if (obj.value!=str_val) obj.value=str_val;
}
/***********************************************
\u529F\u80FD\uFF1A\u9A8C\u8BC1\u5206\u6570\u5728-10\u5230120\u4E4B\u95F4\uFF0C\u4E14\u4FDD\u75592\u4F4D\u5C0F\u6570
***********************************************/
function confirmScore(obj){
	if(trim(obj.value)==""){obj.value="0";return;}
	if(trim(obj.value)=="0"){return;}
	if(trim(obj.value)=="0.00"){obj.value="0";return;}
	
	var num = new Number(obj.value);

	if(num > 120){
		alert("\u8BC4\u5206\u4E0D\u80FD\u8D85\u8FC7120\u5206\u3002");
		obj.focus();
		obj.value="";
		return false;
	}
	if(num < -10){
		alert("\u8BC4\u5206\u4E0D\u80FD\u5C0F\u4E8E-10\u5206\u3002");
		obj.focus();
		obj.value="";
		return false;
	}
	obj.value=new Number(num).toFixed(2);
}

/***********************************************
\u529F\u80FD\uFF1A\u6839\u636E\u8868\u683C\u6BCF\u884C\u586B\u5199\u7684\u6210\u7EE9\u548C\u6743\u91CD\u8BA1\u7B97\u603B\u5206\u6570
*tableF:\u5F53\u524D\u8868\u683C\u7684\u5E8F\u53F7
*scoreF:\u5206\u6570\u5B57\u6BB5\u7684\u5217\u53F7
*ratioF:\u6743\u91CD\u5B57\u6BB5\u7684\u5217\u53F7
***********************************************/
function computeScore(tableF,scoreF,ratioF){
	var objTable = getObjTable("tReview",tableF);
	var value = 0;
	var value1 = 0;
	var value2 = 0;
	for(var i = 1;i<objTable.rows.length;i++){
		value1 = new Number(objTable.rows[i].cells[scoreF].firstChild.firstChild.value);
		value2 = new Number(objTable.rows[i].cells[ratioF].firstChild.firstChild.value);
		value = value + (value1*value2)/100;
	}
	value = value.toFixed(2);
	document.all.CF_LeadFS.value = value;
	document.all.CF_LeadDJ.value = computeGrade(value);
}

/***********************************************
\u529F\u80FD\uFF1A\u6839\u636E\u5206\u6570\u8BA1\u7B97\u8BC4\u5B9A\u7B49\u7EA7
***********************************************/
function computeGrade(num){
	num = new Number(num);
	if(num<=120 && num>=110) return "A++";
	else if(num<110 && num>=100) return "A+";
	else if(num<100 && num>=90) return "A";
	else if(num<90 && num>=70) return "B";
	else return "C";
}

/***********************************************
\u529F\u80FD\uFF1A\u4FEE\u6539\u5355\u884C\u4FE1\u606F
***********************************************/
function modifyInfo(flag){
	if(vStatus!="1"){alert("\u60A8\u65E0\u6743\u9650\u4FEE\u6539\u4FE1\u606F\uFF01");return;}
	if(serverURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6ESAP\u670D\u52A1\u5668\u5730\u5740,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u76F8\u5173\u7684URL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	var seqnr1=document.all.CF_T_P9502__SEQNR1_All.value;
	var infty1=document.all.CF_T_P9502__INFTY1_All.value;
	var seqnr2=document.all.CF_T_P9501__SEQNR1_All.value;
	var infty2=document.all.CF_T_P9501__INFTY1_All.value;
	
	var infty;
	var seqnr;
	var tmpArr;
	if(flag==1){
		infty = "9502";
		seqnr = seqnr1;
	}
	else{
		infty = "9501";
		seqnr = seqnr2;
	}
	if(guid==""){alert("GUID\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	//if(infty==""){alert("INFTY\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(seqnr==""){alert("SEQNR\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	if(seqnr.indexOf("*&^")!=-1){
		var r = getEventIndex();
		tmpArr = seqnr.split("*&^");
		seqnr = tmpArr[r-2];
	}
	
	document.all.CF_NeedReGetContent.value="1";
	
	//\u4FDD\u5B58\u7EE9\u6548\u6587\u6863
	saveAppDoc();
	alert('\u8df3\u8f6c\u5230PORTAL\u754c\u9762\uff0c\u8be5\u529f\u80fd\u5728\u79fb\u52a8\u7aef\u672a\u5b9e\u73b0\uff01');
	// alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
	// window.open(serverURL+viewURL+"?GUID="+guid+"&INFTY="+infty+"&SEQNR="+seqnr+"&OPERA=MOD1");
}

/***********************************************
\u529F\u80FD\uFF1A\u6DFB\u52A0\u4FE1\u606F
***********************************************/
function addInfo(flag){
	if(vStatus!="1"){alert("\u60A8\u65E0\u6743\u9650\u6DFB\u52A0\u4FE1\u606F\uFF01");return;}
	if(serverURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6ESAP\u670D\u52A1\u5668\u5730\u5740,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u76F8\u5173\u7684URL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	var infty;
	var tmpArr;
	if(flag==1){
		infty = "9502";
	}
	else{
		infty = "9501";
	}
	if(guid==""){alert("GUID\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	document.all.CF_NeedReGetContent.value="1";
	
	//\u4FDD\u5B58\u7EE9\u6548\u6587\u6863
	saveAppDoc();
	alert('\u8df3\u8f6c\u5230PORTAL\u754c\u9762\uff0c\u8be5\u529f\u80fd\u5728\u79fb\u52a8\u7aef\u672a\u5b9e\u73b0\uff01');
	// alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
	// window.open(serverURL+viewURL+"?GUID="+guid+"&INFTY="+infty+"&OPERA=INS");
}

//\u4FDD\u5B58\u7EE9\u6548\u6587\u6863
function saveAppDoc(){
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/AG_HRAPP_SaveDoc?OpenAgent&docid="+escape(S_DocId);
	request.open("POST",accessUrl,false);
	request.send(null);
}

/***********************************************
\u529F\u80FD\uFF1A\u6784\u9020XMLHTTP\u5BF9\u8C61
***********************************************/
function CLASS_XMLHTTP(){
	var request = false;
	try{
		request = new XMLHttpRequest();
	}catch (trymicrosoft){
		try{
			request = new ActiveXObject("Msxml2.XMLHTTP");
		}catch (othermicrosoft){
			try{
			   request = new ActiveXObject("Microsoft.XMLHTTP");
			}catch (failed){
				request = false;
			}
		}
	}
	return request;
}