/*\u4FEE\u6539\u8BB0\u5F55
1\u30012012-07-24 modified by ninggzhx 
	1\uFF09\u589E\u52A0\u4E86initAllDynamicTable\u51FD\u6570\uFF0C\u7528\u4E8E\u5FAA\u73AF\u8C03\u7528initTable\u3002
	   \u589E\u52A0\u539F\u56E0\uFF1A\u56E0\u4E3AinitTable\u51FD\u6570\u53EA\u80FD\u521D\u59CB\u5316\u5355\u4E2A\u8868\u683C\uFF0C\u5982\u679C\u8981\u521D\u59CB\u5316\u591A\u4E2A\u8868\u683C\uFF0C\u5219\u9700\u5FAA\u73AF\u8C03\u7528initTable\u51FD\u6570\u3002
2\u30012012-12-12 modified By ningzhx 
	1\uFF09\u589E\u52A0\u4E86displayColor\u51FD\u6570\u548CgetColor\u51FD\u6570\u3002
	   \u589E\u52A0\u539F\u56E0\uFF1A\u76F8\u5173\u6D41\u7A0B\u4E2D\u52A8\u6001\u8868\u683C\u4E2D\u76F8\u5173\u5355\u5143\u683C\u9700\u8981\u6839\u636E\u5185\u5BB9\u663E\u793A\u4E3A\u4E0D\u540C\u7684\u989C\u8272\u3002
3\u30012013-01-15 modified By Yao Yulong
	1) \u589E\u52A0\u4E86viewInfoRC()\u51FD\u6570
	   \u589E\u52A0\u539F\u56E0\uFF1A\u7528\u4E8ERC17A\u4E2D\u4E8C\u6B21\u67E5\u770B	   
4\u30012017-04-06 modified By Qicb\uFF0CcomputeScoreNew\u548CcomputeScoreReturnNew\u65B9\u6CD5\u589E\u52A0\u6743\u91CD\u5224\u65AD\uFF08\u5904\u7406\u5206\u6570\u51FA\u73B0NaN\u60C5\u51B5\uFF09    
\u4FEE\u6539end*/
var dtable,newTableID;

function C_VerificationNull(str){
	if(eval("document.all."+str+".value")!==""){
		return true;
	}
	else{
		alert(eval("document.all."+str+".title")+"\u57DF,\u503C\u4E0D\u80FD\u4E3A\u7A7A");
		return false;
	}
	return true;
}
function C_Comparison(str1,str2){
	if(eval("document.all."+str1+".value")>eval("document.all."+str2+".value")){
		alert(eval("document.all."+str+".title")+"\u57DF\u7684\u503C\u4E0D\u80FD\u5927\u4E8E"+eval("document.all."+str+".title")+"\u57DF\u7684\u503C");
		return false;
	}
	return true;
}
function C_VerificationNo(str){
	if(!isFloat(eval("document.all."+str+".value"),0)){
		alert(eval("document.all."+str+".title")+"\u57DF\u503C\u5FC5\u987B\u662F\u6570\u5B57");
		return false;
	}
	return true;
}
function C_VerificationEmail(str){
	if(eval("document.all."+str+".value").indexOf("@",0)<0){
		alert(eval("document.all."+str+".title")+"\u57DF\u503C\u4E0D\u662F\u5408\u6CD5\u7684Email,\u5408\u6CD5\u7684Email\u5FC5\u987B\u5305\u542B@");
		return false;
	}
	return true;
}
function C_VerificationLength(str,len){
	if(eval("document.all."+str+".value").length>len){
		alert(eval("document.all."+str+".title")+"\u57DF\u503C\u7684\u957F\u5EA6\u4E0D\u80FD\u8D85\u8FC7"+len);
		return false;
	}
	return true;
}
function C_Verificationx(str,len){
	if(eval("document.all."+str+".value").length<len){
		alert(eval("document.all."+str+".title")+"\u57DF\u503C\u7684\u957F\u5EA6\u4E0D\u80FD\u5C0F\u4E8E"+len);
		return false;
	}
	return true;
}
function C_Illegal(str,charset){
	var i;
	for(i=0;i<charset.length;i++){
		if(eval("document.all."+str+".value").indexOf(charset.charAt(i))>=0){
			alert(eval("document.all."+str+".title")+"\u57DF\u4E0D\u80FD\u542B\u6709"+charset+"\u7B49\u975E\u6CD5\u5B57\u7B26")
			return false;
		}
	}
	return true;
}
function C_Adder(str1,str2,str3){
	eval("document.all."+str3+".value=parseInt(str1)+parseInt(str2)");
}
function C_AdderText(str1,str2,str3){
	var a=parseInt(eval("document.all."+str1+".value"));
	var b=parseInt(eval("document.all."+str2+".value"));
	eval("document.all."+str3+".value=a+b");
}
function C_Multiplication(str1,str2,str3){
	eval("document.all."+str3+".value=parseInt(str1)*parseInt(str2)");
}
function C_MultiplicationText(str1,str2,str3){
	var a=parseInt(eval("document.all."+str1+".value"));
	var b=parseInt(eval("document.all."+str2+".value"));
	eval("document.all."+str3+".value=a*b");
}
function C_Subtraction(str1,str2,str3){
	eval("document.all."+str3+".value=parseInt(str1)-parseInt(str2)");
}
function C_SubtractionText(str1,str2,str3){
	var a=parseInt(eval("document.all."+str1+".value"));
	var b=parseInt(eval("document.all."+str2+".value"));
	eval("document.all."+str3+".value=a-b");
}
function C_Divider(str1,str2,str3){
	eval("document.all."+str3+".value=parseInt(str1)/parseInt(str2)");
}
function C_DividerText(str1,str2,str3){
	var a=parseInt(eval("document.all."+str1+".value"));
	var b=parseInt(eval("document.all."+str2+".value"));
	eval("document.all."+str3+".value=a/b");
}
function C_ComputeDayNum(str1,str2,str3){
	var StartTime=trim(eval("document.all."+str1+".value"));
	StartTime=StartTime.substring(StartTime.indexOf("-")+1)+"-"+StartTime.substring(0,StartTime.indexOf("-"));
	var EndTime=trim(eval("document.all."+str2+".value"));
	EndTime=EndTime.substring(EndTime.indexOf("-")+1)+"-"+EndTime.substring(0,EndTime.indexOf("-"));
	var ST=new Date(StartTime);
	var ET=new Date(EndTime);
	var theNum;
	if(eval("document.all."+str2+".value")==""&&eval("document.all."+str1+".value")=="")
	{
		return;
	}
	if(eval("document.all."+str2+".value")==""&&eval("document.all."+str1+".value")!="")
	{
		theNum=0.5*(1+1);
	}
	else
	{
		theNum=(ET-ST)/86400000+0.5*(1+1);
	}
	var thenum1=parseFloat(theNum);
	eval("document.all."+str3+".value=thenum1");
}

//\u5FAA\u73AF\u4FDD\u5B58\u8868\u683C
function Controls(Num){
	if(document.all.item("CF_Body")!==null){	
		try{
			saveRtf("CF_Body");
		}
		catch(e)
		{
		}
	}
	
	for(var j=1;j<=Num;j++)
		if(document.all.item("dtable_"+j)!=null){
			try{
			   saveTable(j);
			}
			catch(e)
			{}
		}
}
function saveTable(Num){
	//\u5148\u83B7\u53D6\u8BE5\u8868\u683C\u5BF9\u5E94\u7684\u4FE1\u606F	
	getCurField(Num);
	//add by xwf
	
	var f="document.forms[0].";
	var tableRow = newTableID.rows.length;
	for(var k=0;k<arrField.length;k++){
		if(arrField[k].indexOf("%%")==-1){
			var tmpArr=new Array();
			if(tableRow<dtable.rows.length){
				tmpArr[tmpArr.length]="";
			}
			else{
				for(var r=0;r<tableRow;r++){
					if(jgetFieldObj(arrField[k]+"_"+(r+1))[0]){
						var tmpStr=jgetFieldValue(arrField[k]+"_"+(r+1));
						if(tmpStr==""){
							tmpStr="\u25B2";
						}else{
							tmpStr = tmpStr.replace(/\r\n/g,"#$%");
							tmpStr = tmpStr.replace(/\n/g,"#$%");
						}
						tmpArr[tmpArr.length]=tmpStr;
					}
				}
			}
			if(jgetFieldObj(arrField[k]+"_All")[0]){
				jsetFieldValueForSave(arrField[k]+"_All",tmpArr.join("*&^"));
			}
			else{
				alert("\u591A\u503C\u57DF"+arrField[k]+"_All\u4E0D\u5B58\u5728,\u8BF7\u68C0\u67E5!");
				return false;
			}
		}
	}
	for(var j=0;j<arrSumField.length;j++){
		if(arrSumField[j].indexOf("%%")==-1){
			if(jgetFieldObj(arrSumField[j]+"_1")[0] && jgetFieldObj(arrSumField[j]+"_All")[0]){
				jsetFieldValueForSave(arrSumField[j]+"_All",jgetFieldValue(arrSumField[j]+"_1"));
			}
			else{
				alert("\u591A\u503C\u57DF"+arrSumField[j]+"_All\u4E0D\u5B58\u5728,\u8BF7\u68C0\u67E5!");
				return false;
			}
		}
	}
	return false;
	spanNewTable.innerHTML="";
}
//\u8BE5\u51FD\u6570\u4E0EjsetFieldValue\u51FD\u6570\u5C11\u4E86\u8F6C\u5316\u6362\u884C\u4EE3\u7801
function jsetFieldValueForSave(fieldName,value){
	var jfieldObj = $("[name='"+fieldName+"']");
	var fieldObj = jfieldObj[0];
	if(fieldObj.tagName=="TEXTAREA"){
		jfieldObj.val(value);
		if(fieldName.indexOf("CF_T_P9503_A__ZZHRPDPACT11")!=-1){
			var styleFieldName = "CF_T_P9503_A__ZZHRTXTYP1" + fieldName.substring(fieldName.lastIndexOf("_"),fieldName.length);
			var jstyleFieldObj = $("[name='"+styleFieldName+"']");
			if(jstyleFieldObj){
				if(jstyleFieldObj.val()){
					if(jstyleFieldObj.val().toUpperCase() == "B"){
						jfieldObj.css("font-weight","bold");
					}
				}
			}
		}
		return;
	}
	if(fieldObj.tagName=="SELECT")
	{
		jfieldObj.attr("value",value);
		return;
	}
	if(fieldObj.tagName=="INPUT"){
		if(fieldObj.type=="text"){
			jfieldObj.val(value);
			return;
		}
		if(fieldObj.type=="radio"){
			var f=eval("document.forms[0]."+fieldName);
			//$("input[@name="+fieldName+"][value="+value+"]").attr("checked",true);
			if(f.length==null)
			{
				if(f.value==value)
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==value)
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
		if(fieldObj.type=="checkbox"){
			var f=eval("document.forms[0]."+fieldName);
			var rtnV="";
			var valueArr=value.split(";");
			if(f.length==null)
			{
				if(f.value==valueArr[0])
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==valueArr[i])
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
	}
	return;
}
function getFieldValue(fieldName)
{
	var filedObj=getFieldObj(newTableID,fieldName);
	var f=eval("document.forms[0]."+fieldName);
	if(filedObj.tagName=="SELECT")
	{
		if(f.options[f.selectedIndex].text!="")
		{
			return f.options[f.selectedIndex].text;
		}
		else
		{
			return f.options[f.selectedIndex].value;
		}
	}
	else if(filedObj.tagName=="TEXTAREA")
	{
		if(f.value.indexOf("*&^")!=-1){
			re=/\*\&\^/g;
		}
		else{
			re=/\r\n/g;
		}
		return f.value.replace(re,"<br>");
	}
	else{
		if(filedObj.type=="text")
		{
			return f.value;
		}
		if(filedObj.type=="radio")
		{
			if(f.length==null)
			{
				if(f.checked)
				{
					return f.value;
				}
				else
				{
					return "";
				}
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].checked)
				{
					return f[i].value;
				}
			}
			return "";
		}
		if(filedObj.type=="checkbox")
		{
			var rtnV="";
			if(f.length==null)
			{
				if(f.checked)
				{
					return f.value;
				}
				else
				{
					return "";
				}
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].checked)
				{
					if(i!=0)
					{
						rtnV=rtnV+";"+f[i].value
					}
					else
					{
						rtnV=f[i].value;
					}
				}
				else
				{
					if(i!=0)
					{
						rtnV=rtnV+";";
					}
					else
					{
						rtnV="";
					}
				}
			}
			return rtnV;
		}
	}
	return "";
}

function jgetFieldValue(fieldName)
{
	var returnValue;
	var jfieldObj = $("[name='"+fieldName+"']");
	var fieldObj = jfieldObj[0];
	if(fieldObj.tagName=="TEXTAREA"){
		if(jfieldObj.val().indexOf("*&^")!=-1){
			re=/\*\&\^/g;
		}
		else{
			re=/\r\n/g;
		}
		return (jfieldObj.val().replace(re,"<br>"));
	}
	if(fieldObj.tagName=="SELECT")
	{
		return jfieldObj.val();
	}
	if(fieldObj.tagName=="INPUT"){
		if(fieldObj.type=="text"){
			return jfieldObj.val();
		}
		if(fieldObj.type=="radio"){
			returnValue = $("input:radio[name='"+fieldName+"']:checked").val();
			if(returnValue!=undefined){
				return returnValue;
			}
			else{
				return "";
			}
		}
		if(fieldObj.type=="checkbox"){
			returnValue = "";
			$("input:checkbox[name='"+fieldName+"']:checked").each(function(){
				returnValue = returnValue + $(this).val() + ";";
			});
			returnValue = returnValue.substring(0,returnValue.lastIndexOf(";"));
			return returnValue;
		}
	}
	return "";
}

function initTable(tablenum)
{
	//\u83B7\u5F97\u539F\u59CB\u8868\u683C
	dtable=eval("document.all.dtable_"+tablenum);
	//add by xwf
	arrField = new Array(); //added at 2012-07-26 by ningzhx
	//arrSumField = new Array();
	//alert(arrSumField.length);

	if(dtable==null)
	return;
	if(dtable.rows.length<2)
	return;
	var t_tmpTr;
	
	if(dtable.rows.length==2)
	{
		t_tmpTr=dtable.rows[1];
		getArrField(t_tmpTr);
		
	}
	else
	{
		t_tmpTr=dtable.rows[dtable.rows.length-2];
		getArrField(t_tmpTr);
		t_tmpTr=dtable.rows[dtable.rows.length-1];
		getSumArrField(t_tmpTr);
	}

	var tmpTalbe=dtable.cloneNode(true);
	_insertCell(tmpTalbe,0,"beforeBegin");
	_insertCell(tmpTalbe,tmpTalbe.rows[0].cells.length-1,"afterEnd");
	setTableNo(tmpTalbe);
	
	tmpTalbe.rows[0].cells[tmpTalbe.rows[0].cells.length-1].innerHTML=addr;
	tmpTalbe.rows[1].cells[tmpTalbe.rows[0].cells.length-1].innerHTML=delr;
	
	if(tmpTalbe.rows.length>2)tmpTalbe.rows[tmpTalbe.rows.length-1].cells[tmpTalbe.rows[0].cells.length-1].innerHTML=sumTable;

	/*20121121
	if(document.forms[0].Form.value!=="CFM_Custom_Class")
	{
		if(document.forms[0].F_MainDocStatus.value=="\u5F85\u5BA1"||document.forms[0].F_MainDocStatus.value=="\u901A\u8FC7")
		{
			tmpTalbe.rows[0].cells[tmpTalbe.rows[0].cells.length-1].innerHTML="\u3016 \u6DFB \u52A0 \u3017";
			tmpTalbe.rows[1].cells[tmpTalbe.rows[0].cells.length-1].innerHTML="\u3016 \u5220 \u9664 \u3017";
			tmpTalbe.rows[tmpTalbe.rows.length-1].cells[tmpTalbe.rows[0].cells.length-1].innerHTML=" ";
		}
	}
	*/
	
	html=tmpTalbe.outerHTML;
	html=html.replace(/dtable/i,"newTableID");
	html="<span id='spanNewTable'>"+html+"</span>";
	document.write(html);
	//\u83B7\u53D6\u65B0\u8868\u683C\u5BF9\u8C61
	newTableID=eval("document.all.newTableID_"+tablenum);
	
	if(newTableID.rows.length<3)
	{	
		for(var k=0;k<newTableID.rows[newTableID.rows.length-1].cells.length;k++)
		{
			newTableID.rows[newTableID.rows.length-1].cells[k].innerHTML=replaceField(newTableID.rows[newTableID.rows.length-1].cells[k].innerHTML,"","_1");
		}
	}
	else
	{
		for(var k=0;k<newTableID.rows[newTableID.rows.length-2].cells.length;k++)
		{
			newTableID.rows[newTableID.rows.length-2].cells[k].innerHTML=replaceField(newTableID.rows[newTableID.rows.length-2].cells[k].innerHTML,"","_1");
		}
		for(var k=0;k<newTableID.rows[newTableID.rows.length-1].cells.length;k++)
		{
			newTableID.rows[newTableID.rows.length-1].cells[k].innerHTML=replaceSumField(newTableID.rows[newTableID.rows.length-1].cells[k].innerHTML,"","_1");
		}
	}
	if(S_IsNewDoc=="0"||document.forms[0].F_MainDocStatus.value=="\u901A\u8FC7")initTableDate();
}
function setssFieldValue(fieldName,value)
{
	eval("document.forms[0]."+fieldName).value=value;
}

function getFieldObj(obj,objName)
{	
	for(var x=0;x<obj.childNodes.length;x++)
	{
		
		var rtnObj=getFieldObj(obj.childNodes[x],objName);
		if(rtnObj!=null)
		return rtnObj;
		if(obj.childNodes[x].tagName=="INPUT"||obj.childNodes[x].tagName=="TEXTAREA"||obj.childNodes[x].tagName=="SELECT")
		{
			if(obj.childNodes[x].name==objName)
			{
				return obj.childNodes[x];
			}
		}
	}
}

function jgetFieldObj(objName)
{
	var objType = $("[name='"+objName+"']");
	return objType;
}
function initTableDate(){

	var f="document.forms[0].";
	if(arrField.length==0)
	return;
	if(arrField[0]=="")
	return;
	for(var k=0;k<arrField.length;k++)
	{	
		if(arrField[k].indexOf("%%")==-1 && jgetFieldObj(arrField[k]+"_All")[0])
		{	
			var tmpArr=new Array();
			var tmpStr=eval(f+arrField[k]+"_All").value;
			tmpStr=tmpStr.replace(/\u25B2/ig,"");
			if(tmpStr.indexOf("*&^")!=-1){
				tmpArr=tmpStr.split("*&^");
			}
			else{
				tmpArr=tmpStr.split("\r\n");
			}
			for(var r=0;r<tmpArr.length;r++)
			{
				if(jgetFieldObj(arrField[k]+"_"+(r+1))[0]){

				}
				else{
					AddRow();
				}
				jsetFieldValue(arrField[k]+"_"+(r+1),tmpArr[r]);
				//setFieldValue(arrField[k]+"_"+(r+1),tmpArr[r]);
			}
		}
	}
	for(var j=0;j<arrSumField.length;j++)
	{
		if(arrSumField[j].indexOf("%%")==-1&&eval(f+arrSumField[j]+"_All")!=null)
		{
			eval(f+arrSumField[j]+"_1").value=eval(f+arrSumField[j]+"_All").value;
		}
	}
}

function getArrField(obj)
{
	for(var x=0;x<obj.childNodes.length;x++)
	{
		getArrField(obj.childNodes[x]);
		if(obj.childNodes[x].tagName=="INPUT"||obj.childNodes[x].tagName=="SELECT"||obj.childNodes[x].tagName=="TEXTAREA")
		{
			for(var i=0;i<arrField.length;i++)
			{
				if(arrField[i]==obj.childNodes[x].name)
				return;
			}
			arrField[arrField.length]=obj.childNodes[x].name;
		}
	}
}

function setFieldValue(fieldName,value)
{
	var filedObj=getFieldObj(newTableID,fieldName);
	var f=eval("document.forms[0]."+fieldName);
	if(filedObj!=null&&filedObj.tagName=="SELECT")
	{
		for(var i=0;i<f.options.length;i++)
		{
			if(f.options[i].text==value||f.options[i].value==value)
			{
				f.options[i].selected=true;
			}
			else
			{
				f.options[i].selected=false;
			}
		}
		return;
	}
	else if(filedObj!=null&&filedObj.tagName=="TEXTAREA"){
		f.value = value.replace(/#\$\%/g,"\n");
		return;
	}
	else
	{
		if(filedObj.type=="text")
		{
			f.value=value;
			return;
		}
		if(filedObj.type=="radio")
		{
			if(f.length==null)
			{
				if(f.value==value)
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==value)
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
		if(filedObj.type=="checkbox")
		{
			var rtnV="";
			var valueArr=value.split(";");
			if(f.length==null)
			{
				if(f.value==valueArr[0])
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==valueArr[i])
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
	}
	return "";
}

function jsetFieldValue(fieldName,value){
	var jfieldObj = $("[name='"+fieldName+"']");
	var fieldObj = jfieldObj[0];
	if(fieldObj.tagName=="TEXTAREA"){
		jfieldObj.val(value.replace(/#\$\%/g,"\n"));
		if(fieldName.indexOf("CF_T_P9503_A__ZZHRPDPACT11")!=-1){
			var styleFieldName = "CF_T_P9503_A__ZZHRTXTYP1" + fieldName.substring(fieldName.lastIndexOf("_"),fieldName.length);
			var jstyleFieldObj = $("[name='"+styleFieldName+"']");
			if(jstyleFieldObj){
				if(jstyleFieldObj.val()){
					if(jstyleFieldObj.val().toUpperCase() == "B"){
						jfieldObj.css("font-weight","bold");
					}
				}
			}
		}
		return;
	}
	if(fieldObj.tagName=="SELECT")
	{
		jfieldObj.attr("value",value);
		return;
	}
	if(fieldObj.tagName=="INPUT"){
		if(fieldObj.type=="text"){
			jfieldObj.val(value);
			return;
		}
		if(fieldObj.type=="radio"){
			var f=eval("document.forms[0]."+fieldName);
			//$("input[@name="+fieldName+"][value="+value+"]").attr("checked",true);
			if(f.length==null)
			{
				if(f.value==value)
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==value)
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
		if(fieldObj.type=="checkbox"){
			var f=eval("document.forms[0]."+fieldName);
			var rtnV="";
			var valueArr=value.split(";");
			if(f.length==null)
			{
				if(f.value==valueArr[0])
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==valueArr[i])
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
	}
	return;
}

function setFieldValue_bakxup(fieldName,value)
{	
	var filedObj=getFieldObj(newTableID,fieldName);
	var f=eval("document.forms[0]."+fieldName);
	
	if(filedObj!=null&&filedObj.tagName=="SELECT")
	{
		for(var i=0;i<f.options.length;i++)
		{
			if(f.options[i].text==value||f.options[i].value==value)
			{
				f.options[i].selected=true;
			}
			else
			{
				f.options[i].selected=false;
			}
		}
		return;
	}
	else
	{
		if(filedObj.type=="text")
		{
			f.value=value;
			return;
		}
		if(filedObj.type=="radio")
		{
			if(f.length==null)
			{
				if(f.value==value)
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==value)
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
		if(filedObj.type=="checkbox")
		{
			var rtnV="";
			var valueArr=value.split(";");
			if(f.length==null)
			{
				if(f.value==valueArr[0])
				{
					f.checked=true;
				}
				else
				{
					f.checked=false;
				}
				return;
			}
			for(var i=0;i<f.length;i++)
			{
				if(f[i].value==valueArr[i])
				{
					f[i].checked=true;
				}
				else
				{
					f[i].checked=false;
				}
			}
			return;
		}
	}
	return "";
}
function getSumArrField(obj)
{
	for(var x=0;x<obj.childNodes.length;x++)
	{
		getSumArrField(obj.childNodes[x]);
		if(obj.childNodes[x].tagName=="INPUT")
		{
			for(var i=0;i<arrSumField.length;i++)
			{
				if(arrSumField[i]==obj.childNodes[x].name)
				return;
			}
			arrSumField[arrSumField.length]=obj.childNodes[x].name;
		}
	}
}
function replaceField(html,pre,nxt)
{
	var tmpHtml=html;
	for(var k=0;k<arrField.length;k++)
	{
		var re=new RegExp(arrField[k]+pre,"g");
		tmpHtml=tmpHtml.replace(re,arrField[k]+nxt);
	}
	return tmpHtml;
}
function replaceSumField(html,pre,nxt)
{
	var tmpHtml=html;
	for(var k=0;k<arrSumField.length;k++)
	{
		var re=new RegExp(arrSumField[k]+pre,"g");
		tmpHtml=tmpHtml.replace(re,arrSumField[k]+nxt);
	}
	return tmpHtml;
}
function insertRow(myTable,theRowNum,sWhere)
{
	var i,j,newTR;
	i=theRowNum;
	if(myTable)
	{
		newTR=myTable.rows[i].cloneNode(true);
		myTable.rows[i].insertAdjacentElement(sWhere,newTR);
	}
}
function delRow()
{
	var oa=window.event.srcElement;

//\u83B7\u5F97\u5F53\u524D\u4E8B\u4EF6\u5BF9\u5E94\u7684\u663E\u793A\u8868\u683C\u5BF9\u8C61\u53CA\u539F\u59CB\u8868\u683C\u5BF9\u8C61
	getdtTable(window.event.srcElement);
//add by xwf

	if(actioning)
	return;
	actioning=true;
	
	var otr=oa.parentElement;
	var i=0;
	while(otr.tagName!="TR")
	{
		otr=otr.parentElement;
		i=otr.rowIndex;
	}
	if(checkRow()){
		newTableID.deleteRow(i);
		for(var k=i;k<newTableID.rows.length;k++)
		{
			for(var r=0;r<newTableID.rows[k].cells.length;r++)
			{
				newTableID.rows[k].cells[r].innerHTML=replaceField(newTableID.rows[k].cells[r].innerHTML,"_"+(k+1),"_"+k);
			}
		}
		setTableNo(newTableID);
	}
	actioning=false;
}
function AddRow()
{	
//\u83B7\u5F97\u5F53\u524D\u4E8B\u4EF6\u5BF9\u5E94\u7684\u663E\u793A\u8868\u683C\u5BF9\u8C61\u53CA\u539F\u59CB\u8868\u683C\u5BF9\u8C61
	if(window.event && window.event!=null){
		getdtTable(window.event.srcElement);
	}
//add by xwf

	if(actioning)
	return;
	actioning=true;
	var sWhere;
	var i,newTR;
	if(dtable.rows.length>2)
	{
		i=newTableID.rows.length-2;
	}
	else
	{
		i=newTableID.rows.length-1; //1
	}
	sWhere="afterEnd";
	if(newTableID)
	{	
		if(newTableID.rows.length<dtable.rows.length)
		{	
			var tmpTable=dtable.cloneNode(true);
			_insertCell(tmpTable,0,"beforeBegin");
			_insertCell(tmpTable,tmpTable.rows[0].cells.length-1,"afterEnd");
			tmpTable.rows[1].cells[tmpTable.rows[0].cells.length-1].innerHTML=delr;
			newTR=newTableID.rows[0].cloneNode(true);
			newTableID.rows[0].insertAdjacentElement(sWhere,newTR);
			for(var k=0;k<newTableID.rows[1].cells.length;k++)
			{
				newTableID.rows[1].cells[k].innerHTML=replaceField(tmpTable.rows[1].cells[k].innerHTML,"","_1")
			}
		}
		else
		{	
			newTR=newTableID.rows[i].cloneNode(true);
			newTableID.rows[i].insertAdjacentElement(sWhere,newTR);
			for(var k=0;k<newTableID.rows[i+1].cells.length;k++)
			{
				newTableID.rows[i+1].cells[k].innerHTML=replaceField(newTableID.rows[i+1].cells[k].innerHTML,"_"+i,"_"+(i+1));
			}
		}
		setTableNo(newTableID);
	}
	actioning=false;
}




function sumTalbeField()
{
//\u83B7\u5F97\u5F53\u524D\u4E8B\u4EF6\u5BF9\u5E94\u7684\u663E\u793A\u8868\u683C\u5BF9\u8C61\u53CA\u539F\u59CB\u8868\u683C\u5BF9\u8C61
	getdtTable(window.event.srcElement);
//add by xwf
		
	var f="document.forms[0].";
	for(var j=0;j<arrSumField.length;j++)
	{
		var tmpFieldName=arrSumField[j].substring(0,arrSumField[j].lastIndexOf("_Sum"));
		
		var tmpSum=0;
		for(var k=0;k<newTableID.rows.length;k++)
		{
			if(eval(f+tmpFieldName+"_"+(k+1))!=null)
			{
				if(!isNaN(eval(f+tmpFieldName+"_"+(k+1)).value))
				{
					tmpSum=tmpSum+parseFloat(eval(f+tmpFieldName+"_"+(k+1)).value);
				}
			}
		}
	
		if(eval(f+tmpFieldName+"_Sum_1")!=null)
		{
			eval(f+tmpFieldName+"_Sum_1").value=tmpSum;
		}
	}

}
function checkRow()
{
	if(newTableID)
	{
		if(newTableID.rows.length==2) {
			alert("\u8BE5\u8868\u683C\u5DF2\u5269\u4E0B\u4E00\u884C\uFF0C\u8BF7\u4E0D\u8981\u5220\u9664\u3002");
			return false;
		}else
			return true;
	}

}



function setTableNo(theTable)
{
	for(var i=0;i<theTable.rows.length;i++)
	{
		if(i==0)
		{
			theTable.rows[i].cells[0].innerText="\u5E8F\u53F7";
			theTable.rows[i].cells[0].noWrap=true;
		}
		else
		{
			theTable.rows[i].cells[0].innerText=""+i;
		}
	}
	if(dtable.rows.length>2)theTable.rows[theTable.rows.length-1].cells[0].innerText="\u5408\u8BA1";
}
function _insertCell(myTable,theCellNum,sWhere)
{
	var i,j,newTD;
	j=theCellNum;
	if(myTable)
	{
		for(i=0;i<myTable.rows.length;i++)
		{	
			newTD=myTable.rows[i].cells[j].cloneNode(true);
			if(j==0)
				newTD.width="3%"
			else    
				newTD.width="5%"
			newTD.innerText="";
			newTD.colSpan=1;
			newTD.nowrap=true;
			newTD.align="center";
			myTable.rows[i].cells[j].insertAdjacentElement(sWhere,newTD);
		}
	}
}
function filemngRtf()
{
	if(subform=="")
	{
		try
		{
			initRtf("F_Body");
		}
		catch(e)
		{
		}
	}
	else
	{
		document.all.tb_1.style.display="none";
		document.all.tb_2.style.display="none";
	}
}
function filemngClassRtf()
{
	if(subform=="")
	{
		try
		{
			initRtf("F_Body");
		}
		catch(e)
		{
		}
	}
	else
	{
		document.all.tb_1.style.display="none";
		document.all.tb_2.style.display="none";
	}
}
function reviewRtf()
{
	if(subform=="")
	{
		try
		{
			initRtf("F_Body");
		}
		catch(e)
		{
		}
	}
	else
	{
		document.all.tb_1.style.display="none";
	}
}

//\u83B7\u53D6\u5F53\u524D\u8868\u683C
function getdtTable(tableObj)
{
	while(tableObj != null && tableObj.tagName!="TABLE")
		tableObj=tableObj.parentElement;
	if (!tableObj && tableObj == null)
		return;

	else{		
		var TableNum =tableObj.id
		TableNum = TableNum.substring(TableNum.length-1,TableNum.length)
		getCurField(TableNum);
	     }
}
//\u83B7\u53D6\u8BE5\u8868\u683C\u5BF9\u5E94\u7684\u4FE1\u606F
function getCurField(Num){

	var t_tmpTr
	dtable = eval("dtable_"+ Num)
	newTableID=eval("newTableID_"+Num);
	arrField = new Array();
	arrSumField = new Array();

	if(dtable.rows.length==2)
	{
		t_tmpTr=dtable.rows[1];
		getArrField(t_tmpTr);
	}
	else{
		t_tmpTr=dtable.rows[dtable.rows.length-2];
		getArrField(t_tmpTr);
		t_tmpTr=dtable.rows[dtable.rows.length-1];
		getSumArrField(t_tmpTr);
	}
}
//\u5FAA\u73AF\u8C03\u7528initTable added by ningzhx at 2012-07-24\u3002
//\u6CE8\u610F\uFF1A\u5728\u5B50\u8868\u5355rtf\u57DF\u540E\u7684\u8BA1\u7B97\u6587\u672C\u4E2D\u7684\u8C03\u7528\u7531initTable\u6539\u4E3AinitAllDynamicTable(inum),\u5176\u4E2Dinum\u4E3A\u52A8\u6001\u8868\u683C\u7684\u4E2A\u6570\u3002
function initAllDynamicTable(iNum){
	for(var i=1;i<=iNum;i++){
		initTable(i);
	}
}

//\u4EE5\u4E0B\u662F\u5B50\u8868\u5355\u4F7F\u7528\u5230\u7684\u903B\u8F91\u529F\u80FD\u51FD\u6570
/***********************************************
\u529F\u80FD\uFF1A\u6784\u9020XMLHTTP\u5BF9\u8C61
***********************************************/
function CLASS_XMLHTTP(){
	var request = false;
	try{
		request = new XMLHttpRequest();
	}catch (trymicrosoft){
		try{
			request = new ActiveXObject("Msxml2.XMLHTTP");
		}catch (othermicrosoft){
			try{
			   request = new ActiveXObject("Microsoft.XMLHTTP");
			}catch (failed){
				request = false;
			}
		}
	}
	return request;
}

/***********************************************
\u529F\u80FD\uFF1A\u6D6E\u70B9\u578B\u6570\u636E\u7684\u68C0\u6D4B\uFF0C\u4E0D\u5408\u6CD5\u5219\u8F6C\u6362\u4E3A\u5408\u6CD5
***********************************************/
function checkFloat(obj){
	var str_tmp;
	var str_val="";
	for (var i=0;i<obj.value.length;i++){
		str_tmp=obj.value.substring(i,i+1);		
	 if ( (str_tmp>="0" && str_tmp<="9") || (str_tmp=="." && obj.value.indexOf(".")!=0) || str_tmp == "-")
			str_val+=str_tmp
	}
	if (obj.value!=str_val) obj.value=str_val;
}
//\u4E8C\u6B21\u67E5\u770B \u6821\u9A8C\u9886\u5BFC\u5206
function CheckLeaderGrade(flag){
	var request = new CLASS_XMLHTTP();
	
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var oawfo = document.all.CF_Oawfno.value;
	var accessUrl=path+"/CAG_HRAPP_CheckLeaderGrade?OpenAgent";
	accessUrl = accessUrl+"&oawfo="+escape(oawfo)+"&MainDocId="+escape(MainDocId)+"&CustomDocID="+escape(S_DocId)+"&flag="+escape(flag);
	
	request.open("POST",accessUrl,false);
	request.send(null);

	var responseText=request.responseText;
   	var responseArr = responseText.split("@");
   	var statusNo = responseArr[1];
   	
   	if(statusNo=="E" || statusNo==null || statusNo==""){
   		alert(responseArr[2]);
   		return false;
   	}else return true;
}
//\u6539\u53D8\u8C03\u7528\u7EE9\u6548\u590D\u6742\u6D41\u7A0B\u7B2C\u4E8C\u4E2A\u6D41\u7A0B\u67E5\u770B\u4FE1\u606F\u51FD\u6570
function viewInfoChangeFun(){
	var RunFunFlag="";
	if(document.all.InterfaceTypeIsWSForJS){
		if(document.all.InterfaceTypeIsWSForJS.value=="1"){
			RunFunFlag = "WS";
		}
	}
	if(RunFunFlag=="WS"){
		viewInfo_WS();
	}else{
		viewInfo();
	}
} 
/***********************************************
\u529F\u80FD\uFF1A\u7EE9\u6548\u590D\u6742\u6D41\u7A0B\u7B2C\u4E8C\u4E2A\u6D41\u7A0B\u67E5\u770B\u4FE1\u606F\u7528
***********************************************/
var DeclareGuid,DeclareDept,DeclareMainDocID;
function viewInfo(){
	var srcEl = window.event.srcElement;
	var parEl= srcEl.parentElement;
	var i=0;
	//\u83B7\u53D6\u67E5\u770B\u7684\u884C\u6570
	while(parEl.tagName!="TR"){
		parEl=parEl.parentElement;
		i=parEl.rowIndex;
	}

	//\u83B7\u53D6\u5BF9\u5E94\u7684\u5206\u7BA1\u90E8\u95E8\u503C
	var dept = document.all.CF_T_HEADER__KODEPT1_All.value;
	if(dept.indexOf("*&^")!=-1){
		var deptV = dept.split("*&^")[i-1];
	}
	else{
		var deptV = dept.split("\r\n")[i-1];
	}

	//\u83B7\u53D6\u5BF9\u5E94\u7684GUID\u503C
	var guid = document.all.CF_T_HEADER__ZZ_GUID1_All.value;
	if(guid.indexOf("*&^")!=-1){
		var guidV = guid.split("*&^")[i-1];
	}
	else{
		var guidV = guid.split("\r\n")[i-1];
	}
	
	DeclareGuid = guidV;
	DeclareDept = deptV;
	DeclareMainDocID = MainDocId;
	
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	var accessUrl=path+"/CAG_HRAPP_GetAPPInfo?OpenAgent&guid="+escape(guidV)+"&dept="+escape(deptV)+"&docid="+escape(MainDocId);

	request.open("POST",accessUrl,false);
	request.send(null);
	var t=setTimeout("viewInfoPrint();",6000);
}
function viewInfo_WS(){
	var srcEl = window.event.srcElement;
	var parEl= srcEl.parentElement;
	var i=0;
	//\u83B7\u53D6\u67E5\u770B\u7684\u884C\u6570
	while(parEl.tagName!="TR"){
		parEl=parEl.parentElement;
		i=parEl.rowIndex;
	}

	//\u83B7\u53D6\u5BF9\u5E94\u7684\u5206\u7BA1\u90E8\u95E8\u503C
	var dept = document.all.CF_T_HEADER__KODEPT1_All.value;
	if(dept.indexOf("*&^")!=-1){
		var deptV = dept.split("*&^")[i-1];
	}
	else{
		var deptV = dept.split("\r\n")[i-1];
	}

	//\u83B7\u53D6\u5BF9\u5E94\u7684GUID\u503C
	var guid = document.all.CF_T_HEADER__ZZ_GUID1_All.value;
	if(guid.indexOf("*&^")!=-1){
		var guidV = guid.split("*&^")[i-1];
	}
	else{
		var guidV = guid.split("\r\n")[i-1];
	}
	
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	var accessUrl=path+"/CAG_HRAPP_GetAPPInfo_WS?OpenAgent&guid="+escape(guidV)+"&dept="+escape(deptV)+"&docid="+escape(MainDocId);
	
	request.open("POST",accessUrl,false);
	request.send(null);
	responseText=request.responseText;
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	if(result == "null" || result == ""){
		alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
		return false;
	}
	else{
		//var Style= "LEFT=3000,TOP=2000,resizable=0,scrollbars=0";
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		
		//\u5F53\u524D\u5B50\u8868\u5355\uFF1ACSF_SAPHRAPP0302  \u5BF9\u5E94\u8868\u5355\uFF1AFM_SAPHRAPP0302  \u5BF9\u5E94\u89C6\u56FE\uFF1AVD_SAPHRAPP0302
		var power = checkPower();
		var vStatus = checkStatus();
		accessUrl=result+"&isedited="+power+"&vstatus="+vStatus;
		var winobj = window.open(accessUrl,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
	}
}
/*Add by huyiqun 20131216 \u65B0\u589E\u901A\u7528\u521B\u5EFA\u5F85\u529E\u670D\u52A1\u7684\u7EE9\u6548\u4E8C\u53D6\u6570\u529F*/
function viewInfo_ReloadData(){
	var srcEl = window.event.srcElement;
	var parEl= srcEl.parentElement;
	var i=0;
	//\u83B7\u53D6\u67E5\u770B\u7684\u884C\u6570
	while(parEl.tagName!="TR"){
		parEl=parEl.parentElement;
		i=parEl.rowIndex;
	}
	
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	var accessUrl=path+"/CAG_ESB_ReloadData_JAVA?OpenAgent&index="+escape(i-1)+"&maindocid="+escape(MainDocId);
	
	request.open("POST",accessUrl,false);
	request.send(null);
	responseText=request.responseText;
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	if(result == "null" || result == ""){
		alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
		return false;
	}else{
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		//\u79F0
		var NodeName = parent.FlowCurNodeName;
		
		//\u5F53\u524D\u8282\u70B9\u662F\u5426\u5177\u6709\u7F16\u8F91\u6743\u9650:0-\u65E0,1-\u6709
		var Str_isedited = "0";
		//\u5F53\u524D\u8282\u70B9\u662F\u5426\u5177\u6709\u586B\u5199\u5355\u884C\u610F\u89C1\u4E0E\u5206\u6570\u6743\u9650\uFF1A0-\u65E0,1-\u6709(\u7F16\u8F91\u6307\u6807\u5206\u7BA1\u90E8\u95E8\u610F\u89C1),2-\u6709(\u7F16\u8F91\u4E1A\u52A1\u5206\u7BA1\u9886\u5BFC\u610F\u89C1)
		var Str_vstatus = "0";
		if(maindocStatus=="\u5F85\u5BA1"){
			if(NodeName.indexOf("\u6307\u6807\u5206\u7BA1")>-1){
				Str_isedited = "1";
				Str_vstatus = "1";
			}
			if(NodeName.indexOf("\u4E1A\u52A1\u5206\u7BA1")>-1){
				Str_isedited = "1";
				Str_vstatus = "2";
			}
		}
		accessUrl=result+"&isedited="+Str_isedited+"&vstatus="+Str_vstatus;
		var winobj = window.open(accessUrl,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
	}
}
var xmlHttp;
function viewInfoPrint(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRAPP_OpenURLForAPPInfo?OpenAgent&guid="+escape(DeclareGuid)+"&dept="+escape(DeclareDept)+"&docid="+escape(DeclareMainDocID);
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	responseText=xmlHttp.responseText;
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	if(result == "null" || result == ""){
		alert("\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u91CD\u65B0\u70B9\u51FB\uFF01");
		return false;
	}else{
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		//\u5F53\u524D\u5B50\u8868\u5355\uFF1ACSF_SAPHRAPP0302  \u5BF9\u5E94\u8868\u5355\uFF1AFM_SAPHRAPP0302  \u5BF9\u5E94\u89C6\u56FE\uFF1AVD_SAPHRAPP0302
		var power = checkPower();
		var vStatus = checkStatus();
		accessUrl=result+"&isedited="+power+"&vstatus="+vStatus;
		var winobj = window.open(accessUrl,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
	}
}

/***********************************************
\u529F\u80FD\uFF1ARC17A\u6D41\u7A0B\u67E5\u770B\u4FE1\u606F\u7528
***********************************************/
function viewInfoRC(){
	var srcEl = window.event.srcElement;
	var parEl= srcEl.parentElement;
	var i=0;
	//\u83B7\u53D6\u67E5\u770B\u7684\u884C\u6570
	while(parEl.tagName!="TR"){
		parEl=parEl.parentElement;
		i=parEl.rowIndex;
	}
	
	//\u83B7\u53D6\u5BF9\u5E94\u7684GUID\u503C
	var guid = document.all.CF_P9463_T__ZZ_GUID21_All.value;
	if(guid.indexOf("*&^")!=-1){
		var guidV = guid.split("*&^")[i-1];
	}
	else{
		var guidV = guid.split("\r\n")[i-1];
	}
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;

	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	var accessUrl=path+"/CAG_HRRC_GetRCInfo?OpenAgent&guid="+escape(guidV)+"&docid="+escape(MainDocId);
	request.open("POST",accessUrl,false);
	request.send(null);
	
	var t=setTimeout("viewRCInfoPrint();",6000);
}
var xmlHttp;
function viewRCInfoPrint(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRRC_OpenURLForRCInfo?OpenAgent";
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	responseText=xmlHttp.responseText;
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	if(result == "null" || result == ""){
		alert("\u7CFB\u7EDF\u7E41\u5FD9\uFF0C\u8BF7\u91CD\u65B0\u70B9\u51FB\uFF01");
		return;
	}
	else{
		//var Style= "LEFT=3000,TOP=2000,resizable=0,scrollbars=0";
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		var winobj = window.open(result,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
	}
}

/***********************************************
\u529F\u80FD\uFF1A\u57F9\u8BAD\u6D41\u7A0B\u4FEE\u6539\u4FE1\u606F
***********************************************/
var xmlHttp;
function modifyTEMSAPInfo(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRTEM_GetURL?OpenAgent&cusdocid="+escape(S_DocId);
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	var t = setTimeout("openModifyTEMSAPInfo()","4000");
}

function openModifyTEMSAPInfo(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRTEM_OpenURL?OpenAgent";
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	responseText=xmlHttp.responseText;
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	if(result == "null" || result == ""){
		alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
		return;
	}
	else{
		//var Style= "LEFT=3000,TOP=2000,resizable=0,scrollbars=0";
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		
		alert("\u5C06OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
		var winobj = window.open(result,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
	}
}
/***********************************************
\u529F\u80FD\uFF1A\u62DB\u8058\u6D41\u7A0B\u4FEE\u6539\u4FE1\u606F
***********************************************/
var xmlHttp;
function modifyRCSAPInfo(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRRC_GetURL?OpenAgent&cusdocid="+escape(S_DocId);
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	var t = setTimeout("openModifyRCSAPInfo()","4000");
}

function openModifyRCSAPInfo(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRRC_OpenURL?OpenAgent";
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	responseText=xmlHttp.responseText;
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	if(result == "null" || result == ""){
		alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
		return;
	}
	else{
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		
		alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
		var winobj = window.open(result,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
	}
}
/***********************************************
\u529F\u80FD\uFF1ASAP\u6570\u636E WS
***********************************************/
var xmlHttp;
function ModifySAPInfo_WS(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HR_GetURL_WS?OpenAgent&pname="+escape(proposerName)+"&guid="+escape(guid)+"&oawfo="+escape(oawfo)+"&hr2oawf="+escape(hr2oawf)+"&cusdocid="+escape(S_DocId);
	
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	responseText=xmlHttp.responseText;
	
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	
	var responseArr = result.split("@");
   	var statusNo = responseArr[0];
   			
   	if(statusNo != "S"){
		alert(responseArr[1]);return;
	}else{
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		
		alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
		window.open(responseArr[2],"_blank",Style);
	}
}
/*\u529F\u80FD\uFF1A\u4FEE\u6539\u6570\u636E Add by huyiqun 20140103*/
var xmlHttp;
function ModifySAPInfo_ReloadData(){
	if(document.all.CF_NeedReGetContent){
		document.all.CF_NeedReGetContent.value="1";
	}
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_ESB_ReloadData_JAVA?OpenAgent&maindocid="+escape(MainDocId);
	
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	responseText=xmlHttp.responseText;
	
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
	
	var responseArr = result.split("@");
   	var statusNo = responseArr[0];
   			
   	if(statusNo != "S"){
		alert(responseArr[1]);return;
	}else{
		var Style= "top=0,left=0,toolbar=yes,location=yes,scrollbars=yes,resizable=yes,status=yes";
		
		alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
		window.open(responseArr[2],"_blank",Style);
	}
}
function modifySAPInfo_0522(){
	if(window.XMLHttpRequset){
  		xmlHttp = new XMLHttpRequest();
 	}else if(window.ActiveXObject){
  		xmlHttp = new ActiveXObject("Microsoft.XMLHTTP");
 	}
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRTEMRC_GetURL?OpenAgent&pname="+escape(proposerName)+"&guid="+escape(guid)+"&oawfo="+escape(oawfo)+"&hr2oawf="+escape(hr2oawf)+"&cusdocid="+escape(S_DocId);
	
	
	xmlHttp.open("POST",accessUrl,false);
	xmlHttp.send(null);
	var responseText=xmlHttp.responseText;
	responseText=responseText.substring(responseText.indexOf("@")+1);
     var result=responseText.substring(0,responseText.indexOf("@"));
	if(result == "null" || result==""){
     	alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
		return;
	}else if(responseText.indexOf("\u9519\u8BEF")!=-1){
     	alert(result);
		return;
	}else{
		saveAppDoc();
		var Style= "top=0,left=0";
		var winobj = window.open(result,"_blank",Style);
		winobj.resizeTo(window.screen.availWidth,window.screen.availHeight);
     }
	/*
	\u8BE5\u79CD\u65B9\u5F0F\u5728\u8FDE\u7EED\u70B9\u51FB2\u6B21\u4F1A\u6709\u95EE\u9898
	xmlHttp.open("GET",accessUrl,true);
 	xmlHttp.onreadystatechange=callback;
 	xmlHttp.send(null);
 	*/
}

function callback(){
	if(xmlHttp.readyState == 4){
		if(xmlHttp.status == 200){
   			var responseText=xmlHttp.responseText;
			responseText=responseText.substring(responseText.indexOf("@")+1);
     		var result=responseText.substring(0,responseText.indexOf("@"));
			if(result == "null" || result==""){
     			alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
				return;
			}else if(responseText.indexOf("\u9519\u8BEF")!=-1){
     			alert(result);
				return;
			}else{
				saveAppDoc();
				var Style= "LEFT=3000,TOP=2000,resizable=0,scrollbars=0";
				window.open(result,"_blank",Style);
     		}
  		}
 	}
}

/***********************************************
\u529F\u80FD\uFF1A\u57F9\u8BAD/\u62DB\u8058\u6D41\u7A0B\u4FEE\u6539\u4FE1\u606F(\u5907\u4EFD)
***********************************************/
function modifySAPInfo1(){	
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRTEMRC_GetURL?OpenAgent&docid="+escape(MainDocId)+"&pname="+escape(proposerName)+"&guid="+escape(guid)+"&oawfo="+escape(oawfo)+"&hr2oawf="+escape(hr2oawf);

	request.open("POST",accessUrl,false);
	request.send(null);

	responseText=request.responseText;
	alert(responseText);
	responseText=responseText.substring(responseText.indexOf("*")+1);
	var result=responseText.substring(0,responseText.indexOf("*"));
			
	if(result == "null"){
		alert("\u83B7\u53D6SAP URL\u9519\u8BEF\uFF0C\u8BF7\u8054\u7CFB\u7BA1\u7406\u5458\uFF01");
		return;
	}else if(responseText.indexOf(":")!=-1){
		alert(result);
		return;
	}else{
		alert(result);
		var Style= "LEFT=3000,TOP=2000,resizable=0,scrollbars=0";
		window.open(result,"_blank",Style);
	}
}

/***********************************************
\u529F\u80FD\uFF1A\u68C0\u67E5\u5F53\u524D\u8282\u70B9\u662F\u5426\u5177\u6709\u7F16\u8F91\u6743\u9650:0-\u6CA1\u6709,1-\u6709
***********************************************/
function checkPower(){
	if(maindocStatus != "\u5F85\u5BA1") return "0";
		
	var curnode = parent.ifFlow.document.all.F_ReviewNo.value;
	if(parent.ifFlow.getOption(curnode, 8) != "" && parent.ifFlow.getOption(curnode, 8) != "0") return "1";
	else return "0";
}

/**********************************
*vStatus:0-\u8D77\u8349\u4EBA\u9636\u6BB5,\u4E0D\u80FD\u7F16\u8F91\u5355\u884C\u610F\u89C1\u548C\u5206\u6570\uFF0C\u9690\u85CF\u8868\u5355\u4E0B\u9762\u6240\u6709\u610F\u89C1\u548C\u5206\u6570
*vStatus:1-\u586B\u5199\u5355\u884C\u610F\u89C1\u548C\u5206\u6570\u7684\u8282\u70B9,\u663E\u793A\u548C\u7F16\u8F91\u8868\u5355\u4E0B\u9762yc1,yc2,yc3,yc4,yc5,yc6\u4FE1\u606F\uFF0C\u9690\u85CF\u540E\u7EED\u5176\u4ED6\u4FE1\u606F
*vStatus:2-\u663E\u793A\u8868\u5355\u4E0B\u9762yc1,yc2,yc3,yc4,yc5,yc6\u4FE1\u606F\uFF0C\u663E\u793A\u548C\u7F16\u8F91yc7,yc8,yc9,yc10,yc11,yc12\u4FE1\u606F\uFF0C\u9690\u85CF\u540E\u7EED\u5176\u4ED6\u4FE1\u606F
*vStatus:3-\u663E\u793A\u8868\u5355\u4E0B\u9762yc1,yc2,yc3,yc4,yc5,yc6,yc7,yc8,yc9,yc10,yc11,yc12\u4FE1\u606F\uFF0C\u663E\u793A\u548C\u7F16\u8F91yc13,yc14,yc15,yc16,yc17,yc18\u4FE1\u606F
Modify by huyiqun 20131113 \u8BE5\u51FD\u6570\u4EC5\u7EE9\u6548\u590D\u6742\u6D41\u7A0B\u8C03\u7528\uFF0C\u6743\u9650\u914D\u7F6E\u4E3A2\u8868\u793A\u53EF\u4FEE\u6539\u7B2C\u4E8C\u4E2A\u8282\u70B9\u7684\u5BA1\u6279\u4EBA\u5373N1(\u5206\u7BA1\u90E8\u95E8\u603B\u76D1)\u53EF\u4FEE\u6539N2(\u5206\u7BA1\u9886\u5BFC)\u7684\u5BA1\u6279\u4EBA
**********************************/
function checkStatus(){
	if(maindocStatus=="\u65B0\u6587\u6863" || maindocStatus=="\u8349\u7A3F" || maindocStatus=="\u9A73\u56DE" || maindocStatus=="\u64A4\u56DE") return "0";
	if(maindocStatus == "\u5F85\u5BA1"){
		var curnode = parent.ifFlow.document.all.F_ReviewNo.value;
		var ifOption = parent.ifFlow.getOption(curnode, 8);
		if(ifOption == "-1"){
			return "1";
		}else if(ifOption == "-2"){
			return "2";
		}else if(ifOption == "-3"){
			return "3";
		}else if(ifOption == "2"){
			return "1";
		}else{
			return "0";
		}
	}else{
		return "0";
	}
}

/***********************************************
\u529F\u80FD\uFF1A\u9A8C\u8BC1\u5206\u6570\u5728-10\u5230120\u4E4B\u95F4\uFF0C\u4E14\u4FDD\u75592\u4F4D\u5C0F\u6570
***********************************************/
function confirmScore(obj){
	if(trim(obj.value)==""){obj.value="0";return;}
	if(trim(obj.value)=="0"){return;}
	if(trim(obj.value)=="0.00"){obj.value="0";return;}
	
	var num = new Number(obj.value);

	if(num > 120){
		alert("\u8BC4\u5206\u4E0D\u80FD\u8D85\u8FC7120\u5206\u3002");
		obj.focus();
		obj.value="";
		return false;
	}
	if(num < -10){
		alert("\u8BC4\u5206\u4E0D\u80FD\u5C0F\u4E8E-10\u5206\u3002");
		obj.focus();
		obj.value="";
		return false;
	}
	obj.value=new Number(num).toFixed(2);
}

/***********************************************
\u529F\u80FD\uFF1A\u6839\u636E\u5355\u884C\u7684\u5206\u6570\u548C\u6743\u91CD\u8BA1\u7B97\u76F4\u63A5\u4E3B\u7BA1\u7684\u5206\u6570(APP08,APP11,APP20)
2017-04-06 modified By Qicb \u589E\u52A0\u6743\u91CD\u5224\u65AD\uFF08\u5904\u7406\u5206\u6570\u51FA\u73B0NaN\u60C5\u51B5\uFF09
D(\u5206\u6570)\u8BA1\u7B97\u89C4\u5219\uFF1A	A(\u6743\u91CD*\u5206\u6570\u7D2F\u52A0)/B(\u6743\u91CD\u7D2F\u52A0)+C(\u8D1F\u5206\u6570\u7D2F\u52A0)
A\u3001B\u8BA1\u7B97\u89C4\u5219\uFF1A		\u6743\u91CD>0\u4E14\u5206\u6570<=0 \u4E0D\u8BA1\u7B97
C \u8BA1\u7B97\u89C4\u5219\uFF1A		\u5206\u6570<0 \u8BA1\u7B97
***********************************************/
function computeScoreNew(objTable,indexI,indexJ){
	var dtable = document.getElementById(objTable);
	var ValueA = 0;
	var ValueB = 0;
	var ValueC = 0;
	var ValueD = 0;
	var ValueWeight = 0;
	var ValueGrade = 0;

	for(var i = 1;i<dtable.rows.length;i++){
		ValueWeight = new Number(dtable.rows[i].cells[indexI].firstChild.value);	//\u6743\u91CD
		ValueGrade = new Number(dtable.rows[i].cells[indexJ].firstChild.value);		//\u5206\u6570
		
		if(ValueWeight>0 && ValueGrade<=0){
		}else{
			ValueA = ValueA + (ValueWeight*ValueGrade);
			ValueB = ValueB + ValueWeight;
		}
		if(ValueGrade<0){
			ValueC = ValueC + ValueGrade;
		}
	}
	
	if(ValueB>0){
		ValueD = (ValueA/ValueB) + ValueC;
		ValueD = ValueD.toFixed(2);
	}
	
	if(document.all.CF_LeadFSC) document.all.CF_LeadFSC.value = ValueD;
	if(document.all.CF_LeadFS_Auto) document.all.CF_LeadFS_Auto.value = ValueD;
	if(document.all.CF_LeadFS) document.all.CF_LeadFS.value = ValueD;
	if(document.all.CF_LeadDJ)document.all.CF_LeadDJ.value = computeGrade(ValueD);
}

/***********************************************
\u529F\u80FD\uFF1A\u8FD4\u56DE\u5206\u6570(App0903,App1203)
2017-04-06 modified By Qicb \u589E\u52A0\u6743\u91CD\u5224\u65AD\uFF08\u5904\u7406\u5206\u6570\u51FA\u73B0NaN\u60C5\u51B5\uFF09
D(\u5206\u6570)\u8BA1\u7B97\u89C4\u5219\uFF1A	A(\u6743\u91CD*\u5206\u6570\u7D2F\u52A0)/B(\u6743\u91CD\u7D2F\u52A0)+C(\u8D1F\u5206\u6570\u7D2F\u52A0)
A\u3001B\u8BA1\u7B97\u89C4\u5219\uFF1A		\u6743\u91CD>0\u4E14\u5206\u6570<=0 \u4E0D\u8BA1\u7B97
C \u8BA1\u7B97\u89C4\u5219\uFF1A		\u5206\u6570<0 \u8BA1\u7B97
***********************************************/
function computeScoreReturnNew(objTable,indexI,indexJ){
	var dtable = document.getElementById(objTable);
	var ValueA = 0;
	var ValueB = 0;
	var ValueC = 0;
	var ValueD = 0;
	var ValueWeight = 0;
	var ValueGrade = 0;

	for(var i = 1;i<dtable.rows.length;i++){
		ValueWeight = new Number(dtable.rows[i].cells[indexI].firstChild.value);	//\u6743\u91CD
		ValueGrade = new Number(dtable.rows[i].cells[indexJ].firstChild.value);		//\u5206\u6570
		
		if(ValueWeight>0 && ValueGrade<=0){
		}else{
			ValueA = ValueA + (ValueWeight*ValueGrade);
			ValueB = ValueB + ValueWeight;
		}
		if(ValueGrade<0){
			ValueC = ValueC + ValueGrade;
		}
	}
	
	if(ValueB>0){
		ValueD = (ValueA/ValueB) + ValueC;
		ValueD = ValueD.toFixed(2);
	}
	
	return ValueD;
}

/***********************************************
\u529F\u80FD\uFF1A\u6839\u636E\u5206\u6570\u8BA1\u7B97\u8BC4\u5B9A\u7B49\u7EA7
***********************************************/
function computeGrade(num){
	num = new Number(num);
	if(num<=120 && num>=110) return "A++";
	else if(num<110 && num>=100) return "A+";
	else if(num<100 && num>=90) return "A";
	else if(num<90 && num>=70) return "B";
	else return "C";
}

/***********************************************
\u529F\u80FD\uFF1A\u663E\u793A\u548C\u6253\u5370\u63A7\u5236
***********************************************/
function printctl(){
	if (document.getElementById("print_DtTable")!=null){     
     	var t=document.getElementById("print_DtTable").childNodes.item(0);
      	for(var j=0;j<t.childNodes(0).childNodes.length;j++){
          	t.childNodes(0).childNodes(j).noWrap="noWrap"
               t.childNodes(0).childNodes(j).align="center"
          }
     
   	 	for(var i=1;i< t.childNodes.length;i++){
       		for(var j=0;j<t.childNodes(i).childNodes.length;j++){     
              		t.childNodes(i).childNodes(j).align="center"
            	}
    		}
	}else{
  		parent.showLabel(2);
  	}
}

/***********************************************
\u529F\u80FD\uFF1A\u4FE1\u606F\u67E5\u770B\u754C\u9762
***********************************************/
function sAlert(flag){
	var tableName,tableDesc,tableField;
	if(flag==1){
		tableName = "CF_T_P9503_A__";
		tableDesc = "\u4E2A\u4EBA\u884C\u52A8\u8BA1\u5212";
		tableField = "CF_T_P9503_A__ZZHRPDPACT21_All";
	}else if(flag==2){
		tableName = "CF_T_P9503_O__";
		tableDesc = "\u5DE5\u5212";
		tableField = "CF_T_P9503_O__ZZHRPDPACT21_All";
	}else if(flag==3){
		tableName = "CF_T_P9503_Q__";
		tableDesc = "\u5E74\u5EA6\u5173\u952E\u6280\u80FD\u63D0\u5347\u8BA1\u5212";
		tableField = "CF_T_P9503_Q__ZZHRPDPACT21_All";
	}else if(flag==4){
		tableName = "CF_T_P9503_A__";
		tableDesc = "\u90E8\u95E8\u5DE5\u4F5C\u4E3B\u8BA1\u5212";
		tableField = "CF_T_P9503_A__ZZHRPDPACT11_All";
	}else{
		tableName = "CF_T_P9503_E__";
		tableDesc = "\u5E74\u5EA6\u57F9\u8BAD\u8BA1\u5212";
		tableField = "CF_T_P9503_E__ZZHRPDPACT21_All";
	}
	
	var msgw,msgh,bordercolor; 
	msgw=1000;			//\u63D0\u793A\u7A97\u53E3\u7684\u5BBD\u5EA6  
	msgh=300;				//\u63D0\u793A\u7A97\u53E3\u7684\u9AD8\u5EA6  
	bordercolor="#c51100";	//\u63D0\u793A\u7A97\u53E3\u7684\u8FB9\u6846\u989C\u8272  

 	var sWidth,sHeight;  
	sWidth=document.body.clientWidth; 
	sHeight=document.body.clientHeight;

	//bgObj\u4E3A\u6574\u4E2A\u5C4F\u5E55\u80CC\u666F
 	var bgObj=document.createElement("div");
	bgObj.setAttribute('id','bgDiv');
	bgObj.style.position="absolute";
	bgObj.style.top="0";
	bgObj.style.background="#cccccc";
	bgObj.style.filter="progid:DXImageTransform.Microsoft.Alpha(style=3,opacity=25,finishOpacity=75)";
	bgObj.style.opacity="0.6";
	bgObj.style.left="0";
	bgObj.style.width=sWidth + "px";
	bgObj.style.height=sHeight + "px";
	bgObj.style.zIndex = "10000";
	document.body.appendChild(bgObj);
	
	//\u63D0\u793A\u7A97\u53E3
	var msgObj=document.createElement("div");
	msgObj.setAttribute("id","msgDiv");
	msgObj.setAttribute("align","center");
	msgObj.style.background="white";
	msgObj.style.border="1px solid " + bordercolor;
	msgObj.style.position = "absolute";
	msgObj.style.left = (sWidth-msgw)/2+"px";
	//msgObj.style.top = (sHeight-msgh)/2-window.screenTop+255+"px";
	//msgObj.style.top = (sHeight-msgh)/2+"px";
	msgObj.style.top = "50px";
	msgObj.style.font="12px/1.6em Verdana, Geneva, Arial, Helvetica, sans-serif";
	//msgObj.style.marginLeft = "-200px";
	//msgObj.style.marginTop = -75+document.documentElement.scrollTop+"px";
	msgObj.style.width = msgw + "px";
	msgObj.style.height =msgh + "px";
	msgObj.style.textAlign = "center";
	msgObj.style.lineHeight ="5px";
	msgObj.style.zIndex = "10001";

	document.body.appendChild(msgObj);
	
  try{
  	var txt = "<FONT color=#ff0000 size=2 face=\u5FAE\u8F6F\u96C5\u9ED1>\u56FE\u4F8B\uFF1A\u8BA1\u5212=</FONT>"
	txt = txt + "<FONT size=2 face=\u5FAE\u8F6F\u96C5\u9ED1> <INPUT class=textdocnone style='BACKGROUND: gray' readOnly size=5 value='  ' name=CF_Gray></FONT>"
	txt = txt + "<FONT color=#ff0000 size=2 face=\u5FAE\u8F6F\u96C5\u9ED1>&nbsp; \u8FDB\u884C=</FONT>"
	txt = txt + "<FONT size=2 face=\u5FAE\u8F6F\u96C5\u9ED1> <INPUT class=textdocnone style='BACKGROUND: yellow' readOnly size=5 value='  ' name=CF_Yellow></FONT>"
	txt = txt + "<FONT color=#ff0000 size=2 face=\u5FAE\u8F6F\u96C5\u9ED1> \u5B8C\u6210=</FONT>"
	txt = txt + "<FONT size=2 face=\u5FAE\u8F6F\u96C5\u9ED1> <INPUT class=textdocnone style='BACKGROUND: green' readOnly size=5 value='  ' name=CF_Green></FONT>"
	txt = txt + "<FONT color=#ff0000 size=2 face=\u5FAE\u8F6F\u96C5\u9ED1> \u672A\u5F00\u59CB=</FONT>"
	txt = txt + "<FONT size=2 face=\u5FAE\u8F6F\u96C5\u9ED1> <INPUT class=textdocnone style='BACKGROUND: red' readOnly size=5 value='  ' name=CF_Red></FONT>"
  	txt = txt + "<br>"
	// tHead
  	txt = txt + "<table border=1 width=100%><tr><td rowspan=2 width='2%' align=center>\u5E8F\u53F7</td>";
  	txt = txt + "<td rowspan=2 width='13%' align=center>"+tableDesc+"</td><td colspan=12 align=center>\u6708\u5EA6\u5DE5\u4F5C\u8FDB\u5EA6\u8BA1\u5212</td></tr>";
  	txt = txt + "<tr><td width='2%' align=center>1\u6708</td>";
  	txt = txt + "<td width='2%' align=center>2\u6708</td>";
  	txt = txt + "<td width='2%' align=center>3\u6708</td>";
  	txt = txt + "<td width='2%' align=center>4\u6708</td>";
  	txt = txt + "<td width='2%' align=center>5\u6708</td>";
  	txt = txt + "<td width='2%' align=center>6\u6708</td>";
  	txt = txt + "<td width='2%' align=center>7\u6708</td>";
  	txt = txt + "<td width='2%' align=center>8\u6708</td>";
  	txt = txt + "<td width='2%' align=center>9\u6708</td>";
  	txt = txt + "<td width='2%' align=center>10\u6708</td>";
  	txt = txt + "<td width='2%' align=center>11\u6708</td>";
  	txt = txt + "<td width='2%' align=center>12\u6708</td></tr>";

	var tmpField = eval("document.all."+tableField);
	var applyPro = tmpField.value;
	if(applyPro.indexOf("*&^")!=-1){
		var applyProV = applyPro.split("*&^");
	}
	else{
		var applyProV = applyPro.split("\r\n");
	}
	var tmpV,tmpC,k;
  	//tBody
	for(var i=0;i<applyProV.length;i++){
		txt = txt+ "<tr><td align=center>"+(i+1)+"</td>";
		//txt = txt+ "<td>"+getArrPro(tableName+"ZZHRPDPACT21_All",i)+"</td>";
		//\u589E\u52A0\u5BF9\u4E8E\u5355\u5143\u683C\u5185\u6709\u6362\u884C\u7B26\u7684\u903B\u8F91\u5224\u65AD\uFF0C\u6362\u884C\u7B26\u4E3A#$%
		txt = txt+ "<td>"+getArrPro(tableField,i).replace(/#\$\%/g,"<br>")+"</td>";
		
		for(var j=1;j<13;j++){
			if(j!=11)k=j;else k="1A";
			
			tmpV = getArrPro(tableName+"ZZHRPDPM"+k+"1_All",i);
			tmpC = getColorV(tmpV);
			txt = txt+ "<td bgcolor='"+ tmpC +"'><font color='"+ tmpC + "'>" + tmpV +"</font></td>";
		}
		txt=txt+"</tr>";
	}
	txt = txt + "</table>";
   }catch(e){txt = "Error"};	
   	var cancelBu = addButton("submit","\u8FD4\u56DE");
	var buEl = document.createElement("p");
	var spanEl = document.createElement("span");
	spanEl.innerHTML="&nbsp;&nbsp;";
	buEl.setAttribute("align","left");
	buEl.appendChild(spanEl);
	buEl.appendChild(cancelBu);
	document.getElementById("msgDiv").appendChild(buEl);
   
	var pEl=document.createElement("p");
	pEl.style.margin="1em 0";
	pEl.setAttribute("id","msgTxt");
	pEl.innerHTML=txt;
	document.getElementById("msgDiv").appendChild(pEl);
}

/***********************************************
\u529F\u80FD\uFF1A\u4FE1\u606F\u754C\u9762\u83B7\u53D6\u503C
***********************************************/
function getArrPro(ItemName,i){
	var applyPro = document.getElementById(ItemName).value;
	if(applyPro.indexOf("*&^")!=-1){
		var applyProV = applyPro.split("*&^");
	}
	else{
		var applyProV = applyPro.split("\r\n");
	}
	if(applyProV[i]) return (applyProV[i]=='\u25B2') ? "" : applyProV[i];
	else return "";
}

/***********************************************
\u529F\u80FD\uFF1A\u4FE1\u606F\u67E5\u770B\u754C\u9762\u8FD4\u56DE\u6309\u94AE
***********************************************/
function addButton(buttonType,buttonValue){
	var cancelBu=document.createElement("input");
	cancelBu.setAttribute("type",buttonType); 
	cancelBu.setAttribute("name","button"); 
	cancelBu.setAttribute("value",buttonValue); 
	cancelBu.style.color="#003048";
	cancelBu.style.font="13px Verdana, Geneva, Arial, Helvetica, sans-serif"; 
	cancelBu.style.background="#c4e5fa"; 
	cancelBu.style.height="19px"; 
	cancelBu.style.padding="0px 1px"; 
	cancelBu.style.border="1px #0066CC solid"; 
	cancelBu.style.cursor="hand"; 
	cancelBu.onclick=function(){
		bgObj = document.getElementById("bgDiv");
		buEl = window.event.srcElement.parent;
		msgObj = document.getElementById("msgDiv");
		if(bgObj) document.body.removeChild(bgObj);   
		if(msgObj && buEl) msgObj.removeChild(buEl);   
		if(msgObj) document.body.removeChild(msgObj);   
	}
	return cancelBu;
}
/***********************************************
\u529F\u80FD\uFF1AAPP2001/APP2101\u67E5\u770B\u5B9E\u9645\u884C\u4E3A\u4E8B\u4F8B
***********************************************/
function viewURLInfo(){
	if(serverURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6ESAP\u670D\u52A1\u5668\u5730\u5740,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u5B9E\u9645\u884C\u4E3A\u4E8B\u4F8BURL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	var pernr = document.all.CF_E_P9500__PERNR.value;
	
	if(pernr==""){alert("\u4EBA\u5458\u7F16\u53F7\u80FD\u7A7A\uFF01");return;}
	
	alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
	window.open(serverURL+viewURL+"?pernr="+pernr);
}
/***********************************************
\u529F\u80FD\uFF1Aflag=1 APP05/APP08/APP11/APP19 \u67E5\u5B9E\u9645\u884C\u4E3A\u4E8B\u4F8B
flag=3 APP08/APP11 \u67E5\u770B\u57F9\u8BAD\u7ECF\u5386
***********************************************/
function viewAPPURLInfo(flag){
	var serverURL = document.all.CF_ServerURL.value;
	if(serverURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6ESAP\u670D\u52A1\u5668\u5730\u5740,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	if(flag==3){
		var viewURL = document.all.CF_URL_3.value;
		if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u57F9\u8BAD\u7ECF\u5386URL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	}else{
		var viewURL = document.all.CF_URL_1.value;
		if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u5B9E\u9645\u884C\u4E3A\u4E8B\u4F8BURL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	}
	
	var pernr = document.all.CF_E_P9500__PERNR.value;
	if(pernr==""){alert("\u4EBA\u5458\u7F16\u53F7\u4E0D\u80FD\u4E3A\u7A7A\uFF01");return;}
	
	var StrPERNR = "?pernr="+pernr;
	if(flag==3){
		StrPERNR = "?PERNR="+pernr;
	}
	
	alert("\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
	window.open( serverURL + viewURL + StrPERNR );	
}
/* \u8BBE\u7F6E\u76F8\u5173\u5355\u5143\u683C\u80CC\u666F\u989C\u8272  Added by ningzhx At 2012-12-12
 * index 	\u2014 \u6807\u8BC6\u7B2Cindex\u4E2A\u52A8\u6001\u8868\u683C
 * ibegin	\u2014 \u6807\u8BC6\u8BE5\u8868\u683C\u9700\u8BBE\u7F6E\u989C\u8272\u5F00\u59CB\u5217\u5E8F\u53F7
 * iend	\u2014 \u6807\u8BC6\u8BE5\u8868\u683C\u4E2D\u9700\u8BBE\u7F6E\u989C\u8272\u7684\u7ED3\u675F\u5217\u5E8F\u53F7
**/
function displayColor(index,ibegin,iend){
	var dtable = document.getElementById("newTableID_"+index);
	if(dtable){
		var rows = dtable.rows;
		for(var rowIndex = 1;rows[rowIndex];rowIndex++){
			for(var cellIndex=ibegin;rows[rowIndex].cells[cellIndex] && cellIndex<=iend;cellIndex++){
				var cell = rows[rowIndex].cells[cellIndex];
				var color = getColor(cell);
        // console.log(cell);
				if(cell.children){
					if(cell.children[0]){
            // console.log(cell.children[0]);
						cell.style.backgroundColor = color;  // td bgcolor
						cell.children[0].style.background = color;  //input bgcolor
						//cell.childNodes[0].style.color = color;  //input color
					}
				}
			}
		}
	}
}
/* \u6839\u636E\u5355\u5143\u683C\u4E2Dinput\u5143\u7D20\u7684\u503C\u5185\u5BB9\u8FD4\u56DE\u989C\u8272\u503C  Added By ningzhx At 2012-12-12
 * cell 	\u2014 \u5355\u5143\u683C\u5BF9\u8C61
**/
function getColor(cell){
	var vElem = cell.getElementsByTagName("INPUT");
	if(vElem.length<=0) return;
	var field = vElem[0]; 	
	if(field){
		var fieldValue = field.value;
		var colorValue;
		switch(fieldValue.toUpperCase()){
		case "A":   //done
			colorValue = "green";
			break;
		case "B":   //doing
			colorValue = "yellow";
			break;
		case "C":   //planing
			colorValue = "gray";
			break;
		case "D":   //delay
			colorValue = "red";
			break;
		default :
			colorValue = "";
			break;
		}
		return colorValue;
	}
}
/* \u76F4\u63A5\u6839\u636E\u503C\u8FD4\u56DE\u989C\u8272\u503C  Added By ningzhx At 2012-12-12
 * cellV 	\u2014 \u5355\u5143\u683C\u503C
**/
function getColorV(cellV){
	if(trim(cellV)=="") return "";
	
	switch(cellV.toUpperCase()){
		case "A":   //done
			colorValue = "green";
			break;
		case "B":   //doing
			colorValue = "yellow";
			break;
		case "C":   //planing
			colorValue = "gray";
			break;
		case "D":   //delay
			colorValue = "red";
			break;
		defult :
			colorValue = "";
			break;
	}
	return colorValue;
}

/***********************************************
\u529F\u80FD\uFF1A\u7EE9\u6548\u4FEE\u6539\u5355\u884C\u4FE1\u606F
***********************************************/
function modifyAppInfo(flowFlag){
	var seqnr;
	var infty;
	var serverURL = document.all.CF_ServerURL.value;
	var viewURL = document.all.CF_URL.value;
	var guid = document.all.CF_Guid.value;
	var fieldName = window.event.srcElement.parentElement.parentElement.childNodes[1].childNodes[0].name;
	//alert($(this).children("td:eq(2)").html());
	var sapDetailTableName = fieldName.substring(0,fieldName.indexOf("__"))+"__SEQNR1_All";
	if(document.all[sapDetailTableName]){
		seqnr = document.all[sapDetailTableName].value;
	}
	infty = fieldName.substring(fieldName.indexOf("CF_")+6,fieldName.indexOf("CF_")+10);
	
	if(serverURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6ESAP\u670D\u52A1\u5668\u5730\u5740,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u76F8\u5173\u7684URL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	if(guid==""){alert("GUID\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(seqnr==""){alert("SEQNR\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	if(seqnr.indexOf("*&^")!=-1){
		var r = getEventIndex();
		tmpArr = seqnr.split("*&^");
		seqnr = tmpArr[r-1];
	}
	else if(seqnr.indexOf("\r\n")!=-1){
		var r = getEventIndex();
		tmpArr = seqnr.split("\r\n");
		seqnr = tmpArr[r-1];
	}
	document.all.CF_NeedReGetContent.value="1";
	
	//\u4FDD\u5B58\u7EE9\u6548\u6587\u6863
	saveAppDoc();
	
	var url;
	if(flowFlag==1) url=serverURL+viewURL+"?GUID="+guid+"&INFTY="+infty+"&SEQNR="+seqnr+"&OPERA=MOD1"+"&PAR=SELF";
	else url=serverURL+viewURL+"?GUID="+guid+"&INFTY="+infty+"&SEQNR="+seqnr+"&OPERA=MOD1";
	
	alert("\u5C06\u79BB\u5F00OA\u754C\u9762\uFF0C\u8DF3\u8F6C\u5230PORTAL\u754C\u9762\u3002");
	window.open(url);
}

/***********************************************
\u529F\u80FD\uFF1A\u7EE9\u6548\u6DFB\u52A0\u4FE1\u606F
***********************************************/
function addAppInfo(){
	var serverURL = document.all.CF_ServerURL.value;
	var viewURL = document.all.CF_URL.value;
	var guid = document.all.CF_Guid.value;

	if(serverURL==""){alert("\u7CFB\u7EDF\u672A\u914DSAP\u670D\u52A1\u5668\u5730\u5740,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	if(viewURL==""){alert("\u7CFB\u7EDF\u672A\u914D\u7F6E\u76F8\u5173\u7684URL,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	var infty;
	var fieldName = "";
	var TOBJ = $(window.event.srcElement).parent().parent().next();
	if(TOBJ.find("input").attr("name") == undefined ){
		fieldName = TOBJ.find("textarea").attr("name");
	}else{
		fieldName = TOBJ.find("input").attr("name");
	}
	infty = fieldName.substring(fieldName.indexOf("CF_")+6,fieldName.indexOf("CF_")+10);

	if(guid==""){alert("GUID\u4E0D\u80FD\u4E3A\u7A7A,\u8BF7\u8054\u7CFB\u7CFB\u7EDF\u7BA1\u7406\u5458\uFF01");return;}
	
	document.all.CF_NeedReGetContent.value="1";
	
	//\u4FDD\u5B58\u7EE9\u6548\u6587\u6863
	saveAppDoc();
	
	window.open(serverURL+viewURL+"?GUID="+guid+"&INFTY="+infty+"&OPERA=INS");
}

//\u4FDD\u5B58\u7EE9\u6548\u6587\u6863
function saveAppDoc(){
	var request = new CLASS_XMLHTTP();
	var dbUrl=document.location.pathname;
	path=dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
	var accessUrl=path+"/CAG_HRAPP_SaveDoc?OpenAgent&docid="+escape(S_DocId);
	request.open("POST",accessUrl,false);
	request.send(null);
}

//\u83B7\u53D6\u9F20\u6807\u4E8B\u4EF6\u7684\u5F53\u524D\u8868\u683C\u884C\uFF080,1,2,3\uFF09
function getEventIndex(){
	var oa=window.event.srcElement;
	var otr=oa.parentElement;
	var i=0;
	while(otr.tagName!="TR"){
		otr=otr.parentElement;
		i=otr.rowIndex;
	}
	return i;
}

//\u83B7\u53D6\u5F53\u524D\u8868\u683CID\u540E\u9762\u7684\u5E8F\u53F7
function getTableIDNo(){
	getdtTable(window.event.srcElement);
	var flag =dtable.id;
	flag = flag.substring(flag.length-1,flag.length);
	return flag;
}

//\u83B7\u53D6\u5BA1\u6279\u6D41\u7A0B\u6807\u7B7E\u9875\u4E2D\u7684\u5904\u7406\u65B9\u5F0F Add by hyq 20130607
function getApprovalDealResult(){
	var flowForm = parent.ifFlow.document.forms[0];
	var tdResultObj = parent.ifFlow.document.all.tdResult;
	
	if(tdResultObj != null){
		if (tdResultObj.parentNode.style.display.toLowerCase() != "none") {
			if(flowForm.F_Result){
				for (var k = 0; k < flowForm.F_Result.length; k++) {
					if (flowForm.F_Result[k].checked) {
						return flowForm.F_Result[k].value;
					}
				}
			}
		}
	}
	return "";
}

//\u83B7\u53D6\u5BA1\u6279\u6D41\u7A0B\u6807\u7B7E\u9875\u4E2D\u7684\u7279\u6743\u5904\u65B9\u5F0F Add by hyq 20130608
function getApprovalDealSaResult(){
	var flowForm = parent.ifFlow.document.forms[0];
	var tdSaObj = parent.ifFlow.document.all.tdSa;
	
	if(tdSaObj != null){
		if (tdSaObj.parentNode.style.display.toLowerCase() != "none") {
			if(flowForm.F_SaResult){
				for (var k = 0; k < flowForm.F_SaResult.length; k++) {
					if (flowForm.F_SaResult[k].checked) {
						return flowForm.F_SaResult[k].value;
					}
				}
			}
		}
	}
	return "";
}

//\u9A73\u56DE\u5230\u8D77\u8349\u4EBA\u73AF\u8282 Add by hyq 20130607 \u76EE\u524D\u8C03\u6574\u4E3A\u6240\u6709HR\u6D41\u7A0B\u90FD\u53EF\u9A73\u56DE\u5230\u8D77\u8349\u4EBA
function RejectToDrafter(){
	return true;
	
	var flowForm=parent.ifFlow.document.forms[0];
	
	if(flowForm.F_Result){
		for (var k = 0; k < flowForm.F_Result.length; k++) {
			if (flowForm.F_Result[k].checked && flowForm.F_Result[k].value=='\u9A73\u56DE') {
				var index = flowForm.selNode.options[flowForm.selNode.selectedIndex].value;
				if(index=='0'){
					alert("\u8BE5\u6D41\u7A0B\u4E0D\u80FD\u9A73\u56DE\u81F3\u8D77\u8349\u4EBA\uFF0C\u8BF7\u7528\u5E9F\u5F03\uFF01")
 					return false;
				}
			}
		}
	}
	return true;
}

//\u63A7\u5236\u57F9\u8BAD\u4E0E\u62DB\u8058\u7684\u201C\u4FEE\u6539SAP\u6570\u636E\u201D\u4E0E\u201C\u91CD\u65B0\u83B7\u53D6SAP\u6570\u636E\u201D\u6309\u94AE\u7684\u9690\u85CF
function setTEMRCHidden(maindocStatus){
	if(maindocStatus=="\u65B0\u6587\u6863" || maindocStatus=="\u901A\u8FC7"){
		if(document.all.td_button) document.all.td_button.style.display = "none";
	}
	if(maindocStatus=="\u9A73\u56DE"){
		if(parent.MainDocIsBeingEdited){
			if(parent.MainDocIsBeingEdited!="1"){
				if(document.all.td_button) document.all.td_button.style.display = "none";
			}
		}
	}
}
function TEMRCRejectUpdateSAPButtonControl(maindocStatus){
	//\u57F9\u8BAD/\u62DB\u8058 \u9A73\u56DE\u6216\u64A4\u56DE\u4E0D\u505A\u6309\u94AE\u9690\u85CF
	if(maindocStatus=="\u9A73\u56DE" || maindocStatus=="\u64A4\u56DE"){
		if(document.all.CF_NeedReGetContent.value=="1"){
			if(document.all.CF_IsDraftSubmit){
				if(document.all.CF_IsDraftSubmit.value=="1"){
					alert("\u8BF7\u5148\u5728\u5BA1\u6279\u5185\u5BB9\u754C\u9762\u70B9\u51FB\"\u91CD\u65B0\u83B7\u53D6SAP\u6570\u636E\"\u6309\u94AE\u518D\u63D0\u4EA4\u6D41\u7A0B\uFF01");
					document.all.CF_IsDraftSubmit.value = "";
					return false;
				}
			}
		}
	}
	if(document.all.CF_IsDraftSubmit){
		document.all.CF_IsDraftSubmit.value = "";
	}
	return true;
}
/*\u610F\u89C1\u5206\u6570\u7B49\u7EA7onBlur\u51FD\u6570 \u76EE\u524D0903/1203\u6D41\u7A0B\u4F7F\u7528
flag="FS"\u8868\u793A\u5206\u6570\u8F93\u5165\u6846\uFF0C\u5219\u9700\u8981\u8BA1\u7B97\u7B49\u7EA7
\u5B57\u6BB5\u683C\u5F0F\uFF1ACF_TLead8YJ
*/
function YJFSDJonBlurFun(thisobj,flag){
	var Str_No = thisobj.name.substring(8,9);
	var Str_Para = "CF_TLead"+Str_No+"YJ^:CF_TLead"+Str_No+"FS^ \u5206\u6570\uFF1A:CF_TLead"+Str_No+"DJ^ \u7B49\u7EA7\uFF1A";
	if(flag=="FS"){
		confirmScore(thisobj);
		document.all[ "CF_TLead"+Str_No+"DJ" ].value = computeGrade(thisobj.value);
	}
	RIToFlowDealOpinion(thisobj,Str_Para);
}
//\u628A\u76F8\u5173\u610F\u89C1\u4FE1\u606F\u5199\u5165\u5BA1\u6279\u6D41\u7A0B\u9875\u9762\u4E2D\u7684\u5904\u7406\u610F\u89C1\u4E2D\uFF0C\u53C2\u6570StrPara\u683C\u5F0F\uFF1A\u5B57\u6BB5\u540D\u79F0^\u663E\u793A\u540D\u79F0\uFF0C\u591A\u503C\u7528\u5192\u53F7:\u5206\u5272
function RIToFlowDealOpinion(thisobj,StrPara){
	if(thisobj && thisobj.readOnly){return;}
	var flowForm = parent.ifFlow;
	if(!flowForm) return;
	var opinion = flowForm.document.all.F_Opinion;
	if(!opinion) return;
	
	var StrOpinionValue = "";
	var SParaArr;
	var SParaObj;

	var ParaArr = StrPara.split(":");
	for(var r=0;r<ParaArr.length;r++){
		SParaArr = ParaArr[r].split("^");
		
		SParaObj = document.all[ SParaArr[0] ];
		
		if(SParaObj){
			if(document.all[ SParaArr[0] ].value!=""){
				StrOpinionValue = StrOpinionValue + SParaArr[1] + document.all[ SParaArr[0] ].value;
			}
		}
	}
	if(StrOpinionValue!=""){
		opinion.value = StrOpinionValue;
	}
}
//\u628A\u201C\u5BA1\u6279\u5185\u5BB9\u201D\u4E2D\u586B\u5199\u7684\u5185\u5BB9\u5E26\u5165\u5230\u201C\u5BA1\u6279\u6D41\u7A0B\u201D\u4E2D\u7684\u201C\u5904\u7406\u610F\u89C1\u201D\u6846\u4E2D \u5B50\u8868\u5355Onload\u8C03\u7528
function RIToFlowDealOpinionOnLoad(thisobj,StrPara){
	var tdSaObj = parent.ifFlow.document.all.tdSa;
	if(tdSaObj != null){
		if (tdSaObj.parentNode.style.display.toLowerCase() != "none") {
			//\u7279\u6743\u5904\u7406\u8868\u683C\u663E\u793A\u8868\u793A\u7279\u6743\u5904\u7406\u5219\u4E0D\u64CD\u4F5C
		}else{
			RIToFlowDealOpinion(thisobj,StrPara);
		}
	}else{
		RIToFlowDealOpinion(thisobj,StrPara);
	}
}
//\u53D6\u6B63\u6587\u7684\u6D41\u6C34\u53F7
function GetSerialNoToDoc(){
	if(maindocStatus=="\u65B0\u6587\u6863" || maindocStatus=="\u8349\u7A3F"){
		var SerialPrefix = parent.document.all.F_SerialPrefix;
		var SerialNo = parent.document.all.F_SerialNo;
		if(SerialPrefix && SerialNo){
			var request = new CLASS_XMLHTTP();
			var dbUrl = document.location.pathname;
			path = dbUrl.substring(0,dbUrl.indexOf(".nsf")+4);
	
			var accessUrl = path+"/CAG_HRWord_GetSerialNoToDoc?OpenAgent&serialprefix="+escape(SerialPrefix.value)+"&serialno="+escape(SerialNo.value);
			accessUrl = accessUrl +"&maindocid="+escape(MainDocId);
	
			request.open("POST",accessUrl,false);
			request.send(null);
	
			var responseText=request.responseText;
   			var responseArr = responseText.split("@");
   			var statusNo = responseArr[1];
   			//\u628A\u914D\u7F6E\u4E2D\u7684\u6D41\u6C34\u53F7\u8D4B\u503C\u5230\u5F53\u524D\u9875\u9762\u4E2D
   			if(statusNo=="U"){
				SerialNo.value = responseArr[2];
			}
		}
	}
}
/*\u529F\u80FD\uFF1A\u9690\u85CF\u5BA1\u6279\u6D41\u7A0B\u9875\u9762HR\u4E0D\u4F7F\u7528\u7684\u6309\u94AE \u53C2\u6570\u4E3A\u7A7A\u5219\u8868\u793A\u9690\u85CF\u5E9F\u5F03 \u7B7E\u540D\u6309\u94AE \u5EF6\u65F61\u79D2\u8BA9\u5BA1\u6279\u6D41\u7A0B\u9875\u9762\u52A0\u8F7D*/
function HiddenControlFLowPageButton( StrButtonIDList ){
	setTimeout("HiddenControlFLowPageButtonRun('"+StrButtonIDList+"')",1000);
}
function HiddenControlFLowPageButtonRun( StrButtonIDList ){
	if(maindocStatus!="\u5F85\u5BA1"){return;}
	if(StrButtonIDList==""){StrButtonIDList="bu_ShowAbandon;optCachet";}
	
	var ButtonID_Arr = new Array();
	ButtonID_Arr = StrButtonIDList.split(";");
	
	if(parent.ifFlow){
		for (i=0;i<ButtonID_Arr.length ;i++ ){
			if( ButtonID_Arr[i]!="" ){
				var ButtonObj = parent.ifFlow.document.all[ ButtonID_Arr[i] ];
				if(ButtonObj != null){
					ButtonObj.style.display = "none";
				}
			}
		}
	}
}

//\u76D1\u542C\u57DF\u7684\u5C5E\u6027\u66F4\u6539\u5E76\u66F4\u6539\u5BA1\u6279\u8BB0\u5F55 2014-08-21 modified By Qicb
function onChangeValue(strFieldAuto,strField){
	//\u6D41\u7A0B\u975E\u5F85\u5BA1\u72B6\u6001\u4E0D\u505A\u57DF\u7684\u76D1\u542C\u5904\u7406
	if(maindocStatus!="\u5F85\u5BA1"){return;}
	var elem1 = eval("document.all."+strFieldAuto+""); 
	var elem2 = eval("document.all."+strField+""); 
	if(!elem1 && !elem2){return;}
	if("\v"=="v"){	
		elem1.onpropertychange = changeVal; 
	}else{
		elem1.addEventListener("input",changeVal,false); 
	}
	function changeVal(){ 
		if(elem1 && elem2){
			if(elem2.value=="" || elem2.value=="0"){
				if(elem1.value!="" && !isNaN(elem1.value)){
					elem2.value = elem1.value;
				}
			}
			confirmScore(elem2);
			document.all.CF_LeadDJ.value = computeGrade(elem2.value);
			RIToFlowDealOpinion(elem2,"CF_LeadYJ^\u8BC4\u4EF7\u610F\u89C1\uFF1A:CF_LeadFS^ \u5206\u6570\uFF1A:CF_LeadDJ^ \u7B49\u7EA7\uFF1A");
		}; 
	}
}

//\u8D77\u8349\u73AF\u8282\u9A73\u56DE\u73AF\u8282\u624D\u663E\u793A "\u53D6\u6D88\u6D41\u7A0B"\u6309\u94AE
function CancelFLowButtonControl(docStatus){
	var obj = document.all.bu_Cancel_Ab;
	if(!obj) return;
	var otr = obj.parentElement;
	while(otr.tagName!="TR"){
		otr = otr.parentElement;
	}
	if(";\u65B0\u6587\u6863;\u8349\u7A3F;\u9A73\u56DE;\u64A4\u56DE;".indexOf( ";" + docStatus + ";")<0){
		obj.style.display = "none";
		otr.style.display = "none";
	}else{
		if(parent.MainDocIsBeingEdited && parent.MainDocIsBeingEdited!="1"){
			obj.style.display = "none";
			otr.style.display = "none";
		}
	}
}


