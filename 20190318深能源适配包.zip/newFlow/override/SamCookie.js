var SamCookie = {};
/**
 * cookie设计是为了解决Http协议无状态性，cookie允许浏览器在有限时间、大小内存储数据，浏览器每次请求时都会把cookie数据包含到请求头部上传给服务器。
 * cookie的存储理论大小：每个domain/path（即cookie文件）只能有20个（后期扩充到50个）cookie对象，整个cookie文件理论上不能超过4k（各种浏览器、不同版本实现皆有差异，主流都是在几K之间）。
 * 因而，cookie不适合做浏览器本地存储。
 * cookie规范（Netscape 草案、RFC 2109、RFC 2965）中限制了一部分字符。简便起见可使用escape与unescape来编码与解码cookie的value来以规避。
 * 但是使用escape编码，导致长度损失近5倍。因而可以调用SamCookie.addCookieNoCode函数，采用不编码全部数据，只编码被限制的字符来节省数据大小。
 */
SamCookie.getCookieFN = function(name,nocode) {
	var strCookie = document.cookie;
	var arrCookie = strCookie.split("; ");
	for (var i = 0; i < arrCookie.length; i++) {
		var arr = arrCookie[i].split("=");
		if (arr[0] == name){
			if(arr[1]==undefined){
				return "";
			}
			if(nocode==true){
				return SamCookie.codeLimitChar(arr[1],false);
			}
			return unescape(arr[1]);
		}
	}
	return "";
}
SamCookie.getCookie = function(name) {
	return SamCookie.getCookieFN(name);
}
SamCookie.getCookieNoCode = function(name) {
	return unescape(decodeURI(SamCookie.getCookieFN(name,true)));
}
SamCookie.addCookieFN = function(name,value,expires,path,domain,nocode) {
	var str=name+"=";
	if(nocode==true){
		str = str + SamCookie.codeLimitChar(value,true);
	}else{
		str = str + escape(value);
	}
 	if(expires!=null && expires!=""){
  		var date=new Date();
  		date.setTime(date.getTime()+expires*60*1000); //expires单位分钟
  		str+=";expires="+date.toGMTString();
 	}
 	if(path!=null && path!=""){
  		str+=";path="+path;//指定可访问cookie的目录
 	}
 	if(domain!=null && domain!=""){
  		str+=";domain="+domain;//指定可访问cookie的域
 	}
 	document.cookie= encodeURI(str);
}
SamCookie.addCookie = function(name,value,expires,path,domain) {
	SamCookie.addCookieFN(name,value,expires,path,domain);
}
SamCookie.addCookieNoCode = function(name,value,expires,path,domain){
	SamCookie.addCookieFN(name,value,expires,path,domain,true);
}
SamCookie.deleteCookie = function(name,value,path,domain){
	SamCookie.addCookie(name,value,-3000,path,domain);
} 
SamCookie.deleteAll = function(path,domain){
	var strCookie = document.cookie;
	var arrCookie = strCookie.split("; ");
	var str = "";
	var date=new Date(0);
	for (var i = 0; i < arrCookie.length; i++) {
		str = arrCookie[i];
		str+=";expires="+date.toGMTString();
		if(path!=null && path!=""){
			str+=";path="+path;//指定可访问cookie的目录
		}
		if(domain!=null && domain!=""){
			str+=";domain="+domain;//指定可访问cookie的域
		}
		document.cookie=str;
	}
}
// flag为true则编码限制字符串，否则解码。
SamCookie.codeLimitChar=function(v,flag){
	var lmtC = ['\t', ' ', '\"', '(', ')', ',', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '{', '}'];
	var reArr1 = [/\t/g, / /g, /\"/g, /\(/g, /\)/g, /,/g, /:/g, /;/g, /</g, /=/g, />/g, /\?/g, /@/g, /\[/g, /\\/g, /\]/g, /\{/g, /\}/g];
	var reArr2 = [];
	var codeC = [];
	var rtnS = v;
	for(var i =0;i<lmtC.length;i++){
		codeC[i] = escape(lmtC[i]);
		reArr2[i] = new RegExp(codeC[i],"g");
	}
	if(flag){
		for(var i =0;i<lmtC.length;i++){
			rtnS = rtnS.replace(reArr1[i], codeC[i]);
		}
	}else {
		for(var i =0;i<lmtC.length;i++){
			rtnS = rtnS.replace(reArr2[i], lmtC[i]);
		}
	}
	return rtnS;
}