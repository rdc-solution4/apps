var AddressXML = new ActiveXObject("MSXML.DOMDocument");
AddressXML.async = false;
var focusObj = 1;
var CommonPostList = new Array;
var OptAList = new Array;
var OptNList = new Array;
var SelAList = new Array;
var SelNList = new Array;
var AInfoList = new Array;
var DInfoList = new Array;
var PersonAList = null;
var PersonNList = null;
var Loaded = false;
var GetDepInfoDb = getNotesIniValue("GetDepInfoDb");
var GetPostInfoDb = getNotesIniValue("GetPostInfoDb");
var GetGroupInfoDb = getNotesIniValue("GetGroupInfoDb");
var GetPeopleInfoDb = getNotesIniValue("GetPeopleInfoDb");
var isUseLDAP = (GetPeopleInfoDb.toLowerCase() != "/names.nsf/");
var dialogArgumentsFC ;
try{
	dialogArgumentsFC  = top.dialogArguments;
}catch(e){
	dialogArgumentsFC = getCookie("addressPar").split("^");
}
if(dialogArgumentsFC==undefined)
	dialogArgumentsFC = getCookie("addressPar").split("^");

function AddressGetInfoDb(dbInfo) {
    switch (dbInfo) {
    case "0":
    case "U":
        return GetDepInfoDb;
    case "1":
    case "P":
        return GetPostInfoDb;
    case "2":
    case "G":
        return GetGroupInfoDb;
    case "4":
    case "M":
        return GetPeopleInfoDb;
    default:
        return "/names.nsf/";
    }
}
function AddressOnLoad(isMulSelect) {
    AddressXML.async = false;
    AddressType = new Array;
    for (var i = 0; i < dialogArgumentsFC[0].length; i++) {
        switch (dialogArgumentsFC[0].substring(i, i + 1)) {
        case "U":
            AddressType[AddressType.length] = "0";
            break;
        case "P":
            AddressType[AddressType.length] = "1";
            break;
        case "G":
            AddressType[AddressType.length] = "2";
            break;
        case "M":
            AddressType[AddressType.length] = "4";
            break;
        case "C":
            AddressXML.load(GetPostInfoDb + "LKS_SearchAllPostDisName?ReadViewEntries&count=9999999&PreFormat&CollapseView");
            var nodes = AddressXML.selectNodes("/viewentries/viewentry");
            if (nodes.length > 0) for (var j = 0; j < nodes.length; j++) CommonPostList[CommonPostList.length] = GetChildNodeText(nodes[j], "F_DisName");
        }
    }
}
function AddressListUnit(viewName) {
    OptAList = new Array;
    OptNList = new Array;
    for (var i = 0; i < AddressType.length; i++) {
        AddressLoadXML(AddressGetInfoDb(AddressType[i]) + "LKS_AddressByParent?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + AddressType[i] + encodeURI(viewName), AddressType[i] == "0" && !isUseLDAP);
    }
    AddressRefreshOption();
}

function AddressListPersonalGroup(viewName, isLeafNode) {
    OptAList = new Array;
    OptNList = new Array;
    if (isLeafNode) var strUrl = "../lks_profile.nsf/AG_AddressGetGroupMember?OpenAgent&Group=" + encodeURI(viewName);
    else var strUrl = "../lks_profile.nsf/VD_AddressCommonGroup?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + encodeURI(viewName);

AddressLoadXML(strUrl);
    AddressRefreshOption();
}

function AddressListGroup(viewName, isLeafNode) {
    OptAList = new Array;
    OptNList = new Array;
    if (isLeafNode) var strUrl = "../lks_sysconfig.nsf/AG_AddressGetGroupMember?OpenAgent&Group=" + encodeURI(viewName);
    else var strUrl = GetGroupInfoDb + "LKS_AddressCommonGroup?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + encodeURI(viewName);
    AddressLoadXML(strUrl);
    AddressRefreshOption();
}
function AddressSearch(viewName, canSearchUnit, canSearchPost, canSearchPeople) {
    if (canSearchUnit == null) canSearchUnit = true;
    if (canSearchPost == null) canSearchPost = true;
    if (canSearchPeople == null) canSearchPeople = true;
    var strUrl = null;
    OptAList = new Array;
    OptNList = new Array;
    for (var i = 0; i < AddressType.length; i++) {
        if ((AddressType[i] == "0" || AddressType[i] == "U") & !canSearchUnit) continue;
        if ((AddressType[i] == "1" || AddressType[i] == "P") & !canSearchPost) continue;
        if ((AddressType[i] == "4" || AddressType[i] == "M") & !canSearchPeople) continue;
        AddressLoadXML(AddressGetInfoDb(AddressType[i]) + "LKS_AddressSearch?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + AddressType[i] + encodeURI(viewName), AddressType[i] == "0" && !isUseLDAP);
    }
    AddressRefreshOption();
}
function AddressLoadXML(url, isSame) {
    AddressXML.load(url);
    var nodes = AddressXML.selectNodes("/viewentries/viewentry");
    if (nodes.length > 0) {
        for (var j = 0; j < nodes.length; j++) {
            OptAList[OptAList.length] = GetChildNodeText(nodes[j], "ad");
            OptNList[OptNList.length] = isSame ? OptAList[OptNList.length] : GetChildNodeText(nodes[j], "name");
        }
    }
}
function AddressLoadMore(userND, isOnLoad) {
    if (userND == "") var info = "";
    else {
        AddressXML.load("../lks_sysconfig.nsf/AG_GetMoreInfo?OpenAgent&nd=" + encodeURI(userND));
        var info = AddressXML.selectNodes("/ReturnMsg")[0].text;
    }
    for (var i = 0; i < AInfoList.length; i++) if (AInfoList[i] == userND) DInfoList[i] = info;
    if (isOnLoad) SelectedInfo.innerHTML = (info == "" || SelNList[0] == "") ? "": SelNList[0] + "&nbsp;→&nbsp;" + info;
    else AddressRefreshInfo();
}
function AddressRefreshInfo() {
    if (GetCookie("LKS_UA_IsShowMoreInfo") != "1") return "";
    if (focusObj == 1) {
        var i = document.all.F_OptName.selectedIndex;
        var infoA = OptAList;
        var infoN = OptNList;
    } else {
        var i = document.all.F_SelectedName.selectedIndex;
        var infoA = SelAList;
        var infoN = SelNList;
    }
    var info = "";
    if (i > -1) {
        for (var j = 0; j < AInfoList.length; j++) if (AInfoList[j] == infoA[i]) break;
        if (j == AInfoList.length) {
            AInfoList[j] = infoA[i];
            if (infoA[i].substring(0, 1) == "%" && infoA[i].substring(infoA[i].length - 1) == "%") {
                info = infoA[i].substring(1, infoA[i].length - 1);
                if (info.indexOf("%") > -1) DInfoList[j] = "通用岗位-纵向单位岗位";
                else if (info.indexOf("领导#") > -1) DInfoList[j] = "通用岗位-直线领导";
                else if (info.indexOf("$") > -1) DInfoList[j] = "通用岗位-横向单位岗位";
                else DInfoList[j] = "通用岗位-申请人相关";
            } else {
                DInfoList[j] = "Loading...";
                setTimeout("AddressLoadMore(\"" + infoA[i] + "\", false)", 100);
            }
        }
        info = DInfoList[j] == "-1" ? "": infoN[i] + "&nbsp;→&nbsp;" + DInfoList[j];
    }
    MoreInfo.innerHTML = info;
}
function AddressRefreshOption() {
    with(document.forms[0]) {
        var i;
        for (i = 0; i < OptNList.length; i++) F_OptName.options[i] = new Option(OptNList[i]);
        for (; i < F_OptName.options.length;) F_OptName.options[i] = null;
    }
    MoreInfo.innerHTML = "";
}
function GetChildNodeText(XmlNode, ChildNodeName) {
    var Node = null,
    AttrNode;
    Node = XmlNode.firstChild;
    while (Node != null) {
        AttrNode = Node.getAttributeNode ? Node.getAttributeNode("name") : '';
        if (AttrNode != null && AttrNode.nodeValue == ChildNodeName) return Node.text;
        Node = Node.nextSibling;
    }
    return "";
}
function AddressListCommonPost(title, info) {
    OptAList = new Array;
    OptNList = new Array;
    var n = info.substring(3);
    info = info.substring(0, 3);
    switch (info) {
    case "CPU":
        OptAList[0] = "%申请人%";
        OptNList[0] = "<申请人>";
        OptAList[1] = "%申请人#0%";
        OptNList[1] = "<申请人的领导>";
        break;
    case "CPL":
        var n = parseInt(n);
        OptAList[0] = "%领导#0%";
        OptNList[0] = "<直线领导>";
        for (var i = 1; i < n; i++) {
            OptAList[i] = "%领导#" + i + "%";
            OptNList[i] = "<" + i + "级直线领导>";
        }
        for (var i = 1; i <= n; i++) {
            OptAList[i + n - 1] = "%领导#-" + i + "%";
            OptNList[i + n - 1] = "<" + i + "级领导>";
        }
        break;
    case "CPV":
        for (var i = 0; i < CommonPostList.length; i++) {
            OptAList[i] = "%" + CommonPostList[i] + "%" + n + "%";
            OptNList[i] = "<" + title + "-" + CommonPostList[i] + ">";
        }
        break;
    case "CPH":
        var n = parseInt(n);
        for (var i = 0; i < CommonPostList.length; i++) {
            OptAList[i] = "%" + CommonPostList[i] + "$" + n + "%";
            OptNList[i] = "<" + title + "下的" + CommonPostList[i] + ">";
        }
    }
    AddressRefreshOption();
}
function nameFormat(nameList, rtnType) {
    if (nameList[0]) {
        var rtnList = nameList;
    } else {
        var rtnList = new Array;
        rtnList[0] = nameList;
    }
    var n, tmpArr;
    for (var i = 0; i < rtnList.length; i++) {
        if (rtnList[i] == "") continue;
        tmpArr = rtnList[i].split("/");
        switch (rtnType) {
        case "CN":
            rtnList[i] = (n = tmpArr[0].indexOf("=")) > -1 ? tmpArr[0].substring(n + 1) : tmpArr[0];
            break;
        case "A":
            for (var j = 0; j < tmpArr.length; j++) tmpArr[j] = (n = tmpArr[j].indexOf("=")) > -1 ? tmpArr[j].substring(n + 1) : tmpArr[j];
            rtnList[i] = tmpArr.join("/");
            break;
        case "C":
            if (tmpArr.length > 1) {
                tmpArr[0] = tmpArr[0].indexOf("=") > -1 ? tmpArr[0] : "CN=" + tmpArr[0];
                for (var j = 1; j < tmpArr.length - 1; j++) tmpArr[j] = tmpArr[j].indexOf("=") > -1 ? tmpArr[j] : "OU=" + tmpArr[j];
                tmpArr[j] = tmpArr[j].indexOf("=") > -1 ? tmpArr[j] : "O=" + tmpArr[j];
            }
            rtnList[i] = tmpArr.join("/");
        }
    }
    return nameList[0] ? rtnList: rtnList[0];
}
function AddressListPersonalAddress(listType, userND) {
    if (PersonAList == null) {
        var queryUrl = "../lks_profile.nsf/VD_PersonalAddress?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + encodeURI(userND);
        AddressXML.load(queryUrl);
        var nodes = AddressXML.selectNodes("/viewentries/viewentry");
        if (nodes.length > 0) {
            PersonNList = GetChildNodeText(nodes[0], "name").split(";");
            PersonAList = GetChildNodeText(nodes[0], "ad").split(";");
        } else {
            PersonNList = "";
            PersonAList = "";
        }
    }
    OptAList = new Array;
    OptNList = new Array;
    var tmpStr;
    for (var i = 0; i < PersonNList.length; i++) if (PersonNList[i].length > 1) if (listType.indexOf(PersonNList[i].substring(0, 1)) > -1) {
        OptAList[OptAList.length] = PersonAList[i].substring(1);
        OptNList[OptNList.length] = PersonNList[i].substring(1);
    }
    AddressRefreshOption();
}
function AddressAddToMyAddress() {
    if (document.all.F_SelectedName) var info = SelAList.join(";");
    else var info = (document.all.F_OptName.selectedIndex == -1) ? "": OptAList[document.all.F_OptName.selectedIndex];
    if (info == "") {
        alert("您尚未选择要添加列表！");
        return;
    }
    var tagObj = addressFrame.document.all;
    if (tagObj.F_ReturnStatus) {
        tagObj.F_AddList.value = info;
        tagObj.F_ReturnStatus.value = "1";
        tagObj.btnSaveJS.click();
        PersonNList = null;
        PersonAList = null;
    } else {
        addressFrame.location.href = "../lks_profile.nsf/ag_openpersonaladdress?openagent&editdocument&onload=parent.AddressAddToMyAddress()";
    }
}