function C_VerificationNull(str) {
    if (eval("document.all." + str + ".value") !== "") {
        return true;
    } 
    else {
        alert(eval("document.all." + str + ".title") + "域,值不能为空");
        return false;
    }
    return true;
}
function C_Comparison(str1, str2) {
    if (eval("document.all." + str1 + ".value") > eval("document.all." + str2 + ".value")) {
        alert(eval("document.all." + str + ".title") + "域的值不能大于" + eval("document.all." + str + ".title") + "域的值");
        return false;
    }
    return true;
}
function C_VerificationNo(str) {
    if (!isFloat(eval("document.all." + str + ".value"), 0)) {
        alert(eval("document.all." + str + ".title") + "域值必须是数字");
        return false;
    }
    return true;
}
function C_VerificationEmail(str) {
    if (eval("document.all." + str + ".value").indexOf("@", 0) < 0) {
        alert(eval("document.all." + str + ".title") + "域值不是合法的Email,合法的Email必须包含@");
        return false;
    }
    return true;
}
function C_VerificationLength(str, len) {
    if (eval("document.all." + str + ".value").length > len) {
        alert(eval("document.all." + str + ".title") + "域值的长度不能超过" + len);
        return false;
    }
    return true;
}
function C_Verificationx(str, len) {
    if (eval("document.all." + str + ".value").length < len) {
        alert(eval("document.all." + str + ".title") + "域值的长度不能小于" + len);
        return false;
    }
    return true;
}
function C_Illegal(str, charset) {
    var i;
    for (i = 0; i < charset.length; i++) {
        if (eval("document.all." + str + ".value").indexOf(charset.charAt(i)) >= 0) {
            alert(eval("document.all." + str + ".title") + "域不能含有" + charset + "等非法字符")
            return false;
        }
    }
    return true;
}
function C_Adder(str1, str2, str3) {
    eval("document.all." + str3 + ".value=parseInt(str1)+parseInt(str2)");
}
function C_AdderText(str1, str2, str3) {
    var a = parseInt(eval("document.all." + str1 + ".value"));
    var b = parseInt(eval("document.all." + str2 + ".value"));
    eval("document.all." + str3 + ".value=a+b");
}
function C_Multiplication(str1, str2, str3) {
    eval("document.all." + str3 + ".value=parseInt(str1)*parseInt(str2)");
}
function C_MultiplicationText(str1, str2, str3) {
    var a = parseInt(eval("document.all." + str1 + ".value"));
    var b = parseInt(eval("document.all." + str2 + ".value"));
    eval("document.all." + str3 + ".value=a*b");
}
function C_Subtraction(str1, str2, str3) {
    eval("document.all." + str3 + ".value=parseInt(str1)-parseInt(str2)");
}
function C_SubtractionText(str1, str2, str3) {
    var a = parseInt(eval("document.all." + str1 + ".value"));
    var b = parseInt(eval("document.all." + str2 + ".value"));
    eval("document.all." + str3 + ".value=a-b");
}
function C_Divider(str1, str2, str3) {
    eval("document.all." + str3 + ".value=parseInt(str1)/parseInt(str2)");
}
function C_DividerText(str1, str2, str3) {
    var a = parseInt(eval("document.all." + str1 + ".value"));
    var b = parseInt(eval("document.all." + str2 + ".value"));
    eval("document.all." + str3 + ".value=a/b");
}
function C_ComputeDayNum(str1, str2, str3) {
    var StartTime = trim(eval("document.all." + str1 + ".value"));
    StartTime = StartTime.substring(StartTime.indexOf("-") + 1) + "-" + StartTime.substring(0, StartTime.indexOf("-"));
    var EndTime = trim(eval("document.all." + str2 + ".value"));
    EndTime = EndTime.substring(EndTime.indexOf("-") + 1) + "-" + EndTime.substring(0, EndTime.indexOf("-"));
    var ST = new Date(StartTime);
    var ET = new Date(EndTime);
    var theNum;
    if (eval("document.all." + str2 + ".value") == "" && eval("document.all." + str1 + ".value") == "") {
        return;
    }
    if (eval("document.all." + str2 + ".value") == "" && eval("document.all." + str1 + ".value") != "") {
        theNum = 0.5 * (1 + 1);
    } 
    else {
        theNum = (ET - ST) / 86400000 + 0.5 * (1 + 1);
    }
    var thenum1 = parseFloat(theNum);
    eval("document.all." + str3 + ".value=thenum1");
}
function Controls() {
    if (document.all.item("CF_Body") !== null ) {
        try {
            saveRtf("CF_Body");
        } 
        catch (e) {}
    }
    if (document.all.item("dtable") !== null ) {
        try {
            saveTable();
        } 
        catch (e) {}
    }
}
function saveTable() {
    var f = "document.forms[0].";
    for (var k = 0; k < arrField.length; k++) {
        if (arrField[k].indexOf("%%") == -1) {
            var tmpArr = new Array();
            if (newTableID.rows.length < dtable.rows.length) {
                tmpArr[tmpArr.length] = "";
            } else {
                for (var r = 0; r < newTableID.rows.length; r++) {
                    if (getFieldObj(newTableID, arrField[k] + "_" + (r + 1)) != null ) {
                        var tmpStr = getFieldValue(arrField[k] + "_" + (r + 1));
                        if (tmpStr == "")
                            tmpStr = "▲";
                        tmpArr[tmpArr.length] = tmpStr;
                    }
                }
            }
            if (eval(f + arrField[k] + "_All") != null ) {
                eval(f + arrField[k] + "_All").value = tmpArr.join("\r\n");
            } else {
                alert("多值域" + f + arrField[k] + "_All不存在,请检查!");
                return false;
            }
        }
    }
    for (var j = 0; j < arrSumField.length; j++) {
        if (arrSumField[j].indexOf("%%") == -1) {
            if (getFieldObj(newTableID, arrSumField[j] + "_1") != null  && eval(f + arrSumField[j] + "_All") != null ) {
                eval(f + arrSumField[j] + "_All").value = getFieldValue(arrSumField[j] + "_1");
            } else {
                alert("多值域" + f + arrSumField[j] + "_All不存在,请检查!");
                return false;
            }
        }
    }
    spanNewTable.innerHTML = "";
}
function getFieldValue(fieldName) {
    var filedObj = getFieldObj(newTableID, fieldName);
    var f = eval("document.forms[0]." + fieldName);
    if (filedObj.tagName == "SELECT") {
        if (f.options[f.selectedIndex].text != "") {
            return f.options[f.selectedIndex].text;
        } else {
            return f.options[f.selectedIndex].value;
        }
    } else {
        if (filedObj.type == "text" || filedObj.tagName == "TEXTAREA") {
            if (filedObj.tagName == "TEXTAREA") {
                re = /\r\n/g;
                return (f.value).replace(re, "<br>")
            }
            return f.value;
        }
        if (filedObj.type == "radio") {
            if (f.length == null ) {
                if (f.checked) {
                    return f.value;
                } else {
                    return "";
                }
            }
            for (var i = 0; i < f.length; i++) {
                if (f[i].checked) {
                    return f[i].value;
                }
            }
            return "";
        }
        if (filedObj.type == "checkbox") {
            var rtnV = "";
            if (f.length == null ) {
                if (f.checked) {
                    return f.value;
                } else {
                    return "";
                }
            }
            for (var i = 0; i < f.length; i++) {
                if (f[i].checked) {
                    if (i != 0) {
                        rtnV = rtnV + ";" + f[i].value
                    } else {
                        rtnV = f[i].value;
                    }
                } else {
                    if (i != 0) {
                        rtnV = rtnV + ";";
                    } else {
                        rtnV = "";
                    }
                }
            }
            return rtnV;
        }
    }
    return "";
}
function initTable() {
    if (dtable == null )
        return;
    if (dtable.rows.length < 2)
        return;
    var t_tmpTr;
    if (dtable.rows.length == 2) {
        t_tmpTr = dtable.rows[1];
        getArrField(t_tmpTr);
    } else {
        t_tmpTr = dtable.rows[dtable.rows.length - 2];
        getArrField(t_tmpTr);
        t_tmpTr = dtable.rows[dtable.rows.length - 1];
        getSumArrField(t_tmpTr);
    }
    var tmpTalbe = dtable.cloneNode(true);
    _insertCell(tmpTalbe, 0, "beforeBegin");
    _insertCell(tmpTalbe, tmpTalbe.rows[0].cells.length - 1, "afterEnd");
    setTableNo(tmpTalbe);
    tmpTalbe.rows[0].cells[tmpTalbe.rows[0].cells.length - 1].innerHTML = addr;
    tmpTalbe.rows[1].cells[tmpTalbe.rows[0].cells.length - 1].innerHTML = delr;
    tmpTalbe.rows[1].cells[tmpTalbe.rows[0].cells.length - 1].noWrap = true;
    if (tmpTalbe.rows.length > 2)
        tmpTalbe.rows[tmpTalbe.rows.length - 1].cells[tmpTalbe.rows[0].cells.length - 1].innerHTML = sumTable;
    if (document.forms[0].Form.value !== "CFM_Custom_Class") {
        if (document.forms[0].F_MainDocStatus.value == "待审" || document.forms[0].F_MainDocStatus.value == "通过") {
            tmpTalbe.rows[0].cells[tmpTalbe.rows[0].cells.length - 1].innerHTML = "〖 添 加 〗";
            tmpTalbe.rows[0].cells[tmpTalbe.rows[0].cells.length - 1].noWrap = true;
            tmpTalbe.rows[1].cells[tmpTalbe.rows[0].cells.length - 1].innerHTML = "〖 删 除 〗";
            tmpTalbe.rows[1].cells[tmpTalbe.rows[0].cells.length - 1].noWrap = true;
            tmpTalbe.rows[tmpTalbe.rows.length - 1].cells[tmpTalbe.rows[0].cells.length - 1].innerHTML = "     ";
        }
    }
    html = tmpTalbe.outerHTML;
    html = html.replace(/dtable/i, "newTableID");
    html = "<span id='spanNewTable'>" + html + "</span>";
    document.write(html);
    if (newTableID.rows.length < 3) {
        for (var k = 0; k < newTableID.rows[newTableID.rows.length - 1].cells.length; k++) {
            newTableID.rows[newTableID.rows.length - 1].cells[k].innerHTML = replaceField(newTableID.rows[newTableID.rows.length - 1].cells[k].innerHTML, "", "_1");
        }
    } else {
        for (var k = 0; k < newTableID.rows[newTableID.rows.length - 2].cells.length; k++) {
            newTableID.rows[newTableID.rows.length - 2].cells[k].innerHTML = replaceField(newTableID.rows[newTableID.rows.length - 2].cells[k].innerHTML, "", "_1");
        }
        for (var k = 0; k < newTableID.rows[newTableID.rows.length - 1].cells.length; k++) {
            newTableID.rows[newTableID.rows.length - 1].cells[k].innerHTML = replaceSumField(newTableID.rows[newTableID.rows.length - 1].cells[k].innerHTML, "", "_1");
        }
    }
    if (S_IsNewDoc == "0" || document.forms[0].F_MainDocStatus.value == "通过")
        initTableDate();
}
function setssFieldValue(fieldName, value) {
    eval("document.forms[0]." + fieldName).value = value;
}
function getFieldObj(obj, objName) {
    for (var x = 0; x < obj.childNodes.length; x++) {
        var rtnObj = getFieldObj(obj.childNodes[x], objName);
        if (rtnObj != null )
            return rtnObj;
        if (obj.childNodes[x].tagName == "INPUT" || obj.childNodes[x].tagName == "SELECT" || obj.childNodes[x].tagName == "TEXTAREA") {
            if (obj.childNodes[x].name == objName) {
                return obj.childNodes[x];
            }
        }
    }
}
function initTableDate() {
    var f = "document.forms[0].";
    if (arrField.length == 0)
        return;
    if (arrField[0] == "")
        return;
    for (var k = 0; k < arrField.length; k++) {
        if (arrField[k].indexOf("%%") == -1 && eval(f + arrField[k] + "_All") != null ) {
            var tmpArr = new Array();
            var tmpStr = eval(f + arrField[k] + "_All").value.replace(/▲/ig, "");
            // tmpArr = tmpStr.split("\r\n");
          	tmpArr = tmpStr.replace(/(\r\n)|(\n)/g,'<br>').split('<br>');
            for (var r = 0; r < tmpArr.length; r++) {
                if (eval(f + arrField[k] + "_" + (r + 1)) == null ) {
                    AddRow();
                }
                setFieldValue(arrField[k] + "_" + (r + 1), tmpArr[r]);
            }
        }
    }
    for (var j = 0; j < arrSumField.length; j++) {
        if (arrSumField[j].indexOf("%%") == -1 && eval(f + arrSumField[j] + "_All") != null ) {
            eval(f + arrSumField[j] + "_1").value = eval(f + arrSumField[j] + "_All").value;
        }
    }
}
function getArrField(obj) {
    for (var x = 0; x < obj.childNodes.length; x++) {
        getArrField(obj.childNodes[x]);
        if (obj.childNodes[x].tagName == "INPUT" || obj.childNodes[x].tagName == "SELECT" || obj.childNodes[x].tagName == "TEXTAREA") {
            for (var i = 0; i < arrField.length; i++) {
                if (arrField[i] == obj.childNodes[x].name)
                    return;
            }
            arrField[arrField.length] = obj.childNodes[x].name;
        }
    }
}
function setFieldValue(fieldName, value) {
    var filedObj = getFieldObj(newTableID, fieldName);
    var f = eval("document.forms[0]." + fieldName);
    if (filedObj != null  && filedObj.tagName == "SELECT") {
        for (var i = 0; i < f.options.length; i++) {
            if (f.options[i].text == value || f.options[i].value == value) {
                f.options[i].selected = true;
            } else {
                f.options[i].selected = false;
            }
        }
        return;
    } else {
        if (filedObj.type == "text" || filedObj.tagName == "TEXTAREA") {
            if (filedObj.tagName == "TEXTAREA") {
                re = /<br>/g;
                f.value = value.replace(re, "\r\n");
            } else {
                f.value = value
            }
            return;
        }
        if (filedObj.type == "radio") {
            if (f.length == null ) {
                if (f.value == value) {
                    f.checked = true;
                } else {
                    f.checked = false;
                }
                return;
            }
            for (var i = 0; i < f.length; i++) {
                if (f[i].value == value) {
                    f[i].checked = true;
                } else {
                    f[i].checked = false;
                }
            }
            return;
        }
        if (filedObj.type == "checkbox") {
            var rtnV = "";
            var valueArr = value.split(";");
            if (f.length == null ) {
                if (f.value == valueArr[0]) {
                    f.checked = true;
                } else {
                    f.checked = false;
                }
                return;
            }
            for (var i = 0; i < f.length; i++) {
                if (f[i].value == valueArr[i]) {
                    f[i].checked = true;
                } else {
                    f[i].checked = false;
                }
            }
            return;
        }
    }
    return "";
}
function getSumArrField(obj) {
    for (var x = 0; x < obj.childNodes.length; x++) {
        getSumArrField(obj.childNodes[x]);
        if (obj.childNodes[x].tagName == "INPUT") {
            for (var i = 0; i < arrSumField.length; i++) {
                if (arrSumField[i] == obj.childNodes[x].name)
                    return;
            }
            arrSumField[arrSumField.length] = obj.childNodes[x].name;
        }
    }
}
function replaceField(html, pre, nxt) {
    var tmpHtml = html;
    for (var k = 0; k < arrField.length; k++) {
        var re = new RegExp(arrField[k] + pre,"g");
        tmpHtml = tmpHtml.replace(re, arrField[k] + nxt);
    }
    return tmpHtml;
}
function replaceSumField(html, pre, nxt) {
    var tmpHtml = html;
    for (var k = 0; k < arrSumField.length; k++) {
        var re = new RegExp(arrSumField[k] + pre,"g");
        tmpHtml = tmpHtml.replace(re, arrSumField[k] + nxt);
    }
    return tmpHtml;
}
function insertRow(myTable, theRowNum, sWhere) {
    var i, j, newTR;
    i = theRowNum;
    if (myTable) {
        newTR = myTable.rows[i].cloneNode(true);
        myTable.rows[i].insertAdjacentElement(sWhere, newTR);
    }
}
function delRow() {
    if (actioning)
        return;
    actioning = true;
    var oa = window.event.srcElement;
    var otr = oa.parentElement;
    var i = 0;
    while (otr.tagName != "TR") {
        otr = otr.parentElement;
        i = otr.rowIndex;
    }
    newTableID.deleteRow(i);
    for (var k = i; k < newTableID.rows.length; k++) {
        for (var r = 0; r < newTableID.rows[k].cells.length; r++) {
            newTableID.rows[k].cells[r].innerHTML = replaceField(newTableID.rows[k].cells[r].innerHTML, "_" + (k + 1), "_" + k);
        }
    }
    setTableNo(newTableID);
    actioning = false;
}
function AddRow() {
    if (actioning)
        return;
    actioning = true;
    var sWhere;
    var i, newTR;
    if (dtable.rows.length > 2) {
        i = newTableID.rows.length - 2;
    } else {
        i = newTableID.rows.length - 1;
    }
    sWhere = "afterEnd";
    if (newTableID) {
        if (newTableID.rows.length < dtable.rows.length) {
            var tmpTable = dtable.cloneNode(true);
            _insertCell(tmpTable, 0, "beforeBegin");
            _insertCell(tmpTable, tmpTable.rows[0].cells.length - 1, "afterEnd");
            tmpTable.rows[1].cells[tmpTable.rows[0].cells.length - 1].innerHTML = delr;
            newTR = newTableID.rows[0].cloneNode(true);
            newTableID.rows[0].insertAdjacentElement(sWhere, newTR);
            for (var k = 0; k < newTableID.rows[1].cells.length; k++) {
                newTableID.rows[1].cells[k].innerHTML = replaceField(tmpTable.rows[1].cells[k].innerHTML, "", "_1")
            }
        } else {
            newTR = newTableID.rows[i].cloneNode(true);
            newTableID.rows[i].insertAdjacentElement(sWhere, newTR);
            for (var k = 0; k < newTableID.rows[i + 1].cells.length; k++) {
                newTableID.rows[i + 1].cells[k].innerHTML = replaceField(newTableID.rows[i + 1].cells[k].innerHTML, "_" + i, "_" + (i + 1));
            }
        }
        setTableNo(newTableID);
    }
    actioning = false;
}
function sumTalbeField() {
    var f = "document.forms[0].";
    for (var j = 0; j < arrSumField.length; j++) {
        var tmpFieldName = arrSumField[j].substring(0, arrSumField[j].lastIndexOf("_Sum"));
        var tmpSum = 0;
        for (var k = 0; k < newTableID.rows.length; k++) {
            if (eval(f + tmpFieldName + "_" + (k + 1)) != null  && eval(f + tmpFieldName + "_" + (k + 1)).value != "") {
                if (!isNaN(eval(f + tmpFieldName + "_" + (k + 1)).value)) {
                    tmpSum = tmpSum + parseFloat(eval(f + tmpFieldName + "_" + (k + 1)).value);
                }
            }
        }
        if (eval(f + tmpFieldName + "_Sum_1") != null ) {
            eval(f + tmpFieldName + "_Sum_1").value = tmpSum;
        }
    }
}
function deleteRow(i) {
    var i, j;
    var orow;
    if (myTable) {
        if (myTable.rows.length < 2)
            alert("该表格已剩下一行，如果您想要删除表格，请在表格边框上点击一下，选中后按Del键删除。");
        else
            myTable.deleteRow();
    }
}
function setTableNo(theTable) {
    for (var i = 0; i < theTable.rows.length; i++) {
        if (i == 0) {
            theTable.rows[i].cells[0].innerText = "序号";
            theTable.rows[i].cells[0].noWrap = true;
            theTable.rows[i].cells[0].width = "1%";
        } else {
            theTable.rows[i].cells[0].innerText = "" + i;
            theTable.rows[i].cells[0].width = "1%";
        }
    }
    if (dtable.rows.length > 2)
        theTable.rows[theTable.rows.length - 1].cells[0].innerText = "合计";
}
function _insertCell(myTable, theCellNum, sWhere) {
    var i, j, newTD;
    j = theCellNum;
    if (myTable) {
        for (i = 0; i < myTable.rows.length; i++) {
            newTD = myTable.rows[i].cells[j].cloneNode(true);
            newTD.innerText = "";
            newTD.colSpan = 1;
            myTable.rows[i].cells[j].insertAdjacentElement(sWhere, newTD);
        }
    }
}
function filemngRtf() {
    if (subform == "") {
        try {
            initRtf("F_Body");
        } 
        catch (e) {}
    } 
    else {
        document.all.tb_1.style.display = "none";
        document.all.tb_2.style.display = "none";
    }
}
function filemngClassRtf() {
    if (subform == "") {
        try {
            initRtf("F_Body");
        } 
        catch (e) {}
    } 
    else {
        document.all.tb_1.style.display = "none";
        document.all.tb_2.style.display = "none";
    }
}
function reviewRtf() {
    if (subform == "") {
        try {
            initRtf("F_Body");
        } 
        catch (e) {}
    } 
    else {
        document.all.tb_1.style.display = "none";
    }
}
