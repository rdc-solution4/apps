RegisterJsFile("dialog.js");
function LKSDialog(title, mulSelect, sourceDb, itemList) {
    this.title = title ? title : "";
    this.mulSelect = mulSelect;
    this.itemList = (itemList ? itemList : "").split(":");
    if (this.itemList.length == 1)
        this.itemList[1] = this.itemList[0];
    this.canBeMove = false;
    var path = location.href.toLowerCase();
    var po = location.protocol.toLowerCase();
    path = path.substring(po.length + 3);
    path = path.substring(path.indexOf("/"));
    path = path.substring(0, path.indexOf(".nsf"));
    if (sourceDb == null )
        sourceDb = path + ".nsf";
    path = path.substring(0, path.lastIndexOf("/"));
    if (sourceDb.indexOf("/") == -1)
        sourceDb = path + "/" + sourceDb;
    this.sourceDb = sourceDb;
    this.dialogPath = path.substring(0, path.lastIndexOf("/")) + "/sys/lks_public.nsf/fm_dialog?readform";
    this.style = null ;
    this.moreInfo = null ;
    this.moreInfoName = null ;
    this.showSelectNone = true;
    this.GetItemValue = DialogGetItemValue;
    this.AddDefaultOpt = DialogAddDefaultOpt;
    this.AddDefaultSel = DialogAddDefaultSel;
    this.AddDefaultView = DialogAddDefaultView;
    this.AddDefaultData = DialogAddDefaultData;
    this.EnableSearch = DialogEnableSearch;
    this.Show = DialogShow;
    this.SetItemValue = DialogSetItemValue;
    this.SetItemOption = DialogSetItemOption;
    this.SetFieldOption = DialogSetFieldOption;
    this.DefaultOptList = new Array;
    this.DefaultOptList[0] = new Array;
    this.DefaultOptList[1] = new Array;
    this.DefaultOptList[2] = new Array;
    this.DefaultSelList = new Array;
    this.DefaultSelList[0] = new Array;
    this.DefaultSelList[1] = new Array;
    this.DefaultSelList[2] = new Array;
    this.SearchInfo = null ;
    this.rtnVal = null ;
    this.Tree = null ;
}
function DialogShow() {
    if (this.style == null )
        this.style = (this.Tree ? "dialogWidth:620px;" : "dialogWidth:440px;") + " dialogHeight:400px; status:0;scroll:0; help:0";
    var path = this.dialogPath + "&title=" + escape(this.title) + "&type=" + (this.Tree ? "T" : "N") + (this.mulSelect ? "M" : "S");
    var parameter = new Array;
    parameter[0] = this.Tree;
    parameter[1] = this.DefaultOptList;
    parameter[2] = this.DefaultSelList;
    parameter[3] = this.SearchInfo;
    parameter[4] = this.canBeMove;
    parameter[5] = this.moreInfo;
    parameter[6] = this.moreInfoName;
    parameter[7] = this.showSelectNone;
    this.rtnVal = window.showModalDialog(path, parameter, this.style);
}
function DialogTree(title, sourceDb) {
    this.index = 0;
    this.sourceDb = sourceDb;
    this.treeCode = "LKSTree=createTreeBase(\"" + title + "\",\"LKSTree\",document.all.treeDiv);\n";
    this.treeCode += "LKSTree.OnFolderQueryOpen = DialogOpenFolder;\n";
    this.treeCode += "var Aux0 = LKSTree.TreeRoot;\n";
    this.treeCode += "Aux0.href = 'C0';\n";
    this.appendChild = DialogTreeAppendChild;
    this.appendView = DialogTreeAppendView;
    this.addEntry = DialogTreeAddEnrty;
    this.addViewEntry = DialogTreeAddViewEnrty;
    this.bindSelect = DialogTreeBindSelect;
    this.addDataEntry = DialogTreeAddDataEnrty;
    this.childEntries = new Array;
}
function DialogTreeAppendChild(parent, title) {
    var pnode = parent == null  ? "Aux0" : "Aux" + parent;
    this.treeCode += "var Aux" + (++this.index) + "=appendChild(" + pnode + ",\"" + title + "\",\"C" + this.index + "\");\n";
    return this.index.toString();
}
function DialogTreeAppendView(parent, viewName) {
    var pnode = parent == null  ? "Aux0" : "Aux" + parent;
    if (viewName.indexOf("/") == -1)
        viewName = this.sourceDb + "/" + viewName;
    this.treeCode += "appendView(" + pnode + ",\"" + viewName + "\",\"V" + viewName + "\");\n";
}
function DialogTreeBindSelect(node) {
    node = node == null  ? "0" : node;
    this.treeCode += "Aux" + node + ".parameter='binded'\n";
}
function DialogAddEntry(obj, type, keyList, disList, node) {
    var i, j;
    if (node != null ) {
        for (i = 0; i < obj.length; i++)
            if (obj[i][3] == node)
                break;
        if (i == obj.length) {
            obj[i] = new Array;
            obj[i][0] = new Array;
            obj[i][1] = new Array;
            obj[i][2] = new Array;
            obj[i][3] = node;
        }
        obj = obj[i];
    }
    if (typeof (keyList) == "string") {
        obj[0][obj[0].length] = type;
        obj[1][obj[1].length] = keyList;
        obj[2][obj[2].length] = disList;
    } else {
        for (j = 0; j < keyList.length; j++) {
            obj[0][obj[0].length] = type;
            obj[1][obj[1].length] = keyList[j];
            obj[2][obj[2].length] = disList[j];
        }
    }
}
function DialogTrim(arr) {
    var rtn = new Array;
    if (typeof (arr) == "string") {
        var tmpStr = arr;
        arr = new Array;
        arr[0] = tmpStr;
    }
    for (var i = 0; i < arr.length; i++) {
        var tmpStr = arr[i];
        for (; tmpStr.substring(0, 1) == " "; tmpStr = tmpStr.substring(1))
            ;
        for (; tmpStr.substring(tmpStr.length - 1) == " "; tmpStr = tmpStr.substring(0, tmpStr.length - 1))
            ;
        if (tmpStr != "")
            rtn[rtn.length] = tmpStr;
    }
    return rtn;
}
function DialogTreeAddEnrty(node, keyList, disList) {
    node = node == null  ? "0" : node;
    disList = disList == null  ? keyList : disList;
    DialogAddEntry(this.childEntries, "C", keyList, disList, node);
}
function DialogTreeAddViewEnrty(node, viewName, className) {
    node = node == null  ? "0" : node;
    viewName = (viewName.indexOf("/") == -1) ? (this.sourceDb + "/" + viewName) : viewName;
    className = className ? className : "";
    DialogAddEntry(this.childEntries, "V", viewName, className, node);
}
function DialogTreeAddDataEnrty(node, queryUrl) {
    node = node == null  ? "0" : node;
    DialogAddEntry(this.childEntries, "O", queryUrl, "", node);
}
function DialogAddDefaultOpt(keyList, disList) {
    disList = disList == null  ? keyList : disList;
    DialogAddEntry(this.DefaultOptList, "C", keyList, disList, null );
}
function DialogAddDefaultSel(keyList, disList) {
    disList = disList == null  ? keyList : disList;
    DialogAddEntry(this.DefaultSelList, "C", keyList, disList, null );
}
function DialogAddDefaultView(viewName, className) {
    viewName = (viewName.indexOf("/") == -1) ? (this.sourceDb + "/" + viewName) : viewName;
    className = className ? className : "";
    DialogAddEntry(this.DefaultOptList, "V", viewName, className);
}
function DialogAddDefaultData(queryUrl) {
    DialogAddEntry(this.DefaultOptList, "O", queryUrl, "");
}
function DialogEnableSearch(viewName, words, startWord, isCategory, isXML) {
    if (viewName.indexOf("/") == -1)
        viewName = this.sourceDb + "/" + viewName;
    this.SearchInfo = new Array;
    this.SearchInfo[0] = viewName;
    this.SearchInfo[1] = words ? words : "请输入起始字符";
    this.SearchInfo[2] = startWord ? startWord : "";
    this.SearchInfo[3] = isCategory ? isCategory : false;
    this.SearchInfo[4] = isXML ? isXML : false;
}
function DialogGetItemValue(itemName, itemList, fieldList, sepStr) {
    var i;
    itemList = itemList.split(":");
    fieldList = fieldList.split(":");
    for (i = 0; i < itemList.length; i++)
        if (itemName == itemList[i])
            break;
    var rtnVal = eval("document.all." + fieldList[i] + ".value");
    if (sepStr != null )
        rtnVal = rtnVal.split(sepStr);
    return DialogTrim(rtnVal);
}
function DialogSetItemValue(viewName, itemList, fieldList, sepStr, isAddVal, viewIsCate) {
    var fieldObj;
    itemList = itemList.split(":");
    fieldList = fieldList.split(":");
    if (!isAddVal)
        for (var i = 0; i < fieldList.length; i++){
            // eval("document.all." + fieldList[i]).value = "";
          	document.getElementsByName(fieldList[i])[0].value = "";
        }
          
    if (sepStr == null )
        sepStr = ";";
    if (this.itemList[0] == "") {
        var extendMode = true;
    } else {
        var extendMode = false;
        for (var i = 0; i < itemList.length; i++) {
            switch (itemList[i]) {
            case this.itemList[0]:
                // fieldObj = eval("document.all." + fieldList[i]);
                 fieldObj = document.getElementsByName(fieldList[i])[0];
                var tmpStr = this.rtnVal[0].length == 0 ? "" : DialogFunctionJoin(this.rtnVal[0], sepStr);
                fieldObj.value += (fieldObj.value == "" || tmpStr == "" ? "" : sepStr) + tmpStr;
                itemList[i] = null ;
                break;
            case this.itemList[1]:
                // fieldObj = eval("document.all." + fieldList[i]);
                fieldObj = document.getElementsByName(fieldList[i])[0];
                var tmpStr = this.rtnVal[1].length == 0 ? "" : DialogFunctionJoin(this.rtnVal[1], sepStr);
                fieldObj.value += (fieldObj.value == "" || tmpStr == "" ? "" : sepStr) + tmpStr;
                itemList[i] = null ;
                break;
            default:
                extendMode = true;
            }
        }
    }
    if (!extendMode)
        return;
    if (viewName.indexOf("/") == -1)
        viewName = this.sourceDb + "/" + viewName;
    var className = this.rtnVal[0];
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    if (viewIsCate)
        var QueryURL = viewName + "?readviewentries&count=9999999&preformat&restricttocategory=";
    else
        var QueryURL = viewName + "?readviewentries&count=1&preformat&startkey=";
    for (var k = 0; k < className.length; k++) {
        if (className[i] == "")
            continue;xml.load(QueryURL + escape(className[k]));
        var nodes = xml.selectNodes("/viewentries/viewentry");
        for (var i = 0; i < nodes.length; i++) {
            if (!viewIsCate)
                if (nodes[0].selectNodes("entrydata")[0].text != className[k])
                    return;
            for (var j = 0; j < itemList.length; j++) {
                if (itemList[j] == null )
                    continue;fieldObj = document.getElementsByName(fieldList[j])[0]; //eval("document.all." + fieldList[j]);
                fieldObj.value += (fieldObj.value == "" ? "" : sepStr) + GetChildNodeText(nodes[i], itemList[j]);
            }
        }
    }
}
function DialogSetItemOption(viewName, itemList, fieldList, sepStr, addPlusSel, viewIsCate) {
    itemList = itemList.split(":");
    fieldList = fieldList.split(":");
    addPlusSel = addPlusSel ? true : false;
    sepStr = sepStr ? sepStr : "";
    if (this.itemList[0] == "") {
        var extendMode = true;
    } else {
        var extendMode = false;
        for (var i = 0; i < itemList.length; i++) {
            switch (itemList[i]) {
            case this.itemList[0]:
                this.SetFieldOption(fieldList[i], sepStr ? this.rtnVal[0].split(sepStr) : this.rtnVal[0], addPlusSel, sepStr);
                itemList[i] = null ;
                break;
            case this.itemList[1]:
                this.SetFieldOption(fieldList[i], sepStr ? this.rtnVal[1].split(sepStr) : this.rtnVal[1], addPlusSel, sepStr);
                itemList[i] = null ;
                break;
            default:
                extendMode = true;
            }
        }
    }
    if (!extendMode)
        return;
    if (viewName.indexOf("/") == -1)
        viewName = this.sourceDb + "/" + viewName;
    var className = this.rtnVal[0];
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    var tmpArr;
    if (viewIsCate)
        var QueryURL = viewName + "?readviewentries&count=9999999&preformat&restricttocategory=";
    else
        var QueryURL = viewName + "?readviewentries&count=1&preformat&startkey=";
    for (var k = 0; k < className.length; k++) {
        if (className[i] == "")
            continue;xml.load(QueryURL + escape(className[k]));
        var nodes = xml.selectNodes("/viewentries/viewentry");
        for (var j = 0; j < itemList.length; j++) {
            if (itemList[j] == null )
                continue;tmpArr = new Array;
            if (viewIsCate || nodes[0].selectNodes("entrydata")[0].text == className[k])
                for (var i = 0; i < nodes.length; i++)
                    tmpArr[tmpArr.length] = GetChildNodeText(nodes[i], itemList[j]);
            this.SetFieldOption(fieldList[j], tmpArr, addPlusSel, sepStr);
        }
    }
}
function DialogSetFieldOption(fieldName, optList, addPlusSel, sepStr) {
    if (fieldName == "")
        return;
    var fieldObj = eval("document.all." + fieldName);
    if (!fieldObj || fieldObj.tagName != "SELECT")
        return;
    var i, j, k, tmpArr, fieldVal = fieldObj.options[fieldObj.selectedIndex].text;
    for (i = fieldObj.options.length - 1; i >= 0; i--)
        fieldObj.options[i] = null ;
    i = 0;
    if (addPlusSel)
        fieldObj.options[i++] = new Option("---请选择---"," ");
    if (!optList[0])
        optList = new Array(optList);
    for (j = 0; j < optList.length; j++) {
        if (optList[j] == "")
            continue;if (sepStr != "")
            tmpArr = optList[j].split(sepStr);
        else
            tmpArr = new Array(optList[j]);
        for (k = 0; k < tmpArr.length; k++) {
            fieldObj.options[i++] = new Option(tmpArr[k],tmpArr[k]);
            if (fieldVal == tmpArr[k])
                fieldObj.selectedIndex = i - 1;
        }
    }
}
function GetChildNodeText(XmlNode, ChildNodeName) {
    var Node = null , AttrNode;
    Node = XmlNode.firstChild;
    while (Node != null ) {
        AttrNode = Node.getAttributeNode("name");
        if (AttrNode != null  && AttrNode.nodeValue == ChildNodeName)
            return Node.text;
        Node = Node.nextSibling;
    }
    return "";
}
function SimpleDialog(title, itemList, fieldList, viewName, useTree, treeView, treeTitle) {
    var dialog = new LKSDialog(title,false,null );
    if (useTree) {
        treeTitle = treeTitle ? treeTitle : title;
        dialog.Tree = new DialogTree(treeTitle,dialog.sourceDb);
        dialog.Tree.appendView(null , treeView);
        dialog.AddDefaultView(treeView, "-1");
    } else {
        dialog.AddDefaultView(viewName);
    }
    dialog.Show();
    if (dialog.rtnVal) {
        dialog.SetItemValue(viewName, itemList, fieldList);
        return true;
    } else {
        return false;
    }
}
function DialogFunctionJoin(arr, sepStr) {
    var rtnVal = "";
    for (var i = 0; i < arr.length; i++)
        rtnVal += sepStr + arr[i];
    if (i > 0)
        rtnVal = rtnVal.substring(1);
    return rtnVal;
}
