var FlowLog_FinishMan=new Array();
var S_NeedSaveSign=false;
var S_EsaDocId;
var  dbNeedEsaArray = new Array("lks/koa/lks_financeflowreview.nsf","lks/koa.rlgs/lks_financeflowreview.nsf","lks/koa.ylwdc/lks_financeflowreview.nsf","lks/koa.xggs/lks_financeflowreview.nsf","lks/koa.mwdl/lks_financeflowreview.nsf","lks/koa.dbdc/lks_financeflowreview.nsf","lks/koa.dsfgs/lks_financeflowreview.nsf","lks/koa.wygs/lks_financeflowreview.nsf","lks/koa.dlfw/lks_financeflowreview.nsf","lks/koa.ysgs/lks_financeflowreview.nsf","lks/koa.hbgs/lks_financeflowreview.nsf","lks/koa.whhb/lks_financeflowreview.nsf") //是否需要启动安证通签名

if(document.body) {
	var onloadFunction = document.body.onload;
	if((""+onloadFunction).indexOf("esa_Onload()")==-1) {
		document.body.onload = function(){
			if(onloadFunction) onloadFunction();
			//新建文档权限检测  
			if(window.checkRight_Run)  if(!checkRight_Run()) return;                        
			setTimeout("showFlowLog();esa_Onload();",10);
		}
	}
}
function esa_Onload() {
	//待审情况
	if (document.all.F_EsaRs) {
		if (document.all.F_ParentDocID) {
			if (document.all.F_ParentDocID.length) {
				S_EsaDocId = document.all.F_ParentDocID[0].value;
			} else {
				S_EsaDocId = document.all.F_ParentDocID.value;
			}
		} else {
			S_EsaDocId = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
		}
	} else {
		//是否打印状态
		if (S_IsNewDoc == 1) {
			if (document.all.F_ParentDocID) {
				S_EsaDocId = document.all.F_ParentDocID.value;
			}
		} else {
			S_EsaDocId = S_DocId;
		}
		document.all.Sys_EsaField.innerHTML = "<textarea name=\"F_EsaRs\" style=\"display:none\" rows=\"1\" cols=\"10\"></textarea><textarea name=\"F_EsaOption\" style=\"display:none\" rows=\"1\" cols=\"10\"></textarea>";
	}
	showEsaSign();
}


function addEsaSign() {
	var lRet = 0;
	try {
		lRet = document.all["AztAdd"].ESAOnAddNew();
	}catch (e) {
		document.getElementById("AztAdd").style.height="30px";
		document.getElementById("Sys_EsaAddSign").style.display = "";
		setTimeout(addEsaSignNew, 30);
		return;
	}
	var v = GetAbsoluteLocation("AztAdd");
	S_NeedSaveSign = true;
	if (lRet != 0) {
		document.all["AztAdd"].ESAShowErrorMsg(lRet);
		S_NeedSaveSign = false;
	}
}
function addEsaSignNew() {
	var v = GetAbsoluteLocation("F_Opinion");
	var opobj = document.getElementById("F_Opinion");
	/*安证通插件的ESASetProBarStyle函数：
		用途：	设置进度条风格
		参数：	int xPos 进度条相对浏览器的x位置
	      		int yPos 进度条相对浏览器的y位置
	      		Hex(8) BarColor 进度条前景色，格式为：0xAABBGGRR，例如：0x00FAE5C4，其中AA从00-FF，00表示不透明
	      		Hex(8) BkColor 进度条背景色，格式同BarColor
	      		int nWidth 进度条宽度
	      		int nHeight 进度条高度
	*/
	try {
		document.all["AztAdd"].ESASetProBarStyle(v[1] + 3, v[0] - getScrollTop() + opobj.offsetHeight + 5,0x00FAE5C4,0x00F0F0F0, 200, 20);
	}catch (e2) {}
	var lRet = 0;
	lRet = document.all["AztAdd"].ESAOnAddNew(S_EsaDocId, 2, 0, "");
	var v = GetAbsoluteLocation("AztAdd");
	S_NeedSaveSign = true;
	if (lRet != 0) {
		document.all["AztAdd"].ESAShowErrorMsg(lRet);
		S_NeedSaveSign = false;
	}
}
function resizeControl(c, a, b) {
    //处理位置和大小
	doResizeControl(a, b, c);
}
function doResizeControl(a, b, c) {
	document.all[c].style.visibility = "hidden";
	document.all[c].style.pixelWidth = a;
	document.all[c].style.pixelHeight = b;
	document.all[c].style.visibility = "visible";
}
function doMove(a, b, c) {
	document.all[c].style.visibility = "hidden";
	var nw = document.all[c].style.pixelWidth;
	var nh = document.all[c].style.pixelHeight;
	document.all[c].style.left = a;
	document.all[c].style.top = b;
	document.all[c].style.visibility = "visible";
}
function saveEsaSign() {
	var nRet = document.all["AztAdd"].ESAVerifySubmit();
	if (nRet <= 0) {
		if (nRet == 0) {
				//不能提交只加盖了样章的表单。
			alert("");
		} else {
			if (nRet == -1) {
				//验证失败
				alert("需求方印章验证失败！");
			} else {
				//其他错误
				document.all["AztAdd"].ESAShowErrorMsg(nRet);
			}
		}
	} else {
		if (nRet == 1) {
			//验证无误，提交印章信息
			document.all("F_EsaRs").value = document.all["AztAdd"].ESAMarshal();
			return sendEsaSign(document.all("F_EsaRs").value);
		}
	}
	return false;
}
//koa_lihx 20161128 获取滚动条的高度
function getScrollTop() {
	var scrollPos;
	if (window.pageYOffset) {
		scrollPos = window.pageYOffset;
	} else {
		if (document.compatMode && document.compatMode != "BackCompat") {
			scrollPos = document.documentElement.scrollTop;
		} else {
			if (document.body) {
				scrollPos = document.body.scrollTop;
			}
		}
	}
	return scrollPos;
} 
//获取对象在页面中的坐标
//koa_lihx 20161128 补足支持frame层级嵌套定位问题，获取对象相对顶层窗口的偏移量	
function GetAbsoluteLocation(objName, isTopXY) {
	var element = window.document.getElementById(objName);
	if (arguments.length != 1 || element == null) {
		return null;
	}
	var offsetTop = element.offsetTop;
	var offsetLeft = element.offsetLeft;
	var offsetWidth = element.offsetWidth;
	var offsetHeight = element.offsetHeight;
	while (element = element.offsetParent) {
		offsetTop += element.offsetTop;
		offsetLeft += element.offsetLeft;
	} 
    	//获取对象相对顶层窗口的偏移量
	offsetTop += this.screenTop - top.screenTop;
	offsetLeft += this.screenLeft - top.screenLeft;
	var labels = new Array(offsetTop, offsetLeft, offsetWidth, offsetHeight);
	return labels;
}
function ESAGetData(control) {
	return document.all["F_EsaOption"].value;
}

function RunJspByXml(agent)
{
	var xml = new ActiveXObject("MSXML.DOMDocument");
	xml.async = false;
	var path="http://oajava.sec.com.cn:8083/order";
	xml.load(path +"/" + agent);
	nodes = xml.selectNodes("value");
	result = nodes[0].text;
	if(result=="" || result==null){
		alert("没有印章!");
	}
	xml=null;
	return result;
}

function getEsaSign(signObj,uid,docid){

	var v=RunJspByXml("signdomino.jsp?userid="+uid+"&docid="+docid);
	if(v=="" || v==null){
		alert("没有印章!");
		document.all("F_EsaRs").value="";
		return false;
	}
	
	document.all("F_EsaRs").value=v;

	try{
	var rnt = signObj.ESAVerifySowSign(document.all("F_EsaRs").value,document.all("F_EsaRs").value.length);
	}catch(e){
		//20170124 koa_lihx 解决用户未安装安证通控件时，获取签名图片报错导致后续所有JS代码不能执行的问题.
		//当用户未曾安装安证通控件时，则控制台报错，签名图片隐藏;
		signObj.style.display="none";
		if(window.console!=null){
			console.error("发生错误，Name:"+e.name+"；Message:"+e.message+"；Number:"+e.number+"。");
		}
	}
	//20170124 koa_lihx 在该行的用户列显示一个图标表示该节点是用户签名后审批通过的（类似微信）.
	for(var obj = signObj.parentElement;obj!=null;obj = obj.parentElement){
		if(obj.tagName=="TR"){
			var spanArr=obj.getElementsByTagName("span");
			for(var ix=0;ix<spanArr.length;ix++){
				if(spanArr[ix].nodenm!=null){
					var imgObj=document.createElement("img");
					imgObj.title="签名审批";
					imgObj.src="http://oa.sec.com.cn/lks/koa/images/ESASign.png";
					imgObj.style.width="20px";
					imgObj.style.height="20px";
					spanArr[ix].appendChild(imgObj);
					break;
				}
			}
			break;
		}
	}
	
	var v = GetAbsoluteLocation(signObj.id);
    document.all[signObj.id].style.width="82";

    document.all[signObj.id].style.height="50";
    doMove(v[1], v[0], signObj.id);	
}
function showEsaSign(){
	if (!document.all.Sys_EsaSign) return;
	if (document.all.Sys_EsaSign.length)
	{
		for (i=0;i<document.all.Sys_EsaSign.length;i++)
	    {
     		var spanObj=document.all.Sys_EsaSign[i];
     		var signOcxHTML="<object classid=\"clsid:49FB4BA2-3A7A-4635-91CD-9C2D5470F8CF\" CODEBASE=\""+S_DbPath+"/AztSOW.CAB#version=1,0,0,0\" id=\"AztSow"+i+"\"></object>"
     		spanObj.innerHTML=signOcxHTML;  
     		var signObj=eval("document.all.AztSow"+i) ;
     		getEsaSign(signObj,spanObj.userid,S_EsaDocId);

    	}
	}else{
		var spanObj=document.all.Sys_EsaSign;
     	var signOcxHTML="<object classid=\"clsid:49FB4BA2-3A7A-4635-91CD-9C2D5470F8CF\" CODEBASE=\""+S_DbPath+"/AztSOW.CAB#version=1,0,0,0\" id=\"AztSow0\"></object>"
     	spanObj.innerHTML=signOcxHTML;   
     	var signObj=eval("document.all.AztSow0") ;
     	getEsaSign(signObj,spanObj.userid,S_EsaDocId);
    }	
}
function sendEsaSign(signData){
	//*固定值测试
	var sendData="userid="+S_UserAd+"&flowid="+S_EsaDocId+"&rs="+signData;

	var objHTTP = new ActiveXObject("Microsoft.XMLHTTP");
	objHTTP.Open('post','http://oajava.sec.com.cn:8083/order/sendsigndomino.jsp',false);
	objHTTP.setrequestheader("cache-control","no-cache"); 
	objHTTP.setrequestheader("Content-Type","application/x-www-form-urlencoded");
	objHTTP.Send(sendData);
	if(objHTTP.responseText.indexOf("false")!=-1) return false; else return true;
}
function arrayIndexOf(arr,v)
{
    for(var i = arr.length; i-- && arr[i] !== v;);
    return i;
}
function optObjFormatMoney(objTd)
{
    if(objTd.innerText!='' && !isNaN(objTd.innerText)) objTd.innerText=FormatMoney(objTd.innerText,"2");
}
/**
 * 处理附件中的#号
 * 将审批记录中的附件名称中包含的#转换为%23
 */
function chuLiFJZJHao(){
//if(S_UserName=="koa_lihx"){
	var reviewLog = document.getElementById("FlowLog_MainTable");
	if(reviewLog==null){return;}
	var arr = reviewLog.getElementsByTagName("A");
	var i=0;ix1=-1,ix2=-1,ix3=-1,temps="",temps1="";
	for(;i<arr.length;i++){
		if(arr[i].href==null){
			continue;
		}
		ix1=arr[i].href.toLowerCase().indexOf("/$file/");
		if(ix1>-1){
			ix2=arr[i].href.indexOf(".",ix1);
			if(ix2>ix1){
				temps=arr[i].href.substring(ix1,ix2);
				temps1=temps.replace("#",escape("#"));
				if(temps!="" && temps!=temps1){
					arr[i].href=arr[i].href.replace(temps,temps1);
				}
			}		
		}
	}
//}
}
//flowlog for table 20090708
function showFlowLog()
{
showFlowLogNew2();
try{
	chuLiFJZJHao();
}catch(e){}
return;
	var S_LogId="";
	//是否打印状态
	if (S_IsNewDoc==1){ 
		if(document.all.F_ParentDocID)
			S_LogId=document.all.F_ParentDocID.value;
        }
	else S_LogId=S_DocId;
	//if(S_LogId=="609290CCAD3BEF9348257D57002B5630.." || S_LogId=="BC4DA9083D6813F848257D3B0028AA37.."){
		//showFlowLogNew2();
		//return ;
	//}
	//var tmphrefStr = location.href;
	//if(tmphrefStr.indexOf("koa.xxjs")!=-1 && S_UserAd!="chenliangang"){
	//if(tmphrefStr.indexOf("koa.xxjs")!=-1 && parent.location.href.indexOf("&newlog=false")==-1){
		//showFlowLogNew2();
		//return ;
	//}



     if(window.S_IsEdited==0 && document.all.Sys_FormatMoney)
     {
          if(!document.all.Sys_FormatMoney.length) optObjFormatMoney(document.all.Sys_FormatMoney);
          else
          for(var l=0;l<document.all.Sys_FormatMoney.length;l++)
               optObjFormatMoney(document.all.Sys_FormatMoney[l]);
     }
     if(!document.all.FlowLog_Table)  return;
     var j=document.all.FlowLog_Table.length;
     var systemHTML=""
     var Str_TableLog = '<table id=FlowLog_MainTable width=100% align=center border="0" cellspacing="1" cellpadding="5" bgcolor=#c0c0c0>';
     Str_TableLog += '<tr valign="top"><td width="1%" bgcolor="#FFFFFF" noWrap align=center><b>序号</b></td><td width="15%" bgcolor="#FFFFFF"  align=center><b>处理时间</b></td><td width="25%" bgcolor="#FFFFFF"  align=center><b>处理人</b></td><td width="30%" bgcolor="#FFFFFF"  align=center><b>具体意见</b></td><td width="30%" bgcolor="#FFFFFF"  align=center><b>流程节点及处理方式</b></td></tr>'

     var Str_ReviewLog="",str_User,str_Post;
     var trNode;
     if (!j){
          trNode=document.all.FlowLog_Table;
          if(document.all.FlowLog_Table.previousSibling.flowlogtable!='1') return;
          var parentElem = trNode.parentElement;                  
          Str_ReviewLog += printRowHtml(trNode,0);
     }
     else {
          if(document.all.FlowLog_Table[0].previousSibling.flowlogtable!='1') return;
          var parentElem = document.all.nodeNo[0].parentElement;
          for(var i=0;i<j;i++)
          {
               trNode=document.all.FlowLog_Table[i]               
               Str_ReviewLog += printRowHtml(trNode,i);
          }  
     }       
     Str_ReviewLog += "</table>"
     parentElem.innerHTML=(Str_TableLog+Str_ReviewLog)
     if (document.all.Td_FlowLogIsPrint)setTableStyle(document.all.FlowLog_MainTable);
     if(!document.all.finishMan) return;
     FlowLog_FinishMan=uniqueTrim(FlowLog_FinishMan);
     if(FlowLog_FinishMan) document.all.finishMan.innerHTML=FlowLog_FinishMan.join(";");
}
function getTagHTML(obj,tagName)
{
    var returnObj = obj.getElementsByTagName("SPAN");
    if (returnObj.length>0){
        for(var i=0;i<returnObj.length;i++)
        {
            // attu=eval("returnObj[i]."+tagName)
          attu= returnObj[i].getAttribute(tagName);
            if (attu)
                return returnObj[i].outerHTML;
        }
        
    }
    return ""
}
function getTagUserAdHTML(obj,tagName,rownum)
{
    var returnObj = obj.getElementsByTagName("SPAN");
    if (returnObj.length>0){
        for(var i=0;i<returnObj.length;i++)
        {
            // attu=eval("returnObj[i]."+tagName);
          	attu= returnObj[i].getAttribute(tagName);
            if (attu){
		if(window.S_JavaScriptRnd && rownum>0)FlowLog_FinishMan.push(returnObj[i].innerText);
                return returnObj[i].outerHTML;
	    }	
        }
        
    }
    return ""
}
function printRowHtml(trNode,i)
{
     var timeStr=""
     var Str_ReviewLog = '<tr valign="top" nodekey="'+trNode.nodekey+'">';
     Str_ReviewLog += '<td bgcolor="#FFFFFF">'+(i+1)+'</td>';
     var tempStr;
     
     timeStr=getTagHTML(trNode,"istime")
     Str_ReviewLog += '<td bgcolor="#FFFFFF">'+timeStr+"</td>"  //处理时间列值
     str_User = getTagUserAdHTML(trNode,"nodenm",i);
     if(str_User=='' && trNode.innerHTML.indexOf(" 系统 ")==-1) str_User =  getTagUserAdHTML(trNode,"userAD",i);          
     Str_ReviewLog += '<td bgcolor="#FFFFFF">'+str_User+'</td>';  //处理人列值
     if(str_User!=''){
          tempStr = getTagHTML(trNode,"nodelog");
          Str_ReviewLog += '<td bgcolor="#FFFFFF">'+tempStr+'</td>';   //处理意见列值
          tempStr = getTagHTML(trNode,"nodetype");
          if(tempStr==''){
               Str_ReviewLog += '<td bgcolor="#FFFFFF">'+trimTimeStr(trNode.outerHTML,timeStr)+'</td>';   //处理方式列值
          }
          else Str_ReviewLog += '<td bgcolor="#FFFFFF">'+tempStr+'</td>';   //处理方式列值
     }else{
          Str_ReviewLog += '<td bgcolor="#FFFFFF">&nbsp;</td>'; //当处理人为空时，处理意见相应的也为空
          Str_ReviewLog += '<td bgcolor="#FFFFFF">'+trimTimeStr(trNode.outerHTML,timeStr)+'</td>';  //处理方式列值
     }
     Str_ReviewLog += '</tr>';        
     return Str_ReviewLog;
}
function trimTimeStr(srcStr,timeStr)
{
    k= srcStr.indexOf(timeStr);   
    if (k!=-1) return srcStr.substring(k+timeStr.length)
    else srcStr
}
function setTableStyle(tableObj)
{
        tableObj.cellSpacing=0;
	tableObj.cellPadding=4;
	tableObj.border=1;
	tableObj.align='center';
	tableObj.borderColor='#000000';
        for(i=0;i<tableObj.rows.length;i++)
        {
            for(j=0;j<tableObj.rows[i].cells.length;j++)
            {
                if(tableObj.rows[i].cells[j].innerText=='') tableObj.rows[i].cells[j].innerHTML='&nbsp;';
            }
        }
}



//增加新版流程意见函数
function showFlowLogNew(){
	if(window.S_IsEdited==0 && document.all.Sys_FormatMoney){
          	if(!document.all.Sys_FormatMoney.length)
			optObjFormatMoney(document.all.Sys_FormatMoney);
          	else
          		for(var l=0;l<document.all.Sys_FormatMoney.length;l++)
               			optObjFormatMoney(document.all.Sys_FormatMoney[l]);
     	}
     	if(!document.all.FlowLog_Table)
		return;
     	var j=document.all.FlowLog_Table.length;
     	var systemHTML="" 
     	var Str_TableLog = '<table id=FlowLog_MainTable width=100%  border="0" cellspacing="1" cellpadding="5" bgcolor=#c0c0c0>';
     	//Str_TableLog += '<tr valign="top"><td rowspan=2 width=2% bgcolor="#FFFFFF" noWrap ><a id=moreImg style=\"cursor:hand\" src=\"/lks/koa/images/+.png\" onclick=\"moreInfo();\"><b>详<br>细</b></a></td><td noWrap width=15% bgcolor="#F0F0F0"  ><b>处理人</b></td><td noWrap  width=10% 			bgcolor="#F0F0F0"  ><b>时间</b></td><td   width=73% 			bgcolor="#F0F0F0"  ><b>处理方式</b></td></tr><tr><td colspan=3 width=98% bgcolor="#FFFFFF"  ><b>意见</b></td></tr>'
     	Str_TableLog += '<tr valign="top"><td rowspan=2 width=2% bgcolor="#FFFFFF" noWrap ><a id=moreImg style=\"cursor:hand\" onclick=\"moreInfo();\" ><b>序号<br>&nbsp<img  width=20px height=20px src=\"/lks/koa/images/jiahao.png\"></b></a></td><td noWrap width=15% bgcolor="#F0F0F0"  ><b>处理人</b></td><td noWrap  width=10% 			bgcolor="#F0F0F0"  ><b>时间</b></td><td   width=73% 			bgcolor="#F0F0F0"  ><b>处理方式</b></td></tr><tr><td colspan=3 width=98% bgcolor="#FFFFFF"  ><b>意见</b></td></tr>'
     	var Str_ReviewLog="",str_User,str_Post;
     	var trNode;	
     	if (!j){
          	trNode=document.all.FlowLog_Table;
          	if(document.all.FlowLog_Table.previousSibling.flowlogtable!='1') return;
          	var parentElem = trNode.parentElement;                  
		Str_ReviewLog += printRowHtmlNew(trNode,0);
     	}
     	else {
          	if(document.all.FlowLog_Table[0].previousSibling.flowlogtable!='1')
			return;
          	var parentElem = document.all.nodeNo[0].parentElement;

          	for(var i=0;i<j;i++){
               		trNode=document.all.FlowLog_Table[i]              
               		Str_ReviewLog += printRowHtmlNew(trNode,i);
         	}  
     	}       
     	Str_ReviewLog += "</table>"
     	parentElem.innerHTML=(Str_TableLog+Str_ReviewLog);
     	if (document.all.Td_FlowLogIsPrint)setTableStyle(document.all.FlowLog_MainTable);
     	//审批意见加载完毕
     	isLogLoad =1;
     	if(!document.all.finishMan)
		return;
     	FlowLog_FinishMan=uniqueTrim(FlowLog_FinishMan);
     	if(FlowLog_FinishMan)
		document.all.finishMan.innerHTML=FlowLog_FinishMan.join(";");   
}



function printRowHtmlNew(trNode,i){
	var timeStr="";
     	//提前计算处理方式
     	var tmptype2,tmptype3,tmptypeALL;
     	tmptype2 = "";
     	tmptype3 = "";
     	tmptype2= getTagHTML(trNode,"nodetype");
     	if(tmptype2==''){
     		tmptype2 = trimTimeStr(trNode.outerHTML,tmptype2);
     	}else
		tmptype2 =tmptype2; 
     	trNodeNext=document.all.FlowLog_Table[i+1];
     	if(trNodeNext!=null && trNodeNext!="undefined"){
     		tmptype3= getTagHTML(trNodeNext,"nodetype");
		if(tmptype3=="")
			tmptype3 = '<td  style="display:none" width=0 bgcolor="#F0F0F0">'+trimTimeStr(trNodeNext.outerHTML,"")+'</td>'
		var n2_i,n2_j;
		n2_i = tmptype3.indexOf("‘\"");
		if(n2_i==-1)
			tmptype3="";
		else{
			tmptype3 = tmptype3.substring(n2_i+2,tmptype3.length);
			n2_j = tmptype3.indexOf("\"");
			if(n2_j!=-1){
				tmptype3 = tmptype3.substring(0,n2_j);
			}
        	}
     	} 
	var hideFlag = false;        
     	if(tmptype2.indexOf("通过")!=-1||tmptype2.indexOf("提交时")!=-1||tmptype2.indexOf("解析为空")!=-1 || tmptype2.indexOf("系统")!=-1 || (tmptype2.indexOf("授权")!=-1 && tmptype2.indexOf("阅读")!=-1) )
		//tmptype2='';
		hideFlag = true;
     	if(tmptype3!="")
     		tmptypeALL = tmptype2+"经\""+tmptype3+"\"分支";
     	else
		//if(tmptype2!="")
			tmptypeALL = tmptype2;
        	//else
			//tmptypeALL = "";
     	//提前判断流程意见是不是空的
     	var logStr="";
     	logStr = getTagHTML(trNode,"nodelog");
	str_User = getTagUserAdHTML(trNode,"nodenm",i);

	var isHide = false;
     	//if((logStr=="" && tmptypeALL=="") || (str_User.indexOf("koa_")!=-1) || )
	if(logStr=="" && hideFlag==true || (str_User.indexOf("koa_")!=-1))
		logStr=' style="display:none" ';
     	else
		logStr="";
	
     	var Str_ReviewLog = '<tr '+logStr+' valign="top" nodekey="'+trNode.nodekey+'">';

     	Str_ReviewLog += '<td rowspan=2 width=2% '+logStr+'bgcolor="#FFFFFF">'+(i+1)+'</td>';
     	var tempStr; 
     	timeStr=getTagHTML(trNode,"istime")
     	var tmpI,tmpJ,tmphead,tmpend,va1,va2;
     	tmpI = timeStr.indexOf(">")+1;
     	// tmpJ = timeStr.indexOf("</SPAN>");
 		 tmpJ = timeStr.indexOf("</span>");
     	tmphead = timeStr.substring(0,tmpI);
     	tmpend = timeStr.substring(tmpJ,timeStr.length);
     	timeStr = timeStr.substring(tmpI,tmpJ);
     	//va1 = timeStr.split(" ");
     	//va2 = va1[0].split("-");
     	//timeStr = va2[0].substring(2,4)+"/"+va2[1]+"/"+va2[2]+" "+va1[1];
     	//timeStr = tmphead +timeStr+tmpend;
     	
     	if(str_User=='' && trNode.innerHTML.indexOf(" 系统 ")==-1) str_User =  getTagUserAdHTML(trNode,"userAD",i);   
	//把岗位去掉_ip4
    	var userI,userJ;
    	userI = str_User.indexOf("（");
    	userJ = str_User.lastIndexOf("）");
    	//str_User = str_User.substring(0,userI)+str_User.substring(userJ+1,str_User.length);   
    	userI = str_User.indexOf("(");
    	userJ = str_User.lastIndexOf(")");
    	//str_User = str_User.substring(0,userI)+str_User.substring(userJ+1,str_User.length);
    	Str_ReviewLog += '<td '+logStr+' noWrap width=15% bgcolor="#F0F0F0"style="word-break:break-all;">'+str_User+'</td>';  //处理人列值
	Str_ReviewLog += '<td '+logStr+'   noWrap width=10% bgcolor="#F0F0F0" style="word-break:break-all;">'+timeStr+"</td>"  //处理时间列值
	Str_ReviewLog += '<td '+logStr+'   width=73% bgcolor="#F0F0F0" style="word-break:break-all;">'+tmptypeALL+"</td>"  //处理时间列值
	//计算处理方式
     	if(str_User!=''){	
        	tempStr = getTagHTML(trNode,"nodelog");
          	Str_ReviewLog += '</tr><tr '+logStr+'><td  colspan=3 '+logStr+' width=98% bgcolor="#FFFFFF" style="word-break:break-all;">'+tempStr+'</td>';   //处理意见列值
          	tempStr = getTagHTML(trNode,"nodetype");
     	}else{
          	Str_ReviewLog += '</tr><tr'+logStr+'><td colspan=3 '+logStr+' width=98% bgcolor="#FFFFFF" style="word-break:break-all;">&nbsp;'+'</td>'; //当处理人为空时，处理意见相应的也为空
     	}
     	Str_ReviewLog += '</tr>';        
     	return Str_ReviewLog;
}

function moreInfo(){
	var tableObj = document.getElementById("FlowLog_MainTable");
	var imgObj = document.getElementById("moreImg");
	var htmlStr = imgObj.innerHTML;

	if(htmlStr.indexOf("jian")!=-1)
		imgObj.innerHTML = "<b>序号<br>&nbsp<img width=20px height=20px src=\"/lks/koa/images/jiahao.png\"></b>";
	else
		imgObj.innerHTML = "<b>序号<br>&nbsp<img width=20px height=20px src=\"/lks/koa/images/jianhao.png\"></b>";	
	for(var i=0;i<tableObj.rows.length;i++){

		for(var j=0;j<tableObj.rows[i].cells.length;j++){
			if(tableObj.rows[i].cells[j].style.display=="none"){
				tableObj.rows[i].style.display="";
				tableObj.rows[i].cells[j].style.display="";
				tableObj.rows[i].cells[j].flag="none";

			}else if(tableObj.rows[i].cells[j].flag=="none"){
				tableObj.rows[i].style.display="none";
				tableObj.rows[i].style.border="0";
				tableObj.rows[i].cells[j].style.display="none";
				tableObj.rows[i].cells[j].style.co="0";
				tableObj.rows[i].cells[j].flag="";			
			}	
		}

	}
	
	resizeIframe();
}


//增加新版流程意见函数
function showFlowLogNew2(){
	if(window.S_IsEdited==0 && document.all.Sys_FormatMoney){
          	if(!document.all.Sys_FormatMoney.length)
			optObjFormatMoney(document.all.Sys_FormatMoney);
          	else
          		for(var l=0;l<document.all.Sys_FormatMoney.length;l++)
               			optObjFormatMoney(document.all.Sys_FormatMoney[l]);
     	}
     	if(!document.all.FlowLog_Table)
		return;
     	var j=document.all.FlowLog_Table.length;
     	var systemHTML="" 
     	var Str_TableLog = '<table id=FlowLog_MainTable width=100%  border="0" cellspacing="1" cellpadding="5" bgcolor=#c0c0c0>';
     	//Str_TableLog += '<tr valign="top"><td rowspan=2 width=2% bgcolor="#FFFFFF" noWrap ><a id=moreImg style=\"cursor:hand\" src=\"/lks/koa/images/+.png\" onclick=\"moreInfo();\"><b>详<br>细</b></a></td><td noWrap width=15% bgcolor="#F0F0F0"  ><b>处理人</b></td><td noWrap  width=10% 			bgcolor="#F0F0F0"  ><b>时间</b></td><td   width=73% 			bgcolor="#F0F0F0"  ><b>处理方式</b></td></tr><tr><td colspan=3 width=98% bgcolor="#FFFFFF"  ><b>意见</b></td></tr>'
     	Str_TableLog += '<tr valign="top"><td width=2% bgcolor="#FFFFFF" noWrap ><a id=moreImg style=\"cursor:hand\" onclick=\"moreInfo2();\" ><b><img  width=20px height=20px src=\"/lks/koa/images/jiahao.png\"></b></a>&nbsp</td><td noWrap width=0% bgcolor="#F0F0F0"  ><b>处理时间</b></td><td noWrap  width=0% 			bgcolor="#F0F0F0"  ><b>处理人</b></td><td  width=98% bgcolor="#FFFFFF"  ><b>意见</b></td><td   width=0%  bgcolor="#F0F0F0" nowrap id=dealType  style="display:none" ><b>处理方式</b></td></tr>'
     	var Str_ReviewLog="",str_User,str_Post;
     	var trNode;	
     	if (!j){
          	trNode=document.all.FlowLog_Table;
          	if(document.all.FlowLog_Table.previousSibling.flowlogtable!='1') return;
          	var parentElem = trNode.parentElement;                  
		Str_ReviewLog += printRowHtmlNew2(trNode,0);
     	}
     	else {
          	if(document.all.FlowLog_Table[0].previousSibling.flowlogtable!='1')
			return;
          	var parentElem = document.all.nodeNo[0].parentElement;

          	for(var i=0;i<j;i++){
               		trNode=document.all.FlowLog_Table[i]              
               		Str_ReviewLog += printRowHtmlNew2(trNode,i);
         	}  
     	}       
     	Str_ReviewLog += "</table>"
     	parentElem.innerHTML=(Str_TableLog+Str_ReviewLog);
     	if (document.all.Td_FlowLogIsPrint)setTableStyle(document.all.FlowLog_MainTable);
	
		//灰白相间处理逻辑
		var tableObj = document.getElementById("FlowLog_MainTable");	
		var iflag = 0;
		for(var i=0;i<tableObj.rows.length;i++){
			if(tableObj.rows[i].cells[1].style.display==""){	
				if(iflag%2==0){
					for(var j=0;j<tableObj.rows[i].cells.length;j++)
						tableObj.rows[i].cells[j].style.backgroundColor="#F0F0F0";
				}
				else
					for(var j=0;j<tableObj.rows[i].cells.length;j++)
						tableObj.rows[i].cells[j].style.backgroundColor="#FFFFFF";
				iflag+=1;
			}	
		}
	
     	//审批意见加载完毕
     	isLogLoad =1;
     	if(!document.all.finishMan)
		return;
     	FlowLog_FinishMan=uniqueTrim(FlowLog_FinishMan);
     	if(FlowLog_FinishMan)
		document.all.finishMan.innerHTML=FlowLog_FinishMan.join(";");   
}



function printRowHtmlNew2(trNode,i){
	var timeStr="";
     	//提前计算处理方式
     	var tmptype2,tmptype3,tmptypeALL;
     	tmptype2 = "";
     	tmptype3 = "";
     	tmptype2= getTagHTML(trNode,"nodetype");
     	if(tmptype2==''){
     		tmptype2 = trimTimeStr(trNode.outerHTML,tmptype2);
     	}else
		tmptype2 =tmptype2; 
     	trNodeNext=document.all.FlowLog_Table[i+1];
     	if(trNodeNext!=null && trNodeNext!="undefined"){
     		tmptype3= getTagHTML(trNodeNext,"nodetype");
		if(tmptype3=="")
			tmptype3 = '<td  style="display:none" width=0 bgcolor="#F0F0F0">'+trimTimeStr(trNodeNext.outerHTML,"")+'</td>'
		var n2_i,n2_j;
		n2_i = tmptype3.indexOf("‘\"");
		if(n2_i==-1)
			tmptype3="";
		else{
			tmptype3 = tmptype3.substring(n2_i+2,tmptype3.length);
			n2_j = tmptype3.indexOf("\"");
			if(n2_j!=-1){
				tmptype3 = tmptype3.substring(0,n2_j);
			}
        	}
     	} 
	var hideFlag = false;        
     	if(tmptype2.indexOf("通过")!=-1||tmptype2.indexOf("提交时")!=-1||tmptype2.indexOf("解析为空")!=-1 || (tmptype2.indexOf("系统")!=-1 && (tmptype2.indexOf("系统 抄送")==-1||tmptype2.toLowerCase().indexOf("userad=\"\"")!=-1)) || (tmptype2.indexOf("授权")!=-1 && tmptype2.indexOf("阅读")!=-1) )
		//tmptype2='';
		hideFlag = true;
     	if(tmptype3!="")
     		tmptypeALL = tmptype2+"经\""+tmptype3+"\"分支";
     	else
		//if(tmptype2!="")
			tmptypeALL = tmptype2;
        	//else
			//tmptypeALL = "";
     	//提前判断流程意见是不是空的
     	var logStr="";
     	logStr = getTagHTML(trNode,"nodelog");
	str_User = getTagUserAdHTML(trNode,"nodenm",i);

	var isHide = false;
     	//if((logStr=="" && tmptypeALL=="") || (str_User.indexOf("koa_")!=-1) || )
	if(logStr=="" && hideFlag==true || (str_User.indexOf("koa_")!=-1))
		logStr=' style="display:none" ';
     	else
		logStr="";
	
     	var Str_ReviewLog = '<tr '+logStr+' valign="top" nodekey="'+trNode.getAttribute('nodekey')+'">';

     	Str_ReviewLog += '<td  valign=center width=2% '+logStr+'bgcolor="#FFFFFF">'+(i+1)+'</td>';
     	var tempStr; 
     	timeStr=getTagHTML(trNode,"istime")
     	var tmpI,tmpJ,tmphead,tmpend,va1,va2;
     	tmpI = timeStr.indexOf(">")+1;
     	tmpJ = timeStr.indexOf("</span>");
     	tmphead = timeStr.substring(0,tmpI);
     	tmpend = timeStr.substring(tmpJ,timeStr.length);
     	timeStr = timeStr.substring(tmpI,tmpJ);
     	//va1 = timeStr.split(" ");
     	//va2 = va1[0].split("-");
     	//timeStr = va2[0].substring(2,4)+"-"+("0"+va2[1]).substring(+"/"+va2[2]+" "+va1[1];
		var timeStrFull = timeStr.substring(timeStr.length-2,timeStr.length);
     	timeStr =      	formatTimeStr(timeStr);
     	if(str_User=='' && trNode.innerHTML.indexOf(" 系统 ")==-1) str_User =  getTagUserAdHTML(trNode,"userAD",i);   
	//把岗位去掉_ip4
    	var userI,userJ;
    	userI = str_User.indexOf("（");
    	userJ = str_User.lastIndexOf("）");
		if(userI!=-1){
			var tmpPostStr = str_User.substring(userI,userJ+1).toLowerCase();
			if(tmpPostStr.indexOf(">")!=-1)
				tmpPostStr = tmpPostStr.substring(tmpPostStr.indexOf(">")+1,tmpPostStr.indexOf("</span>"));
			str_User = "*<span title='"+tmpPostStr+"'>" + str_User.substring(0,userI)+"<span id='post_"+i+"' style='display:none' >"+str_User.substring(userI,userJ+1)+"</span>"+str_User.substring(userJ+1,str_User.length)+"</span>";   
		}
			//userI = str_User.indexOf("(");
    	//userJ = str_User.lastIndexOf(")");
    	//str_User = str_User.substring(0,userI)+str_User.substring(userJ+1,str_User.length);
		var tmpbgcolor = "";
		if(i%2==0)
			tmpbgcolor = "#F0F0F0";
		else
			tmpbgcolor = "#FFFFFF";
			
		Str_ReviewLog += '<td '+logStr+'   nowrap valign=center noWrap width=0% bgcolor="'+tmpbgcolor+'" style="word-break:break-all;">'+timeStr+"<span id=timeStrFull_"+i+" style='display:none'>:"+timeStrFull+"</span></td>"  //处理时间列值
    	Str_ReviewLog += '<td '+logStr+'   noWrap  valign=center  width=0% bgcolor="'+tmpbgcolor+'" style="word-break:keep-all;">'+str_User+'</td>';  //处理人列值

	
	//计算处理方式
     	//if(str_User!=''){	
        	tempStr = getTagHTML(trNode,"nodelog");
          	Str_ReviewLog += '<td  '+logStr+' width=98%  valign=center bgcolor="'+tmpbgcolor+'" style="word-break:break-all;">'+tempStr.replace("，并上传了附件","并上传附件")+'<span id=dealType_'+i+' style="color:#6c6c6c">'+getDealTypeSimple(tmptypeALL)+'</span></td>';   //处理意见列值
          	tempStr = getTagHTML(trNode,"nodetype");
     	//}else{
        //  	Str_ReviewLog += '<td  '+logStr+' width=98% bgcolor="'+tmpbgcolor+'" style="word-break:break-all;">&nbsp;'+'<span id=dealType_'+i+' style="color:#6c6c6c"></span></td>'; //当处理人为空时，处理意见相应的也为空
     	//}
		//Str_ReviewLog += '<td '+logStr+'  width=0%   flag=none width=10% bgcolor="'+tmpbgcolor+'" style="word-break:keep-all;color:#6c6c6c">'+getDealTypeSimple(tmptypeALL)+"</td>"  //处理方式列值
		Str_ReviewLog += '<td '+logStr+'  width=0%  id=dealType_'+i+'  width=10% bgcolor="'+tmpbgcolor+'" style="word-break:break-all;display:none">'+tmptypeALL+"</td>"  //处理方式列值
     	Str_ReviewLog += '</tr>';        
     	return Str_ReviewLog;
}

function moreInfo2(){
	var tableObj = document.getElementById("FlowLog_MainTable");
	var imgObj = document.getElementById("moreImg");
	var htmlStr = imgObj.innerHTML;

	if(htmlStr.indexOf("jian")!=-1)
		imgObj.innerHTML = "<b><img width=20px height=20px src=\"/lks/koa/images/jiahao.png\"></b>";
	else
		imgObj.innerHTML = "<b><img width=20px height=20px src=\"/lks/koa/images/jianhao.png\"></b>";	
	
	
	for(var i=0;i<tableObj.rows.length;i++){

		for(var j=0;j<tableObj.rows[i].cells.length;j++){
			if(tableObj.rows[i].cells[j].style.display=="none"){		
				tableObj.rows[i].cells[j].style.display="";
				//if(j!=4){
					tableObj.rows[i].style.display="";
					tableObj.rows[i].cells[j].flag="none";
				//}
			}else if(tableObj.rows[i].cells[j].flag=="none"){
				tableObj.rows[i].cells[j].style.display="none";
				if(j!=4){
					tableObj.rows[i].style.display="none";
					tableObj.rows[i].cells[j].flag="";
				}					
			}	
		}
		hidePost(i);
	}
	//灰白相间处理逻辑
	var iflag = 0;
	for(var i=0;i<tableObj.rows.length;i++){
		try{
			var ifHide = true;
			var timeTmpObj = null;
			if(tableObj.rows[i].cells[2].style.wordBreak == "keep-all"){
				tableObj.rows[i].cells[2].style.wordBreak ="break-all";
				timeTmpObj = document.getElementById("timeStrFull_"+(i-1));
				if(timeTmpObj!=null)
					timeTmpObj.style.display = "";
				timeTmpObj = document.getElementById("dealType_"+(i-1));
				if(timeTmpObj!=null)
					timeTmpObj.style.display = "none";					
				
				tableObj.rows[i].cells[1].style.wordBreak ="keep-all";
				tableObj.rows[i].cells[1].style.width ="8%";
				tableObj.rows[i].cells[2].style.width ="15%";
				tableObj.rows[i].cells[3].style.width ="50%";
				tableObj.rows[i].cells[4].style.width ="25%";
				ifHide=false;
			}
			else if(tableObj.rows[i].cells[2].style.wordBreak == "break-all"){
				tableObj.rows[i].cells[2].style.wordBreak ="keep-all";
				timeTmpObj = document.getElementById("timeStrFull_"+(i-1));
				if(timeTmpObj!=null)
					timeTmpObj.style.display = "none";
				timeTmpObj = document.getElementById("dealType_"+(i-1));
				if(timeTmpObj!=null)
					timeTmpObj.style.display = "";
				tableObj.rows[i].cells[1].style.wordBreak ="keep-all";					
				tableObj.rows[i].cells[1].style.width ="8%";
				tableObj.rows[i].cells[2].style.width ="0%";
				tableObj.rows[i].cells[3].style.width ="98%";
				tableObj.rows[i].cells[4].style.width ="0%";
				ifHide = true;
			}
			if(ifHide){
				tableObj.rows[0].cells[1].style.wordBreak ="keep-all";
				tableObj.rows[0].cells[2].style.wordBreak ="keep-all";
				tableObj.rows[0].cells[1].style.width ="8%";
				tableObj.rows[0].cells[2].style.width ="0%";
				tableObj.rows[0].cells[3].style.width ="98%";
				tableObj.rows[0].cells[4].style.width ="0%";
			}else{
				tableObj.rows[0].cells[1].style.wordBreak ="keep-all";
				tableObj.rows[0].cells[2].style.wordBreak ="keep-all";
				tableObj.rows[0].cells[1].style.width ="8%";
				tableObj.rows[0].cells[2].style.width ="15%";
				tableObj.rows[0].cells[3].style.width ="50%";
				tableObj.rows[0].cells[4].style.width ="25%";
			}
		}catch(e){
		}
		if(tableObj.rows[i].cells[1].style.display==""){
			if(iflag%2==0){
				for(var j=0;j<tableObj.rows[i].cells.length;j++)
					tableObj.rows[i].cells[j].style.backgroundColor="#F0F0F0";
			}
			else
				for(var j=0;j<tableObj.rows[i].cells.length;j++)
					tableObj.rows[i].cells[j].style.backgroundColor="#FFFFFF";
			iflag+=1;
		}
	}
	
	
	resizeIframe();
}

//显示与隐藏岗位
function hidePost(i){
	var tmpObj = document.getElementById("post_"+i);
	var tmpObj2 = document.getElementById("postClick_"+i);
	
	if(tmpObj!=null)
		if(tmpObj.style.display=="none"){
			tmpObj.style.display = "";
		}
		else{
			tmpObj.style.display = "none";
		}
}

//获取简版的处理方式
function getDealTypeSimple(dt){
var i,j,tmpStr;

console.log('getDealTypeSimple',dt)

	if(dt.indexOf("回复")!=-1 && dt.indexOf("内部沟通")!=-1){
		i = dt.indexOf("回复");
		j = dt.indexOf("内部沟通");
		tmpStr = dt.substring(i+3,j-1);
		i = tmpStr.indexOf(">");
		tmpStr = tmpStr.substring(i+1,tmpStr.length);		
		return "[回复"+tmpStr+"]";
	}

	if(dt.indexOf("结束")!=-1 && dt.indexOf("内部沟通")!=-1 )
		
		return "[结束沟通]";

	if(dt.indexOf("对")!=-1 && dt.indexOf("发起")!=-1 && dt.indexOf("内部沟通")!=-1 ){
		i = dt.indexOf("对");
		j = dt.indexOf("发起");
		tmpStr = dt.substring(i+1,j);
		return "[沟通"+tmpStr+"]";
	}


	if(dt.indexOf("转办")!=-1 && dt.indexOf("处理给")!=-1){
		i = dt.indexOf("处理给");
		tmpStr = dt.substring(i+4,dt.length);
		i = tmpStr.indexOf(">");
		tmpStr = tmpStr.substring(i+1,tmpStr.length);
		i = tmpStr.indexOf("<");
		tmpStr = tmpStr.substring(0,i);
		return "[转办"+tmpStr+"]";
	}

	if(dt.indexOf("呈送")!=-1 && dt.indexOf("给")!=-1){
		i = dt.indexOf("给");
		tmpStr = dt.substring(i+1,dt.length);
		i = tmpStr.indexOf(">");
		tmpStr = tmpStr.substring(i+1,tmpStr.length);
		i = tmpStr.indexOf("<");
		tmpStr = tmpStr.substring(0,i);
		return "[呈送"+tmpStr+"]";
	}




	if(dt.indexOf("授权")!=-1){
		i = dt.indexOf("授权");
		j = dt.indexOf("处理");
		tmpStr = dt.substring(i+2,j);
		i = tmpStr.indexOf("\">");
		tmpStr = tmpStr.substring(i+2,tmpStr.length);	
		i = tmpStr.indexOf("<");
		tmpStr = tmpStr.substring(0,i);	
		return "[授权"+tmpStr+"]";
	}

	if(dt.indexOf("抄送")!=-1){
		if(dt.indexOf("系统 抄送")!=-1){
			i = dt.indexOf("</B>");
			tmpStr = dt.substring(i+5,dt.length);	
		}else {
			i = dt.indexOf("抄送");
			tmpStr = dt.substring(i-7,dt.length);
		}
		var reList = "";
		var tt = "";
		while(true){
			i = tmpStr.indexOf(">");
			if(i==-1)
				break;
			tmpStr = tmpStr.substring(i+1,tmpStr.length);
			i = tmpStr.indexOf("<");
			tt = tmpStr.substring(i);
			tmpStr = tmpStr.substring(0,i);
			if(reList=="")
				reList = tmpStr;
			else
				reList +=tmpStr;
			tmpStr = tt;
		}
		reList = reList.replace(/;/g,"、")
		if(reList.length>40){
			var ix = reList.indexOf("、",40);
			if(ix>=40){
				reList = reList.substr(0,ix)+"......";
			}
		}
		if(dt.indexOf("系统 抄送")!=-1){
			reList = "抄送："+reList;
		}
		return "["+reList+"]";
	}
	
	

	if(dt.indexOf("附加意见")!=-1)
		return "[附加]";

	if(dt.indexOf("驳回")!=-1)
		return "[驳回]";

	if(dt.indexOf("修改")!=-1)
		return "[修改]";

	if(dt.indexOf("跳转")!=-1)
		return "[跳转]";
	if(dt.indexOf("跳过")!=-1)
		return "[跳过]";


	if(dt.indexOf("提交")!=-1 )
		return "[提交]";
		
	if(dt.indexOf("撤回")!=-1 )
		return "[撤回]";
		
	if(dt.indexOf("废弃")!=-1 )
		return "[废弃]";


	return "";
}

//时间格式化 原格式2014-9-11 17:2:8或者2014/9/11 17:2:8这种类型 格式化为2014-09-11 17:02:08
function formatTimeStr(timeStr){
	va1 = timeStr.split(" ");
    	va2 = va1[0].split("-");
	try{
		if(va2.length==1){
			va2 = va1[0].split("/");
		}
		if(va2[1].length==1)
			va2[1] = "0"+va2[1];
		if(va2[2].length==1)
			va2[2] = "0"+va2[2];
	
		va3 = va1[1].split(":");
		if(va3[0].length==1)
			va3[0] = "0"+va3[0];
		if(va3[1].length==1)
			va3[1] = "0"+va3[1];
		//if(va3[2].length==1)
		//va3[2] = "0"+va3[2];
		
		return va2[0]+"-"+va2[1]+"-"+va2[2]+" "+va3[0]+":"+va3[1] ; //+":"+va3[2];
	}catch(e){
		return timeStr;
	}
}