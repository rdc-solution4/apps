/*压缩类型：完全*/
/********************************************************************
功能：流程图部分功能在kOA系统上的具体实现
使用：
	作为流程图的扩展部分，在父窗口中指定，并由flowchart_panel.js引入
实现：
	流程图预留接口的以下函数
		FlowChartObject.DrawFlow
		FlowChartObject.CheckFlow_Extend
		FlowChart_Node_ShowAttribute
		FlowChart_Line_ShowAttribute
作者：叶中奇
创建时间：2005-06-01
修改记录：
	2005-06-16：完成了kOA流程配置的扩充功能
	2006-10-30: Wulx 增加节点限制到50个
********************************************************************/

//====================::::::::::常量/公用函数::::::::::====================
//审批类型代码与含义对应表
var FlowTypeList = new Array;
FlowTypeList["10"] = "审批:串行";
FlowTypeList["11"] = "审批:并行";
FlowTypeList["12"] = "审批:会审";
FlowTypeList["20"] = "签字:串行";
FlowTypeList["21"] = "签字:并行";
FlowTypeList["22"] = "签字:会签";
FlowTypeList["30"] = "抄送";

//刷新节点node的显示样式
function FlowChart_KOA_RefreshNodeView(node)
{
	var rename;
	if(node.Type=="start")
		rename="";
	else
	{
		rename = node.Data.F_ReviewerName;
		if(rename=="")
			rename="<添加处理人>";
		else
		{
			//if(rename.length>28)
				//rename=rename.substring(0,28)+"...";
		}
	}
	node.SetText(node.Data.F_NodeName);
	node.SetReviewer(rename);
	node.SetParsedByInfo();	//2015-03	
	if(node.Type=="start")
		node.SetImage("flowstart_1.gif");
	else
		node.SetImage("review_"+node.Data.F_ReviewType+"_1.gif");
	var title ="";
	if (node.Data.F_SubFlowDef!=null && node.Data.F_SubFlowDef!="")
	{
		node.SetSubFlow(node.Data.F_SubFlowDef);
		title = "节点名："+node.Data.F_NodeName;
		title += "<br>节点信息：并发流程节点";
	}else{
		title = "节点名："+node.Data.F_NodeName;
		title += "<br>节点信息：普通流程节点";
		title += "<br>处理人："+node.Data.F_ReviewerName;
		title += "<br>处理方式："+node.Data.F_ReviewTypeNm;
	}
	node.SetTitle(title);
	node.SetReviewerAd(node.Data.F_Reviewer);
}

//====================::::::::::初始化调用函数::::::::::====================
//根据文档信息展现流程
FlowChartObject.DrawFlow = function ()
{
	/****************************************************************
	表格位置（n）和FlowChartObject.Nodes.all索引（m）的对应关系说明：
	注意到：
		FlowChartObject.Nodes.all[0]为起始节点
		FlowChartObject.Nodes.all[1]为结束节点
		以后依次创建的节点的索引值为2,3,4……
	而创建节点的顺序是按照表格的顺序创建的，也就是说
		表格第1行对应的节点为FlowChartObject.Nodes.all[2]，
		表格第2行对应的节点为FlowChartObject.Nodes.all[3]……
	结论：表格位置（n）+1=FlowChartObject.Nodes.all索引（m）
	****************************************************************/
	//删除原有的节点
	for(; FlowChartObject.Nodes.all.length>2; )
		FlowChartObject.Nodes.all[2].Delete(true);
	FlowChartObject.Current.SelectElement(null, true, true);
	FlowChartObject.Nodes.Index = 0;
	
	//设置开始、结束节点图片
	FlowChartObject.Nodes.Start.SetImage("flowstart_1.gif");
	FlowChartObject.Nodes.Start.SetFunction("ChgAttribute", false);
	FlowChartObject.Nodes.End.SetImage("flowend_1.gif");
	FlowChartObject.Nodes.End.SetFunction("ChgAttribute", false);
	
	//若原表格设置的节点个数为0，不初始化数据
	var nodesLen = parent.document.all.F_ReviewAmount.value;
	if(nodesLen==0){
		FlowChartObject.Nodes.Start.CanLinkStart=false;
		FlowChartObject.Nodes.Start.CanLinkEnd=true;
		return;
	}
	
	var i, j, index, node;
	var posHadSet = true;					//位置信息是否完整
	var jumpCon;							//跳转条件
	
	//==========遍历所有节点，创建节点对象，获取节点信息，判断节点位置是否完整==========
	/******************************************************************************************
	node.Data.clientXXX信息说明：
	流程正式的信息均以node.Data.F_XXX形式出现，一般的，F_XXX就是表单中的域名
	以下的值为表格→图形切换时所用的临时数据
	rowIndex
		节点所处图形界面的“行”，第一行的值为0（为开始节点）
	colIndex
		节点所处图形界面的“列”，第一列的值为0
	parentNode
		若节点A处于第2行，节点B处于第3行，并且节点B为节点A的下一节点，则节点B的parentNode为节点A
		该变量主要在根据上一个节点判断下一个节点的位置时使用
	jumpInfo
		（二维数组）节点的跳转信息
		jumpInfo[i][0]：跳转信息的文本；若无跳转条件则取空值
		jumpInfo[i][1]：跳转位置（表格的位置）；
						若无跳转条件则取跳转节点（node.Data.F_JumpNode）的值；
						若无跳转节点则取下一节点的位置
						若为最后节点，则取0（注意到0+1=1刚好是结束节点的索引位置，符合前面规则）
		样例：
			原数据（node.Data.F_JumpCondition的值）：
				金额<=5000 #2
				金额>5000 #4
			保存数据：
				jumpInfo[0][0] = "金额<=5000"
				jumpInfo[0][1] = 2
				jumpInfo[1][0] = "金额>5000"
				jumpInfo[1][1] = 4
	******************************************************************************************/
	//开始节点的下一个节点为表格中的第一个节点
	FlowChartObject.Nodes.Start.Data.jumpInfo = new Array(new Array("", 1));
	//读取开始和结束节点的F_NodePosition信息
	FlowChartObject.Nodes.Start.Data.F_NodePosition = parent.document.all.F_NodePosition_Start.value;
	FlowChartObject.Nodes.End.Data.F_NodePosition = parent.document.all.F_NodePosition_End.value;
	if(FlowChartObject.Nodes.Start.Data.F_NodePosition=="" || FlowChartObject.Nodes.End.Data.F_NodePosition=="")
		posHadSet = false;
	//读取其它节点的信息
	//for(i=1; i<=nodesLen; i++)	//fengy
	for(i=0; i<=nodesLen; i++)
	{
		if(i==0)
			node = FlowChartObject.Nodes.Start;
		else
			node = new FlowChart_Node();
		//原kOA流程的节点信息
		for(j=0; j<parent.arrField.length; j++)
			eval("node.Data."+parent.arrField[j]+"=parent.document.all."+parent.arrField[j]+"_"+i+".value;");
		node.Data.F_ReviewTypeNm = FlowTypeList[node.Data.F_ReviewType];
		//node.CanParse = true;
		if(!flowIsEdit||i==0)
		{
			node.CanLinkStart = false;
			node.CanLinkEnd = false;
		}
		
		node.Data.index = i;		//WULX
		node.Data.rowIndex = 1;
		node.Data.colIndex = 0;
		node.Data.parentNode = null;
		if(i==0)
		{
			node.Data.F_NodeName="开始";
			node.Data.F_NodeKey="0";
		}else
		{
			if(parent.isAllow)
			{
				node.EditProperty="1";
				node.SetProImage("editnode.gif");
			}else if(parent.S_IsEdited=="1" && parent.getOption(node.Data.index,0) =="1")
			{
				node.EditProperty="2";
				node.SetProImage("editreviewer.gif");
				node.CanParse = false;
			}
		}	
		
		node.Data.jumpInfo = new Array;

		if(node.Data.F_JumpCondition!="")
		{
			jumpCon = node.Data.F_JumpCondition.split("\r\n");
			for(j=0; j<jumpCon.length; j++)
			{
				index = jumpCon[j].indexOf(" #");
				//Wulx node.Data.jumpInfo[j] = new Array(jumpCon[j].substring(0, index), parseInt(jumpCon[j].substring(index+2)));
				node.Data.jumpInfo[j] = new Array(jumpCon[j].substring(0, index),  jumpCon[j].substring(index+2).toLowerCase()=="end"?0:parseInt(jumpCon[j].substring(index+2)));
			}
		}else
		{
			node.Data.jumpInfo[0] = new Array(
				"",
				node.Data.F_JumpNode==""?
					(i==nodesLen?0:i+1):
					(node.Data.F_JumpNode.toLowerCase()=="end"?0:parseInt(node.Data.F_JumpNode))
			);
		}
		//更新节点显示样式
		FlowChart_KOA_RefreshNodeView(node);
		//记录节点位置是否完整
		if(posHadSet && node.Data.F_NodePosition=="")
			posHadSet = false;
	}
	
	//==========调整节点位置并创建相应的连线==========
	if(posHadSet)	//原保存的节点位置信息是完整的，根据节点位置信息调整节点位置
		FlowChart_KOA_INI_DrawView();
	else			//原保存的节点位置信息没有或可能被修改过，重新生成节点位置信息
		FlowChart_KOA_INI_RebuildView();
	parent.resizeChartSize();
	
	parent.IsShowFlowChart = true;
}

//根据原有的位置信息画流程图
function FlowChart_KOA_INI_DrawView()
{
	var i, j, node, position;
	for(i=0; i<FlowChartObject.Nodes.all.length; i++)
	{
		node = FlowChartObject.Nodes.all[i];
		/**********************************************************************
		F_NodePosition的信息格式：
			x,y;连线1起始位置,连线1结束位置;连线2起始位置,连线2结束位置;……
			其中连线为该节点引出的连线
		**********************************************************************/
		position = node.Data.F_NodePosition.split(";");
		for(j=0; j<position.length; j++)
			position[j] = position[j].split(",");
		node.MoveTo(parseInt(position[0][0]), parseInt(position[0][1]));
		if(node.Type!="end")
			FlowChart_KOA_INI_AddLine(node, position);
	}
}

/**************************************************************************************************
功能：将表格信息翻译成流程图
实现思路：
	1、遍历所有节点，将下一个节点所处界面行位置（rowIndex）置为上一节点之后
		注意判断若有些节点可能会往前跳转，这种情况不能做上述处理
	2、节点所处界面的行号已经确定，创建节点间的连线
	3、根据行号，从上到下调整节点显示的位置。节点的x坐标根据上一节点确定先后，并作居中处理
**************************************************************************************************/
function FlowChart_KOA_INI_RebuildView()
{
	var i, j, index, node, nextNode;
	//====================获取每个节点的rowIndex====================
	//注意：下面的循环并未处理最后一个节点
	for(i=1; i<FlowChartObject.Nodes.all.length-2; i++)
	{
		//注意：表格位置（n）和FlowChartObject.Nodes.all索引（m）的对应关系
		node = FlowChartObject.Nodes.all[i+1];
		for(j=0; j<node.Data.jumpInfo.length; j++)
		{
			//node2为当前节点将要跳转到的节点
			nextNode = FlowChartObject.Nodes.all[node.Data.jumpInfo[j][1]+1];
			if(nextNode.Data.rowIndex<=node.Data.rowIndex)
			{
				//node2位置在node前面，可能需要调整
				if(i>node.Data.jumpInfo[j][1])
				{
				/******************************************************************************
				node节点往前面的节点node2跳转，检查node2的跳转信息
				若node2的所有跳转都跳转到node后，说明node2应该放在node的后面
				但若调整了node2的位置，则node2后面节点的位置可能就需要重新调整，所以将i重置
				******************************************************************************/
					for(index = 0; index<nextNode.Data.jumpInfo.length; index++)
						if(i>=nextNode.Data.jumpInfo[index][1])
							break;
					if(index==nextNode.Data.jumpInfo.length)
					{
						//把node2放在node的上面，记录parentNode是为了同一行的节点排序，返回前面的节点运行
						nextNode.Data.parentNode = node;
						nextNode.Data.rowIndex = node.Data.rowIndex + 1;
						i = node.Data.jumpInfo[j][1]-1;
						break;
					}
				}else
				{
					//把node2放在node的上面，记录parentNode是为了同一行的节点排序
					nextNode.Data.parentNode = node;
					nextNode.Data.rowIndex = node.Data.rowIndex + 1;
				}
			}
		}
	}
	FlowChartObject.Nodes.Start.Data.rowIndex = 0;
	FlowChartObject.Nodes.End.Data.rowIndex = FlowChartObject.Nodes.all[FlowChartObject.Nodes.all.length-1].Data.rowIndex+1;
	
	/******************************************************************************************
	为了方便计算，下面函数将节点的位置保存在一个二维数组rows中
	若rows[i][j]==node，说明node这个节点出现在流程图的第i+1行第j+1列
	rows[i][j]的位置将在后面的函数中根据上一个节点的位置再次排序
	在遍历的过程，将连线接上
	******************************************************************************************/
	FlowChart_KOA_INI_AddLine(FlowChartObject.Nodes.Start);
	var rows = new Array();
	for(i=2; i<FlowChartObject.Nodes.all.length; i++)
	{
		node = FlowChartObject.Nodes.all[i];
		FlowChart_KOA_INI_AddLine(node);
		j = node.Data.rowIndex;
		if(rows[j]==null)
			rows[j] = new Array;
		rows[j][rows[j].length] = node;
	}
	
	//====================移动节点位置====================
	var dx = 40;			//节点列间隔
	var dy = 40;			//节点行间隔
	//移动开始/结束节点位置
	var x = Math.round((document.body.clientWidth-node.GetWidth())/2);
	FlowChartObject.Nodes.Start.MoveTo(x, 20, true);
	FlowChartObject.Nodes.End.MoveTo(x, 120, true);
	var y = FlowChartObject.Nodes.Start.Top+FlowChartObject.Nodes.Start.GetHeight()+dy;
	//由于rowIndex==0的节点是起始节点，所以rows[0]==null，所以下面的循环从1开始
	for(i=1; i<rows.length; i++)
	{
		//起始坐标=(界面的宽度-所有节点的宽度-节点中间间隙的宽度)/2
		x = Math.round((document.body.clientWidth-rows[i].length*rows[i][0].GetWidth()-(rows[i].length-1)*dx)/2);
		//根据上一节点的位置排序
		rows[i].sort(FlowChart_KOA_INI_SortPosition);
		for(j=0; j<rows[i].length; j++)
		{
			//设置当前节点的位置，为后面的排序使用
			rows[i][j].Data.colIndex = j;
			rows[i][j].MoveTo(x, y, true);
			x = rows[i][j].Left+rows[i][j].GetWidth()+dx;
		}
		y = rows[i][0].Top+rows[i][0].GetHeight()+dy;
	}
	//移动结束节点位置
	FlowChartObject.Nodes.End.MoveTo(null, y, true);
}

/**********************************************************
功能：排序函数
返回值：
	>0：node2排在node1后面
	=0：不改变顺序
	<0：node1排在node2后面
**********************************************************/
function FlowChart_KOA_INI_SortPosition(node1, node2)
{
	if(node1.Data.parentNode==null)
		return 1;
	if(node2.Data.parentNode==null)
		return -1;
	return node1.Data.parentNode.Data.colIndex - node2.Data.parentNode.Data.colIndex;
}

/**********************************************************
功能：创建node1的连线
参数：
	node1：引出连线的节点
	position：二维数组（n>0）
		position[0][0]：节点x坐标
		position[0][1]：节点y坐标
		position[n][0]：节点引出的第n条连线的起点位置
		position[n][1]：节点引出的第n条连线的终点位置
**********************************************************/
function FlowChart_KOA_INI_AddLine(node1, position)
{
	var line, node2;
	for(var i=0; i<node1.Data.jumpInfo.length; i++)
	{
		node2 = FlowChartObject.Nodes.all[node1.Data.jumpInfo[i][1]+1];
		line = new FlowChart_Line;
		if(position==null || position[i+1]==null)
		{
			if(node2.Data.rowIndex<node1.Data.rowIndex)
			{
				//node1处于node2之下
				line.SetStartPoint("link", node1, "NodeTop");
				line.SetEndPoint("link", node2, "NodeBottom");
			}else
			{
				//node1处于node2之上
				line.SetStartPoint("link", node1, "NodeBottom");
				line.SetEndPoint("link", node2, "NodeTop");
			}
		}else
		{	
			if(position[i+1][1]==0){   //指向节点号为0,表示指向结束节点,见FlowChartObject.DrawFlow()中jumpInfo[][]的说明
				line.SetStartPoint("link", node1, position[i+1][0]);
				line.SetEndPoint("link", FlowChartObject.Nodes.End, "NodeTop");
			}else{
				line.SetStartPoint("link", node1, position[i+1][0]);
				line.SetEndPoint("link", node2, position[i+1][1]);
			}
		}
		//lih20081105加上对开始节点的处理不允许删除节点下的分支和节点
		if(node1.Data.index==0){
			line.CanDelete=false;
			line.CanChgStart = false;				//是否可以修改起点
			line.CanChgEnd = false;					//是否可以修改终点
			node2.CanDelete=false;
		}
		line.SetText(node1.Data.jumpInfo[i][0]);
	}
}
//节点中选择处理人，弹出地址本对话框	fengy
function FlowChart_Node_ShowAddress()
{
    with (parent.document.forms[0])
    {
       	var r=this.Data.index;
  		var upgmc=eval("F_ReviewType_"+r).value;
  		//2015-05 AddressBook1("ad:name","F_Reviewer_" + r +":F_ReviewerName_" + r,true,(upgmc=="30" ? "UPGM" : "PM"),true);
  		AddressBook1("ad:name","F_Reviewer_" + r +":F_ReviewerName_" + r,true,(upgmc=="30" ? "UPGM" : "UPGM"),true);
 		if (!checkUserNum(this.Data,eval("F_Reviewer_"+this.Data.index).value,eval("F_ReviewerName_"+this.Data.index).value,eval("F_NodeKey_"+r).value,eval("F_ReviewType_"+r).value)){ return false;	}	//2015-04 modify		
  		this.Data.F_Reviewer = eval("F_Reviewer_"+this.Data.index).value;
        this.Data.F_ReviewerName = eval("F_ReviewerName_"+this.Data.index).value;
		var rename = this.Data.F_ReviewerName;
		if(rename=="")
			rename="<添加处理人>";
		else
		{
			if(rename.length>25)
				rename=rename.substring(0,25)+"...";
		}
   		this.SetReviewer(rename);
    	this.SetReviewerAd(this.Data.F_Reviewer);
    }
}
function checkUserNum(recObj,ads,nas,nodeKey,nType) {
//2015-04 modify
//检查节点审批人数量是不是超过限制
//ads:选择后的AD
//nas:选择后的NAMES
	try{
		if(recObj.F_Reviewer!=ads){
			var agent="Ag_CheckUserNum?openagent&ads="+escape(ads);
			var hasKey=false;
			for(var i = 1;i<50;i++){
				if(eval("parent.document.forms[0].F_ParsedBy_"+i).value==nodeKey) {
				//有需求重新解析的内容
					hasKey = true;
					break;
				}
			}
			var id = parent.location.href;
			if(hasKey){	
				if(id.toLowerCase().indexOf(".nsf/0/")!=-1){ //create
					id = id.substring(0,id.indexOf("?"));
					id = id.replace(/.+\//ig,"");
				}else{ //review
					id = id.replace(/.+&ParentUNID=/ig,"").replace(/&.*/ig,"");
				}
				agent="Ag_CheckUserNum?openagent&ads="+escape(ads)+"&nas="+escape(nas)+"&nkey="+nodeKey+"&ty="+nType+"&id="+id;
			}
			
			var xml=new ActiveXObject("MSXML.DOMDocument");
			xml.async=false;
			var path=parent.location.href.substring(0,parent.location.href.indexOf(".nsf")+4);;
			xml.load(path+"/"+agent);
			var nodes=xml.selectNodes("ReturnMsg/ReturnCode");
			var result=nodes[0].text;
			if(result=="0"){
				alert("节点处理人数超过了限制,请检查;");
				return false;
			}else{
				if(hasKey){
					nodes=xml.selectNodes("ReturnMsg/ReturnKeys");
					recObj.Key_Ref=nodes[0].text;
					nodes=xml.selectNodes("ReturnMsg/ReturnAds");
					recObj.Reviewer_Ref=nodes[0].text;
					nodes=xml.selectNodes("ReturnMsg/ReturnNames");
					recObj.ReviewerNames_Ref=nodes[0].text;
					setParseNodes(recObj);		//2015-04
				}
			}
		}
		return true;
	}catch(e){}
	return true;
}
//====================::::::::::过程调用函数::::::::::====================
//替换原有的设置节点属性的函数
function FlowChart_Node_ShowAttribute()
{
	if(this.CanChgAttribute)
	{
		var recObj = new Object;
		var i, fresh;
		//注意：当recObj.F_JumpCondition==null时不显示跳转条件框，F_JumpNode同
		if(this.Data.F_Reviewer==null)
		{
			//节点信息未设置，初始化节点信息
			for(i=0; i<parent.arrField.length; i++)
				switch(parent.arrField[i])
				{
					case "F_JumpCondition":
					case "F_JumpNode":
					break;
					default:
						eval("recObj."+parent.arrField[i]+"='';");
				}
			recObj.F_NodeName = this.Text;
			fresh = "true";
		}else
		{
			//节点信息曾经设置，获取节点信息
			for(i=0; i<parent.arrField.length; i++)
				switch(parent.arrField[i])
				{
					case "F_JumpCondition":
					case "F_JumpNode":
					break;
					default:
						eval("recObj."+parent.arrField[i]+"=this.Data."+parent.arrField[i]+";");
	
				}
			fresh = "false";
		}
		/**********************************************************************
		parent.editDialogInfo：数组
			[0]：对话框的路径
			[1]：对话框风格
			[2]：谁打开的这个对话框
		**********************************************************************/
		if(this.Data.F_NodeKey==null)this.Data.F_NodeKey=this.Key;		//取NodeKey  fengy
		var iKey=this.Data.F_NodeKey;
		recObj.Key=this.Data.F_NodeKey;
		//gw 2015-03 add---
		//if(this.Data.F_ReviewType!=null){
			if(this.Data.F_NodeName==null)this.Data.F_NodeName=this.Text;
			recObj.ParsedByArr=FlowChart_KOA_CheckFlow_CkRoute(this.Data.F_NodeName,this.Data.F_NodeKey);
		//}
		//gw end-----------
		//recObj.ChangeReviewer= (parent.getOption(FlowChartObject.Nodes.Index,0) =="1" && parent.isEdited)?"1":"0";
        recObj.resWin = window.parent;
		recObj.ChangeReviewer= (parent.getOption(this.Data.index,0) =="1" && parent.isEdited)?"1":"0";	
		recObj.F_ReviewNo = parent.document.forms[0].F_ReviewNo?parent.document.forms[0].F_ReviewNo.value:"";
		recObj.F_IsAllowEdit=parent.isAllow;
		recObj.index = this.Data.index;
		recObj.whoOpen = parent.editDialogInfo[2];
		recObj = window.showModalDialog(parent.editDialogInfo[0] + "&fresh=" + fresh, recObj, parent.editDialogInfo[1]);
		if(recObj!=null)
		{
			//数据回写，注意返回值的审批类型为F_ReviewTypeAd
			this.Data = recObj;
			this.Data.F_NodeKey = iKey;
			this.Data.F_ReviewType = this.Data.F_ReviewTypeAd;
			FlowChart_KOA_RefreshNodeView(this);
			this.SetParsedByInfo(recObj);	//2015-04 modify
			setParseNodes(recObj);		//2015-04
			tempObj=eval("parent.document.forms[0].F_Reviewer_" + this.NodeNum);
			tempObj.value=this.ReviewerAd;
			tempObj=eval("parent.document.forms[0].F_ReviewerName_" + this.NodeNum);
			tempObj.value=this.Reviewer;
			//FlowChartObject.SaveFlow();
		}
	}
}

//替换原有的设置连线属性的函数
function FlowChart_Line_ShowAttribute()
{
	if(this.CanChgAttribute && this.StartPoint.Node.LineStart.length>1)
	{
		var style = "dialogWidth:500px; dialogHeight:235px; status:0;scroll:0; help:0";
		this.resWin = window.parent;
		this.S_DbUrl=parent.S_DbUrl;
		this.S_MainDbUrl=top.S_DbUrl;
		if(this.CanDelete)
			this.CanChanged = true;
		else
			this.CanChanged = false;
		var rtnVal = showModalDialog(S_ResourcePath+"html/lineattrib.html",this, style);
		if(rtnVal!=null){
			this.SetText(rtnVal);
			FlowChart_Line_SetJumpType(this.StartPoint.Node);
		}
	}
}

//流程检查的扩展函数
FlowChartObject.CheckFlow_Extend = function ()
{
	var i, j, node;
	//没有除起始和结束的其它节点，返回true
	if(FlowChartObject.Nodes.all.length==2)
		return true;
	//检查开始节点和结束节点的连接个数
	if(FlowChartObject.Nodes.Start.LineStart.length>1)
	{
		FlowChartObject.Current.SelectElement(null, true, true);
		for(i=0; i<FlowChartObject.Nodes.Start.LineStart.length; i++)
			FlowChartObject.Current.SelectElement(FlowChartObject.Nodes.Start.LineStart[i], false, true);
		//fengy alert("起始节点连线不能多于一个！");
		//fengy return false;
	}
	if(FlowChartObject.Nodes.End.LineEnd.length>1)
	{
		FlowChartObject.Current.SelectElement(null, true, true);
		for(i=0; i<FlowChartObject.Nodes.End.LineEnd.length; i++)
			FlowChartObject.Current.SelectElement(FlowChartObject.Nodes.End.LineEnd[i], false, true);
		//WULX alert("结束节点连线不能多于一个！");
		//WULXreturn false;
	}
	//检查节点个数
	if(FlowChartObject.Nodes.all.length>50)
	{
		alert("流程节点数不能超过50个！");
		return false;
	}
	var allarr = new Array;				//检查循环时经过的所有节点
	//检查是否出现循环
	if(!FlowChart_KOA_CheckFlow_Cyc(FlowChartObject.Nodes.Start, new Array, allarr)){
		if(parent.document.all.F_RecycleFlow) parent.document.all.F_RecycleFlow.value="1";
	}else{
		if(parent.document.all.F_RecycleFlow) parent.document.all.F_RecycleFlow.value="0";//return false;
	}
	for(i=0; i<FlowChartObject.Nodes.all.length; i++)
	{
		node = FlowChartObject.Nodes.all[i];
		if(node.Data.F_NodeName == null)
		{
			node.Data.F_NodeName = node.Text;
			node.Data.F_Reviewer = "";
			node.Data.F_ReviewerName = "";
      		node.Data.F_Option = "0;0;0;0;0;0;0;0;0;0;0;0000";
      		node.Data.F_NodeSetting = "1:通过;2:驳回;3:转办;5:沟通;8:废弃";
      		node.Data.F_ReviewType = "10";
      		node.Data.F_NodeKey=node.Key;
      		node.Data.F_BakReviewer = "";
      		node.Data.F_BakReviewerName = "";
      		node.Data.F_FunList= "";
      		node.Data.F_RevField="";
		}
		
		//allarr[i]=node;		//fengy0317
		//检查节点信息是否有配置
		//if(node.Data.F_Reviewer==null && node.CanChgAttribute)
		/*if(node.Data.F_Reviewer==null && node.CanChgAttribute && node.Key!=="start")
		{
			FlowChartObject.Current.SelectElement(node, true, true);
			alert("节点信息必需配置！");
			return false;
		}*/
		//检查孤立节点
		/*if(allarr.indexOf(node)==-1)
		{
			FlowChartObject.Current.SelectElement(node, true, true);
			alert("存在无法到达的节点！");
			return false;
		}*/
		//检查分支是否有设置跳转条件
		if(node.LineStart.length>1)
			for(j=0; j<node.LineStart.length; j++)
				if(node.LineStart[j].Text=="")
				{
					FlowChartObject.Current.SelectElement(node.LineStart[j], true, true);
					alert("分支连线必需设置跳转条件！");
					return false;
				}
	}
	return true;
}

/**********************************************************
功能：检查流程循环点
参数：
	node：检查起始点
	arr：当前检查的路线经过的节点列表
	allarr：曾经被检查过的节点
**********************************************************/
function FlowChart_KOA_CheckFlow_Cyc(node, arr, allarr)
{
	var i, j;
	allarr[allarr.length] = node;
	//终止节点不需要检查
	if(node.Type=="end")
		return true;
	i = arr.indexOf(node);
	if(i!=-1)
	{
		//选中循环的节点和连线
		FlowChartObject.Current.SelectElement(null, true, true);
		for(; i<arr.length; i++)
		{
			FlowChartObject.Current.SelectElement(arr[i], false, true);
			//寻找循环连线
			for(j=0; j<node.LineEnd.length; j++)
			{
				if(i==arr.length-1)
				{
					//根据前面的判断，arr最后的节点应该有流入node中的连线
					if(arr[i].LineStart[j].EndPoint.Node==node)
						break;
				}else
				{
					if(arr[i].LineStart[j].EndPoint.Node==arr[i+1])
						break;
				}
			}
			FlowChartObject.Current.SelectElement(arr[i].LineStart[j], false, true);
		}
		//alert("出现循环节点！");
		return false;
	}
	//检查的节点通过，记录检查路线
	arr[arr.length] = node;
	j = arr.length;
	for(i=0; i<node.LineStart.length; i++)
	{
		//注意到检查分支节点的时候，数组arr会被增长，清空后面的数据
		if(j!=arr.length)
			arr = arr.slice(0, j);
		if(!FlowChart_KOA_CheckFlow_Cyc(node.LineStart[i].EndPoint.Node, arr, allarr))
			return false;
	}
	return true;
}

//====================::::::::::提交调用函数::::::::::====================
var FlowChart_KOA_GridRow;			//全局变量，图形流程节点在表格显示的行号
var FlowChart_KOA_HasGoneNode;		//全局变量,存储节点位置信息
/******************************************************************************
功能：检查流程配置是否合理，并将流程信息写入到表单的域中
返回：
	true：成功写入
	false：写入失败
******************************************************************************/
FlowChartObject.SaveFlow= function()
{
	if(!FlowChartObject.HadInited)
		return true;
	var i, j, node;
	
	//设置节点个数
	parent.document.all.F_ReviewAmount.value = FlowChartObject.Nodes.all.length - 2;
	
	//没有节点，直接返回
	if(FlowChartObject.Nodes.all.length==2)
		return true;
	
	//检测流程配置是否合理
	if(!FlowChartObject.CheckFlow(true))
		return false;
	
		//清空多余的域信息
	//for(i=1; i<=50; i++)	//fengy
	for(i=0; i<=50; i++)
		for(j=0; j<parent.arrField.length; j++)
			// eval("parent.document.all."+parent.arrField[j]+"_"+i+".value='';");
      parent.document.getElementsByName(parent.arrField[j]+"_"+i).value=';';

	//初始化
	FlowChart_KOA_GridRow = 0;
	FlowChart_KOA_HasGoneNode=new Array;
	//for(i=2; i<FlowChartObject.Nodes.all.length; i++)
	for(i=0; i<FlowChartObject.Nodes.all.length; i++)
	{
		if(i!=1)
		{
			node = FlowChartObject.Nodes.all[i];
			node.Data.rowIndex = 0;
			node.Data.colIndex = 0;
		}
		//node.Data.rowIndex = i-1;
	}
	
	//设置节点所处于表格的行号
	FlowChart_KOA_Save_SetGridRow(FlowChartObject.Nodes.Start.LineStart[0].StartPoint.Node);
	
	//整理节点信息写入表单的域中
	var nextNode;			//下一节点
	//for(i=2; i<FlowChartObject.Nodes.all.length; i++)
	for(i=0; i<FlowChartObject.Nodes.all.length; i++)
	{
		if(i!=1)		//fengy
		{
		node = FlowChartObject.Nodes.all[i];
		//整理节点Data对象中F_JumpCondition、F_JumpNode、F_NodePosition的信息
		/**********************************************************************
		F_NodePosition的信息格式：
			x,y;连线1起始位置,连线1结束位置;连线2起始位置,连线2结束位置;……
			其中连线为该节点引出的连线
		**********************************************************************/
		node.Data.F_NodePosition = node.Left + "," + node.Top + ";";
		if(node.LineStart.length==1)
		{
			nextNode = node.LineStart[0].EndPoint.Node;
			node.Data.F_JumpCondition = "";			
			//若下一个节点为结束点或下一个节点的行号为当前节点行号+1，则不需跳转
			//node.Data.F_JumpNode = (nextNode.Type=="end" || node.Data.rowIndex+1==nextNode.Data.rowIndex)?"":nextNode.Data.rowIndex;
			if(nextNode.Type=="end"){			//连线指向结束节点
				//if(node.Data.rowIndex!=(FlowChartObject.Nodes.all.length-2)){		//当前节点不是最后一个节点,则"跳转到节点"为"end"
					node.Data.F_JumpNode = "end";
				//}else{																//当前节点是最后一个节点,则"跳转到节点"为空
				//	node.Data.F_JumpNode ="";
				//}			
			}else{        						//连线指向非结束节点,指向当前节点下一节点,则"跳转到节点"为空,否则"跳转到节点"为nextNode.Data.rowIndex
				node.Data.F_JumpNode = nextNode.Data.rowIndex;//(node.Data.rowIndex+1==nextNode.Data.rowIndex)?"":nextNode.Data.rowIndex;
			}
			node.Data.F_NodePosition += node.LineStart[0].StartPoint.Position+","+node.LineStart[0].EndPoint.Position;
		}else
		{
			node.Data.F_JumpCondition = "";
			//node.Data.F_JumpNode = "";
			for(j=0; j<node.LineStart.length; j++)
			{
				nextNode = node.LineStart[j].EndPoint.Node;
				var jumpCon ;
				if(nextNode.Type=="end" || isNaN(parseInt(nextNode.Data.rowIndex)) || parseInt(nextNode.Data.rowIndex)==(FlowChartObject.Nodes.all.length-1)){
					jumpCon = "end";
				} else{
					jumpCon = nextNode.Data.rowIndex;
				}
				node.Data.F_JumpCondition += "\r\n" + node.LineStart[j].Text + " #" + jumpCon;
				node.Data.F_NodePosition += node.LineStart[j].StartPoint.Position+","+node.LineStart[j].EndPoint.Position+";";
			}
			//去除F_JumpCondition起始的\r\n和F_NodePosition结束的;号
			node.Data.F_JumpCondition = node.Data.F_JumpCondition.substring(2);
			node.Data.F_NodePosition = node.Data.F_NodePosition.substring(0, node.Data.F_NodePosition.length-1);
		}
		//将节点相关信息写入文档域中
		for(j=0; j<parent.arrField.length; j++)
			eval("parent.document.all."+parent.arrField[j]+"_"+node.Data.rowIndex+".value = node.Data."+parent.arrField[j]+";");
			//if(parent.arrField[j].indexOf("F_Reviewer")!=-1 || parent.arrField[j].indexOf("F_NodePosition")!=-1) {eval("parent.document.all."+parent.arrField[j]+"_"+node.Data.rowIndex+".value = node.Data."+parent.arrField[j]+";");}  //仅写回位置信息和修改处理人
		}
	}
	//写入开始和结束节点的F_NodePosition信息
	node = FlowChartObject.Nodes.Start;
	node.Data.F_NodePosition = node.Left+","+node.Top+";"+node.LineStart[0].StartPoint.Position+","+node.LineStart[0].EndPoint.Position;
	parent.document.all.F_NodePosition_Start.value = node.Data.F_NodePosition;
	node = FlowChartObject.Nodes.End;
	node.Data.F_NodePosition = node.Left+","+node.Top;
	parent.document.all.F_NodePosition_End.value = node.Data.F_NodePosition;
	
	return true;
}

//获取node节点的在表格界面中的行号，并保存到node.Data.rowIndex中
function FlowChart_KOA_Save_SetGridRow(node)
{
	//不处理结束节点
	if(node.Type=="end")
		return;
	/**********************************************************************************************
	node.Data.colInde为节点曾处理过的流入次数
	若节点的处理过的流入次数<节点总共可流入的次数，说明该节点在后面处理过程中仍会碰到，将处理过程
	留待最后流入再处理。
	**********************************************************************************************/
	node.Data.colIndex++;
	//if(node.LineEnd.length>node.Data.colIndex)
	//	return;
		FlowChart_KOA_HasGoneNode.push(node.Top+":"+node.Left);
	//设置节点在表格界面中出现的行号
	if(node.Type=="start")
		node.Data.rowIndex = 0;
	else
	{
		FlowChart_KOA_GridRow++;
		node.Data.rowIndex = FlowChart_KOA_GridRow;
	}
	
	//处理后续节点
	for(var i=0; i<node.LineStart.length; i++)
		if(FlowChart_KOA_Check_GoneNodeByPosition(node.LineStart[i].EndPoint.Node))
			FlowChart_KOA_Save_SetGridRow(node.LineStart[i].EndPoint.Node);
}

//根据节点位置判断是否对该节点做过处理
function FlowChart_KOA_Check_GoneNodeByPosition(node){
	if(FlowChart_KOA_HasGoneNode==null || FlowChart_KOA_HasGoneNode.length==0) return true;
	var tmpPositionStr=node.Top+":"+node.Left;
	if(FlowChart_KOA_HasGoneNode.toString().indexOf(tmpPositionStr)!=-1)
		return false;
	return true;
}
/**********************************************************
 2015-04
功能：检查流程路径
参数：
	nodeName:	指定节点的节点名
	nodeKey:	指定节点的节点Key
**********************************************************/
function FlowChart_KOA_CheckFlow_CkRoute(nodeName,nodeKey)
{
// 2015-04
//取得所有节点的接入节点(包含该节点本身),以"#@#"分隔;节点Key和节点名以"|"分隔;
	try{
		var node1;
		var node2;
		var rtnStr="";		
		for(var i=2; i<FlowChartObject.Nodes.all.length; i++){
			node1 = FlowChartObject.Nodes.all[i];
			var rtnStr1="";
			if(node1.Type!="start" && node1.Type!="end"){
				if(node1.Data.F_NodeKey==null){
					rtnStr1=node1.Key;					
				}else{
					rtnStr1=node1.Data.F_NodeKey;
				}
				if(node1.Data.F_NodeName==null){
					rtnStr1=rtnStr1+"|"+node1.Text+";";
				}else{
					rtnStr1=rtnStr1+"|"+node1.Data.F_NodeName+";";
				}
			}else{
				rtnStr1=";";
			}
			for(var j=0; j<node1.LineEnd.length; j++)
			{
				node2=node1.LineEnd[j].StartPoint.Node;
				var rtnStr2="";
				if(node2.Type!="start" && node2.Type!="end"){
					if(node2.Data.F_NodeKey==null){
						rtnStr2=node2.Key;					
					}else{
						rtnStr2=node2.Data.F_NodeKey;
					}
					if(node2.Data.F_NodeName==null){
						rtnStr2=rtnStr2+"|"+node2.Text+";";
					}else{
						rtnStr2=rtnStr2+"|"+node2.Data.F_NodeName+";";
					}
					rtnStr1 = rtnStr2+";"+rtnStr1;
				}
			}
			rtnStr = rtnStr+"#@#"+rtnStr1;
		}
		rtnArr = s_getRoute(rtnStr,nodeKey,nodeName);
		//alert(rtnArr);
		return rtnArr;
	}catch(e){
		return "";
	}
}
function s_getRoute(allKeys,nodeKey,nodeName){
// 2015-04
//1.检查选定的节点(nodeKey),是否有接入点节;有的话,接入点节信息加入到返回数组中;
//2.循环向前取,直到取得所有当前节点连入接点的连入接点
	var tmpArrAll;
	var tmpArrPart;
	var tmpArrC;
	var rtnArr=new Array();
	if(allKeys.length>0){
		tmpArrAll = allKeys.split("#@#");
	}else{
		return "";
	}
	//1.取当前节点的连入接点
	rtnArr = s_getOneRoute(tmpArrAll,rtnArr,nodeKey+"|"+nodeName,nodeKey+"|"+nodeName);
	//2.取当前节点的连入接点的连入接点
	tmpArrC = rtnArr;
	if(rtnArr.length>0){
		for(var i=0;i<tmpArrC.length;i++){
			rtnArr = s_getOneRoute(tmpArrAll,rtnArr,tmpArrC[i],nodeKey+"|"+nodeName);
		}
	}
	//2.循环向前取,直到取得所有当前节点连入接点的连入接点
	for(;tmpArrC.length<rtnArr.length;){
		tmpArrC = rtnArr;
		for(var i=0;i<tmpArrC.length;i++){
			rtnArr = s_getOneRoute(tmpArrAll,rtnArr,tmpArrC[i],nodeKey+"|"+nodeName);
		}
	}
	return rtnArr;
}
function s_getOneRoute(tmpArrAll,chkRouteArr,chkKey,specifiedKey){
// 2015-04
//检查chkKey节点,是否有接入点节;有的话,接入点节信息加入到chkRouteArr数组中;
	var tmpStr="";
	var tmpArr=new Array();
	for(var i=0;i<tmpArrAll.length;i++){
		tmpArrPart=Array_unique1(tmpArrAll[i].split(";"));
		if(tmpArrPart.length>1 && tmpArrPart[tmpArrPart.length-1]==chkKey){	
			for(var j=0;j<tmpArrPart.length-1;j++){
				//有循环节点时,排除自己
				if(tmpArrPart[j]!=specifiedKey){	
					tmpArr[tmpArr.length]= tmpArrPart[j];
				}
			}
		}
	}
	if(tmpArr.length>0){
		for(var i=0;i<tmpArr.length;i++){
			if(tmpArr[i]!=""){
				chkRouteArr[chkRouteArr.length]=tmpArr[i];
			}
		}
	}
	chkRouteArr = Array_unique1(chkRouteArr);
	return chkRouteArr;
}

/**********************************************************
 2015-03-26
功能：数组去重去空
参数：
**********************************************************/
function Array_unique1(arr) {
    var result = [], hash = {};
    for (var i = 0, elem; (elem = arr[i]) != null; i++) {
        if (!hash[elem] && arr[i]!="") {
            result.push(elem);
            hash[elem] = true;
        }
    }
    return result;
}
/**********************************************************
 2015-04
功能：修改基准节点人员时,重置关联节点人员为解析的结果
参数：recObj:基准节点obj
**********************************************************/
function setParseNodes(recObj){

	if(recObj.Key_Ref==null)return;
	if(recObj.Reviewer_Ref==null)return;
	if(recObj.ReviewerNames_Ref==null)return;
	
	var keys_Ref;
	var ads_Ref;
	var names_Ref;
	var tempObj;
	var node1;
	var node2;
	keys_Ref = recObj.Key_Ref.split("|");
	ads_Ref = recObj.Reviewer_Ref.split("|");
	names_Ref = recObj.ReviewerNames_Ref.split("|");

	for(var i=2; i<FlowChartObject.Nodes.all.length; i++){
		node1 = FlowChartObject.Nodes.all[i];
		for(var j=0; j<keys_Ref.length; j++){
			if(node1.Data.F_NodeKey==keys_Ref[j]){
				node1.Data.F_Reviewer=ads_Ref[j];
				node1.Data.F_ReviewerName=names_Ref[j];
				FlowChart_KOA_RefreshNodeView(node1);
				tempObj=eval("parent.document.forms[0].F_Reviewer_" + node1.NodeNum);
				tempObj.value=node1.Data.F_Reviewer;
				tempObj=eval("parent.document.forms[0].F_ReviewerName_" + node1.NodeNum);
				tempObj.value=node1.Data.F_ReviewerName;
			}
		}
	}
	return true;
}