/*压缩类型：完全*/
/****************************************************************************************
功能：流程图连线对象定义
使用：
	作为流程图组件的一部分，由flowchart_panel.js自动引入
需要扩展的功能：
	修改连线属性（FlowChart_Line_ShowAttribute）
	对象属性Data的值修改
作者：叶中奇
创建时间：2005-06-01
修改记录：
	2005-06-07：完成主要功能
****************************************************************************************/

//====================::::::::::流程图连线全局对象::::::::::====================

FlowChartObject.Lines = new Object;				//全局连线对象
FlowChartObject.Lines.all = new Array;			//连线索引
FlowChartObject.Lines.OptLine = null;			//操作连线

//连线初始化操作，创建操作线
FlowChartObject.Lines.Initialize = function()
{
	if(FlowChartObject.IsEdited)
	{
		FlowChartObject.Lines.OptLine = new FlowChart_Line("optline");
		FlowChartObject.Lines.OptLine.Hide();
	}
};

//====================::::::::::流程图连线对象::::::::::====================
function FlowChart_Line(LineType, LineText)
{
	//==========属性==========
	this.Name = "Line";									//对象名称
	this.Type = LineType?LineType:"normal";				//类型：normal（普通）；optline（操作线）
	this.Text = LineText?LineText:"";					//连线文本
	this.title = "";									//显示文本
	//this.jumpType = "";								//决策类型: "0"手动决策;"1"公式自动决策
	this.formula = "";									//自动决策公式条件
	this.IsSelected = false;							//是否被选中
	this.CanDelete = parent.isAllow==1?true:false;								//是否可以被删除  fengy 审批中可修改流程
	if(flowIsEdit)
	{
		this.CanChgStart = true; //true;					//是否可以修改起点
		this.CanChgEnd = true; //true;						//是否可以修改终点
	}else
	{
		this.CanChgStart = false; //true;					//是否可以修改起点
		this.CanChgEnd = false; //true;						//是否可以修改终点
	}
	
	this.CanChgAttribute = true; //true;				//是否可以修改属性
	this.CanParse = false;								//是否可以拷贝粘贴	fengy
	//==========子对象==========
	this.Data = null;									//连线数据，用于扩充
	this.DOMText!=null;								//显示文本的HTML对象
	this.StartPoint = new Object;						//起始点
	this.StartPoint.Node = null;						//连接的流程节点
	this.StartPoint.Position = "";						//连接的位置
	this.StartPoint.TempX = 0;							//移动时的临时坐标x
	this.StartPoint.TempY = 0;							//移动时的临时坐标y
	this.EndPoint = new Object;						//结束点
	this.EndPoint.Node = null;
	this.EndPoint.Position = "";
	this.EndPoint.TempX = 0;
	this.EndPoint.TempY = 0;
	
	//==========方法==========
	this.SetText = FlowChart_Line_SetText;				//设置文本
	this.SetFunction = FlowChart_Line_SetFunction;		//设置功能
	this.Select = FlowChart_Line_Select;				//选中连线
	this.GetPointXY = FlowChart_Line_GetPointXY;		//获取操作点的位置
	this.SetStartPoint = FlowChart_Line_SetStartPoint;	//设置起始点
	this.SetEndPoint = FlowChart_Line_SetEndPoint;		//设置结束点
	this.Refresh = FlowChart_Line_Refresh;				//刷新显示
	this.ShowAttribute = FlowChart_Line_ShowAttribute;	//显示属性
	this.Show = FlowChart_Line_Show;					//显示连线
	this.Hide = FlowChart_Line_Hide;					//隐藏连线
	this.Delete = FlowChart_Line_Delete;				//删除连线
    this.desc="";
	//==========初始化==========
	var htmlCode = "<v:polyline id=LineElements class=flowline_"+this.Type+" filled=false style='position:absolute;top:0;left:0'/>";
	var newElem = document.createElement(htmlCode);
	newElem.innerHTML = "<v:stroke StartArrow=Diamond EndArrow=Classic />";
	if(this.Type!="normal")
		newElem.innerHTML += "<v:stroke dashstyle=LongDash />";
	document.body.appendChild(newElem);
	this.DOMElement = newElem;
	newElem.LKSObject = this;
	this.SetText();
	if(this.Type=="normal")
		FlowChartObject.Lines.all[FlowChartObject.Lines.all.length] = this;
}

//====================::::::::::流程图连线函数::::::::::====================

//设置文本，若不传参数，则采用当前值
function FlowChart_Line_SetText(LineText)
{
	if(LineText!=null){
		this.Text = LineText;
		this.title = FlowChart_Line_GetValue(this.Text,"title");
		this.desc=FlowChart_Line_GetValue(this.Text,"desc");
		this.formula = FlowChart_Line_GetValue(this.Text,"formula");
		this.StartPoint.Node.jumpType = FlowChart_Line_GetValue(this.Text,"jumpType");
	}
	if(this.Text=="")
	{
		if(this.DOMText!=null)
			this.DOMText.style.display = "none";
	}else
	{
		if(this.DOMText==null)
		{
			//若用于显示连线文本的DOM对象未创建，则创建
			var htmlCode = "<table class=flowlinetext_tb style='position:absolute;' />";
			var newElem = document.createElement(htmlCode);
			this.DOMText = newElem;
			newElem.LKSObject = this;
			newElem.insertRow(-1).insertCell(-1);
			newElem.rows[0].cells[0].className = "flowlinetext_td";
			document.body.appendChild(newElem);
		}
		this.DOMText.style.display = "";
		this.DOMText.rows[0].cells[0].innerText = this.title;
		this.Refresh();
	}
}

/***********************************************************************************
功能：设置功能权限
参数：
	funcName：节点对象中以"Can"开头的属性，如："Delete"表示设置节点"CanDelete"属性
	value：true或false，为空则不修改原有属性
***********************************************************************************/
function FlowChart_Line_SetFunction(funcName, value)
{
	if(eval("this.Can"+funcName)==null)
		throw "参数设置无效";
	else
		if(value!=null)
			eval("this.Can"+funcName+"=value;");
}

/************************************************************
功能：选中连线
参数：
	selType：true（选中）；false（不选中）；null（反向选中）
************************************************************/
function FlowChart_Line_Select(selType)
{
	this.IsSelected = (selType==null)?!this.IsSelected:selType;
	this.DOMElement.StrokeColor = (this.IsSelected)?"#FF0000":"#000000";
}

/**********************************************************
功能：获取操作点的位置
参数：
	position：位置，值为：LineStart、LineEnd
**********************************************************/
function FlowChart_Line_GetPointXY(position)
{
	switch(position)
	{
		case "LineStart":
		if(this.StartPoint.Node==null)
			return new Array(this.StartPoint.TempX, this.StartPoint.TempY);
		else
			return this.StartPoint.Node.GetPointXY(this.StartPoint.Position);
			
		case "LineEnd":
		if(this.EndPoint.Node==null)
			return new Array(this.EndPoint.TempX, this.EndPoint.TempY);
		else
			return this.EndPoint.Node.GetPointXY(this.EndPoint.Position);
	}
}

/**********************************************************
功能：设置起始点
参数：
	linkType="xy"（表示未与流程节点连接）
		x：坐标x
		y：坐标y
	linkType="link"（表示与流程节点连接）
		x：流程节点对象
		y：连接位置
**********************************************************/
function FlowChart_Line_SetStartPoint(linkType, x, y)
{
	if(this.StartPoint.Node!=null)
		this.StartPoint.Node.DelLineStart(this);
	if(linkType=="link")
	{
		this.StartPoint.Node = x;
		this.StartPoint.Position = y;
		if(this.Type=="normal")
			x.AddLineStart(this);
	}else
	{
		this.StartPoint.Node = null;
		this.StartPoint.Position = "";
		this.StartPoint.TempX = x;
		this.StartPoint.TempY = y;
	}
	this.Refresh();
}

//设置结束点，参数同设置起始点
function FlowChart_Line_SetEndPoint(linkType, x, y)
{
	if(this.EndPoint.Node!=null)
		this.EndPoint.Node.DelLineEnd(this);
	if(linkType=="link")
	{
		this.EndPoint.Node = x;
		this.EndPoint.Position = y;
		if(this.Type=="normal")
			x.AddLineEnd(this);
	}else
	{
		this.EndPoint.Node = null;
		this.EndPoint.Position = "";
		this.EndPoint.TempX = x;
		this.EndPoint.TempY = y;
	}
	this.Refresh();
}

//刷新显示
function FlowChart_Line_Refresh()
{
	var p1 = this.GetPointXY("LineStart");
	var p2 = this.GetPointXY("LineEnd");
	//若连线设置了文本信息，则在连线中间显示文本
	if(this.Text!="")
	{
		//若连线与水平线小于45°，文本显示在直线上方，否则文本显示在直线右方。
		if(Math.abs(p1[0]-p2[0])>Math.abs(p1[1]-p2[1]))
		{
			this.DOMText.style.left = (p1[0]+p2[0]-this.DOMText.clientWidth)/2;
			this.DOMText.style.top = (p1[1]+p2[1])/2-this.DOMText.clientHeight;
		}else
		{
			this.DOMText.style.left = (p1[0]+p2[0])/2;
			this.DOMText.style.top = (p1[1]+p2[1]-this.DOMText.clientHeight)/2;
		}
	}
	//调整连线位置
  
  
  // 这里报错重新调整处理
	// this.DOMElement.points.value = p1[0]+","+p1[1]+" "+p2[0]+","+p2[1];
  this.DOMElement.setAttribute('points',p1[0]+","+p1[1]+" "+p2[0]+","+p2[1]);
}

//显示属性，该功能一般由其他的JS编写替换代码
function FlowChart_Line_ShowAttribute()
{
	if(this.CanChgAttribute)
		alert("显示线段属性："+this.Text);
}

//显示连线
function FlowChart_Line_Show()
{
	this.DOMElement.style.display = "";
	if(this.Text!="")
		this.DOMText.style.display = "";
}

//隐藏连线
function FlowChart_Line_Hide()
{
	this.DOMElement.style.display = "none";
	if(this.DOMText!=null)
		this.DOMText.style.display = "none";
}

/**********************************************************
功能：删除连线
参数：
	force：true（强制删除），false（默认）
**********************************************************/
function FlowChart_Line_Delete(force)
{
	if(!force && !this.CanDelete)
		return;
	//解除相关的链接
	this.StartPoint.Node.DelLineStart(this);
	this.EndPoint.Node.DelLineEnd(this);
	FlowChartObject.Lines.all = FlowChartObject.Lines.all.removeElem(this);
	//删除HTML对象
	if(this.DOMText!=null)
		this.DOMText.removeNode(true);
	this.DOMElement.removeNode(true);
}
function FlowChart_Line_GetValue(strIn,varName){
	try{
	var rtn = "";
	var str = strIn;
	var tmpName = "&"+varName+"=";
	if (str.indexOf(tmpName)==-1) return rtn;
	var tmp = str.substring(str.indexOf(tmpName)+2+varName.length,str.length);
	if (tmp == "") return tmp;
	if (tmp.indexOf("&")==-1){
		rtn = tmp;
	}else{
		rtn = tmp.substring(0,tmp.indexOf("&"));
	}
	rtn = rtn.replace(/%3D/ig,"&");
	return rtn;
	}catch(e){
	}
}
function FlowChart_Line_SetJumpType(node){
	var tmpName="&jumpType=";
	var tmpValue="";
	if(node.LineStart.length>1)
		for(j=0; j<node.LineStart.length; j++)
		if(node.LineStart[j].Text!=""){
			tmpValue = FlowChart_Line_GetValue(node.LineStart[j].Text,"jumpType");
			if(tmpValue!=""){
				var reg = new RegExp(tmpName+tmpValue,"i"); 
				node.LineStart[j].Text = node.LineStart[j].Text.replace(reg,tmpName+node.jumpType);
				//alert(node.LineStart[j].Text);
			}
		}
}
