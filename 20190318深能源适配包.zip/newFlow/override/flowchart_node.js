/*压缩类型：完全*/
/**********************************************************
功能：流程图节点对象定义
使用：
	作为流程图组件的一部分，由flowchart_panel.js自动引入
需要扩展的功能：
	修改节点属性（FlowChart_Node_ShowAttribute）
	对象属性Data的值修改
作者：叶中奇
创建时间：2005-06-01
修改记录：
	2005-06-07：完成主要的功能
**********************************************************/
IncludeJsFile("person.js");

//====================::::::::::流程图节点全局对象::::::::::====================

FlowChartObject.Nodes = new Object;
FlowChartObject.Nodes.all = new Array;				//节点索引
FlowChartObject.Nodes.Index;						//节点流水号
FlowChartObject.Nodes.Start = null;					//起始节点
FlowChartObject.Nodes.End = null;					//终止节点
FlowChartObject.Nodes.Image = "review_10_1.gif";	//默认图片
FlowChartObject.Nodes.ProImage = "proimage.gif";	//默认图片

FlowChartObject.Nodes.jumpType = "";				//决策类型: "0"手动决策;"1"公式自动决策

//新建节点，并移动到当前光标下
FlowChartObject.Nodes.New = function()
{
	var newNode = new FlowChart_Node();
	var xx = event.clientX + document.body.scrollLeft - newNode.GetWidth()/2;
	var yy = event.clientY + document.body.scrollTop - newNode.GetHeight()/2;
	newNode.MoveTo(xx, yy, true);
	newNode.Key=""+(parseInt(parent.document.all.F_NodeKeyNum.value)+1);
	eval("parent.document.all.F_NodeKeyNum.value='"+newNode.Key+"';");	//节点关健字+1
	return newNode;
};

FlowChartObject.Nodes.InfoBox = new Object;			//详细信息框
FlowChartObject.Nodes.InfoBox.Visible = false;		//详细信息框是否可见
FlowChartObject.Nodes.InfoBox.DOMElement = null;	//详细信息框的DOM对象

//显示详细信息框，由图片点击事件触发
FlowChartObject.Nodes.InfoBox.ShowInfo = function()
{
	//this指图片的input标签对象
	var DOMObj = FlowChartObject.Nodes.InfoBox.DOMElement;
	if(this.LKSObject.Title=="" || this.LKSObject.Type=="start")
	{
		DOMObj.style.display = "none";
		FlowChartObject.Nodes.InfoBox.Visible = false;
	}else
	{
		FlowChartObject.Nodes.ReviewInfoBox.Hide();
		DOMObj.rows[0].cells[0].innerHTML = "节点信息：<br>"+this.LKSObject.Title+"<br>节点编号："+this.LKSObject.Data.F_NodeKey;
		DOMObj.style.display = "";
		//将信息框显示在当前节点的旁边，并不让显示框超出边界
		var x = this.LKSObject.DOMElement.clientWidth;
		if(this.LKSObject.Left+x+4+DOMObj.clientWidth>document.body.clientWidth+document.body.scrollLeft)
			DOMObj.style.left = this.LKSObject.Left-DOMObj.clientWidth-4;
		else
			DOMObj.style.left = this.LKSObject.Left+x+4;
		if(this.LKSObject.Top+DOMObj.clientHeight>document.body.clientHeight+document.body.scrollTop)
			DOMObj.style.top = this.LKSObject.Top+this.LKSObject.DOMElement.clientHeight-DOMObj.clientHeight;
		else
			DOMObj.style.top = this.LKSObject.Top;
		FlowChartObject.Nodes.InfoBox.Visible = true;
	}
};

//隐藏详细信息框
FlowChartObject.Nodes.InfoBox.Hide = function()
{
	if(FlowChartObject.Nodes.InfoBox.Visible && event.srcElement.id!="NodeImages")
	{
		FlowChartObject.Nodes.InfoBox.DOMElement.style.display = "none";
		FlowChartObject.Nodes.InfoBox.Visible = false;
	}
};

//显示审批结果详细信息框，由节点点击事件触发
FlowChartObject.Nodes.InfoBox.ShowLogInfo = function()
{
	//this指图片的input标签对象
	var DOMObj = FlowChartObject.Nodes.InfoBox.DOMElement;
			if(this.LKSObject.LogInfo=="" || this.LKSObject.LogInfo=="节点审批记录：<br>")
	{
		DOMObj.style.display = "none";
		FlowChartObject.Nodes.InfoBox.Visible = false;
	}else{
		FlowChartObject.Nodes.ReviewInfoBox.Hide();
		DOMObj.rows[0].cells[0].innerHTML = this.LKSObject.LogInfo;
		DOMObj.style.display = "";
		//将信息框显示在当前节点的旁边，并不让显示框超出边界
		var x = this.LKSObject.DOMElement.clientWidth;
		if(this.LKSObject.Left+x+4+DOMObj.clientWidth>document.body.clientWidth+document.body.scrollLeft)
			DOMObj.style.left = this.LKSObject.Left-DOMObj.clientWidth-4;
		else
			DOMObj.style.left = this.LKSObject.Left+x+4;
		if(this.LKSObject.Top+DOMObj.clientHeight>document.body.clientHeight+document.body.scrollTop)
			DOMObj.style.top = this.LKSObject.Top+this.LKSObject.DOMElement.clientHeight-DOMObj.clientHeight;
		else
			DOMObj.style.top = this.LKSObject.Top;
		FlowChartObject.Nodes.InfoBox.Visible = true;
	}
};

FlowChartObject.Nodes.ReviewInfoBox = new Object;			//处理人信息框
FlowChartObject.Nodes.ReviewInfoBox.Visible = false;		//处理人信息框是否可见
FlowChartObject.Nodes.ReviewInfoBox.DOMElement = null;		//处理人信息框的DOM对象

//显示节点处理人信息，由处理人点击事件触发
FlowChartObject.Nodes.ReviewInfoBox.ShowInfo = function()
{
	//this指图片的input标签对象
	var DOMObj = FlowChartObject.Nodes.ReviewInfoBox.DOMElement;
	if(this.LKSObject.ReviewerAd=="" || this.LKSObject.Type=="start" ||FlowChartObject.Nodes.ReviewInfoBox.Visible)
	{
		DOMObj.style.display = "none";
		FlowChartObject.Nodes.ReviewInfoBox.Visible = false;
	}else
	{
		DOMObj.rows[0].cells[0].innerHTML = AddressGetGroupList(this.LKSObject.ReviewerAd);
		if(DOMObj.rows[0].cells[0].innerText.length > 30)
			DOMObj.rows[0].cells[0].width=280;
		else
			DOMObj.rows[0].cells[0].removeAttribute("width");
		DOMObj.style.display = "";
		//将信息框显示在当前节点的旁边，并不让显示框超出边界
		var x = this.LKSObject.DOMElement.clientWidth;
		if(this.LKSObject.Left+x+4+DOMObj.clientWidth>document.body.clientWidth+document.body.scrollLeft)
			DOMObj.style.left = this.LKSObject.Left-DOMObj.clientWidth-4;
		else
			DOMObj.style.left = this.LKSObject.Left+x+4;
		if(this.LKSObject.Top+DOMObj.clientHeight>document.body.clientHeight+document.body.scrollTop)
			DOMObj.style.top = this.LKSObject.Top+this.LKSObject.DOMElement.clientHeight-DOMObj.clientHeight;
		else
			DOMObj.style.top = this.LKSObject.Top+this.LKSObject.DOMElement.clientHeight-DOMObj.clientHeight-4;
		FlowChartObject.Nodes.ReviewInfoBox.Visible = true;
	}
};
//隐藏处理人详细信息框
FlowChartObject.Nodes.ReviewInfoBox.Hide = function()
{
	if(FlowChartObject.Nodes.ReviewInfoBox.Visible)
	{
		FlowChartObject.Nodes.ReviewInfoBox.DOMElement.style.display = "none";
		FlowChartObject.Nodes.ReviewInfoBox.Visible = false;
	}
};
//显示节点属性
function ShowProperty(NodeProperty)
{
  debugger;
	//this指图片的input标签对象
	var obj = FlowChartObject.Event.GetLKSObject();
	if(obj!=null)
	{
		if(this.LKSObject.EditProperty=="1")
			obj.ShowAttribute();
		else if(this.LKSObject.EditProperty=="2")
			obj.ShowAddress();
	}
}
//节点初始化操作，创建详细显示框的HTML对象，创建开始和结束节点
FlowChartObject.Nodes.Initialize = function()
{
	var htmlCode = "<table class=flownodeinfo_tb style='position:absolute; display:none' />";
	var newElem = document.createElement(htmlCode);
	newElem.insertRow(-1).insertCell(-1);
	newElem.rows[0].cells[0].className = "flownodeinfo_td";
	document.body.appendChild(newElem);
	FlowChartObject.Nodes.InfoBox.DOMElement = newElem;
	newElem.LKSObject = FlowChartObject.Nodes.InfoBox;
	LKSEvent.AddEvent("onmousedown", FlowChartObject.Nodes.InfoBox.Hide);
	
	var htmlCode1 = "<table class=flownodeinfo_tb1 style='position:absolute; display:none' />";
	var newElem1 = document.createElement(htmlCode1);
	newElem1.insertRow(-1).insertCell(-1);
	newElem1.rows[0].cells[0].className = "flownodeinfo_td";
	document.body.appendChild(newElem1);
	FlowChartObject.Nodes.ReviewInfoBox.DOMElement = newElem1;
	newElem1.LKSObject = FlowChartObject.Nodes.ReviewInfoBox;
	//LKSEvent.AddEvent("ondblclick", FlowChartObject.Nodes.ReviewInfoBox.Hide);
	
	var node = new FlowChart_Node("start");
	var x = Math.round((document.body.clientWidth-node.GetWidth())/2);
	node.MoveTo(x, 20, true);
	node = new FlowChart_Node("end");
	node.MoveTo(x, 120, true);
	FlowChartObject.Nodes.Index = 0;
};

//====================::::::::::流程图节点对象::::::::::====================
function FlowChart_Node(NodeType, NodeText, NodeImg, NodeProImg, NodeReviewer)
{
	//==========初始校验==========
	switch(NodeType)
	{
		case "start":
		if(FlowChartObject.Nodes.Start!=null)
			throw "开始节点只能有一个";
		FlowChartObject.Nodes.Start = this;
		NodeText = NodeText?NodeText:"开始";
		break;
		
		case "end":
		if(FlowChartObject.Nodes.End!=null)
			throw "结束节点只能有一个";
		FlowChartObject.Nodes.End = this;
		NodeText = NodeText?NodeText:"结束";
	}
	
	//==========属性==========
	this.Name = "Node";														//对象名称
	this.Type = NodeType?NodeType:"normal";									//类型：normal（普通）；start（开始）；end（结束）
	this.Top = 0;															//纵坐标
	this.Left = 0;															//横坐标
	this.NodeNum=FlowChartObject.Nodes.Index+1;								//节点对应序号
	this.Text = NodeText?NodeText:"节点"+(++FlowChartObject.Nodes.Index);		//节点文本
	this.Reviewer = NodeReviewer?NodeReviewer:"<添加处理人>";					//节点文本
	this.Title = "";														//节点标题
	this.LogInfo = "";
	this.Image = NodeImg?NodeImg:FlowChartObject.Nodes.Image;				//节点图片，IsEnabled=true时显示图片Image+"_1.gif"，IsEnabled=false时显示Image+"_2.gif"
	this.ProImage = NodeProImg?NodeProImg:FlowChartObject.Nodes.ProImage;	//节点图片，IsEnabled=true时显示图片Image+"_1.gif"，IsEnabled=false时显示Image+"_2.gif"
	this.IsSelected = false;												//是否被选中
	this.CanDelete = this.Type!="normal"?false:true;						//是否可以被删除
	this.CanLinkStart = (this.Type!="start" && this.Type!="end")?true:false;						//是否可以接入连线起点
	this.CanLinkEnd = this.Type!="start"?true:false;						//是否可以接入连线终点
	this.CanParse = false;													//是否可以拷贝粘贴	fengy
	//this.CanLinkStart = false;
	//this.CanLinkEnd = false;
	this.CanChgAttribute = true;											//是否可以修改属性
	//==========子对象==========
	this.Data = new Object;												//节点数据，用于扩充
	this.LineStart = new Array;											//起点为当前节点的连线
	this.LineEnd = new Array;												//终点为当前节点的连线
	this.EditProperty = "1";												//0 不可编辑；1编辑属性；2编辑处理人
	
	//==========方法==========
	this.GetWidth = FlowChart_Node_GetWidth;								//获取节点宽度
	this.GetHeight = FlowChart_Node_GetHeight;								//获取节点高度
	this.SetText = FlowChart_Node_SetText;									//设置文本
	this.SetBgColor = FlowChart_Node_SetBgColor;							//设置背景色
	this.SetLogInfo = FlowChart_Node_SetLogInfo;							//显示log信息
	this.SetTitle = FlowChart_Node_SetTitle;								//设置标题
	this.SetImage = FlowChart_Node_SetImage;								//设置图片
	this.SetProImage = FlowChart_Node_SetProImage;							//设置图片
	this.SetReviewer = FlowChart_Node_SetReviewer;							//设置节点处理人		//fengy
	this.SetParsedByInfo = FlowChart_Node_SetParsedByInfo;					//2015-03
	this.SetReviewerAd = FlowChart_Node_SetReviewerAd;						//审批人ID
	this.ShowAddress = FlowChart_Node_ShowAddress;							//显示地址本
	this.SetFunction = FlowChart_Node_SetFunction;							//设置功能
	this.MoveTo = FlowChart_Node_MoveTo;									//移动节点
	this.Select = FlowChart_Node_Select;									//选中节点
	this.GetPointXY = FlowChart_Node_GetPointXY;							//获取操作点的位置
	this.ShowAttribute = FlowChart_Node_ShowAttribute;						//显示属性
	this.Delete = FlowChart_Node_Delete;									//删除节点
	this.AddLineStart = FlowChart_Node_AddLineStart;						//添加连线起点
	this.AddLineEnd = FlowChart_Node_AddLineEnd;							//添加连线终点
	this.DelLineStart = FlowChart_Node_DelLineStart;						//删除连线起点
	this.DelLineEnd = FlowChart_Node_DelLineEnd;							//删除连线终点
	this.SetSubFlow =FlowChart_Node_SetSubFlow;								//设置显示子流程
	//==========初始化==========
	//外框部分，用于显示阴影效果
	var htmlCode = "<table border=0 cellpadding=0 cellspacing=0 style='position:absolute;' id=NodeElements class=flownode_top />";
	var newElem = document.createElement(htmlCode);
	document.body.appendChild(newElem);
	newElem.insertRow(-1).insertCell(-1);
	newElem.insertRow(-1).insertCell(-1);
	newElem.insertRow(-1).insertCell(-1);
	newElem.insertRow(-1).insertCell(-1);	//2015-03 add	
	newElem.rows[0].insertCell(-1);
	newElem.rows[2].insertCell(-1);
	newElem.rows[2].insertCell(-1);
	newElem.rows[2].insertCell(-1);
	newElem.rows[3].insertCell(-1);//2015-03 add
	newElem.rows[3].insertCell(-1);//2015-03 add
	newElem.rows[3].insertCell(-1);//2015-03 add	
	newElem.rows[0].cells[0].colSpan = 2;
	newElem.rows[0].cells[0].rowSpan = 2;
	if(NodeType=="start" || NodeType=="end")
		newElem.rows[0].cells[0].className = "flownode_main_beout";			//主显示区域
	else
		newElem.rows[0].cells[0].className = "flownode_main_out";			//主显示区域
	newElem.rows[0].cells[1].className = "flownode_sd_blank";			//右上角空白部分
	newElem.rows[1].cells[0].className = "flownode_sd_black_r";			//右边阴影部分
	newElem.rows[2].cells[0].className = "flownode_sd_blank";			//左下角空白部分
	newElem.rows[2].cells[1].className = "flownode_sd_black_b";			//下边阴影部分
	newElem.rows[2].cells[2].className = "flownode_sd_black_rb";		//右下角阴影部分
	newElem.rows[3].cells[0].className = "flownode_sd_blank";			//2015-03 add 左下角空白部分
	newElem.rows[3].cells[1].className = "flownode_sd_black_b";			//2015-03 add下边阴影部分
	newElem.rows[3].cells[2].className = "flownode_sd_black_rb";		//2015-03 add右下角阴影部分	
	this.DOMElement = newElem;
	newElem.LKSObject = this;
	
	//主显示区域
	htmlCode = "<table class=flownode_main_nor />";
	newElem = document.createElement(htmlCode);
	this.DOMElement.rows[0].cells[0].appendChild(newElem);
	newElem.insertRow(-1).insertCell(-1);								//第一个单元格显示图片
	if(NodeType=="start" || NodeType=="end")
	{
		newElem.rows[0].insertCell(-1);										//第二个单元格显示文字
		newElem.rows[0].cells[0].width = 1;
		newElem.rows[0].cells[0].className = "flownode_text";
		newElem.rows[0].cells[1].className = "flownode_text";
	}else
	{
		newElem.insertRow(-1).insertCell(-1);								//第一个单元格显示图片
		newElem.rows[0].insertCell(-1);										//第二个单元格显示文字
		newElem.rows[0].insertCell(-1);										//第二个单元格显示文字
		newElem.rows[0].cells[0].width = 1;
		newElem.rows[0].cells[0].height = 20;
		newElem.rows[0].cells[0].className = "flownode_sd_nodename";
		newElem.rows[0].cells[1].width = 165;
		newElem.rows[0].cells[1].className = "flownode_sd_nodename";
		newElem.rows[0].cells[2].className = "flownode_sd_nodename";
		newElem.rows[1].insertCell(-1);								//第二个单元格显示文字
		newElem.rows[1].cells[0].height = 30;
		newElem.rows[1].cells[0].colSpan = 3;
		newElem.rows[1].cells[0].className = "flownode_text";

		//2015-03 add----
		newElem.insertRow(-1);
		newElem.rows[2].insertCell(-1);								//第三个单元格显示文字
		newElem.rows[2].cells[0].height = 20;
		newElem.rows[2].cells[0].colSpan = 2;
		newElem.rows[2].cells[0].className = "flownode_text";
		newElem.rows[2].style.display="none";
		//this.ParsedByTR = newElem.rows[2];
		//this.DOMParsedBy = newElem.rows[2].cells[0];
		//---------------		
	}
	this.DOMMain = newElem;
	//图片区域
	htmlCode = "<input type=image id=NodeImages />";
	newElem = document.createElement(htmlCode);
	this.DOMMain.rows[0].cells[0].appendChild(newElem);
	this.DOMImage = newElem;
	newElem.LKSObject = this;	
	newElem.onclick = FlowChartObject.Nodes.InfoBox.ShowInfo;			//点击图片显示详细信息
	//文字区域
	this.DOMText = this.DOMMain.rows[0].cells[1];
	this.DOMText.LKSObject = this;
	if(NodeType=="start" || NodeType=="end")
		this.DOMReviewer = "";
	else
	{
		this.DOMReviewer = this.DOMMain.rows[1].cells[0];
		this.DOMReviewer.LKSObject=this;
		this.DOMReviewer.onclick = FlowChartObject.Nodes.ReviewInfoBox.ShowInfo;
		
		htmlCode = "<input type=image id=NodeProImages />";
		newElem = document.createElement(htmlCode);
		this.DOMMain.rows[0].cells[2].appendChild(newElem);
		this.DOMProImage = newElem;
		newElem.LKSObject = this;
		newElem.onclick = ShowProperty;		//点击图片显示节点信息 
		this.SetProImage();
	}
	this.SetReviewer();
	this.SetText();
	this.SetImage();
	this.SetParsedByInfo();	//2015-03	
	this.DOMText.onclick =  FlowChartObject.Nodes.InfoBox.ShowLogInfo; //点击文本显示审批详细信息
	FlowChartObject.Nodes.all[FlowChartObject.Nodes.all.length] = this;
}

//====================::::::::::流程图节点函数::::::::::====================

//获取节点宽度
function FlowChart_Node_GetWidth()
{
	return this.DOMElement.clientWidth;
}

//获取节点高度
function FlowChart_Node_GetHeight()
{
	return this.DOMElement.clientHeight;
}

//设置文本，若不传参数，则采用当前值
function FlowChart_Node_SetText(NodeText)
{
	if(NodeText!=null)
		this.Text = NodeText;
	this.DOMText.innerHTML = this.Text;
}
//设置节点通用岗位解析信息
//2015-03 add
//2015-04 Modify
function FlowChart_Node_SetParsedByInfo(recObj)
{	
	try{
		//新建一个节点时
		var ParsedByTR = this.DOMMain.rows[2];
		var DOMParsedBy = this.DOMMain.rows[2].cells[0];
		if(recObj!=null && recObj.F_ParsedByText!=null){
			if(recObj.F_ParsedByText=="" || recObj.F_ParsedByText=="起草人"){
				DOMParsedBy.innerHTML = "";
				ParsedByTR.style.display="none";
				this.DOMReviewer.className = "flownode_text";
				return;
			}else{
				DOMParsedBy.innerHTML = "通用岗位由  <b>"+recObj.F_ParsedByText+"</b> 解析";
				ParsedByTR.style.display="";
				this.DOMReviewer.className = "flownode_sd_nodename1";
				return;			
			}
		}
		
		//打开流程文档时
		var iKey=this.Data.F_NodeKey;
		var ParsedByInfo=this.Data.F_ParsedBy;
		if(iKey && ParsedByInfo){
			if(ParsedByInfo!="" && ParsedByInfo!="0" && ParsedByInfo!="undefined"){
				for(var i=2; i<FlowChartObject.Nodes.all.length; i++){
					var node = FlowChartObject.Nodes.all[i];
					if(node.Data.F_NodeKey==this.Data.F_ParsedBy){
						ParsedByInfo=node.Data.F_NodeName;
						break;
					}
				}
				if(ParsedByInfo==this.Data.F_ParsedBy){//加载时,可能有些node没有初始化,读不到节点信息
					for(var i =0;i<50;i++){
						if(eval("parent.document.forms[0].F_NodeKey_"+i).value==this.Data.F_ParsedBy){
							ParsedByInfo=eval("parent.document.forms[0].F_NodeName_"+i).value;
							break;
						}
					}
				}
				DOMParsedBy.innerHTML = "通用岗位由  <b>"+ParsedByInfo+"</b> 解析";
				ParsedByTR.style.display="";
				this.DOMReviewer.className = "flownode_sd_nodename1";
			}else{
				DOMParsedBy.inflowchart_node.jsnerHTML = "";
				ParsedByTR.style.display="none";
				this.DOMReviewer.className = "flownode_text";
			}
		}else{
			DOMParsedBy.innerHTML = "";
			ParsedByTR.style.display="none";
			this.DOMReviewer.className = "flownode_text";
		}
	}catch(e){}
}

//设置背景颜色
function FlowChart_Node_SetBgColor(className)
{
	if(className!=null)
		this.DOMMain.className = className;
}
//设置标题，若不传参数，则采用当前值
function FlowChart_Node_SetTitle(NodeTitle)
{
	if(NodeTitle!=null)
		this.Title = NodeTitle;
}
//设置审批记录，若不传参数，则采用当前值
function FlowChart_Node_SetLogInfo(LogInfo)
{
	if(LogInfo!=null)
		this.LogInfo = LogInfo;
}

//设置图片，若不传参数，则采用当前值
function FlowChart_Node_SetImage(NodeImage)
{
	if(NodeImage!=null)
	{
		if(this.Image==NodeImage)
			return;
		this.Image = NodeImage;
	}
	this.DOMImage.src = S_ResourcePath+"images/"+this.Image;
}
//设置节点处理人，若不传参数，则采用当前值
function FlowChart_Node_SetReviewer(NodeReviewer)
{
	if(NodeReviewer!=null && (this.IsOffshoot==null || !this.IsOffshoot))
		this.Reviewer = NodeReviewer;
	if(this.Reviewer.length>28) txt=this.Reviewer.substring(0,28)+"..."; else txt=this.Reviewer;
	this.DOMReviewer.innerHTML = txt;//"<b><font size=4>"+this.NodeNum+".</font></b>&nbsp;"+this.Reviewer;
}
//设置编辑属性图片，若不传参数，则采用当前值
function FlowChart_Node_SetProImage(NodeProImage)
{
	if(this.IsOffshoot==null || !this.IsOffshoot){
		if(NodeProImage!=null)
		{
			if(this.ProImage==NodeProImage)
				return;
			this.ProImage = NodeProImage;
		}
		this.DOMProImage.src = S_ResourcePath+"images/"+this.ProImage;
	}
}
//设置审批人ID，若不传参数，则采用空值
function FlowChart_Node_SetReviewerAd(NodeReviewerAd)
{
	if(NodeReviewerAd!=null)
		this.ReviewerAd = NodeReviewerAd;
}

/****************************************************************************************
功能：设置功能权限
参数：
	funcName：节点对象中以"Can"开头的属性，如："Delete"表示设置节点"CanDelete"属性
	value：true或false，为空则不修改原有属性
****************************************************************************************/
function FlowChart_Node_SetFunction(funcName, value)
{
	if(eval("this.Can"+funcName)==null)
		throw "参数设置无效";
	else
		if(value!=null)
			eval("this.Can"+funcName+"=value;");
}

/**********************************************************
功能：移动节点，同时移动节点的连线
参数：
	x：横坐标，不指定则取原有值
	y：纵坐标，不指定则取原有值
	toGrid：true（吸附到网格），默认为false
**********************************************************/
function FlowChart_Node_MoveTo(x, y, toGrid)
{
	if(x!=null)
		this.Left = x;
	if(y!=null)
		this.Top = y;
	if(toGrid)
	{
		this.Left = Math.round(this.Left/FlowChartObject.Grid.Width)*FlowChartObject.Grid.Width;
		this.Top = Math.round(this.Top/FlowChartObject.Grid.Width)*FlowChartObject.Grid.Width;
	}
	this.DOMElement.style.top = this.Top;
	this.DOMElement.style.left = this.Left;
	var i;
	for(i=0; i<this.LineStart.length; i++)
		this.LineStart[i].Refresh();
	for(i=0; i<this.LineEnd.length; i++)
		this.LineEnd[i].Refresh();
}

/********************************************************************
功能：选中节点
参数：
	selType：true（选中）；false（不选中）；null（反向选中）
********************************************************************/
function FlowChart_Node_Select(selType)
{
	var bgclassName = this.DOMMain.className;
	var bgclassName_sel = bgclassName;
	if(bgclassName.indexOf("_sel")!=-1) bgclassName = bgclassName.substring(0,bgclassName.indexOf("_sel"));
	bgclassName_sel = bgclassName + "_sel";
	this.IsSelected = (selType==null)?!this.IsSelected:selType;
	this.DOMMain.className = this.IsSelected?bgclassName_sel:bgclassName;
}

/********************************************************************
功能：获取操作点的位置
参数：
	position：位置，值为：NodeTop、NodeBottom、NodeLeft、NodeRight
********************************************************************/
function FlowChart_Node_GetPointXY(position)
{
	var width = this.DOMMain.clientWidth;
	var height = this.DOMMain.clientHeight;
	switch(position)
	{
		case "NodeTop":
		return new Array(this.Left+width/2, this.Top);
		
		case "NodeBottom":
		return new Array(this.Left+width/2, this.Top+height);
		
		case "NodeLeft":
		return new Array(this.Left, this.Top+height/2);
		
		case "NodeRight":
		return new Array(this.Left+width, this.Top+height/2);
	}
}

//显示属性，该功能一般由其他的JS编写替换代码
function FlowChart_Node_ShowAttribute()
{
	if(this.CanChgAttribute)
		alert("显示节点属性："+this.Text);
}

/**********************************************************
功能：删除节点，同时删除相关的连线
参数：
	force：true（强制删除），false（默认）
**********************************************************/
function FlowChart_Node_Delete(force)
{
	if(!force && !this.CanDelete)
		return;
	for(; this.LineStart.length>0;)
		this.LineStart[0].Delete(true);
	for(; this.LineEnd.length>0; )
		this.LineEnd[0].Delete(true);
	FlowChartObject.Nodes.all = FlowChartObject.Nodes.all.removeElem(this);
	this.DOMElement.removeNode(true);
}

//添加连线起点
function FlowChart_Node_AddLineStart(line)
{
	if(this.LineStart.indexOf(line)==-1)
		this.LineStart[this.LineStart.length] = line;
}

//添加连线终点
function FlowChart_Node_AddLineEnd(line)
{
	if(this.LineEnd.indexOf(line)==-1)
		this.LineEnd[this.LineEnd.length] = line;
}

//删除连线起点
function FlowChart_Node_DelLineStart(line)
{
	this.LineStart = this.LineStart.removeElem(line);
}

//删除连线终点
function FlowChart_Node_DelLineEnd(line)
{
	this.LineEnd = this.LineEnd.removeElem(line);
}

//组装子流程链接
function FlowChart_Node_SetSubFlow(subflowstr,isFlow){
	if(subflowstr!=null && subflowstr!=""){
		var tmpArr=subflowstr.split(";");
		var tmpRtnArr=new Array;
		var path=parent.location.href;
		var editstr="?opendocument";
		path=path.substring(0,path.indexOf(".nsf")+4);
		if(path.toLowerCase().indexOf("lks_flow.nsf")==-1 && isFlow!=1)
			path=path.substring(0,path.lastIndexOf("/"))+"/lks_flowdef.nsf";
		for(var i=0;i<tmpArr.length;i++){
				tmpArr[i]=trim(tmpArr[i]);
				var htmlStr;
				if(isFlow!=1)
					htmlStr="<a onclick=\"window.open('"+ path + "/0/"+tmpArr[i].substr(tmpArr[i].indexOf("|")+1)+editstr+"','_blank');return false;\" href='#'>"+tmpArr[i].substring(0,tmpArr[i].indexOf("|"))+"</a>";
				else
					htmlStr="<a onclick=\"parent.location=('"+ path + "/FM_ReviewSubFlow?openform&ParentUNID="+tmpArr[i].substr(tmpArr[i].indexOf("|")+1)+"');return false;\" href='#'>"+tmpArr[i].substring(0,tmpArr[i].indexOf("|"))+"</a>";
				tmpRtnArr.push(htmlStr);
		}
		this.DOMReviewer.innerHTML=tmpRtnArr.join(";");//"<b><font size=4>"+this.NodeNum+".</font></b>&nbsp;"+tmpRtnArr.join(";");
	}
}