function getContractNo(strPrefix,fieldName,deptFieldName,cataFieldName,serverName,type){
	if(parent.S_SubmitType && parent.S_SubmitType=="draft")
		return true;
	var fieldObj=eval("document.all."+fieldName);
	if(fieldObj && fieldObj.value==""){
		var tmpPre = strPrefix;
		var tmpPreID=strPrefix;
		var tmpDept="";
		var tmpDeptID="";
		var tmpCate="";
		var tmpCateID="";

		var tmpObj = document.getElementById(deptFieldName);  
		tmpDeptID = tmpObj.options[tmpObj.selectedIndex].value; //单位编码
		tmpDept = tmpObj.options[tmpObj.selectedIndex].text; //单位名称

		tmpObj = document.getElementById(cataFieldName);
		tmpCateID = tmpObj.options[tmpObj.selectedIndex].value;	//类别编码
		tmpCate = tmpObj.options[tmpObj.selectedIndex].text; //类别名称

		tmpPre +=tmpDeptID+"-"+tmpCateID;
		tmpPreID +=tmpDeptID;
	
		if(type && type=="zhaobiao")
			txtagent="AG_GetZhaobiaoFlowNoNew"; 
		else
			txtagent="AG_GetBargainFlowNoNew";
		var sagent="/lks/koa/lks_devconfigsec.nsf/"+txtagent+"?openagent&pre="+escape(tmpPre)+"&preID="+escape(tmpPreID)+"&dept="+escape(tmpDept)+"&cate="+escape(tmpCate);
		if(serverName) sagent+="&svr="+serverName;
		var xml = createXMLDomRequest()
		if(xml){
			xml.async = false;
			xml.load(sagent);
			var nodes = xml.selectNodes("returnValue");
			fieldObj.value=nodes[0].text;
		}
	}
	return true;
}

function getContractNoSam(strPrefix,fieldName,deptFieldName,cataFieldName,serverName,type){
	if(parent.S_SubmitType && parent.S_SubmitType=="draft")
		return true;
	var fieldObj=eval("document.all."+fieldName);
	if(fieldObj && fieldObj.value==""){
		var tmpPre = strPrefix;
		var tmpPreID=strPrefix;
		var tmpDept="";
		var tmpDeptID="";
		var tmpCate="";
		var tmpCateID="";

		var tmpObj = document.getElementById(deptFieldName);  
		tmpDeptID = tmpObj.options[tmpObj.selectedIndex].value; //单位编码
		tmpDept = tmpObj.options[tmpObj.selectedIndex].text; //单位名称

		tmpObj = document.getElementById(cataFieldName);
		tmpCateID = tmpObj.options[tmpObj.selectedIndex].value;	//类别编码
		tmpCate = tmpObj.options[tmpObj.selectedIndex].text; //类别名称

		tmpPre +=tmpDeptID+"-"+tmpCateID;
		tmpPreID +=tmpDeptID;
	
		if(type && type=="zhaobiao")
			txtagent="AG_GetZhaobiaoFlowNoNew"; 
		else
			txtagent="AG_GetBargainFlowNoSam";
			
		/* koa_lihx 20161213 记录获取编号的日志
		 * 收集主文档以及操作者信息
		 * eg:&opAD=wanghan&opName=王菡&mdunid=AB0D3943E005D002482580AB002E5109&mdser=oa.sec.com.cn&mdpath=lks/koa/lks_review.nsf
		 */
		var flowLogArgs="&opAD="+escape(S_UserAd);
		flowLogArgs=flowLogArgs+"&opName="+escape(S_UserName);
		if(top.S_IsNewDoc==1){ //新建流程时，主表单还没有保存，主题需要参数传递
			//主表单是否保存了需要代码验证
			flowLogArgs=flowLogArgs+"&mdsubject="+escape(top.document.getElementById("Subject").value);
		}
		flowLogArgs=flowLogArgs+"&mdunid="+escape(top.S_DocId);
		flowLogArgs=flowLogArgs+"&mdser="+escape(location.hostname);
		flowLogArgs=flowLogArgs+"&mdpath="+escape(location.pathname.substring(1,top.location.pathname.indexOf(".nsf"))+".nsf");
		
		var sagent="/lks/koa/lks_devconfigsec.nsf/"+txtagent+"?openagent&pre="+escape(tmpPre)+"&preID="+escape(tmpPreID)+"&dept="+escape(tmpDept)+"&cate="+escape(tmpCate);
		sagent=sagent+flowLogArgs;
		if(serverName) sagent+="&svr="+serverName;
		var xml = createXMLDomRequest()
		if(xml){
			xml.async = false;
			xml.load(sagent);
			var nodes = xml.selectNodes("/");
			fieldObj.value=nodes[0].text;
		}
	}
	return true;
}

function createXMLDomRequest()
{
　　var i,activeXarr; 
　　var activeXarr = [ 
　　　　"Msxml2.DOMDocument", 
　　　　"MSXML.DOMDocument" ,
	"Microsoft.XMLDOM" 
　　]; 
　　for(i=0; i<activeXarr.length; i++){ 
　　　　try{ 
　　　　　　var o = new ActiveXObject(activeXarr[i]); 
　　　　　　return o; 
　　　　}catch(e){} 
　　} 
　　return false; 
}
