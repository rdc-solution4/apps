<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>请登录深圳能源OA系统</title><meta http-equiv="Content-Type" content"text/html; charset=gb2312"> <style type="text/css">   <!--  a {  font: 12px "宋体"; color: #478969; text-decoration: none}    a:visited {  font: 12px "宋体"; color: #478969; text-decoration: none} a:hover {  font: 12px "宋体"; color:478969; text-decoration: underline; } td { font: 12px/30px "宋体" color: #003048}  .field {  font: 12px "Arial"; color: #000000;height: 20px;width: 120px;background-color: #ffffff }  .bnt{ height: 17px; 	width: 65px; border: #B4C8D7; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px 	color: #000000; 	background-attachment: fixed; background-image: url(images/bnt1.jpg); 	background-repeat: no-repeat; }  .username {  font: 12px "Arial"; color: #000000; border: #000000; } .password { font: 12px "Arial"; color: #000000; background: #FFFFFF; border: #000000; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px }  .passwordmouseover { font: 12px "Arial"; color: #FF0000; background: #000000; border: #000099; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px }  .usernamemouseover { font: 12px "Arial"; color: #0066FF; background: #CCCCFF; border: #000099; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px }  .buttonmouseover { font: 12px "宋体"; color: #f3f3f3; background: #f3f3f3; letter-spacing: 10px; padding: 2px 6px; border: #660099; border-style: solid; border-top-width: 1px; border-right-width: 1px; border-bottom-width: 1px; border-left-width: 1px; height: 20px; cursor: hand } .font_form{font-size:14px;font-weight:bold;color:#000000}   --> </style>
<script language="JavaScript" type="text/javascript">
<!-- 
function goBackOA(){
	location.href = "http://oa.sec.com.cn";
}
function gotoLogin(){
	var hrefStr = location.href;
	location.href = "http://oa.sec.com.cn/names.nsf?login&redirectto="+hrefStr;
}

function loginCheck(userad){
    //查看用户密码是否过期，是否被禁用
     var statusGPS ="";
     var GPSReturn;
	var xmlGPS= getIEXmlAX();
	if(xmlGPS){
		xmlGPS.async = false;
		xmlGPS.load("/lks/sys/lks_usercenter.nsf/AG_GetPasswordStatus?openagent&userad="+userad);
		nodesGPS = xmlGPS.selectNodes("ReturnMsg");
		if (nodesGPS){
			statusGPS = ( nodesGPS[0].text);
			GPSReturn = statusGPS.split("_");
			if(parseInt(GPSReturn[0])>90){
				return "gq";
			}
			if(parseInt(GPSReturn[1])=="514"){
				return "jy";
			}
		}
	}
  
}
// -->
</script>

<script language="JavaScript" type="text/javascript">
<!-- 
function edit(){
var width=420;
var height=300;
var style="width="+width+" height="+height;
var path=document.all.F_appsetuppath.value;
style+=" left="+(screen.availWidth-width)/2;
style+=" top="+(screen.availHeight-height)/2;
window.open("/"+path+"lks_public.nsf/PasswordChange?OpenForm", "", style);
}
function submitForm(){
	/*
	var cr = loginCheck(document.all.Username.value); 
	if(cr=="gq"){
		location.href = "/domcfg.nsf/LoginTipUpdatePWD?OpenForm&gqts=4";
		return;
	}
	if(cr=="jy"){
		document.all.xtts.innerHTML="系统提示：因错误密码次数超过三次，您的账户已经被禁用。他人恶意尝试密码导致用户账号被锁的情况，请1分钟后再试，或联系曾工（83680180）跟踪恶意来源。";
		return;
	}
	*/
	
	setCookie("22",document.forms[0].Password.value); 
	//记录是否保存登陆信息
	document.all.RedirectTo.value=document.all.RedirectTo.value+"&savelogin="+(document.all.F_SaveLoginInfo.checked?"1":"0");
	setCookie("33",(document.all.F_SaveLoginInfo.checked?"1":"0"));  
	document.forms[0].submit();
}
function getCookie(name)
{
    var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)")); 
　　if(arr !=null) return unescape(arr[2]); return null; 
}
function setCookie(name,value) 
{ 
　　var Days = 365; //此 cookie 将被保存 365 天 
　　var exp　= new Date(); 
　　exp.setTime(exp.getTime() + Days*24*60*60*1000); 
    document.cookie = name+"="+escape (value)+"; path=/; expires="+exp.toUTCString(); 	
} 

function getIEXmlAX()
{   
　　var i,activeXarr;   
　　var activeXarr = [             
　　　　"MSXML4.DOMDocument",   
　　　　"MSXML3.DOMDocument",   
　　　　"MSXML2.DOMDocument",   
　　　　"MSXML.DOMDocument",   
　　　　"Microsoft.XmlDom"  
　　];     
　　for(i=0; i<activeXarr.length; i++){   
　　　　try{   
　　　　　　var o = new ActiveXObject(activeXarr[i]);   
　　　　　　return o;   
　　　　}catch(e){}   
　　}   
　　return false;   
}   


function submitForm2(){
	var uName = document.all.Username.value;
	//运维用户不做1分钟限制
     if(!(uName=="koa_liangy" || uName=="liangyang" || uName=="admin_liangy" || uName=="koa_lihx" || uName=="ll_lihuanxi" || uName=="lc_gp2"|| uName=="gelan" || uName=="admin_gel"|| uName=="koa_gel"
		|| uName=="wanghan"|| uName=="koa_wangh"|| uName=="xupei"|| uName=="koa_xup"|| uName=="koa_luorf"|| uName=="yegangying"|| uName=="koa_yegy"
          || uName=="panghaifeng"|| uName=="koa_panghf")){
		var s_44=getCookie("44");
		if(s_44 && s_44!=""){
			alert("为确保OA系统正常服务，请不要一分钟内多次登录，多谢。");
			return false;
		}	
	}
	setCookie2("44","1") ;
	
	      var xml= getIEXmlAX();
        window.status="正在获取登陆令牌.......";
        if(xml)
        {
            xml.async = false;
            
            var cpassword = escape(document.all.Password.value);
            //cpassword = escape(cpassword);
            
		if(cpassword!=null&&cpassword!=""){
			cpassword=cpassword.replace(/\+/g,"%2B");
			//cpassword=cpassword.replace(/\&/g,"%26");
			//cpassword=cpassword.replace(/\%/g,"%25");
			//cpassword=cpassword.replace(/\$/g,"%24");
			//cpassword=cpassword.replace(/\#/g,"%23");
			//cpassword=cpassword.replace(/\=/g,"%3d");
		}
		//alert(escape(cpassword))
            xml.load("/domcfg.nsf/AG_GetDominoToken_Input?openagent&us="+document.all.Username.value+"&kw="+cpassword);
            nodes = xml.selectNodes("ReturnMsg");
            if (nodes)
                token = nodes[0].text;
        }  
        window.status="获取登陆令牌完成";     
        
        if(token && token=="over"){
        	alert("由于同时登录人数众多，请稍后片刻再尝试登录，带来不便之处敬请原谅。")
        	return false;
        }
      
        if(token && token=="error"){
 
        	alert("用户或者密码错误，请重新输入");
        	return false;
        }
        setCookie("22",document.forms[0].Password.value); 
        //记录是否保存登陆信息
	   document.all.RedirectTo.value=document.all.RedirectTo.value+"&savelogin="+(document.all.F_SaveLoginInfo.checked?"1":"0");
	   // document.all.RedirectTo.value = "/domcfg.nsf/fm_userinfo?readform"
	   setCookie("33",(document.all.F_SaveLoginInfo.checked?"1":"0"));  
        
        var logUrl = document.all.F_LogDb.value;
if (logUrl!=""){
	var rdtUrl = document.all.RedirectTo.value;
	logUrl = "/"+logUrl+"/ag_loginlog?openagent&";
	if(rdtUrl.substring(0,logUrl.length)!=logUrl)
		document.all.RedirectTo.value = logUrl+"url="+document.all.RedirectTo.value+"&mbsize="+screen.width+"*"+screen.height;
}
if (token && token!=""){
    var exp　= new Date(); 
    exp.setTime(exp.getTime() + 600*60*1000); //600分钟
    document.cookie = "LtpaToken="+token+"; path=/; domain=sec.com.cn; expires="+exp.toUTCString();
    location.href=document.all.RedirectTo.value+"&savelogin="+(document.all.F_SaveLoginInfo.checked?"1":"0");;
    return ;
}
document.all.loaddata_div.style.display='none';
document.body.style.backgroundImage='url("/lks/koa/images/back.jpg")';
document.body.style.backgroundRepeat='repeat-x';
document.all.mainTable.style.display='';

	setCookie("22",document.forms[0].Password.value); 
	//记录是否保存登陆信息
	document.all.RedirectTo.value=document.all.RedirectTo.value+"&savelogin="+(document.all.F_SaveLoginInfo.checked?"1":"0");
	setCookie("33",(document.all.F_SaveLoginInfo.checked?"1":"0"));  
	
}


function setCookie2(name,value) 
{ 
　　var exp　= new Date(); 
　　exp.setTime(exp.getTime() + 60*1000);  //用户1分钟内只能登录3次
    document.cookie = name+"="+escape (value)+"; path=/; expires="+exp.toUTCString(); 	
} 


function submitForm3(){
	setCookie("22",document.forms[0].Password.value); 
	//记录是否保存登陆信息
	document.all.RedirectTo.value=document.all.RedirectTo.value+"&savelogin="+(document.all.F_SaveLoginInfo.checked?"1":"0");
	setCookie("33",(document.all.F_SaveLoginInfo.checked?"1":"0"));  
	document.forms[0].submit();
}

// -->
</script>
</head>
<body text="#000000" bgcolor="#FFFFFF" leftmargin=0 rightmargin=0 topmargin=0 bottommargin=0  onkeydown="//if(event.keyCode==13)
     //submit();" onload="

//alert(document.all.RedirectTo.value);
if(S_reasonType==&quot;1&quot;)
	return;
if (document.all.F_IsUserCenter.value=='1') return;


        
        
var S_11,S_22,token;
var S_QueryStr=(document.all.Query_String.value).toLowerCase();
if ((S_QueryStr=='open' || S_QueryStr=='readform') &amp;&amp; S_reasonType=='0')
{
    S_11=getCookie(&quot;11&quot;);
    S_22=getCookie(&quot;22&quot;);
    
    
    if(S_11 &amp;&amp; S_22){
    /*
			var cr = loginCheck(document.all.Username.value); 
			if(cr==&quot;gq&quot;){
				location.href = &quot;/domcfg.nsf/LoginTipUpdatePWD?OpenForm&amp;gqts=4&quot;;
				return;
			}
			if(cr==&quot;jy&quot;){
				document.all.xtts.innerHTML=&quot;系统提示：因错误密码次数超过三次，您的账户已经被禁用。他人恶意尝试密码导致用户账号被锁的情况，请1分钟后再试，或联系曾工（83680180）跟踪恶意来源。&quot;;
				return;
			}
	*/
        var xml= getIEXmlAX();
        window.status=&quot;正在获取登陆令牌.......&quot;;
        if(xml)
        {
            xml.async = false;
           // xml.load(&quot;/domcfg.nsf/AG_GetDominoToken_cookie?openagent&amp;us=&quot;+S_11+&quot;&amp;kw=&quot;+S_22);
            xml.load(&quot;/domcfg.nsf/AG_GetDominoToken?openagent&amp;us=&quot;+S_11+&quot;&amp;kw=&quot;+S_22);
            nodes = xml.selectNodes(&quot;ReturnMsg&quot;);
            if (nodes)
              token = (nodes[0].text);
        } 
		window.status=&quot;获取登陆令牌完成&quot;;     
    }
}
//document.all.Username.focus();
var logUrl = document.all.F_LogDb.value;
if (logUrl!=&quot;&quot;){
	if(window.console!=null){
		console.info(&quot;1:&quot;+document.all.RedirectTo.value);
		console.info(&quot;2:&quot;+logUrl);
	}
	var rdtUrl = document.all.RedirectTo.value;
	logUrl = &quot;/&quot;+logUrl+&quot;/ag_loginlog?openagent&amp;&quot;;
	if(rdtUrl.substring(0,logUrl.length)!=logUrl)
		document.all.RedirectTo.value = logUrl+&quot;url=&quot;+document.all.RedirectTo.value+&quot;&amp;mbsize=&quot;+screen.width+&quot;*&quot;+screen.height;
	if(window.console!=null){
		console.info(&quot;1:&quot;+document.all.RedirectTo.value);
	}
}
if (token &amp;&amp; token!=&quot;&quot;){
    var exp　= new Date(); 
    exp.setTime(exp.getTime() + 600*60*1000); //600分钟
    document.cookie = &quot;LtpaToken=&quot;+token+&quot;; path=/; domain=sec.com.cn; expires=&quot;+exp.toUTCString();
    location.href=document.all.RedirectTo.value+&quot;&amp;istoken=1&quot;;
    return ;
}
document.all.loaddata_div.style.display='none';
document.body.style.backgroundImage='url(&quot;/lks/koa/images/back.jpg&quot;)';
document.body.style.backgroundRepeat='repeat-x';
document.all.mainTable.style.display='';
//设置是否保存登陆信息
var S_33=getCookie(&quot;33&quot;);
if(document.all.F_SaveLoginInfo &amp;&amp; S_33)
{
	if(S_33=='1')
		document.all.F_SaveLoginInfo.checked=true;
	else 
		document.all.F_SaveLoginInfo.checked=false;
}
">

<form method="post" action="/names.nsf?Login" name="_DominoForm">
<input type="hidden" name="%%ModDate" value="5A1A3F7000000000">
<input name="Keyword" value="201808151432424124" style="display:none">
<table style="display:none" border="0" cellspacing="0" cellpadding="0">
<tr valign="top"><td width="140"><img width="1" height="1" src="/icons/ecblank.gif" border="0" alt=""></td><td width="349" valign="middle">
<input name="F_serverurl" value="oa.sec.com.cn">
<input name="Server_Name" value="oa.sec.com.cn">
<input name="F_IsUserCenter" value="0"></td></tr>

<tr valign="top"><td width="140"><img width="1" height="1" src="/icons/ecblank.gif" border="0" alt=""></td><td width="349">
<input name="Query_String" value="OpenJavascriptLibrary"></td></tr>

<tr valign="top"><td width="140"><img width="1" height="1" src="/icons/ecblank.gif" border="0" alt=""></td><td width="349" valign="middle">
<input name="F_appsetuppath" value="lks/sys/"></td></tr>

<tr valign="top"><td width="140"><img width="1" height="1" src="/icons/ecblank.gif" border="0" alt=""></td><td width="349">
<input name="F_LogDb" value="lks/sys/lks_loginlog.nsf"> 
<input type="submit" value="login"> loginformforip4</td></tr>
</table>
<script language="Javascript">
var S_IsLoginForm="domcfg.nsf";
//if(navigator.platform != "Win32" && navigator.platform != "Win64"){
//location.href='http://mob_oa.sec.com.cn/pdalogin.html?open&a=0'
//}
</script>
<style type="text/css">
<!--
body,td,th {
	font-family: 宋体, Arial;
	font-size: 12px;
	color: #636363;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style>
<script language="Javascript">
var S_reasonType="0";
</script>
<table id=unauthor align=center border=0  height=100% cellpadding=20px style="display:none">
<tr><td><img src="/lks/koa/images/unauthor/ganth.png"></img></td><td style="font-size: 15px;font-family: Microsoft YaHei;">
<span style="color:#FFA042;font-size: 30px;">您访问的OA页面无法打开</span><br>
可能原因如下:<br>
1、【需您审批的流程】该流程尚未流转到您审批的环节，请稍候或者联系相关人员；<br>
2、【无需您审批的流程】该流程没有抄送或者传阅给您，请联系该流程办理人员；<br>
3、【其他文档】该文档没有开放阅读权限给您，请联系文档相关人员。 <br>
<img src="/lks/koa/images/unauthor/green.png" style="cursor:hand" onclick=goBackOA();></img>&nbsp&nbsp&nbsp&nbsp&nbsp
<img src="/lks/koa/images/unauthor/blue.png" style="cursor:hand" onclick=gotoLogin();></img>
</td></tr>
</table>
<div id="loaddata_div" style="position:absolute;left:40%;top:30%"><img src='/domcfg.nsf/loadmsg.gif' /><Font color=#ff0000 size=4><b>正在加载.....请稍侯.</b></Font></div>
<table width="1002" border="0" align="center" cellpadding="0" cellspacing="0" style=display:none id=mainTable>
  <tr>
    <td width="178"><img src="/lks/sys/images/ny_01.jpg" width="178" height="590" /></td>
    <td width="260"><img src="/lks/sys/images/ny_02.jpg" width="260" height="590" /></td>
    <td width="236" valign="top" background="/lks/sys/images/ny_03.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td height="233" valign="bottom" id=xtts>系统提示：登录OA系统</td>
      </tr>
      <tr>
      </tr>
      <tr>
        <td><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="25">用户名：</td>
            <td>
<input name="Username" value="" tabindex="1" maxlength=256 size="12" onmouseover="this.style.backgroundColor = 'E7FEFF'" onmouseout="this.style.backgroundColor = ''" onkeydown="if(event.keyCode==13){
	submitForm();
}" class="field"></td>
            <td width="54" rowspan="2"><img       src="/lks/sys/images/a.jpg"   width="54"   height="47"   onclick=submitForm(); style="cursor:hand" /></td>
          </tr>
          <tr>
            <td height="25">密&nbsp;&nbsp;码：</td>
            <td>
<input name="Password" value="" type="password" tabindex="2" maxlength=256 size="12" onmouseover="this.style.backgroundColor = 'E7FEFF'" onmouseout="this.style.backgroundColor = ''" onkeydown="if(event.keyCode==13){
	submitForm();
}" class="field"></td>
            </tr>
          <tr>
            <td height="25" colspan=2>
<input name="%%Surrogate_F_SaveLoginInfo" type="hidden" value="1">
<input type="checkbox" name="F_SaveLoginInfo" value="1" checked>保存登录信息</td>
            </tr>
        </table></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
      </tr>
    </table></td>
    <td width="171"><img src="/lks/sys/images/ny_04.jpg" width="171" height="590" /></td>
    <td><img src="/lks/sys/images/ny_05.jpg" width="157" height="590" /></td>
  </tr>
</table>
 
<input name="RedirectTo" value="/lks/koa/lks_sapitems.nsf/JS_DynamicTable_SAPHRAPP0302?OpenJavascriptLibrary" style="display:none">

<script>
var S_reasonType="0";
if(S_reasonType=="1"){
   var tableObj = document.getElementById("unauthor");
   tableObj.style.display="";
}
if(S_reasonType=="2"){
	//setCookie("11","");
	setCookie("22",""); 
	setCookie("33",""); 
	window.location = "http://oa.sec.com.cn/domcfg.nsf/LoginTipUpdatePWD?OpenForm&gqts=5";
}
</script></form>
</body>
</html>
