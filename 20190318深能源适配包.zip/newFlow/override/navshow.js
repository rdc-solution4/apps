S_DbUrl = location.pathname;
S_DbUrl = S_DbUrl.substring(0, S_DbUrl.toLowerCase().indexOf(".nsf") + 4);
if (S_DbUrl.charAt(0) != "/") {
    S_DbUrl = "/" + S_DbUrl
}
if (window.S_DbPath == null) {
    S_DbPath = S_DbUrl.substring(0, S_DbUrl.lastIndexOf("/"))
}
if (window.S_SetupPath == null) {
    S_SetupPath = S_DbPath.substring(0, S_DbPath.lastIndexOf("/"))
}
if (window.S_JsFileList == null) {
    S_JsFileList = new Array
}
var isLoadPersonList = true;
var isSync = true;
if (!isLoadPersonList) {
    isSync = false
}
var TreeNodeUNIDCounter = 0;
var preloadArray = new Array;
var ImgPathPrefix = "";
var nodeViewStyle = new Object;
var CurrentUserTree;
EventHandler = new Object;
var S_IniValueList = null;
EventHandler.ObjectList = new Array;
var LKS_Tree;
function generateTree() {
    ImgPathPrefix = S_DbPath + "/images/tree/";
    var f = new Array;
    // var g = document.all.DIV_TreeContent.innerText.replace(/^\s*/, "").split("\r\n");
    var g =document.all.DIV_TreeContent.innerText.replace(/(\r\n)|(\n)/g,'<br>').split('<br>')
    var e = getTreeNodeInfo(g[0]);
    if (e == null) {
        return false
    }
    var d, c;
    LKSTree = createTreeBase(e.title, "LKSTree", document.all.treeDiv);
    LKSTree.Target = "viewFrame";
    LKSTree.EnableRightMenu();
    f[0] = LKSTree.TreeRoot;
    f[0].target = e.target;
    f[0].href = e.href;
    f[0].IsExpanded = true;
    for (d = 1; d < g.length; d++) {
        if (g[d] == "") {
            continue
        }
        e = getTreeNodeInfo(g[d]);
        if (e == null) {
            continue
        }
        c = e.index;
        if (isNaN(c) || f[c] == null) {
            continue
        }
        switch (e.type) {
        case "C":
            var b = location.protocol;
            var a = e.href;
            a = a.replace(/%网络协议%/i, b);
            f[c + 1] = appendChild(f[c], e.title, a, "", e.target);
            f[c + 1].IsExpanded = e.expand;
            break;
        case "V":
            if (e.view.substring(e.view.length - 9, e.view.length - 1) == ":sepstr=") {
                appendView(f[c], e.view.substring(0, e.view.length - 9), e.href, e.target, null, e.view.substring(e.view.length - 1))
            } else {
                appendView(f[c], e.view, e.href, e.target)
            }
            break;
        case "U":
            appendUnit(f[c], e.title, e.href, "", "", e.target);
            break;
        case "P":
            appendUnit(f[c], e.title, e.href, "", "M", e.target)
        }
    }
    LKSTree.Show()
}
function getTreeNodeInfo(c) {
    c = c.split("|");
    if (c.length < 5) {
        return null
    }
    var b = new Array;
    b.index = parseInt(c[0]);
    b.expand = (c[1] == "E");
    b.type = c[2];
    if (c[2] == "V") {
        b.view = c[3]
    } else {
        b.title = c[3]
    }
    b.target = c[4];
    b.href = c[5];
    for (var a = 6; a < c.length; a++) {
        b.href += "|" + c[a]
    }
    return b
}
EventHandler.AddObject = function(a) {
    this.ObjectList[this.ObjectList.length] = a
}
;
function createTreeBase(b, c, a) {
    return BuildUserTreeView(c, b, a)
}
function BuildUserTreeView(e, d, c) {
    var b = new TreeNode(null,d,"Group","");
    var a = new UserTreeView();
    a.RefName = e;
    a.DOMElement = c;
    a.TreeRoot = b;
    CurrentUserTree = a;
    return a
}
function TreeNode(j, g, f, a, d, h) {
    var b, c, e;
    if (j != null) {
        if (d == null || d == "") {
            d = j.target
        }
        if (f == null || f == "") {
            f = j.type
        }
    } else {
        if (d == null) {
            d = ""
        }
        if (f == null) {
            f = ""
        }
    }
    this.id = TreeNodeUNIDCounter++;
    this.title = g;
    this.type = f;
    this.parent = j;
    this.href = a;
    this.target = d;
    this.parameter = h;
    this.ImgOpened = "";
    this.ImgClosed = "";
    this.HasNotFetchChildrenNode = 0;
    this.CreatedByAppendView = 0;
    this.MenuType = new Array();
    this.MenuTarget = new Array();
    this.ViewName = new Array();
    this.HrefPrefix = new Array();
    this.LevelSep = new Array();
    this.parameterlist = new Array();
    this.ViewInfo = new Array();
    this.removeNode = TreeNode_RemoveNode;
    this.insertBefore = TreeNode_InsertBefore;
    this.setHTMLDirty = TreeNode_SetHTMLDirty;
    if (j == null) {
        this.prevsibling = null;
        this.nextsibling = null;
        this.firstchild = null;
        this.lastchild = null
    } else {
        c = j.lastchild;
        if (c == null) {
            e = j.firstchild;
            j.firstchild = this;
            this.nextsibling = e;
            this.prevsibling = null;
            if (e != null) {
                e.prevsibling = this
            }
        } else {
            e = c.nextsibling;
            c.nextsibling = this;
            this.nextsibling = e;
            this.prevsibling = c;
            if (e != null) {
                e.prevsibling = this
            }
        }
        j.lastchild = this
    }
}
function UserTreeView() {
    this.RefName = "";
    this.TreeRoot = null;
    this.ShowCheckBox = false;
    this.IsMultSel = true;
    this.LastCheckedNode = null;
    this.CurrentNodeCSS = 'style="background-color: #FFFFCC; border: 1px solid;"';
    this.CurrentNodeID = -1;
    this.DOMElement = null;
    this.Target = "";
    this.NavigateEnabled = true;
    this.ClickCaptionExpand = false;
    this.NavigateWhenExpand = false;
    this.ImgVertLine = ImgPathPrefix + "vertline1.3.gif";
    this.ImgNode = ImgPathPrefix + "node1.3.gif";
    this.ImgNodePlus = ImgPathPrefix + "nodeplus1.4.gif";
    this.ImgNodeMinus = ImgPathPrefix + "nodeminus1.4.gif";
    this.ImgLastNode = ImgPathPrefix + "lastnode1.3.gif";
    this.ImgLastNodePlus = ImgPathPrefix + "lastnodeplus1.4.gif";
    this.ImgLastNodeMinus = ImgPathPrefix + "lastnodeminus1.4.gif";
    this.ImgOpenedFolder = ImgPathPrefix + "openfolder.gif";
    this.ImgClosedFolder = ImgPathPrefix + "closedfolder.gif";
    this.ImgUnit = ImgPathPrefix + "unit.gif";
    this.ImgPerson = ImgPathPrefix + "person.gif";
    this.ImgBlank = ImgPathPrefix + "blank1.3.png";
    this.ImgLeaf = ImgPathPrefix + "link.gif";
    PreloadImage(this.ImgVertLine);
    PreloadImage(this.ImgNode);
    PreloadImage(this.ImgNodePlus);
    PreloadImage(this.ImgNodeMinus);
    PreloadImage(this.ImgLastNode);
    PreloadImage(this.ImgLastNodePlus);
    PreloadImage(this.ImgLastNodeMinus);
    PreloadImage(this.ImgOpenedFolder);
    PreloadImage(this.ImgClosedFolder);
    PreloadImage(this.ImgBlank);
    PreloadImage(this.ImgLeaf);
    this.DrawNodeIndentHTML = UserTreeViewDrawNodeIndentHTML;
    this.DrawNodeOuterHTML = UserTreeViewDrawNodeOuterHTML;
    this.DrawNodeInnerHTML = UserTreeViewDrawNodeInnerHTML;
    this.DrawNode = UserTreeViewDrawNode;
    this.RefreshNode = UserTreeViewRefreshNode;
    this.SetCurrentNode = UserTreeViewSetCurrentNode;
    this.FetchChildrenNode = UserTreeViewFetchChildrenNode;
    this.OpenHref = UserTreeViewOpenHref;
    this.EnableRightMenu = UserTreeEnableRightMenu;
    this.ExpandNode = UserTreeViewExpandNode;
    this.OpenFolder = UserTreeViewOpenFolder;
    this.Show = UserTreeViewShow;
    this.Search = UserTreeViewSearch;
    this.GetNextSearchNode = UserTreeViewGetNextSearchNode;
    this.AddToMap = UserTreeViewAddToMap;
    this.AddURLToNav = UserTreeViewAddURLToNav
}
function UserTreeEnableRightMenu() {
    document.oncontextmenu = function() {
        IncludeJsFile("portal_rightmenu.js", null, false);
        return showRightMenu()
    }
}
function UserTreeViewSetCurrentNode(d, e) {
    if (this.CurrentNodeID == d.id) {
        return
    }
    var c, a, b;
    if (this.CurrentNodeID == -1) {
        this.CurrentNodeID = d.id
    } else {
        b = GetNodeByID(this.TreeRoot, this.CurrentNodeID);
        if (b == null) {
            this.CurrentNodeID = d.id
        } else {
            this.CurrentNodeID = d.id;
            this.RefreshNode(b)
        }
    }
    c = GetNodeByID(this.TreeRoot, this.CurrentNodeID);
    for (a = 0; c.parent != null; c = c.parent) {
        if (!c.parent.IsExpanded) {
            this.ExpandNode(c.parent.id)
        }
    }
    this.RefreshNode(d);
    if (e) {
        setTimeout("try{document.all.TVN_" + this.CurrentNodeID + ".scrollIntoView();setSearchBarposition('document.all.TVN_" + this.CurrentNodeID + "');}catch(e){}", 10)
    }
}
function GetNodeByID(b, d) {
    var c, a;
    if (b == null) {
        return null
    }
    if (b.id == d) {
        return b
    }
    c = b.firstchild;
    while (c != null) {
        a = GetNodeByID(c, d);
        if (a == null) {
            c = c.nextsibling
        } else {
            return a
        }
    }
    return null
}
function MenuItem(b, a, c) {
    this.Name = b;
    this.Location = a;
    this.Argument = c
}
function RightMenuObject(a) {
    this.MenuItems = new Array;
    this.PopWin = new PopWinObject();
    this.PopWin.ClearWhenHide = true;
    this.PopWin.Document.oncontextmenu = function() {
        return false
    }
    ;
    this.Width = a ? a : 0;
    this.PopWin.RowMouseOver = function(b) {
        b.style.color = "#ffffff";
        b.style.backgroundColor = "#000080"
    }
    ;
    this.PopWin.RowMouseOut = function(b) {
        b.style.color = "#000000";
        b.style.backgroundColor = "#cccccc"
    }
    ;
    this.AddItem = function(c, b, d) {
        this.MenuItems[this.MenuItems.length] = new MenuItem(c,b,d)
    }
    ;
    this.GetMenu = function() {
        var b = "<table cellspacing=0>";
        for (var c = 0; c < this.MenuItems.length; c++) {
            b += "<tr><td><button style='font-size:9pt; color:#000000; background-color:#cccccc; text-align:left; padding:2px 16px 1px 12px;border:0 solid;";
            if (this.Width != 0) {
                b += "width:" + this.Width + "'"
            } else {
                b += "'"
            }
            b += " onmouseout='PopWinObject.RowMouseOut(this)'";
            b += " onmouseover='PopWinObject.RowMouseOver(this)'";
            if (this.MenuItems[c].Location) {
                b += ' onclick="PopWinObject.Hide();PopWinObject.Parent.' + this.MenuItems[c].Location + "(" + (this.MenuItems[c].Argument ? this.MenuItems[c].Argument : "") + ');"'
            }
            b += ">";
            b += this.MenuItems[c].Name;
            b += "</button></td></tr>"
        }
        b += "</table>";
        return b
    }
    ;
    this.Show = function() {
        this.PopWin.OnShow = function() {
            var e = this.Document.all.tags("BUTTON");
            var c = 0;
            for (var d = 0; d < e.length; d++) {
                var b = e[d].clientWidth;
                if (e[d].clientWidth > c) {
                    c = e[d].clientWidth
                }
            }
            for (d = 0; d < e.length; d++) {
                e[d].style.width = c
            }
        }
        ;
        this.PopWin.PopByMouse(this.GetMenu())
    }
}
function TreeNode_RemoveNode() {
    var b = this.parent;
    if (b == null) {
        return false
    }
    var a = this.nextsibling;
    var c = this.prevsibling;
    if (a == null) {
        b.lastchild = c
    } else {
        a.prevsibling = c;
        a.setHTMLDirty()
    }
    if (c == null) {
        b.firstchild = a
    } else {
        c.nextsibling = a;
        c.setHTMLDirty()
    }
    b.setHTMLDirty();
    this.parent = null;
    this.prevsibling = null;
    this.nextsibling = null;
    return true
}
function TreeNode_InsertBefore(c, a) {
    if (a != null && a.parent != this) {
        return false
    }
    var b, d;
    for (b = this; b != null; b = b.parent) {
        if (b == c) {
            return false
        }
    }
    d = a == null ? this.lastchild : a.prevsibling;
    c.removeNode();
    c.parent = this;
    c.nextsibling = a;
    c.prevsibling = d;
    if (a == null) {
        this.lastchild = c
    } else {
        a.prevsibling = c;
        a.setHTMLDirty()
    }
    if (d == null) {
        this.firstchild = c
    } else {
        d.nextsibling = c;
        d.setHTMLDirty()
    }
    this.setHTMLDirty();
    c.setHTMLDirty();
    return true
}
function TreeNode_SetHTMLDirty() {
    this.IsExpandedHTMLDirty = true;
    this.IsCollapsedHTMLDirty = true;
    for (var a = this.firstchild; a != null; a = a.nextsibling) {
        a.setHTMLDirty()
    }
}
function PreloadImage(a) {
    var b = preloadArray.length;
    preloadArray[b] = new Image;
    preloadArray[b].src = a
}
function appendChild(c, f, a, b, e, g) {
    var d = new TreeNode(c,f,b,a,e,g);
    return d
}
function UserTreeViewShow() {
    var a = this.DrawNode(this.TreeRoot, 0, true);
    this.DOMElement.innerHTML = a
}
function UserTreeViewDrawNode(e, a, d) {
    if (e.IsExpanded && e.HasNotFetchChildrenNode) {
        this.FetchChildrenNode(e)
    }
    var b;
    var c;
    var f;
    f = this.DrawNodeOuterHTML(e, a, d);
    d = d && e.IsExpanded;
    a++;
    if (e.IsExpanded) {
        b = e.firstchild;
        while (b != null) {
            f = f + this.DrawNode(b, a, d);
            b = b.nextsibling
        }
    }
    return f
}
function UserTreeViewDrawNodeOuterHTML(c, a, b) {
    if (!b) {
        return ""
    }
    if (c.IsExpanded) {
        if ((c.IsExpandedHTMLDirty == null) || c.IsExpandedHTMLDirty || c.OuterHTMLExpanded == null) {
            c.OuterHTMLExpanded = "<table id='TVN_" + c.id + "' cellpadding=0 cellspacing=0 border=0>" + this.DrawNodeInnerHTML(c, a) + "</table>"
        }
        c.IsExpandedHTMLDirty = false;
        return c.OuterHTMLExpanded
    } else {
        if ((c.IsCollapsedHTMLDirty == null) || c.IsCollapsedHTMLDirty || c.OuterHTMLCollapsed == null) {
            c.OuterHTMLCollapsed = "<table id='TVN_" + c.id + "' cellpadding=0 cellspacing=0 border=0>" + this.DrawNodeInnerHTML(c, a) + "</table>"
        }
        c.IsCollapsedHTMLDirty = false;
        return c.OuterHTMLCollapsed
    }
}
function UserTreeViewDrawNodeInnerHTML(c, a) {
    var g;
    ReloadUserTreeViewStyle(c, this);
    if (this.OnNodeQueryDraw != null) {
        g = this.OnNodeQueryDraw(c, nodeViewStyle);
        if (g != null) {
            return g
        }
    }
    var f, e, b, d;
    f = "<tr><td valign=middle nowrap>";
    f = f + this.DrawNodeIndentHTML(c, a);
    f = f + "</td><td valign=middle nowrap " + (this.CurrentNodeID == c.id ? nodeViewStyle.CurrentNodeCSS : "") + ">";
    if (c.IsChecked == null) {
        c.IsChecked = false
    }
    if (nodeViewStyle.CheckboxType != "") {
        e = "<input onClick='" + this.RefName + ".CheckNode(" + c.id + ")' type=" + nodeViewStyle.CheckboxType + " id='CHK_" + c.id + "' " + (c.IsChecked ? "Checked" : "") + ">"
    } else {
        e = ""
    }
    if (c.href != "" && this.ClickCaptionExpand == false && this.NavigateEnabled) {
        d = c.target == "" ? this.Target : c.target;
        f = f + "<a lks_nodeid=" + c.id + ' title="' + m_HtmlEscape(c.title) + '" href="javascript:' + this.RefName + ".OpenFolder(" + c.id + ",'" + d + "')\">" + e + (c.text ? c.text : c.title) + "</a>"
    } else {
        f = f + "<a lks_nodeid=" + c.id + ' title="' + m_HtmlEscape(c.title) + '" href="javascript:' + this.RefName + ".ExpandNode(" + c.id + ')">' + e + (c.text ? c.text : c.title) + "</a>"
    }
    f += "</td></tr>";
    if (this.OnNodePostDraw != null) {
        g = this.OnNodePostDraw(c, f);
        if (g != null) {
            return g
        }
    }
    return f
}
function ReloadUserTreeViewStyle(a, b) {
    nodeViewStyle.ImgVertLine = b.ImgVertLine;
    nodeViewStyle.ImgNode = b.ImgNode;
    nodeViewStyle.ImgNodePlus = b.ImgNodePlus;
    nodeViewStyle.ImgNodeMinus = b.ImgNodeMinus;
    nodeViewStyle.ImgLastNode = b.ImgLastNode;
    nodeViewStyle.ImgLastNodePlus = b.ImgLastNodePlus;
    nodeViewStyle.ImgLastNodeMinus = b.ImgLastNodeMinus;
    nodeViewStyle.ImgBlank = b.ImgBlank;
    nodeViewStyle.CurrentNodeCSS = b.CurrentNodeCSS;
    switch (a.type) {
    case "Unit":
        nodeViewStyle.ImgOpenedFolder = b.ImgUnit;
        nodeViewStyle.ImgClosedFolder = b.ImgUnit;
        nodeViewStyle.ImgLeaf = b.ImgUnit;
        break;
    case "Person":
        nodeViewStyle.ImgOpenedFolder = b.ImgPerson;
        nodeViewStyle.ImgClosedFolder = b.ImgPerson;
        nodeViewStyle.ImgLeaf = b.ImgPerson;
        break;
    default:
        nodeViewStyle.ImgOpenedFolder = b.ImgOpenedFolder;
        nodeViewStyle.ImgClosedFolder = b.ImgClosedFolder;
        nodeViewStyle.ImgLeaf = b.ImgLeaf
    }
    if (b.ShowCheckBox) {
        if (b.IsMultSel) {
            nodeViewStyle.CheckboxType = "checkbox"
        } else {
            nodeViewStyle.CheckboxType = "radio"
        }
    } else {
        nodeViewStyle.CheckboxType = ""
    }
}
function UserTreeViewDrawNodeIndentHTML(e, c) {
    var d;
    var a;
    var b;
    if (e == null) {
        return ""
    }
    b = (!e.HasNotFetchChildrenNode && e.firstchild == null);
    if (b) {
        a = "<img src=" + nodeViewStyle.ImgLeaf + ">"
    } else {
        a = '<a href="javascript:' + this.RefName + ".ExpandNode(" + e.id + ')">' + (e.IsExpanded ? "<img src=" + nodeViewStyle.ImgOpenedFolder + " border=0>" : "<img src=" + nodeViewStyle.ImgClosedFolder + " border=0>") + "</a>"
    }
    if (c <= 0) {
        return a
    }
    if (e.nextsibling == null) {
        if (b) {
            a = "<img src=" + nodeViewStyle.ImgLastNode + ">" + a
        } else {
            a = '<a href="javascript:' + this.RefName + ".ExpandNode(" + e.id + ')">' + (e.IsExpanded ? "<img src=" + nodeViewStyle.ImgLastNodeMinus + " border=0>" : "<img src=" + nodeViewStyle.ImgLastNodePlus + " border=0>") + "</a>" + a
        }
    } else {
        if (b) {
            a = "<img src=" + nodeViewStyle.ImgNode + ">" + a
        } else {
            a = '<a href="javascript:' + this.RefName + ".ExpandNode(" + e.id + ')">' + (e.IsExpanded ? "<img src=" + nodeViewStyle.ImgNodeMinus + " border=0>" : "<img src=" + nodeViewStyle.ImgNodePlus + " border=0>") + "</a>" + a
        }
    }
    d = e.parent;
    for (i = c - 1; i > 0; i--) {
        if (d == null) {
            return a
        } else {
            if (d.nextsibling == null) {
                a = "<img src=" + nodeViewStyle.ImgBlank + ">" + a
            } else {
                a = "<img src=" + nodeViewStyle.ImgVertLine + ">" + a
            }
            d = d.parent
        }
    }
    return a
}
function m_HtmlEscape(b) {
    var d, a;
    var e, c;
    d = b.length;
    e = "";
    for (a = 0; a < d; a++) {
        c = b.charAt(a);
        if (c == "&") {
            e += "&amp;"
        } else {
            if (c == '"') {
                e += "&quot;"
            } else {
                if (c == " ") {
                    e += "&nbsp;"
                } else {
                    if (c == "<") {
                        e += "&lt;"
                    } else {
                        if (c == ">") {
                            e += "&gt;"
                        } else {
                            e += c
                        }
                    }
                }
            }
        }
    }
    return e
}
function UserTreeViewExpandNode(id) {
    var node;
    node = GetNodeByID(this.TreeRoot, id);
    if (this.OnNodeQueryExpand != null) {
        if (!this.OnNodeQueryExpand(node)) {
            return
        }
    }
    if (node == null) {
        return
    }
    if (node.href != "" && this.NavigateWhenExpand && this.NavigateEnabled) {
        this.OpenHref(node, node.target)
    }
    var now, indent_level;
    node.IsExpanded = !node.IsExpanded;
    indent_level = 0;
    now = node;
    while (now.parent != null) {
        indent_level++;
        now = now.parent
    }
    var element = eval("document.all.TVN_" + node.id);
    if (node.IsExpanded) {
        if (element != null) {
            element.outerHTML = this.DrawNode(node, indent_level, true)
        }
    } else {
        if (element != null) {
            element.outerHTML = this.DrawNodeOuterHTML(node, indent_level, true)
        }
        HideTreeNodeChildren(node)
    }
    if (this.OnNodePostExpand != null) {
        this.OnNodePostExpand(node)
    }
}
function UserTreeViewOpenFolder(b, a) {
    if (!a) {
        a = this.Target
    }
    node = GetNodeByID(this.TreeRoot, b);
    if (this.OnFolderQueryOpen != null) {
        if (!this.OnFolderQueryOpen(node, a)) {
            this.SetCurrentNode(node);
            return
        }
    }
    this.OpenHref(node, a);
    this.SetCurrentNode(node);
    if (this.OnFolderPostOpen != null) {
        this.OnFolderPostOpen(node, a)
    }
}
function UserTreeViewOpenHref(node, target) {
    var strhref = node.href;
    var i = node.href.indexOf("javascript:");
    if (i == 0) {
        eval(node.href.substring(11));
        return
    }
    i = node.href.indexOf("?");
    if (i > -1 && target.toLowerCase() == "viewframe") {
        if (window.S_CurrentStyle) {
            strhref += "&css=" + S_CurrentStyle
        }
        if (node.info) {
            strhref += "&Info=" + encodeURI(node.info)
        }
        var strpath = GetNodePath(node, ">>").substring(2);
        strhref += "&Path=" + encodeURI(strpath)
    }
    if (window.S_ICM_SERVER != null && strhref.indexOf("/") == 0 && S_ICM_SERVER != "") {
        strhref = S_ICM_SERVER + strhref
    }
    window.open(strhref, target)
}
function UserTreeViewRefreshNode(d) {
    var c = document.all["TVN_" + d.id];
    d.IsExpandedHTMLDirty = true;
    d.IsCollapsedHTMLDirty = true;
    var a = 0;
    for (var b = d; b.parent != null; b = b.parent) {
        a++
    }
    if (c != null) {
        c.outerHTML = this.DrawNodeOuterHTML(d, a, true)
    }
}
function PopWinObject() {
    var a = document.createElement("div");
    document.body.insertBefore(a);
    a.outerHTML = "<iframe IsPopWin=1 id=PopWinIframe width=1 height=1 frameborder=0 scrolling=no style='position:absolute;display:none;z-index:99999'></iframe>";
    this.Iframe = document.all.PopWinIframe;
    this.Iframe.Object = this;
    this.Parent = self;
    this.Window = document.frames("PopWinIframe");
    this.Document = document.frames("PopWinIframe").document;
    document.frames("PopWinIframe").document.open();
    document.frames("PopWinIframe").document.close();
    document.frames("PopWinIframe").PopWinObject = this;
    this.Body = document.frames("PopWinIframe").document.body;
    this.Iframe.removeAttribute("id");
    this.Body.style.border = "2 outset";
    this.Body.style.marginTop = 0;
    this.Body.style.marginLeft = 0;
    this.Body.style.marginRight = 0;
    this.Body.style.marginBottom = 0;
    this.Body.style.backgroundColor = "#cccccc";
    this.IsAutoSize = true;
    this.HideWhenMouseOut = true;
    this.ClearWhenHide = false;
    EventHandler.AddObject(this);
    this.Iframe.onmouseover = function() {
        this.Object.Display = "block"
    }
    ;
    this.Iframe.onmouseout = function() {
        this.Object.Display = "none";
        this.Object.Window.setTimeout("if(PopWinObject.Display=='none' && PopWinObject.HideWhenMouseOut) PopWinObject.Hide();", 2000)
    }
    ;
    this.Show = function(b, f, c, e, d) {
        if (d) {
            this.Body.innerHTML = d
        }
        if (e) {
            this.Iframe.style.posHeight = e
        }
        if (c) {
            this.Iframe.style.posWidth = c
        }
        if (f) {
            this.Iframe.style.posTop = f
        }
        if (b) {
            this.Iframe.style.posLeft = b
        }
        this.Iframe.style.display = "block";
        if (this.IsAutoSize) {
            this.Window.setTimeout("PopWinObject.AutoSize();", 1)
        }
        if (this.OnShow) {
            this.Window.setTimeout("PopWinObject.OnShow();", 10)
        }
    }
    ;
    this.AutoSize = function() {
        this.Iframe.style.posWidth = this.Body.scrollWidth;
        this.Iframe.style.posHeight = this.Body.scrollHeight
    }
    ;
    this.BestPosition = function() {
        var c, e, b, d;
        b = document.body.clientWidth - this.ReferX - this.Iframe.style.posWidth;
        d = document.body.clientHeight - this.ReferY - this.Iframe.style.posHeight;
        if (b < 0) {
            this.Iframe.style.posLeft += b
        }
        if (d < 0) {
            this.Iframe.style.posTop += d
        }
    }
    ;
    this.PopByPoint = function(c, b, d) {
        this.ReferX = b;
        this.ReferY = d;
        this.Show(this.ReferX + document.body.scrollLeft, this.ReferY + document.body.scrollTop, null, null, c);
        this.Window.setTimeout("PopWinObject.BestPosition();", 100)
    }
    ;
    this.PopByMouse = function(b) {
        this.ReferX = event.x;
        this.ReferY = event.y;
        this.Show(this.ReferX + document.body.scrollLeft, this.ReferY + document.body.scrollTop, null, null, b);
        this.Window.setTimeout("PopWinObject.BestPosition();", 100)
    }
    ;
    this.Hide = function() {
        if (this.Iframe.style.display != "none") {
            this.Iframe.style.display = "none"
        }
    }
    ;
    this.OnDocumentMouseDown = function() {
        this.Hide()
    }
}
document.onmousedown = function() {
    for (var a = 0; a < EventHandler.ObjectList.length; a++) {
        if (EventHandler.ObjectList[a].OnDocumentMouseDown) {
            try {
                EventHandler.ObjectList[a].OnDocumentMouseDown()
            } catch (b) {}
        }
    }
}
;
function showTreeSearchBar() {
    if (window.DIV_SearchBar) {
        if (DIV_SearchBar.style.display != "") {
            DIV_SearchBar.style.display = "";
            document.all.F_TreeKeyword.focus()
        } else {
            DIV_SearchBar.style.display = "none"
        }
        return
    }
    var a = document.createElement("<div id=DIV_SearchBar style='position:absolute;z-index:2; top:5px; left:5px; width:100%'></div>");
    var b = "<table id=TB_SearchBar class=seachbar width=100% cellspacing=1 cellpadding=2><tr><td bgcolor=#FFFFFF>";
    b += "<table width=100% cellpadding=0 cellspacing=1 border=0><tr valign=bottom>";
    b += "<td nowrap width=0>关键字</td>";
    b += '<td colspan=2 width=100%><input id=F_TreeKeyword class=texttree onkeyup="if(event.keyCode==13)Btn_TreeNext.click();"></td>';
    b += "</tr><tr valign=bottom>";
    b += "<td>搜 索</td>";
    b += '<td nowrap align=left><input id=Btn_TreePre class=btntree type=button value=↑ title=查找上一个 onclick="' + CurrentUserTree.RefName + '.Search(-1);">&nbsp;<input id=Btn_TreeNext class=btntree type=button value=↓ title=查找下一个 onclick="' + CurrentUserTree.RefName + '.Search(1);">&nbsp;</td>';
    b += '<td nowrap align=right><input id=Btn_TreeMore class=btntree type=button value=□ title=最大化 onclick="UserTreeViewChgSearchBarStyle();">&nbsp;<input id=Btn_TreeLock class=btntree type=button value=× onclick="UserTreeViewHideSearchBar();" title=隐藏搜索条></td>';
    b += "</tr></table>";
    b += "</td></tr><tr style='display:none'><td bgcolor=#FFFFFF>";
    b += "<input name=F_TreeSearchCase type=checkbox>区分大小写";
    b += "</td></tr><tr style='display:none'><td bgcolor=#FFFFFF>";
    b += "&nbsp;搜索起始节点：<br><input name=F_TreeSearchType type=radio>根节点<br><input name=F_TreeSearchType type=radio checked>当前节点";
    b += "</td></tr></table>";
    a.innerHTML = b;
    document.body.appendChild(a);
    setTimeout("document.all.F_TreeKeyword.focus();", 100);
    window.onscroll = UserTreeViewOnWinScroll
}
function UserTreeViewOnWinScroll() {
    DIV_SearchBar.style.top = document.body.scrollTop + 5;
    DIV_SearchBar.style.left = document.body.scrollLeft + 5
}
function UserTreeViewSearch(d) {
    var a = document.all.F_TreeSearchCase.checked;
    var c = a ? F_TreeKeyword.value : F_TreeKeyword.value.toLowerCase();
    if (c == "") {
        alert("请输入关键字!");
        F_TreeKeyword.focus();
        return false
    }
    var b = this.TreeRoot;
    if (document.all.F_TreeSearchType[1].checked && this.CurrentNodeID > -1) {
        b = this.GetNextSearchNode(GetNodeByID(b, this.CurrentNodeID), d)
    }
    for (; b != null; b = this.GetNextSearchNode(b, d)) {
        if ((a ? b.title : b.title.toLowerCase()).indexOf(c) > -1) {
            break
        }
    }
    if (b == null) {
        alert("关键字“" + c + "”未找到！")
    } else {
        this.SetCurrentNode(b, true);
        document.all.F_TreeSearchType[1].checked = true;
        UserTreeViewChgSearchBarStyle(0)
    }
}
function UserTreeViewChgSearchBarStyle(a) {
    if (a == 0) {
        Btn_TreeMore.value = "─"
    } else {
        if (a == 1) {
            Btn_TreeMore.value = "□"
        }
    }
    var b = "";
    if (Btn_TreeMore.value == "□") {
        Btn_TreeMore.value = "─";
        Btn_TreeMore.title = "最小化"
    } else {
        Btn_TreeMore.value = "□";
        Btn_TreeMore.title = "最大化";
        b = "none"
    }
    for (var c = 1; c < TB_SearchBar.rows.length; c++) {
        TB_SearchBar.rows[c].style.display = b
    }
}
function UserTreeViewHideSearchBar() {
    DIV_SearchBar.style.display = "none"
}
function UserTreeViewGetNextSearchNode(b, c) {
    var a;
    if (c == 1) {
        if (b.HasNotFetchChildrenNode) {
            this.FetchChildrenNode(b)
        }
        if (b.firstchild != null) {
            return b.firstchild
        }
        if (b.nextsibling != null) {
            return b.nextsibling
        }
        for (a = b.parent; a != null; a = a.parent) {
            if (a.nextsibling != null) {
                return a.nextsibling
            }
        }
    } else {
        if (b.prevsibling != null) {
            for (a = b.prevsibling; true; a = a.lastchild) {
                if (a.HasNotFetchChildrenNode) {
                    this.FetchChildrenNode(a)
                }
                if (a.lastchild == null) {
                    return a
                }
            }
        }
        return b.parent
    }
    return null
}
function UserTreeViewAddToMap(a) {
    var b = "";
    if (a) {
        b = "&nodeid=" + CurrentUserTree.CurrentNodeID
    }
    window.open(S_SetupPath + "/koa/lks_workplace.nsf/FM_SelectNav?OpenForm" + b, "_blank", "resizable=yes scrollbars=yes")
}
function UserTreeViewAddURLToNav(a) {
    window.open(S_SetupPath + "/koa/lks_workplace.nsf/FM_Navigation?OpenForm&type=" + a + "&url=" + location.href, "_blank")
}
function appendView(f, a, e, g, d, c, h, b) {
    f.MenuType[f.MenuType.length] = (d == null) ? "" : d;
    f.MenuTarget[f.MenuTarget.length] = (g == null) ? "" : g;
    f.ViewName[f.ViewName.length] = a;
    f.HrefPrefix[f.HrefPrefix.length] = e;
    f.LevelSep[f.LevelSep.length] = (c == null) ? "/" : c;
    f.parameterlist[f.parameterlist.length] = h;
    f.ViewInfo[f.ViewInfo.length] = b;
    f.HasNotFetchChildrenNode = 1;
    f.CreatedByAppendView = 2;
    if (f.id == "0") {
        UserTreeViewFetchChildrenNode(f)
    }
}
function appendUnit(b, j, g, f, a, e, c, k, h) {
    e = (e == null) ? "" : e;
    f = (f == null) ? "" : f;
    a = (a == null) ? "" : a;
    h = (h == null) ? true : false;
    if (h && c == null) {
        if (!l) {
            var l = getPeopleAccess()
        }
        c = l.baseUnit
    } else {
        c = (c == null) ? "-1" : c
    }
    c = (c == null) ? "-1" : c;
    var d = appendChild(b, j, g + "&Info=" + encodeURI(c), f, e, k);
    d.MenuType[0] = a;
    d.MenuTarget[0] = e;
    d.ViewName[0] = c;
    d.HrefPrefix[0] = g;
    d.parameterlist[0] = k;
    d.HasNotFetchChildrenNode = 1;
    d.CreatedByAppendView = 3;
    if (d.id == "0") {
        UserTreeViewFetchChildrenNode(d)
    }
    return d
}
function getPeopleAccess() {
    var h = [];
    var g = new ActiveXObject("MSXML.DOMDocument");
    g.async = false;
    if (typeof (S_SetupPath) != "undefined") {
        g.load(S_SetupPath + "/sys/lks_sysconfig.nsf/AG_AddressGetInfo?openagent")
    } else {
        g.load("../lks_sysconfig.nsf/AG_AddressGetInfo?openagent")
    }
    var a = g.selectNodes("/viewentries/viewentry");
    h.CurUserAD = GetChildNodeText(a[0], "CurUserAD");
    var j = GetChildNodeText(a[0], "DepDisLevel");
    h.DepDisLevel = (j == "") ? -1 : parseInt(j);
    var c = GetChildNodeText(a[0], "DepExpandLevel");
    h.DepExpandLevel = (c == "") ? 1 : parseInt(c);
    var e = GetChildNodeText(a[0], "AllExpandLevel");
    h.AllExpandLevel = (e == "") ? 1 : parseInt(e);
    var f = GetChildNodeText(a[0], "MyExpandLevel");
    h.MyExpandLevel = (f == "") ? 1 : parseInt(f);
    var k = GetChildNodeText(a[0], "PostDisLevel");
    h.PostDisLevel = (k == "") ? 3 : parseInt(k);
    h.CurUserFullDep = GetChildNodeText(a[0], "CurUserFullDep").split("/");
    h.CurUserAllDep = GetChildNodeText(a[0], "CurUserAllDep").split("/");
    b(h.CurUserAD, h.CurUserAllDep);
    return h;
    function b(n, l) {
        var m = d(n, l);
        if (m.baseUnit == null) {
            h.baseUnit = "-1"
        } else {
            h.baseUnit = m.baseUnit
        }
        if (m.searchPost == null) {
            h.searchPost = true
        } else {
            if (m.searchPost == "false" || m.searchPost == "0") {
                h.searchPost = false
            } else {
                h.searchPost = true
            }
        }
        if (m.searchUnit == null) {
            h.searchUnit = true
        } else {
            if (m.searchUnit == "false" || m.searchUnit == "0") {
                h.searchUnit = false
            } else {
                h.searchUnit = true
            }
        }
        if (m.searchPeople == null) {
            h.searchPeople = true
        } else {
            if (m.searchPeople == "false" || m.searchPeople == "0") {
                h.searchPeople = false
            } else {
                h.searchPeople = true
            }
        }
        if (m.mailForbidUnit == null) {
            h.mailForbidUnit = new Array()
        } else {
            h.mailForbidUnit = m.mailForbidUnit.split(";")
        }
    }
    function d(o, v) {
        var n = new Array();
        var t = new ActiveXObject("MSXML.DOMDocument");
        t.async = false;
        if (typeof (S_SetupPath) != "undefined") {
            t.load(S_SetupPath + "/sys/html/addressaccess.xml")
        } else {
            t.load("../html/addressaccess.xml")
        }
        if (t.parseError.errorCode != 0) {
            return n
        } else {
            if (v != null) {
                v[v.length] = o
            } else {
                v = new Array();
                v[0] = o
            }
            var m = t.selectNodes("/accessentries/accessentry");
            var r = null;
            var u = -1;
            if (m == null) {
                return null
            }
            for (var s = 0; s < m.length; s++) {
                tmpArray = m[s].getAttribute("name").toLowerCase().split(";");
                for (var q = 0; q < tmpArray.length; q++) {
                    if (tmpArray[q] == "default" && u == -1) {
                        r = m[s]
                    } else {
                        for (var p = 0; p < v.length; p++) {
                            if (tmpArray[q] == v[p].toLowerCase()) {
                                if (u < p) {
                                    r = m[s];
                                    u = p
                                }
                            }
                        }
                    }
                }
            }
            if (r != null) {
                var l = r.selectNodes("entrydata");
                if (l == null || l.length <= 0) {}
                for (var s = 0; s < l.length; s++) {
                    tmpStr = l[s].getAttribute("name");
                    if (tmpStr != null) {
                        n[tmpStr] = XMLGetNodeTextList(l[s], true, ";")
                    }
                }
            }
        }
        return n
    }
}
function UserTreeViewFetchChildrenNode(p) {
    if (this.OnChildrenNodeQueryFetch != null) {
        if (!this.OnChildrenNodeQueryFetch(p)) {
            return
        }
    }
    switch (p.CreatedByAppendView) {
    case 1:
    case 2:
        for (var t = 0; t < p.ViewName.length; t++) {
            var s = p.ViewName[t].split(/:(?!.*\/)/);
            var l;
            if (s.length > 1) {
                l = s[0];
                s[0] = parseInt(s[1]);
                s[1] = s[0] < 0 ? -1 : 1;
                s[0] = s[0] * s[1]
            } else {
                s[0] = 1;
                s[1] = 1;
                l = p.ViewName[t]
            }
            if (s[2] == null) {
                s[2] = 1
            } else {
                s[2] = parseInt(s[2])
            }
            var f = new ActiveXObject("MSXML.DOMDocument");
            f.async = false;
            var o = new Array;
            var a = new Array;
            var n = 0;
            var g = 1;
            var d;
            var h = l.indexOf("?") > 0 ? l : (l + "?readviewentries");
            if (p.ViewInfo[t] != null) {
                h += "&expand=" + p.ViewInfo[t].position + "&count=1000&start=" + p.ViewInfo[t].position + "."
            } else {
                h += "&collapseview&count=1000&start="
            }
            for (; true; ) {
                f = getXmlDoc(h + g + "&m_Seq=" + Math.random());
                o[n] = f.selectNodes("/viewentries/viewentry");
                if (p.ViewInfo[t] != null) {
                    d = p.ViewInfo[t].position.length + 1;
                    for (var r = o[n].length - 1; r > -1; r--) {
                        g = o[n][r].attributes.getNamedItem("position").text;
                        if (g.substring(0, d) == p.ViewInfo[t].position + ".") {
                            break
                        }
                    }
                    a[n] = r + 1
                } else {
                    a[n] = o[n].length
                }
                if (a[n] == 1000) {
                    g = o[n][999].attributes.getNamedItem("position").text;
                    d = g.lastIndexOf(".");
                    if (d > -1) {
                        g = g.substring(t)
                    }
                    g = parseInt(g) + 1
                } else {
                    break
                }
                n++
            }
            for (g = s[0] * s[1] == -1 ? n : 0; g >= 0 && g <= n; g += s[1]) {
                if (a[g] > 0) {
                    var q, b, c;
                    var e;
                    var r = s[0] * s[1] == -1 ? a[n] - 1 : 0;
                    for (; r >= 0 && r < a[g]; r += s[1]) {
                        e = o[g][r].firstChild.attributes.getNamedItem("columnnumber").text;
                        if (e == "0") {
                            q = o[g][r].firstChild.text;
                            b = q;
                            c = null;
                            if (s[0] != 1) {
                                d = q.indexOf(":");
                                c = d > -1 ? q.substring(0, d) : null;
                                q = d > -1 ? q.substring(d + 1) : q;
                                b = s[2] == 0 ? q : b
                            }
                            if (p.LevelSep[t] == "\\") {
                                if (q != "-1" && q != "-1/") {
                                    if (q.charAt(q.length - 1) == "/") {
                                        d = 1;
                                        q = q.substring(0, q.length - 1)
                                    } else {
                                        d = 0
                                    }
                                    var k = GetChildByTitle(p, q);
                                    if (k == null) {
                                        k = new TreeNode(p,q,"","")
                                    }
                                    if (d == 1) {
                                        k.type = p.MenuType[t];
                                        k.target = p.MenuTarget[t];
                                        k.parameter = p.parameterlist[t];
                                        k.info = (p.ViewInfo[t] == null) ? b : p.ViewInfo[t].info + "/" + b.substring(0, b.length - 1);
                                        k.order = c;
                                        k.href = p.HrefPrefix[t]
                                    } else {
                                        var m = new Object();
                                        m.info = (p.ViewInfo[t] == null) ? b : p.ViewInfo[t].info + "/" + b;
                                        m.position = o[g][r].attributes.getNamedItem("position").text;
                                        m.children = parseInt(o[g][r].attributes.getNamedItem("children").text);
                                        appendView(k, p.ViewName[t], p.HrefPrefix[t], p.MenuTarget[t], p.MenuType[t], "\\", p.parameterlist[t], m);
                                        k.CreatedByAppendView = 1
                                    }
                                }
                            } else {
                                if (q != "-1") {
                                    CreatePath(p, p.LevelSep[t] + q, p.MenuType[t], p.HrefPrefix[t], p.MenuTarget[t], p.LevelSep[t], p.parameterlist[t], b, c)
                                }
                            }
                        }
                    }
                }
            }
            if (s[0] != 1) {
                UserTreeViewSortChildrenNode(p, s[0] * s[1])
            }
        }
        p.HasNotFetchChildrenNode = 0;
        p.IsExpandedHTMLDirty = true;
        p.IsCollapsedHTMLDirty = true;
        break;
    case 3:
        var f = new ActiveXObject("MSXML.DOMDocument");
        if (f != null) {
            f.async = false;
            f.load(getNotesIniValue("GetDepInfoDb") + "LKS_XMLUnitGroup?ReadViewEntries&count=9999&PreFormat&RestrictToCategory=" + encodeURI(p.ViewName[0]));
            var o = f.selectNodes("/viewentries/viewentry");
            if (o.length > 0) {
                for (var t = 0; t < o.length; t++) {
                    appendUnit(p, GetChildNodeText(o[t], "disname"), p.HrefPrefix[0], "Unit", p.MenuType[0], p.MenuTarget[0], GetChildNodeText(o[t], "extendname"), p.parameterlist[0])
                }
            }
            if (p.MenuType[0].indexOf("M") > -1) {
                f.load(getNotesIniValue("GetPeopleInfoDb") + "LKS_XMLPerson?ReadViewEntries&count=9999&PreFormat&RestrictToCategory=" + encodeURI(p.ViewName[0]));
                var o = f.selectNodes("/viewentries/viewentry");
                if (o.length > 0) {
                    for (var t = 0; t < o.length; t++) {
                        appendChild(p, GetChildNodeText(o[t], "name"), p.HrefPrefix[0] + "&Info=" + encodeURI(GetChildNodeText(o[t], "ad")), "Person", p.MenuTarget[0], p.parameterlist[0])
                    }
                }
            }
            p.HasNotFetchChildrenNode = 0;
            p.IsExpandedHTMLDirty = true;
            p.IsCollapsedHTMLDirty = true
        }
    }
    if (this.OnChildrenNodePostFetch != null) {
        this.OnChildrenNodePostFetch(p)
    }
}
function CreatePath(l, o, k, a, j, h, n, e, f) {
    if (h == null) {
        h = "/"
    }
    var c;
    var g;
    var d;
    var m, b;
    g = true;
    b = null;
    m = l;
    c = o.indexOf(h);
    if (c < 0) {
        return null
    }
    while (g) {
        c = c + 1;
        if (c >= o.length) {
            break
        }
        o = o.substring(c, o.length);
        c = o.indexOf(h);
        if (c < 0) {
            g = false;
            d = o
        } else {
            d = o.substring(0, c)
        }
        d = m_StrTrim(d);
        if (d != "") {
            b = GetChildByTitle(m, d);
            if (b == null) {
                b = new TreeNode(m,d,"","");
                if (b == null) {
                    return null
                }
                if (m != null && m.CreatedByAppendView > 0) {
                    b.CreatedByAppendView = 1
                }
            }
            m = b
        }
    }
    if (b != null) {
        if (k != null) {
            b.type = k
        }
        if (j != null) {
            b.target = j
        }
        if (n != null) {
            b.parameter = n
        }
        if (e != null) {
            b.info = e
        }
        if (f != null) {
            b.order = f
        }
        b.href = a
    }
    return b
}
function m_StrTrim(d) {
    var c, b;
    var a = d.length;
    for (c = 0; c < a; c++) {
        if (d.charAt(c) != " ") {
            break
        }
    }
    if (c >= a) {
        return ""
    }
    b = c;
    for (c = a - 1; c >= 0; c--) {
        if (d.charAt(c) != " ") {
            break
        }
    }
    if (c < 0) {
        return ""
    }
    return d.substring(b, c + 1)
}
function GetChildByTitle(b, d) {
    var a, c;
    if (b == null) {
        return null
    } else {
        c = null;
        a = b.firstchild;
        while (a != null) {
            if (a.title == d) {
                return a
            } else {
                a = a.nextsibling
            }
        }
    }
}
function GetNodePath(a, b) {
    var c = "";
    if (b == null) {
        b = "\\"
    }
    if (a == null) {
        return ""
    }
    if (a.parent == null) {
        return b
    }
    while (a.parent != null) {
        c = b + a.title + c;
        a = a.parent
    }
    return c
}
function GetChildNodeText(a, c) {
    var b = null, d;
    b = a.firstChild;
    while (b != null) {
        d = b.getAttributeNode("name");
        if (d != null && d.nodeValue == c) {
            return b.text
        }
        b = b.nextSibling
    }
    return ""
}
function getNotesIniValue(g) {
    g = g.toLowerCase();
    if (S_IniValueList == null) {
        var e = S_SetupPath + "/sys/lks_sysconfig.nsf/AG_XMLGetIniValue?OpenAgent";
        var c = new ActiveXObject("MSXML.DOMDocument");
        c.async = false;
        c.load(e);
        var b = c.selectNodes("/ReturnMsg/value");
        var a, f;
        S_IniValueList = new Array;
        for (var d = 0; d < b.length; d++) {
            a = b[d].getAttributeNode("name");
            if (a != null) {
                f = a.nodeValue.toLowerCase();
                switch (f) {
                case "getdepinfodb":
                case "getpeopleinfodb":
                case "getpostinfodb":
                case "getgroupinfodb":
                    S_IniValueList[f] = b[d].text == "" ? "/names.nsf/" : ("/" + b[d].text.toLowerCase() + "/");
                    break;
                case "ioencoding":
                    S_IniValueList[f] = b[d].text == "" ? "GB2312" : b[d].text;
                    break;
                default:
                    S_IniValueList[f] = b[d].text
                }
            }
        }
    }
    return S_IniValueList[g]
}
function HideTreeNodeChildren(node) {
    var now;
    var element;
    now = node.firstchild;
    while (now != null) {
        element = eval("document.all.TVN_" + now.id);
        if (element != null) {
            element.outerHTML = ""
        }
        if (now.IsExpanded) {
            HideTreeNodeChildren(now)
        }
        now = now.nextsibling
    }
}
function getWorkplaceStyle() {
    var c = location.href.toLowerCase();
    var a = c.indexOf("&css=");
    if (a > -1) {
        c = c.substring(a + 5);
        a = c.indexOf("&");
        if (a > -1) {
            c = c.substring(0, a)
        }
        S_CurrentStyle = c;
        document.writeln("<script src=" + S_DbPath + "/" + c + "/leftpage/nav_page.js><\/script>")
    } else {
        c = null;
        try {
            c = document.cookie.match(/\bLKS_WorkplaceStyle=(.*?)(?=;|$)/g)
        } catch (b) {}
        if (c != null) {
            c = c[0].substring(19)
        } else {
            c = "workplace/common"
        }
        S_CurrentStyle = c;
        document.writeln("<script src=" + S_DbPath + "/" + c + "/leftpage/leftpage.js><\/script>")
    }
}
function UserTreeViewSortChildrenNode(f, a) {
    if (a == null || a == 1) {
        return
    }
    if (f.firstchild == null) {
        return
    }
    var h = new Array;
    var g = new Array;
    var e;
    for (var c = f.firstchild; c != null; c = c.nextsibling) {
        UserTreeViewSortChildrenNode(c, a);
        e = -1;
        for (var d = 0; d < h.length; d++) {
            e = UserTreeViewSortFunction(c.order, h[d], a);
            if (e != -1) {
                break
            }
        }
        switch (e) {
        case 1:
            for (var b = g.length; b > d; b--) {
                g[b] = g[b - 1];
                h[b] = h[b - 1]
            }
            g[d] = c;
            h[d] = c.order;
            break;
        case -1:
            g[g.length] = c;
            h[h.length] = c.order;
            break
        }
    }
    for (var d = g.length - 1; d >= 0; d--) {
        MoveToHead(f, g[d])
    }
}
function UserTreeViewSortFunction(c, b, d) {
    if (c == null || c == "") {
        return 0
    }
    if (b == null || b == "") {
        return 1
    }
    switch (Math.abs(d)) {
    case 3:
        c = parseFloat(c);
        b = parseFloat(b)
    }
    var a = (c < b ? 1 : -1) * (d > 0 ? 1 : -1);
    return a
}
function MoveToHead(c, e) {
    var a, d, b;
    a = c.firstchild;
    if (a == e) {
        return
    }
    d = e.prevsibling;
    b = e.nextsibling;
    if (d != null) {
        d.nextsibling = b
    }
    if (b != null) {
        b.prevsibling = d
    }
    if (e == c.lastchild) {
        c.lastchild = d
    }
    c.firstchild = e;
    e.nextsibling = a;
    e.prevsibling = null;
    a.prevsibling = e
}
function getXmlDoc(d) {
    var c = new ActiveXObject("MSXML.DOMDocument");
    c.async = false;
    var a = (location.protocol + "//" + location.host).toLowerCase();
    if (d.toLowerCase().indexOf("http") == 0 && d.toLowerCase().indexOf(a) != 0) {
        c.load(S_SetupPath + "/sys/lks_public.nsf/AG_GetXmlDoc?openagent&url=" + d)
    } else {
        c.load(d);
        var b = c.selectNodes("/viewentries");
        if (window.S_ICM_SERVER != null && S_ICM_SERVER != "" && b.length == 0 && d.indexOf("/") == 0) {
            c.load(S_SetupPath + "/sys/lks_public.nsf/AG_GetXmlDoc?openagent&url=" + S_ICM_SERVER + d)
        }
    }
    return c
}
getWorkplaceStyle();
