var FA_Type = new Array("审批", "签字", "抄送");
var FA_Type0 = new Array("串行", "并行", "会审");
var FA_Type1 = new Array("串行", "并行", "会签");
var whoOpen = "";
function createType() {
	var strOpt = "<select class=selectmenu id=FF_Type onChange=changeType();>";
	for (var i = 0; i < window.FA_Type.length; i++)
		strOpt += "<option value=" + i + (i ? ">" : " selected>")
				+ window.FA_Type[i];
	strOpt += "</select>";
	document.all.ReviewType1.innerHTML = strOpt;
	changeType();
}
function getType(s) {
	with (document.forms[0]) {
		var indexT = FF_Type.selectedIndex;
		var nodeNm = window.FA_Type[indexT];
		var nodeAd = 10 * (indexT + 1);
		if (eval("window.FA_Type" + indexT) != null) {
			var strField = eval("FA_Type" + indexT);
			for (var i = 0; i < strField.length; i++) {
				if (tagReviewType[i].checked) {
					nodeAd = tagReviewType[i].value;
					nodeNm = nodeNm + ":" + tagReviewType[i].text;
				}
			}
		}
		if (s == "AD")
			return nodeAd;
		else
			return nodeNm;
	}
}
function changeType() {
	var doc = document.all;
	var strOpt = "";
	var indexT = doc.FF_Type.selectedIndex;
	var j = (indexT + 1) * 10;
	if (eval("window.FA_Type" + indexT) != null) {
		var strField = eval("window.FA_Type" + indexT);
		for (var i = 0; i < strField.length; i++, j++) {
			strOpt += "<input type=radio name=tagReviewType value=" + j
					+ " text=" + strField[i] + (i ? ">" : " checked>");
			strOpt += "<span onClick=\"tagReviewType[" + i + "].click();\">"
					+ strField[i] + "</span>";
		}
	}
	doc.ReviewType2.innerHTML = strOpt;
	changeSelect(indexT);
}
function changeSelect(i) {
	var doc = document.all;
	var outer = doc.aSelect.outerHTML;
	var reg1 = (whoOpen == "Define") ? /PMC/ : /PM/;
	var par1 = (whoOpen == "Define") ? "PMC" : "PM";
	var reg2 = (whoOpen == "Define") ? /UPGMC/ : /UPGM/;
	var par2 = (whoOpen == "Define") ? "UPGMC" : "UPGM";
	if (i == 2) {
		outer = outer.replace(/★/, par2);
		outer = outer.replace(reg1, par2);
		doc.press.style.display = "none";
		doc.option1.checked = false;
		doc.option1.disabled = true;
		doc.optionSpan1.outerHTML = "<span id=optionSpan1 title=不可用 disabled>"
				+ doc.optionSpan1.innerHTML + "</span>";
		doc.option2.checked = false;
		doc.option2.disabled = true;
		doc.optionSpan2.outerHTML = "<span id=optionSpan2 title=不可用 disabled>"
				+ doc.optionSpan2.innerHTML + "</span>";
		doc.option6.disabled = true;
		doc.option6.checked = false;
		doc.optionSpan6.outerHTML = "<span id=optionSpan6 title=不可用 disabled>"
				+ doc.optionSpan6.innerHTML + "</span>";
		doc.option7.disabled = true;
		doc.option7.checked = false;
		doc.optionSpan7.outerHTML = "<span id=optionSpan7 title=不可用 disabled>"
				+ doc.optionSpan7.innerHTML + "</span>";
		doc.option8.disabled = true;
		doc.option8.checked = false;
		doc.optionSpan8.outerHTML = "<span id=optionSpan8 title=不可用 disabled>"
				+ doc.optionSpan8.innerHTML + "</span>";
	} else {
		outer = outer.replace(/★/, par2); 	// 2015 outer = outer.replace(/★/, par1);
		if (outer.indexOf(par2) != -1) {
			doc.press.style.display = "block";
			doc.option1.disabled = false;
			doc.optionSpan1.outerHTML = "<span id=optionSpan1 title=在文档流转过程中，&#10;本节点的处理人员可以决定后续的流程。 onClick=(option1.checked=!option1.checked);>"
					+ doc.optionSpan1.innerHTML + "</span>";
			doc.option2.disabled = false;
			doc.optionSpan2.outerHTML = "<span id=optionSpan2 title=在文档流转过程中，&#10;本节点的处理人员可以上载附件。 onClick=(option2.checked=!option2.checked);>"
					+ doc.optionSpan2.innerHTML + "</span>";
			doc.option6.disabled = false;
			doc.optionSpan6.outerHTML = "<span id=optionSpan6 title=在文档流转过程中，&#10;上一节点处理人与本节点重复也不跳过本节点。 onClick=(option6.checked=!option6.checked);>"
					+ doc.optionSpan6.innerHTML + "</span>";
			doc.option7.disabled = false;
			doc.optionSpan7.outerHTML = "<span id=optionSpan7 title=在文档流转过程中，&#10;处于本节点审批，但未开始前起草人可撤回。 onClick=(option7.checked=!option7.checked);>"
					+ doc.optionSpan7.innerHTML + "</span>";
			doc.option8.disabled = false;
			doc.optionSpan8.outerHTML = "<span id=optionSpan8 title=在文档流转过程中，&#10;本节点的处理人员可以修改后续节点处理人。 onClick=(option8.checked=!option8.checked);>"
					+ doc.optionSpan8.innerHTML + "</span>";
			if (doc.RvInput.value != "") {
				var nmlist = doc.RvNameInput.value.split(";");
				var ndlist = doc.RvInput.value.split(";");
				var newnm = "", newnd = "", tmpstr;
				var cpost = false;
				for (var j = 0, k = 0; j < ndlist.length; j++) {
					cpost = ndlist[j].substring(0, 1) == "%"
							&& ndlist[j].substring(ndlist[j].length - 1) == "%";
					tmpstr = GetUserInfo(ndlist[j], "lkstype");
					if (tmpstr[0] == "person" || tmpstr[0] == "post" || cpost) {
						newnd += (ndlist[j] + ";");
						newnm += (nmlist[j] + ";");
					} else
						k++;
				}
				if (k) {
					if (newnd != "") {
						newnd = newnd.substring(0, newnd.length - 1);
						newnm = newnm.substring(0, newnm.length - 1);
					}
					//doc.RvInput.value = newnd;					//2015	需求二 del
					//doc.RvNameInput.value = newnm;				//2015	需求二 del
					//alert("系统已自动去除不合理的“处理人员”！");	//2015	需求二 del
				}
			}
			//outer = outer.replace(reg2, par1);						//2015	需求二 del
		}
	}
	doc.option7.disabled = true;
	doc.aSelect.outerHTML = outer;
}
function iniRecord() {  // modified at 201604
	var recObj = window.dialogArguments;
	if (recObj.Key != null)
		document.all.divCurNode.innerHTML = "<font color=red>当前节点Key： <b>"
				+ recObj.Key + "</b>";
	whoOpen = recObj.whoOpen;
	createType();
	with (document.forms[0]) {
		F_NodeName.value = recObj.F_NodeName;
		for (i = 0; i < NodeNameInput.length; i++)
			if (NodeNameInput.options[i].text == recObj.F_NodeName)
				NodeNameInput.options[i].selected = true;
		RvInput.value = recObj.F_Reviewer;
		RvNameInput.value = recObj.F_ReviewerName;
		RvBakInput.value = recObj.F_BakReviewer;
		RvBakNameInput.value = recObj.F_BakReviewerName;
		F_Creator.value = recObj.F_Creator;
		var nodeAd = parseInt(recObj.F_ReviewType);
		if (!isNaN(nodeAd)) {
			FF_Type.options[Math.floor(nodeAd / 10 - 1)].selected = true;
			changeType();
			if (ReviewType2.innerHTML != "")
				tagReviewType[nodeAd % 10].checked = true;
		}
		if (recObj.F_JumpCondition != null) {
			JumpConditionInput.value = recObj.F_JumpCondition;
		} else {
			trF_JumpCondition.parentNode.style.display = "none";
			trF_AutoCondition.parentNode.style.display = "none";
		}
		if (recObj.F_JumpNode != null) {
			var strOpt = "<select class=selectmenu id=selJump>";
			for (var j = 0; j <= recObj.rowCount; j++) {
				if (j == recObj.rowIndex || j == (recObj.rowIndex + 1))
					continue;
				strOpt = strOpt
						+ "<option value='"
						+ (j ? j : "")
						+ (recObj.F_JumpNode.toString() == j.toString()
								? "' selected"
								: "'") + ((j != 0) ? (">节点 " + j) : ">不跳转");
			}
			if (recObj.F_JumpNode.toLowerCase() == "end") {
				strOpt = strOpt + "<option value='end' selected>结束";
			} else {
				strOpt = strOpt + "<option value='end'>结束";
			}
			spanJump.innerHTML = strOpt + "</select>";
		} else
			trF_JumpNode.parentNode.style.display = "none";
		setOptions(recObj.F_Option);
		iniParsedBy(recObj);	//gw 2015-02 add
		iniExtendInfo(recObj.F_ExtendHours); // added at 201604
		if (F_FunList.value == "")
			trF_AdditionFun.parentNode.style.display = "none";
		else
			setFunList(F_FunList.value, recObj.F_FunList);
		if (recObj.F_IsAllowEdit == "1") {
			document.all.spanFunList.disabled = false;
			document.all.nodeSet.disabled = false;
		} else
			document.all.spanFunList.disabled = true;
		iniNodeSetting(recObj.F_NodeSetting);
		iniSubFlowdef(recObj.F_SubFlowDef);
	}
}
function iniExtendInfo(extendinfo){  // added at 201604
//alert("extendinfo is "+extendinfo);
	try{
		if((parseFloat(extendinfo)+"")!=(extendinfo+"")){return;}
		var extendobjs = document.getElementsByName("optionextend");
		for(var i = 0;extendobjs[i];i++){extendobjs[i].checked=true;}
		document.getElementById("optionextendhours").value=extendinfo;
	}catch(e){}
}
function iniParsedBy(recObj) {
//alert("iniParsedBy_nodereview.js");
// 2015-02 add
//解析前置节点名为列表，用于可解析通用岗位的节点
	recObj.resWin;
	var selHTML="";
	var nodeNameArr;
	var tmpS = "";
	if(recObj.ParsedByArr!=null){
		for(var i=0; i<recObj.ParsedByArr.length; i++){
			if(recObj.ParsedByArr[i]!=""){
				tmpS="<option value='"+recObj.ParsedByArr[i].split("|")[0]+"'>"+recObj.ParsedByArr[i].split("|")[1];
				if(recObj.F_ParsedBy!=null){
					if(recObj.F_ParsedBy==recObj.ParsedByArr[i].split("|")[0]){
						tmpS="<option selected value='"+recObj.ParsedByArr[i].split("|")[0]+"'>"+recObj.ParsedByArr[i].split("|")[1];
					}
				}
			}
			selHTML=selHTML+tmpS;
		}
	}
	selHTML="<option value=''>起草人"+selHTML;
	if(recObj.F_IsAllowEdit == "1"){
		selHTML="<select class=selectmenu id='ParsedBy'>"+selHTML;
	}else{
		selHTML="<select disabled class=selectmenu id='ParsedBy'>"+selHTML;
	}
	selHTML=selHTML+"</select>";

	document.all.divParsedBy.innerHTML=selHTML;
}
function saveRecord() {
	with (document.forms[0]) {
		if (F_NodeName.value == "") {
			F_NodeName.focus();
			alert("“节点名称”不能为空！");
			return false;
		}
		if(!chkSubFlowSetting(document.forms[0])){
			return false;
		}
		if (document.forms[0].JumpConditionInput != null)
			if (!checkCond())
				return false;
		var recObj = window.dialogArguments;	//2015-04 var recObj = new Object;
		if (!checkUserNum(recObj,RvInput.value,RvNameInput.value,window.dialogArguments.Key,getType("AD"))){ return false;	}	//2015-04 modify
		recObj.F_NodeName = F_NodeName.value;
		recObj.F_Reviewer = RvInput.value;
		recObj.F_ReviewerName = RvNameInput.value;
		recObj.F_BakReviewer = RvBakInput.value;
		recObj.F_BakReviewerName = RvBakNameInput.value;
		recObj.F_ReviewTypeAd = getType("AD");
		recObj.F_ReviewTypeNm = getType("NM");
		if (trF_JumpCondition.parentNode.style.display != "none")
			recObj.F_JumpCondition = JumpConditionInput.value;
		if (trF_JumpNode.parentNode.style.display != "none")
			recObj.F_JumpNode = selJump.value;
		recObj.F_Option = getOptions();
		recObj.F_FunList = getFunList();
		recObj.F_NodeSetting = getNodeSetList();
		recObj.F_SubFlowDef=getSubFlowDefList();
		recObj.F_ParsedBy=ParsedBy.options[ParsedBy.selectedIndex].value;	//gw 2015-02 add
		recObj.F_ParsedByText=ParsedBy.options[ParsedBy.selectedIndex].text;	//2015-04 add 
    
    window.opener.setReturnVlaue(recObj,window.opener.currentNodeData);
    window.close();
   
    
	
		// window.returnValue = recObj;
		// window.close();
	}
}
function checkUserNum(recObj,ads,nas,nodeKey,nType) {
//2015-04 modify
//检查节点审批人数量是不是超过限制
//ads:选择后的AD
//nas:选择后的NAMES
	try{
		if(recObj.F_Reviewer!=ads){
			var agent="Ag_CheckUserNum?openagent&ads="+escape(ads);
			var hasKey=false;
			for(var i = 1;i<50;i++){
				if(eval("recObj.resWin.document.forms[0].F_ParsedBy_"+i).value==nodeKey) {
				//有需求重新解析的内容
					hasKey = true;
					break;
				}
			}
			if(hasKey){
				var id = recObj.resWin.location.href;
				if(id.indexOf("/0/")>-1){
					id = id.substring(0,id.indexOf("?"));
					id = id.substring(id.indexOf("/0/")+3,id.length);
				}else{
					id = id.substring(id.indexOf("&ParentUNID=")+12,id.indexOf("&ParentUNID=")+12+32);
				}
				agent="Ag_CheckUserNum?openagent&ads="+escape(ads)+"&nas="+escape(nas)+"&nkey="+nodeKey+"&ty="+nType+"&id="+id;
			}
			
			var xml=new ActiveXObject("MSXML.DOMDocument");
			xml.async=false;
			var path=S_DbUrl;
			xml.load(path+"/"+agent);
			var nodes=xml.selectNodes("ReturnMsg/ReturnCode");
			var result=nodes[0].text;
			if(result=="0"){
				alert("节点处理人数超过了限制,请检查;");
				return false;
			}else{
				if(hasKey){
					nodes=xml.selectNodes("ReturnMsg/ReturnKeys");
					recObj.Key_Ref=nodes[0].text;
					nodes=xml.selectNodes("ReturnMsg/ReturnAds");
					recObj.Reviewer_Ref=nodes[0].text;
					nodes=xml.selectNodes("ReturnMsg/ReturnNames");
					recObj.ReviewerNames_Ref=nodes[0].text;
				}
			}
		}
		return true;
	}catch(e){}
	return true;
}

function setOptions(opts) {
	var doc = document.all;
	if (doc.F_Defoption.value == "")
		var opts = opts.split(";");
	else {
		var opts = opts.split(";");
		var optDefs = doc.F_Defoption.value.split(";");
		for (var i = 0; i <= 9; i++) {
			if (i <= 2) {
				opts[i] = optDefs[i];
			}
			if (i == 7) {
				opts[i] = optDefs[3];
			}
			if (i == 9) {
				opts[i] = optDefs[4];
			}
		}
	}
	for (var i = 0; i <= 11; i++) {
		if(i==8) {
			optStr=(opts[i]?trim(opts[i]):"");
			setOptionsSingle(i,optStr);
			continue;
		}
		if (i == 11) {
			if (opts[i] == null)
				var optsend = "0000";
			else
				var optsend = opts[i];
			optsend = optsend.replace(/(^\s*)|(\s*$)/g, "");
			for (var kk = 1; kk <= 4; kk++) {
				if (eval("doc.optionsend" + kk) != null) {
					eval("doc.optionsend" + kk).checked = (parseInt(optsend
							.substr(kk - 1, 1)) == 1) ? true : false;
				}
			}
		} else {
			if (i == 3 || i == 5) {
				var days = parseInt(opts[i]);
				if (isNaN(days))
					days = "";
				eval("doc.option" + i).value = days;
			} else
				eval("doc.option" + i).checked = (parseInt(opts[i]) == 1)
						? true
						: false;
		}
	}
	if (whoOpen == "Review" || document.forms[0].F_IsDef.value == "0") {
		doc.option0.disabled = true;
		doc.optionSpan0.outerHTML = "<span id=optionSpan0 title=不可用 disabled>"
				+ doc.optionSpan0.innerHTML + "</span>";
		doc.option8.disabled = true;
		setOptionsExDisabled(8,true);
	}
}
function getOptions() {
	var doc = document.forms[0];
	var opts = new Array;
	var optsend = "";
	for (var i = 0; i <= 11; i++) {
                if (i == 8) {
			opts[i] = getOptionsSingle(i);
                        continue;
                }
		if (i == 11) {
			for (var j = 1; j <= 4; j++) {
				if (eval("doc.optionsend" + j) == null)
					optsend += "0";
				else
					optsend += eval("doc.optionsend" + j).checked ? "1" : "0";
			}
			opts[i] = optsend;
		} else {
			if (i == 3 || i == 5) {
				var sday = trim(eval("doc.option" + i).value);
				opts[i] = (isNaN(parseInt(sday)) ? "0" : parseInt(sday));
			} else
				opts[i] = eval("doc.option" + i).checked ? "1" : "0";
		}
	}
	return opts.join(";");
}
function setFunList(tit, val) {
	var doc = document.all;
	var tits = tit.split("^");
	var vals = val.split(";");
	var vas, ids, txt;
	var str = "";
	for (var i = 0; i < tits.length; i++) {
		vas = (vals[i] == null ? "0" : trim(vals[i]));
		ids = "chkFunList" + i;
		txt = "<span>" + tits[i] + "</span>";
		str = str + "<input type=checkbox id=" + ids
				+ (vas == "1" ? " checked>" : ">") + txt;
		if ((i + 1) % 3 != 0)
			str += "&nbsp;&nbsp;&nbsp;";
		else
			str += "<br>";
	}
	document.all.spanFunList.innerHTML = str;
}
function getFunList() {
	var doc = document.forms[0];
	var opts = new Array;
	var i = 0;
	while (eval("doc.chkFunList" + i) != null) {
		opts[i] = eval("doc.chkFunList" + i).checked ? "1" : "0";
		i++;
	}
	return opts.join(";");
}
function checkCond() {
	with (document.forms[0]) {
		var cond = trim(JumpConditionInput.value);
		if (fullTrim(cond) != "") {
			var reg;
			var reg1;
			var conds = cond.split("\n");
			for (var j = 0; j < conds.length; j++) {
				cond = trim(conds[j]) + "\n";
				if (cond.length == 1)
					continue;
				reg = eval("/\\s\\#\\d*\\s*\\n/g");
				reg1 = eval("/\\s\\#end\\s*\\n/g");
				if (cond.search(reg) == -1 && cond.search(reg1) == -1) {
					var str = "跳转信息第：" + (j + 1) + "个条件格式不正确！";
					str += "\n\n请确认“#”号前有空格，并且没写成全角“＃”。";
					alert(str);
					return false;
				}
			}
		}
	}
	return true;
}
function fullTrim(str) {
	var len = str.length;
	if (!len)
		return "";
	var wSpace = new Array(" ", "\n", "\t", "\r");
	var w;
	for (var i = 0; i < len; i++) {
		for (w = 0; w < wSpace.length; w++)
			if (str.charAt(i) == wSpace[w])
				break;
		if (w == wSpace.length)
			break;
	}
	if (i == (len - 1))
		return "";
	for (var j = len; j > 0; j--) {
		for (w = 0; w < wSpace.length; w++)
			if (str.charAt(j - 1) == wSpace[w])
				break;
		if (w == wSpace.length)
			break;
	}
	if (i > j)
		return "";
	return str.substring(i, j);
}
function getNodeName() {
	with (document.forms[0])
		F_NodeName.value = NodeNameInput.options[NodeNameInput.selectedIndex].text;
}
function vis(idDsp, idH) {
	eval("document.all." + idDsp).style.display = "";
	eval("document.all." + idH).style.display = "none";
}
function showLabel(n) {
	var intConstant = 125;
	var rowHeight;
	for (var i = 1; i < labelTable.rows.length; i++) {
		var o = eval("document.all.buLabel" + i);
		if (o != null)
			if (i == n) {
				labelTable.rows[i].style.display = "";
				o.className = "labelbg1";
				o.blur();
				labelTable.CurrentLabel = n;
				rowHeight = labelTable.rows[i].clientHeight;
			} else {
				labelTable.rows[i].style.display = "none";
				o.className = "labelbg2";
			}
	}
	try {
		if (dialogHeight) {
			dialogHeight = (intConstant + rowHeight) + "px";
		}
	} catch (err) {
	}
}
function simpleAddress(dataformat, formDataFields, toDataFields) {
	var path = location.href.toLowerCase();
	path = path.substring(0, path.indexOf(".nsf") + 4);
	path += "/FM_AddressMul?OpenForm";
	var dogstyle = "dialogWidth:430px; dialogHeight:330px; status:0;scroll:0; help:0";
	var obj = new Object;
	var fromAds = "";
	var fromNames = "";
	var toAds = "";
	var toNames = "";
	var style = dataformat.split(":");
	var formData = formDataFields.split(":");
	var toData = toDataFields.split(":");
	for (var i = 0; i < style.length; i++) {
		if (style[i] == "ad") {
			fromAds = document.getElementById(formData[i]).value;
			toAds = document.getElementById(toData[i]).value;
		}
		if (style[i] == "name") {
			fromNames = document.getElementById(formData[i]).value;
			toNames = document.getElementById(toData[i]).value;
		}
	}
	obj.fromAds = fromAds;
	obj.fromNames = fromNames;
	obj.toAds = toAds;
	obj.toNames = toNames;
	var recObj = window.dialogArguments;
	obj.F_Creator = recObj.resWin.document.all.F_Creator.value;
	var rtnObj = window.showModalDialog(path, obj, dogstyle);
	if (rtnObj == null) {
		return;
	}
	for (var i = 0; i < style.length; i++) {
		if (style[i] == "ad") {
			eval("document.all." + toData[i]).value = rtnObj.returnAds;
		}
		if (style[i] == "name") {
			eval("document.all." + toData[i]).value = rtnObj.returnNames;
		}
	}
}
function selectFiled(obj) {
	if (obj.checked) {
		if (document.forms[0].option10.disabled) {
			fiedList.innerHTML = document.forms[0].F_ReviewNo.value;
		} else {
			var htmlinfo = getfiedListInnerHtml();
			if (htmlinfo == "") {
				alert("当前模块的对应信息不全，请检查！")
				obj.checked = false;
			} else
				fiedList.innerHTML = htmlinfo;
		}
	} else {
		fiedList.innerHTML = "";
	}
}
function getfiedListInnerHtml(field) {
	var recObj = window.dialogArguments;
	var maindb = recObj.resWin.document.all.F_ParentFilePath.value;
	var path = location.href.toLowerCase();
	path = path.substring(0, path.indexOf(".nsf") + 4) + "/";
	path += "AG_GetField?openagent&db=" + maindb + "&method=node";
	var xml = new ActiveXObject("MSXML.DOMDocument");
	var htmlCode = null;
	xml.async = false;
	var seccuss = xml.load(path);
	var tmpstr = "";
	with (document.forms[0]) {
		if (seccuss) {
			nodes = xml.selectNodes("ReturnMsg");
			tmpstr = nodes(0).text;
			var customArr = getCustomFields();
			if (customArr.length == 0 && tmpstr == "") {
				return "";
			}
			var tmpArr = tmpstr.split(":");
			htmlCode = "<select id='fieldselect'>";
			if (tmpstr != "")
				for (var i = 0; i < tmpArr.length; i++) {
					var tmpInfo = tmpArr[i].split("^");
					var mainformname = recObj.resWin.parent.document.forms[0].name;
					if (mainformname.substring(1, mainformname.length)
							.toLowerCase() == tmpInfo[2].toLowerCase()) {
						if (field != null) {
							var strFields = field.split("^");
							if (strFields[1] == tmpInfo[1])
								htmlCode += "<option value=" + tmpInfo[1]
										+ " selected>" + tmpInfo[0];
							else
								htmlCode += "<option value=" + tmpInfo[1] + ">"
										+ tmpInfo[0];
						} else {
							htmlCode += "<option value=" + tmpInfo[1] + ">"
									+ tmpInfo[0];
						}
					}
				}
			if (customArr.length != 0) {
				for (var i = 0; i < customArr.length; i++) {
					tmpInfo = customArr[i].split("^");
					if (field != null) {
						var strFields = field.split("^");
						if (strFields[1] == tmpInfo[1])
							htmlCode += "<option value=" + tmpInfo[1]
									+ " selected>" + tmpInfo[0];
						else
							htmlCode += "<option value=" + tmpInfo[1] + ">"
									+ tmpInfo[0];
					} else {
						htmlCode += "<option value=" + tmpInfo[1] + ">"
								+ tmpInfo[0];
					}
				}
			}
			htmlCode += "</select>";
			if (htmlCode == "<select id='fieldselect'></select>")
				return "";
			return htmlCode;
		} else {
			alert("获取节点处理人信息失败！");
			return "";
		}
	}
}
function inifiedList(field) {
	if (document.all.option10.checked) {
		if (document.forms[0].option10.disabled) {
			document.all.fiedList.innerHTML = "《"
					+ field.substring(0, field.indexOf("^")) + "》";
		} else {
			if (field == null || field == "")
				document.all.option10.checked = false;
			else {
				var htmlinfo = getfiedListInnerHtml(field);
				if (htmlinfo == "") {
					alert("当前模块的对应信息不全，请检查！")
					document.all.option10.checked = false;
				} else
					document.all.fiedList.innerHTML = htmlinfo;
			}
		}
	}
}
function getCustomFields() {
	var rtnArr = new Array();
	var k = 0;
	if (recObj.resWin.parent.document.forms[0].F_SubForm != null) {
		var f = recObj.resWin.parent.if_subform.document.forms[0];
		for (var i = 0; i < f.elements.length; i++) {
			if (f.elements[i].name.toUpperCase().indexOf("CF_") == 0
					&& f.elements[i].title != "" && f.elements[i].org != null
					&& f.elements[i].org == "true") {
				rtnArr[k] = f.elements[i].title + "^" + f.elements[i].name;
				k++;
			}
		}
	}
	return rtnArr;
}
function getField() {
	if (document.all.option10.checked) {
		if (document.all.fieldselect != null) {
			field = document.all.fieldselect;
			return field.options[field.selectedIndex].text + "^"
					+ field.options[field.selectedIndex].value;
		}
	}
	return "";
}
function checkNodeConfig(obj) {
	var configNm = obj.value;
	var dealName = eval("document.all.F_DealName_" + configNm);
	if (obj.checked) {
		dealName.disabled = false;
	} else {
		dealName.value = "";
		dealName.disabled = true;
	}
}
function getOperateName(index){
	switch(index){
		case "1",1:
			return "通过";
			break;
		case "2",2:
			return "驳回";
			break;
		case "3",3:
			return "转办";
			break;
		case "4",4:
			return "呈送";
			break;
		case "5",5:
			return "沟通";
			break;
		case "6",6:
			return "请示";
			break;
		case "7",7:
			return "会签";
			break;
		case "8",8:
			return "废弃";
			break;
		default:
			return document.forms[0].F_DefNodeset.value;
			break;
		}			
}

function getNodeSetList() {
	var rtnStr = "";
	for (var i = 0; i < 8; i++) {
		var nodeSet = eval("document.all.F_NodeSet_" + (i + 1));
		if (nodeSet.checked) {
			var dealName = eval("document.all.F_DealName_" + (i + 1)).value;
			if (dealName != "")
				rtnStr += ";" + (i + 1) + ":" + dealName;
			else {
				rtnStr += ";" + (i + 1) + ":" + getOperateName(i + 1);
			}
		}
	}
	if (rtnStr == "")
		return getOperateName(0);
	return rtnStr.substring(1);
}
function iniNodeSetting(argu) {
	if (argu == "" || argu == null)
		argu = getOperateName(0);
	if (argu != "") {
		var tmpArr = argu.split(";");
		for (var i = 0; i < tmpArr.length; i++) {
			var nodeSet = tmpArr[i].split(":");
			eval("document.all.F_NodeSet_" + nodeSet[0]).checked = true;
			if (nodeSet[0] == "1" || nodeSet[0] == "2")
				eval("document.all.F_NodeSet_" + nodeSet[0]).disabled = true;
			var nodeDealName = eval("document.all.F_DealName_" + nodeSet[0]);
			nodeDealName.value = nodeSet[1];
			nodeDealName.disabled = false;
		}
	}
}
//增加子流程设置
function addSubFlowRow(obj){
	//obj对应属性有name,unid
	var subflowTab=document.getElementById("subflowTab");
	if(subflowTab==null) return;
    var tr0=subflowTab.rows[0];
    var insertTr=subflowTab.insertRow(-1);
    var insertTd;
if(window.S_CanModifyFlow!=null && !window.S_CanModifyFlow  && tr0.cells.length>2) tr0.deleteCell(2);
    for(var i=0;i<tr0.cells.length;i++){
		insertTd=insertTr.insertCell(i);
		if(i==0)
			insertTd.innerHTML="<input type='text' name='F_SubFlowName' class='textdocdown' size=30 value='" +((obj==null || obj.name=="")?("子流程"+(subflowTab.rows.length-1)):trim(obj.name))+"'/>" + "<input type='text' name='F_SubFlowId' style='display:none' value='" +((obj==null || obj.unid=="")?"":obj.unid)+"'/>";
		if(i==1)
			insertTd.innerHTML="<div id='F_Status' style='color:" +((obj==null || obj.unid=="")?("red" + "'>未设置"):("blue"+ "'>已设置")) +"</div>";
		if(i==2)
			insertTd.innerHTML="〔<a href='#' selectDis='1' onclick='deleteThisSubflow();'>删除</a>〕〔<a href='#' selectDis='1' onclick='newSubFlow();'>设置</a>〕<a href='#' style='display:none'>〔选择〕</a>";
		insertTd.width=tr0.cells[i].width;
     	insertTd.bgColor =tr0.cells[i].bgColor;
     	insertTd.align=subflowTab.align;
	}
}
function RefersToSubFlowRow(obj,unid)
{
    //obj对应属性有name,unid
    var subflowTab=document.getElementById("subflowTab");
    if(subflowTab==null) return;
    var tr0=subflowTab.rows[0];
    var insertTr=subflowTab.insertRow(-1);
    var insertTd;
	if(window.S_CanModifyFlow!=null && !window.S_CanModifyFlow  && tr0.cells.length>2) tr0.deleteCell(2);
    for(var i=0;i<tr0.cells.length;i++){
        insertTd=insertTr.insertCell(i);
        if(i==0)
            insertTd.innerHTML="<input type='text' name='F_SubFlowName' class='textdocdown' size=30 value='" +("子流程"+(subflowTab.rows.length-1))+"'/>" + "<input type='text' name='F_SubFlowId' style='display:none' value='" +((obj==null || obj.unid=="")?"":obj.unid)+"'/>";
        if(i==1)
            insertTd.innerHTML="<div id='F_Status' style='color:" +("blue"+ "'>已设置") +"</div>";
        if(i==2)
            insertTd.innerHTML="〔<a href='#' selectDis='1' onclick='deleteThisSubflow();'>删除</a>〕〔<a href='#' selectDis='1' onclick='newSubFlow();'>设置</a>〕<a href='#' style='display:none'>〔选择〕</a>";
        insertTd.width=tr0.cells[i].width;
     	insertTd.bgColor =tr0.cells[i].bgColor;
     	insertTd.align=subflowTab.align;
    }
    var trObj=insertTr;
    currentSubFlowObj=trObj.all.F_SubFlowId;
    currentSubFlowColorObj=trObj.all.F_Status;
    setSubFlowUnid(unid)
}
// 初始化子流程表格
function iniSubFlowdef(subFlowStr){
	var nodeTypeInput=document.all.NodeTypeInput;
	if(subFlowStr==null || subFlowStr==""){
		nodeTypeInput.selectedIndex=0;
		chengeNodeType();
		return;
	}
	var subFlowArr=subFlowStr.split(";");
	nodeTypeInput.selectedIndex=1;
	chengeNodeType();
	if(subFlowArr.length>0){
		for(var i=0;i<subFlowArr.length;i++){
			var subFlowobj=new Object;
			subFlowobj.name=subFlowArr[i].substring(0,subFlowArr[i].indexOf("|"));
			subFlowobj.unid=subFlowArr[i].substr(subFlowArr[i].indexOf("|")+1);
			addSubFlowRow(subFlowobj);
		}
	}
}
// 获取子流程表格数据
function getSubFlowDefList(){
	var nodeTypeInput=document.all.NodeTypeInput;
	if(nodeTypeInput.selectedIndex==1){
		var subflowTab=document.getElementById("subflowTab");
		var rtnArr=new Array;
		var totalRowLen=subflowTab.rows.length;
		if (totalRowLen<=1)
			return "";
		for (var i=1;i<totalRowLen; i++)
		{
			var tmpRow=subflowTab.rows[i];
			rtnArr.push(tmpRow.all.F_SubFlowName.value +"|"+tmpRow.all.F_SubFlowId.value);
		}
		return rtnArr.join(";");
	}else return "";
}

// 设置子流程的隐藏
function chengeNodeType(){
	var nodeTypeInput=document.all.NodeTypeInput;
	if(nodeTypeInput.selectedIndex==1){
		displayLabel("8",1);
		displayLabel("3;4;5",0);
		trF_NodeEvent.parentNode.style.display = "none";
		trF_NodeDealType.parentNode.style.display = "none";
		trF_NodeDealSetting.parentNode.style.display = "none";
		trF_NodeDealMan.parentNode.style.display = "none";
	}else{
		displayLabel("8",0);
		//nodeTypeInput.disabled=true;
		trF_NodeEvent.parentNode.style.display = "";
		trF_NodeDealType.parentNode.style.display = "";
		trF_NodeDealSetting.parentNode.style.display = "";
		trF_NodeDealMan.parentNode.style.display = "";
		displayLabel("3;4;5",1);
	}
	if (document.all.F_NodeEvent.value == "1")
			trF_NodeEvent.parentNode.style.display = "none";
}

function openSubFlow(unid){
	window.open(S_DbUrl+"/0/" + unid +"?opendocument","_blank");
	return false;
}
function _getElementByAlink(){
	var tmpobj=event.srcElement;
	while(tmpobj!=null){
		if(tmpobj.tagName=="TR")
			return tmpobj;
		tmpobj=tmpobj.parentElement;
	}
	return null;
}
//删除该行子流程设置
function deleteThisSubflow(){
	var subflowTab=document.getElementById("subflowTab");
	var trObj=_getElementByAlink();
	if(trObj!=null)
		subflowTab.deleteRow(trObj.rowIndex);
}
var currentSubFlowUnidObj=null;
var currentSubFlowColorObj=null;
//设置子表单界面
function newSubFlow(){
	var path=window.location.href;
	var subflowTab=document.getElementById("subflowTab");
	var trObj=_getElementByAlink();
	var name=trObj.all.F_SubFlowName;
	currentSubFlowObj=trObj.all.F_SubFlowId;
	currentSubFlowColorObj=trObj.all.F_Status;
	var style="status=no,menubar=no,toolbar=no,menubar=no,location=no,resizable=yes,scrollbars=yes";
	path=path.substr(0,path.indexOf(".nsf")+4);
	if (currentSubFlowObj.value!="")
		window.open(path+"/0/"+currentSubFlowObj.value+"?editdocument","_blank",style);
	else
		window.open(path+"/FM_FlowDef?openform&subflow=1","_blank",style);
}
//设置当前子流程
function setSubFlowUnid(unid){
	if(unid!=null && unid!=""){
		currentSubFlowObj.value=unid;
		currentSubFlowColorObj.innerText="已设置";
		currentSubFlowColorObj.style.color="blue";
	}
	currentSubFlowObj==null;
}
//校验子流程表格数据
function chkSubFlowSetting(doc){
	var nodeTypeInput=document.all.NodeTypeInput;
	if(nodeTypeInput.selectedIndex==1){
		var subflowTab=document.getElementById("subflowTab");
		var rtnArr=new Array;
		var totalRowLen=subflowTab.rows.length;
		if (totalRowLen<=1){
			alert("请设置子流程信息!");
			showLabel(8);
			return false;
		}
		for (var i=1;i<totalRowLen; i++)
		{
			var tmpRow=subflowTab.rows[i];
			if(tmpRow.all.F_SubFlowName.value==""|| tmpRow.all.F_SubFlowId.value==""){
				alert("子流程信息不完整,请设置完整!");
				return false;
			}
		}
		return true;
	}
	return true;
}