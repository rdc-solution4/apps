var lab_number = 0;
var allinfo = new Object();
function getElementArray(b) {
	var a = b;
	if (a == null) {
		return new Array
	}
	if (a.length == null) {
		return new Array(a)
	}
	return a
}
function htmlEscape(b) {
	var a = new RegExp();
	a.compile("&", "gi");
	b = b.replace(a, "&amp;");
	a.compile('\\"', "gi");
	b = b.replace(a, "&quot;");
	a.compile("<", "gi");
	b = b.replace(a, "&lt;");
	a.compile(">", "gi");
	b = b.replace(a, "&gt;");
	return b
}
function getSubstringByByteLength(d, c) {
	if (d.length * 2 <= c) {
		return d
	}
	var b = 0;
	for (var a = 0; a < d.length; a++) {
		if (Math.abs(d.charCodeAt(a)) > 200) {
			b = b + 2
		} else {
			b++
		}
		if (b > c) {
			return d.substring(0, a) + (b % 2 == 0 ? ".." : "...")
		}
	}
	return d
}
function Portal_OnLoad() {
	if (document.all.ID_QuickNew != null
			&& document.all.F_QuickNewName.value != "") {
		var h = htmlEscape(document.all.F_QuickNewName.value).split("\r\n");
		var a = document.all.F_QuickNewURL.value.split("\r\n");
		var g = document.all.F_QuickNewImg.value.split("\r\n");
		var f = new Array;
		var d = new RegExp();
		d.compile(" ");
		for (var c = 0; c < h.length; c++) {
			f[c] = new Array;
			f[c].name = h[c];
			var b = location.protocol;
			f[c].url = a[c].replace(/%网络协议%/i, b);
			if (f[c].url != "" && window.S_ICM_SERVER != null
					&& S_ICM_SERVER != "" && f[c].url.indexOf("/") == 0) {
				f[c].url = S_ICM_SERVER + f[c].url
			}
			f[c].img = S_PortalInfo.Path + "common/icon/" + g[c]
		}
		var e = "<div style='overflow-x:hidden;width:100;height:100%' id=DIV_QuickNew>"
				+ getQuickNewInHTML(f) + "</div>";
		document.all.ID_QuickNew.innerHTML = getQuickNewOutHTML(e);
		Portlet_OnResize("Portlet_ResetQuickNew()")
	}
	if (window.Win_OnLoad) {
		Win_OnLoad()
	}
}
function Portlet_ResetQuickNew() {
	S_PortalInfo.TimeOutID["Portlet_ResetQuickNew()"] = 0;
	var a = DIV_QuickNew.offsetParent;
	if (a.clientWidth <= 100) {
		return
	}
	var b, c;
	for (c = a; c.id != "ID_QuickNew"; c = c.parentNode) {
		if (c.clientWidth != 0) {
			b = c.clientWidth
		}
	}
	if (b > document.body.clientWidth) {
		DIV_QuickNew.style.width = 100;
		Portlet_OnResize("Portlet_ResetQuickNew()")
	} else {
		DIV_QuickNew.style.width = a.clientWidth
	}
	QuickNew_CheckScrollPicInit()
}
function Portlet_OnResize(a) {
	if (typeof(a) != "string") {
		for (a in S_PortalInfo.TimeOutID) {
			if (S_PortalInfo.TimeOutID[a] != 0) {
				clearTimeout(S_PortalInfo.TimeOutID[a])
			}
			S_PortalInfo.TimeOutID[a] = setTimeout(a, 100)
		}
	} else {
		if (S_PortalInfo.TimeOutID[a] == null) {
			S_PortalInfo.TimeOutID[a] = 0
		}
		if (S_PortalInfo.TimeOutID[a] != 0) {
			clearTimeout(S_PortalInfo.TimeOutID[a])
		}
		S_PortalInfo.TimeOutID[a] = setTimeout(a, 100)
	}
}
window.attachEvent("onresize", Portlet_OnResize);
function Portlet_ResetText() {
	S_PortalInfo.TimeOutID["Portlet_ResetText()"] = 0;
	var a = getElementArray(document.all.LKS_Content_TXT);
	var g = false;
	var c, e, f, b, d;
	for (c = 0; c < a.length; c++) {
		f = a[c].offsetParent;
		e = f && f.lastChild;
    if(!e){
      continue;
    }
		if (e.id != "LKS_Content_END") {
			e = document
					.createElement("<a id=LKS_Content_END style='font-size:1px'></a>");
			e.innerHTML = "&nbsp;";
			f.appendChild(e)
		}
		b = parseInt(a[c].currentStyle.fontSize);
		if (isNaN(b)) {
			b = 15
		}
		if (a[c].offsetTop + b < e.offsetTop) {
			a[c].innerText = "..";
			g = true;
			continue
		}
		if (a[c].innerText == a[c].title) {
			continue
		}
		d = Math.round((f.offsetWidth - e.offsetLeft
				+ a[c].nextSibling.offsetLeft - a[c].offsetLeft)
				/ b * 2)
				- 4;
		a[c].innerText = getSubstringByByteLength(a[c].title, d)
	}
	if (g) {
		Portlet_OnResize("Portlet_ResetText()")
	}
}
function QuickNew_Scroll(b) {
	var a = getElementArray(document.all.Btn_QuickNew);
	if (a.length < 2) {
		QuickNew_CheckScrollPic();
		return
	}
	if (DIV_QuickNew.scrollLeft != Btn_QuickNew[S_PortalInfo.QuickNewIndex].offsetLeft
			&& b > 0) {
		QuickNew_CheckScrollPic();
		return
	}
	S_PortalInfo.QuickNewIndex += b;
	if (S_PortalInfo.QuickNewIndex < 0) {
		S_PortalInfo.QuickNewIndex -= b;
		QuickNew_CheckScrollPic();
		return
	}
	if (S_PortalInfo.QuickNewIndex >= a.length) {
		S_PortalInfo.QuickNewIndex -= b;
		QuickNew_CheckScrollPic();
		return
	}
	DIV_QuickNew.scrollLeft = Btn_QuickNew[S_PortalInfo.QuickNewIndex].offsetLeft;
	QuickNew_CheckScrollPic()
}
function Portlet_Refresh(a) {
	var c = getElementArray(document.all.LKS_Portlet);
	for (var b = 0; b < c.length; b++) {
		if (c[b].uniqueID == a) {
			c[b].LKS_Refresh();
			return
		}
	}
}
function QuickNew_CheckScrollPicInit() {
	var a = getElementArray(document.all.Btn_QuickNew);
	var b = DIV_QuickNew.offsetParent;
	if (!Btn_QuickNew[S_PortalInfo.QuickNewIndex]) {
		SetQuickNewScrollPic(false, false);
		return
	}
	var c = Btn_QuickNew[S_PortalInfo.QuickNewIndex].offsetWidth * (a.length);
	if (a.length < 2 || c <= (b.clientWidth + 10)) {
		SetQuickNewScrollPic(false, false);
		return
	}
	c = Btn_QuickNew[S_PortalInfo.QuickNewIndex].offsetWidth
			* (a.length - S_PortalInfo.QuickNewIndex);
	if (c >= (b.clientWidth + 8)) {
		SetQuickNewScrollPic(null, true)
	} else {
		SetQuickNewScrollPic(null, false)
	}
}
function QuickNew_CheckScrollPic() {
	try {
		var a = getElementArray(document.all.Btn_QuickNew);
		var b = DIV_QuickNew.offsetParent;
		var c = Btn_QuickNew[S_PortalInfo.QuickNewIndex].offsetWidth
				* (a.length);
		if (a.length < 2 || c <= (b.clientWidth + 10)) {
			SetQuickNewScrollPic(false, false);
			return
		}
		if (DIV_QuickNew.scrollLeft != Btn_QuickNew[S_PortalInfo.QuickNewIndex].offsetLeft) {
			SetQuickNewScrollPic(null, false)
		} else {
			SetQuickNewScrollPic(null, true)
		}
		if (S_PortalInfo.QuickNewIndex >= a.length) {
			SetQuickNewScrollPic(null, false)
		}
		if (S_PortalInfo.QuickNewIndex <= 0) {
			SetQuickNewScrollPic(false, null)
		} else {
			SetQuickNewScrollPic(true, null)
		}
	} catch (d) {
	}
}
function getXMLHeadContent(h) {
	var a = getDbPath(h.HeadURL);
	var d, g, b, c, e;
	xml = new ActiveXObject("MSXML.DOMDocument");
	xml.async = false;
	xml = getXmlDoc(h.HeadURL);
	d = xml.selectNodes("/viewentries/viewentry");
	if (d.length == 0) {
		return null
	}
	var f = new Array();
	for (e = 0; e < d.length; e++) {
		f[e] = new Array;
		for (g = d[e].firstChild; g != null; g = g.nextSibling) {
			b = g.getAttributeNode("name");
			if (b == null) {
				continue
			}
			c = b.nodeValue.toLowerCase();
			if (c.substring(0, 12) != "portletinfo_") {
				continue
			}
			if (g.text == "") {
				continue
			}
			f[e][c.substring(12)] = g.text
		}
		f[e].href = getDocUrl(a, d[e], f[e].href);
		f[e].image = getDocUrl(a, d[e], f[e].image);
		if (window.S_ICM_SERVER != null && S_ICM_SERVER != ""
				&& f[e].href.indexOf("/") == 0) {
			f[e].href = S_ICM_SERVER + f[e].href
		}
		if (window.S_ICM_SERVER != null && S_ICM_SERVER != ""
				&& f[e].image.indexOf("/") == 0) {
			f[e].image = S_ICM_SERVER + f[e].image
		}
	}
	return f
}
function checkIsNew(b, c) {
	var a = b.split("-");
	a = new Date(a[1] + "/" + a[2] + "/" + a[0]);
	a.setDate(a.getDate() + c);
	return a > S_PortalInfo.Today
}
function getDbPath(a) {
	var b = a.toLowerCase().indexOf(".nsf");
	if (b == -1) {
		return ""
	}
	return a.substring(0, b + 4) + "/"
}
function getDocUrl(a, e, g) {
	if (g == null || g == "") {
		var b = e.getAttributeNode("unid");
		if (b == null) {
			return null
		}
		return a + "0/" + b.nodeValue + "?opendocument&m_Seq=" + Math.random()
	}
	var d = new RegExp();
	d.compile("\\%当前用户\\%", "gi");
	g = g.replace(d, encodeURI(S_PortalInfo.CurUserID));
	d.compile(" ", "gi");
	g = g.replace(d, "%20");
	if (g.charAt(0) == "/") {
		return a + g.substr(g.indexOf(".nsf/") + 5)
	}
	var f = g;
	var c = f.indexOf("?");
	if (c > -1) {
		f = f.substring(0, c)
	}
	c = f.indexOf("://");
	if (c > -1) {
		return g
	}
	return a + g
}
function getXmlDoc(d) {
	var c = new ActiveXObject("MSXML.DOMDocument");
	c.async = false;
	var a = (location.protocol + "//" + location.host).toLowerCase();
	if (d.toLowerCase().indexOf("http") == 0 && d.toLowerCase().indexOf(a) != 0) {
		c.load(S_SetupPath + "/sys/lks_public.nsf/AG_GetXmlDoc?openagent&url="
				+ d)
	} else {
		c.load(d);
		var b = c.selectNodes("/viewentries");
		if (window.S_ICM_SERVER != null && S_ICM_SERVER != "" && b.length == 0
				&& d.indexOf("/") == 0) {
			c.load(S_SetupPath
					+ "/sys/lks_public.nsf/AG_GetXmlDoc?openagent&url="
					+ S_ICM_SERVER + d)
		}
	}
	return c
}
function formatUrl(a) {
	if (a == null) {
		return null
	}
	return a
}
function showMultiTab(f, a, e) {
	f = f.substring(0, f.indexOf("_number_"));
	tabs = allinfo[f].labinfo;
	var d = allinfo[f].LKS_Portlet_ID;
	var g = document.getElementById(d);
	if (g == null) {
		return
	}
	if (document.getElementById(tabs[a]["UUID"]).style.display == "") {
		return
	}
	if (e == "extend") {
		_tagParent.innerHTML = getExtendTabBlockHTML(tabs, a)
	} else {
		_tagParent.innerHTML = getLimitTabBlockHTML(tabs, a)
	}
	for (var c = 1; tabs[c]; c++) {
		if (c == a) {
			g.setAttribute("LKS_Curr_TAB_UUID", tabs[c]["UUID"]);
			var b = document.getElementById(tabs[c]["UUID"]).innerHTML;
			if (b == "") {
				g.handleTabHTML(tabs[c])
			}
			document.getElementById(tabs[c]["UUID"]).style.display = ""
		} else {
			document.getElementById(tabs[c]["UUID"]).style.display = "none"
		}
	}
	if (!S_PortalInfo.DesignMode) {
		Portlet_OnResize("Portlet_ResetText()")
	}
}
function getTagNodeParent() {
	var a = event.srcElement;
	for (; a = a.parentNode;) {
		if (a.tagName == "CODE") {
			return a
		}
	}
	return null
}
var _tabTrigger = null, _tagParent = null;
function clearShowTabTrigger() {
	if (_tabTrigger != null) {
		clearTimeout(_tabTrigger)
	}
}
function showTabTrigger(d, b, c) {
	var a = 300;
	_tagParent = getTagNodeParent();
	_tabTrigger = setTimeout('showMultiTab("' + d + '",' + b + ',"' + c + '")',
			a)
};