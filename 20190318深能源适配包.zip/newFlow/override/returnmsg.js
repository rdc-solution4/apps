/**
 * koa_lihx 20161031 实现全系统返回界面自动关闭；
 *	2、判断是否存在自定义动作，有则采用自定义动作，不关闭；
 * 	1、返回界面若无错误字样，则倒计时5.1秒后自动关闭；
 */
var ReturnMsgDaoJiShi = {};
//进入响应界面立即执行的动作
ReturnMsgDaoJiShi.firstAction=function(){
  
	var path=window.location.href;
	var ix=path.indexOf("nsf/");
	path=path.substr(0,ix).toLowerCase();
	if(path.indexOf("review")>-1 || path.indexOf("lks_flow")>-1 || 
		path.indexOf("archivemngnewex")>-1 || path.indexOf("rules")>-1 || 
		path.indexOf("filemng")>-1 || path.indexOf("lks_news")>-1 || 
		path.indexOf("workoverview")>-1){
			if(_ysp_top==window){window.opener=null;window.open('', '_self');window.close();}
	}else {
		var timeoutid=setTimeout("if(_ysp_top==window){window.opener=null;window.open('', '_self');window.close();}",5100);
	}
}
ReturnMsgDaoJiShi.firstAction_ip4=function(){
	window.open('/lks/sys/lks_systemsso.nsf/ag_openhomepageIp4?open','_self');
}
//获取按钮
ReturnMsgDaoJiShi.getBtnByValue=function(v){
	var arrs=document.getElementsByTagName("input");
	var locObj=null;
	for(var i=0;i<arrs.length;i++){
		if(arrs[i].className.toLowerCase() == "btndoc" && arrs[i].type.toLowerCase() == "button" && arrs[i].value.toLowerCase() == v){
			locObj=arrs[i];
			break;
		}
	}
	return locObj;
}
//显示倒计时
ReturnMsgDaoJiShi.showDaoJiShi=function(v,tips){
	var locObj=ReturnMsgDaoJiShi.getBtnByValue(v);
	if(locObj==null){return;}
	var jishi=document.getElementById("img_DaoJiShi");
	if(jishi==null){
		if(v=="关闭"){
			locObj.parentNode.insertAdjacentText("beforeBegin","      ");
			jishi=document.createElement("SPAN");
			jishi.style.cssText='vertical-align:middle;color:red;font-weight:bold';
			jishi.innerText='5';
			var daojishi=function(){jishi.innerText=parseInt(jishi.innerText)-1;if(parseInt(jishi.innerText)>0)setTimeout(daojishi,1000);}
			setTimeout(daojishi,1000);
			locObj.parentNode.insertAdjacentElement("beforeBegin",jishi);
			jishi.insertAdjacentHTML("afterEnd","<font style='color:red;font-weight:bold'>秒</font><font color=black>后自动"+tips+"。</font>");
		}else if(v=="返回"){
			
		}
	}
}
//自动关闭
ReturnMsgDaoJiShi.autoCloseWindow=function(){
	var locObj=ReturnMsgDaoJiShi.getBtnByValue("关闭");
	if(locObj==null){return;}
	var path=window.location.href;
	var ix=path.indexOf("nsf/");
	path=path.substr(0,ix).toLowerCase();
  
	var timeoutid=setTimeout("if(_ysp_top==window){window.opener=null;window.open('', '_self');window.close();}",5100);
}
//自动返回
ReturnMsgDaoJiShi.autoReturn=function(){
	var btn=ReturnMsgDaoJiShi.getBtnByValue("返回");
	if(btn==null){return;}
	//直接返回
	btn.click();
	//var timeoutid=setTimeout(function(){btn.click();},5100);
}