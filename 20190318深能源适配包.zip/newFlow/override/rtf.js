RegisterJsFile("rtf.js");
IncludeJsFile("rightmenu.js|dhtmledit.js");
document.writeln("<link rel=stylesheet href=" + S_DbPath + "/css/rtf.css>");
function initRtf(rtfName) {
    var rtext;
    var re;
    var i;
    var rtfDivObj = eval(rtfName + "Div");
  
    if (document.forms[0].buSaveImageNew == null ) {
        if (rtfDivObj.rtfIsEdited) {
            rtext = eval("document.all." + rtfName + ".value");
            re = /&quot;/g;
            rtext = rtext.replace(re, "\"");
            var riframe = eval(rtfName + "Iframe.document");
            riframe.designMode = "On";
            try {
                riframe.open();
                riframe.close();
                riframe.body.innerHTML = rtext;
            } 
            catch (err) {
                setTimeout("initRtf(\"" + rtfName + "\", true);", 100);
                return;
            }
            for (i = 0; i < riframe.all.length; i++)
                rtf_setImageSrc(riframe.all[i]);
            if (document.all.ImageTemplate != null ) {
                document.all.ImageTemplate.OnDocumentMouseDown = function() {
                    this.style.display = "none"
                }
                EventHandler.AddObject(document.all.ImageTemplate);
            }
            if (document.all.FlashTemplate != null ) {
                document.all.FlashTemplate.OnDocumentMouseDown = function() {
                    this.style.display = "none"
                }
                EventHandler.AddObject(document.all.FlashTemplate);
            }
        } 
        else {
            rtext = rtfDivObj.innerText;
            re = /&quot;/g;
            rtext = rtext.replace(re, "\"");
            re = / \r\n/g;
            rtext = rtext.replace(re, "");
            var rview = eval(rtfName + "View");
            rview.innerHTML = rtext;
            for (i = 0; i < rview.all.length; i++)
                rtf_reSetImageSrc(rview.all[i]);
        }
    } else {
        if (rtfDivObj.rtfIsEdited) {} else {
            rtext = rtfDivObj.innerText;
            re = /&quot;/g;
            rtext = rtext.replace(re, "\"");
            var rview = eval(rtfName + "View");
            re = /&#91;/g;
            rtext = rtext.replace(re, "\[");
            re = /&#93;/g;
            rtext = rtext.replace(re, "\]");
            re = / \r\n/g;
            rtext = rtext.replace(re, "");
            rview.innerHTML = rtext;
            for (i = 0; i < rview.all.length; i++) {
                if (parent != null  && parent.if_subform != null  && eval("document.all." + rtfName + "View") != null )
                    rtf_reSetImageSrc(rview.all[i], parent.S_DbUrl, parent.S_DocId);
                else
                    rtf_reSetImageSrc(rview.all[i]);
            }
        }
    }
}
function initRtfImage(img) {
    var strHtml = "";
    var strImage;
    switch (img.Type) {
    case "Image":
        strImage = S_DbUrl + "/0/" + S_DocId + "/$file/" + escape(img.Src.substring(img.Src.lastIndexOf("\\") + 1));
        strHtml = "<img src='" + strImage + "' ImgUrl='" + strImage + "' border=0";
        if (img.Align)
            strHtml += " align=" + img.Align;
        strHtml += ">";
        break;
    case "Flash":
        strImage = S_DbUrl + "/0/" + S_DocId + "/$file/" + escape(img.Src.substring(img.Src.lastIndexOf("\\") + 1));
        strHtml = "<OBJECT classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://active.macromedia.com/flash2/cabs/swflash.cab#version=4,0,0,0'>";
        strHtml += "<PARAM NAME=movie VALUE='" + strImage + "'>";
        strHtml += "<PARAM NAME=quality VALUE=high>";
        strHtml += "<EMBED src='" + strImage + "' quality=high  TYPE='application/x-shockwave-flash' PLUGINSPAGE='http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash'>";
        strHtml += "</EMBED></OBJECT>";
        break;
    }
    img.outerHTML = strHtml;
}
function saveRtf(rtfName) {
    if (document.forms[0].buSaveImageNew == null ) {
        rtext = eval(rtfName + "Iframe.document.body.innerHTML");
    } else {
        setCurrentIframeID(rtfName + "Iframe");
        if (eval(IframeID).Dvbbs_bTextMode != 1) {
            rtext = IframeID.document.body.innerText;
        } else {
            rtext = IframeID.document.body.innerHTML;
        }
    }
    var fieldRtf = eval("document.all." + rtfName);
    var re = /\"/g;
    rtext = rtext.replace(re, "&quot;");
    re = /<form>/gi;
    rtext = rtext.replace(re, "<FORMA>");
    re = /<form(\s+)/gi;
    rtext = rtext.replace(re, "<FORMA$1");
    re = /<\/form>/gi;
    rtext = rtext.replace(re, "</FORMA>");
    re = /\[/gi;
    rtext = rtext.replace(re, "&#38;#91;");
    re = /\]/gi;
    rtext = rtext.replace(re, "&#38;#93;");
    fieldRtf.value = rtext;
}
function insertTable(rtfName) {
    var tableinfo = showModalDialog(S_DbPath + "/html/table.htm", null , "dialogWidth:390px; dialogHeight:390px; status:0; resizable:1");
    if (tableinfo) {
        var strTable = "<table";
        if (tableinfo.T_Width.length > 0)
            strTable += " width=" + tableinfo.T_Width;
        if (tableinfo.T_Height.length > 0)
            strTable += " height=" + tableinfo.T_Height;
        if (tableinfo.T_Border.length > 0)
            strTable += " border=" + tableinfo.T_Border;
        if (tableinfo.T_BgColor.length > 0)
            strTable += " bgcolor=" + tableinfo.T_BgColor;
        if (tableinfo.T_CellPadding.length > 0)
            strTable += " cellpadding=" + tableinfo.T_CellPadding;
        if (tableinfo.T_CellSpacing.length > 0)
            strTable += " cellspacing=" + tableinfo.T_CellSpacing;
        strTable += ">";
        var nRow = parseInt(tableinfo.T_Row);
        if (isNaN(nRow))
            nRow = 1;
        var nCol = parseInt(tableinfo.T_Col);
        if (isNaN(nCol))
            nCol = 1;
        var flagw = tableinfo.T_Width.substring(tableinfo.T_Width.length - 1);
        var width = parseInt(flagw != "%" ? tableinfo.T_Width : tableinfo.T_Width.substring(0, tableinfo.T_Width.length - 1));
        var tdwidth = isNaN(width) ? "" : (flagw == "%" ? (width / nCol).toString() + "%" : (width / nCol).toString());
        var flagh = tableinfo.T_Height.substring(tableinfo.T_Height.length - 1);
        var height = parseInt(flagh != "%" ? tableinfo.T_Height : tableinfo.T_Height.substring(0, tableinfo.T_Height.length - 1));
        var tdheight = isNaN(height) ? "" : (flagw == "%" ? (height / nRow).toString() + "%" : (height / nRow).toString());
        for (var i = 0; i < nRow; i++) {
            strTable += "<tr>";
            for (var j = 0; j < nCol; j++) {
                strTable += "<td";
                if (tableinfo.TD_BgColor.length > 0)
                    strTable += " bgcolor=" + tableinfo.TD_BgColor;
                if (tableinfo.TD_NoWrap)
                    strTable += " nowrap";
                if (tdwidth.length)
                    strTable += " width=" + tdwidth;
                if (tdheight.length)
                    strTable += " height=" + tdheight;
                strTable += "></td>";
            }
            strTable += "</tr>";
        }
        strTable += "</table>";
        insertHTML(rtfName, strTable);
    }
}
function editTD(rtfName) {
    var otb = getCurTable(rtfName);
    var otd = getCurTD(rtfName);
    if (!otd || !otb)
        return;
    var obj = new Object;
    obj.TD_Width = otd.width;
    obj.TD_Height = otd.height;
    obj.TD_BgColor = otd.bgColor;
    obj.TD_NoWrap = otd.noWrap;
    var tdinfo = showModalDialog(S_DbPath + "/html/td.htm", obj, "dialogWidth:390px; dialogHeight:220px; status:0; resizable:1");
    if (tdinfo) {
        otd.width = tdinfo.TD_Width;
        otd.height = tdinfo.TD_Height;
        otd.bgColor = tdinfo.TD_BgColor;
        otd.noWrap = tdinfo.TD_NoWrap;
        otb.width = "";
        otb.height = "";
    }
}
function getCurTable(rtfName) {
    var riframe = eval(rtfName + "Iframe");
    riframe.focus();
    var redit = riframe.document.selection.createRange();
    var otable = redit.parentElement();
    while (otable.tagName != "TABLE" && otable.tagName != "BODY")
        otable = otable.parentElement;
    if (otable.tagName == "TABLE")
        return otable;
    else
        return null ;
}
function getCurTD(rtfName) {
    var riframe = eval(rtfName + "Iframe");
    riframe.focus();
    var redit = riframe.document.selection.createRange();
    var otd = redit.parentElement();
    while (otd.tagName != "TD" && otd.tagName != "BODY")
        otd = otd.parentElement;
    if (otd.tagName == "TD")
        return otd;
    else
        return null ;
}
function calculateTable(rtfName) {
    var r, c;
    var i;
    var t;
    var total = 0;
    var myTable = getCurTable(rtfName);
    if (myTable) {
        r = myTable.rows.length - 1;
        c = myTable.rows[0].cells.length - 1;
        for (i = 1; i < r; i++) {
            t = parseFloat(myTable.rows[i].cells[c].innerText);
            if (!isNaN(t))
                total += t;
        }
        myTable.rows[r].cells[c].innerText = total;
    }
}
function insertCell(rtfName) {
    var i, j, newTD;
    var myTable = getCurTable(rtfName);
    if (myTable) {
        for (i = 0; i < myTable.rows.length; i++) {
            j = myTable.rows[i].cells.length - 1;
            newTD = myTable.rows[i].cells[j].cloneNode(true);
            newTD.innerText = "";
            newTD.colSpan = 1;
            myTable.rows[i].cells[j].insertAdjacentElement("afterEnd", newTD);
        }
        i = myTable.rows[0].cells.length - 1;
        myTable.rows[0].cells[i].innerText = "标题" + i;
    }
}
function deleteCell(rtfName) {
    var i;
    var myTable = getCurTable(rtfName);
    if (myTable) {
        if (myTable.rows[0].cells.length < 2)
            alert("该表格已剩下一列，如果您想要删除表格，请在表格边框上点击一下，选中后按Del键删除。");
        else
            for (i = 0; i < myTable.rows.length; i++)
                myTable.rows[i].deleteCell();
    }
}
function insertRow(rtfName) {
    var i, j, newTR;
    var orow;
    var myTable = getCurTable(rtfName);
    if (myTable) {
        i = myTable.rows.length - 1;
        newTR = myTable.rows[i].cloneNode(true);
        myTable.rows[i].insertAdjacentElement("afterEnd", newTR);
        i++;
        for (j = 0; j < myTable.rows[i].cells.length; j++)
            myTable.rows[i].cells[j].innerText = "";
    }
}
function deleteRow(rtfName) {
    var i, j;
    var orow;
    var myTable = getCurTable(rtfName);
    if (myTable) {
        if (myTable.rows.length < 2)
            alert("该表格已剩下一行，如果您想要删除表格，请在表格边框上点击一下，选中后按Del键删除。");
        else
            myTable.deleteRow();
    }
}
function ColumnInfo(rtfName) {
    var myTable = getCurTable(rtfName);
}
function writeRtfEditBar(rtfName, width) {
    var imgpath = S_DbPath + "/";
    var bartext = "<script FOR=rtfIconTd EVENT=onmouseover> event.srcElement" + ".style.backgroundImage='url(" + imgpath + "icons/rtf/mouseup.gif)'; </script>" + "<script FOR=rtfIconTd EVENT=onmouseout> event.srcElement" + ".style.backgroundImage='none'; </script>" + "<script FOR=rtfIconTd EVENT=onmousedown> event.srcElement" + ".style.backgroundImage='url(" + imgpath + "icons/rtf/mousedown.gif)'; </script>" + "<script FOR=rtfIconTd EVENT=onmouseup> event.srcElement" + ".style.backgroundImage='url(" + imgpath + "icons/rtf/mouseup.gif)'; </script>" + "<script FOR=rtfIconTd EVENT=onload> event.srcElement" + ".style.backgroundImage='url(" + imgpath + "icons/rtf/normal.gif)'; </script>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/copy.gif border=0 align=absmiddle " + "alt=拷贝 onClick=doFormat('" + rtfName + "','Copy')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/cut.gif border=0 align=absmiddle " + "alt=剪切 onClick=doFormat('" + rtfName + "','Cut')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/paste.gif border=0 align=absmiddle " + "alt=粘贴 onClick=doFormat('" + rtfName + "','Paste')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/undo.gif border=0 align=absmiddle " + "alt=撤消 onClick=doFormat('" + rtfName + "','Undo')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/redo.gif border=0 align=absmiddle " + "alt=复原 onClick=doFormat('" + rtfName + "','Redo')></span>" + "\n<img src=" + imgpath + "icons/rtf/ge.gif border=0>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/fontname.gif border=0 align=absmiddle " + "alt=字体名称 onClick=selectFontName('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/fontsize.gif border=0 align=absmiddle " + "alt=字体大小 onClick=selectFontSize('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/fontcolor.gif border=0 align=absmiddle " + "alt=字体颜色 onClick=selectForeColor('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/bold.gif border=0 align=absmiddle " + "alt=粗体 onClick=doFormat('" + rtfName + "','Bold')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/italic.gif border=0 align=absmiddle " + "alt=斜体 onClick=doFormat('" + rtfName + "','Italic')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/underline.gif border=0 align=absmiddle " + "alt=下画线 onClick=doFormat('" + rtfName + "','Underline')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/left.gif border=0 align=absmiddle " + "alt=居左 onClick=doFormat('" + rtfName + "','JustifyLeft')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/center.gif border=0 align=absmiddle " + "alt=居中 onClick=doFormat('" + rtfName + "','JustifyCenter')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/right.gif border=0 align=absmiddle " + "alt=居右 onClick=doFormat('" + rtfName + "','JustifyRight')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/indent.gif border=0 align=absmiddle " + "alt=增加缩进 onClick=doFormat('" + rtfName + "','Indent')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/outdent.gif border=0 align=absmiddle " + "alt=减少缩进 onClick=doFormat('" + rtfName + "','Outdent')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/numlist.gif border=0 align=absmiddle " + "alt=数字编号 onClick=doFormat('" + rtfName + "','InsertOrderedList')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/bullist.gif border=0 align=absmiddle " + "alt=项目编号 onClick=doFormat('" + rtfName + "','InsertUnorderedList')></span>" + "\n<img src=" + imgpath + "icons/rtf/ge.gif border=0>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/instable.gif border=0 align=absmiddle " + "alt=添加表格 onClick=insertTable('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/prptd.gif border=0 align=absmiddle " + "alt=单元格属性 onClick=editTD('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/insrow.gif border=0 align=absmiddle " + "alt=添加行 onClick=insertRow('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/delrow.gif border=0 align=absmiddle " + "alt=减少行 onClick=deleteRow('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/inscol.gif border=0 align=absmiddle " + "alt=添加列 onClick=insertCell('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/delcol.gif border=0 align=absmiddle " + "alt=减少列 onClick=deleteCell('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/calculate.gif border=0 align=absmiddle " + "alt=统计最后一列 onClick=calculateTable('" + rtfName + "')></span>" + "\n<img src=" + imgpath + "icons/rtf/ge.gif border=0>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/link.gif border=0 align=absmiddle " + "alt=编辑链接 onClick=doFormat('" + rtfName + "','CreateLink')></span>";
    if (document.all.ImageTemplate != null )
        bartext += "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/insimage.gif border=0 align=absmiddle " + "alt=插入图片 onClick=showImageTools('" + rtfName + "')></span>";
    if (document.all.FlashTemplate != null )
        bartext += "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/insflash.gif border=0 align=absmiddle " + "alt=插入Flash onClick=showFlashTools('" + rtfName + "')></span>" + "<span id=rtfIconTd><img src=" + imgpath + "icons/rtf/help.gif border=0 align=absmiddle " + "alt=重要提示 onClick=help();></span>";
    bartext += "<br>";
    document.write(bartext);
}
function writeRtf(rtfName, width, height, rtfstyle, rtfIsEdited, canUpload) {
    if (height == null )
        height = "301";
    if (typeof (S_IsEdited) == "undefined" && typeof (window.S_IsEdited) != "undefined")
        S_IsEdited = window.S_IsEdited;
    if (typeof (S_IsEdited) == "undefined")
        S_IsEdited = isEdited;
    rtfIsEdited = (rtfIsEdited == null ) ? S_IsEdited : rtfIsEdited;
    var rtfDivObj = eval(rtfName + "Div");
 
    rtfDivObj.rtfIsEdited = rtfIsEdited;
    if (rtfIsEdited) {
        if (document.forms[0].buSaveImageNew == null ) {
            if (rtfstyle == null  || rtfstyle == 2)
                writeRtfEditBar(rtfName, width);
            document.write("<iframe marginwidth=4 marginheight=0 frameborder=0 id=" + rtfName + "Iframe width=" + width + " height=" + height + " class=iframe></iframe>");
        } else {
            if (rtfstyle == null  || rtfstyle == 2) {
                writeRtfEditBarNew(rtfName, width, height, canUpload);
            } else {
                document.write("<iframe ID=\"" + rtfName + "Iframe\" MARGINHEIGHT=\"5\" MARGINWIDTH=\"5\" width=\"" + width + "\" height=\"" + height + "\"></iframe>");
            }
            if (Dvbbs_bIsIE5) {
                IframeID = frames[rtfName + "Iframe"];
            } 
            else {
                IframeID = document.getElementById(rtfName + "Iframe").contentWindow;
                Dvbbs_bIsNC = true;
            }
            Dvbbs_InitDocument(rtfName, "GB2312", "");
        }
    } 
    else {
//        var table = document.createElement('table');
//       table.innerHTML = '<tr><td id="' + rtfName + 'View"></td></tr>';
//       table.setAttribute('width',width);
     
//       var rtfBody = document.querySelector('#'+rtfName+'Div');
//       rtfBody.parentElement.appendChild(table);
      document.write("<table width=" + width + "><tr><td id=" + rtfName + "View></td></tr></table>");
    }
}
function selectNone(source) {
    source.selectedIndex = 0;
}
function refreshTableMenu(rtfName) {
    var i, j;
    var tableMenu = eval("document.all." + rtfName + "Table");
    var riframe = eval(rtfName + "Iframe");
    var tbls = riframe.document.all.tags("TABLE");
    while (tableMenu.options.length > 1)
        tableMenu.options[1] = null ;
    for (i = 0; i < tbls.length; i++) {
        tbls[i].id = "otable_" + (i + 1);
        j = tableMenu.options.length;
        tableMenu.options[j] = new Option("表格" + (i + 1));
        tableMenu.options[j].value = i + 1;
    }
}
function insertHTML(who, strHtml) {
    var riframe = eval(who + "Iframe");
    riframe.focus();
    var redit = riframe.document.selection.createRange();
    if (redit != null ) {
        redit.pasteHTML(strHtml);
    }
    riframe.focus()
}
function insertInputImage(who) {
    var riframe = eval(who + "Iframe");
    riframe.focus();
    riframe.document.execCommand("InsertInputImage", false, "myInsert");
    riframe.myInsert.style.display = "none";
    riframe.focus();
}
function insertImage(rtfName, ImgPath, align) {
    strHtml = "<span NoInit=1 Type=Image Src='" + ImgPath + "'" + (align ? (" Align=" + align) : "") + "></span>";
    insertHTML(rtfName, strHtml);
}
function insertFlash(rtfName, ImgPath) {
    strHtml = "<span NoInit=1 Type=Flash Src='" + ImgPath + "'></span>";
    insertHTML(rtfName, strHtml);
}
function setImageSrc(who, strImg) {
    var riframe = eval(who + "Iframe");
    var rimage = riframe.myInsert;
    var style = "";
    if (arguments[2] != null )
        style = " align=" + arguments[2];
    if (rimage != null ) {
        rimage.outerHTML = "<img id=" + who + "Img ImgUrl=" + strImg + " src=\"" + strImg + "\"" + style + ">";
    }
}
function doFormat(who, what) {
    var riframe = eval(who + "Iframe");
    riframe.focus();
    if (arguments[2] == null ) {
        riframe.document.execCommand(what);
    } 
    else {
        riframe.document.execCommand(what, false, arguments[2]);
    }
    riframe.focus();
}
function selectFontName(rtfName) {
    var rm = new RightMenuObject();
    rm.AddItem("<font face='宋体'>宋体</font>", "doFormat", "'" + rtfName + "','FontName','宋体'");
    rm.AddItem("<font face='黑体'>黑体</font>", "doFormat", "'" + rtfName + "','FontName','黑体'");
    rm.AddItem("<font face='楷体_GB2312'>楷体</font>", "doFormat", "'" + rtfName + "','FontName','楷体_GB2312'");
    rm.AddItem("<font face='Arial'>Arial</font>", "doFormat", "'" + rtfName + "','FontName','Arial'");
    rm.AddItem("<font face='Courier New'>Courier</font>", "doFormat", "'" + rtfName + "','FontName','Courier New'");
    rm.AddItem("<font face='Times New Roman'>Roman</font>", "doFormat", "'" + rtfName + "','FontName','Times New Roman'");
    rm.AddItem("<font face='Tahoma'>Tahoma</font>", "doFormat", "'" + rtfName + "','FontName','Tahoma'");
    rm.Show();
}
function selectFontSize(rtfName) {
    var rm = new RightMenuObject();
    rm.AddItem("<font size=1>1号</font>", "doFormat", "'" + rtfName + "','FontSize','1'");
    rm.AddItem("<font size=2>2号</font>", "doFormat", "'" + rtfName + "','FontSize','2'");
    rm.AddItem("<font size=3>3号</font>", "doFormat", "'" + rtfName + "','FontSize','3'");
    rm.AddItem("<font size=4>4号</font>", "doFormat", "'" + rtfName + "','FontSize','4'");
    rm.AddItem("<font size=5>5号</font>", "doFormat", "'" + rtfName + "','FontSize','5'");
    rm.AddItem("<font size=6>6号</font>", "doFormat", "'" + rtfName + "','FontSize','6'");
    rm.AddItem("<font size=7>7号</font>", "doFormat", "'" + rtfName + "','FontSize','7'");
    rm.Show();
}
function selectForeColor(rtfName) {
    var rm = new RightMenuObject();
    rm.AddItem("<font color=#FF0000>红色</font>", "doFormat", "'" + rtfName + "','ForeColor','#FF0000'");
    rm.AddItem("<font color=#800000>暗红</font>", "doFormat", "'" + rtfName + "','ForeColor','#800000'");
    rm.AddItem("<font color=#00FF00>绿色</font>", "doFormat", "'" + rtfName + "','ForeColor','#00FF00'");
    rm.AddItem("<font color=#008000>暗绿</font>", "doFormat", "'" + rtfName + "','ForeColor','#008000'");
    rm.AddItem("<font color=#0000FF>蓝色</font>", "doFormat", "'" + rtfName + "','ForeColor','#0000FF'");
    rm.AddItem("<font color=#000080>暗蓝</font>", "doFormat", "'" + rtfName + "','ForeColor','#000080'");
    rm.AddItem("<font color=#FFFF00>黄色</font>", "doFormat", "'" + rtfName + "','ForeColor','#FFFF00'");
    rm.AddItem("<font color=#808000>暗黄</font>", "doFormat", "'" + rtfName + "','ForeColor','#808000'");
    rm.AddItem("<font color=#FF00FF>紫色</font>", "doFormat", "'" + rtfName + "','ForeColor','#800080'");
    rm.AddItem("<font color=#800080>暗紫</font>", "doFormat", "'" + rtfName + "','ForeColor','#800080'");
    rm.AddItem("<font color=#000000>黑色</font>", "doFormat", "'" + rtfName + "','ForeColor','#000000'");
    rm.AddItem("其他", "customForeColor", "'" + rtfName + "'");
    rm.Show();
}
function customForeColor(rtfName) {
    var color = showModalDialog(S_DbPath + "/html/color.htm", color, "dialogWidth:320px; dialogHeight:280px; status:0; resizable:1");
    if (color) {
        doFormat(rtfName, "ForeColor", color);
    }
}
function showImageTools(rtfName) {
    var obj = document.all.ImageTemplate;
    var x = 0;
    for (var p = event.srcElement.parentNode.parentNode; p.offsetParent != null ; p = p.offsetParent)
        x += p.offsetLeft;
    obj.style.left = x + 25;
    var h = -55;
    var version = navigator.appVersion;
    var i = version.indexOf("MSIE");
    if (i > -1) {
        version = version.substring(i + 5);
        i = version.indexOf(".");
        if (i > -1) {
            version = version.substring(0, i);
            if (parseInt(version) > 5)
                h = 25;
        }
    }
    obj.style.top = event.y - event.offsetY + h + document.body.scrollTop;
    obj.Field = rtfName;
    obj.className = "textdocall";
    if (obj.style.display == "none")
        obj.style.display = "block";
    else
        obj.style.display = "none";
}
function showFlashTools(rtfName) {
    var obj = document.all.FlashTemplate;
    var x = 0;
    for (var p = event.srcElement.parentNode.parentNode; p.offsetParent != null ; p = p.offsetParent)
        x += p.offsetLeft;
    obj.style.left = x + 25;
    var h = -55;
    var version = navigator.appVersion;
    var i = version.indexOf("MSIE");
    if (i > -1) {
        version = version.substring(i + 5);
        i = version.indexOf(".");
        if (i > -1) {
            version = version.substring(0, i);
            if (parseInt(version) > 5)
                h = 25;
        }
    }
    obj.style.top = event.y - event.offsetY + h + document.body.scrollTop;
    obj.Field = rtfName;
    obj.className = "textdocall";
    if (obj.style.display == "none")
        obj.style.display = "block";
    else
        obj.style.display = "none";
}
function InsetImg(rtfName) {
    if (isEdited == "1") {
        var f = document.forms[0];
        if (f.F_img.value != "") {
            str_path = S_DbUrl + "/0/" + DocId + "/$File/" + f.F_img.value;
            setImageSrc(rtfName, str_path, f.F_Position[f.F_Position.options.selectedIndex].value);
            f.F_img.value = "";
        }
    }
}
function help() {
    var s = "如果编辑框中的内容是拷贝自其它文字处理程序（如：Microsoft Word），\n\n则可能包含浏览器无法识别的特殊字符，从而导致文档提交失败！\n\n若出现此情况，建议您将此内容作为附件的形式保存在文档中。";
    alert(s);
}
function rtf_setImageSrc(img) {
    if (img.ImgUrl != null ) {
        img.src = img.ImgUrl;
        var imgUrl = img.ImgUrl;
        var thisUrl = S_DbUrl + "/0/" + S_DocId + "/$file/";
        if (imgUrl.substring(0, thisUrl.length).toLowerCase() != thisUrl.toLowerCase()) {
            var i = imgUrl.lastIndexOf("/$file/");
            if (i > 0) {
                thisUrl += imgUrl.substring(i + 7);
                var newImg = new Image();
                newImg.srcImg = img;
                newImg.ImgUrl = thisUrl;
                newImg.onload = function() {
                    if (!this.srcImg.complete) {
                        this.srcImg.ImgUrl = this.ImgUrl;
                        this.srcImg.src = this.ImgUrl;
                    }
                    this.removeNode();
                }
                var oldImg = new Image();
                oldImg.srcImg = img;
                oldImg.newImg = newImg;
                oldImg.ImgUrl = imgUrl;
                oldImg.onload = function() {
                    this.newImg.removeNode();
                    if (this.srcImg.ImgUrl != this.ImgUrl) {
                        this.srcImg.ImgUrl = this.ImgUrl;
                        this.srcImg.src = this.ImgUrl;
                    }
                    this.removeNode();
                }
                oldImg.src = imgUrl;
                newImg.src = thisUrl;
            }
        }
    }
    if (img.NoInit == "1")
        initRtfImage(img);
}
function rtf_reSetImageSrc(img, dbpath, docid) {
    if (img.ImgUrl != null ) {
        img.src = img.ImgUrl;
        var imgUrl = img.ImgUrl;
        var thisUrl = "";
        if (dbpath != null  && docid != null )
            thisUrl = dbpath + "/0/" + docid + "/$file/";
        else
            thisUrl = S_DbUrl + "/0/" + S_DocId + "/$file/";
        if (imgUrl.substring(0, thisUrl.length).toLowerCase() != thisUrl.toLowerCase()) {
            var i = imgUrl.lastIndexOf("/$file/");
            if (i > 0) {
                thisUrl += imgUrl.substring(i + 7);
                var newImg = new Image();
                newImg.srcImg = img;
                newImg.ImgUrl = thisUrl;
                newImg.onload = function() {
                    if (!this.srcImg.complete) {
                        this.srcImg.ImgUrl = this.ImgUrl;
                        this.srcImg.src = this.ImgUrl;
                    }
                    this.removeNode();
                }
                var oldImg = new Image();
                oldImg.srcImg = img;
                oldImg.newImg = newImg;
                oldImg.ImgUrl = imgUrl;
                oldImg.onload = function() {
                    this.newImg.removeNode();
                    if (this.srcImg.ImgUrl != this.ImgUrl) {
                        this.srcImg.ImgUrl = this.ImgUrl;
                        this.srcImg.src = this.ImgUrl;
                    }
                    this.removeNode();
                }
                oldImg.src = imgUrl;
                newImg.src = thisUrl;
            }
        }
    }
    if (img.NoInit == "1")
        initRtfImage(img);
}
