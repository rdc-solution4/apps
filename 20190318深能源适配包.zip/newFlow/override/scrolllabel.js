var S_PortalInfo = new Object();
S_PortalInfo.Path = "../../workplace/";
S_PortalInfo.CurIndex = 0;
S_PortalInfo.PageList = new Array;
S_PortalInfo.StylePath = "../../" + S_CurrentStyle + "/";
window.onresize = Win_OnResize;
function Win_OnResize() {
    var b = Nav_TBObj.rows[0].clientHeight;
    var a = document.body.clientHeight - S_PortalInfo.PageList.length * b - Nav_TBObj.offsetTop - 2;
    Nav_TBObj.rows[S_PortalInfo.CurIndex * 2 + 1].height = a < 1 ? 1 : a
}
function scrollBar(d, a) {
    if (S_PortalInfo.CurIndex == d) {
        return
    }
    var f = d * 2 + 1;
    var c = S_PortalInfo.CurIndex * 2 + 1;
    var h = Nav_TBObj.rows[0].clientHeight;
    var k = document.body.clientHeight - S_PortalInfo.PageList.length * h - Nav_TBObj.offsetTop - 2;
    if (a == null ) {
        Nav_TBObj.rows[f].style.display = "";
        a = 0
    }
    a += 80;
    if (a >= k) {
        a = k;
        Nav_TBObj.rows[c].height = 1;
        Nav_TBObj.rows[c].style.display = "none";
        S_PortalInfo.CurIndex = d;
        try {
            var b = window["Nav_Iframe_" + d];
            if (b.location.href.substring(0, 11) == "about:blank") {
                b.location = getNavUrl(S_PortalInfo.PageList[d])
            }
        } catch (g) {}
    } else {
        Nav_TBObj.rows[c].height = k - a;
        setTimeout("scrollBar(" + d + ", " + a + ")", 1)
    }
    Nav_TBObj.rows[f].height = a < 1 ? 1 : a
}
function getScrollBarHTML(d) {
    var d = getNavInfo();
    var c, b, a, e;
    var f = "<table border=0 cellpadding=0 cellspacing=0 id=Nav_TBObj width=100%>";
    for (c = 0; c < d.length; c++) {
        b = d[c].indexOf("|");
        a = d[c].substring(0, b);
        e = d[c].substring(b + 1);
        S_PortalInfo.PageList[c] = e;
        f += "<tr><td class=navbar_label onclick=scrollBar(" + c + ")>" + getNavBarHTML(a) + "</td></tr>";
        f += "<tr" + (c != 0 ? " style='display:none'" : "") + " height=1><td class=navbar_page><div style='width:100%;height:100%;overflow:auto'>";
        f += "<iframe id=Nav_Iframe_" + c + (c == 0 ? ' src="' + getNavUrl(e) + '"' : "") + " width=100% height=100% frameborder=0></iframe>";
        f += "</div></td></tr>"
    }
    f += "</table>";
    return f
}
function getNavInfo() {
    var b = new Array;
    if (document.all.F_NavInfo == null ) {
        return b
    }
    if (document.all.F_NavInfo.length == null ) {
        b[0] = document.all.F_NavInfo.value
    } else {
        for (var a = 0; a < document.all.F_NavInfo.length; a++) {
            b[a] = document.all.F_NavInfo[a].value
        }
    }
    return b
}
function getNavUrl(a) {
    return a + "&css=" + S_CurrentStyle
}
;