if (window.S_JsFileList != null )
    RegisterJsFile("treestruct1.4.js");
var TreeNodeUNIDCounter = 0;
function TreeNode(parent, title, type, href, target, parameter) {
    var now, prev, save;
    if (parent != null ) {
        if (target == null  || target == "")
            target = parent.target;
        if (type == null  || type == "")
            type = parent.type;
    } else {
        if (target == null )
            target = "";
        if (type == null )
            type = "";
    }
    this.id = TreeNodeUNIDCounter++;
    this.title = title;
    this.type = type;
    this.parent = parent;
    this.href = href;
    this.target = target;
    this.parameter = parameter;
    this.ImgOpened = "";
    this.ImgClosed = "";
    this.HasNotFetchChildrenNode = 0;
    this.CreatedByAppendView = 0;
    this.MenuType = new Array();
    this.MenuTarget = new Array();
    this.ViewName = new Array();
    this.HrefPrefix = new Array();
    this.LevelSep = new Array();
    this.parameterlist = new Array();
    this.ViewInfo = new Array();
    this.removeNode = TreeNode_RemoveNode;
    this.insertBefore = TreeNode_InsertBefore;
    this.setHTMLDirty = TreeNode_SetHTMLDirty;
    if (parent == null ) {
        this.prevsibling = null ;
        this.nextsibling = null ;
        this.firstchild = null ;
        this.lastchild = null ;
    } else {
        prev = parent.lastchild;
        if (prev == null ) {
            save = parent.firstchild;
            parent.firstchild = this;
            this.nextsibling = save;
            this.prevsibling = null ;
            if (save != null )
                save.prevsibling = this;
        } else {
            save = prev.nextsibling;
            prev.nextsibling = this;
            this.nextsibling = save;
            this.prevsibling = prev;
            if (save != null )
                save.prevsibling = this;
        }
        parent.lastchild = this;
    }
}
function TreeNode_RemoveNode() {
    var pNode = this.parent;
    if (pNode == null )
        return false;
    var nxtNode = this.nextsibling;
    var preNode = this.prevsibling;
    if (nxtNode == null )
        pNode.lastchild = preNode;
    else {
        nxtNode.prevsibling = preNode;
        nxtNode.setHTMLDirty();
    }
    if (preNode == null )
        pNode.firstchild = nxtNode;
    else {
        preNode.nextsibling = nxtNode;
        preNode.setHTMLDirty();
    }
    pNode.setHTMLDirty();
    this.parent = null ;
    this.prevsibling = null ;
    this.nextsibling = null ;
    return true;
}
function TreeNode_InsertBefore(newNode, nxtNode) {
    if (nxtNode != null  && nxtNode.parent != this)
        return false;
    var now, preNode;
    for (now = this; now != null ; now = now.parent)
        if (now == newNode)
            return false;
    preNode = nxtNode == null  ? this.lastchild : nxtNode.prevsibling;
    newNode.removeNode();
    newNode.parent = this;
    newNode.nextsibling = nxtNode;
    newNode.prevsibling = preNode;
    if (nxtNode == null )
        this.lastchild = newNode;
    else {
        nxtNode.prevsibling = newNode;
        nxtNode.setHTMLDirty();
    }
    if (preNode == null )
        this.firstchild = newNode;
    else {
        preNode.nextsibling = newNode;
        preNode.setHTMLDirty();
    }
    this.setHTMLDirty();
    newNode.setHTMLDirty();
    return true;
}
function TreeNode_SetHTMLDirty() {
    this.IsExpandedHTMLDirty = true;
    this.IsCollapsedHTMLDirty = true;
    for (var now = this.firstchild; now != null ; now = now.nextsibling)
        now.setHTMLDirty();
}
function MakeResponse(parent, node) {
    var save;
    node.parent = parent;
    node.prevsibling = null ;
    save = parent.firstchild;
    node.nextsibling = save;
    if (save != null )
        save.prevsibling = node;
    parent.firstchild = node;
    if (parent.lastchild == null )
        parent.lastchild = node;
}
function CreatePath(root, path, type, href, target, LevelSep, parameter, info, order) {
    if (LevelSep == null )
        LevelSep = "/";
    var p;
    var GoOn;
    var part;
    var parent, now;
    GoOn = true;
    now = null ;
    parent = root;
    p = path.indexOf(LevelSep);
    if (p < 0)
        return null ;
    while (GoOn) {
        p = p + 1;
        if (p >= path.length)
            break;
        path = path.substring(p, path.length);
        p = path.indexOf(LevelSep);
        if (p < 0) {
            GoOn = false;
            part = path;
        } 
        else
            part = path.substring(0, p);
        part = m_StrTrim(part);
        if (part != "") {
            now = GetChildByTitle(parent, part);
            if (now == null ) {
                now = new TreeNode(parent,part,"","");
                if (now == null )
                    return null ;
                if (parent != null  && parent.CreatedByAppendView > 0)
                    now.CreatedByAppendView = 1;
            }
            parent = now;
        }
    }
    if (now != null ) {
        if (type != null )
            now.type = type;
        if (target != null )
            now.target = target;
        if (parameter != null )
            now.parameter = parameter;
        if (info != null )
            now.info = info;
        if (order != null )
            now.order = order;
        now.href = href;
    }
    return now;
}
function GetNodePath(node, SepStr) {
    var Result = "";
    if (SepStr == null )
        SepStr = "\\";
    if (node == null )
        return "";
    if (node.parent == null )
        return SepStr;
    while (node.parent != null ) {
        Result = SepStr + node.title + Result;
        node = node.parent;
    }
    return Result;
}
function GetNodeByID(root, id) {
    var now, result;
    if (root == null )
        return null ;
    if (root.id == id)
        return root;
    now = root.firstchild;
    while (now != null ) {
        result = GetNodeByID(now, id);
        if (result == null )
            now = now.nextsibling;
        else
            return result;
    }
    return null ;
}
function GetNodeByPath(root, path) {
    var p;
    var GoOn;
    var part;
    var parent, now;
    GoOn = true;
    now = root;
    parent = root;
    p = path.indexOf("\\");
    if (p < 0)
        return null ;
    if (path == "\\")
        return root;
    while (GoOn) {
        p = p + 1;
        if (p >= path.length)
            break;
        path = path.substring(p, path.length);
        p = path.indexOf("\\");
        if (p < 0) {
            GoOn = false;
            part = path;
        } 
        else
            part = path.substring(0, p);
        part = m_StrTrim(part);
        if (part != "") {
            if (now.HasNotFetchChildrenNode != 0)
                UserTreeViewFetchChildrenNode(now);
            now = GetChildByTitle(parent, part);
            if (now == null )
                return null ;
            parent = now;
        }
    }
    return now;
}
function GetPathLastValidNode(root, path) {
    var p;
    var GoOn;
    var part;
    var parent, now;
    GoOn = true;
    now = root;
    parent = root;
    p = path.indexOf("\\");
    if (p < 0)
        return parent;
    if (path == "\\")
        return root;
    while (GoOn) {
        p = p + 1;
        if (p >= path.length)
            break;
        path = path.substring(p, path.length);
        p = path.indexOf("\\");
        if (p < 0) {
            GoOn = false;
            part = path;
        } 
        else
            part = path.substring(0, p);
        part = m_StrTrim(part);
        if (part != "") {
            now = GetChildByTitle(parent, part);
            if (now == null )
                return parent;
            parent = now;
        }
    }
    return now;
}
function GetChildByTitle(parent, title) {
    var now, prev;
    if (parent == null )
        return null ;
    else {
        prev = null ;
        now = parent.firstchild;
        while (now != null ) {
            if (now.title == title)
                return now;
            else
                now = now.nextsibling;
        }
    }
}
function GetLastChild(parent) {
    var now = parent.firstchild;
    if (now == null )
        return null ;
    while (now.nextsibling != null )
        now = now.nextsibling;
    return now;
}
function GetNthChild(parent, n) {
    if (n < 0)
        return null ;
    var i = 0;
    var now = parent.firstchild;
    while (now != null ) {
        if (i++ == n)
            return now;
        now = now.nextsibling;
    }
    return null ;
}
function MoveToHead(parent, child) {
    var firstchild, prev, next;
    firstchild = parent.firstchild;
    if (firstchild == child)
        return;
    prev = child.prevsibling;
    next = child.nextsibling;
    if (prev != null )
        prev.nextsibling = next;
    if (next != null )
        next.prevsibling = prev;
    if (child == parent.lastchild)
        parent.lastchild = prev;
    parent.firstchild = child;
    child.nextsibling = firstchild;
    child.prevsibling = null ;
    firstchild.prevsibling = child;
}
function MoveToTail(parent, child) {
    var prev, next, lastchild;
    lastchild = GetLastChild(parent);
    if (lastchild == child)
        return;
    prev = child.prevsibling;
    next = child.nextsibling;
    if (prev != null )
        prev.nextsibling = next;
    if (next != null )
        next.prevsibling = prev;
    if (child == parent.firstchild)
        parent.firstchild = next;
    lastchild.nextsibling = child;
    child.nextsibling = null ;
    child.prevsibling = lastchild;
}
function ReorderChildren(node, ArrHead, ArrTail) {
    var now, child, i, c;
    now = node.firstchild;
    if (ArrHead != null ) {
        c = ArrHead.length - 1;
        for (i = c; i >= 0; i--) {
            child = GetChildByTitle(node, ArrHead[i]);
            if (child != null ) {
                MoveToHead(node, child);
            }
        }
    }
    if (ArrTail != null ) {
        c = ArrTail.length;
        for (i = 0; i < c; i++) {
            child = GetChildByTitle(node, ArrTail[i]);
            if (child != null ) {
                MoveToTail(node, child);
            }
        }
    }
}
function GetChildrenCount(node) {
    var i = 0;
    node = node.firstchild;
    while (node != null ) {
        i++;
        node = node.nextsibling;
    }
    return i;
}
function createTreeBase(RootTitle, RefName, DOMElement) {
    return BuildUserTreeView(RefName, RootTitle, DOMElement);
}
function appendChild(parent, title, href, type, target, parameter) {
    var node = new TreeNode(parent,title,type,href,target,parameter);
    return node;
}
function appendView(node, viewname, HrefPrefix, target, type, LevelSep, parameter, viewInfo) {
    node.MenuType[node.MenuType.length] = (type == null ) ? "" : type;
    node.MenuTarget[node.MenuTarget.length] = (target == null ) ? "" : target;
    node.ViewName[node.ViewName.length] = viewname;
    node.HrefPrefix[node.HrefPrefix.length] = HrefPrefix;
    node.LevelSep[node.LevelSep.length] = (LevelSep == null ) ? "/" : LevelSep;
    node.parameterlist[node.parameterlist.length] = parameter;
    node.ViewInfo[node.ViewInfo.length] = viewInfo;
    node.HasNotFetchChildrenNode = 1;
    node.CreatedByAppendView = 2;
    if (node.id == "0")
        UserTreeViewFetchChildrenNode(node);
}
function appendUnit(node, title, HrefPrefix, type, extendtype, target, startunit, parameter, limitUser) {
    target = (target == null ) ? "" : target;
    type = (type == null ) ? "" : type;
    extendtype = (extendtype == null ) ? "" : extendtype;
    limitUser = (limitUser == null ) ? true : false;
    if (limitUser && startunit == null ) {
        if (!userAccess)
            var userAccess = getPeopleAccess();
        startunit = userAccess.baseUnit;
    } else {
        startunit = (startunit == null ) ? "-1" : startunit;
    }
    startunit = (startunit == null ) ? "-1" : startunit;
    var newnode = appendChild(node, title, HrefPrefix + "&Info=" + encodeURI(startunit), type, target, parameter);
    newnode.MenuType[0] = extendtype;
    newnode.MenuTarget[0] = target;
    newnode.ViewName[0] = startunit;
    newnode.HrefPrefix[0] = HrefPrefix;
    newnode.parameterlist[0] = parameter;
    newnode.HasNotFetchChildrenNode = 1;
    newnode.CreatedByAppendView = 3;
    if (newnode.id == "0")
        UserTreeViewFetchChildrenNode(newnode);
    return newnode;
}
function getPeopleAccess() {
    var userAccess = [];
    var t_CurUserAD = GetCookie("LKS_UA_CurUserAD");
    var t_CurUserAllDep = GetCookie("LKS_UA_CurUserAllDep");
    if (t_CurUserAD != null  && t_CurUserAllDep != null ) {
        userAccess.CurUserAD = t_CurUserAD;
        userAccess.DepDisLevel = parseInt(GetCookie("LKS_UA_DepDisLevel"));
        userAccess.DepExpandLevel = parseInt(GetCookie("LKS_UA_DepExpandLevel"));
        userAccess.AllExpandLevel = parseInt(GetCookie("LKS_UA_AllExpandLevel"));
        userAccess.MyExpandLevel = parseInt(GetCookie("LKS_UA_MyExpandLevel"));
        userAccess.PostDisLevel = parseInt(GetCookie("LKS_UA_PostDisLevel"));
        var t_CurUserFullDep = GetCookie("LKS_UA_CurUserFullDep");
        userAccess.CurUserFullDep = t_CurUserFullDep;
        if (t_CurUserFullDep != null )
            userAccess.CurUserFullDep = t_CurUserFullDep.split("/");
        userAccess.CurUserAllDep = t_CurUserAllDep;
        if (t_CurUserAllDep != null )
            userAccess.CurUserAllDep = t_CurUserAllDep.split("/");
        userAccess.SysAdminFlag = GetCookie("LKS_UA_SysAdminFlag");
    } else {
        var AddressXML = new ActiveXObject("MSXML.DOMDocument");
        AddressXML.async = false;
        if (typeof (S_SetupPath) != "undefined")
            AddressXML.load(S_SetupPath + "/sys/lks_sysconfig.nsf/AG_AddressGetInfo?openagent");
        else
            AddressXML.load("../lks_sysconfig.nsf/AG_AddressGetInfo?openagent");
        var nodes = AddressXML.selectNodes("/viewentries/viewentry");
        userAccess.CurUserAD = GetChildNodeText(nodes[0], "CurUserAD");
        var DepDisLevel = GetChildNodeText(nodes[0], "DepDisLevel");
        userAccess.DepDisLevel = (DepDisLevel == "") ? -1 : parseInt(DepDisLevel);
        var DepExpandLevel = GetChildNodeText(nodes[0], "DepExpandLevel");
        userAccess.DepExpandLevel = (DepExpandLevel == "") ? 1 : parseInt(DepExpandLevel);
        var AllExpandLevel = GetChildNodeText(nodes[0], "AllExpandLevel");
        userAccess.AllExpandLevel = (AllExpandLevel == "") ? 1 : parseInt(AllExpandLevel);
        var MyExpandLevel = GetChildNodeText(nodes[0], "MyExpandLevel");
        userAccess.MyExpandLevel = (MyExpandLevel == "") ? 1 : parseInt(MyExpandLevel);
        var PostDisLevel = GetChildNodeText(nodes[0], "PostDisLevel");
        userAccess.PostDisLevel = (PostDisLevel == "") ? 3 : parseInt(PostDisLevel);
        userAccess.CurUserFullDep = GetChildNodeText(nodes[0], "CurUserFullDep").split("/");
        userAccess.CurUserAllDep = GetChildNodeText(nodes[0], "CurUserAllDep").split("/");
        userAccess.SysAdminFlag = GetChildNodeText(nodes[0], "SysAdminFlag");
        var d = new Date();
        d.setDate(d.getDate() + 1);
        document.cookie = "LKS_UA_CurUserAD=" + userAccess.CurUserAD + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_DepDisLevel=" + userAccess.DepDisLevel + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_DepExpandLevel=" + userAccess.DepExpandLevel + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_AllExpandLevel=" + userAccess.AllExpandLevel + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_MyExpandLevel=" + userAccess.MyExpandLevel + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_PostDisLevel=" + userAccess.PostDisLevel + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_CurUserFullDep=" + encodeURI(GetChildNodeText(nodes[0], "CurUserFullDep")) + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_CurUserAllDep=" + encodeURI(GetChildNodeText(nodes[0], "CurUserAllDep")) + "; path=/; expires=" + d.toUTCString();
        document.cookie = "LKS_UA_SysAdminFlag=" + userAccess.SysAdminFlag + "; path=/; expires=" + d.toUTCString();
    }
    processPersonAccess(userAccess.CurUserAD, userAccess.CurUserAllDep);
    return userAccess;
    function processPersonAccess(userDN, userDep) {
        var ret = loadPersonAccess(userDN, userDep);
        if (ret["baseUnit"] == null )
            userAccess.baseUnit = "-1";
        else
            userAccess.baseUnit = ret["baseUnit"];
        if (ret["searchPost"] == null )
            userAccess.searchPost = true;
        else {
            if (ret["searchPost"] == "false" || ret["searchPost"] == "0")
                userAccess.searchPost = false;
            else
                userAccess.searchPost = true;
        }
        if (ret["searchUnit"] == null )
            userAccess.searchUnit = true;
        else {
            if (ret["searchUnit"] == "false" || ret["searchUnit"] == "0")
                userAccess.searchUnit = false;
            else
                userAccess.searchUnit = true;
        }
        if (ret["searchPeople"] == null )
            userAccess.searchPeople = true;
        else {
            if (ret["searchPeople"] == "false" || ret["searchPeople"] == "0")
                userAccess.searchPeople = false;
            else
                userAccess.searchPeople = true;
        }
        if (ret["mailForbidUnit"] == null )
            userAccess.mailForbidUnit = new Array();
        else
            userAccess.mailForbidUnit = ret["mailForbidUnit"].split(";");
    }
    function loadPersonAccess(userDN, userDep) {
        var retV = new Array();
        var xml = new ActiveXObject("MSXML.DOMDocument");
        xml.async = false;
        if (typeof (S_SetupPath) != "undefined")
            xml.load(S_SetupPath + "/sys/html/addressaccess.xml");
        else
            xml.load("../html/addressaccess.xml");
        if (xml.parseError.errorCode != 0) {
            return retV;
        } else {
            if (userDep != null ) {
                userDep[userDep.length] = userDN;
            } else {
                userDep = new Array();
                userDep[0] = userDN;
            }
            var nodes = xml.selectNodes("/accessentries/accessentry");
            var theNodes = null ;
            var theIndex = -1;
            if (nodes == null )
                return null ;
            for (var i = 0; i < nodes.length; i++) {
                tmpArray = nodes[i].getAttribute("name").toLowerCase().split(";");
                for (var j = 0; j < tmpArray.length; j++) {
                    if (tmpArray[j] == "default" && theIndex == -1) {
                        theNodes = nodes[i];
                    } else {
                        for (var k = 0; k < userDep.length; k++) {
                            if (tmpArray[j] == userDep[k].toLowerCase()) {
                                if (theIndex < k) {
                                    theNodes = nodes[i];
                                    theIndex = k;
                                }
                            }
                        }
                    }
                }
            }
            if (theNodes != null ) {
                var subnodes = theNodes.selectNodes("entrydata");
                if (subnodes == null  || subnodes.length <= 0)
                    ;for (var i = 0; i < subnodes.length; i++) {
                    tmpStr = subnodes[i].getAttribute("name");
                    if (tmpStr != null ) {
                        retV[tmpStr] = XMLGetNodeTextList(subnodes[i], true, ";");
                    }
                }
            }
        }
        return retV;
    }
}
function XMLGetNodeTextList(node, indexed, sep) {
    var i;
    var Result;
    var subnodes = node.selectNodes("textlist");
    if (subnodes != null  && subnodes.length > 0) {
        subnodes = subnodes[0].selectNodes("text");
        if (subnodes != null  && subnodes.length > 0) {
            Result = subnodes[0].text;
            if (subnodes.length > 1) {
                if (indexed != true)
                    return Result + "...";
                Result = Result;
                for (i = 1; i < subnodes.length; i++)
                    Result += sep + subnodes[i].text;
            }
            return Result;
        }
    }
    return node.text;
}
