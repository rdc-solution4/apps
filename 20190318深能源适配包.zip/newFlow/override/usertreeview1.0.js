if (window.S_JsFileList != null ) {
    RegisterJsFile("usertreeview1.0.js");
    IncludeJsFile("rightmenu.js");
}
var preloadArray = new Array;
var ImgPathPrefix = "";
var nodeViewStyle = new Object;
var CurrentUserTree;
var _top = "_ysp_top";
function PreloadImage(srclink) {
    var i = preloadArray.length;
    preloadArray[i] = new Image;
    preloadArray[i].src = srclink;
}
function HideTreeNodeChildren(node) {
    var now;
    var element;
    now = node.firstchild;
    while (now != null ) {
        element = eval("document.all.TVN_" + now.id);
        if (element != null )
            element.outerHTML = "";
        if (now.IsExpanded)
            HideTreeNodeChildren(now);
        now = now.nextsibling;
    }
}
function UserTreeView() {
    this.RefName = "";
    this.TreeRoot = null ;
    this.ShowCheckBox = false;
    this.IsMultSel = true;
    this.LastCheckedNode = null ;
    this.CurrentNodeCSS = "style=\"background-color: #FFFFCC; border: 1px solid;\"";
    this.CurrentNodeID = -1;
    this.DOMElement = null ;
    this.Target = "";
    this.NavigateEnabled = true;
    this.ClickCaptionExpand = false;
    this.NavigateWhenExpand = false;
    this.ImgVertLine = ImgPathPrefix + "vertline1.3.gif";
    this.ImgNode = ImgPathPrefix + "node1.3.gif";
    this.ImgNodePlus = ImgPathPrefix + "nodeplus1.4.gif";
    this.ImgNodeMinus = ImgPathPrefix + "nodeminus1.4.gif";
    this.ImgLastNode = ImgPathPrefix + "lastnode1.3.gif";
    this.ImgLastNodePlus = ImgPathPrefix + "lastnodeplus1.4.gif";
    this.ImgLastNodeMinus = ImgPathPrefix + "lastnodeminus1.4.gif";
    this.ImgOpenedFolder = ImgPathPrefix + "openfolder.gif";
    this.ImgClosedFolder = ImgPathPrefix + "closedfolder.gif";
    this.ImgUnit = ImgPathPrefix + "unit.gif";
    this.ImgPerson = ImgPathPrefix + "person.gif";
    this.ImgBlank = ImgPathPrefix + "blank1.3.png";
    this.ImgLeaf = ImgPathPrefix + "link.gif";
    PreloadImage(this.ImgVertLine);
    PreloadImage(this.ImgNode);
    PreloadImage(this.ImgNodePlus);
    PreloadImage(this.ImgNodeMinus);
    PreloadImage(this.ImgLastNode);
    PreloadImage(this.ImgLastNodePlus);
    PreloadImage(this.ImgLastNodeMinus);
    PreloadImage(this.ImgOpenedFolder);
    PreloadImage(this.ImgClosedFolder);
    PreloadImage(this.ImgBlank);
    PreloadImage(this.ImgLeaf);
    this.DrawNodeIndentHTML = UserTreeViewDrawNodeIndentHTML;
    this.DrawNodeOuterHTML = UserTreeViewDrawNodeOuterHTML;
    this.DrawNodeInnerHTML = UserTreeViewDrawNodeInnerHTML;
    this.DrawNode = UserTreeViewDrawNode;
    this.RefreshNode = UserTreeViewRefreshNode;
    this.SetCurrentNode = UserTreeViewSetCurrentNode;
    this.FetchChildrenNode = UserTreeViewFetchChildrenNode;
    this.OpenHref = UserTreeViewOpenHref;
    this.SetTreeRoot = UserTreeViewSetTreeRoot;
    this.EnableRightMenu = UserTreeEnableRightMenu;
    this.ExpandNode = UserTreeViewExpandNode;
    this.CheckNode = UserTreeViewCheckNode;
    this.Check = UserTreeViewCheck;
    this.GetAllChecked = UserTreeViewGetAllChecked;
    this.OpenFolder = UserTreeViewOpenFolder;
    this.OnNodeQueryDraw = null ;
    this.OnNodePostDraw = null ;
    this.OnChildrenNodeQueryFetch = null ;
    this.OnChildrenNodePostFetch = null ;
    this.OnNodeQueryExpand = null ;
    this.OnNodePostExpand = null ;
    this.OnFolderQueryOpen = null ;
    this.OnFolderPostOpen = null ;
    this.Draw = UserTreeViewDraw;
    this.Show = UserTreeViewShow;
    this.Search = UserTreeViewSearch;
    this.GetNextSearchNode = UserTreeViewGetNextSearchNode;
    this.AddToMap = UserTreeViewAddToMap;
    this.AddURLToNav = UserTreeViewAddURLToNav;
}
function ReloadUserTreeViewStyle(node, obj) {
    nodeViewStyle.ImgVertLine = obj.ImgVertLine;
    nodeViewStyle.ImgNode = obj.ImgNode;
    nodeViewStyle.ImgNodePlus = obj.ImgNodePlus;
    nodeViewStyle.ImgNodeMinus = obj.ImgNodeMinus;
    nodeViewStyle.ImgLastNode = obj.ImgLastNode;
    nodeViewStyle.ImgLastNodePlus = obj.ImgLastNodePlus;
    nodeViewStyle.ImgLastNodeMinus = obj.ImgLastNodeMinus;
    nodeViewStyle.ImgBlank = obj.ImgBlank;
    nodeViewStyle.CurrentNodeCSS = obj.CurrentNodeCSS;
    switch (node.type) {
    case "Unit":
        nodeViewStyle.ImgOpenedFolder = obj.ImgUnit;
        nodeViewStyle.ImgClosedFolder = obj.ImgUnit;
        nodeViewStyle.ImgLeaf = obj.ImgUnit;
        break;
    case "Person":
        nodeViewStyle.ImgOpenedFolder = obj.ImgPerson;
        nodeViewStyle.ImgClosedFolder = obj.ImgPerson;
        nodeViewStyle.ImgLeaf = obj.ImgPerson;
        break;
    default:
        nodeViewStyle.ImgOpenedFolder = obj.ImgOpenedFolder;
        nodeViewStyle.ImgClosedFolder = obj.ImgClosedFolder;
        nodeViewStyle.ImgLeaf = obj.ImgLeaf;
    }
    if (obj.ShowCheckBox) {
        if (obj.IsMultSel)
            nodeViewStyle.CheckboxType = "checkbox";
        else
            nodeViewStyle.CheckboxType = "radio";
    } else
        nodeViewStyle.CheckboxType = "";
}
function UserTreeViewSetTreeRoot(path) {
    var node = GetNodeByPath(this.TreeRoot, path);
    if (node != null ) {
        this.TreeRoot = node;
        node.parent = null ;
        node.prevsibling = null ;
    }
}
function UserTreeViewExpandNode(id) {
    var node;
    node = GetNodeByID(this.TreeRoot, id);
    if (this.OnNodeQueryExpand != null )
        if (!this.OnNodeQueryExpand(node))
            return;
    if (node == null )
        return;
    if (node.href != "" && this.NavigateWhenExpand && this.NavigateEnabled)
        this.OpenHref(node, node.target);
    var now, indent_level;
    node.IsExpanded = !node.IsExpanded;
    indent_level = 0;
    now = node;
    while (now.parent != null ) {
        indent_level++;
        now = now.parent;
    }
    var element = eval("document.all.TVN_" + node.id);
    if (node.IsExpanded) {
        if (element != null )
            element.outerHTML = this.DrawNode(node, indent_level, true);
    } else {
        if (element != null )
            element.outerHTML = this
            .DrawNodeOuterHTML(node, indent_level, true);
        HideTreeNodeChildren(node);
    }
    if (this.OnNodePostExpand != null )
        this.OnNodePostExpand(node);
}
function UserTreeViewGetAllChecked(node) {
    var now;
    var Result = "";
    if (node.IsChecked) {
        if (node.AbbrName == "\\")
            Result += node.Canonical + "\r\n";
        else
            Result += node.AbbrName + "\r\n";
    }
    return Result;
}
function UserTreeViewCheckNode(id) {
    var node;
    node = GetNodeByID(this.TreeRoot, id);
    if (node == null )
        return;
    if (event.type == "mouseover" && !event.ctrlKey)
        return;
    this.Check(node);
}
function UserTreeViewCheck(node) {
    var now, element;
    element = eval("document.all.CHK_" + node.id);
    if (element != null ) {
        if (this.IsMultSel)
            node.IsChecked = element.checked;
        else {
            if (this.LastCheckedNode != null ) {
                this.LastCheckedNode.IsChecked = false;
                this.LastCheckedNode.IsExpandedHTMLDirty = true;
                this.LastCheckedNode.IsCollapsedHTMLDirty = true;
            }
            node.IsChecked = element.checked;
            this.LastCheckedNode = node;
        }
        node.IsExpandedHTMLDirty = true;
        node.IsCollapsedHTMLDirty = true;
    }
}
function UserTreeViewDrawNodeIndentHTML(node, indent_level) {
    var now;
    var result;
    var CannotExpand;
    if (node == null )
        return "";
    CannotExpand = (!node.HasNotFetchChildrenNode && node.firstchild == null );
    if (CannotExpand)
        result = "<img src=" + nodeViewStyle.ImgLeaf + ">";
    else
        result = "<a href=\"javascript:" 
        + this.RefName 
        + ".ExpandNode(" 
        + node.id 
        + ")\">" 
        + (node.IsExpanded 
        ? "<img src=" + nodeViewStyle.ImgOpenedFolder 
        + " border=0>" 
        : "<img src=" + nodeViewStyle.ImgClosedFolder 
        + " border=0>") + "</a>";
    if (indent_level <= 0) {
        return result;
    }
    if (node.nextsibling == null ) {
        if (CannotExpand)
            result = "<img src=" + nodeViewStyle.ImgLastNode + ">" + result;
        else
            result = "<a href=\"javascript:" 
            + this.RefName 
            + ".ExpandNode(" 
            + node.id 
            + ")\">" 
            + (node.IsExpanded 
            ? "<img src=" + nodeViewStyle.ImgLastNodeMinus 
            + " border=0>" 
            : "<img src=" + nodeViewStyle.ImgLastNodePlus 
            + " border=0>") + "</a>" + result;
    } else {
        if (CannotExpand)
            result = "<img src=" + nodeViewStyle.ImgNode + ">" + result;
        else
            result = "<a href=\"javascript:" 
            + this.RefName 
            + ".ExpandNode(" 
            + node.id 
            + ")\">" 
            + (node.IsExpanded 
            ? "<img src=" + nodeViewStyle.ImgNodeMinus 
            + " border=0>" 
            : "<img src=" + nodeViewStyle.ImgNodePlus 
            + " border=0>") + "</a>" + result;
    }
    now = node.parent;
    for (i = indent_level - 1; i > 0; i--) {
        if (now == null ) {
            return result;
        } else {
            if (now.nextsibling == null ) {
                result = "<img src=" + nodeViewStyle.ImgBlank + ">" + result;
            } else {
                result = "<img src=" + nodeViewStyle.ImgVertLine + ">" + result;
            }
            now = now.parent;
        }
    }
    return result;
}
function UserTreeViewDrawNodeInnerHTML(node, indent_level) {
    var QueryStr;
    ReloadUserTreeViewStyle(node, this);
    if (this.OnNodeQueryDraw != null ) {
        QueryStr = this.OnNodeQueryDraw(node, nodeViewStyle)
        if (QueryStr != null )
            return QueryStr;
    }
    var Result, ChkStr, Checked, Target;
    Result = "<tr><td valign=middle nowrap>";
    Result = Result + this.DrawNodeIndentHTML(node, indent_level);
    Result = Result 
    + "</td><td valign=middle nowrap " 
    + (this.CurrentNodeID == node.id 
    ? nodeViewStyle.CurrentNodeCSS 
    : "") + ">";
    if (node.IsChecked == null )
        node.IsChecked = false;
    if (nodeViewStyle.CheckboxType != "") {
        ChkStr = "<input onClick='" + this.RefName + ".CheckNode(" + node.id 
        + ")' type=" + nodeViewStyle.CheckboxType + " id='CHK_" 
        + node.id + "' " + (node.IsChecked ? "Checked" : "") + ">";
    } else
        ChkStr = "";
    if (node.href != "" && this.ClickCaptionExpand == false 
    && this.NavigateEnabled) {
        Target = node.target == "" ? this.Target : node.target;
        Result = Result + "<a lks_nodeid=" + node.id + " title=\"" 
        + m_HtmlEscape(node.title) + "\" href=\"javascript:" 
        + this.RefName + ".OpenFolder(" + node.id + ",'" + Target 
        + "')\">" + ChkStr + (node.text ? node.text : node.title) 
        + "</a>";
    } else {
        Result = Result + "<a lks_nodeid=" + node.id + " title=\"" 
        + m_HtmlEscape(node.title) + "\" href=\"javascript:" 
        + this.RefName + ".ExpandNode(" + node.id + ")\">" + ChkStr 
        + (node.text ? node.text : node.title) + "</a>";
    }
    Result += "</td></tr>";
    if (this.OnNodePostDraw != null ) {
        QueryStr = this.OnNodePostDraw(node, Result);
        if (QueryStr != null )
            return QueryStr;
    }
    return Result;
}
function UserTreeViewDrawNodeOuterHTML(node, indent_level, Visible) {
    if (!Visible)
        return "";
    if (node.IsExpanded) {
        if ((node.IsExpandedHTMLDirty == null ) || node.IsExpandedHTMLDirty 
        || node.OuterHTMLExpanded == null ) {
            node.OuterHTMLExpanded = "<table id='TVN_" + node.id 
            + "' cellpadding=0 cellspacing=0 border=0>" 
            + this.DrawNodeInnerHTML(node, indent_level) + "</table>";
        }
        node.IsExpandedHTMLDirty = false;
        return node.OuterHTMLExpanded;
    } else {
        if ((node.IsCollapsedHTMLDirty == null ) || node.IsCollapsedHTMLDirty 
        || node.OuterHTMLCollapsed == null ) {
            node.OuterHTMLCollapsed = "<table id='TVN_" + node.id 
            + "' cellpadding=0 cellspacing=0 border=0>" 
            + this.DrawNodeInnerHTML(node, indent_level) + "</table>";
        }
        node.IsCollapsedHTMLDirty = false;
        return node.OuterHTMLCollapsed;
    }
}
function UserTreeViewDrawNode(node, indent_level, Visible) {
    if (node.IsExpanded && node.HasNotFetchChildrenNode)
        this.FetchChildrenNode(node);
    var now;
    var i;
    var Result;
    Result = this.DrawNodeOuterHTML(node, indent_level, Visible);
    Visible = Visible && node.IsExpanded;
    indent_level++;
    if (node.IsExpanded) {
        now = node.firstchild;
        while (now != null ) {
            Result = Result + this.DrawNode(now, indent_level, Visible);
            now = now.nextsibling;
        }
    }
    return Result;
}
function UserTreeViewDraw() {
    return this.DrawNode(this.TreeRoot, 0, true);
}
function UserTreeViewShow() {
    var Result = this.DrawNode(this.TreeRoot, 0, true);
    this.DOMElement.innerHTML = Result;
}
function UserTreeViewFetchChildrenNode(node) {
    if (this.OnChildrenNodeQueryFetch != null )
        if (!this.OnChildrenNodeQueryFetch(node))
            return;
    switch (node.CreatedByAppendView) {
    case 1:
    case 2:
        for (var i = 0; i < node.ViewName.length; i++) {
            var order = node.ViewName[i].split(/:(?!.*\/)/);
            var viewname;
            if (order.length > 1) {
                viewname = order[0];
                order[0] = parseInt(order[1]);
                order[1] = order[0] < 0 ? -1 : 1;
                order[0] = order[0] * order[1];
            } else {
                order[0] = 1;
                order[1] = 1;
                viewname = node.ViewName[i];
            }
            if (order[2] == null )
                order[2] = 1;
            else
                order[2] = parseInt(order[2]);
            var xml = new ActiveXObject("MSXML.DOMDocument");
            xml.async = false;
            var nodes = new Array;
            var nodesLen = new Array;
            var nodesNum = 0;
            var startIndex = 1;
            var tmpI;
            var url = viewname.indexOf("?") > 0 
            ? viewname 
            : (viewname + "?readviewentries");
            if (node.ViewInfo[i] != null ) {
                url += "&expand=" + node.ViewInfo[i].position 
                + "&count=1000&start=" + node.ViewInfo[i].position 
                + ".";
            } else {
                url += "&collapseview&count=1000&start=";
            }
            for (; true; ) {
                xml.load(url + startIndex);
                nodes[nodesNum] = xml.selectNodes("/viewentries/viewentry");
                if (node.ViewInfo[i] != null ) {
                    tmpI = node.ViewInfo[i].position.length + 1;
                    for (var j = nodes[nodesNum].length - 1; j > -1; j--) {
                        startIndex = nodes[nodesNum][j].attributes
                        .getNamedItem("position").text;
                        if (startIndex.substring(0, tmpI) == node.ViewInfo[i].position 
                        + ".")
                            break;
                    }
                    nodesLen[nodesNum] = j + 1;
                } else {
                    nodesLen[nodesNum] = nodes[nodesNum].length;
                }
                if (nodesLen[nodesNum] == 1000) {
                    startIndex = nodes[nodesNum][999].attributes
                    .getNamedItem("position").text;
                    tmpI = startIndex.lastIndexOf(".");
                    if (tmpI > -1)
                        startIndex = startIndex.substring(i);
                    startIndex = parseInt(startIndex) + 1;
                } else
                    break;
                nodesNum++;
            }
            for (startIndex = order[0] * order[1] == -1 ? nodesNum : 0; startIndex >= 0 
            && startIndex <= nodesNum; startIndex += order[1]) {
                if (nodesLen[startIndex] > 0) {
                    var tmpText, tmpInfo, tmpOrder;
                    var column;
                    var j = order[0] * order[1] == -1 ? nodesLen[nodesNum] 
                    - 1 : 0;
                    for (; j >= 0 && j < nodesLen[startIndex]; j += order[1]) {
                        column = nodes[startIndex][j].firstChild.attributes
                        .getNamedItem("columnnumber").text;
                        if (column == "0") {
                            tmpText = nodes[startIndex][j].firstChild.text;
                            tmpInfo = tmpText;
                            tmpOrder = null ;
                            if (order[0] != 1) {
                                tmpI = tmpText.indexOf(":");
                                tmpOrder = tmpI > -1 ? tmpText.substring(0, 
                                tmpI) : null ;
                                tmpText = tmpI > -1 ? tmpText
                                .substring(tmpI + 1) : tmpText;
                                tmpInfo = order[2] == 0 ? tmpText : tmpInfo;
                            }
                            if (node.LevelSep[i] == "\\") {
                                if (tmpText != "-1" && tmpText != "-1/") {
                                    if (tmpText.charAt(tmpText.length - 1) == "/") {
                                        tmpI = 1;
                                        tmpText = tmpText.substring(0, 
                                        tmpText.length - 1);
                                    } else {
                                        tmpI = 0;
                                    }
                                    var subNode = GetChildByTitle(node, 
                                    tmpText);
                                    if (subNode == null ) {
                                        subNode = new TreeNode(node,
                                        tmpText,"","");
                                    }
                                    if (tmpI == 1) {
                                        subNode.type = node.MenuType[i];
                                        subNode.target = node.MenuTarget[i];
                                        subNode.parameter = node.parameterlist[i];
                                        subNode.info = (node.ViewInfo[i] == null ) 
                                        ? tmpInfo.substring(0, 
                                        tmpInfo.length - 1) 
                                        : node.ViewInfo[i].info 
                                        + "/" 
                                        + tmpInfo
                                        .substring(
                                        0, 
                                        tmpInfo.length 
                                        - 1);
                                        subNode.order = tmpOrder;
                                        subNode.href = node.HrefPrefix[i];
                                    } else {
                                        var infoObj = new Object();
                                        infoObj.info = (node.ViewInfo[i] == null ) 
                                        ? tmpInfo 
                                        : node.ViewInfo[i].info 
                                        + "/" + tmpInfo;
                                        infoObj.position = nodes[startIndex][j].attributes
                                        .getNamedItem("position").text;
                                        infoObj.children = parseInt(nodes[startIndex][j].attributes
                                        .getNamedItem("children").text);
                                        appendView(subNode, 
                                        node.ViewName[i], 
                                        node.HrefPrefix[i], 
                                        node.MenuTarget[i], 
                                        node.MenuType[i], "\\", 
                                        node.parameterlist[i], 
                                        infoObj);
                                        subNode.CreatedByAppendView = 1;
                                    }
                                }
                            } else {
                                if (tmpText != "-1")
                                    CreatePath(node, node.LevelSep[i] 
                                    + tmpText, 
                                    node.MenuType[i], 
                                    node.HrefPrefix[i], 
                                    node.MenuTarget[i], 
                                    node.LevelSep[i], 
                                    node.parameterlist[i], tmpInfo, 
                                    tmpOrder);
                            }
                        }
                    }
                }
            }
            if (order[0] != 1)
                UserTreeViewSortChildrenNode(node, order[0] * order[1]);
        }
        node.HasNotFetchChildrenNode = 0;
        node.IsExpandedHTMLDirty = true;
        node.IsCollapsedHTMLDirty = true;
        break;
    case 3:
        var xml = new ActiveXObject("MSXML.DOMDocument");
        if (xml != null ) {
            xml.async = false;
            xml
            .load(getNotesIniValue("GetDepInfoDb") 
            + "LKS_XMLUnitGroup?ReadViewEntries&count=9999&PreFormat&RestrictToCategory=" 
            + encodeURI(node.ViewName[0]));
            var nodes = xml.selectNodes("/viewentries/viewentry");
            if (nodes.length > 0) {
                for (var i = 0; i < nodes.length; i++) {
                    appendUnit(node, GetChildNodeText(nodes[i], "disname"), 
                    node.HrefPrefix[0], "Unit", node.MenuType[0], 
                    node.MenuTarget[0], GetChildNodeText(nodes[i], 
                    "extendname"), node.parameterlist[0]);
                }
            }
            if (node.MenuType[0].indexOf("M") > -1) {
                xml
                .load(getNotesIniValue("GetPeopleInfoDb") 
                + "LKS_XMLPerson?ReadViewEntries&count=9999&PreFormat&RestrictToCategory=" 
                + encodeURI(node.ViewName[0]));
                var nodes = xml.selectNodes("/viewentries/viewentry");
                if (nodes.length > 0) {
                    for (var i = 0; i < nodes.length; i++) {
                        appendChild(node, 
                        GetChildNodeText(nodes[i], "name"), 
                        node.HrefPrefix[0] 
                        + "&Info=" 
                        + encodeURI(GetChildNodeText(
                        nodes[i], "ad")), "Person", 
                        node.MenuTarget[0], node.parameterlist[0]);
                    }
                }
            }
            node.HasNotFetchChildrenNode = 0;
            node.IsExpandedHTMLDirty = true;
            node.IsCollapsedHTMLDirty = true;
        }
    }
    if (this.OnChildrenNodePostFetch != null )
        this.OnChildrenNodePostFetch(node);
}
function GetChildNodeText(XmlNode, ChildNodeName) {
    var Node = null , AttrNode;
    Node = XmlNode.firstChild;
    while (Node != null ) {
        AttrNode = Node.getAttributeNode("name");
        if (AttrNode != null  && AttrNode.nodeValue == ChildNodeName)
            return Node.text;
        Node = Node.nextSibling;
    }
    return "";
}
function BuildUserTreeView(RefName, RootTitle, DOMElement) {
    var root = new TreeNode(null ,RootTitle,"Group","");
    var tree = new UserTreeView();
    tree.RefName = RefName;
    tree.DOMElement = DOMElement;
    tree.TreeRoot = root;
    CurrentUserTree = tree;
    return tree;
}
function UserTreeViewOpenFolder(id, target) {
  target = _top;
    if (!target)
        target = this.Target;
    node = GetNodeByID(this.TreeRoot, id);
    if (this.OnFolderQueryOpen != null )
        if (!this.OnFolderQueryOpen(node, target)) {
            this.SetCurrentNode(node);
            return;
        }
    this.OpenHref(node, target);
    this.SetCurrentNode(node);
    if (this.OnFolderPostOpen != null )
        this.OnFolderPostOpen(node, target);
}
function UserTreeViewSetCurrentNode(node, isScroll) {
    if (this.CurrentNodeID == node.id)
        return;
    var now, indent_level, CurNode;
    if (this.CurrentNodeID == -1) {
        this.CurrentNodeID = node.id;
    } else {
        CurNode = GetNodeByID(this.TreeRoot, this.CurrentNodeID);
        if (CurNode == null ) {
            this.CurrentNodeID = node.id;
        } else {
            this.CurrentNodeID = node.id;
            this.RefreshNode(CurNode);
        }
    }
    now = GetNodeByID(this.TreeRoot, this.CurrentNodeID);
    for (indent_level = 0; now.parent != null ; now = now.parent) {
        if (!now.parent.IsExpanded)
            this.ExpandNode(now.parent.id);
    }
    this.RefreshNode(node);
    if (isScroll)
        setTimeout(
        "try{document.all.TVN_" 
        + this.CurrentNodeID 
        + ".scrollIntoView();setSearchBarposition('document.all.TVN_" 
        + this.CurrentNodeID + "');}catch(e){}", 10);
}
function setSearchBarposition(objName) {
    var obj = eval(objName);
    if (obj) {
        if (document.all.treeDiv.offsetTop < 55 
        && (obj.offsetTop - document.body.scrollTop) < 35)
            DIV_SearchBar.style.top = document.body.scrollTop + 55;
        else
            DIV_SearchBar.style.top = document.body.scrollTop + 5;
    }
}
function UserTreeViewRefreshNode(node) {
    var element = document.all["TVN_" + node.id];
    node.IsExpandedHTMLDirty = true;
    node.IsCollapsedHTMLDirty = true;
    var indent_level = 0;
    for (var now = node; now.parent != null ; now = now.parent)
        indent_level++;
    if (element != null )
        element.outerHTML = this.DrawNodeOuterHTML(node, indent_level, true);
}
function UserTreeViewOpenHref(node, target) {
  target = _top;
    var strhref = node.href;
    var i = node.href.indexOf("javascript:");
    if (i == 0) {
        eval(node.href.substring(11));
        return;
    }
    i = node.href.indexOf("?");
    if (i > -1 && target.toLowerCase() == "viewframe") {
        if (window.S_CurrentStyle)
            strhref += "&css=" + S_CurrentStyle;
        if (node.info)
            strhref += "&Info=" + encodeURI(node.info);
        var strpath = GetNodePath(node, ">>").substring(2);
        strhref += "&Path=" + encodeURI(strpath);
    }
    window.open(strhref, target);
}
function UserTreeViewSortChildrenNode(node, order) {
    if (order == null  || order == 1)
        return;
    if (node.firstchild == null )
        return;
    var sortArr = new Array;
    var nodeArr = new Array;
    var tmpOrder;
    for (var now = node.firstchild; now != null ; now = now.nextsibling) {
        UserTreeViewSortChildrenNode(now, order);
        tmpOrder = -1;
        for (var i = 0; i < sortArr.length; i++) {
            tmpOrder = UserTreeViewSortFunction(now.order, sortArr[i], order);
            if (tmpOrder != -1)
                break;
        }
        switch (tmpOrder) {
        case 1:
            for (var j = nodeArr.length; j > i; j--) {
                nodeArr[j] = nodeArr[j - 1];
                sortArr[j] = sortArr[j - 1];
            }
            nodeArr[i] = now;
            sortArr[i] = now.order;
            break;
        case -1:
            nodeArr[nodeArr.length] = now;
            sortArr[sortArr.length] = now.order;
            break;
        }
    }
    for (var i = nodeArr.length - 1; i >= 0; i--)
        MoveToHead(node, nodeArr[i]);
}
function UserTreeViewSortFunction(str1, str2, sortType) {
    if (str1 == null  || str1 == "")
        return 0;
    if (str2 == null  || str2 == "")
        return 1;
    switch (Math.abs(sortType)) {
    case 3:
        str1 = parseFloat(str1);
        str2 = parseFloat(str2);
    }
    var rtnVal = (str1 < str2 ? 1 : -1) * (sortType > 0 ? 1 : -1);
    return rtnVal;
}
function UserTreeViewSearch(direct) {
    var casesensitive = document.all.F_TreeSearchCase.checked;
    var text = casesensitive ? F_TreeKeyword.value : F_TreeKeyword.value
    .toLowerCase();
    if (text == "") {
        alert("请输入关键字!");
        F_TreeKeyword.focus();
        return false;
    }
    var node = this.TreeRoot;
    if (document.all.F_TreeSearchType[1].checked && this.CurrentNodeID > -1)
        node = this.GetNextSearchNode(GetNodeByID(node, this.CurrentNodeID), 
        direct);
    for (; node != null ; node = this.GetNextSearchNode(node, direct))
        if ((casesensitive ? node.title : node.title.toLowerCase())
        .indexOf(text) > -1)
            break;
    if (node == null ) {
        alert("关键字“" + text + "”未找到！");
    } else {
        this.SetCurrentNode(node, true);
        document.all.F_TreeSearchType[1].checked = true;
        UserTreeViewChgSearchBarStyle(0);
    }
}
function UserTreeViewGetNextSearchNode(node, direct) {
    var now;
    if (direct == 1) {
        if (node.HasNotFetchChildrenNode)
            this.FetchChildrenNode(node);
        if (node.firstchild != null )
            return node.firstchild;
        if (node.nextsibling != null )
            return node.nextsibling;
        for (now = node.parent; now != null ; now = now.parent)
            if (now.nextsibling != null )
                return now.nextsibling;
    } else {
        if (node.prevsibling != null ) {
            for (now = node.prevsibling; true; now = now.lastchild) {
                if (now.HasNotFetchChildrenNode)
                    this.FetchChildrenNode(now);
                if (now.lastchild == null )
                    return now;
            }
        }
        return node.parent;
    }
    return null ;
}
function UserTreeViewChgSearchBarStyle(status) {
    if (status == 0)
        Btn_TreeMore.value = "─";
    else if (status == 1)
        Btn_TreeMore.value = "□";
    var dis = "";
    if (Btn_TreeMore.value == "□") {
        Btn_TreeMore.value = "─";
        Btn_TreeMore.title = "最小化";
    } else {
        Btn_TreeMore.value = "□";
        Btn_TreeMore.title = "最大化";
        dis = "none";
    }
    for (var i = 1; i < TB_SearchBar.rows.length; i++)
        TB_SearchBar.rows[i].style.display = dis;
}
function UserTreeViewHideSearchBar() {
    DIV_SearchBar.style.display = "none";
}
function UserTreeViewOnWinScroll() {
    DIV_SearchBar.style.top = document.body.scrollTop + 5;
    DIV_SearchBar.style.left = document.body.scrollLeft + 5;
}
function showTreeSearchBar() {
    if (window.DIV_SearchBar) {
        if (DIV_SearchBar.style.display != "") {
            DIV_SearchBar.style.display = "";
            document.all.F_TreeKeyword.focus();
        } else
            DIV_SearchBar.style.display = "none";
        return;
    }
    var newElem = document
    .createElement("<div id=DIV_SearchBar style='position:absolute;z-index:2; top:5px; left:5px; width:100%'></div>");
    var htmlCode = "<table id=TB_SearchBar class=seachbar width=100% cellspacing=1 cellpadding=2><tr><td bgcolor=#FFFFFF>";
    htmlCode += "<table width=100% cellpadding=0 cellspacing=1 border=0><tr valign=bottom>";
    htmlCode += "<td nowrap width=0>关键字</td>";
    htmlCode += "<td colspan=2 width=100%><input id=F_TreeKeyword class=texttree onkeyup=\"if(event.keyCode==13)Btn_TreeNext.click();\"></td>";
    htmlCode += "</tr><tr valign=bottom>";
    htmlCode += "<td>搜　索</td>";
    htmlCode += "<td nowrap align=left><input id=Btn_TreePre class=btntree type=button value=↑ title=查找上一个 onclick=\"" 
    + CurrentUserTree.RefName 
    + ".Search(-1);\">&nbsp;<input id=Btn_TreeNext class=btntree type=button value=↓ title=查找下一个 onclick=\"" 
    + CurrentUserTree.RefName + ".Search(1);\">&nbsp;</td>";
    htmlCode += "<td nowrap align=right><input id=Btn_TreeMore class=btntree type=button value=□ title=最大化 onclick=\"UserTreeViewChgSearchBarStyle();\">&nbsp;<input id=Btn_TreeLock class=btntree type=button value=× onclick=\"UserTreeViewHideSearchBar();\" title=隐藏搜索条></td>";
    htmlCode += "</tr></table>";
    htmlCode += "</td></tr><tr style='display:none'><td bgcolor=#FFFFFF>";
    htmlCode += "<input name=F_TreeSearchCase type=checkbox>区分大小写";
    htmlCode += "</td></tr><tr style='display:none'><td bgcolor=#FFFFFF>";
    htmlCode += "&nbsp;搜索起始节点：<br><input name=F_TreeSearchType type=radio>根节点<br><input name=F_TreeSearchType type=radio checked>当前节点";
    htmlCode += "</td></tr></table>";
    newElem.innerHTML = htmlCode;
    document.body.appendChild(newElem);
    setTimeout("document.all.F_TreeKeyword.focus();", 100);
    window.onscroll = UserTreeViewOnWinScroll;
}
function UserTreeEnableRightMenu() {
    document.oncontextmenu = function() {
        if (event.ctrlKey)
            return true;
        if (event.srcElement.lks_nodeid != null )
            CurrentUserTree.SetCurrentNode(GetNodeByID(
            CurrentUserTree.TreeRoot, 
            parseInt(event.srcElement.lks_nodeid)));
        var rm = new RightMenuObject(150);
        if (window.DIV_SearchBar && DIV_SearchBar.style.display == "")
            rm.AddItem("关闭搜索栏", "showTreeSearchBar");
        else
            rm.AddItem("显示搜索栏", "showTreeSearchBar");
        var roles = document.cookie.match(/\bLKS_WorkplaceRoles=(.*?)(?=;|$)/g);
        var isSelect = (CurrentUserTree != null  && CurrentUserTree.CurrentNodeID != -1);
        if (isSelect) {
            var node = GetNodeByID(CurrentUserTree.TreeRoot, 
            CurrentUserTree.CurrentNodeID);
            if (node.href.substring(0, 11) == "javascript:")
                isSelect = false;
        }
        if (roles != null ) {
            rm.AddItem("整理导航树", CurrentUserTree.RefName + ".AddToMap", "false");
            if (isSelect)
                rm.AddItem("添加节点到导航", CurrentUserTree.RefName + ".AddToMap", 
                "true");
            if (roles[0].indexOf("[CreateNav]") > -1)
                rm.AddItem("添加页面到公共导航", CurrentUserTree.RefName 
                + ".AddURLToNav", "1");
            if (roles[0].indexOf("[CreateMyNav]") > -1)
                rm.AddItem("添加页面到个人导航", CurrentUserTree.RefName 
                + ".AddURLToNav", "0");
        }
        rm.AddItem("刷新页面", "history.go", "0");
        rm.Show();
        return false;
    }
}
function UserTreeViewAddToMap(isAdd) {
    var info = "";
    if (isAdd)
        info = "&nodeid=" + CurrentUserTree.CurrentNodeID;
    var dbPath = (S_DbPath.indexOf("/sys") != -1 ? S_SetupPath + "/koa" : S_DbPath);
    window.open(dbPath + "/lks_workplace.nsf/FM_SelectNav?OpenForm" 
    + info, "_blank", "resizable=yes scrollbars=yes");
}
function UserTreeViewAddURLToNav(navType) {
    var dbPath = (S_DbPath.indexOf("/sys") != -1 ? S_SetupPath + "/koa" : S_DbPath);
    window.open(dbPath + "/lks_workplace.nsf/FM_Navigation?OpenForm&type=" 
    + navType + "&url=" + location.href, "_blank");
}
