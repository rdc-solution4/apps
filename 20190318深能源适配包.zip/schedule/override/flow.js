var FA_Type = new Array("审批", "签字", "抄送");
var FA_Type0 = new Array("串行", "并行", "会审");
var FA_Type1 = new Array("串行", "并行", "会签");
var arrField = new Array("F_NodeKey", "F_NodeName", "F_Reviewer",
		"F_ReviewerName", "F_ReviewType", "F_JumpCondition", "F_JumpNode",
		"F_Option", "F_FunList", "F_NodePosition", "F_BakReviewer",
		"F_BakReviewerName", "F_NodeSetting", "F_SubFlowDef","F_ParsedBy","F_ExtendHours");  // added at 201604 F_ExtendHours  //2015-02 add "F_ParsedBy"// flowRecycle增加F_SubFlowDef变量
var xmlList1 = new Array();
var hasOpinion = false;
var urlcachet = "";
var editDialogInfo = new Array;
var isFlowLoaded = false;
RegisterJsFile("flow.js");
function chgReviewer(node, dns, nms) {
	with (document.forms[0]) {
		var r = parseInt(node);
		if (r >= 1 && r <= getRows()) {
			eval("F_Reviewer_" + r).value = dns;
			eval("F_ReviewerName_" + r).value = nms;
			tReview.rows[r].cells[2].innerText = nms;
		}
	}
}
function delRecordN(r) {
	with (document.forms[0]) {
		var rows = getRows();
		for (var i = r + 1; i <= rows; i++) {
			for (var j = 0; j < arrField.length; j++)
				eval(arrField[j] + "_" + (i - 1)).value = eval(arrField[j]
						+ "_" + i).value;
		}
		for (i = 0; i < arrField.length; i++)
			eval(arrField[i] + "_" + rows).value = "";
	}
	delRow(r);
	changeFuture();
}
function setOpinion(flag) {
	hasOpinion = flag;
}
function submitFlow(strDo) {
	presaveFlow();
}
function CheckCustomForm() {
	try {
		if (parent.if_subform != null) {
			return parent.if_subform.C_Check();
		}
	} catch (e) {
	}
	return true;
}
function checkFlowFormat() {
	var rows = 0;
	var isChange = false;
	if (document.all.F_SubmitOpt.value == "0") {
		if (document.all.F_SaResult) {
			var F_SaResult = document.all.F_SaResult;
			for (var t = 0; t < F_SaResult.length; t++) {
				if (F_SaResult[t].checked && F_SaResult[t].value == "修改后续流程") {
					isChange = true;
					break;
				}
			}
		}
	} else if ((document.all.F_SubmitOpt.value == "1")) {
		if (getOption(document.all.F_ReviewNo.value, 1) == "1")
			isChange = true;
	}
	if (IsDisplayedFlow && isChange) {
		if (!if_flowchart.FlowChartObject.SaveFlow()) {
			return false;
		}
	}
	rows = document.all.F_ReviewAmount.value;
	var reg;
	var reg1;
	var k = 0;
	with (document.forms[0]) {
		for (var i = 0; i <= rows; i++) {
			var cond = trim(eval("F_JumpCondition_" + i).value);
			if (fullTrim(cond) == "")
				continue;
			k++;
			var conds = cond.split("\n");
			for (var j = 0; j < conds.length; j++) {
				cond = trim(conds[j]) + "\n";
				if (cond.length == 1)
					continue;
				reg = eval("/\\s\\#\\d*\\s*\\n/g");
				reg1 = eval("/\\s\\#end\\s*\\n/g");
				if (cond.search(reg) == -1 && cond.search(reg1) == -1) {
					alert("流程第“" + i + "”节点的第“" + (j + 1) + "”个条件格式不正确！");
					return false;
				}
				var end = cond.lastIndexOf("#");
				var node = cond.substr(end + 1, cond.length);
				if (node != "end" && parseInt(node) > rows) {
					alert("流程第“" + i + "”节点的第“" + (j + 1) + "”个条件要跳转的节点不存在！");
					return false;
				}
			}
		}
		F_CondAmount.value = k;
		return true;
	}
}
//检测是否需要电子签名
function checkNeedSignFlow()
{
	if(window.S_IsNowSmsReview) {window.S_IsNowSmsReview=false;return true;}
	if (document.all.optCachet) {
		if (document.all.F_EsignEnabled.value=="1") {
			if (!window.S_NeedSaveSign) {
				alert("请使用电子签名或者直接通过短信审批。")
				return false;
			}
		}
	}
	return true;	
}
function checkFlow() {
	if (!isFlowLoaded) {
		alert("流程文档正在加载中,还未加载完成!");
		return false;
	}
	if (!CheckCustomForm())
		return false;
	if (!checkFlowFormat())
		return false;
	//updateRoute();
	insertFlowInfo();
	with (document.forms[0]) {
		var nochecked = true;
		if (F_SubmitOpt.value == 1) {
			if (reviewType(F_ReviewNo.value, "10") == "1"
					|| reviewType(F_ReviewNo.value, "10") == "3") {
				if (document.forms[0].F_DocStatus.value == "待审"
						&& document.forms[0].F_RvCommun.value == "1"
						&& document.forms[0].F_ToCommunADCur.value != "") {
					alert("当前是沟通状态，请先结束沟通或等沟通结束后再做其他操作！");
					return false;
				}
				for (var t = 0; t < F_Result.length; t++) {
					if (F_Result[t].checked) {
						nochecked = false;
						break;
					}
				}
				if (nochecked) {
					alert("请选择流程“处理方式”！")
					return false;
				}
			}
			for (var k = 0; k < F_Result.length; k++) {
				if (F_Result[k].checked) {
					//=======电子签名检测============
					if (F_Result[k].value == "通过" || F_Result[k].value == "转办")
					{
						if(!checkNeedSignFlow()) return false;
					}
					//===============================
					if (F_Result[k].value == "转办" && F_ShiftName.value == "") {
						alert("请选择流程要“转办”的人员！");
						return false;
					}
					if (F_Result[k].value == "呈送" && F_ShiftName.value == "") {
						alert("请选择流程要“呈送”的人员！");
						return false;
					}
					if (F_Result[k].value == "沟通" && F_AskName.value == "") {
						alert("请选择流程要“沟通”的人员！");
						return false;
					}
					if (F_Result[k].value == "会签" && F_AskName.value == "") {
						alert("请选择流程要“会签”的人员！");
						return false;
					}
					if (F_Result[k].value == "请示" && F_AskName.value == "") {
						alert("请选择流程要“请示”的人员！");
						return false;
					}
					if (F_Result[k].value == "转办"
							&& S_UserAd.toLowerCase() == F_Shift.value
									.toLowerCase()) {
						alert("在流程处理中，不允许转办给自己，请重新选择转办人员！")
						return false;
					}
					if (F_Result[k].value == "呈送"
							&& S_UserAd.toLowerCase() == F_Shift.value
									.toLowerCase()) {
						alert("在流程处理中，不允许呈送给自己，请选择呈送人员！");
						return false;
					}
					if (F_Result[k].value == "沟通"
							&& (searchArray(F_Ask.value.split(";"), S_UserAd) != -1 || searchArray(
									F_Ask.value.split(";"), S_UserPost) != -1)) {
						alert("在流程处理中，不允许沟通自己，请选择沟通人员！");
						return false;
					}
					if (F_Result[k].value == "请示"
							&& (searchArray(F_Ask.value.split(";"), S_UserAd) != -1 || searchArray(
									F_Ask.value.split(";"), S_UserPost) != -1)) {
						alert("在流程处理中，不允许请示自己，请选择请示人员！");
						return false;
					}
					if (F_Result[k].value == "会签"
							&& (searchArray(F_Ask.value.split(";"), S_UserAd) != -1 || searchArray(
									F_Ask.value.split(";"), S_UserPost) != -1)) {
						alert("在流程处理中，不允许会签自己，请选择会签人员！");
						return false;
					}
					if (reviewType(F_ReviewNo.value, "01") == "1"
							|| reviewType(F_ReviewNo.value, "01") == "2") {
						var reviewers = eval("F_Reviewer_" + F_ReviewNo.value).value
								.split(";");
						var isbreak = false;
						for (var a = 0; a < reviewers.length; a++) {
							if (searchArray(F_Ask.value.split(";"),
									trim(reviewers[a])) != -1) {
								if (F_Result[k].value == "沟通") {
									alert("在并行或会审处理中，不允许审批人相互沟通，请选择沟通人员！");
									isbreak = true;
									break;
								}
								if (F_Result[k].value == "请示") {
									alert("在并行或会审处理中，不允许审批人相互请示，请选择请示人员！");
									isbreak = true;
									break;
								}
								if (F_Result[k].value == "会签") {
									alert("在并行或会审处理中，不允许审批人相互会签，请选择会签人员！");
									isbreak = true;
									break;
								}
							}
						}
						if (isbreak)
							return false;
					}
				}
			}
		} else {
			for (var t = 0; t < F_SaResult.length; t++) {
				if (F_SaResult[t].checked) {
					nochecked = false;
					break;
				}
			}
			if (nochecked) {
				alert("请选择流程“特权处理”！");
				return false;
			}
		}
		if (F_SubmitOpt.value == 1) {
			if ((reviewType(F_ReviewNo.value, "10") == "1" && F_Result[0].checked)
					|| reviewType(F_ReviewNo.value, "10") == "2") {
				if (!chkCondition())
					return false;
				if (!checkFlowReview())
					return false;
			}
			if (F_Opinion.value == "" && !hasOpinion) {
				alert("您未输入处理意见，请填写后再提交！");
				return false;
			}
		} else {
			if (F_Opinion.value == "" && !hasOpinion) {
				alert("您未输入处理意见，请填写后再提交！");
				return false;
			}
		}
		return true;
	}
}
// 检测流程中需要编辑的处理人
function checkFlowReview() {
	var opt;
	var optarr;
	var maxnum;
	var nodename;
	var curnode;
	var aboutRoad = "";
	var nextnodevalue;
	curnode = document.all.F_ReviewNo.value;
	var curOptionValue = getOption(curnode, 8);
	if (!(curOptionValue != "0" || getOption(curnode, 1) == "1"))
		return true;
	if (curOptionValue != "1" && curOptionValue!="0") {
		if (!checkSpecialNode(curOptionValue))
			return false;
		else return true;
	}
	with (document.forms[0]) {
		var nextnode = "";
		var jumpnode = F_ConJumpNode.value;
		if (jumpnode == "end")
			return true;
		var condition = eval("F_JumpCondition_" + curnode).value;
		if (jumpnode == "0") {
			if (condition == "") {
				nextnode = getNextNode(curnode);
				if (nextnode == "end")
					return true;
				// 田野 090609 modify up to below:增加提醒选择非必填人的功能
				var tempObj = eval("document.all.F_SubFlowDef_" + jumpnode);
				if (tempObj && tempObj.value == "")
					if (parseInt(curnode) <= parseInt(F_ReviewAmount.value)
							&& eval("F_Reviewer_" + nextnode).value == "" && eval("F_SubFlowDef_" + nextnode).value == "") {
						if (getOption(nextnode, 9) != "1") {
							alert("下一个节点处理人不能为空");
							return false;
						} else {
							if (confirm("下一个节点处理人为空,是否选择下一处理人?单击“确定”按钮返回系统添加处理人，单击“取消”按钮不添加处理人直接提交流程"))
								return false;
						}
					}
				// ---------------------------------------------------------
				aboutRoad = curnode + "," + nextnode;
			} else {
				aboutRoad = curnode;
			}
			nextnodevalue = nextnode;
		} else {

			// 田野 090609 modify up to below:增加提醒选择非必填人的功能
			var tempObj = eval("document.all.F_SubFlowDef_" + jumpnode);
			if (tempObj && tempObj.value == "")
				if (eval("F_Reviewer_" + jumpnode).value == "") {
					if (getOption(jumpnode, 9) != "1") {
						alert("下一个节点处理人不能为空");
						return false;
					} else {
						if (confirm("下一个节点处理人为空,是否选择下一处理人?单击“确认”按钮返回系统添加处理人，单击“取消”按钮不添加处理人直接提交流程"))
							return false;
					}
				}
			// ---------------------------------------------------------

			aboutRoad = curnode + "," + jumpnode;
			nextnodevalue = jumpnode;
		}
		if (getOption(nextnodevalue, 8) == "1"
				|| getOption(nextnodevalue, 1) == "1") // 下一节点为可修改处理人权限节点时
			return true;
		/*if (document.all.F_RecycleFlow)
			if (F_RecycleFlow.value == "1")
				return true;*/
		if (checkReviewerNull(nextnodevalue, F_ReviewAmount.value, document.all))
			return true;
		else
			return false;
	}
	return true;
}
var checkArr = new Array();
function checkReviewerNull(node, count, doc) {
	if (node == "end" || node == "0" || node=="")
		return true;

	if (parseInt(node, 10) > parseInt(count))
		return true;
	var isCheck = false;
	var tempArr = getOption(node, 8).split("&");
	checkArr = arrayAddItem(checkArr, tempArr);
	if (getOption(node, 9) == "1" || getOption(node, 10) == "1"
			|| eval("doc.F_SubFlowDef_" + node).value != "")
		isCheck = true;
	if (!isCheck && eval("doc.F_Reviewer_" + node).value == "") {
		nodeKey=eval("doc.F_NodeKey_" + node).value;
		if (!checkArr || arrayIndexOf(checkArr, nodeKey) == -1) {
			var nodename = eval("doc.F_NodeName_" + node).value;
			alert("请选择节点‘" + nodename + "’的处理人！");
			return false;
		}
	}
	if (getOption(node, 8) == "1" || getOption(node, 1) == "1")
		return true;
	var nextNodeNo = getNextNode(node);
	var nodes = nextNodeNo.split(";");
	for (var i = 0; i < nodes.length; i++)
		if (checkReviewerNull(nodes[i], count, doc))
			return true;
		else
			return false;
	return true;
}
function arrayAddItem(arr, newArr) {
	for (i = 0; i < newArr.length; i++) {
		if (newArr[i] == '' || newArr[i] == '0')
			continue;
		arr.push(newArr[i]);
	}
	return arr;
}
function presaveFlow() {
	with (document.forms[0]) {
		var nochecked = true;
		if (F_SubmitOpt.value == 1) {
			if (F_Result[1] != null && F_Result[1].checked
					&& F_Result[1].value == "驳回") {
				var index = selNode.options[selNode.selectedIndex].value;
				if (index > 0) {
					var viewAd = "";
					var viewNm = "";
					var doc = document.all;
					if (doc.review.length == null) {
						viewAd = doc.review.value;
						viewNm = doc.review.text;
					} else {
						var tagtype = doc.review[0].type.toLowerCase();
						for (var i = 0; i < doc.review.length; i++) {
							if (doc.review[i].checked) {
								if (tagtype == "radio") {
									for (var j = i; j < doc.review.length; j++) {
										viewAd = ((viewAd == "")
												? ""
												: (viewAd + ";"))
												+ doc.review[j].value;
										viewNm = ((viewNm == "")
												? ""
												: (viewNm + ";"))
												+ doc.review[j].text;
									}
									break;
								} else {
									viewAd = ((viewAd == "")
											? ""
											: (viewAd + ";"))
											+ doc.review[i].value;
									viewNm = ((viewNm == "")
											? ""
											: (viewNm + ";"))
											+ doc.review[i].text;
								}
							}
						}
					}
					F_Reviewer.value = viewAd;
					F_ReviewerName.value = viewNm;
				} else {
					F_RetractLock.value = chkRetractLock.checked ? "1" : "0";
				}
				F_RetractNode.value = index;
			}
			var addCommNode = 0;
			for (var k = 0; k < F_Result.length; k++) {
				if (F_Result[k].checked) {
					if (F_Result[k].value == "沟通" || F_Result[k].value == "会签"
							|| F_Result[k].value == "请示") {
						addCommNode = 1;
						F_Commun.value = F_RvUserDN.value;
						F_ToCommunAD.value = F_Ask.value;
						F_ToCommunName.value = F_AskName.value;
					}
				}
			}
			if (F_CanUpload.value == "1") {
				if (AttachmentObject.Upload() == 2)
					F_HandleAtt.value = "1";
          F_CachetID.value = SYSF_OriginalId.value;
			}
			buSubmit.click();
		} else {
			if (F_SaResult[1] != null && F_SaResult[1].checked
					&& F_SaResult[1].value == "前后跳转") {
				var index = jumpNode.selectedIndex;
				F_RetractNode.value = jumpNode[index].value;
			}
			buSaSubmit.click();
		}
	}
}
function setNo() {
	for (var i = 1; i < tReview.rows.length; i++) {
		tReview.rows[i].cells[0].innerHTML = getOption(i, 1) == "0"
				? i
				: ("<font color=blue>" + i + "</font>");
		tReview.rows[i].cells[0].align = "center";
	}
}
function resizeIframe() {
	if (document.body.scrollHeight == "") {
		setTimeout("resizeIframe();", 500);
		return;
	}
	var ifFlow = parent.document.all;
	for (var i = 0; i < ifFlow.length; i++) {
		if (ifFlow[i].tagName == "IFRAME" && ifFlow[i].src != null
				&& ifFlow[i].id != "if_subform") {
			var x = ifFlow[i].src.toLowerCase();
			var y = location.href.toLowerCase();
			x = x.indexOf(".nsf");
			y = y.indexOf(".nsf");
			if (x * y > 0) {
				var str = "parent.document.all." + ifFlow[i].id
						+ ".height = document.body.scrollHeight;";
				setTimeout("executeJs('" + str + "','parent.document.all."
								+ ifFlow[i].id + "')", 100);
				if (eval("parent.document.all." + ifFlow[i].id + ".width < 520"))
					eval("parent.document.all." + ifFlow[i].id + ".width = 520");
			}
		}
	}
}
function executeJs(js, condiction) {
	if (condiction != null)
		var obj = eval(condiction);
	if (obj != null) {
		if (obj.offsetHeight == 0)
			setTimeout("executeJs('" + js + "','" + condiction + "')", 100);
		else
			eval(js);
	} else
		eval(js);
}
function createDT() {
	var arrType;
	strHTML = "<table border=0 id=tReview width=100% cellspacing=1 cellpadding=4 bgcolor=#BBBBBB><tr><td bgcolor=#ffffff width=1% nowrap>节点</td>";
	for (var i = 0; i < arguments.length; i++) {
		arrType = arguments[i].split(":");
		strHTML += "<td bgcolor=#ffffff";
		if (arrType.length > 1)
			strHTML += " width=\"" + arrType[1] + "\"";
		if (arrType.length > 2)
			if (arrType[2] != "")
				strHTML += " align=\"" + arrType[2] + "\"";
		if (arrType.length > 3)
			strHTML += " Opration=\"" + arrType[3] + "\"";
		strHTML += ">" + arrType[0] + "</td>";
	}
	strHTML += "</tr></table>";
	document.write(strHTML);
}
function getRows() {
	var tReview = document.all.tReview;
	var validRows = tReview.rows.length - 1;
	return validRows;
}
function addRow() {
	var item;
	var arr;
	var str = "";
	var tReview = document.all.tReview.childNodes[0];
	if (document.all.tReview.tBodies.length > 50) {
		alert("对不起，目前只能支持50个节点！");
		return;
	}
	tReview.insertRow();
	var r = tReview.rows.length - 1;
	for (var i = 0; i < document.all.tReview.rows[0].cells.length; i++) {
		tReview.rows[r].insertCell();
		tReview.rows[r].cells[i].bgColor = "#ffffff";
		item = tReview.rows[0].cells[i].Opration;
		if (item != null) {
			arr = item.split("|");
			if ((document.forms[0].F_NodeEdit.value == 1)
					&& (r > document.forms[0].F_ReviewNo.value))
				tReview.rows[r].cells[i].innerHTML += "<a href='#' onClick='"
						+ arr[1] + "();return false;'>" + arr[0] + "</a>";
			else
				tReview.rows[r].cells[i].innerHTML += "-";
			tReview.rows[r].cells[i].align = tReview.rows[0].cells[i].align;
			tReview.rows[r].cells[i].noWrap = true;
		}
	}
	setNo();
	saJump();
}
function delRow(row) {
	tReview.deleteRow(row);
	document.forms[0].F_ReviewAmount.value = getRows();
	setNo();
	saJump();
	resizeIframe();
}
// flowRecycle 对于子流程中前后跳转至起草节点进行控制 整个替换
function saJump() {
	if (document.all.spanJumpNode != null) {
		var rows = document.all.F_ReviewAmount.value;
		with (document.forms[0]) {
			var strOpt = "<select class=selectmenu id=jumpNode>";
			var cur = F_ReviewNo.value;
			var optionStr = "";
			for (var i = 0; i <= rows; i++) {
				if (i != cur) {
					if (i == 0) {
						if (F_MainFlowDoc.value == "")
							optionStr += "<option value=" + i
									+ (i - 1 == cur ? " selected" : "")
									+ (i ? (">节点 " + i) : ">起草人");
					} else {
						if (eval("document.all.F_ReviewType_" + i).value != "30")
							optionStr += "<option value="
									+ i
									+ (i - 1 == cur ? " selected" : "")
									+ (i
											? (">"
													+ (eval("document.all.F_NodeName_"
															+ i).value)
													+ "(节点 " + i + ")")
											: ">起草人");
					}
				}
			}
			if (optionStr == "")
				strOpt = "";
			else
				strOpt += optionStr + "</select>";
			if (strOpt == "") {
				alert("对不起,没有可跳转的节点可供选择,请选择其他特权操作!");
				F_SaResult[1].checked = false;
			} else
				document.all.spanJumpNode.innerHTML = strOpt;
		}

	}
}
function retrieveRecord(r) {
	var doc = document.forms[0];
	var k = doc.F_ReviewNo.value;
	var nodeAd = parseInt(eval("doc.F_ReviewType_" + r).value);
	var nodeNm = "";
	var str = "";
	if (!isNaN(nodeAd)) {
		var indexT = Math.floor(nodeAd / 10 - 1);
		nodeNm = window.FA_Type[indexT];
		var arrType = eval("window.FA_Type" + indexT);
		if (arrType != null)
			nodeNm = nodeNm + ":" + eval("arrType[" + (nodeAd % 10) + "]");
	}
	tReview.rows[r].cells[1].innerText = eval("doc.F_NodeName_" + r).value;
	if (k < r && (getOption(k, 8) == "1" || getOption(k, 1) == "1")) {
		createInner(tReview.rows[r].cells[2], r,
				eval("doc.F_ReviewerName_" + r).value, eval("doc.F_Reviewer_"
						+ r).value, true);
	} else {
		createInner(tReview.rows[r].cells[2], r,
				eval("doc.F_ReviewerName_" + r).value, eval("doc.F_Reviewer_"
						+ r).value, false);
		if (k == r)
			tReview.rows[r].style.color = "red";
	}
	tReview.rows[r].cells[3].innerText = nodeNm;
	if (tReview.rows[0].cells[4].innerText == "备注") {
		var info = "";
		if (k > r)
			info = "已处理节点";
		else {
			if (k < r)
				info = "未处理节点";
			else {
				if (eval("doc.F_ReviewType_" + r).value.substr(0, 1) == "2") {
					var days = doc.F_Option.value;
					if (days == 0)
						info = "永不过期";
					else
						info = days + " 天后过期";
				} else
					info = "当前节点";
			}
		}
		tReview.rows[r].cells[4].innerText = info;
	}
}
function selectReviewer(upgmc, isCanModify) {
	with (document.forms[0]) {
		var oa = window.event.srcElement;
		var otr = oa.parentElement;
		while (otr.tagName != "TR")
			otr = otr.parentElement;
		r = otr.rowIndex;
		AddressBook("ad:name", "F_Reviewer_" + r + ":F_ReviewerName_" + r,
				true, (upgmc == "30" ? "UPGM" : "PM"), true);
		createInner(tReview.rows[r].cells[2], r,
				eval("F_ReviewerName_" + r).value,
				eval("F_Reviewer_" + r).value, isCanModify);
	}
}
function addRecord() {
	addRow();
	editRecord();
	changeFuture();
}
function delRecord() {
	var oa = window.event.srcElement;
	var otr = oa.parentElement;
	while (otr.tagName != "TR")
		otr = otr.parentElement;
	r = otr.rowIndex;
	with (document.forms[0]) {
		if (!confirm("确定要删除节点“" + r + "”？"))
			return;
		var rows = getRows();
		for (var i = r + 1; i <= rows; i++) {
			for (var j = 0; j < arrField.length; j++)
				eval(arrField[j] + "_" + (i - 1)).value = eval(arrField[j]
						+ "_" + i).value;
		}
		for (i = 0; i < arrField.length; i++)
			eval(arrField[i] + "_" + rows).value = "";
	}
	delRow(r);
	changeFuture();
}
function editRecord() {
	var oa = window.event.srcElement;
	var otr = oa.parentElement;
	while (otr.tagName != "TR")
		otr = otr.parentElement;
	var r = otr.rowIndex;
	with (document.forms[0]) {
		if (r == 0)
			r = tReview.rows.length - 1;
		var cPath = location.href.toLowerCase();
		var dPath = cPath.substring(0, cPath.indexOf(".nsf") + 4)
				+ "/FM_EditNodeReview?OpenForm&IsDef=0";
		var pPath = this.parent.document.location.pathname.toLowerCase();
		pPath = pPath.substring(1, pPath.indexOf(".nsf") + 4);
		dPath = dPath + "&fresh=" + (otr.rowIndex ? false : true);
		dPath = dPath + "&module=" + pPath.replace(/\//g, "+");
		var recObj = new Object;
		recObj.whoOpen = "Review";
		recObj.rowIndex = r;
		recObj.rowCount = getRows();
		recObj.F_NodeName = eval("F_NodeName_" + r).value;
		recObj.F_Reviewer = eval("F_Reviewer_" + r).value;
		recObj.F_ReviewerName = eval("F_ReviewerName_" + r).value;
		recObj.F_ReviewType = eval("F_ReviewType_" + r).value;
		recObj.F_Option = eval("F_Option_" + r).value;
		recObj.F_FunList = eval("F_FunList_" + r).value;
		var feature = "dialogWidth:550px;dialogHeight:300px;center:1;status:0;resizable=yes;scroll:0;help:1";
		recObj = window.showModalDialog(dPath, recObj, feature);
		if (recObj != null) {
			eval("F_NodeName_" + r).value = recObj.F_NodeName;
			eval("F_Reviewer_" + r).value = recObj.F_Reviewer;
			eval("F_ReviewerName_" + r).value = recObj.F_ReviewerName;
			eval("F_ReviewType_" + r).value = recObj.F_ReviewTypeAd;
			eval("F_Option_" + r).value = recObj.F_Option;
			eval("F_FunList_" + r).value = recObj.F_FunList;
			tReview.rows[r].cells[1].innerText = recObj.F_NodeName;
			createInner(tReview.rows[r].cells[2], r, recObj.F_ReviewerName,
					recObj.F_Reviewer, false);
			tReview.rows[r].cells[3].innerText = recObj.F_ReviewTypeNm;
			tReview.rows[r].cells[0].innerHTML = getOption(r, 1) == "0"
					? r
					: ("<font color=blue>" + r + "</font>");
		} else if (otr.rowIndex == 0)
			delRow(tReview.rows.length - 1);
		changeFuture();
	}
	resizeIframe();
}
function createInner(obj, rownum, viewers, viewersAD, isCanModefied) {
	with (document.forms[0]) {
		var d1 = new Date();
		var arr = viewersAD.split(";");
		var arrDis = viewers.split(";");
		var d2 = new Date();
		var t = "";
		var xmlList = new Array();
		var slist = new Array();
		var viewersSpan = "";
		var inner = "";
		this.processText = function() {
			for (var i = 0; i < xmlList.length; i++) {
				if (xmlList[i] != null) {
					if (xmlList[i].readyState == 4) {
						if (xmlList[i].responseText.indexOf("ReturnMsg") > -1) {
							slist[i] = xmlList[i].responseXML
									.selectNodes("/ReturnMsg")[0].text;
						} else
							slist[i] = "";
						xmlList[i] = null;
					}
				}
			}
			for (var i = 0; i < xmlList.length; i++) {
				if (xmlList[i] != null)
					return;
			}
			var tagTitle = "";
			for (var i = 0; i < slist.length; i++) {
				tagTitle += (slist[i] + ";");
			}
			tagTitle = tagTitle.substring(0, tagTitle.length - 1);
			if (tagTitle.substring(0, 1) == ";")
				tagTitle = tagTitle.substring(1, tagTitle.length);
			titleArr = tagTitle.split("）;");
			if (tagTitle != "")
				t = " title=\"" + tagTitle + "\"";
			viewersSpan = "";
			inner = "<a href=#" + t + " onClick=\'selectReviewer(\""
					+ eval("F_ReviewType_" + rownum).value + "\","
					+ isCanModefied + ");return false;\'>修改处理人</a>";
			inner = "　『" + inner + "』";
			for (var ii = 0; ii < arr.length; ii++) {
				if (titleArr.length == arr.length && titleArr[0] != "") {
					if (ii < (arr.length - 1))
						titleArr[ii] = titleArr[ii] + "）";
					viewersSpan = viewersSpan + "<span userAD='" + arr[ii]
							+ "' title='" + titleArr[ii] + "' class='user'>"
							+ arrDis[ii] + "</span>";
				} else {
					viewersSpan = viewersSpan + "<span userAD='" + arr[ii]
							+ "' class='user'>" + arrDis[ii] + "</span>";
				}
				if (ii < (arr.length - 1))
					viewersSpan = viewersSpan + ";";
			}
			if (isCanModefied) {
				obj.innerHTML = viewersSpan + inner;
			} else {
				obj.innerHTML = viewersSpan;
			}
		};
		var s = "";
		var tagT = "";
		xmlList[0] = null;
		for (var i = 0; i < arr.length; i++) {
			if (!isSync) {
				s = personList(trim(arr[i]));
				if (s != "")
					tagT += (s + ";");
			} else {
				xmlList[i] = personList_async(trim(arr[i]), this.processText);
				xmlList1[xmlList1.length] = xmlList[i];
				slist[i] = "";
			}
		}
		if (!isSync) {
			tagT = tagT.substring(0, tagT.length - 1);
			if (tagT.substring(0, 1) == ";")
				tagT = tagT.substring(1, tagT.length);
			tArr = tagT.split("）;");
			if (tagT != "")
				t = " title=\"" + tagT + "\"";
			inner = "<a href=#" + t + " onClick=\'selectReviewer(\""
					+ eval("F_ReviewType_" + rownum).value + "\","
					+ isCanModefied + ");return false;\'>修改处理人</a>";
			inner = "　『" + inner + "』";
			viewersSpan = "";
			for (var ii = 0; ii < arr.length; ii++) {
				if (tArr.length == arr.length && tArr[0] != "") {
					if (ii < (arr.length - 1))
						tArr[ii] = tArr[ii] + "）";
					viewersSpan = viewersSpan + "<span userAD='" + arr[ii]
							+ "' title='" + tArr[ii] + "' class='user'>"
							+ arrDis[ii] + "</span>";
				} else {
					viewersSpan = viewersSpan + "<span userAD='" + arr[ii]
							+ "' class='user'>" + arrDis[ii] + "</span>";
				}
				if (ii < (arr.length - 1))
					viewersSpan = viewersSpan + ";";
			}
			if (isCanModefied) {
				obj.innerHTML = viewersSpan + inner;
			} else {
				obj.innerHTML = viewersSpan;
			}
		} else {
			for (var i = 0; i < xmlList.length; i++) {
				if (xmlList[i] != null)
					return;
			}
			if (viewersSpan == "" && isCanModefied) {
				inner = "<a href=#" + t + " onClick=\'selectReviewer(\""
						+ eval("F_ReviewType_" + rownum).value + "\","
						+ isCanModefied + ");return false;\'>修改处理人</a>";
				inner = "　『" + inner + "』";
				obj.innerHTML = inner;
			}
		}
	}
}
function upRecord() {
	var oa = window.event.srcElement;
	var otr = oa.parentElement;
	while (otr.tagName != "TR")
		otr = otr.parentElement;
	r = otr.rowIndex;
	var otable = otr.parentNode;
	var curRow = parseInt(document.forms[0].F_ReviewNo.value);
	if (r > (curRow + 1))
		exchangeRecord(r, r - 1);
	else
		alert("此节点不能再上移了！");
}
function downRecord() {
	var oa = window.event.srcElement;
	var otr = oa.parentElement;
	while (otr.tagName != "TR")
		otr = otr.parentElement;
	r = otr.rowIndex;
	var otable = otr.parentNode;
	if (r < tReview.rows.length - 1)
		exchangeRecord(r, r + 1);
	else
		alert("此节点不能再下移了！");
}
function exchangeRecord(src, des) {
	with (document.forms[0]) {
		var i;
		for (i = 0; i < arrField.length; i++) {
			tmp = eval(arrField[i] + "_" + src).value;
			eval(arrField[i] + "_" + src).value = eval(arrField[i] + "_" + des).value;
			eval(arrField[i] + "_" + des).value = tmp;
		}
		for (i = 1; i < tReview.rows[0].cells.length; i++) {
			tmp = tReview.rows[src].cells[i].innerHTML;
			tReview.rows[src].cells[i].innerHTML = tReview.rows[des].cells[i].innerHTML;
			tReview.rows[des].cells[i].innerHTML = tmp;
		}
		document.all.spanFuture.innerHTML = eval("F_ReviewerName_"
				+ (parseInt(F_ReviewNo.value) + 1)).value;
	}
	setNo();
}
function reviewType(row, flag) {
	with (document.all) {
		var rwType = eval("F_ReviewType_" + row).value;
		var rt;
		switch (flag) {
			case "01" :
				rt = rwType.substr(1, 1);
				break;
			case "10" :
				rt = rwType.substr(0, 1);
				break;
			case "11" :
				rt = rwType;
				break;
			case "?*" :
				rt = "4";
				break;
			default :
				rt = rwType;
		}
		return rt;
	}
}
function changeNode() {
	var node = parseInt(document.all.selNode.value);
	if (node == 0) {
		document.all.spanRetractReviewer.innerHTML = "";
		document.all.spanRetractLock.innerHTML = "<INPUT TYPE=checkbox ID=chkRetractLock"
				+ isChk + ">" + (isChk.indexOf("display:none")>-1?"":"重新提交后直接返回到本节点");
	} else {
		document.all.spanRetractLock.innerHTML = "";
		var doc = document.forms[0];
		var str = " <input name=review type=";
		var strOpt = "";
		if (reviewType(node, "01") == "0" && reviewType(node, "10") != "3")
			str += "radio";
		else
			str += "checkbox onClick=setCheck('review')";
		var rAd = eval("doc.F_Reviewer_" + node).value.split(";");
		var rName = eval("doc.F_ReviewerName_" + node).value.split(";");
		for (var i = 0; i < rAd.length; i++) {
			strOpt += (str + " text='" + trim(rName[i]) + "' value='"
					+ trim(rAd[i]) + "'");
			strOpt += (rAd.length == 1 ? " disabled" : "");
			strOpt += ((i ? ">" : " checked>") + trim(rName[i]));
		}
		document.all.spanRetractReviewer.innerHTML = strOpt;
	}
}
function getOption(row, index) {
	try {
		with (document.forms[0]) {
			var options = (eval("F_Option_" + row).value).split(";");
			return (options[index] == null ? "0" : trim(options[index]));
		}
	} catch (e) {
	}
}
function setCheck(tag) {
	var tagC = eval("document.all." + tag);
	for (var i = 0; i < tagC.length; i++)
		if (tagC[i].checked)
			break;
	if (i == tagC.length)
		for (i = 0; i < tagC.length; i++)
			tagC[i].checked = true;
}
function changeFuture() {
	var doc = document.forms[0];
	var curNo = parseInt(doc.F_ReviewNo.value);
	var str = "";
	var cond = "";
	if (reviewType(curNo, "01") == "0" && document.all.inpSerial.value == "1")
		return;
	else {
		cond = trim(eval("doc.F_JumpNode_" + curNo).value);
		if (cond != "")
			str = eval("doc.F_ReviewerName_" + cond).value;
		else if (curNo < getRows())
			str = eval("doc.F_ReviewerName_" + (curNo + 1)).value;
		else
			str = "<font color=blue>流程结束！</font>";
		document.all.spanFuture.innerHTML = str;
	}
}
function getTypeName(type) {
	var t1 = parseInt(type.charAt(0));
	var t2 = parseInt(type.charAt(1));
	if (t1 == 1)
		return "审批:" + FA_Type0[t2];
	if (t1 == 2)
		return "签字:" + FA_Type1[t2];
	return "抄送";
}
function insertRecord(index, nodename, reviewer, reviewername, reviewtype,
		option, funlist) {
	addRow();
	var r = document.all.tReview.rows.length - 1;
	eval("document.all.F_NodeName_" + r).value = nodename;
	eval("document.all.F_Reviewer_" + r).value = reviewer;
	eval("document.all.F_ReviewerName_" + r).value = reviewername;
	eval("document.all.F_ReviewType_" + r).value = reviewtype;
	eval("document.all.F_Option_" + r).value = option;
	eval("document.all.F_FunList_" + r).value = funlist;
	tReview.rows[r].cells[1].innerText = nodename;
	tReview.rows[r].cells[2].innerHTML = reviewername;
	tReview.rows[r].cells[3].innerText = getTypeName(reviewtype);
	tReview.rows[r].cells[0].innerHTML = getOption(r, 1) == "0"
			? r
			: ("<font color=blue>" + r + "</font>");
	for (var i = r; i > index; i--)
		exchangeRecord(i, i - 1);
}
function onAttachmentChanged(i) {
	resizeIframe();
}

function insertFlowTip() {
	with (document.forms[0]) {
		if (document.forms[0].F_FlowTip != null) {
			var tips = F_FlowTips.value.split("\n");
			for (i = 0; i < tips.length; i++) {
				if (trim(tips[i]) == "")
					continue;
				if (m_CalculateText(tips[i]) > 6)
					tips[i] = m_Substring(tips[i], 6) + "...";
				F_FlowTip.options[i + 1] = new Option(tips[i]);
			}
		}
	}
}
function popReview(strUrl) {
	var Popup = null;
	var Style = "width=550,height=190,resizable=yes,scrollbars=1";
	Popup = window.open(strUrl, "_blank", Style);
	if (Popup != null) {
		if (Popup.opener == null) {
			Popup.opener = self;
		}
	}
}
function onloadJs() {
	if (document.all.tdRetract != null)
		tdRetract.parentNode.style.display = "none";
	if (document.all.tdTransfer != null)
		tdTransfer.parentNode.style.display = "none";
	if (document.all.tdAsk != null)
		tdAsk.parentNode.style.display = "none";
	if (document.all.tdAsk2 != null)
		tdAsk2.parentNode.style.display = "none";
	var gt;
	var gtobj = document.forms[0].F_CommunName;
	if (gtobj != null)
		gt = gtobj.value;
	if (document.all.buGT != null) {
		document.all.buGT.value = "结束" + gt;
		document.all.buGT.title = "发起" + gt + "人结束" + gt + "过程";
	}
	if (document.all.Btn_RvCommun != null) {
		document.all.Btn_RvCommun.value = "回复" + gt + "意见";
		document.all.Btn_RvCommun.title = "回复" + gt + "并提交意见";
	}
	if (document.forms[0].F_DocStatus.value == "待审"
			&& document.forms[0].F_RvCommun.value == "1"
			&& document.forms[0].F_ToCommunADCur.value != "")
		if (document.all.tdUpload != null)
			document.all.tdUpload.parentNode.style.display = "none";
	var searchStr;
	var fromsStr;
	var fromArr;
	if (document.all.F_RvUserNm != null && document.all.F_RvUserDN != null)
		searchStr = document.all.F_RvUserNm.value + "|"
				+ document.all.F_RvUserDN.value;
	if (document.all.F_RvUnderCommun != null) {
		fromsStr = document.all.F_RvUnderCommun.value;
		fromArr = fromsStr.split(";");
	}
	for (var m = 0; m < fromArr.length; m++) {
		if (fromArr[m] != "") {
			var tempArr = fromArr[m].split("^");
			if (trim(searchStr.toLowerCase()) == trim(tempArr[1].toLowerCase())
					|| document.forms[0].F_RvAdmin.value == "1") {
				if (document.all.btn_stopback != null)
					document.all.btn_stopback.style.display = "";
				break;
			}
		}
	}
	if (document.all.tdSa != null) {
		if (isOnlySa == "1") {
			tdSa.parentNode.style.display = "block";
			for (var i = 0; i < document.forms[0].F_SaResult.length; i++)
				document.forms[0].F_SaResult[i].checked = false;
		} else
			tdSa.parentNode.style.display = "none";
	}
	if (document.all.tdResult != null) {
		if (reviewType(parseInt(document.forms[0].F_ReviewNo.value), "10") == "1")
			tdResult.parentNode.style.display = "block";
		else
			tdResult.parentNode.style.display = "none";
	} else {
		document.all.spanCondition.style.display = "none";
	}
	insertFlowTip();
	resizeIframe();
	if (isEdited) {
		if (document.all.F_ReviewAmount.value > 0) {
			showCondition();
			showNextNodeInfo();
			showDealedMan();
			showSubFlow(); // flowRecycle 增加对showsubflow函数的调用
		}
	}
	isFlowLoaded = true;
}
function showCondition() {
	with (document.forms[0]) {
		if (document.all.spanCondition.style.display == "none")
			return;
		var strOpt = "";
		if (F_ReviewAmount.value > 0) {
			var cond;
			var conds;
			var end;
			var node;
			var disCond;
			var k;
			var i = F_ReviewNo.value;
			cond = trim(eval("F_JumpCondition_" + i).value);
			if (cond == "") {
				return;
			}
			conds = cond.split("\n");
			if (FlowChart_Line_GetValue(conds[0], "jumpType") == "1")
				return;
			if (FlowChart_Line_GetValue(conds[0], "jumpType") == "2")
				return;
			strOpt = strOpt + "节点" + i + "：";
			k = eval("F_JumpNode_" + i).value;
			for (var j = 0; j < conds.length; j++) {
				cond = FlowChart_Line_GetValue(fullTrim(conds[j]), "desc");
				var contitle = FlowChart_Line_GetValue(fullTrim(conds[j]),
						"title");
				end = cond.lastIndexOf("#");
				node = cond.substr(end + 1, cond.length);
				var nodeKey = node.toLowerCase() == "end"
						? "end"
						: eval("F_NodeKey_" + node).value;
				if (node.toLowerCase() == "end") {
					disCond = "\"" + contitle + "\"分支  " + cond + "(结束)";
				} else {
					disCond = "\"" + contitle + "\"";
				}// disCond="\""+contitle+"\"分支
				// "+cond+"("+eval("F_NodeName_"+node).value+")";}
				check = (node == F_ConJumpNode.value) ? "checked" : "";
				if (k == "" && j == 0) {
					strOpt += "<input type=radio name=JumpNode_" + i
							+ " value=" + nodeKey + " onClick=onCondition(" + i
							+ ",'" + nodeKey + "'); " + check + ">" + disCond;
				} else
					strOpt += "<input type=radio name=JumpNode_" + i
							+ " value=" + nodeKey + " onClick=onCondition(" + i
							+ ",'" + nodeKey + "'); " + check + ">" + disCond;
			}
			strOpt += "<br>";
			if (strOpt != "")
				strOpt = "<font color=blue>流程分支决策，请选择该节点的跳转：</font><br>"
						+ strOpt;
		}
		if (strOpt != "")
			document.all.spanCondition.innerHTML = strOpt + "<br>";
	}
}
// yezq 2009-1-23 选择审批人
function flow_selectReviewer(r) {
	// var field = document.getElementsByName("F_ReviewType_" + r)[0];
	// AddressBook("ad:name", "F_Reviewer_" + r + ":F_ReviewerName_" + r, true,
	// 		(field.value == "30" ? "UPGM" : "PM"), true);
	// document.getElementById("FLOWSPANREVIEWER_" + r).innerHTML = document
	// 		.getElementsByName("F_ReviewerName_" + r)[0].value;
  
  	var field = document.getElementsByName("F_ReviewType_" + r)[0];
	AddressBook("ad:name", "F_Reviewer_" + r + ":F_ReviewerName_" + r, true,
			(field.value == "30" ? "UPGM" : "PM"), true,null, null,function() {
    document.getElementById("FLOWSPANREVIEWER_" + r).innerHTML = document
			.getElementsByName("F_ReviewerName_" + r)[0].value;
  });
}

// yezq 2009-2-15 选择备选处理人
function flow_selectBakReviewer(r) {
	var adField = document.getElementsByName("F_Reviewer_" + r)[0];
	var nameField = document.getElementsByName("F_ReviewerName_" + r)[0];
	var path = location.href.toLowerCase();
	path = path.substring(0, path.indexOf(".nsf") + 4);
	path += "/FM_AddressMul?OpenForm";
	var dogstyle = "dialogWidth:430px; dialogHeight:330px; status:0;scroll:0; help:0";
	var obj = new Object;
	obj.fromAds = document.getElementsByName("F_BakReviewer_" + r)[0].value;
	obj.fromNames = document.getElementsByName("F_BakReviewerName_" + r)[0].value;
	obj.toAds = adField.value;
	obj.toNames = nameField.value;
	obj.F_Creator = document.getElementsByName("F_Creator")[0].value;
	var rtnObj = window.showModalDialog(path, obj, dogstyle);
	if (rtnObj != null) {
		adField.value = rtnObj.returnAds;
		nameField.value = rtnObj.returnNames;
		document.getElementById("FLOWSPANREVIEWER_" + r).innerHTML = rtnObj.returnNames;
	}
}
// lih 2008 05 29获取指定节点的下一节点号，若为单个返回此节点号，多个返回字符串“分支节点1;分支节点2”
function getNextNode(node, issat) {
	var doc = document.all;
	var countNode = doc.F_ReviewAmount.value;
	var rtnStr;
	tempObj=eval("doc.F_JumpCondition_" + node);
  // tempObj = document.querySelector('[name="F_JumpCondition_'+node+'"]');
	if(!tempObj) return ""; 
	var cond = tempObj.value;
	tempObj=eval("doc.F_JumpNode_" + node);
  // tempObj = document.querySelector('[name="F_JumpNode_'+node+'"]');
	var jumpnode = tempObj.value;
	if (cond == "") {
		if (jumpnode.toLowerCase() == "end"
				|| parseInt(node) > parseInt(countNode))
			rtnStr = "end";
		else if (jumpnode == "")
			rtnStr = new String(parseInt(node) + 1).toLowerCase();
		else
			rtnStr = jumpnode;
	} else {
		var conds = cond.split("\r\n")
		for (var j = 0; j < conds.length; j++) {
			var desc = FlowChart_Line_GetValue(conds[j], "desc");
			node = desc.substring(desc.lastIndexOf("#") + 1, desc.length);
			if (issat == null || issat == false) return "";
				/*if (jumpnode.toString() == node.toString() && jumpnode != "") {
					rtnStr = node;
					return rtnStr;
				}*/

			if (j == 0)
				rtnStr = node == "end" ? "end" : node;
			else
				rtnStr += node == "end" ? ";end" : ";" + node;
		}
	}
	return rtnStr;
}

// 2010-05-29
function getAllRoute(node, nodeArr) {
	if (document.all.F_RecycleFlow)
		if (document.all.F_RecycleFlow.value == "1")
			return;

	if (node == "end") {
		return;
	} else {
    if(node){
      nodeArr.push(node);
    }
		
		var nextNodeNo = getNextNode(node, true);
		var nodes = nextNodeNo.split(";");
		for (var i = 0; i < nodes.length; i++) {
			getAllRoute(nodes[i], nodeArr);
		}
	}
	return;
}

// 2007.12.17显示下一节点处理人员lih 12.29lih modifid
function showNextNodeInfo(nextNode) {
	try {
		var doc = document.all;
		var cureentNode = doc.F_ReviewNo.value;
		var nextNodeInfo = "";
		if(!nextNode)	nextNode = getNextNode(cureentNode);
		var nodes = nextNode.split(";");
		// =========== start by yezq 2009-1-23 可修改下一节点处理人 ===============
		if (nodes.length == 1) {
			var node = nodes[0];
			if (node == "end") {
				nextNodeInfo = "流程结束";
			} else {
				var subFlowObj = eval("doc.F_SubFlowDef_" + node);
				nextNodeInfo = document.getElementsByName("F_NodeName_" + node)[0].value;
				if(subFlowObj && subFlowObj.value!="") {document.all.spanFuture.innerHTML = nextNodeInfo;return };
				
				nextNodeInfo += "(<span id='FLOWSPANREVIEWER_"
						+ node
						+ "'>"
						+ document.getElementsByName("F_ReviewerName_" + node)[0].value
						+ "</span>)";
				if (getOption(doc.F_ReviewNo.value, 1) == "1"
						|| checkOptionsRight(
								getOption(doc.F_ReviewNo.value, 8), node)) {
					nextNodeInfo += "『<a href='javascript:flow_selectReviewer(\""
							+ node
							+ "\");'><b><font color=red>选择</font></b></a>』";
					if (document.getElementsByName("F_BakReviewerName_" + node)[0].value != "") {
						nextNodeInfo += "『<a href='javascript:flow_selectBakReviewer(\""
								+ node
								+ "\");'><b><font color=red>备选列表</font></b></a>』";
					}
				}
			}
			if (document.all.spanFuture != null)
				document.all.spanFuture.innerHTML = nextNodeInfo;
		}
		// =========== end by yezq 2009-1-23 ===============
	} catch (e) {
	}
}
function showRetractNodes() {
	var hasRouteValue = document.all.F_HasRouteNode.value;
	var hasRouteArr = hasRouteValue.split(",");
	// flowRecycle 对于循环流程处理
	if (document.all.F_RecycleFlow)
		return uniqueTrim(hasRouteArr).sort();

}
function insertFlowInfo() {
	var doc = document.all;
	var curNode = doc.F_ReviewNo.value;
	var rows = doc.F_ReviewAmount.value;
	var field, field1;
	var reviewer, reviewername;
	if (rows > 0) {
		for (var i = parseInt(curNode) + 1; i <= rows; i++) {
			if (getOption(i, 10) == "1") {
				var field = eval("doc.F_RevField_" + i).value.split("^")[1];
				if (field.indexOf("CF_") == 0) {
					field1 = field.substring(0, field.length - 2);
					reviewer = eval("window.parent.if_subform.document.all."
							+ field);
					reviewername = eval("window.parent.if_subform.document.all."
							+ field.substring(0, field.length - 2));
				}
				if (window.parent.S_IsEdited == "1" && field.indexOf("F_") == 0) {
					field1 = eval("doc.F_RevField_" + i).value.split("^")[2];
					reviewer = eval("window.parent.document.all." + field);
					reviewername = eval("window.parent.document.all." + field1);
				}
				if (reviewer != null && reviewer.value != "") {
					eval("doc.F_Reviewer_" + i).value = reviewer.value;
					eval("doc.F_ReviewerName_" + i).value = reviewername.value;
				}
			}
		}
	}
}
function uniqueTrim(arr) {
	if (arr.length == 0) {
		return null;
	}
	arr = trimArray(arr, "");
	var a = {};   
	var len = arr.length;   
	for(var i=0; i<len; i++)  {     
    		if(typeof a[arr[i]] == "undefined")     
    		a[arr[i]] = 1;     
  	}     
  	arr.length = 0;     
  	for(var i in a)     
  		arr[arr.length] = i;     
  	return arr;     
}
function arraySort(sortArr) {
	for (var i = 0; i < sortArr.length; i++) {
		for (var j = 1; j < sortArr.length; j++) {
			if (parseInt(sortArr[j - 1], 10) > parseInt(sortArr[j], 10)) {
				var tmpVar = sortArr[j - 1];
				sortArr[j - 1] = sortArr[j];
				sortArr[j] = tmpVar;
			}
		}
	}
	return sortArr;
}
function getRoadByCur(arr, CurNode) {
	for (var i = 0; i < arr.length; i++) {
		if (arr[i].indexOf(CurNode, 0) == -1) {
			arr[i] = "";
		}
	}
	arr = trimArray(arr, "");
	return arr;
}
function showDealedMan() {
	return;
}
// flowRecycle 增加函数showSubFlow
function showSubFlow() {
	var doc = document.all;
	if (doc.F_HasSubFlow && doc.F_HasSubFlow.value != "") {
		var subFlow = doc.F_HasSubFlow.value;
		var subFlowArr = subFlow.split(";");
		var subFlowHTMLArr = new Array;
		for (var i = 0; i < subFlowArr.length; i++) {
			var subFlowStr = trim(subFlowArr[i]);
			var j = subFlowStr.indexOf("|");
			if (j != -1)
				subFlowHTMLArr
						.push("<a style=\"color:#FF0000\" href=\"javascript:location='FM_ReviewSubFlow?OpenForm&ParentUNID="
								+ subFlowStr.substr(j + 1)
								+ "'\">"
								+ subFlowStr.substring(0, j) + "</a>");
		}
		if (doc.subFlowSpan && subFlowHTMLArr.length > 0)
			doc.subFlowSpan.innerHTML = subFlowHTMLArr.join(" ; ");
	} else
		return;
}
function fullTrim(str) {
	var len = str.length;
	if (!len)
		return "";
	var wSpace = new Array(" ", "\n", "\t", "\r");
	var w;
	for (var i = 0; i < len; i++) {
		for (w = 0; w < wSpace.length; w++)
			if (str.charAt(i) == wSpace[w])
				break;
		if (w == wSpace.length)
			break;
	}
	if (i == (len - 1))
		return "";
	for (var j = len; j > 0; j--) {
		for (w = 0; w < wSpace.length; w++)
			if (str.charAt(j - 1) == wSpace[w])
				break;
		if (w == wSpace.length)
			break;
	}
	if (i > j)
		return "";
	return str.substring(i, j);
}
function onCondition(r, nodekey) {
	if (nodekey == 0 || nodekey == "start")
		nodekey = "0";
	if (nodekey == "end") {
		document.all.spanFuture.innerHTML = "流程结束";
		return;
	}
	var node = changeNodeKeyToNo(nodekey);
	showNextNodeInfo(node);
}
function changeNodeKeyToNo(nokey) {
	if (nokey.toLowerCase() == "start" || nokey.toLowerCase() == "0")
		return "0";
	var rows = document.all.F_ReviewAmount.value;
	for (var i = 0; i <= parseInt(rows); i++) {
		if (eval("document.all.F_NodeKey_" + i).value == nokey)
			return i.toString();
	}
	return "";
}
function getCheck(tag) {
	var doc = document.all;
	var tagC = eval("doc." + tag);
	if (tagC.length == null)
		return tagC.checked;
	else {
		for (var i = 0; i < tagC.length; i++)
			if (tagC[i].checked)
				break;
		if (i == tagC.length)
			return false;
		else
			return true;
	}
}
function chkCondition() {
	with (document.forms[0]) {
		var curedit = F_FlowNthReviewer.value.split(";");
		var i = F_ReviewNo.value;
		var reviewtype = eval("F_ReviewType_" + i).value.substring(1);
		var reviewers = eval("F_Reviewer_" + i).value.split(";");
		var curEditor = F_Editor.value;
		var cutIndex = 0;
		for (var j = 0; j < reviewers.length; j++) {
			if (trim(curEditor.toLowerCase()) == trim(reviewers[j]
					.toLowerCase())) {
				cutIndex = j + 1;
				break;
			}
		}
		if (document.all.tdResult != null
				&& (reviewtype != "0"
						|| (reviewtype == "0" && curedit.length == F_CurSerial.value) || (reviewtype == "0" && cutIndex == reviewers.length))) {
			if (document.all.spanCondition.style.display == "none")
				return true;
			cond = trim(eval("F_JumpCondition_" + i).value);
			if (cond == "")
				return true;
			if (FlowChart_Line_GetValue(cond, "jumpType") == "1")
				return true;
			if (FlowChart_Line_GetValue(cond, "jumpType") == "2")
				return true;
			if (!getCheck("JumpNode_" + i)) {
				alert("流程分支决策：请选择跳转条件以确定流程走向。");
				return false;
			}
			var i = F_ReviewNo.value;
			for (var j = 0; j < eval("JumpNode_" + i).length; j++) {
				if (eval("JumpNode_" + i)[j].checked) {
					var jumpNodekey = eval("JumpNode_" + i)[j].value;
					F_ConJumpNode.value = jumpNodekey.toLowerCase() == "end"
							? "end"
							: changeNodeKeyToNo(jumpNodekey);// eval("JumpNode_"
																// +
																// i)[j].value;
					F_ConditionTitle.value = eval("JumpNode_" + i)[j].nextSibling.nodeValue;
				}
			}
		}
	}
	return true;
}
function FlowChart_Line_GetValue(strIn, varName) {
	try {
		var rtn = "";
		var str = strIn;
		var tmpName = "&" + varName + "=";
		if (str.indexOf(tmpName) == -1)
			return rtn;
		var tmp = str.substring(str.indexOf(tmpName) + 2 + varName.length,
				str.length);
		if (tmp == "")
			return tmp;
		if (tmp.indexOf("&") == -1) {
			rtn = tmp;
		} else {
			rtn = tmp.substring(0, tmp.indexOf("&"));
		}
		rtn = rtn.replace(/%3D/ig, "&");
		return rtn;
	} catch (e) {
	}
}
function resizeIframePress() {
	if (document.body.scrollHeight == "") {
		setTimeout("resizeIframe();", 500);
		return;
	}
	var ifFlow = parent.document.all;
	for (var i = 0; i < ifFlow.length; i++) {
		if (ifFlow[i].tagName == "IFRAME" && ifFlow[i].src != null
				&& ifFlow[i].id != "if_subform") {
			var x = ifFlow[i].src.toLowerCase();
			var y = location.href.toLowerCase();
			x = x.indexOf(".nsf");
			y = y.indexOf(".nsf");
			if (x * y > 0) {
				if (document.body.scrollHeight > 300)
					var str = "parent.document.all." + ifFlow[i].id
							+ ".height = 300;"
				setTimeout("executeJs('" + str + "','parent.document.all."
								+ ifFlow[i].id + "')", 100);
				if (eval("parent.document.all." + ifFlow[i].id + ".width < 520"))
					eval("parent.document.all." + ifFlow[i].id + ".width = 520");
			}
		}
	}
}
function submitCustomForm(thisFormButtonName) {
	var f1 = parent.if_subform;
	if (f1 != null) {
		if (f1.location.href.toLowerCase().indexOf("?opendocument") != -1)
			f1 = null;
	};
	if (f1 == null) {
		eval("document.forms[0]." + thisFormButtonName).click();
	} else {
		var f = parent.if_subform.document.forms[0];
		var CustomButtonName = "";
		var agreeCF = "";
		var disAgreeCF = "";
		var abandonCF = "";
		agreeCF = document.forms[0].F_AgreeCF.value;
		disAgreeCF = document.forms[0].F_DisAgreeCF.value;
		abandonCF = document.forms[0].F_AbandonCF.value;
		tf = document.forms[0];
		f.F_ReturnDo.value = "parent.ifFlow.document.forms[0]."
				+ thisFormButtonName + ".click();";
		if (thisFormButtonName == "buRetract_in") {
			if(abandonCF != "")
			CustomButtonName = abandonCF.substring(abandonCF.indexOf("|") + 1,
					abandonCF.length);
			else{
				eval("document.forms[0]." + thisFormButtonName).click();
				return;
			}
		}
		f.F_ClickEvent.value = "buSubmit_in.click();";
		if (thisFormButtonName == "buSubmit_in") {
			for (var k = 0; k < tf.F_Result.length; k++) {
				if (tf.F_Result[k].checked) {
					if (tf.F_Result[k].value == "驳回") {
						CustomButtonName = disAgreeCF.substring(disAgreeCF
										.indexOf("|")
										+ 1, disAgreeCF.length);
						f.F_Temp.value = "驳回";
					}
					if (tf.F_Result[k].value == "通过") {
						CustomButtonName = agreeCF.substring(agreeCF
										.indexOf("|")
										+ 1, agreeCF.length);
						f.F_Temp.value = "通过";
					}
					if (tf.F_Result[k].value == "废弃") {
						CustomButtonName = abandonCF.substring(abandonCF
										.indexOf("|")
										+ 1, abandonCF.length);
						f.F_Temp.value = "废弃";
					}
					f.F_ClickEvent.value = "buSubmit_in.click();";
				}
			}
		}
		if (thisFormButtonName == "buSaSubmit_in") {
			for (var k = 0; k < tf.F_SaResult.length; k++) {
				if (tf.F_SaResult[k].checked) {
					if (tf.F_SaResult[k].value == "终审通过") {
						CustomButtonName = agreeCF.substring(agreeCF
										.indexOf("|")
										+ 1, agreeCF.length);
						f.F_Temp.value = "通过";
					}
					if (tf.F_SaResult[k].value == "直接废弃") {
						CustomButtonName = abandonCF.substring(abandonCF
										.indexOf("|")
										+ 1, abandonCF.length);
						f.F_Temp.value = "废弃";
					}
					f.F_ClickEvent.value = "buSaSubmit_in.click();";
				}
			}
		}
		if (CustomButtonName != "") {
			eval("f." + CustomButtonName).click();
		} else {
			f.sys_bu_savetwo.click();
		}
	}
}
function getDialogInfo() {
	var cPath = location.href.toLowerCase();
	var dPath = cPath.substring(0, cPath.indexOf(".nsf") + 4)
			+ "/FM_EditNodeReview?OpenForm";
	var pPath = this.parent.document.location.pathname.toLowerCase();
	pPath = pPath.substring(1, pPath.indexOf(".nsf") + 4);
	editDialogInfo[0] = dPath + "&class=review&module="
			+ pPath.replace(/\//g, "+");
	editDialogInfo[1] = "dialogWidth:550px;dialogHeight:420px;center:1;status:0;scroll:0;resizable:1;help:1";
	editDialogInfo[2] = "Review";
}
getDialogInfo();
function getTagObj(obj, tagName) {
	if (!obj)
		return null;
	var returnObj = obj.getElementsByTagName("SPAN");
	if (returnObj.length > 0) {
		for (var i = 0; i < returnObj.length; i++) {
			attu = eval("returnObj[i]." + tagName)
			if (attu)
				return returnObj[i];
		}

	}
	return null
}
function checkOptionsRight(rightStr, nextnode) {
	if (rightStr == '1')
		return true;
	if (!document.all.F_NodePropertyEditValue
			|| document.all.F_NodePropertyEditValue.value == '0'
			|| document.all.F_NodePropertyEditValue.value == '')
		return false;
	var arr = (document.all.F_NodePropertyEditValue.value).split("&");
	var iKey = eval("document.all.F_NodeKey_" + nextnode + ".value")
	if (searchArray(arr, iKey) == -1)
		return false;
	return true;
}
function checkSpecialNode(curOptionValue) {
	var arr = curOptionValue.split("&");
	checkArr = arr;
	var jumpnode=document.all.F_ConJumpNode.value;
	if(jumpnode!="" && jumpnode!="0")
	{
		var tempobj=eval("document.all.F_Reviewer_"+jumpnode)
		if(!checkSpecialValue(tempobj,jumpnode)) return false;
		nextnode = getNextNode(jumpnode);
		while((!isNaN(nextnode)) && nextnode!="" && nextnode!=document.all.F_ReviewNo.value)
		{
			tempobj=eval("document.all.F_Reviewer_"+nextnode)
			if(!checkSpecialValue(tempobj,nextnode)) return false;
			nextnode = getNextNode(nextnode);
		}
	}else{
		for (i = 0; i < arr.length; i++) {
			node = changeNodeKeyToNo(arr[i]);
			if (node == "")
				continue;
			var obj = eval("document.all.F_Reviewer_" + node);
			if(!checkSpecialValue(obj,node)) return false;
		}
	}
	return true;
}
function checkSpecialValue(obj,node)
{
	var subFlowObj = eval("document.all.F_SubFlowDef_" + node);
	if(subFlowObj && subFlowObj.value!="") return true;
	var tempObj=eval("document.all.F_NodeName_" + node);
	if(!tempObj) return true;
	name = tempObj.value;
	var flag = getOption(node, 9);
	if (obj && obj.value == '') {
		//20100823增加判断
		nodeKey=eval("document.all.F_NodeKey_" + node).value;
		if (window.checkArr && arrayIndexOf(checkArr, nodeKey) != -1) {
			if (flag != "1") {
				alert("请设置节点‘" + name + "’的处理人信息");
				return false;
			} else {
				if (confirm("节点‘" + name + "’的处理人为空,是否选择下一处理人?单击“确定”按钮返回系统添加处理人，单击“取消”按钮不添加处理人直接提交流程"))
					return false;
			}
		}
	}
	return true;
}