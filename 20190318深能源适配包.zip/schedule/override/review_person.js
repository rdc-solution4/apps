/*压缩类型：标准*/
S_HasStaffCenter=false;
S_DbUrl=parent.location.pathname;
S_DbUrl=S_DbUrl.substring(0,S_DbUrl.toLowerCase().indexOf(".nsf")+4);
if(S_DbUrl.charAt(0) != "/")
	S_DbUrl = "/" + S_DbUrl;
if(window.S_DbPath==null)
	S_DbPath = S_DbUrl.substring(0, S_DbUrl.lastIndexOf("/"));
if(window.S_SetupPath==null)
	S_SetupPath = S_DbPath.substring(0, S_DbPath.lastIndexOf("/"));
if(window.S_JsFileList==null)
	var S_JsFileList = new Array();
IncludeJsFile("common.js");

function AddressBook1(fieldType, fieldName, isMulSelect, selectType, canBeMove, strSep, rtnType)
{
	var path = S_SetupPath+"/sys/html/addressmain"+(isMulSelect?"mul":"sgl")+".htm";
	var style = "dialogWidth:850px; dialogHeight:450px; status:0;scroll:0; help:0; resizable:1";
	var typeArr = fieldType.split(':');
	var parameter = new Array;
	rtnType = rtnType?rtnType:false;
	parameter[0] = selectType?selectType:"UPGM";
	parameter[1] = canBeMove?canBeMove:false;
	parameter[2] = strSep?strSep:";";
	if (rtnType){
		for (var i=0; i<typeArr.length; i++){
			switch (typeArr[i]){
			case "name":
				parameter[3] = fieldName[i]?fieldName[i]:"";
				break;
			case "ad":
				parameter[4] = fieldName[i]?fieldName[i]:"";
				break;
			}
		}
	}else{
		var nameArr = fieldName.split(':');
		var fieldObj = new Array;
		for (var i=0; i<typeArr.length; i++){
			switch (typeArr[i]){
			case "name":
				fieldObj[0] = eval("parent.document.all."+nameArr[i]);
				parameter[3] = fieldObj[0].value;
				break;
			case "ad":
				fieldObj[1] = eval("parent.document.all."+nameArr[i]);
				parameter[4] = fieldObj[1].value;
				break;
			}
		}
	}
	window.showModalDialog(path, parameter, style);
  window._setReturnValue = function(rtnArr){
    debugger;
    if (rtnType){
		if(rtnArr==null)
			return null;
		var rtnVal = new Array;
		for (var i=0; i<typeArr.length; i++){
			switch (typeArr[i]){
			case "name":
				rtnVal[i] = rtnArr[0];
				break;
			case "ad":
				rtnVal[i] = rtnArr[1];
				break;
			}
		}
		return rtnVal;
	}else{
		if(rtnArr!=null)
			for (var i=0; i<rtnArr.length; i++)
				if (fieldObj[i])
					fieldObj[i].value = rtnArr[i];
	}
	window.refreshFlowchart();
  }
	
}

function IncludeJsFile(fileList, isCss)
{
	if(S_DbPath=="")
		return;
	fileList = fileList.split("|");
	var path = S_DbPath + (isCss?"/css/":"/js/");
	for(var i=0; i<fileList.length; i++)
	{
		fileList[i] = fileList[i].toLowerCase();
		if(searchArray(S_JsFileList, fileList[i])>-1)
			continue;
		S_JsFileList[S_JsFileList.length] = fileList[i];
		document.write("<script src="+path+fileList[i]+"></script>");
	}
}


function searchArray(arrSrc, strSearch)
{
	try{
		if(arrSrc.length != null)
			for(var i = 0; i < arrSrc.length; i++)
				if(arrSrc[i] == strSearch)
					return i;
		return -1;
	}catch(e){
		return -1;
	}
}
function viewPerson(userAD){
	try{
		var arr=GetUserInfo(userAD,"lkstype");
		if(arr[0]=="person"){
			openPerson(userAD);
		}else{
			var hasValue = false;
			if(arr[0]=="post"){
				var GroupMore=AddressGetGroupMore(userAD);
				if(GroupMore.indexOf(":")!=-1){
					arrtmp=GroupMore.split(":");
					if(arrtmp[0]!="" && arrtmp[1]!=""){
						var arrAD=arrtmp[0].split(";");
						var arrNm=arrtmp[1].split(";");						
						if(arrAD.length==arrNm.length){
							if(arrAD.length==1){
								openPerson(arrAD[0]);
								return true;
							}else{
								var num=28;
								var maxNum=0;
								for(var i=0;i<arrNm.length;i++){
									if(maxNum<getStringByteLength(arrNm[i]))maxNum=getStringByteLength(arrNm[i]);
								}
								var rm = new RightMenuObject(num+maxNum*6);
								for(var i=0;i<arrNm.length;i++){
									hasValue = true;
									rm.AddItem(arrNm[i], "openPerson","'"+arrAD[i]+"'");
								}						
							}
						}
					}
				}
			}
			if (hasValue){
				rm.Show();
			}else{		
 				if (arr[0]!="dep")
 			       {
     				  var rm1 = new RightMenuObject(120);  
     				  rm1.AddItem("（暂无人员信息）", "","");
     				  rm1.Show();
                   }
			}
		}
	}catch(err){
	}
}

function openPerson(userAD){
	var user=userAD.toLowerCase();
	user = user.replace(/\//ig, "@");
	window.open(S_SetupPath+"/koa/lks_staffcenter.nsf/VD_SearchByAD/"+encodeURI(trim(user))+"?OpenDocument","_Blank");
}

function trim(str)
{
	for(var i = 0 ; i<str.length && str.charAt(i)==" " ; i++ ) ;
	for(var j =str.length; j>0 && str.charAt(j-1)==" " ; j--) ;
	if(i>j) return ""; 
	return str.substring(i,j); 
}
function AddressGetGroupMore(userND)
{
	try{
		var info = "";
		var AddressXML = new ActiveXObject("MSXML.DOMDocument");
		AddressXML.async = false;
		if (userND!=""){
			AddressXML.load(S_SetupPath+"/sys/lks_sysconfig.nsf/AG_GetGroupInfo?OpenAgent&nd="+encodeURI(userND));		
			info = AddressXML.selectNodes("/ReturnMsg")[0].text;
		}
		return info;
	}catch(e){
	return "err";
	}
}
//获取节点所有处理人信息
function AddressGetGroupList(userNDList)
{
	try
	{
		var info = "";
		var rtninfo = "";
		var t = " title=\"人才中心链接\""; 
		var AddressXML = new ActiveXObject("MSXML.DOMDocument");
		AddressXML.async = false;
		var arrlist = userNDList.split(";");
		if(arrlist.length>0)
		{
			for(var i=0;i<arrlist.length;i++)
			{
				userND = arrlist[i];
				if (userND!="")
				{
					AddressXML.load(S_SetupPath+"/sys/lks_sysconfig.nsf/AG_GetReviewerInfo?OpenAgent&nd="+encodeURI(userND));
					rtninfo = AddressXML.selectNodes("/ReturnMsg")[0].text;
	            	rtninfo = "<a href=#" + t + " onClick=\'viewPerson(\"" + userND + "\");return false;\'>"+rtninfo+"</a>";
					info += rtninfo+";";
				}
			}			
		}
		return info;
	}catch(e){
		return "err";
	}
}

function getStringByteLength(str){
//功能：返回指定String的字节数，中文为2字节
//作者：Wulx 2006/06/02
	var rtnLength=0;
	for(var i=0;i<str.length;i++){
		if(Math.abs(str.charCodeAt(i))>200){
			rtnLength=rtnLength+2;				
		}else{
			rtnLength++;
		}
	}	
	return rtnLength;
}