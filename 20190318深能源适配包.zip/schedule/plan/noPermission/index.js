(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control196_C8iiPg: function (elem) {
      return '系统提示';
    },
    doAction_uiControl212_aglgT9: function (data, elem) {},
    getTemplate_uiControl212_aglgT9: function () {
      var selfTemplate = "import { back, closeWindow} from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    }
  }, "noPermission");
})(window, ysp);