RegisterJsFile("rtcommunion.js");
IncludeJsFile("co_st.js");
var InstallST = false;
var InstallRTX = false;
var rtx_winHasLoaded = false;
var rtx_winLoadTimeout = 0;
var USERIDARR = new Array();
var oRTComList = new Array();
var RTX_IDList = new Array();
function RTComShow() {
    ll_linksCount = 0;
    var oRTCom = document.all.divRTCom;
    if (oRTCom) {
        if (oRTCom.length) {
            for (var i = 0; i < oRTCom.length; i++) {
                RTComShowUser(oRTCom[i]);
                oRTComList[i] = oRTCom[i].UserAd;
            }
        } else {
            RTComShowUser(oRTCom);
        }
    }
    if (InstallST) {
        for (j = 0; j < USERIDARR.length; j++) {
            for (k = 0; k < oRTComList.length; k++) {
                if (oRTComList[k] == USERIDARR[j]) {
                    updateLinkStatus(USERIDARR[j], "32");
                    break;
                }
            }
        }
    }
}
function RTComShowUser(item) {
    item.innerHTML = "";
    if (InstallST) {
        try {
            item.innerHTML += prepareSametimeLink(item.UserAd, item.UserName, true, "icon:yes;text:no");
        } 
        catch (err) {}
    }
    item.innerHTML += item.UserName;
    if (InstallRTX) {
        item.innerHTML += showRTX(item);
    }
    item.onclick = function() {
        event.cancelBubble = true;
    }
}
function showRTX(itemRTCom) {
    var rtnHTML = "";
    var temp;
    if (RTX_IDList[itemRTCom.UserAd] == null ) {
        temp = GetUserInfo(itemRTCom.UserAd, "rtx:ShortName");
        if (temp[0] == "")
            RTX_IDList[itemRTCom.UserAd] = ""
        else
            RTX_IDList[itemRTCom.UserAd] = temp[1];
    }
    if (RTX_IDList[itemRTCom.UserAd] != "")
        rtnHTML = "<img align=absbottom showOffline width=16 height=16 src=" + S_DbPath + "/icons/blank.gif onload=\"rtx_RAP('" + RTX_IDList[itemRTCom.UserAd] + "');\">";
    return rtnHTML;
}
function rtx_RAP(nick) {
    RAP(nick);
    if (rtx_winLoadTimeout != 0) {
        clearTimeout(rtx_winLoadTimeout);
        rtx_winLoadTimeout = 0;
    }
    rtx_winLoadTimeout = setTimeout("rtx_winOnload();", 200);
}
function STStatusCheck(userID, StatusType) {
    if (StatusType == "32") {
        var hasId = false;
        for (i = 0; i < USERIDARR.length; i++) {
            hasId = true;
            break;
        }
        if (hasId || USERIDARR.length == 0)
            USERIDARR[USERIDARR.length] = userID;
    } else {
        for (i = 0; i < USERIDARR.length; i++) {
            if (userID == USERIDARR[i])
                USERIDARR.splice(i, 0);
        }
    }
}
