(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control3_QVtoU7: function (elem) {
      if (elem) {
        return "知识中心分类列表";
      }return;
    },
    doAction_uiControl4_rLiGel: function (data, elem) {},
    getTemplate_uiControl4_rLiGel: function () {
      var selfTemplate = "import { back, closeWindow} from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control4_W3BT1E: function (elem) {
      if (elem) {
        var data = [];var startIndex = $(elem).find("a[title='主目录']").closest("table").index();var increment = parseInt($(elem).find("a[title='主目录']").attr("lks_nodeid"));var _idPre = $(elem).find("a[title='主目录']").closest("table").attr("id").split("_")[0];var lastELe;if (!isNaN(increment)) {
          lastELe = $(elem).find("#" + _idPre + "_" + (1 + increment));
        }if (lastELe.length == 0) {
          lastELe = $(elem).find("a[title='查询方式']").closest("table");
        }var lastIndex = lastELe.index();$(elem).children("table").each(function (tbi, tb) {
          if (tbi > startIndex && tbi < lastIndex) {
            data.push({ id: $(this).attr("id"), text: $(this).find("a[title]").text() });
          }
        });return data;
      }return;
    },
    doAction_uiControl5_fbgrgt: function (data, elem) {
      var _data = data.customData;var type = data.eventType;switch (type) {case "itemClick":
          $(elem).find("#" + _data.id).find("a[title]").click();break;}
    },
    getTemplate_uiControl5_fbgrgt: function () {
      var selfTemplate = "module.exports = React.createClass({\n  itemClick:function(data){\n    var cb = this.props.customHandler;\n    if(cb){\n      if(data==\"\u6211\u53D1\u8D77\u7684\u6587\u6863\"){\n        cb({\n          eventType:\"expandNode\",\n          data:data\n        })\n      } else {\n        cb({\n          eventType:\"itemClick\",\n          data:data\n        })\n        ysp.appMain.showLoading();\n        setTimeout(function(){\n          cb({\n            eventType:\"section-trigger\",\n            data:'control5_mWn7Kk'\n          })\n          ysp.appMain.hideLoading();\n        },500)\n      }\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n    return (\n      <div className=\"usercenter-secondary-manu\">\n        {\n          data?data.map(function(item){\n            return <div className=\"usercenter-list-item\" onClick={(e)=>{\n                _this.itemClick(item);\n              }}>{item.text}<span className=\"amt-icon amt-icon-right\"></span></div>\n          }):\"\"\n        }\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  itemClick: function itemClick(data) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      if (data == \"\u6211\u53D1\u8D77\u7684\u6587\u6863\") {\n        cb({\n          eventType: \"expandNode\",\n          data: data\n        });\n      } else {\n        cb({\n          eventType: \"itemClick\",\n          data: data\n        });\n        ysp.appMain.showLoading();\n        setTimeout(function () {\n          cb({\n            eventType: \"section-trigger\",\n            data: 'control5_mWn7Kk'\n          });\n          ysp.appMain.hideLoading();\n        }, 500);\n      }\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"usercenter-secondary-manu\" },\n      data ? data.map(function (item) {\n        return React.createElement(\n          \"div\",\n          { className: \"usercenter-list-item\", onClick: function onClick(e) {\n              _this.itemClick(item);\n            } },\n          item.text,\n          React.createElement(\"span\", { className: \"amt-icon amt-icon-right\" })\n        );\n      }) : \"\"\n    );\n  }\n});";
    }
  }, "secondary_menu");
})(window, ysp);