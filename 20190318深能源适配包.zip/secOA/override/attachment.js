var Domino_Version = "R7";
var ISENCRYPT = false;
RegisterJsFile("attachment.js");
IncludeJsFile("rightmenu.js");
var AttachmentInfo = new Object();
AttachmentInfo.IsHandled = true;
var AttachmentObject = new Object();
AttachmentObject.Initialize = function() {
	this.checkAttid();
	this.Index = 0;
	this.IsEdited = !(document.all.F_AttachmentList == null);
	this.DetachFile = (document.all.SysF_TmpDetachFile.value == ""
			? new Array
			: document.all.SysF_TmpDetachFile.value.split("|"));
	this.UploadFile = new Array;
	this.FileList = new Array;
	this.Attach = new Array;
	if (window.getNotesIniValue)
		this.IOEncoding = getNotesIniValue("IOEncoding");
	else if (window.m_RunLSFunction)
		this.IOEncoding = m_RunLSFunction("sys_getinivalue", "IOEncoding");
	if (window.S_FileLimited && S_FileLimited != '')
		this.fileLimited = S_FileLimited;
	else
		this.fileLimited = getNotesIniValue("AttachSizeLimit")
	var attachHtml = "";
	var i, j, index, tmpArr, fileArr;
	if (document.all.SysF_TmpUploadFile.value != "") {
		fileArr = document.all.SysF_TmpUploadFile.value.split("/");
		for (i = 0; i < fileArr.length; i++) {
			index = fileArr[i].indexOf("|");
			this.UploadFile[parseInt(fileArr[i].substring(0, index))] = fileArr[i]
					.substring(index + 1).split("|");
		}
	}
	if (this.AttachmentList != "" || this.Attachments.length > 0) {
		if (this.AttachmentList != "")
			tmpArr = this.AttachmentList.split(":");
		else
			tmpArr = new Array();
		fileArr = new Array();
		for (i = 0; i < tmpArr.length; i++) {
			for (j = 0; j < fileArr.length; j++)
				if (tmpArr[i].toLowerCase() == fileArr[j].toLowerCase())
					break;
			if (j == fileArr.length)
				fileArr[j] = tmpArr[i];
		}
		for (i = 0; i < this.Attachments.length; i++) {
			if (this.Attachments[i] != "") {
				attachHtml += "<input id=oattach  style='display:none' type='checkbox' name='%%Detach\' value='"
						+ this.Attachments[i] + "'>";
				for (j = 0; j < fileArr.length; j++) {
					if (fileArr[j].substring(fileArr[j].indexOf("|") + 1)
							.toLowerCase() == this.Attachments[i].toLowerCase()) {
						break;
					}
				}
				if (j == fileArr.length)
					fileArr[fileArr.length] = "-1|" + this.Attachments[i];
			}
		}
		for (i = 0; i < fileArr.length; i++) {
			tmpArr = fileArr[i].split("|");
			if (this.CheckFiles(tmpArr[1], this.Attachments)
					&& !this.CheckFiles(tmpArr[1], this.DetachFile)) {
				index = parseInt(tmpArr[0]);
				if (this.FileList[index] == null)
					this.FileList[index] = new Array;
				this.FileList[index][this.FileList[index].length] = tmpArr[1];
			}
		}
	}
	var path = location.pathname.toLowerCase();
	path = (path.substring(0, 1) == "/" ? "" : "/")
			+ path.substring(0, path.indexOf(".nsf"));
	this.DbName = path + ".nsf";
	path = path.substring(0, path.lastIndexOf("/"));
	this.DbPath = path + "/";
	var htmlCode = "<OBJECT classid='clsid:764BFF15-D431-4640-961C-1B98F94F2383'";
//	htmlCode += " codebase=\"" + path + "/lksframer10217.cab#version=1,0,2,17\"";
	htmlCode += " codebase=\"" + path + "/lksframer1029.cab#version=1,0,2,9\"";
	htmlCode += " id=AttachmentOCX";
	htmlCode += " style='display:none'>";
	htmlCode += "<PARAM name='Server' value='" + location.hostname + "'>";
	if (this.Isencrypt != 0 && this.Isencrypt != false) {
		if (ISENCRYPT
				|| (this.Isencrypt != null & (this.Isencrypt == 1
						|| this.Isencrypt == true || this.Isencrypt == "true"))) {
			this.isencrypt = true;
		}
	}
	if (!AttachmentObject.getexEncry())
		this.isencrypt = false;
	if (this.isencrypt)
		htmlCode += "<PARAM name='encrypt' value='1'>";
	if (location.protocol.toLowerCase().indexOf("https:") == 0) {
		htmlCode += "<PARAM name='security' value='1'>";
		htmlCode += "<PARAM name='Port' value='"
				+ (location.port == "" ? 443 : location.port) + "'>";
	} else {
		htmlCode += "<PARAM name='Port' value='"
				+ (location.port == "" ? 80 : location.port) + "'>";
	}
	path = path.substring(0, path.lastIndexOf("/"))
			+ "/sys/lks_public.nsf/fm_upload?openform";
	htmlCode += "<PARAM name='ReceiveForm' value='" + path + "'>";
	if(Domino_Version=="R8"){
		FileInputNameValue = "%%File.48257de4000b8a28.01d05a1c82f863ca48256d8300151059.$Body.0.114";
	}  
	if (Domino_Version == "R7") {
		FileInputNameValue = "%%File.482571d10039805b.01d05a1c82f863ca48256d8300151059.$Body.0.114";
	} else if (Domino_Version == "R6") {
		FileInputNameValue = "%%File.48256dfa0022064b.01d05a1c82f863ca48256d8300151059.$Body.0.114";
	} else if (Domino_Version == "R5") {
		FileInputNameValue = "%%File01d05a1c82f863ca48256d8300151059.$Body.0.10C";
	}
	htmlCode += "<PARAM name='FileInputName' value='" + FileInputNameValue
			+ "'>";
	if (this.OrgID)
		htmlCode += "<PARAM name='OrgId' value='" + this.OrgID + "'>";
	if (this.DocID)
		htmlCode += "<PARAM name='DocId' value='" + this.DocID + "'>";
	if (this.fileLimited)
		htmlCode += "<PARAM name='FileLimits' value='" + this.fileLimited
				+ "'>";
	if (this.IOEncoding != null && this.IOEncoding != "")
		htmlCode += "<PARAM name='Encoding' value='" + this.IOEncoding + "'>";
	htmlCode += "</OBJECT>";
	document.write(htmlCode + attachHtml);
}
//是否处于或者需要启用附件拆分
AttachmentObject.NeedFJCF = false;
//附件拆分库路径
AttachmentObject.FJCF_DBPath = "";
//附件拆文档UNID
AttachmentObject.FJCF_DocUNID = "";
AttachmentObject.Create = function(index, isSingle, fileType, isEdited,
		IsDownLoad) {
	if (index == null) {
		this.Index++;
		index = this.Index;
	}
	if (this.Attach[index] == null)
		this.Attach[index] = new Object();
	this.Attach[index].IsSingle = (isSingle ? true : false);
	this.Attach[index].FileType = (fileType ? fileType : "所有文件|*.*");
	this.Attach[index].IsEdited = ((isEdited == null)
			? this.IsEdited
			: isEdited);
	this.Attach[index].IsDownLoad = ((IsDownLoad == null) ? false : IsDownLoad);
	this.Index = (this.Index > index ? this.Index : index);
	document.write("<div id=AttachmentDiv" + index + ">");
	document.write(this.DrawAttachment(index));
	document.write("</div>");
}
AttachmentObject.DrawAttachment = function(index) {
	var i, j, htmlCode = "", fileurl;
	if (this.FileList[index]) {
		for (i = 0; i < this.FileList[index].length; i++) {
			//表示是定时任务发起的流程
			if((typeof S_IsNewDoc != "undefined" && S_IsNewDoc)
				&& (typeof S_F_TaskDocUNID != "undefined" && S_F_TaskDocUNID!="")
				&& (typeof S_F_AttsDocPath != "undefined" && S_F_AttsDocPath!="")){
					fileurl = S_F_AttsDocPath + "/$file/"+ this.FileList[index][i];	
			}else {
				fileurl = this.DbName + "/0/" + this.DocID + "/$file/"
					+ this.FileList[index][i];
			}
			//附件拆分
			if(AttachmentObject.NeedFJCF==true){
				fileurl = this.FJCF_DBPath + "/0/" + this.FJCF_DocUNID + "/$file/"
					+ this.FileList[index][i];
			}
			if (this.Attach[index].GetHTML) {
				if (this.Attach[index].IsEdited
						|| this.Attach[index].IsDownLoad)
					htmlCode += this.Attach[index].GetHTML(fileurl,
							this.isencrypt,
							"<input type=checkbox id=AttachmentCheck" + index
									+ " IsUpload=1 Index=" + i + ">", false);
				else
					htmlCode += this.Attach[index].GetHTML(fileurl,
							this.isencrypt, null, false);
			} else {
				if (window.isAttEdit == null)
					isAttEdit = false;
				if (window.isAttDownload == null)
					isAttDownload = true;
				if (this.Attach[index].IsEdited
						|| this.Attach[index].IsDownLoad)
					htmlCode += ButtonHTML(fileurl, this.isencrypt,
							"<input type=checkbox id=AttachmentCheck" + index
									+ " IsUpload=1 Index=" + i + ">", false);
				else
					htmlCode += ButtonHTML(fileurl, this.isencrypt, null, false);
			}
		}
	}
	if (this.UploadFile[index]) {
		for (i = 0; i < this.UploadFile[index].length; i++) {
      var paseFileName = this.UploadFile[index][i].replace(/\\/g,"/");
			if (this.Attach[index].IsEdited)
				htmlCode += "<input type=checkbox id=AttachmentCheck" + index
						+ " IsUpload=0 Index=" + i + ">";
			htmlCode += "<a target='_blank' href='file:///" + paseFileName
					+ "'><img src=/icons/vwicn005.gif border=0>";
			j = this.UploadFile[index][i].lastIndexOf("\\");
			htmlCode += (j > -1
					? this.UploadFile[index][i].substring(j + 1)
					: this.UploadFile[index][i])
					+ "</a></br>";
		}
	}
	if (htmlCode == "")
		htmlCode = "暂无附件！";
	if (this.Attach[index].IsEdited) {
		var btnCode = "<input type=button value=增加 onclick=AttachmentObject.Add("
				+ index
				+ ") class=btndoc onMouseOver=this.className='btndocmouseover' onMouseOut=this.className='btndoc'>&nbsp;&nbsp;";
		if (this.FileList[index] != null || this.UploadFile[index] != null) {
			btnCode += "<input type=button value=删除 onclick=AttachmentObject.Delete("
					+ index
					+ ") class=btndoc onMouseOver=this.className='btndocmouseover' onMouseOut=this.className='btndoc'>&nbsp;&nbsp;";
			btnCode += "<input type=button value=全选 onclick=AttachmentObject.SelectAll("
					+ index
					+ ") class=btndoc onMouseOver=this.className='btndocmouseover' onMouseOut=this.className='btndoc'>";
		}
		btnCode += "<font style='font-size:5px'><br><br></font>";
		htmlCode = btnCode + htmlCode;
	} else if (this.Attach[index].IsDownLoad) {
		if (this.FileList[index] != null || this.UploadFile[index] != null)
			btnCode = "<input type=button value=下载 onclick=AttachmentObject.downLoad("
					+ index + ") class=upload>";
		btnCode += "<font style='font-size:5px'><br><br></font>";
		htmlCode = btnCode + htmlCode;
	}
	return htmlCode;
}
AttachmentObject.CheckFileName = function(str) {
	var lib = "^&*%$@!…',\~/";
	for (var i = 0; i < lib.length; i++) {
		if (str.indexOf(lib.charAt(i)) != -1) {
			alert("控件不支持含有字符" + lib.charAt(i) + "的文件名！");
			return false;
		}
	}
	return true;
}
AttachmentObject.Add = function(index,file) {
	if (AttachmentObject.OnQueryAdd)
		if (!AttachmentObject.OnQueryAdd(index))
			return;
	// var fileName = document.all.AttachmentOCX
	// 		.SelectFiles(
	// 				!this.Attach[index].IsSingle,
	// 				"All Files (*.*)|*.*|Office Files|*.doc;*.docx;*.xls;*.xlsx;*.ppt;*.pptx;*.vsd;*.rtf;*.csv");
  var fileName = file;
	if (fileName == null || fileName == "")
		return;
	fileName = fileName.split(";");
	var str;
	for (var i = 0; i < fileName.length; i++) {
		str = fileName[i].substring(fileName[i].lastIndexOf("\\") + 1,
				fileName[i].length);
		if (!AttachmentObject.CheckFileName(str))
			return false;
		if (this.CheckFiles(fileName[i], this.FileList)
				|| this.CheckFiles(fileName[i], this.UploadFile)) {
			if (confirm("不能上传重名的文件：" + fileName[i]
					+ "\n点击“确定”忽略选定该文件，点击“取消”忽略本次操作。")) {
				fileName[i] = "";
				return;
			} else
				return;
		}
		if (this.fileLimited != 0 || this.fileLimited == null) {
			var x, j, filename;
			// document.all.AttachmentOCX.checkAddFile("", "");
			for (x = 0; x < this.UploadFile.length; x++)
				if (this.UploadFile[x] != null)
					for (j = 0; j < this.UploadFile[x].length; j++) {
						filename = this.UploadFile[x][j];
						// if (!document.all.AttachmentOCX.checkAddFile(fileName,
						// 		"add")) {
						// 	document.all.AttachmentOCX.checkAddFile("", "del")
						// 	alert("文件大小计算错误，请重新添加附件！");
						// 	return false;
						// }
					}
			for (var y = 0; y <= i; y++) {
				if ("" != fileName[y]) {
					// if (!document.all.AttachmentOCX.checkAddFile(fileName[y],
					// 		"add")) {
					// 	document.all.AttachmentOCX.checkAddFile("", "del");
					// 	alert("文件“" + fileName[y] + "”\n将会使新增文件总大小超过系统配置大小"
					// 			+ this.fileLimited + "M，不能添加。");
					// 	return false
					// }
				}
			}
		}
	}
	for (var i = 0; i < fileName.length; i++)
		if (fileName[i] != "") {
			if (this.UploadFile[index] == null)
				this.UploadFile[index] = new Array(fileName[i]);
			else
				this.UploadFile[index][this.UploadFile[index].length] = fileName[i];
		}
	this.Refresh(index);
	if (AttachmentObject.OnPostAdd)
		AttachmentObject.OnPostAdd(index, fileName);
}
AttachmentObject.Delete = function(index,anchor) {
  debugger;
	var found = false;
	var obj = eval("document.all.AttachmentCheck" + index);
  var _obj = obj[anchor]?obj[anchor]:obj;
	// if (obj.length) {
	// 	for (var i = 0; i < obj.length; i++)
	// 		if (obj[i].checked)
	// 			found = true;
	// } else {
	// 	if (obj.checked)
	// 		found = true;
	// }
	// if (!found) {
	// 	alert("请选择需要删除的附件");
	// 	return;
	// }
	if (AttachmentObject.OnQueryDelete)
		if (!AttachmentObject.OnQueryDelete(index))
			return;
  this.DeleteOne(_obj, index);
	// if (obj.length)
	// 	for (var i = 0; i < obj.length; i++)
	// 		this.DeleteOne(obj[i], index);
	// else
	// 	this.DeleteOne(obj, index);
	this.Refresh(index);
	if (AttachmentObject.OnPostDelete)
		AttachmentObject.OnPostDelete(index);
}
AttachmentObject.SelectAll = function(index) {
	var obj = eval("document.all.AttachmentCheck" + index);
	var checked = (event.srcElement.value == "全选");
	if (obj.length) {
		for (var i = 0; i < obj.length; i++)
			obj[i].checked = checked;
	} else {
		obj.checked = checked;
	}
	event.srcElement.value = checked ? "不选" : "全选";
}
AttachmentObject.downLoad = function(index) {
	var found = false;
	var obj = eval("document.all.AttachmentCheck" + index);
	var urlPath = location.href;
	var ii = urlPath.toLowerCase().indexOf(this.DocID.toLowerCase()) + 32;
	urlPath = urlPath.substring(0, ii) + "/$file/";
	//附件拆分
	if(AttachmentObject.NeedFJCF==true){
		urlPath = this.FJCF_DBPath + "/0/" + this.FJCF_DocUNID + "/$file/";
	}
	var selectFile = "";
	if (obj.length) {
		for (var i = 0; i < obj.length; i++) {
			if (obj[i].checked) {
				selectFile += (selectFile == "" ? "" : ";") + urlPath
						+ encodeURI(this.FileList[index][i]) + "|"
						+ this.FileList[index][i];
			}
		}
	} else {
		if (obj.checked)
			selectFile += (selectFile == "" ? "" : ";") + urlPath
					+ encodeURI(this.FileList[index][0]) + "|"
					+ this.FileList[index][0];
	}
	if (selectFile == "") {
		alert("请选择需要下载的附件");
		return;
	}
	with (document.all.AttachmentOCX) {
		var retV = false;
		if (selectFile.indexOf(";") > 0) {
			downLoadFiles(selectFile, "");
			retV = true;
		} else {
			var i = selectFile.lastIndexOf("|");
			retV = SaveAsEx(selectFile.substring(0, i), "1", selectFile
							.substring(i + 1), "1");
		}
		if (retV)
			alert("您所选择的文件已经下载完成！");
	}
}
AttachmentObject.DeleteOne = function(obj, index) {
	i = parseInt(obj.getAttribute("Index"));
  var IsUpload = obj.getAttribute("IsUpload");
	if (IsUpload == "1") {
		this.DetachFile[this.DetachFile.length] = this.FileList[index][i];
		if (document.all.oattach) {
			if (document.all.oattach[0]) {
				for (var j = 0; j < document.all.oattach.length; j++) {
					if (document.all.oattach[j].value == this.FileList[index][i]) {
						document.all.oattach[j].checked = true;
						break;
					}
				}
			} else {
				if (document.all.oattach.value == this.FileList[index][i])
					document.all.oattach.checked = true;
			}
		}
		this.FileList[index][i] = "";
	} else {
		this.UploadFile[index][i] = "";
	}
}
AttachmentObject.Refresh = function(index) {
	var i, j, tmpArr;
	if (this.UploadFile[index] != null) {
		tmpArr = new Array;
		for (i = 0; i < this.UploadFile[index].length; i++)
			if (this.UploadFile[index][i] != "")
				tmpArr[tmpArr.length] = this.UploadFile[index][i];
		this.UploadFile[index] = tmpArr.length == 0 ? null : tmpArr;
	}
	if (this.FileList[index] != null) {
		tmpArr = new Array;
		for (i = 0; i < this.FileList[index].length; i++)
			if (this.FileList[index][i] != "")
				tmpArr[tmpArr.length] = this.FileList[index][i];
		this.FileList[index] = tmpArr.length == 0 ? null : tmpArr;
	}
	tmpArr = new Array;
	for (i = 0; i < this.UploadFile.length; i++)
		if (this.UploadFile[i] != null)
			tmpArr[tmpArr.length] = i + "|" + this.UploadFile[i].join("|");
	document.all.SysF_TmpUploadFile.value = tmpArr.join("/");
	document.all.SysF_TmpDetachFile.value = this.DetachFile.join("|");
	eval("document.all.AttachmentDiv" + index).innerHTML = this
			.DrawAttachment(index);
	if (window.onAttachmentChanged != null)
		onAttachmentChanged(index);
}

AttachmentObject.Upload = function() {
	var i, j, t, filename;
	var tmpArr1 = new Array, tmpArr2 = new Array;
	for (i = 0; i < this.UploadFile.length; i++)
		if (this.UploadFile[i] != null)
			for (j = 0; j < this.UploadFile[i].length; j++) {
				filename = this.UploadFile[i][j];
				tmpArr1[tmpArr1.length] = filename;
				t = filename.lastIndexOf("\\");
				if (t > -1)
					filename = filename.substring(t + 1);
				tmpArr2[tmpArr2.length] = i.toString() + "|" + filename;
			}
	if (!tmpArr1.length && !this.DetachFile.length) {
		return 1;
	} else {
			// PostInit();
			// PostAddField("F_UploadList", tmpArr2.join("\n"));
			// PostAddField("F_DetachList", this.DetachFile.join("\n"));
			// for (i = 0; i < tmpArr1.length; i++)
			// 	PostAddFile(tmpArr1[i], "");
			if (true || PostSend()) {
				document.all.SysF_TmpUploadFile.value = "";
				document.all.SysF_TmpDetachFile.value = "";
				return 2;
			} else
				return 0;
	}
}

AttachmentObject.CheckFiles = function(fileName, fileList) {
	var i;
	if (typeof(fileList) == "object") {
		for (i = 0; i < fileList.length; i++) {
			if (fileList[i] == null)
				continue;
			if (this.CheckFiles(fileName, fileList[i]))
				return true;
		}
	} else {
		fileName = fileName.toLowerCase();
		i = fileName.lastIndexOf("\\");
		if (i > -1)
			fileName = fileName.substring(i + 1);
		fileList = fileList.toLowerCase();
		i = fileList.lastIndexOf("\\");
		if (i > -1)
			fileList = fileList.substring(i + 1);
		if(AttachmentObject.AttachmentsListReplace && (AttachmentObject.AttachmentsListReplace).indexOf(fileName)!=-1)
		fileName=repAttNameSpecial(fileName);
		return (fileName == fileList);
	}
	return false;
}
AttachmentObject.GetFileList = function(index) {
	var rtnList = new Array;
	var i;
	if (this.FileList[index])
		for (i = 0; i < this.FileList[index].length; i++)
			rtnList[rtnList.length] = this.FileList[index][i];
	if (this.UploadFile[index])
		for (i = 0; i < this.UploadFile[index].length; i++)
			rtnList[rtnList.length] = this.UploadFile[index][i];
	return rtnList;
}
AttachmentObject.openDoc = function(attUrl) {
	if (this.isencrypt) {
		if (attUrl.indexOf("://") < 0)
			attUrl = "http://" + location.hostname + attUrl
		var strFname = document.all.AttachmentOCX.GetUniqueFileName();
		strFname = strFname.substring(0, strFname.lastIndexOf("."))
				+ attUrl.substring(attUrl.lastIndexOf("."))
		if (document.all.AttachmentOCX.SaveAs(attUrl, "", strFname, "")) {
			document.all.AttachmentOCX.ExecuteFile(strFname);
		}
	} else {
		open(attUrl, "_blank", "");
	}
}
AttachmentObject.checkAttid = function() {
	var theUrl = location.href.toLowerCase();
	var i = theUrl.indexOf("?open");
	if (i == -1)
		i = theUrl.indexOf("?edit");
	if (i > 0) {
		theUrl = theUrl.substring(0, i);
		i = theUrl.lastIndexOf("/");
		var docid = theUrl.substring(i + 1).toUpperCase();
		if (docid.length == 32) {
			theUrl = theUrl.substring(0, i);
			if (theUrl.substring(theUrl.length - 4) != ".nsf") {
				if (docid != this.DocID.toUpperCase()) {
					this.OrgID = this.DocID;
					this.DocID = docid;
				}
			}
		}
	}
}
AttachmentObject.getExcelHtml = function(fileName) {
	if (fileName == null)
		fileName = "";
	with (document.all.AttachmentOCX) {
		return getExcelHtml(fileName);
	}
}
AttachmentObject.getexEncry = function() {
	var strURL = location.href.toLowerCase();
	var ret = true;
	if (strURL.indexOf("lks_archivemng") > 0
			&& strURL.indexOf("/vd_class/") > 0)
		ret = false;
	else if (strURL.indexOf("lks_archivemng") > 0
			&& document.title.indexOf("_新建类别") > 0)
		ret = false;
	else if (strURL.indexOf("lks_filemng") > 0
			&& strURL.indexOf("/vd_displayclass/") > 0)
		ret = false;
	else if (strURL.indexOf("lks_filemng") > 0
			&& strURL.indexOf("fm_class") > 0)
		ret = false;
	else if (strURL.indexOf("lks_flow") > 0)
		ret = false;
	else if (strURL.indexOf("lks_news") > 0)
		ret = false;
	return ret;
}
function ButtonHTML(path, isencrypt, EditCode) {
	var htmlCode = "";
	if(chkAttNameHasSpecial(path))var url = getDbUrl("/", true) + encodeURI(repAttNameSpecial(path));
        else var url = getDbUrl("/", true) + encodeURI(path);
	var filename = path.substring(path.lastIndexOf("/") + 1);
	var ext = url.substring(url.lastIndexOf(".")).toLowerCase();
	if (EditCode != null)
		htmlCode = EditCode;
	if (window.S_IsEdited)
		isAttDownload = true;
	if (ext == ".doc" || ext == ".xls" || ext == ".mpp" || ext == ".ppt"
			|| ext == ".xlc" || ext == ".docx" || ext == ".xlsx"
			|| ext == ".pptx" || ext == ".ppsx") {
		htmlCode += "<a href=\"\" onClick=\"showAttMenu('" + url
				+ "',false,true,isAttEdit,isAttDownload"
				+ (isencrypt == null ? "" : "," + isencrypt)
				+ ");return false;\"";
		htmlCode += " onContextMenu=\"showAttMenu('" + url
				+ "',false,true,isAttEdit,isAttDownload"
				+ (isencrypt == null ? "" : "," + isencrypt)
				+ ");return false;\">";
		htmlCode += "<img src=/icons/vwicn021.gif border=0> " + filename
				+ "</a>";
	} else {
		htmlCode += "<a href=\"\" onClick=\"showAttMenu('" + url
				+ "',true,false,false,isAttDownload"
				+ (isencrypt == null ? "" : "," + isencrypt)
				+ ");return false;\"";
		htmlCode += " onContextMenu=\"showAttMenu('" + url
				+ "',true,false,false,isAttDownload"
				+ (isencrypt == null ? "" : "," + isencrypt)
				+ ");return false;\">"
		htmlCode += "<img src=/icons/vwicn005.gif border=0> " + filename
				+ "</a>";
	}
	return htmlCode + "<br>";
}
function showAttMenu(atturl, isopen, isread, isedit, isdownload, isencrypt) {
  
  //适配替换，附件预览
  if (ysp.appMain.isIOS()) {
    atturl = encodeURI(decodeURI(atturl));
    if(/.\pdf$/.test(atturl)){
       ysp.appMain.openWindow(atturl + '?_ysp_forcepc=1'); 
    }else {
      ysp.appMain.openWindow(atturl + '?_ysp_filepreview=1');
    }
  } else {
    ysp.appMain.openWindow(atturl);
  }
	// var rm = new RightMenuObject();
	// if (isopen == true)
	// 	rm.AddItem("打开", "openAttachment", "'" + atturl + "',1"
	// 					+ (isencrypt == null ? "" : "," + isencrypt));
	// if (isread == true)
	// 	rm.AddItem("阅读", "openAttachment", "'" + atturl + "',2"
	// 					+ (isencrypt == null ? "" : "," + isencrypt));
	// if (isedit == true)
	// 	rm.AddItem("编辑", "openAttachment", "'" + atturl + "',3"
	// 					+ (isencrypt == null ? "" : "," + isencrypt));
	// if (isdownload == true)
	// 	rm.AddItem("下载", "openAttachment", "'" + atturl + "',4"
	// 					+ (isencrypt == null ? "" : "," + isencrypt));
	// rm.Show();
}
function openAttachment(attUrl, optNum, isencrypt) {

	var srcAttUrl=attUrl;
	var re = new RegExp("\\#", "g");
	var dbpath;
	dbpath = location.href;
	dbpath = dbpath.substr(0,dbpath.indexOf(".nsf")+4);
	attUrl = attUrl.replace(re, "%23");
	if (window.isAttEdit == null)
		isAttEdit = false;
	if (window.isAttCopy == null)
		isAttCopy = true;
	if (window.isAttPrint == null)
		isAttPrint = true;
	if (window.isAttDownload == null)
		isAttDownload = true;
	if (window.isAttShowRevision == null)
		isAttShowRevision = false;
	if (AttachmentInfo.IsHandled) {
		if (optNum == 2 && window.EditOnlineObject == null)
			optNum = 1;
		if (optNum == 1) {
			if (isencrypt) {
				var strFname = document.all.AttachmentOCX.GetUniqueFileName();
				strFname = strFname.substring(0, strFname.lastIndexOf("."))
						+ attUrl.substring(attUrl.lastIndexOf("."))
				if (document.all.AttachmentOCX.SaveAs(attUrl, "", strFname, "")) {
					document.all.AttachmentOCX.ExecuteFile(strFname);
				}
			} else {
				open(attUrl, "_blank", "");
			}
		}
		if (optNum == 2) {
			AttachmentInfo.IsHandled = false;
			AttachmentInfo.Mode = "2";
			AttachmentInfo.OrgId = EditOnlineObject.OrgId;
			AttachmentInfo.FileUrl = attUrl;
			AttachmentInfo.CanPrint = isAttPrint;
			AttachmentInfo.CanCopy = isAttCopy;
			if (isencrypt)
				AttachmentInfo.Isencrypt = isencrypt
			AttachmentInfo.CanRevision = isAttShowRevision;
			open(dbpath+"/FM_EditOnline?OpenForm", "_blank",
					"menubar=no,resizable=yes");
//			open("../FM_EditOnline?OpenForm", "_blank",
//			"menubar=no,resizable=yes");
		}
		if (optNum == 3) {

			AttachmentInfo.IsHandled = false;
			AttachmentInfo.Mode = "3";
			AttachmentInfo.OrgId = EditOnlineObject.OrgId;
			AttachmentInfo.DocId = EditOnlineObject.DocId;
			AttachmentInfo.FileUrl = attUrl;
			AttachmentInfo.CanPrint = isAttPrint;
			AttachmentInfo.CanCopy = isAttCopy;
			AttachmentInfo.CanRevision = isAttShowRevision;
			if (isencrypt)
				AttachmentInfo.Isencrypt = isencrypt
		
			if (window.S_Isjg && S_Isjg == "1"){
				var e = getLockUser(1,S_DocId);
				if (e != "" && S_UserName != e) {
					alert("该附件正在被'" + e + "'编辑,请等该用户关闭或者30分钟后进入编辑！");
					AttachmentInfo.IsHandled = true;
					return false
				}
				alert("该附件已经被您加锁，并保留编辑时间30分钟，30分钟后可能会被其他人编辑！")
				var c = createXMLHTTPRequest();
				c.open("Get", S_SetupPath + "/sys/lks_attachlock.nsf/AG_AttachLock?OpenAgent&docid=" + S_DocId + "&us=" + S_UserName + "&dbpath=" + S_DbUrl + "&m_Seq=" + Math.random(), false);
				c.send("");
				AttachmentInfo.IsLock = true

			}else{
				if (window.locklist != null) {
					if (window.locklist != "") {
						var lockArr = locklist.split("☆")
						var attName = attUrl.substring(attUrl.indexOf(".nsf") + 48)
						for (m = 0; m < lockArr.length; m++) {
							if (lockArr[m] == decodeURI(attName)) {
								alert("此文档正在被编辑中请稍后编辑！")
								AttachmentInfo.IsHandled = true
								return false
							}
						}
					}
				open(dbpath+"/AG_Lock?OpenAgent&attUrl=" + attUrl); 
//				open("../AG_Lock?OpenAgent&attUrl=" + attUrl);
				AttachmentInfo.IsLock = true;

				}


				
			}
			open(dbpath+"/FM_EditOnline?OpenForm", "_blank",
					"menubar=no,resizable=yes");
//			open("../FM_EditOnline?OpenForm", "_blank",
//			"menubar=no,resizable=yes");
		}
		if (optNum == 4) {
			var theFile = decodeURI(srcAttUrl.substring(srcAttUrl.lastIndexOf("/")
					+ 1))
			if (document.all.AttachmentOCX.SaveAsEx(attUrl, "1", theFile, "1"))
				alert("附件已经下载完成!");
			else
				alert("附件下载失败!");
		}
	}
}


function repAttNameSpecial(fname)
{
	var k=fname.indexOf("$file/")
	var arrA=new Array("\/","\\\\",":","\\*","\\?",'\"',"\\<","\\>","\\|","“","”","×");
	var arrB=new Array("@01@","@02@","@03@","@04@","@05@","@06@","@07@","@08@","@09@","@10@","@11@","@12@");
	if(k!=-1)
	{
		attName=fname.substring(k+6); 
		for(i=0;i<arrA.length;i++){re = new RegExp(arrA[i], "g");attName = attName.replace(re, arrB[i]);}
		return fname.substring(0,k+6)+attName;
	}else {
		for(i=0;i<arrA.length;i++){re = new RegExp(arrA[i], "g");fname = fname.replace(re, arrB[i]);}
		return fname;
	}

}
function chkAttNameHasSpecial(fname)
{
	var i=fname.indexOf("$file/")
	if(i!=-1) fname=fname.substring(i+6); 
	if(AttachmentObject.AttachmentsListReplace && (AttachmentObject.AttachmentsListReplace).indexOf(fname)!=-1) return true;
	return false;
}                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        