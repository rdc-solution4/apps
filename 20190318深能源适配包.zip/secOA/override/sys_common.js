S_DbUrl = location.pathname;
S_DbUrl = S_DbUrl.substring(0, S_DbUrl.toLowerCase().indexOf(".nsf") + 4);
if (S_DbUrl.charAt(0) != "/")
    S_DbUrl = "/" + S_DbUrl;
if (window.S_DbPath == null ) {
    S_DbPath = S_DbUrl.substring(0, S_DbUrl.lastIndexOf("/"));
}
if (window.S_SetupPath == null )
    S_SetupPath = S_DbPath.substring(0, S_DbPath.lastIndexOf("/"));
if (window.S_JsFileList == null )
    S_JsFileList = new Array;
var isLoadPersonList = true;
var isSync = true;
if (!isLoadPersonList)
    isSync = false;
RegisterJsFile("common.js");
IncludeJsFile("utils1.0.js");
LoadCurStyleFilePath();
function LoadCurStyleFilePath() {
    var path = location.href.toLowerCase();
    var i = path.indexOf("&css=");
    if (i > -1) {
        path = path.substring(i + 5);
        i = path.indexOf("&");
        if (i > -1)
            path = path.substring(0, i);
        path = unescape(path);
        S_CurrentStyle = path;
    } else {
        path = GetCookie("LKS_WorkplaceStyle");
        if (path == null )
            path = "workplace/common";
        S_CurrentStyle = path;
    }
}
function IncludeJsFile(fileList, isCss, isStat, hasPath) {
    if (S_DbPath == "")
        return;
    var path = "";
    isStat = isStat ? true : false;
    fileList = fileList.split("|");
    if (hasPath == null )
        path = S_DbPath + (isCss ? "/css/" : "/js/");
    else 
    if (hasPath == '1')
        path = S_SetupPath + "/";
    else
        path = S_SetupPath + "/koa/" + S_CurrentStyle + "/";
    for (var i = 0; i < fileList.length; i++) {
        fileList[i] = fileList[i].toLowerCase();
        if (searchArray(S_JsFileList, fileList[i]) > -1)
            continue;S_JsFileList[S_JsFileList.length] = fileList[i];
        document.write("<script src=" + path + fileList[i] + "></script>");
    }
}
function RegisterJsFile(fileName) {
    fileName = fileName.toLowerCase();
    if (searchArray(S_JsFileList, fileName) == -1)
        S_JsFileList[S_JsFileList.length] = fileName;
}
function resizeWindow() {
    try {
        self.moveTo(0, 0);
        self.resizeTo(screen.availWidth, screen.availHeight);
    } catch (err) {}
}
function AddAppinfo(fieldName) {
    var style = "dialogWidth:630px; dialogHeight:300px; status:0;scroll:0; help:0";
    var RetrunStr = "";
    var path = getDbUrl("...") + "/koa/lks_workplace.nsf/FM_APPress?readform";
    var rtnVal = window.showModalDialog(path, "", style);
    var fieldObj = eval("document.all." + fieldName);
    var RetrunStr = fieldObj.value;
    if (rtnVal != null ) {
        for (i = 0; i < rtnVal.length; i++) {
            if (RetrunStr == "") {
                RetrunStr = rtnVal[i];
            } 
            else {
                RetrunStr = RetrunStr + "\n" + rtnVal[i];
            }
        }
        fieldObj.value = RetrunStr;
    }
}
function trim(str) {
    var i = 0;
    var j = str.length;
    for (i; i < str.length && str.charAt(i) == " "; i++)
        ;
    for (j; j > 0 && str.charAt(j - 1) == " "; j--)
        ;
    if (i > j)
        return "";
    return str.substring(i, j);
}
function trimField(strField) {
    var item = eval("document.all." + strField);
    item.value = trim(item.value);
    return item.value;
}
function getUrlParam(urlstring, paramname) {
    var tempstr;
    var i, j;
    i = urlstring.indexOf(paramname + "=");
    if (i == -1)
        return "";
    tempstr = urlstring.substring(i);
    i = tempstr.indexOf("=") + 1;
    j = tempstr.indexOf("&");
    if (j == -1)
        return tempstr.substring(i);
    return tempstr.substring(i, j);
}
function isInt(strNum) {
    var strTmp = strNum;
    if (strTmp.substring(0, 1) == "-")
        strTmp = strTmp.substring(1);
    var re = /\D/g;
    if (re.test(strTmp))
        return false;
    var val = parseInt(strNum, 10);
    if (isNaN(val))
        return false;
    if (arguments[1] != null )
        if (val < arguments[1])
            return false;
    if (arguments[2] != null )
        if (val > arguments[2])
            return false;
    return true;
}
function isFloat(strNum) {
    var strTmp = strNum;
    if (strTmp.substring(0, 1) == "-")
        strTmp = strTmp.substring(1);
    var i = strTmp.indexOf(".");
    if (i != -1) {
        var tempstr = strTmp.substring(i + 1);
        var j = tempstr.indexOf(".");
        if (j != -1)
            return false;
    }
    var re = /[^\d\.]/g;
    if (re.test(strTmp))
        return false;
    var val = parseFloat(strNum);
    if (isNaN(val))
        return false;
    if (arguments[1] != null )
        if (val < arguments[1])
            return false;
    if (arguments[2] != null )
        if (val > arguments[2])
            return false;
    return true;
}
function input(strMsg) {
    var arr = new Array;
    arr[0] = strMsg;
    arr[1] = (arguments[1] == null ) ? "" : arguments[1];
    var style = "dialogWidth:400px; dialogHeight:140px; status:0;scroll:0; help:0";
    return showModalDialog(S_DbPath + "/html/input.htm", arr, style);
}
function trimArray(src) {
    var rtn = new Array;
    for (var i = 0; i < src.length; i++) {
        for (var j = 1; j < arguments.length; j++) {
            if (src[i] == arguments[j])
                break;
        }
        if (j == arguments.length && src[i] != null )
            rtn[rtn.length] = src[i];
    }
    return rtn;
}
function searchArray(arrSrc, strSearch) {
    if (arrSrc.length != null )
        for (var i = 0; i < arrSrc.length; i++)
            if (trim(arrSrc[i].toLowerCase()) == trim(strSearch.toLowerCase()))
                return i;
    return -1;
}
function createLabel(title, n, isDisabled) {
    isDisabled = isDisabled ? isDisabled : 0;
    var bg = (n == 1) ? "1" : "2";
    var strHtml = " <INPUT TYPE=button onClick=\"showLabel(" + n + ");\" VALUE=\"" + title + "\" ID=buLabel" + n + " CLASS=labelbg" + bg + " rowDisabled=" + isDisabled + "> ";
    document.write(strHtml);
}
function createLabelip4(title, n, isDisabled) {
    isDisabled = isDisabled ? isDisabled : 0;
    var bg = (n == 1) ? "1" : "2";
    var strHtml = " <INPUT TYPE=button onClick=\"showLabelip4(" + n + ");\" VALUE=\"" + title + "\" ID=buLabel" + n + " CLASS=labelbgip" + bg + "   rowDisabled=" + isDisabled + "> ";
    document.write(strHtml);
}
function showLabel(n) {
    for (var i = 1; i < labelTable.rows.length; i++) {
        var o = eval("document.all.buLabel" + i);
        if (o != null )
            if (i == n) {
                labelTable.rows[i].style.display = "";
                o.className = "labelbg1";
                o.blur();
                labelTable.CurrentLabel = n;
            } else {
                labelTable.rows[i].style.display = "none";
                o.className = "labelbg2";
            }
    }
}
function displayLabel(labelID, isDisplay) {
    var buID;
    var tagObj;
    buID = labelID.split(";")
    for (var i = 0; i < buID.length; i++) {
        tagObj = eval("document.all.buLabel" + buID[i]);
        if (tagObj != null ) {
            if (isDisplay == 1) {
                tagObj.style.display = "inline";
            } 
            else
                tagObj.style.display = "none";
        }
    }
}
function showLabelip4(n) {
    for (var i = 1; i < labelTable.rows.length; i++) {
        var o = eval("document.all.buLabel" + i);
        if (o != null )
            if (i == n) {
                labelTable.rows[i].style.display = "";
                o.className = "labelbgip1";
                o.blur();
                labelTable.CurrentLabel = n;
            } else {
                labelTable.rows[i].style.display = "none";
                o.className = "labelbgip2";
            }
    }
}
function displayLabel(labelID, isDisplay) {
    var buID;
    var tagObj;
    buID = labelID.split(";")
    for (var i = 0; i < buID.length; i++) {
        tagObj = eval("document.all.buLabel" + buID[i]);
        if (tagObj != null ) {
            if (isDisplay == 1) {
                tagObj.style.display = "inline";
            } 
            else
                tagObj.style.display = "none";
        }
    }
}
function showLabelTable() {
    console.log("~~~~~~~~~~~~~~~");
    var btnObj, tagObj;
    labelTable.className = "labeltb";
    labelTable.rows[0].className = "tbbg";
    labelTable.rows[0].cells[0].className = "tbbg";
    labelTable.CurrentLabel = 1;
    for (var i = 1; i < labelTable.rows.length; i++) {
        labelTable.rows[i].style.display = "none";
        labelTable.rows[i].className = "trbg";
        labelTable.rows[i].cells[0].className = "tdbg";
        btnObj = eval("document.all.buLabel" + i);
        if (btnObj != null  && btnObj.rowDisabled != "0")
            for (var j = 0; j < labelTable.rows[i].all.length; j++) {
                tagObj = labelTable.rows[i].all[j];
                if (tagObj.tagName == "INPUT" || tagObj.tagName == "TEXTAREA" || tagObj.tagName == "SELECT")
                    tagObj.disabled = true;
                if (tagObj.tagName == "A" && tagObj.selectTag == "1")
                    tagObj.style.display = "none";
            }
    }
    labelTable.rows[1].style.display = "";
    var i = parseInt(getUrlParam(location.href.toLowerCase(), "label"));
    if (!isNaN(i))
        showLabel(i);
    labelTable.style.display = "";
}
function enableAllFields() {
    var tagObjs = document.forms[0].all;
    for (var i = 0; i < tagObjs.length; i++)
        if (tagObjs[i].tagName == "INPUT" || tagObjs[i].tagName == "TEXTAREA" || tagObjs[i].tagName == "SELECT")
            tagObjs[i].disabled = false;
}
function refreshWithLabel() {
    url = location.href;
    if (document.all.labelTable != null ) {
        var re = /&label=\d+/gi;
        var l = "&label=" + document.all.labelTable.CurrentLabel;
        if (url.search(re) > -1)
            url = url.replace(re, l);
        else
            url += l;
    }
    location = url;
}
function closeIE() {
    if (window.S_IsEdited != null  && S_IsEdited == "1")
        if (!confirm("当前为编辑状态，确认关闭吗？"))
            return;
    top.opener = top;
    top.close();
}
function AddressBook(fieldType, fieldName, isMulSelect, selectType, canBeMove, strSep, rtnType) {
    var path = S_SetupPath + "/sys/html/addressmain" + (isMulSelect ? "mul" : "sgl") + ".htm";
    var style = "dialogWidth:850px; dialogHeight:450px; status:0;scroll:0; help:0; resizable:1";
    var typeArr = fieldType.split(':');
    var parameter = new Array;
    rtnType = rtnType ? rtnType : false;
    parameter[0] = selectType ? selectType : "UPGM";
    parameter[1] = canBeMove ? canBeMove : false;
    parameter[2] = strSep ? strSep : ";";
    if (rtnType) {
        for (var i = 0; i < typeArr.length; i++) {
            switch (typeArr[i]) {
            case "name":
                parameter[3] = fieldName[i] ? fieldName[i] : "";
                break;
            case "ad":
                parameter[4] = fieldName[i] ? fieldName[i] : "";
                break;
            }
        }
    } else {
        var nameArr = fieldName.split(':');
        var fieldObj = new Array;
        for (var i = 0; i < typeArr.length; i++) {
            switch (typeArr[i]) {
            case "name":
                fieldObj[0] = eval("document.all." + nameArr[i]);
                parameter[3] = fieldObj[0].value;
                break;
            case "ad":
                fieldObj[1] = eval("document.all." + nameArr[i]);
                parameter[4] = fieldObj[1].value;
                break;
            }
        }
    }
    //----------------------------------------------------------------start
    /**2014-12-15 update by luowx
     **由于ie浏览器打补丁，导致部分ie在使用 window.showModalDialog打开子窗口，然后在子窗口里面再使用 window.showModalDialog时，无法传递参数
     **改用cookie的方式来传参
     */
    var parStr = "";
    for (var tmpi = 0; tmpi < parameter.length; tmpi++) {
        if (parStr == "")
            parStr = parameter[tmpi];
        else
            parStr += "^" + parameter[tmpi];
    }
    addCookie("addressReturn", "", 10, "/", ".sec.com.cn");
    //每次调用地址本，先清空返回值的cookie
    addCookie("addressPar", parStr, 10, "/", ".sec.com.cn");
    //将参数写入到cookie中，如果发生showModalDialog无法传值和返回的问题，则使用cookie值
    //----------------------------------------------------------------end
    
    var rtnArr = window.showModalDialog(path, parameter, style);
    
    //----------------------------------------------------------------start
    if (rtnArr == undefined) {
        rtnArr = getCookie("addressReturn").split("^");
        if (rtnArr == "undefined") {
            rtnArr = null ;
        } else {
            rtnArr = rtnArr.replaceAll("*", ";", "gi");
        }
    }
    
    
    //----------------------------------------------------------------end
    if (rtnType) {
        if (rtnArr == null )
            return null ;
        var rtnVal = new Array;
        for (var i = 0; i < typeArr.length; i++) {
            switch (typeArr[i]) {
            case "name":
                rtnVal[i] = rtnArr[0];
                break;
            case "ad":
                rtnVal[i] = rtnArr[1];
                break;
            }
        }
        return rtnVal;
    } else {
        if (rtnArr != null )
            for (var i = 0; i < rtnArr.length; i++)
                if (fieldObj[i])
                    fieldObj[i].value = rtnArr[i];
    }
}
function GetChildNodeText(XmlNode, ChildNodeName) {
    var Node = null , 
    AttrNode;
    Node = XmlNode.firstChild;
    while (Node != null ) {
        AttrNode = Node.getAttributeNode("name");
        if (AttrNode != null  && AttrNode.nodeValue == ChildNodeName)
            return Node.text;
        Node = Node.nextSibling;
    }
    return "";
}
function GetUserInfo(ADList, infoList, SepStr) {
    if (SepStr == null )
        SepStr = ";";
    var ADArr = ADList.split(SepStr);
    var GetPostInfoDb = getNotesIniValue("GetPostInfoDb");
    var isUseLDAP = (getNotesIniValue("GetPeopleInfoDb").toLowerCase() != "/names.nsf/");
    var infoArr = infoList.split(":");
    var rtnArr = new Array, arr, rtnVal;
    var i, j;
    var depnode, othernode;
    var finddep = false
      , findpost = false
      , findother = false;
    for (i = 0; i < ADArr.length; i++)
        ADArr[i] = trim(ADArr[i]);
    ADArr = nameFormat(ADArr, "C");
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    for (i = 0; i < infoArr.length; i++) {
        if (infoArr[i].length > 3 && infoArr[i].substring(0, 3) == "dep") {
            finddep = true;
            continue;
        }
        if (infoArr[i] == "post" || infoArr[i] == "dpost")
            findpost = true;
        findother = true;
    }
    for (i = 0; i < ADArr.length; i++) {
        if (ADArr[i] != "") {
            if (finddep) {
                xml.load(S_SetupPath + "/sys/lks_sysconfig.nsf/AG_UserAllDeptView?openagent&ad=" + escape(ADArr[i]));
                depnode = xml.selectNodes("/viewentries/viewentry");
            }
            if (findpost) {
                xml.load(GetPostInfoDb + "LKS_SearchPostByPerson?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + escape(ADArr[i]));
                othernode = xml.selectNodes("/viewentries/viewentry");
                arr = new Array;
                for (var k = 0; k < othernode.length; k++)
                    arr[k] = GetChildNodeText(othernode[k], "ListName");
            }
            if (findother) {
                xml.load("/names.nsf/LKS_SearchByAD?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + escape(ADArr[i]));
                othernode = xml.selectNodes("/viewentries/viewentry");
                if (othernode.length == 0) {
                    xml.load(S_SetupPath + "/sys/lks_sysconfig.nsf/LKS_SearchByAD?ReadViewEntries&count=9999999&PreFormat&RestrictToCategory=" + escape(ADArr[i]));
                    othernode = xml.selectNodes("/viewentries/viewentry");
                }
            }
            for (j = 0; j < infoArr.length; j++) {
                rtnVal = "";
                switch (infoArr[j].substring(0, 3)) {
                case "dep":
                    var level = infoArr[j].substring(3);
                    if (level == "") {
                        rtnVal = (othernode.length) ? GetChildNodeText(othernode[0], infoArr[j]) : "";
                    } else {
                        rtnVal = (depnode.length) ? GetChildNodeText(depnode[0], level) : "";
                    }
                    break;
                case "pos":
                    for (var k = 0; k < arr.length; k++)
                        rtnVal = (rtnVal == "" ? "" : rtnVal + SepStr) + arr[k];
                    break;
                case "dpo":
                    if (othernode.length) {
                        var tmp = GetChildNodeText(othernode[0], "dep");
                        for (var k = 0; k < arr.length; k++)
                            if (arr[k].substring(0, tmp.length) == tmp)
                                rtnVal = (rtnVal == "" ? "" : rtnVal + SepStr) + arr[k];
                    }
                    break;
                default:
                    if (othernode.length) {
                        if (!isUseLDAP && infoArr[j] == "name") {
                            rtnVal = GetChildNodeText(othernode[0], "lkstype");
                            if (rtnVal == "dep") {
                                rtnVal = ADArr[i];
                                break;
                            }
                        }
                        rtnVal = GetChildNodeText(othernode[0], infoArr[j]);
                    }
                }
                rtnArr[j] = (!rtnArr[j] ? "" : rtnArr[j] + SepStr) + rtnVal;
            }
        }
    }
    return rtnArr;
}
function isTime(fieldname) {
    var str = fieldname.value;
    var dt = new Date();
    var nowTime = dt.getHours() + ":" + dt.getMinutes();
    var OneChar = "";
    for (var i = 0; i < str.length; i++) {
        OneChar = str.charAt(i);
        if (OneChar == ":")
            break;
    }
    if (isInt(str.substring(0, i))) {
        hourStr = parseInt(trim(str.substring(0, i)), 10);
        m = trim(str.substring(0, i)).length;
    } else {
        alert("请检查您的时间输入是否有误");
        fieldname.value = nowTime;
        fieldname.focus();
        return false;
    }
    if (isInt(str.substring(i + 1, str.length))) {
        minuStr = parseInt(trim(str.substring(i + 1, str.length)), 10);
        n = trim(str.substring(i + 1, str.length)).length;
    } else {
        alert("请检查您的时间输入是否有误");
        fieldname.value = nowTime;
        return false;
    }
    if ((hourStr > 23 || hourStr < 0) || (minuStr > 59 || minuStr < 0) || (m > 2 || n > 2)) {
        alert("请检查您的时间输入是否有误");
        fieldname.value = nowTime;
        return false;
    }
    return true;
}
function checkPleonasm(viewName, keyword, docid, casesensitive, viewType) {
    var path = location.href.toLowerCase();
    var i;
    if (!docid) {
        docid = DocId;
        if (!docid) {
            i = path.indexOf("?");
            if (i > -1) {
                docid = path.substring(0, i);
                docid = docid.substring(docid.lastIndexOf("/") + 1);
            }
        }
    }
    path = path.substring(path, path.indexOf(".nsf"));
    i = viewName.lastIndexOf("/");
    if (i > -1) {
        var dbpath = viewName.substring(0, i);
        viewName = viewName.substring(i + 1);
    } else {
        var dbpath = path + ".nsf";
    }
    i = dbpath.indexOf("://");
    if (i > -1) {
        dbpath = dbpath.substring(i + 3);
        dbpath = dbpath.substring(dbpath.indexOf("/") + 1);
    }
    dbpath = dbpath.substring(0, 1) == "/" ? dbpath.substring(1) : dbpath;
    path = path.substring(0, path.lastIndexOf("/"));
    path = path.substring(0, path.lastIndexOf("/")) + "/sys/lks_public.nsf/AG_CheckPleonasm?Openagent";
    path += (casesensitive ? "&casesensitive" : "") + "&db=" + dbpath + "&view=" + viewName;
    path += (viewType == null  ? "" : "&viewtype=" + viewType);
    path += "&class=" + escape(keyword) + "&docid=" + docid;
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    xml.load(path);
    nodes = xml.selectNodes("ReturnMsg");
    return ( nodes[0].text == "1") ;
}
function DrawButtom(imgpath, strText, strCode, strId, title) {
    var Result = "";
    var tbwidth = strText.length * 20;
    if (title == "" || title == null )
        title = strText;
    Result += "<table width=" + tbwidth + " title='" + title + "' onMouseOver='this.className=\"TBButtomLinkmouseover\"' onMouseOut='this.className=\"TBButtomLink\"' onclick='" + strCode + "' cellpadding=0 border=0 cellspacing=0 height=19 class=TBButtomLink id=" + strId + ">";
    Result += "<td width=10 background='" + imgpath + "buttomleft.gif'>&nbsp;</td>";
    Result += "<td valign=bottom align=center background='" + imgpath + "buttomcenter.gif' nowrap>" + strText + "</td>";
    Result += "<td width=10 background='" + imgpath + "buttomright.gif'>&nbsp;</td>";
    Result += "</table>";
    return Result;
}
function showAuthorization(dbPath, idObj, fieldName, EmptyAllRead, mailText, notify, status) {
    if (mailText == null )
        mailText = "\"请查阅文档：\"+Subject";
    if (notify == null )
        notify = true;
    if (status == null  | status == "")
        status = "RE";
    var path = location.href.toLowerCase();
    path = path.substring(path.indexOf("//") + 2);
    path = path.substring(path.indexOf("/"), path.indexOf(".nsf"));
    if (dbPath == null )
        dbPath = path.substring(1, path.length) + ".nsf";
    path = path.substring(0, path.lastIndexOf("/"));
    path = path.substring(0, path.lastIndexOf("/"));
    path += "/sys/lks_public.nsf/fm_authorizeframe?readform&dbpath=" + dbPath;
    if (status == "RE")
        var style = "dialogWidth:600px; dialogHeight:320px; status:0;scroll:0; help:0";
    else 
    if (status == "R" | status == "E")
        var style = "dialogWidth:600px; dialogHeight:250px; status:0;scroll:0; help:0";
    var parameter = new Array;
    var i, tmpArr;
    if (typeof (idObj) == "string") {
        path += "&docid=" + idObj;
        parameter[1] = idObj;
    } else {
        if (idObj == null )
            idObj = document.forms[0].F_Selected;
        if (idObj.length == null ) {
            if (idObj.checked)
                parameter[1] = idObj.value;
        } else {
            for (i = 0; i < idObj.length; i++)
                if (idObj[i].checked)
                    parameter[1] = parameter[1] ? parameter[1] + ";" + idObj[i].value : idObj[i].value;
        }
        if (parameter[1] == null ) {
            alert("请先选定需要授权的文档！");
            return false;
        }
    }
    if (fieldName == null )
        fieldName = "F_DisReader:F_Reader:F_DisEditor:F_Editor";
    tmpArr = fieldName.split(':');
    path += "&reader=" + tmpArr[0] + ":" + tmpArr[1] + "&editor=" + tmpArr[2] + ":" + tmpArr[3];
    if (EmptyAllRead == null )
        parameter[0] = 1;
    else
        parameter[0] = EmptyAllRead ? 1 : 0;
    parameter[2] = mailText;
    parameter[3] = notify;
    parameter[4] = status;
    rtnArr = window.showModalDialog(path, parameter, style);
    if (rtnArr == null )
        return false;
    else
        return true;
}
function setFavorite(showText, theURL) {
    var path = location.href.toLowerCase();
    path = path.substring(path.indexOf("//") + 2, path.length);
    path = path.substring(path.indexOf("/"), path.length);
    path = path.substring(0, path.indexOf(".nsf"));
    path = path.substring(0, path.lastIndexOf("/"));
    path += "/lks_favoritemng.nsf/FM_Favoriteframe?readform";
    var parameter = new Array;
    parameter[0] = showText;
    parameter[1] = theURL;
    var style = "dialogWidth:600px; dialogHeight:300px; status:0;scroll:1; help:0";
    rtnArr = window.showModalDialog(path, parameter, style);
    if (rtnArr == null )
        return false;
    else
        return true;
}
function replaceSymbol(field, from, to) {
    var re = eval("/" + from + "+/g");
    var arr = field.split(":");
    for (var i = 0; i < arr.length; i++) {
        reField = eval("document.all." + arr[i]);
        var fieldValue = reField.value;
        reField.value = fieldValue.replace(re, to);
    }
    return true;
}
function moveButton() {
    var newElem, i;
    if (window.S_OperationBar)
        newElem = S_OperationBar;
    else {
        document.body.style.marginTop = "26";
        newElem = document.createElement("<div id=S_OperationBar style='position:absolute;top:0px;z-index:999'></div>");
        document.body.appendChild(newElem);
        window.attachEvent("onscroll", function() {
            S_OperationBar.style.top = document.body.scrollTop;
        });
        document.body.attachEvent("onscroll", function() {
            S_OperationBar.style.top = document.body.scrollTop;
        });
    }
    newElem.innerHTML = BtnBar_GetOuterHTML(BtnBar_GetInnerHTML(document.all.buttonDiv.all.tags("INPUT")));
}
function BtnBar_GetOuterHTML(btnHTML) {
    var htmlCode = "<table border=0 cellpadding=0 cellspacing=0 style=\"width:100%;height:26;\">";
    htmlCode += "<tr><td style=\"text-align:right;vertical-align:middle;\">" + btnHTML + "</td></tr></table>";
    return htmlCode;
}
function BtnBar_GetInnerHTML(btnList) {
    var filePath = S_DbPath + "/workplace/common/images/";
    var htmlCode = "<table border=0 cellpadding=0 cellspacing=0><tr height=19>"
    for (var i = 0; i < btnList.length; i++) {
        htmlCode += "<td style='background-image:url(" + filePath + "view_btn_1.gif);width:6'></td>";
        htmlCode += "<td style='background-image:url(" + filePath + "view_btn_2.gif);padding:3px 5px 0px 5px'>";
        htmlCode += "<a style='text-decoration:none;' href=\"javascript:void document.all." + btnList[i].name + ".click();\" title=\"" + btnList[i].title + "\"><nobr>";
        htmlCode += btnList[i].value + "</nobr></a></td>";
        htmlCode += "<td style='background-image:url(" + filePath + "view_btn_3.gif);width:6'></td>";
        htmlCode += "<td style='width:10px'></td>";
    }
    htmlCode += "<td width=20></td></tr></table>";
    return htmlCode;
}
function removeButton() {}
function GetViewFieldText(viewName, className, itemList, fieldList) {
    if (fieldList == null )
        fieldList = itemList;
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    if (viewName.indexOf("/") == -1) {
        var sourceDb;
        var path = location.href.toLowerCase();
        path = path.substring(0, path.indexOf(".nsf"));
        sourceDb = path + ".nsf";
        viewName = sourceDb + "/" + viewName;
    }
    var QueryURL = viewName + "?readviewentries&count=9999999&preformat&restricttocategory=";
    xml.load(QueryURL + escape(className));
    var nodes = xml.selectNodes("/viewentries/viewentry");
    if (nodes.length == 0)
        return false;
    itemList = itemList.split(":");
    fieldList = fieldList.split(":");
    for (i = 0; i < itemList.length; i++)
        eval("document.all." + itemList[i]).value = GetChildNodeText(nodes[0], fieldList[i]);
    return true;
}
function GetViewFieldValue(viewName, className, fieldList) {
    var rtn = new Array;
    var sourceDb;
    var path = location.href.toLowerCase();
    if (fieldList == null )
        return fasle;
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    if (viewName.indexOf("/") == -1) {
        path = path.substring(0, path.indexOf(".nsf"));
        sourceDb = path + ".nsf";
        viewName = sourceDb + "/" + viewName;
    } 
    else {
        path = path.substring(0, path.indexOf("/lks"));
        viewName = path + "/" + viewName;
    }
    var QueryURL = viewName + "?readviewentries&count=9999999&preformat&restricttocategory=";
    xml.load(QueryURL + escape(className));
    var nodes = xml.selectNodes("/viewentries/viewentry");
    if (nodes.length == 0)
        return false;
    fieldList = fieldList.split(":");
    for (i = 0; i < fieldList.length; i++)
        rtn[rtn.length] = GetChildNodeText(nodes[0], fieldList[i]);
    return rtn;
}
function checkField(fieldList) {
    var fieldObj, fieldInfo, rtnVal = true;
    fieldList = fieldList.split(":");
    for (var i = 0; i < fieldList.length; i++) {
        fieldInfo = fieldList[i].split("^");
        fieldObj = eval("document.all." + fieldInfo[0]);
        if (!fieldObj)
            continue;if (fieldObj.tagName != "SELECT")
            fieldObj.value = trim(fieldObj.value);
        if (fieldInfo[2] == null  || fieldInfo[2] == "")
            fieldInfo[2] = "E";
        for (; fieldInfo[2] != ""; fieldInfo[2] = fieldInfo[2].substring(1)) {
            switch (fieldInfo[2].substring(0, 1)) {
            case "I":
                if (fieldObj.value != "" && !isInt(fieldObj.value)) {
                    alert("“" + fieldInfo[1] + "”应为整数！请重新输入。");
                    rtnVal = false;
                }
                break;
            case "F":
                if (fieldObj.value != "" && !isFloat(fieldObj.value)) {
                    alert("“" + fieldInfo[1] + "”应为数字！请重新输入。");
                    rtnVal = false;
                }
                break;
            case "E":
                if (fieldObj.tagName == "SELECT") {
                    if (fieldObj.selectedIndex == 0) {
                        alert("请选择“" + fieldInfo[1] + "”！");
                        rtnVal = false;
                    }
                    break;
                }
                if (fieldObj.value == "") {
                    alert("请填写“" + fieldInfo[1] + "”！");
                    rtnVal = false;
                }
                break;
            case "T":
                if (fieldObj.value.charAt(fieldObj.value.length - 1) == "<") {
                    alert("“" + fieldInfo[1] + "”含有非法字符组合！请重新输入。");
                    rtnVal = false;
                    break;
                }
                if (fieldObj.value.search(/<\w/gi) > -1) {
                    alert("“" + fieldInfo[1] + "”含有非法字符组合！请重新输入。");
                    rtnVal = false;
                }
                break;
            case "C":
                if (fieldObj.value.charAt(fieldObj.value.length - 1) == "<") {
                    alert("“" + fieldInfo[1] + "”含有非法字符组合！请重新输入。");
                    rtnVal = false;
                    break;
                }
                if (fieldObj.value.search(/<\w/gi) > -1) {
                    alert("“" + fieldInfo[1] + "”含有非法字符组合！请重新输入。");
                    rtnVal = false;
                    break;
                }
                if (fieldObj.value.search(/[\&+|]/gi) > -1) {
                    alert("“" + fieldInfo[1] + "”不能含有\\&+|等特殊符号！请重新输入。");
                    rtnVal = false;
                    break;
                }
            case ",":
                replaceSymbol(fieldInfo[0], "，", ",");
                break;
            case ";":
                replaceSymbol(fieldInfo[0], "；", ";");
                break;
            }
            if (!rtnVal) {
                try {
                    fieldObj.focus();
                } 
                catch (err) {}
                return false;
            }
        }
    }
    return true;
}
function remind(width, height) {
    var speed = 2;
    var WW = 180;
    var WH = 160;
    if (width != null )
        WW = width;
    if (height != null )
        WH = height;
    var SW = screen.availWidth;
    var SH = screen.availHeight;
    var WX = SW - WW - 10;
    var WY = SH;
    window.focus();
    window.resizeTo(WW, WH);
    window.moveTo(WX, WY);
    remind_moveup(0, WH / speed, speed);
}
function remind_moveup(numNow, numMax, speed) {
    window.moveBy(0, -speed);
    if (numNow >= numMax)
        setTimeout("remind_movedown(" + numNow + "," + speed + ")", 3000);
    else
        setTimeout("remind_moveup(" + (numNow + 1) + "," + numMax + "," + speed + ")", 10);
}
function remind_movedown(numNow, speed) {
    window.moveBy(0, speed);
    if (numNow >= 0)
        setTimeout("remind_movedown(" + (numNow - 1) + "," + speed + ")", 10);
    else
        window.close();
}
function getDbUrl(opt, includeDNS) {
    var url = includeDNS ? location.href : location.pathname;
    if (opt == "/")
        return location.href.substring(0, location.href.indexOf(location.pathname));
    url = url.substring(0, url.toLowerCase().indexOf(".nsf") + 4);
    if (opt == null )
        opt = ".";
    for (var i = 1; i < opt.length; i++)
        url = url.substring(0, url.lastIndexOf("/"));
    if (url.charAt(0) != "/" && !includeDNS)
        url = "/" + url;
    return url;
}
function getRadioValue(v) {
    var object = eval("document.forms[0]." + v);
    var nlength = object.length;
    for (var i = 0; i < object.length; i++) {
        if (object[i].checked == true) {
            return object[i].value;
        }
    }
    return "";
}
function nameFormat(nameList, rtnType) {
    if (nameList[0]) {
        var rtnList = nameList;
    } else {
        var rtnList = new Array;
        rtnList[0] = nameList;
    }
    var n, tmpArr;
    for (var i = 0; i < rtnList.length; i++) {
        if (rtnList[i] == "")
            continue;tmpArr = rtnList[i].split("/");
        switch (rtnType) {
        case "CN":
            rtnList[i] = (n = tmpArr[0].indexOf("=")) > -1 ? tmpArr[0].substring(n + 1) : tmpArr[0];
            break;
        case "A":
            for (var j = 0; j < tmpArr.length; j++)
                tmpArr[j] = (n = tmpArr[j].indexOf("=")) > -1 ? tmpArr[j].substring(n + 1) : tmpArr[j];
            rtnList[i] = tmpArr.join("/");
            break;
        case "C":
            if (tmpArr.length > 1) {
                tmpArr[0] = tmpArr[0].indexOf("=") > -1 ? tmpArr[0] : "CN=" + tmpArr[0];
                for (var j = 1; j < tmpArr.length - 1; j++)
                    tmpArr[j] = tmpArr[j].indexOf("=") > -1 ? tmpArr[j] : "OU=" + tmpArr[j];
                tmpArr[j] = tmpArr[j].indexOf("=") > -1 ? tmpArr[j] : "O=" + tmpArr[j];
            }
            rtnList[i] = tmpArr.join("/");
        }
    }
    return nameList[0] ? rtnList : rtnList[0];
}
function forbidLink() {
    document.oncontextmenu = function() {
        if (event.srcElement.tagName == "A")
            return false;
    }
    ;
}
function disableClick() {
    for (var i = 0; i < document.all.length; i++)
        document.all[i].onclick = function() {
            return false;
        }
        ;
}
function RunAgentByXml(agent) {
    var xml = new ActiveXObject("MSXML.DOMDocument");
    xml.async = false;
    var path = S_DbUrl;
    xml.load(path + "/" + agent);
    nodes = xml.selectNodes("ReturnCode");
    result = nodes[0].text;
    return result;
}
function personList(userND) {
    var info = "";
    if (isLoadPersonList) {
        var xml = new ActiveXObject("MSXML.DOMDocument");
        xml.async = false;
        if (userND == "")
            info = "";
        else {
            try {
                xml.load(S_SetupPath + "/sys/lks_sysconfig.nsf/AG_GetMoreInfo?OpenAgent&nd=" + escape(userND));
                info = xml.selectNodes("/ReturnMsg")[0].text;
            } catch (err) {
                info = "";
            }
        }
    }
    return info;
}
function personList_async(userND, thefunction) {
    var xhttp = new ActiveXObject("MSXML2.XMLHTTP");
    var info = null ;
    if (isLoadPersonList) {
        if (userND == "")
            info = ""
        else {
            try {
                xhttp.onreadystatechange = thefunction;
                xhttp.open("GET", S_SetupPath + "/sys/lks_sysconfig.nsf/AG_GetMoreInfo?OpenAgent&nd=" + escape(userND), true);
                xhttp.Send();
            } catch (err) {
                info = "";
            }
        }
        if (info == null )
            return xhttp;
        else
            return null ;
    }
    return null ;
}
function flowHidenButton(iframeObj) {
    try {
        if (iframeObj == null ) {
            iframeObj = "ifFlow";
        }
        var framedoc = eval(iframeObj);
        if (framedoc.document.all.tdButton != null ) {
            framedoc.document.all.tdButton.parentNode.style.display = "none";
            if (framedoc.document.all.optCachetA != null )
                framedoc.document.all.optCachetA.parentNode.style.display = "";
        } 
        else
            setTimeout("flowHidenButton(\"" + iframeObj + "\");", 100);
    } 
    catch (err) {}
}
function showBackgroundImg() {
    var imgurl = getUrlParam(location.href, "bgimg");
    if (imgurl != "")
        document.writeln("<style>body{background:url(" + imgurl + ")}</style>");
    var imgurl = getUrlParam(location.href, "bgcolor");
    if (imgurl != "")
        document.writeln("<style>body{background-color:" + imgurl + "}</style>");
}
showBackgroundImg();
EventHandler = new Object;
EventHandler.ObjectList = new Array;
EventHandler.AddObject = function(obj) {
    this.ObjectList[this.ObjectList.length] = obj;
}
document.onmousedown = function() {
    for (var i = 0; i < EventHandler.ObjectList.length; i++) {
        if (EventHandler.ObjectList[i].OnDocumentMouseDown) {
            try {
                EventHandler.ObjectList[i].OnDocumentMouseDown();
            } 
            catch (err) {}
        }
    }
}
function GetCookie(name) {
    var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
    if (arr != null )
        return decodeURI(arr[2]);
    return null ;
}
//function resizeIframe(strObj,intHeight){var str;if(document.body.scrollHeight==""||document.body.scrollHeight<5){str=(intHeight==null)?"resizeIframe('"+strObj+"')":"resizeIframe('"+strObj+"',"+intHeight+")";setTimeout(str,500);return;}
//if(intHeight==null)intHeight=5;if(document.body.scrollHeight>intHeight)intHeight=document.body.scrollHeight;if(strObj!=null){str="parent.document.all."+strObj+".style.height = "+intHeight;setTimeout(str,100);}else{var Obj=parent.document.getElementsByTagName("IFRAME");for(var i=0;i<Obj.length;i++){if(Obj[i]!=null){if(Obj[i].src!=null&&Obj[i].id!="if_subform"){var x=Obj[i].src.toLowerCase();var y=location.href.toLowerCase();x=x.indexOf(".nsf");y=y.indexOf(".nsf");if(x*y>0){str=Obj[i].id+".style.height = "+intHeight;setTimeout(str,100);}}}}}}
function resizeIframe(strObj, intHeight) {
    var str;
    
    if (document.body.scrollHeight == "" || document.body.scrollHeight < 5) {
        str = (intHeight == null ) ? "resizeIframe('" + strObj + "')" : "resizeIframe('" + strObj + "'," + intHeight + ")";
        setTimeout(str, 500);
        return;
    }
    if (intHeight == null )
        intHeight = 5;
    if (document.body.scrollHeight > intHeight)
        intHeight = document.body.scrollHeight;
    if (strObj != null ) {
        str = "parent.document.all." + strObj + ".style.height = " + intHeight;
        setTimeout(str, 100);
    } else {
        var Obj = parent.document.getElementsByTagName("IFRAME");
        for (var i = 0; i < Obj.length; i++) {
            if (Obj[i] != null ) {
                if (Obj[i].src != null  && Obj[i].id != "if_subform") {
                    var x = Obj[i].src.toLowerCase();
                    var y = location.href.toLowerCase();
                    
                    x = x.indexOf(".nsf");
                    y = y.indexOf(".nsf");
                    
                    if (x * y > 0) {
                        try {
                            str = Obj[i].id + ".style.height = " + intHeight;
                            eval(str);
                            //setTimeout(str, 100);
                        } catch (e) {
                            str = "parent.document.all." + Obj[i].id + ".style.height = " + intHeight;
                            eval(str);
                            //setTimeout(str, 100);
                        }
                    }
                }
            }
        }
    }
}

function AjaxXmlDoc(url, async) {
    this.xmlDoc = null ;
    this.async = async == null  || !async ? false : true;
    this.url = url == null  ? "" : url;
    this._TyeThese = AjaxXmlDoc_TyeThese;
    this._GetXMLDoc = AjaxXmlDoc_GetXMLDoc;
    this.Load = AjaxXmlDoc_Load;
    this.xmlDoc = this._GetXMLDoc();
}
function AjaxXmlDoc_TyeThese() {
    var returnValue;
    for (var i = 0; i < arguments.length; i++) {
        var lambda = arguments[i];
        try {
            returnValue = lambda();
            break;
        } catch (e) {}
    }
    return returnValue;
}
function AjaxXmlDoc_GetXMLDoc() {
    if (this.xmlDoc != null )
        return this.xmlDoc;
    return this._TyeThese(function() {
        return new ActiveXObject('Microsoft.XMLHTTP')
    }, function() {
        return new ActiveXObject('MSXML.DOMDocument')
    }, function() {
        return new ActiveXObject('Msxml2.DOMDocument')
    }, function() {
        return new ActiveXObject('Microsoft.XMLDOM')
    });
}
function AjaxXmlDoc_Load() {
    if (this.xmlDoc == null  || this.url == "")
        return false;
    this.xmlDoc.async = this.async;
    this.xmlDoc.load(this.url);
    return (this.xmlDoc.parseError != 0) ? false : true;
}

function getCookie(objName) {
    //获取指定名称的cookie的值
    var arrStr = document.cookie.split("; ");
    for (var i = 0; i < arrStr.length; i++) {
        var temp = arrStr[i].split("=");
        if (temp[0] == objName)
            return decodeURI(temp[1]);
    }
}

function addCookie(name, value, expires, path, domain) {
    var str = name + "=" + encodeURI(value);
    if (expires != "") {
        var date = new Date();
        date.setTime(date.getTime() + expires * 60 * 1000);
        //expires单位分钟
        str += ";expires=" + date.toGMTString();
    }
    if (path != "") {
        str += ";path=" + path;
        //指定可访问cookie的目录
    }
    if (domain != "") {
        str += ";domain=" + domain;
        //指定可访问cookie的域
    }
    document.cookie = str;
}
String.prototype.replaceAll = function(reallyDo, replaceWith, ignoreCase) {
    if (!RegExp.prototype.isPrototypeOf(reallyDo)) {
        return this.replace(new RegExp(reallyDo,(ignoreCase ? "gi" : "g")), replaceWith);
    } else {
        return this.replace(reallyDo, replaceWith);
    }
}

/*门户待办刷新：若JS变量MHDBSXing.LastRefresh不等于document.cookie.reftask则刷新，并将MHDBSXing.LastRefresh置为reftask的值，在首次打开门户时reftask默认为undefined，MHDBSXing.LastRefresh默认为undefined，不执行刷新代码；
在流程审批过程中需要刷新门户待办列表框，则调用接口ReturnMsgFn并传刷新参数，该接口使cookie中reftask置为系统时间。
koa_lihx 20161107解决跨单位存在待办交换情况下1秒钟待办并未能够交换完成，故延迟30秒再刷新一次。
 */
var MHDBSXing = {
    LastRefresh: "init"
}
MHDBSXing.TimedRefreshFn = function() {
    var refreshTask = document.cookie.match(/\breftask=(.*?)(?=;|$)/g);
    refreshTask = refreshTask != null  ? refreshTask[0] : null ;
    refreshTask = refreshTask != null  ? refreshTask.replace("reftask=", "") : null ;
    if (MHDBSXing.LastRefresh === "init") {
        MHDBSXing.LastRefresh = refreshTask;
    }
    if (MHDBSXing.LastRefresh != refreshTask) {
        var frameObj = null ;
        var frames = parent.document.frames;
        for (var i = 0; i < frames.length; i++) {
            if (frames[i].name == "viewFrame") {
                frameObj = frames[i].document.getElementsByTagName("IFRAME");
                for (j = 0; j < frameObj.length; j++) {
                    framehref = (frameObj[j].src).toLowerCase();
                    if ((framehref.indexOf("lks_tasks") != -1 && framehref.indexOf("fm_tasklist") != -1) || (framehref.indexOf("lks_hubconfig") != -1 && framehref.indexOf("fm_indexlist") != -1)) {
                        frameObj[j].src = frameObj[j].src;
                        setTimeout((function(obj, ix) {
                            //30秒钟后再次刷新，避免待办交换延迟
                            return function() {
                                obj.src = obj.src;
                            }
                        })(frameObj[j], j), 30000);
                    }
                }
                break;
            }
        }
        MHDBSXing.LastRefresh = refreshTask;
    }
}

/**门户公告栏 koa_lihx 2017-03-13*/
var MHGGLan = {
    maxTimes: 3
};
MHGGLan.init = function() {
    // 假如是门户的头部引用，则绘制门户体系span
    if (parent.S_PortalInfo != null  && parent.S_PortalInfo.TipsContent != "") {
        if (new RegExp("sec.com.cn/homepage","ig").test(top.location.href) && new RegExp("/head/head.html$","ig").test(window.location.pathname)) {
            if (window.localStorage != null ) {
                if (parent.S_PortalInfo.TipsContent == window.localStorage.getItem("MHGGLan-value")) {
                    return;
                }
            }
            MHGGLan.content = parent.S_PortalInfo.TipsContent.replace(/.*\$\$BH\$\$\*\*/ig, "");
            MHGGLan.contentShow = MHGGLan.content.replaceAll("&nbsp;", " ").replaceAll("&nbsp;", "　");
            window.attachEvent("onload", function() {
                var div_time = document.getElementById("Div_TimeInfo");
                var tips_div = document.createElement("DIV");
                tips_div.id = "tips_div";
                tips_div.innerHTML = "<Div>" 
                + "<Div id='tips_cnt' style='float:left;height:20px;word-break:keep-all;white-space:nowrap;color:red'></Div></Div>";
                tips_div.style.cssText = "float:left;overflow:hidden;height:20px;width:" + "200px" + ";background:#f5f5f5";
                tips_div.title = MHGGLan.content;
                var span = document.createElement("DIV");
                span.innerText = "│";
                span.style.width = "20px";
                span.style.height = "20px";
                span.style.styleFloat = "left";
                span.style.textAlign = "center";
                div_time.insertAdjacentElement("afterEnd", span);
                MHGGLan.sepDiv = span;
                span.insertAdjacentElement("afterEnd", tips_div);
                
                //使在同一行
                div_time.style.styleFloat = "left";
                var span = document.createElement("SPAN");
                span.style.styleFloat = "left";
                var arr = [];
                var i = 0;
                var ne = div_time.previousSibling;
                while (ne != null ) {
                    arr[i++] = ne;
                    ne = ne.previousSibling;
                }
                for (var i = arr.length - 1; i >= 0; i--) {
                    span.appendChild(arr[i]);
                }
                span.innerHTML = span.innerHTML.replace("深圳能源OA系统", "&nbsp;");
                div_time.insertAdjacentElement("beforeBegin", span);
                
                //关闭按钮
                if (window.localStorage != null ) {
                    MHGGLan.markLabBtn = document.createElement("span");
                    MHGGLan.markLabBtn.title = "标记已读";
                    var cssTest = "float:left;font-size:2px;width:16px;height:16px;text-align:center;font-weight:bold;color:white;" + 
                    "background-image:url(/lks/koa/images/close_gray.png);display:none;cursor:hand;";
                    MHGGLan.markLabBtn.style.cssText = cssTest;
                    MHGGLan.markLabBtn.onmouseout = function() {
                        MHGGLan.markLabBtn.style.display = "none";
                    }
                    MHGGLan.markLabBtn.onclick = function() {
                        window.localStorage.setItem("MHGGLan-value", parent.S_PortalInfo.TipsContent);
                        clearTimeout(MHGGLan.tips_timer);
                        MHGGLan.markLabBtn.style.display = "none";
                        MHGGLan.tips_div.style.display = "none";
                        MHGGLan.sepDiv.style.display = "none";
                    }
                    div_time.parentElement.appendChild(MHGGLan.markLabBtn);
                }
                
                //获取最大可以获得的长度
                MHGGLan.maxAvailWidthFn = function(obj) {
                    var p = obj;
                    var syzdkd = obj.parentElement.clientWidth;
                    while (p.previousSibling != null ) {
                        p = p.previousSibling;
                        syzdkd = syzdkd - p.clientWidth;
                    }
                    p = obj;
                    while (p.nextSibling != null ) {
                        p = p.nextSibling;
                        syzdkd = syzdkd - p.clientWidth;
                    }
                    return syzdkd - 3;
                }
                
                //横向滚动
                MHGGLan.tips_div = document.getElementById("tips_div");
                MHGGLan.tips_cnt = document.getElementById("tips_cnt");
                MHGGLan.maxAvailWidth = MHGGLan.maxAvailWidthFn(MHGGLan.tips_div);
                //最优效果都是基于界面接近最大化的前提。
                //计算外层合适的长度（当单遍内容长度大于外层可以获得的最大长度，则外层长度略小于最大可获得长度；当小于时则为最大滚动次数倍单内容长度的一半；若最外层计算所得小于200px，则强制为200px）
                MHGGLan.tips_cnt.innerText = MHGGLan.contentShow + " ";
                if (MHGGLan.tips_cnt.clientWidth > MHGGLan.maxAvailWidth) {
                    MHGGLan.tips_div.style.width = (MHGGLan.maxAvailWidth) + "px";
                } else {
                    MHGGLan.tips_div.style.width = parseInt(MHGGLan.maxTimes * MHGGLan.tips_cnt.clientWidth / 2) + "px";
                }
                if (MHGGLan.tips_div.clientWidth < 200) {
                    MHGGLan.tips_div.style.width = 200 + "px";
                }
                
                //计算外层与内部滚动层的长度比例（假如单遍内容长度比外层长则使内层长度为单内容长度的最大滚动次数倍，若小于外层长度则更多地填充空格扩展到2倍以上外层的长度）
                if (MHGGLan.tips_cnt.clientWidth > MHGGLan.tips_div.clientWidth) {
                } else {
                    while (MHGGLan.maxTimes * MHGGLan.tips_cnt.clientWidth <= 2 * MHGGLan.tips_div.clientWidth) {
                        MHGGLan.tips_cnt.innerText = MHGGLan.tips_cnt.innerText + " ";
                    }
                    MHGGLan.contentShow = MHGGLan.tips_cnt.innerText;
                }
                //将内容扩展到最大横向滚动次数
                MHGGLan.tips_cnt.innerText = "";
                for (var i = 0; i < MHGGLan.maxTimes; i++) {
                    MHGGLan.tips_cnt.innerText = MHGGLan.tips_cnt.innerText + (MHGGLan.tips_cnt.innerText != "" ? " " : "") + MHGGLan.contentShow;
                }
                MHGGLan.CntDivWidth = MHGGLan.tips_cnt.clientWidth;
                MHGGLan.tips_cnt.innerText = MHGGLan.tips_cnt.innerText + (MHGGLan.tips_cnt.innerText != "" ? " " : "") + MHGGLan.contentShow;
                MHGGLan.tips_cnt.innerText = MHGGLan.tips_cnt.innerText + "                                             ";
                MHGGLan.tips_cnt.innerText = MHGGLan.tips_cnt.innerText + "                                             ";
                MHGGLan.tips_cnt.innerText = MHGGLan.tips_cnt.innerText + "                                             ";
                
                MHGGLan.scrollText = function() {
                    if (MHGGLan.tips_div.scrollLeft >= MHGGLan.CntDivWidth) {
                        clearTimeout(MHGGLan.tips_timer);
                        return;
                    } else {
                        MHGGLan.tips_div.scrollLeft++;
                    }
                }
                MHGGLan.tips_timer = setInterval(MHGGLan.scrollText, 25);
                MHGGLan.tips_div.onmouseover = function() {
                    if (MHGGLan.markLabBtn != null ) {
                        MHGGLan.markLabBtn.style.display = "block";
                    }
                }
                MHGGLan.tips_div.onmouseout = function() {
                    if (MHGGLan.markLabBtn != null ) {
                        if (event.toElement != MHGGLan.markLabBtn) {
                            MHGGLan.markLabBtn.style.display = "none";
                        }
                    }
                }
                
                //公告栏宽度随window窗口宽度变化
                window.attachEvent("onresize", function() {
                //MHGGLan.tips_div.style.width=(document.body.clientWidth>1366?"470":(document.body.clientWidth<=1024?"270":"270"))+"px";
                });
            });
        }
    }
}
MHGGLan.init();
