/*压缩类型：标准*/
///////////////////////////////////////////////////
//
//	Description: 
//	Display data contained in NotesView on a HTML page;
//	History:
//	Created by zhg, 2002-01-28 11:23:00, Version 1.0
//		Version limitation: 
//			1)Not support NoteViews Category hierachical
//			2)Browser must support ActiveX and MSXML3.0
//	Update by zhg, 2002-02-06 14:56:00 Version 1.1
//		1)Support checkbox, support multi-checked;
//	Update by zhg, 2002-02-22 09:56:00 Version 1.1.1
//		1)Support OnSortChange Event;
//	Update by zhg, 2002-03-08 10:43:00 Version 1.2
//		1)Add Column member -- "Name", support pick column value by "Name";
//	Update by zhg, 2002-03-20 18:20:00 Version 1.2.1
//		1)Add method OnQueryXML
//
RegisterJsFile("listview1.2.js");
IncludeJsFile("rtcommunion.js");

var viewObj = new Array();
function ListView(RefName, NavElementTop, TableElement, NavElementBottom)
{
	viewObj[viewObj.length] = this;
	this.HasColumns = true;
	this.RefName = RefName;
    //ViewRefName=RefName;
	this.CellPadding = "2";
	this.CellSpacing = "2";
	this.LastClickRow = -1;
	this.NavEnabled = true;
	this.IndexTextList = false;
    this.createColumns=false;
    this.HasReadCount=false;
    this.ViewName="";
    this.RestrictToCategory="-1";
    this.IsCateGory=false;
	this.IsReadStartCount = false;
    this.NoFileHtml="没有任何文档!"
    this.THClass="";
    this.TDClass="";
    this.TRClass="";
    this.CheckBoxType = "checkbox";
    this.ReadCountFromAgent = false;
    this.xml = null;
    this.xmldoc = null;
    this.async = true;

	//isLargeMode
	try{
		this.IsLargeMode = isLargeMode;
	}catch(err){
		this.IsLargeMode = false;
	}
	
	//Color:
	this.ColumnColor = "c9e3e4";
	this.ColumnFontColor = "333333";
	this.RowColor0 = "FFFFFF";
	this.RowColor1 = "F5F5F5";
	this.RowColorFocused = "DFDFDF";
    this.columnalign=new Array();
	this.ColumnPara=new Array();

	//Data:
	this.HideColumnNum="";
	this.Columns = new Array();
	this.Rows = new Array();
	this.Silence = true;
	this.TryTimes = 0;
	this.CategoryDepth = 0;
	this.LocateColumnByName = false;
    this.AutoLink=true;

	//Images:
	this.AscImage = "/icons/dblasc.gif";
	this.DescImage = "/icons/dbldesc.gif";
	this.SortImage = "/icons/dblsort.gif";

	this.ImgGo = "/lks/images/go.gif";

	this.Target = "_self";
	this.NavElementTop = NavElementTop;
	this.TableElement = TableElement;
	this.NavElementBottom = NavElementBottom;
	this.HasIndexColumn = true;
	this.HasCheckboxColumn = false;
	this.UseXMLDataSource = true;
	
	//Page navigation information:
	this.NavParamNameStart = "Start";
	this.NavParamNameCount = "Count";
	this.NavParamNameAscend = "ResortAscending";
	this.NavParamNameDescend = "ResortDescending";
	this.NavHost = "";	//User Provide
	this.NavPath = "";	//User Provide
    this.NsfPath="";

	this.AscendSortColumn = -1;
	this.DescendSortColumn = -1;
	
	this.RecordCount = 10;		//User Provide
	this.PageSize = 10;		//User Provide
	this.RecordOffset = 1;		//User Provide
	this.TotalPage = 1;		//Compute
	this.CurrPage = 1;		//Compute
	this.HasViewedMaxPage = 1;		//Compute
	this.IsLastPage = false;		//Compute
	this.ComputeStatics = ListViewComputeStatics;
    this.RefreshViewStatus=ListViewRefreshStatics;
	
	//Events:
	this.CustomOnRowClick = null;			//User OnClick event handler
	this.OnRowUserClick=ListViewOnRowUserClick;	//User define OnClick Event Handler
	this.OnRowClick = ListViewOnRowClick;		//Default OnClick Event Handler
	this.CustomOnMouseOver = null;
	this.OnMouseOver = ListViewOnMouseOver;
	this.OnMouseOut = ListViewOnMouseOut;
	this.OnSortChange = ListViewOnSortChange; //User provide
    //getcount
        this.GetRecordCount=ListViewRecordCount;
        //this.ProcessRecordCount=ListViewProcessRecordCount;
	//Data Operations:
        this.AddAllColums=ListViewAddAllColumn;
	this.AddColumn = ListViewAddColumn;
	this.InsertColumn = ListViewInsertColumn;
	this.AddRow = ListViewAddRow;

	//Check operations:
	this.CheckAll = ListViewCheckAll;
	
	//Draw Methods:        
	this.Clear = ListViewClear;
	this.Show = ListViewShow;
	this.DrawAll = ListViewDrawAll;
	this.DrawTable = ListViewDrawTable;
	this.DrawRows = ListViewDrawRows;
	this.DrawColumns = ListViewDrawColumns;	
	this.DrawNavBar = ListViewDrawNavBar;
	this.GenerateTDTxt = ListViewGenerateTDTxt;
	
	//Nagivation Operation:
	this.ShowAll = ListViewShowAll;
	this.Turn = ListViewTurn;
	//this.Goto = ListViewGoto;
	this.Head = ListViewHead;
	this.Next = ListViewNext;
	this.Prev = ListViewPrev;
	this.Last = ListViewLast;
	this.Refresh = ListViewRefresh;
	this.OnPostViewReLoad = ListViewOnPostViewReload;
	
	this.SetSortColumn = ListViewSetSortColumn;
	this.SetPageSize = ListViewSetPageSize;
	
	//XML Loading:
	this.LoadXMLDataSource = ListViewLoadXMLDataSource;
	this.LoadXMLStr = ListViewLoadXMLStr;		//NOTE: IE only support UTF-16!!
	this.OnQueryXML = ListViewOnQueryXML;

	this.TransformXML = ListViewTransformXML;
	this.TransformXMLStr = ListViewTransformXMLStr;	//NOTE: IE only support UTF-16!!	
	this.SortRows = ListViewSortRows;
	this.Compare = ListViewCompare;
	//Methods:
	this.HasColumn = ListViewHasColumn;
        //viewtable
        this.CheckLink=ListViewCheckLink;
        this.ReadStartCount=ListViewReadStartCount;
        this.Processtext=ListViewProcessText;
        this.SetProcessText=null;
        this.Populate=ListViewPopulate;
        this.PopulateByColumn=ListViewPopulateByColumn;
        thisView = this;
        //view handling
        this.ChangeView=ListViewChangeView;
        //异步读取文档程序
        this.ReadyGoto = function(){        	
        	for(var i=0;i<viewObj.length;i++){        		
        		if(viewObj[i].xml!=null){        				
        			if(viewObj[i].xml.readyState==4){        	
        			var theView = viewObj[i];
        			var thexml = theView.xml;				
				if(thexml.parseError.errorCode!=0) {
					alert("错误信息:"+thexml.parseError);
					theView.xml = null;
					continue;
				}		
				if(!theView.createColumns) theView.AddAllColums(thexml);
				var RetVal = theView.TransformXML(thexml);
				if(RetVal == 1) {
					theView.CurrPage=theView.tmpPageNO;
					theView.RecordOffset = (theView.CurrPage-1)*theView.PageSize + 1;
					theView.Show();
                		}
				if(RetVal == 0){
					if(!theView.Silence){
						alert("超出有效页数范围");				
					}
					theView.CurrPage = theView.TotalPage + 1;
					theView.Show();
				}
				else if(RetVal == -1){//RecordCount = 0, no record read
                        		theView.CurrPage = theView.TotalPage + 1;
					theView.Show();
				}
				else if(RetVal == -2){
					theView.Show();
					if(!theView.Silence)alert("网络连接失败 或 浏览器不支持MSXML3.0/ActiveX");
				}
				else if(RetVal == -3){
                     			if(theView.CurrPage>1) {
                     				if(!theView.Silence){
                        			alert("超出有效页数范围!");
                        		}
                        		theView.Goto(1);
                     			} else {
                     				theView.Columns = new Array();
                     				theView.Clear();
                        			theView.Show();
                     			}                  
				}
				window.status = "完成";
				theView.TryTimes = 0;		
				if(theView.OnPostViewReLoad)
				theView.OnPostViewReLoad();		
				theView.xml = null;
				}
			}
		}
        }        
        //异步读取文档数程序
	this.ProcessRecordCount = function()
	{
		for(var i=0;i<viewObj.length;i++){        		
        		if(viewObj[i].xmldoc!=null){
        			if(viewObj[i].xmldoc.readyState==4){        	
        				var theView = viewObj[i];        			
					if(theView.xmldoc.parseError.errorCode==0) {
						var nodes = theView.xmldoc.selectNodes("viewcount");
						if(nodes == null) return null;
						if(nodes[0]==null) return null;		
						var intcount = 0;
						var eDocCount = nodes[0].attributes.getNamedItem("docCount");
						if(eDocCount != null)intcount = eDocCount.text;
	
						theView.RecordCount=intcount;          
						theView.HasReadCount = true;
						if(! this.IsLargeMode ) {theView.ReadCountFromAgent = true;}
						if(intcount==0) return true;
						theView.ComputeStatics();
						theView.RefreshViewStatus();
					}
					viewObj[i].xmldoc = null;
				}
			}
		}
	}
	//页面跳转
	this.Goto = function(PageNO)
	{	
		thisView.LastClickRow = -1;	
 		PageNO = m_ParseInt(PageNO);        
		if(PageNO < 1)PageNO = 1;
		if(PageNO > thisView.TotalPage) PageNO = thisView.TotalPage;
		var start=(PageNO-1)*thisView.PageSize+1;
		//if(this.IsLargeMode && thisView.IsReadStartCount && PageNO>1) {
		if(thisView.IsReadStartCount && PageNO>1) {
			start=thisView.ReadStartCount(start);
			if(start==""){
       			this.TotalPage =this.CurrPage;
				this.CheckLink();
			 	return null;
			}
			if(start==-1) return null;
		}
		if(PageNO>this.HasViewedMaxPage) this.HasViewedMaxPage = PageNO;
		var newurl = thisView.NavHost+thisView.NavPath+"&m_Seq="+Math.random();
		newurl += "&"+thisView.NavParamNameStart+"="+start;	
		newurl += "&"+thisView.NavParamNameCount+"="+(thisView.PageSize<=0?99999999:thisView.PageSize);	
		if(thisView.AscendSortColumn >= 0){
			newurl += "&"+thisView.NavParamNameAscend+"="+(thisView.AscendSortColumn+thisView.CategoryDepth);
		}
		else if(thisView.DescendSortColumn >= 0){
			newurl += "&"+thisView.NavParamNameDescend+"="+(thisView.DescendSortColumn+thisView.CategoryDepth);
		}
		if(thisView.UseXMLDataSource){		
  			window.status = "正在读取: "+newurl; 
  			if(thisView.async){
  				try{	
  					
					thisView.xml = new ActiveXObject("MSXML.DOMDocument");
					if(thisView.xml!=null){
						thisView.xml.onreadystatechange = thisView.ReadyGoto;
						thisView.tmpPageNO = PageNO;
						thisView.xml.load(newurl);
					}
				}catch(err){
				}
				return;		
  			}else{
				var RetVal = thisView.LoadXMLDataSource(newurl);
				if(RetVal == 1) {
                    		thisView.CurrPage=PageNO;
                    		thisView.RecordOffset = (thisView.CurrPage-1)*thisView.PageSize + 1;
					thisView.Show();     
                		}
				if(RetVal == 0){
					if(!thisView.Silence){
						alert("超出有效页数范围");				
					}
					thisView.CurrPage = thisView.TotalPage + 1;
					thisView.Show();
				}
				else if(RetVal == -1){//RecordCount = 0, no record read
                        		thisView.CurrPage = thisView.TotalPage + 1;
					thisView.Show();
				}
				else if(RetVal == -2){
					thisView.Show();
					if(!thisView.Silence)alert("网络连接失败 或 浏览器不支持MSXML3.0/ActiveX");
				}
				else if(RetVal == -3){
     	                		if(thisView.CurrPage>1) {
 			                    	if(!thisView.Silence){
        	        		        	alert("超出有效页数范围!");
                	        		}
                        			thisView.Goto(1);
                     			} else {
                     				thisView.Columns = new Array();
                     				thisView.Clear();
                        			thisView.Show();
                     			}                  
				}
				window.status = "完成";
				thisView.TryTimes = 0;
			}
		}else document.location.replace(newurl);
		if (thisView.OnPostViewReLoad)
			thisView.OnPostViewReLoad();
	}
}

function ListViewRecordCount()
{
	if(this.IsLargeMode) {return null; }
	var url;
	url=this.NavHost+this.NsfPath+"AG_ReadCount?openAgent&view="+this.ViewName+"&m_Seq="+Math.random()+"&cate="+escape(this.RestrictToCategory)+"&type="+this.IsCateGory; 
	try{
		this.xmldoc = new ActiveXObject("MSXML.DOMDocument");
		if(this.xmldoc != null){
			this.xmldoc.onreadystatechange =this.ProcessRecordCount;
			this.xmldoc.load(url);
		}
	}
	catch(err){
	}
	return null; 
}

function ListViewReadStartCount(startCount)
{
	if(this.RecordCount<startCount) {
		this.Goto(1);
		return false;
	}
	var url;
	var position;
	var Count = this.RecordOffset;
	if(Count>startCount) {
		if(this.Rows[0].PositionNum==null) return -1;
			position=this.Rows[0].PositionNum;
	}else
		if(Count==startCount) {
			if(this.Rows[0].PositionNum==null) return -1;
			position=this.Rows[0].PositionNum;
			return position.substring(position.indexOf(".")+1,position.length)
		}else{
			if(this.Rows[this.Rows.length-1].PositionNum==null) return -1;
			position=this.Rows[this.Rows.length-1].PositionNum;
			Count=Count+this.Rows.length-1;
		}

	startCount=startCount-Count;
	url=this.NavHost+this.NsfPath+"AG_ReadCount?openAgent&view="+this.ViewName+"&m_Seq="+Math.random()+"&cate="+escape(this.RestrictToCategory)+"&position="+position+"&start="+startCount;
	var intcount=1;
	try{
		var xml = new ActiveXObject("MSXML.DOMDocument");
		if(xml != null){
			xml.async = false;
			if(xml.load(url)) {
				var nodes = xml.selectNodes("Returncount");
				if(nodes == null) return 1;
				intcount=nodes[0].attributes.getNamedItem("StartCount").text    
			}
		}
	}
	catch(err){
	}
	return intcount; 
}

function ListViewProcessText(strtextlist,i,j)
{
	if(this.SetProcessText!=null) return this.SetProcessText(strtextlist,i,j);
	else return strtextlist;
}

function ListViewHasColumn(ColName)
{
	for(var i=0; i<this.Columns.length; i++)if(ColName == this.Columns[i].Name)return true;
	return false;
}

function ListViewCheckAll()
{
	var obj = event.srcElement;
	var Checked = obj.checked;
	var CheckboxList = document.all.tags("input");
	
	for(var i=0; i<CheckboxList.length; i++){
		obj = CheckboxList(i);
		if(obj.name == "F_Selected")obj.checked = Checked;
	}
}

function ListViewOnSortChange(ColumnNO, AscDesc)
//	ColumnNO: < 0, 不排序;
//	AscDesc: 0 -- 降序, 1 -- 升序, 其他 -- 取消排序
//	Return: true, allow change;
{
	return true;
}

function ListViewComputeStatics()
{
	if(this.PageSize < 0)this.PageSize = this.RecordCount;
	else if(this.PageSize==0) this.PageSize = this.Rows.length;
	//if(this.PageSize <= 0)this.PageSize = 5;//min_pagesize;
	this.RecordOffset = (this.CurrPage-1)*this.PageSize + 1;
	if(this.RecordCount%this.PageSize == 0){
		this.TotalPage = m_ParseInt(this.RecordCount/this.PageSize);
	}
	else{
		this.TotalPage = m_ParseInt(this.RecordCount/this.PageSize+1);
	}
	
	if(this.RecordOffset%this.PageSize == 0){
		this.CurrPage = m_ParseInt(this.RecordOffset/this.PageSize);
	}
	else{
		this.CurrPage = m_ParseInt(this.RecordOffset/this.PageSize+1);
	}	
	if(this.CurrPage > this.TotalPage){
		this.CurrPage = this.TotalPage;
		if(this.CurrPage < 1)this.CurrPage = 1;
		this.RecordOffset = (this.CurrPage-1)*this.PageSize + 1;
	}
}

function ListViewSetPageSize(NewSize){
	var iNewSize = m_ParseInt(NewSize);
	this.PageSize = iNewSize<5?5:(iNewSize>500?500:iNewSize);
}

function ListViewSetSortColumn(ColumnNO, AscDesc)
//	ColumnNO: < 0, 不排序;
//	AscDesc: 0 -- 降序, 1 -- 升序, 其他 -- 取消排序
{
	if(ColumnNO<0 || (AscDesc!=0 && AscDesc!=1)){
		if(this.OnSortChange(ColumnNO, AscDesc)){
			this.AscendSortColumn = -1;
			this.DescendSortColumn = -1;
		}
	}
	else{
		if(this.OnSortChange(ColumnNO, AscDesc)){
			if(AscDesc == 0){
				this.AscendSortColumn = -1;
				this.DescendSortColumn = ColumnNO;
			}
			else{
				this.AscendSortColumn = ColumnNO;
				this.DescendSortColumn = -1;
			}
		}
	}
	this.Refresh();
}

function ListViewOnQueryXML(url)
{
 	return RequestXML(url);
}

function ListViewShowAll()
{
	this.PageSize = 0;
	this.Goto(1);
}

function ListViewHead()
{
	this.Goto(1);
}

function ListViewNext()
{        
        var page=this.CurrPage+1;
        if(page>this.TotalPage) page=this.TotalPage;
	this.Goto(page);
}

function ListViewPrev()
{
        var page=this.CurrPage-1;
        if(page<1) page=1;
	this.Goto(page);
}

function ListViewLast()
{
	this.Goto(this.TotalPage);
}

function ListViewRefresh(isShowAll)
{
	if(isShowAll!=null){
		this.HasReadCount = false;
		if(isShowAll)
			this.PageSize = 0;
	}
	else {
		this.HasReadCount = false;
		if(this.ReadCountFromAgent) setTimeout(this.RefName+".GetRecordCount()",100);
	}
	this.Goto(this.CurrPage);
}

function ListRow(Href)
{
	this.Href = Href;//for OnClick default handler
	this.ColumnValues = new Array();
	this.AddColumnValue = ListRowAddColumnValue;
	this.DocUNID = "";
}

function ListRowAddColumnValue(ColVal)
{
	this.ColumnValues[this.ColumnValues.length] = ColVal;
}
//CreateColumms
function ListViewAddAllColumn(xml)
{
	var nodes = xml.selectNodes("/viewentries/viewentry");
	if(nodes == null) return null;
	if(nodes.length==0) return null;
	var subnodes = nodes[0].selectNodes("entrydata");
	var cc = subnodes.length 
	var attri;
	var nameattri;
	var width;
	var sorts;
	var align;
	var HideColumn;
	var Statistic;
	var numArr = this.HideColumnNum.split(":");
	for(var i=0;i<cc;i++) {   
		attri=subnodes[i].attributes.getNamedItem("name").text.split(":");
		nameattri=attri[0]?attri[0]:attri;
		width=attri[1]?attri[1]:"";
		align=attri[2]?(attri[2]=="0"?"left":(attri[2]=="2"?"right":"center")):"center"
		sorts=attri[3]?attri[3]:"0";
		wordnum=attri[4]?m_ParseInt(attri[4]):0;
		Statistic=attri[5]?attri[5]:"";
		if(this.ColumnPara.length>i)
			width=this.ColumnPara[i];  
		if(nameattri.toLowerCase()=="href")
			continue;
		for(var j=0,HideColumn=false; j<numArr.length; j++)
			if (parseInt(numArr[j],10)==i+1){
				HideColumn = true;
				break;
			}
		this.AddColumn(new ListColumn(i, nameattri, width, sorts, wordnum, HideColumn, Statistic));
		this.columnalign[i]=align;
	}
	this.createColumns=true;
}

function ListColumn(Name, Caption, Width, Sortable, wordnum, HideColumn, Statistic)
{
	this.Name = Name;
	this.Caption = Caption;
	this.Width = Width;
	this.Sortable = Sortable;
	this.WordNum = wordnum;
	this.HideColumn = HideColumn;
	this.Statistic = Statistic;
	if (Statistic!=""){
		this.RowNumber = 0;
		this.RowSum = 0;
	}
}

function ListViewAddColumn(Col)
{
	this.Columns[this.Columns.length] = Col;
}

function ListViewInsertColumn(Col, Idx)
{
	this.Columns = m_ArrayInsert(this.Columns, Idx, Col);
}

function ListViewAddRow(Row)
{
	this.Rows[this.Rows.length] = Row;
}

function ListViewShow()
{	
	var Result = "";
	if(this.Columns.length==0) {
        	if(this.TableElement != null)
        		this.TableElement.innerHTML = this.NoFileHtml;
		if(this.NavElementTop != null)
			this.NavElementTop.innerHTML = "";
		if(this.NavElementBottom != null)
			this.NavElementBottom.innerHTML = "";
		return null;
        }
	if(this.NavElementTop != null){
		this.NavElementTop.innerHTML = this.DrawNavBar("Top");
	}
	if(this.TableElement != null){
		this.TableElement.innerHTML = this.DrawTable();
	}
	if(this.NavElementBottom != null){
		this.NavElementBottom.innerHTML = this.DrawNavBar("Bottom");
	}
	if(this.HasReadCount) this.CheckLink();
}

function ListViewClear()
{
	this.Rows = new Array();
	if(!this.HasReadCount) {
		this.RecordCount = 0;
		this.RecordOffset = 1;
	}
	this.ComputeStatics();
}

function ListViewDrawAll()
{
	var Result = "";
	
	Result += this.DrawNavBar("Top");
	Result += this.DrawTable();	
	Result += this.DrawNavBar("Bottom");

	return Result;
}

function ListViewDrawTable()
{
	var Result = "";
	var tbclass="";
        if(this.TBClass!="") tbclass="class="+this.TBClass;
	Result += "<table "+tbclass+" id=VW_"+this.RefName+" width=100% border=0 style=\""+this.TableStyle+"\" cellpadding="+this.CellPadding+" cellspacing="+this.CellSpacing+">";
	if(this.HasColumns)Result += this.DrawColumns();
	Result += this.DrawRows();
	Result += "</table>";
	setTimeout("window.scrollTo(0,0);document.body.fireEvent('onscroll');",100);
	return Result;
}

function ListViewDrawColumns()
{
	var Result = "", SortStr = "", ImgSrc, SortHref;
	var i, c;
	var sorts;
        var thclass="";
        var tdclass="";
        if(this.THClass!="") thclass="class="+this.THClass;
        if(this.TDClass!="") tdclass="class="+this.TDClass;
	Result += "<tr "+thclass+" bgcolor="+this.ColumnColor+">";
	
	if(this.HasIndexColumn){
		Result += "<td valign=middle height=20 align=center nowrap width=30 "+tdclass+"><font color="+this.ColumnFontColor+">序号</font></td>";
	}
	if(this.HasCheckboxColumn){
		Result += "<td valign=middle height=20 align=center nowrap width=10><font color="+this.ColumnFontColor+">";
		if(this.CheckBoxType.toLowerCase()=="checkbox")
			Result += "<input type=checkbox style='width: 13; height: 13; border=0' onclick='"+this.RefName+".CheckAll();event.cancelBubble=true;'>";
		Result += "</font></td>";
	}
	
	c = this.Columns.length;
	for(i=0; i<c; i++){
		if (this.Columns[i].HideColumn)
			continue;
        //if(i>this.columnalign.length-1) sorts="center";
        //    else sorts=this.columnalign[i]; 
        sorts = "center";
		if(this.Columns[i].Sortable=="1"){
			var arrow;
			if(this.AscendSortColumn == i){
				ImgSrc = this.AscImage;
				SortHref = this.RefName+".SetSortColumn("+i+", 0)";
				arrow = "↑";
			}
			else if(this.DescendSortColumn == i){
				ImgSrc = this.DescImage;
				SortHref = this.RefName+".SetSortColumn("+i+", 1)";
				arrow = "↓";
			}
			else{
				ImgSrc = this.SortImage;
				SortHref = this.RefName+".SetSortColumn("+i+", 0)";
				arrow="";
			}
		
			SortStr = "<a href='javascript:"+SortHref+"'>";
			Result += 
				"<td nowrap height=20 valign=middle align="+sorts+" width="+
				this.Columns[i].Width+" "+tdclass+">"+
				SortStr+"<font color="+this.ColumnFontColor+">"+this.Columns[i].Caption+"</font></a>"+arrow
				"</td>";
		}
		else if (this.Columns[i].Sortable=="2"){//Change the ViewName
				SortHref = this.RefName+".ChangeView("+i+")";
				SortStr = "<a href='javascript:"+SortHref+"'>";
				var arrow;
				var ViewNameStr = this.ViewName;
				var Key = i+1;
				var k = ViewNameStr.indexOf("_"+Key+"_1");
				var j = ViewNameStr.indexOf("_"+Key+"_2");
				if (k>0)
					arrow = "↑";
				else if(j>0)
					arrow = "↓";
				else
					arrow = "";
				Result += 
					"<td nowrap height=20 valign=middle align="+sorts+" width="+
					this.Columns[i].Width+" "+tdclass+">"+
					SortStr+"<font color="+this.ColumnFontColor+">"+this.Columns[i].Caption+"</font></a>"+arrow
					"</td>";
			}
		else{
			Result += 
				"<td nowrap height=20 align="+sorts+" valign=middle width="+
				this.Columns[i].Width+" "+tdclass+">"+
				"<font color="+this.ColumnFontColor+">"+this.Columns[i].Caption+"</font>"+
				"</td>";
		}
	}
	
	Result += "</tr>";
	return Result;
}

function ListViewDrawRows()
{
	var Result = "";
	var indent = "";        
	var i=0, c, ii, cc, offset;
	var sorts;
	var trclass="";
	var tdclass="";
	var celltext;

	if(this.TRClass!="") trclass="class="+this.TRClass;
	if(this.TDClass!="") tdclass="class="+this.TDClass;
	offset = this.RecordOffset;	
	c = this.Rows.length;
	for(; i<c; i++){
		if(i >= this.PageSize)break;
		Result += 
			"<tr "+trclass+" id="+this.RefName+"VWROW_"+i+" bgcolor="+
			(i==this.LastClickRow?this.RowColorFocused:(i%2==0?this.RowColor0:this.RowColor1))+
			" onMouseOver='javascript: "+this.RefName+".OnMouseOver("+i+
			")' onMouseOut='javascript: "+this.RefName+".OnMouseOut("+i+
			")' onClick='javascript: "+this.RefName+
			".OnRowClick("+i+
			");'>";
		if(this.HasIndexColumn){
			if(this.Rows[i].DocUNID!="") 
				Result += "<td height=20 align=center nowrap width=30 "+tdclass+">"+(offset++)+"</td>";
			else
				Result += "<td height=20 align=center nowrap width=30></td>";
		}
		if(this.HasCheckboxColumn){
			if(this.Rows[i].DocUNID!="") 
				Result += "<td valign=middle height=20 onclick='event.cancelBubble=true;' align=left nowrap width=10><input type="+this.CheckBoxType+" style='width: 13; height: 13; border=0' onclick='event.cancelBubble=true;' name=F_Selected value="+this.Rows[i].DocUNID+"></td>";
			else
				Result += "<td valign=middle height=20 onclick='event.cancelBubble=true;' align=left nowrap width=10></td>";
		}

		cc = this.Columns.length;
		if(this.Rows[i].position==0){
			for(ii=0; ii<cc; ii++){
				if (this.Columns[ii].HideColumn)
					continue;
				if(ii>this.columnalign.length-1) sorts="center";
				else sorts=this.columnalign[ii];
				if(ii >= this.Rows[i].ColumnValues.length){
					Result += "<td height=20 width="+this.Columns[ii].Width+" "+tdclass+">&nbsp;</td>";
				}else{
					celltext = this.GenerateTDTxt(i,ii);							
					Result += "<td height=20 width="+this.Columns[ii].Width+" "+tdclass+" align="+sorts+(this.Columns[ii].WordNum>0?" nowrap>":">")+celltext+"</td>";
				}
				switch(this.Columns[ii].Statistic.substring(0,1)){
				case "A":
				case "S":
					this.Columns[ii].RowSum=(i==0?0:this.Columns[ii].RowSum)+m_ParseFloat(this.Rows[i].ColumnValues[ii]);
				case "N":
					this.Columns[ii].RowNumber=(i==0?0:this.Columns[ii].RowNumber)+1;
				}
			}
		}else {
			indent=""
			for(ii=0;ii<this.Rows[i].position;ii++) indent="<img src=/icons/ecblank.gif width=16>"+indent;                 
			for(ii=0; ii<this.Rows[i].ColumnValues.length; ii++){
				if(ii>this.columnalign.length-1) sorts="center";
				else sorts=this.columnalign[ii];
				celltext = indent + this.GenerateTDTxt(i,ii);						
				if(ii == this.Rows[i].ColumnValues.length-1){
					Result += "<td height=20 colspan="+(cc-this.Rows[i].ColumnValues.length+1)+" "+tdclass+" align="+sorts+(this.Columns[ii].WordNum>0?" nowrap>":">")+celltext+"</td>";
				}else{
					Result += 
						"<td height=20 width="+this.Columns[ii].Width+" "+tdclass+" align="+sorts+(this.Columns[ii].WordNum>0?" nowrap>":">")+celltext+"</td>";
					indent="";
				}
			}
		}
		Result += "</tr>";
	}
	cc = this.Columns.length;
	for(ii=0; ii<cc; ii++){
		if (this.Columns[ii].HideColumn)
			continue;
		if (this.Columns[ii].Statistic!="")
			break;
	}
	if (ii<cc){
		Result += "<tr id="+this.RefName+"VWROW_"+i+" bgcolor="+(i%2==0?this.RowColor0:this.RowColor1)+" >";
		if(this.HasIndexColumn)
			Result += "<td height=20 align=left>&nbsp;</td>";
		if(this.HasCheckboxColumn)
			Result += "<td height=20 align=left>&nbsp;</td>";
		for(ii=0; ii<cc; ii++)
			if (!this.Columns[ii].HideColumn){
				switch(this.Columns[ii].Statistic.substring(0,1)){
				case "A":
					Result += "<td height=20 "+tdclass+">平均："+m_Round(this.Columns[ii].RowSum/this.Columns[ii].RowNumber,this.Columns[ii].Statistic.substring(1))+"</td>";
					break;
				case "S":
					Result += "<td height=20 "+tdclass+">总和："+m_Round(this.Columns[ii].RowSum,this.Columns[ii].Statistic.substring(1))+"</td>";
					break;
				case "N":
					Result += "<td height=20 "+tdclass+">个数："+this.Columns[ii].RowNumber+"</td>";
					break;
				default:
					Result += "<td height=20>&nbsp;</td>";
				}
			}
		Result += "</tr>";
		i++;
	}
	c = this.PageSize;
	for(; i<c; i++){
		Result += "<tr id="+this.RefName+"VWROW_"+i+" bgcolor="+(i%2==0?this.RowColor0:this.RowColor1)+" >";
		if(this.HasIndexColumn)
			Result += "<td height=20 align=left>&nbsp;</td>";
		if(this.HasCheckboxColumn)
			Result += "<td height=20 align=left>&nbsp;</td>";

		for(ii=0; ii<cc; ii++)
			if (!this.Columns[ii].HideColumn)
				Result += "<td height=20>&nbsp;</td>";
		Result += "</tr>";
	}
	return Result;
}

function ListViewDrawNavBar(Side)
{
 	var Result = "";
        var str_pre="Top";
        if(Side=="Bottom") str_pre="End";
	Result += "<table border=0 cellpadding="+this.CellPadding+" cellspacing=0 width=100%><tr><td nowrap>";

	Result += "<a id="+str_pre+"Head href='javascript:"+this.RefName+".Head()'>首页</a>&nbsp;&nbsp;";
	Result += "<a id="+str_pre+"Prev href='javascript:"+this.RefName+".Prev()'>前页</a>&nbsp;&nbsp;";
	Result += "<a id="+str_pre+"Next href='javascript:"+this.RefName+".Next()'>后页</a>&nbsp;&nbsp;";
	if(! this.IsLargeMode) {Result += "<a id="+str_pre+"Last href='javascript:"+this.RefName+".Last()'>末页</a>&nbsp;&nbsp;";}
	Result += "<a id="+str_pre+"Refresh href='javascript:"+this.RefName+".Refresh()'>刷新</a>&nbsp;&nbsp;";

	Result += "</td><td align=right nowrap>";
	
	Result += "第<input type=text class=textdocnone id="+str_pre+"CurPage size=2 readonly=true value="+this.CurrPage+">页&nbsp;&nbsp;";
	if(! this.IsLargeMode ) {Result += "共<input type=text class=textdocnone id="+str_pre+"TotalPage size=5 readonly=true value="+this.TotalPage+">页&nbsp;&nbsp;";}
	
	Result += "每页&nbsp;<input type=text class=InputView name='VW_PageSize_"+Side+"' size=2 value="+this.PageSize+" onKeyPress='if(event.keyCode==&quot;13&quot;) btnGo"+Side+".click()'>&nbsp;条&nbsp;&nbsp;";
	if(!this.IsLargeMode ) {Result += "共<input type=text class=textdocnone id="+str_pre+"count size=5 readonly=true value="+this.RecordCount+">条&nbsp;&nbsp;";}
	if(!this.IsLargeMode ){
		Result += "到第&nbsp;<input type=text class=InputView name='VW_CurrPage_"+Side+"' size=2 value="+this.CurrPage+" onKeyPress='if(event.keyCode==&quot;13&quot;) btnGo"+Side+".click()'>&nbsp;页&nbsp;";
		Result += "<img id=btnGo"+Side+" style='cursor: hand' title='转到' align=absmiddle src='"+this.ImgGo+"' onClick=\""+this.RefName+".Turn('"+Side+"');\">";
	}else{
		Result += "<input type=text style='display:none' class=InputView name='VW_CurrPage_"+Side+"' size=2 value="+this.CurrPage+">";	
		Result += "到第&nbsp;<select name='VW_SelectedPage_"+Side+"' class=selectmenu onchange=\"document.forms[0].VW_CurrPage_"+Side+".value = this.options[this.selectedIndex].value;\">";
		for(var p_i=1;p_i<=this.HasViewedMaxPage;p_i++){
			if(p_i==this.CurrPage){Result += "<option value="+p_i+" selected>"+p_i;}
			else{Result += "<option value="+p_i+">"+p_i;}
		}
		Result += "<option value="+p_i+">next";
		Result += "</select>&nbsp;页&nbsp;";
		Result += "<img id=btnGo"+Side+" style='cursor: hand' title='转到' align=absmiddle src='"+this.ImgGo+"' onClick=\""+this.RefName+".Turn('"+Side+"');\">";
		}
	Result += "</td></tr></table>";
	
	return Result;
}
function ListViewTurn(Side)
{
	var obj = eval("document.all.VW_PageSize_"+Side);
	var NewSize = m_ParseInt(obj.value);
	if (NewSize<5 || NewSize>500){
		alert("每页显示的条目数必需为整数，并且在5～500之间！");
		obj.focus();
		obj.select();
		return;
	}
	obj = eval("document.all.VW_CurrPage_"+Side);
	var PageNO = m_ParseInt(obj.value);
	if(! this.IsLargeMode){
		var NewTotalPage = m_ParseInt(this.RecordCount/NewSize);
		if(this.RecordCount % NewSize > 0)
			NewTotalPage = NewTotalPage + 1;
		if (PageNO<1){
			alert("跳转页面数必需为正整数，并且在1～"+NewTotalPage+"之间！");
			obj.focus();
			obj.select();
			return;
		}
	}
	
	if(PageNO > NewTotalPage){
		if (!confirm("跳转页面超出总页面范围，是否跳转到最后一页？")){
			obj.focus();
			obj.select();
			return;
		}
	}
	this.PageSize = NewSize;
	this.Goto(PageNO);
}
function ListViewOnRowClick(RowNumber)
{
	if(this.CustomOnRowClick != null){
		this.CustomOnRowClick(RowNumber);
	}
	else{
		if(this.NavEnabled != true)return;
		if(this.Rows[RowNumber].Href != ""){
			var href = this.Rows[RowNumber].Href;
			if(href.substring(0, 11).toLowerCase()== "javascript:"){
        if(href.indexOf('http://') ==-1 && href.indexOf('https://') ==-1){
          // window.open("ag_opendoc?openagent&Docid="+docid+"&UserAD="+escape(document.all.F_CurUser.value));
          eval(href);
          // if(decodeURI(location.href).indexOf('Info=待办&Path=待办')!=-1){
          //   window.open("ag_opendoc?openagent&Docid="+this.Rows[RowNumber].DocUNID+"&UserAD="+escape(document.all.F_CurUser.value),'_self');
          // } else {
          //   eval(href);
          // }
        } else {
          var originHref = href.slice(20,-3);
          if(originHref.indexOf('%u')!=-1){
            originHref = encodeURI(unescape(originHref));
          }
          ysp.appMain.openWindow(originHref);
        }
			}else{
				if(href.substring(0, 7).toLowerCase() != "http://")href = this.NavHost+href;
				href += "&m_Seq="+Math.random();
				// window.open(href, this.Target);
         if(href.indexOf('http://') ==-1 && href.indexOf('https://') ==-1){
          href = window.location.origin +href;
        }
        ysp.appMain.openWindow(href);
			}
		}
	}
	
	if(this.LastClickRow != RowNumber){
		var row = eval("document.all.VWROW_"+this.LastClickRow);
		if(row != null)row.bgColor = (this.LastClickRow%2==0?this.RowColor0:this.RowColor1);
		this.LastClickRow = RowNumber;	
	}	
}
//--------------
function ListViewOnRowUserClick(RowNumber)
{
	if(this.CustomOnRowClick != null){
		this.CustomOnRowClick(RowNumber);
	}
	else{
		if(this.NavEnabled != true)return;
		if(this.Rows[RowNumber].Href != ""){
			var href = this.Rows[RowNumber].Href;
			if(href.substring(0, 11).toLowerCase()== "javascript:"){
				eval(href.substring(11));
			}else{
				if(href.substring(0, 7).toLowerCase() != "http://")href = this.NavHost+href;
				href += "&m_Seq="+Math.random();
				window.open(href, this.Target,"toolbar=no,menubar=no,scrollbars=yes,resizable=yes, location=no,status=no");
			}
		}
	}
	
	if(this.LastClickRow != RowNumber){
		var row = eval("document.all.VWROW_"+this.LastClickRow);
		if(row != null)row.bgColor = (this.LastClickRow%2==0?this.RowColor0:this.RowColor1);
		this.LastClickRow = RowNumber;	
	}	
}
//---------------------
function ListViewOnMouseOver(RowNumber)
{
	var tb, elems;
	
	if(this.CustomOnMouseOver != null){
		this.CustomOnMouseOver(RowNumber);
	}
	else{
		if(this.NavEnabled != true)return;
		if(this.Rows[RowNumber].Href != ""){
			row = eval("document.all."+this.RefName+"VWROW_"+RowNumber);
			if(row != null){
				row.bgColor = this.RowColorFocused;
				row.style.cursor = "hand";
				status = this.Rows[RowNumber].Href;
			}
		}
	}
}

function ListViewOnMouseOut(RowNumber)
{
	var row;
	
	if(this.CustomOnMouseOut != null){
		this.CustomOnMouseOut(RowNumber);
	}
	else{
		if(this.NavEnabled != true)return;
		if(this.Rows[RowNumber].Href != ""){
			row = eval("document.all."+this.RefName+"VWROW_"+RowNumber);
			if(row != null)row.bgColor = (RowNumber==this.LastClickRow?this.RowColorFocused:(RowNumber%2==0?this.RowColor0:this.RowColor1));
			status = "";
		}
	}
}

function ListViewTransformXML(xml)
//	return:
//		1: RecordCount > 0, and some records were read
//		0: RecordCount > 0, but PageNO out of range, no records were read
//		-1: RecordCount = 0, and no records were read
{
	var rc = GetEntriesCount(xml);
	if(rc > 0){
		var rows = this.LocateColumnByName?this.PopulateByColumn(xml, this.Columns):this.Populate(xml);
		if(rows!=null && rows.length>0){
			if(this.Processtext!=null) {
				for(var i=0;i<rows.length;i++)       
					for(var j=0;j<rows[i].ColumnValues.length;j++)
						rows[i].ColumnValues[j]=this.Processtext(rows[i].ColumnValues[j],i,j);
			}
			this.Rows = rows;
			//this.Rows = this.SortRows(rows);
			if(!this.HasReadCount) {
				this.HasReadCount=true;
				this.RecordCount = rc;       
			}
			//this.RecordOffset = GetEntriesOffset(xml);
			this.ComputeStatics();
			return 1;
		}else{
			this.Rows = new Array();
			if(!this.HasReadCount) {
				this.HasReadCount=true;
				this.RecordCount = rc;
			}
			//this.RecordOffset = this.CurrPage;
			this.ComputeStatics();
			return 0;
		}
	}else{//rc <= 0
		if(rc == 0){                       
			this.Clear();
			return -1;
		}else return -3;//XML string has no attribute of "toplevelentries"
	}
}

function ListViewTransformXMLStr(xmlstr)
//	return:
//		1: RecordCount > 0, and some records were read
//		0: RecordCount > 0, but PageNO out of range, no records were read
//		-1: RecordCount = 0, and no records were read
//		-2: Browser not support XML3.0 or Networks error.
{
	var xml = RequestXMLFromStr(xmlstr);     
	return xml==null ? -2 : this.TransformXML(xml);
}

function ListViewLoadXMLDataSource(url)
//	return:
//		1: RecordCount > 0, and some records were read
//		0: RecordCount > 0, but PageNO out of range, no records were read
//		-1: RecordCount = 0, and no records were read		
//		-2: Browser not support XML3.0 or Networks error.
{
       	var xml = this.OnQueryXML(url);
        if(!this.createColumns) this.AddAllColums(xml);
    	return xml==null ? -2 : this.TransformXML(xml);
}

function ListViewLoadXMLStr(xmlstr)
{
	window.status = "正在读取数据...";
	var RetVal = this.TransformXMLStr(xmlstr);
	
	if(RetVal==1 || RetVal==-1)this.Show();
	else if(RetVal == 0){
		if(!this.Silence)alert("超出有效页数范围");
	}
	else if(RetVal == -2){
		this.Show();
		if(!this.Silence)alert("网络连接失败 或 浏览器不支持MSXML3.0/ActiveX");
	}
	else if(RetVal == -3){
		if(this.CurrPage > 1)this.Prev();
		else{
			this.Clear();
			this.Show();
		}
	}
	window.status = "完成";
}

//
//	NoteView XML output parsing Utilities:
//

function RequestXML(url)
{
	try{
		var xml = new ActiveXObject("MSXML.DOMDocument");
		if(xml != null){
			xml.async = false;
			if(xml.load(url)) {
                           return xml;
                        }
		}
	}
	catch(err){
	}
	return null;
}

function RequestXMLFromStr(xmlstr)
{
	try{
		var xml = new ActiveXObject("MSXML.DOMDocument");
		if(xml != null){
			xml.async = false;
			if(xml.loadXML(xmlstr))return xml;
		}
	}
	catch(err){
	}
	return null;
}

function GetEntriesCount(xml)
//return: -1, no this node
{
	var node = null;
	var nodes = xml.selectNodes("/viewentries");
	if(nodes!=null && nodes.length>0)node = nodes[0];
	if(node != null){
		var NumStr = node.getAttribute("toplevelentries");
		//alert(NumStr);
		if(NumStr==null || NumStr=="")return -1;
		var Result = m_ParseInt(NumStr);
		nodes = node.selectNodes("viewentry");
		return Result >= nodes.length ? Result : nodes.length;
	}
	else return -1;
}

function XMLGetChildNodeText(XmlNode, ChildNodeName)
{
	var Node = null, AttrNode;
	
	Node = XmlNode.firstChild;
	while(Node != null){
		AttrNode = Node.getAttributeNode("name");
		if(AttrNode != null && AttrNode.nodeValue == ChildNodeName) {
                 return Node.text;
                }
		Node = Node.nextSibling;
	}
	return "";
}

function XMLGetNodeTextList(node, indexed, sep)
//Separate multi-value text
{
	var i;
	var Result;
	
	var subnodes = node.selectNodes("textlist");
	if(subnodes!=null && subnodes.length>0){
		subnodes = subnodes[0].selectNodes("text");
		if(subnodes!=null && subnodes.length>0){
			Result = subnodes[0].text;
			if(subnodes.length > 1){
				if(indexed != true)return Result+"...";				
				Result = "(1)"+Result;
				for(i=1; i<subnodes.length; i++)Result += sep+"("+(i+1)+")"+subnodes[i].text;
			}
			return Result;
		}
	}

	return node.text;
}

function XMLGetChildNodeTextList(XmlNode, ChildNodeName, indexed, sep)
//XMLNode should have attribute named as "name"
{
	var Node = null, AttrNode;
	
	Node = XmlNode.firstChild;
	while(Node != null){
		AttrNode = Node.getAttributeNode("name");
		if(AttrNode != null && AttrNode.nodeValue == ChildNodeName)return XMLGetNodeTextList(Node, indexed, sep);
		Node = Node.nextSibling;
	}
	return "";
}

function GetEntriesOffset(xml)
{
	var nodes = xml.selectNodes("/viewentries/viewentry");
	if(nodes!=null && nodes.length>0)return m_ParseInt(nodes[0].getAttribute("position"));
	return -1;
}

function ListViewPopulateByColumn(xml, ListColumns)
{
	var row, rows;
	var node, UNIDAttrNode;
	var i, c, ii, cc;
	var subnodes;

	var nodes = xml.selectNodes("/viewentries/viewentry");
	if(nodes == null)return null;
	
	rows = new Array();
	
	c = nodes.length;
	for(i=0; i<c; i++){
		node = nodes[i];
		subnodes = node.selectNodes("entrydata");
		if(subnodes == null || subnodes.length<=0)continue;
		
		cc = subnodes.length;
		if(cc>ListColumns.length)cc = ListColumns.length;
		
		row = new ListRow(XMLGetChildNodeText(node, "Href"));
		row.ColumnValues = new Array();
		
		for(ii=0; ii<cc; ii++){
			row.ColumnValues[ii] = XMLGetChildNodeText(node, ListColumns[ii].Name, true, "<br>");
		}
		
		UNIDAttrNode = node.attributes.getNamedItem("unid");
		if(UNIDAttrNode != null)row.DocUNID = UNIDAttrNode.text;
		else row.DocUNID = "";

		rows[i] = row;
	}
	
	return rows;
}

function ListViewPopulate(xml)
{
	var row, rows;
	var node, UNIDAttrNode,position;
	var i, c, ii, cc,j;
	var subnodes;
	var nodes = xml.selectNodes("/viewentries/viewentry");
	if(nodes == null)return null;
	
	rows = new Array();
	
	c = nodes.length;
	for(i=0; i<c; i++){
		node = nodes[i];
		subnodes = node.selectNodes("entrydata");
		if(subnodes == null || subnodes.length<=0)continue;
		
		cc = subnodes.length;
		
		var ColumnValues = new Array();
		for(ii=0; ii<cc; ii++){
			ColumnValues[ii] = XMLGetNodeTextList(subnodes[ii], this.IndexTextList, "<br>");
		}
		
		//row = new ListRow(ColumnValues[ColumnValues.length-1]);//the last column must be "href";
               UNIDAttrNode = node.attributes.getNamedItem("unid");     
               var hrefvalue=XMLGetChildNodeText(node, "Href");
               if(this.AutoLink && hrefvalue=="" && UNIDAttrNode!=null) {
                    hrefvalue=this.NavHost+this.NsfPath+this.ViewName+"/"+UNIDAttrNode.text+"?opendocument"
                   }
                row = new ListRow(hrefvalue);
		           
//计算层次开始
                position=node.attributes.getNamedItem("position").text;
                row.PositionNum=position;
                 j=0;
                while(position.indexOf(".")>-1) {
                 position=position.substring(position.indexOf(".")+1,position.length);
                 j++;
                 }
                row.position=j;
         	if(UNIDAttrNode != null)row.DocUNID = UNIDAttrNode.text;
		else row.DocUNID = "";
 		cc--;                
    		for(ii=0; ii<=cc; ii++){	
			row.ColumnValues[ii] =ColumnValues[ii];
		}
		rows[i] = row;
	}
	
	return rows;
}

function ListViewRefreshStatics()
 { 
   if(document.all.TopCurPage!=null) document.all.TopCurPage.value=this.CurrPage;   
   if(document.all.EndCurPage!=null) document.all.EndCurPage.value=this.CurrPage;
   if(document.all.TopTotalPage!=null) document.all.TopTotalPage.value=this.TotalPage;
   if(document.all.EndTotalPage!=null) document.all.EndTotalPage.value=this.TotalPage;
   if(document.all.Topcount!=null) document.all.Topcount.value=this.RecordCount;
   if(document.all.Endcount!=null) document.all.Endcount.value=this.RecordCount;
   this.CheckLink();
   }

function ListViewCheckLink()
{	
	if(this.IsLargeMode){
		try{
 			var ThePageNO = this.CurrPage+1;
			if(ThePageNO < 1)ThePageNO = 1;
			if(ThePageNO > thisView.TotalPage) ThePageNO = thisView.TotalPage;
			var start=(ThePageNO-1)*thisView.PageSize+1;
			if(thisView.IsReadStartCount && ThePageNO>1) {
				start=thisView.ReadStartCount(start);
				if(start==""){
       				this.TotalPage =this.CurrPage;
       				this.HasViewedMaxPage = this.CurrPage;
       				this.IsLastPage = true;
				}else{
					if(start!="" && this.CurrPage==this.HasViewedMaxPage)this.IsLastPage = false;
				}
			}
		}catch(err){}
	}
	if(this.CurrPage==this.TotalPage)this.IsLastPage = true;
	if(this.IsLastPage){		
		var objT = document.forms[0].VW_SelectedPage_Top;
       	var objB = document.forms[0].VW_SelectedPage_Bottom;
       	if (objT!=null){
       		objT.options[objT.options.length-1]=null;
       		objB.options[objB.options.length-1]=null;
       	}
    }
	if(!this.HasReadCount) return null;
	if(this.CurrPage==1){
		if(document.all.TopHead!=null && document.all.TopHead.href!=null)
			document.all.TopHead.removeAttribute("href");
		if(document.all.EndHead!=null && document.all.EndHead.href!=null)
			document.all.EndHead.removeAttribute("href");
		if(document.all.TopPrev!=null && document.all.TopPrev.href!=null)
			document.all.TopPrev.removeAttribute("href");
		if(document.all.EndPrev!=null && document.all.EndPrev.href!=null)
			document.all.EndPrev.removeAttribute("href");
	}else{
		if(document.all.TopHead!=null)
			document.all.TopHead.setAttribute("href","javascript:"+this.RefName+".Head();");
		if(document.all.EndHead!=null)
			document.all.EndHead.setAttribute("href","javascript:"+this.RefName+".Head();");
		if(document.all.TopPrev!=null)
			document.all.TopPrev.setAttribute("href","javascript:"+this.RefName+".Prev();");
		if(document.all.EndPrev!=null)
			document.all.EndPrev.setAttribute("href","javascript:"+this.RefName+".Prev();");
	}
	if(this.CurrPage==this.TotalPage){
		if(document.all.TopNext!=null && document.all.TopNext.href!=null)
			document.all.TopNext.removeAttribute("href");
		if(document.all.EndNext!=null && document.all.EndNext.href!=null)
			document.all.EndNext.removeAttribute("href");
		if(document.all.TopLast!=null && document.all.TopLast.href!=null)
			document.all.TopLast.removeAttribute("href");
		if(document.all.EndLast!=null && document.all.EndLast.href!=null)
			document.all.EndLast.removeAttribute("href");
	}else{
		if(document.all.TopNext!=null)
			document.all.TopNext.setAttribute("href","javascript:"+this.RefName+".Next();");
		if(document.all.EndNext!=null)
			document.all.EndNext.setAttribute("href","javascript:"+this.RefName+".Next();");
		if(document.all.TopLast!=null)
			document.all.TopLast.setAttribute("href","javascript:"+this.RefName+".Last();");
		if(document.all.EndLast!=null)
			document.all.EndLast.setAttribute("href","javascript:"+this.RefName+".Last();");
	}
}
function ListViewSortRows(rows)
{
	var sortnums = new Array();
	var maxval = new Array();
	if (rows.length==0)
		return rows;
	for(var i=0; i<this.Columns.length; i++)
		if (this.Columns[i].Sortable>"1")
			sortnums[sortnums.length] = i;
	if (sortnums.length==0)
		return rows;
	var newrows = new Array();
	var maxi;
	for (var i=0; i<rows.length; i++){
		maxi=-1;
		for(var j=0; j<rows.length; j++)
			if (rows[j]!=null){
				for (var k=0; k<sortnums.length; k++){
					if(maxi>-1 && rows[j].ColumnValues[sortnums[k]]==maxval[k])
						continue;
					if
					(
						maxi==-1
						|| ((this.Columns[sortnums[k]].Sortable=="2")?-1:1)==this.Compare(rows[j].ColumnValues[sortnums[k]],maxval[k], k)
					)
					{
						maxi = j;
						for (var kk=0; kk<sortnums.length; kk++)
							maxval[kk]=rows[j].ColumnValues[sortnums[kk]];
					}
					break;
				}
			}
		newrows[i] = rows[maxi];
		rows[maxi] = null;
	}
	return newrows;
}

function ListViewCompare(x, y, column)
{
	if (x>y) return 1;
	if (x==y) return 0;
	return -1;
}

function ListViewGenerateTDTxt(RowNum,columnsNum)
{
	try{
		var celltext = this.Rows[RowNum].ColumnValues[columnsNum];
		var WordNum = this.Columns[columnsNum].WordNum;
		if(screen.availWidth!=800) WordNum = parseInt(WordNum*screen.availWidth/800);	
		if (WordNum>0){
			var re = /\"/g;
			if (m_CalculateText(celltext)>WordNum)
				celltext = "<div title=\""+celltext.replace(re,"&quot;")+"\">"+m_Substring(celltext,WordNum-2)+"...</div>";
			else
				celltext = "<div title=\""+celltext.replace(re,"&quot;")+"\">"+celltext+"</div>";
		}	
		return celltext;
	}catch(e){}
}
//----------------------------------------------------------------
function ListViewOnPostViewReload()
{	
	RTComShow();
}
function ListViewChangeView(ColumnNO)
{
	var column = ColumnNO + 1;
	var ascendStr = "_"+column+"_1";
	var descendStr = "_"+column+"_2";
	var ViewNameStr = this.ViewName;
	var NavPathStr = this.NavPath;
	var i = ViewNameStr.indexOf(ascendStr);
	var j = ViewNameStr.indexOf(descendStr);
	if(i>0)
		this.ViewName = ViewNameStr.substring(0,ViewNameStr.lastIndexOf("_1"))+"_2";
	else if(j>0)
		this.ViewName = ViewNameStr.substring(0,j);
	else{
		var tmpStr = ViewNameStr;
		var plusStr = "";
		while (tmpStr.lastIndexOf("_") != -1){
			plusStr = tmpStr;
			tmpStr = tmpStr.substring(0,tmpStr.lastIndexOf("_"));
		}
		this.ViewName = plusStr+ascendStr;
	}
	NavPathStr = NavPathStr.substring(0,NavPathStr.indexOf(ViewNameStr));
	NavPathStr = NavPathStr+this.ViewName+"?ReadViewEntries&PreFormat";
	if (this.RestrictToCategory != "")
		this.NavPath = NavPathStr + "&RestrictToCategory=" + escape(this.RestrictToCategory);
	else
		this.NavPath = NavPathStr
	this.Refresh();
}
