(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control73_Lhk29C: function (elem) {
      if (elem) {
        return "添加审批人员";
      }
    },
    doAction_uiControl85_xOm65T: function (data, elem) {},
    getTemplate_uiControl85_xOm65T: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },

    getData_control75_tU5KFD: function (elem) {
      if (elem) {
        var data = { label: [], content: [] };function getFieldValue($field) {
          switch ($field.attr("type")) {case "radio":
              if ($field.attr("checked") != undefined) {
                return true;
              }return false;break;case "checkbox":
              return $field[0].checked;break;default:
              return $field.val() || $field.text();break;}
        }function getFieldText($field) {
          switch ($field.attr("type")) {case "radio":
              return $field.next("span").text();break;case "checkbox":
              return $field.next("span").text() || $field[0].nextSibling.nodeValue && $field[0].nextSibling.nodeValue.trim();break;default:
              return $field.val() || $field.text();break;}
        }function getFieldOptions($field) {
          var options = [];$field.children("option").each(function (opi, op) {
            options.push({ value: $(op).val(), text: $(op).text(), selected: $(op).selected });
          });return options;
        }function gettrValue($td) {
          var tdDataList = [];$td.find("input,select,textarea,a").each(function () {
            switch ($(this)[0].tagName) {case "INPUT":
                if ($(this).css("display") != "none") {
                  tdDataList.push({ type: $(this).attr("type") || "text",
                    value: getFieldValue($(this)), text: getFieldText($(this)) });
                }break;case "SELECT":
                tdDataList.push({ type: "select", value: getFieldValue($(this)), text: getFieldText($(this)), options: getFieldOptions($(this)) });break;case "TEXTAREA":
                break;case "A":
                if ($(this).parent().css("display") != "none") {
                  tdDataList.push({ type: "button", value: getFieldValue($(this)), text: getFieldText($(this)) });
                }break;default:
                tdDataList.push({ type: "input", value: getFieldValue($(this)), text: getFieldText($(this)) });break;}
          });return tdDataList;
        }function gettabData($tr) {
          var trDataList = [];$tr.find("fieldset>legend+table>tbody>tr").each(function (stri) {
            if ($(this).children("td").length > 1 && $(this).children("td").text()) {
              trDataList.push({ label: $(this).children("td").eq(0).text(), value: gettrValue($(this).children("td").eq(1)) });
            }
          });return trDataList;
        }$(elem).find("#thd").children("input[type='button']").each(function (index, input) {
          if ($(this).css("display") != "none") {
            data.label.push({ actived: false, value: $(this).attr("value"), index: $(this).attr("id").match(/\d+/g)[0]
            });
          }
        });$(elem).children("tbody").children("tr.trbg").each(function (tri) {
          data.content.push(gettabData($(this)));
        });return data;
      }return;
    },
    doAction_uiControl87_c4LkJI: function (data, elem) {
      switch (data.eventType) {case "selectReviewer":
          $(elem).find("#aSelect").click();break;default:
          break;}
    },
    getTemplate_uiControl87_c4LkJI: function () {
      var selfTemplate = "var GlobalTab = require('ysp-custom-components').GlobalTab;\nconst {Group,Field,Choose,List,Button,Select} = AMUITouch2;\nmodule.exports = React.createClass({\n  getInitialState:function(){\n    var data = this.props.customData;\n    return {\n      data:data,\n      tabContent:data.content[0],\n      active:0\n    }\n  },\n  handler:function(data){\n    this.setState({\n      tabContent:this.state.data.content[data.data.item.index-1],\n      active:data.data.index\n    })\n    var callback=this.props.customHandler;\n    if(callback){\n      callback(data)\n    }\n  },\n  renderField:function(field){\n    var _this = this;\n    switch(field.type){\n      case \"select\":\n        return <Field\n                 type=\"text\"\n                 disabled\n                 value={field.value}\n                 />\n        break;\n        \n      case \"checkbox\":\n        return <Field \n                 type={field.type}\n                 disabled\n                 value={field.value}\n                 labelAfter={field.text}\n                 />\n        break;\n      \n      case \"radio\":\n        return <Field \n                 type={field.type}\n                 disabled\n                 value={field.value}\n                 labelAfter={field.text}\n                 />\n        break;\n      \n      case \"button\":\n        return <Button onClick={function(){\n            _this.selectReviewer()\n          }}>{field.text}</Button>\n        break;  \n        \n      default:\n        return <Field\n                 type={field.type}\n                 disabled\n                 value={field.value}\n                 />\n        break;\n    }\n  },\n  selectReviewer:function(){\n    var callback=this.props.customHandler;\n    if(callback){\n      callback({\n        eventType:\"selectReviewer\",\n        data:\"\"\n      })\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData\n    return <div className=\"flowchart-selector-reviewer-container\">\n      <GlobalTab data={data.label} type=\"nomal\" callback={_this.handler} active={_this.state.active}/>\n      <div className=\"flowchart-selector-reviewer\">\n          <div>\n            {\n              _this.state.tabContent&&_this.state.tabContent.map(function(tab,index){\n\t\t\t\t\t\t\t\treturn (\n                  <div className=\"flowchart-selector-content\">\n                    <div className=\"flowchart-selector-label\">{tab.label}</div>\n                    <div className=\"flowchart-selector-field\">\n                      {\n                        tab.value&&tab.value.map(function(field){\n                          return _this.renderField(field)\n                        })\n                      }\n                    </div>\n                </div>\n                 )\n              })\n            }\n          </div>\n      </div>\n    </div>\n  }\n});";
      return "\"use strict\";\n\nvar GlobalTab = require('ysp-custom-components').GlobalTab;\nvar _AMUITouch = AMUITouch2,\n    Group = _AMUITouch.Group,\n    Field = _AMUITouch.Field,\n    Choose = _AMUITouch.Choose,\n    List = _AMUITouch.List,\n    Button = _AMUITouch.Button,\n    Select = _AMUITouch.Select;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  getInitialState: function getInitialState() {\n    var data = this.props.customData;\n    return {\n      data: data,\n      tabContent: data.content[0],\n      active: 0\n    };\n  },\n  handler: function handler(data) {\n    this.setState({\n      tabContent: this.state.data.content[data.data.item.index - 1],\n      active: data.data.index\n    });\n    var callback = this.props.customHandler;\n    if (callback) {\n      callback(data);\n    }\n  },\n  renderField: function renderField(field) {\n    var _this = this;\n    switch (field.type) {\n      case \"select\":\n        return React.createElement(Field, {\n          type: \"text\",\n          disabled: true,\n          value: field.value\n        });\n        break;\n\n      case \"checkbox\":\n        return React.createElement(Field, {\n          type: field.type,\n          disabled: true,\n          value: field.value,\n          labelAfter: field.text\n        });\n        break;\n\n      case \"radio\":\n        return React.createElement(Field, {\n          type: field.type,\n          disabled: true,\n          value: field.value,\n          labelAfter: field.text\n        });\n        break;\n\n      case \"button\":\n        return React.createElement(\n          Button,\n          { onClick: function onClick() {\n              _this.selectReviewer();\n            } },\n          field.text\n        );\n        break;\n\n      default:\n        return React.createElement(Field, {\n          type: field.type,\n          disabled: true,\n          value: field.value\n        });\n        break;\n    }\n  },\n  selectReviewer: function selectReviewer() {\n    var callback = this.props.customHandler;\n    if (callback) {\n      callback({\n        eventType: \"selectReviewer\",\n        data: \"\"\n      });\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    return React.createElement(\n      \"div\",\n      { className: \"flowchart-selector-reviewer-container\" },\n      React.createElement(GlobalTab, { data: data.label, type: \"nomal\", callback: _this.handler, active: _this.state.active }),\n      React.createElement(\n        \"div\",\n        { className: \"flowchart-selector-reviewer\" },\n        React.createElement(\n          \"div\",\n          null,\n          _this.state.tabContent && _this.state.tabContent.map(function (tab, index) {\n            return React.createElement(\n              \"div\",\n              { className: \"flowchart-selector-content\" },\n              React.createElement(\n                \"div\",\n                { className: \"flowchart-selector-label\" },\n                tab.label\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"flowchart-selector-field\" },\n                tab.value && tab.value.map(function (field) {\n                  return _this.renderField(field);\n                })\n              )\n            );\n          })\n        )\n      )\n    );\n  }\n});";
    },
    getData_control74_96BGE2: function (elem) {
      if (elem) {
        var data = [];$(elem).find("input").each(function () {
          data.push($(this).val());
        });return data;
      }return;
    },
    doAction_uiControl86_zXFpBm: function (data, elem) {
      switch (data.eventType) {case "click":
          $(elem).find("input").eq(data.customData).click();break;}
    },
    getTemplate_uiControl86_zXFpBm: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    return (\n      <GlobalFooterBtn data={data} type=\"normal\" callback={_this.props.customHandler}/>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { data: data, type: \"normal\", callback: _this.props.customHandler });\n  }\n});";
    }
  }, "Flowchart_SelectPeople");
})(window, ysp);