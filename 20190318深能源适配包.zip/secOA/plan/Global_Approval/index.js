(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control8_FdTntr: function (elem) {
      return '常用审批语';
    },
    doAction_uiControl8_xNGToE: function (data, elem) {},
    getTemplate_uiControl8_xNGToE: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData || '\u5E38\u7528\u5BA1\u6279\u8BED';\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "'use strict';\n\nvar _appRenderer = require('appRenderer');\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  render: function render() {\n    var data = this.props.customData || '\u5E38\u7528\u5BA1\u6279\u8BED';\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },

    getData_control49_W7wvI7: function (elem) {
      if (!elem) {
        return;
      }var data = [];var collapseData = [];function initSelect($select, item) {
        var select = {};select.options = [];select.type = 'select';select.trIndex = item.trIndex;select.name = $select.attr('name');select.id = $select.attr('id');$select.find('option').each(function () {
          if (this.selected) {
            select.value = $(this).val();
          }select.options.push({ value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
        });return select;
      }$(elem).children('tbody').children('tr').each(function (i, tr) {
        var trId = this.getAttribute('id') || '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none' || $(this).find('#ReviewLog_TD').length) {
          return;
        }$tds.each(function (j, td) {
          if (j % 2 == 0 && $tds[j + 1]) {
            var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
              return;
            }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, trIndex: i };var $select = $oddTd.find('select');if ($select.length) {
              item.select = [];$select.each(function (i, select) {
                var selectObj = initSelect($(select), item);item.select.push(selectObj);
              });
            }var $inputs = $oddTd.find('input');if ($inputs.length) {
              $inputs.each(function (index, input) {
                var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden) {
                  return;
                }var type = input.type;item.type = type;var inputObj = { trIndex: item.trIndex, index: index, type: type, text: $(this).parent().text(), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly, placeholder: this.placeholder };if (type == 'radio') {
                  inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;if (this.name == 'F_IsSignSms') {
                    inputObj.text = ['电子签名', '短信验证', '微信验证'][parseInt(this.value) - 1];
                  }inputObj.parentId = $(this).parent().attr('id');item.radios = item.radios || { trIndex: item.trIndex, type: type, name: this.name, options: [] };item.radios.options.push(inputObj);
                }if (type == 'checkbox') {
                  inputObj.text = $(this).next().text() || inputObj.text;inputObj.parentId = $(this).parent().attr('id');item.checkbox = item.checkbox || { trIndex: item.trIndex, type: type, name: this.name, options: [] };item.checkbox.options.push(inputObj);
                }if (type == 'button' || type == 'text') {
                  item.inputs = item.inputs || [];inputObj.label = this.parentNode.innerText || '';item.inputs.push(inputObj);
                }if (item.radios) {
                  item.inputLabel = this.parentNode.innerText;
                }
              });
            }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
              item.textarea = [];$textarea.each(function () {
                var textareaObj = { type: 'textarea', trIndex: item.trIndex, name: this.name, disabled: this.disabled, placeholder: this.placeholder, value: this.value };item.textarea.push(textareaObj);
              });
            }var $aLink = $oddTd.find('a');if ($aLink.length) {
              item.link = [];$aLink.each(function (i, a) {
                item.link.push({ trIndex: item.trIndex, index: i, text: a.textContent, type: 'link' });
              });
            }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea) {
              item.content = content;
            }if (!label) {
              return;
            }if ($.inArray(td0Text, ['当前处理人：', '即将流向：', '已处理人：', '特权人：']) != -1) {
              collapseData.push(item);
            } else {
              data.push(item);
            }
          }
        });
      });return { basicData: data, collapseData: collapseData };
    },
    doAction_uiControl62_hGpBz0: function (data, elem) {
      var oData = data.dataCustom;var $tr = $(elem).children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();var $input = $parent.find('[type="' + oData.type + '"]');if (oData.type == 'radio') {
              $tr.find('[type="' + oData.type + '"]').each(function () {
                if (this != $input[0]) {
                  this.checked = false;
                }
              });
            }$input[0].checked = !$input[0].checked;
          } else {
            $tr.find('input').eq(oData.index).click();
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var triggerElem = $tr.find('[name="' + oData.name + '"]');triggerElem.val(oData.value);
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          var $a = $tr.find('a').eq(oData.index);if ($a.attr('target') == "blank") {
            var href = $a[0].href;elem.ownerDocument.defaultView.open(href); // $a.attr('target', '_ysp_top');
          } else {
            $a.click();
          }
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl62_hGpBz0: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n     var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    const self = this;\n    const data = this.props.customData;\n \t\tif(!data || !data.basicData){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});\n";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || !data.basicData) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    }
  }, "GlobalAttachNew");
})(window, ysp);