(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control41_mKhp67: function (elem) {},
    doAction_uiControl53_ZM1IWr: function (data, elem) {},
    getTemplate_uiControl53_ZM1IWr: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nvar leftBar = <div className=\"navbar-nav navbar-left\">\n      <a onClick={back} className=\"navbar-nav-item\">\n        <span className=\"icon icon-left-nav icon-back\"></span>\n        <span className=\"navbar-nav-title\">\u8FD4\u56DE</span>\n      </a>\n    </div>;\nmodule.exports = React.createClass({\n  render: function() {\n   var data =this.props.data.customData; \n    return (\n        <Header amStyle=\"white\" title=\"\u5FAE\u4FE1\u9A8C\u8BC1\" children={leftBar} style={{background:\"#fff\"}}>\n     </Header>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nvar leftBar = React.createElement(\n  'div',\n  { className: 'navbar-nav navbar-left' },\n  React.createElement(\n    'a',\n    { onClick: _appRenderer.back, className: 'navbar-nav-item' },\n    React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n    React.createElement(\n      'span',\n      { className: 'navbar-nav-title' },\n      '\\u8FD4\\u56DE'\n    )\n  )\n);\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.data.customData;\n    return React.createElement(_yspInteriorComponents.Header, { amStyle: 'white', title: '\\u5FAE\\u4FE1\\u9A8C\\u8BC1', children: leftBar, style: { background: \"#fff\" } });\n  }\n});";
    },
    getData_control52_XW6361: function (elem) {
      var str = '';$(elem).find('b').each(function () {
        str = str + this.textContent;if (this.nextElementSibling && this.nextElementSibling.tagName == 'BR') {
          str = str + '\r\n';
        }
      });return str;
    },
    doAction_uiControl70_L0sAks: function (data, elem) {},
    getTemplate_uiControl70_L0sAks: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    return (\n      <pre>\n       {this.props.customData}\n      </pre>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      \"pre\",\n      null,\n      this.props.customData\n    );\n  }\n});";
    }
  });
})(window, ysp);