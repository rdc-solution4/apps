(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control48_RQJGCH: function (elem) {
      if (!elem) {
        return;
      }return elem.innerText;
    },
    doAction_uiControl21_CuoQ9y: function (data, elem) {},
    getTemplate_uiControl21_CuoQ9y: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\t\n  \treturn (<NavBar\n      title={data}\n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control52_GDpryv: function (elem) {
      if (!elem) {
        return;
      }function initGroupData(elem) {
        var data = [];$(elem).children('table').each(function (i) {
          var $tds = $(this).find('tbody>tr>td');var $imgs = $tds.eq(0).find('img');var text = $tds.eq(1).text();var item = { index: i, tableId: $(this).attr('id'), text: text, imgs: $imgs.length };if (~$tds.eq(1).find('a')[0].href.indexOf("OpenFolder") && !$tds.eq(0).find('a')[0]) {
            item.radio = true;
          } else {
            item.radio = false;
          }if ($tds.eq(1)[0].style.backgroundColor == "rgb(255, 255, 204)") {
            item.choose = true;
          } else {
            item.choose = false;
          }$imgs.each(function (i, e) {
            if (this.src.indexOf('nodeminus') != -1 || this.src.indexOf('openfolder') != -1) {
              item.nodeminus = true;
            }if (this.src.indexOf('nodeplus') != -1 || this.src.indexOf('closedfolder') != -1) {
              item.nodeplus = true;
            }
          });data.push(item);
        });return data;
      }return initGroupData(elem);
    },
    doAction_uiControl61_Udud7J: function (data, elem) {
      var event = data.eventType;var data = data.dataCustom;var _newtable = $(elem).children('table[id="' + data.tableId + '"]');if (event === 'expendNode') {
        _newtable.find('td').eq(0).find('a').click();
      }if (event === 'treeClick') {
        _newtable.find('td').eq(1).find('a').click();
      }
    },
    getTemplate_uiControl61_Udud7J: function () {
      var selfTemplate = "const { Field,Icon,Button,Title,Divide,Switch } = AMUITouch2;\n\nmodule.exports = React.createClass({\n  expendNode: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'expendNode',\n        data:e\n      })\n    }\n  },\n \ttreeClick: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'treeClick',\n        data:e\n      })\n    }\n  },\n  renderTree: function(data){\n    var _this = this;\n    return (\n      <div className='address-tree'>\n        {data.map(function(d, i){\n          var pLeft = (d.imgs)*10 + 'px';\n          var defalutStyle = {'text-algin':'left','padding-left':pLeft};\n          if(i == 0){\n            return (\n              <Title amStyle=\"primary\">{d.text}</Title>\n            )\n          }else{\n            return (\n              <div>\n                <div className=\"tree-item\" style={defalutStyle}>\n                  {d.nodeplus ? <span onClick={()=>{_this.expendNode(d)}} className='amt-tree-switcher amt-tree-noline_close'></span> : ''}\n                  {d.nodeminus ? <span onClick={()=>{_this.expendNode(d)}} className='amt-tree-switcher amt-tree-noline_open'></span> : ''}\n                  {!d.nodeminus && !d.nodeplus ? <span className='amt-tree-switcher'></span> : ''}\n                  <span onClick={()=>{_this.treeClick(d)}}>{d.text}</span>\n                </div>\n                {d.radio ? <Switch shape=\"checkbox\" checked={d.choose} onValueChange={()=>{_this.treeClick(d)}}/> : null}\n                <Divide />\n              </div>\n            )\n          }\n        })}\n      </div>\n    )\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <div className=\"fw-treebox\">\n        {data ? this.renderTree(data) : ''}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Icon = _AMUITouch.Icon,\n    Button = _AMUITouch.Button,\n    Title = _AMUITouch.Title,\n    Divide = _AMUITouch.Divide,\n    Switch = _AMUITouch.Switch;\n\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  expendNode: function expendNode(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'expendNode',\n        data: e\n      });\n    }\n  },\n  treeClick: function treeClick(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'treeClick',\n        data: e\n      });\n    }\n  },\n  renderTree: function renderTree(data) {\n    var _this = this;\n    return React.createElement(\n      'div',\n      { className: 'address-tree' },\n      data.map(function (d, i) {\n        var pLeft = d.imgs * 10 + 'px';\n        var defalutStyle = { 'text-algin': 'left', 'padding-left': pLeft };\n        if (i == 0) {\n          return React.createElement(\n            Title,\n            { amStyle: 'primary' },\n            d.text\n          );\n        } else {\n          return React.createElement(\n            'div',\n            null,\n            React.createElement(\n              'div',\n              { className: 'tree-item', style: defalutStyle },\n              d.nodeplus ? React.createElement('span', { onClick: function onClick() {\n                  _this.expendNode(d);\n                }, className: 'amt-tree-switcher amt-tree-noline_close' }) : '',\n              d.nodeminus ? React.createElement('span', { onClick: function onClick() {\n                  _this.expendNode(d);\n                }, className: 'amt-tree-switcher amt-tree-noline_open' }) : '',\n              !d.nodeminus && !d.nodeplus ? React.createElement('span', { className: 'amt-tree-switcher' }) : '',\n              React.createElement(\n                'span',\n                { onClick: function onClick() {\n                    _this.treeClick(d);\n                  } },\n                d.text\n              )\n            ),\n            d.radio ? React.createElement(Switch, { shape: 'checkbox', checked: d.choose, onValueChange: function onValueChange() {\n                _this.treeClick(d);\n              } }) : null,\n            React.createElement(Divide, null)\n          );\n        }\n      })\n    );\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement('div', null);\n    }\n    return React.createElement(\n      'div',\n      { className: 'fw-treebox' },\n      data ? this.renderTree(data) : ''\n    );\n  }\n});";
    },
    getData_undefined: function (elem) {},
    doAction_: function (data, elem) {},
    getTemplate_: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    },
    getData_control53_Axm22x: function (elem) {
      if (!elem) {
        return;
      }var data = [];var $tds = $(elem).children('tbody').find('tr>td');$tds.each(function (i, e) {
        data.push($(this) && $(this).text().replace("：", ""));
      });return data;
    },
    doAction_uiControl65_5pIdJG: function (data, elem) {},
    getTemplate_uiControl65_5pIdJG: function () {
      var selfTemplate = "const { Field,Icon,Button,Title,Divide,Switch } = AMUITouch2;\n\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data && data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <div className=\"fw-treebox\">\n        <Title amStyle=\"primary\">{data[0]}</Title>\n        <div className=\"tree-item\" style={{'text-algin':'left','padding':'0 15px 0 15px'}}>{data[1]}</div>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Icon = _AMUITouch.Icon,\n    Button = _AMUITouch.Button,\n    Title = _AMUITouch.Title,\n    Divide = _AMUITouch.Divide,\n    Switch = _AMUITouch.Switch;\n\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data && data.length == 0) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"fw-treebox\" },\n      React.createElement(\n        Title,\n        { amStyle: \"primary\" },\n        data[0]\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"tree-item\", style: { 'text-algin': 'left', 'padding': '0 15px 0 15px' } },\n        data[1]\n      )\n    );\n  }\n});";
    },
    getData_control54_bRaCvD: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        if ($(item).attr('value') == '选择' || $(item).attr('value') == '取消') {
          var objShow = {};objShow.title = $(item).attr('value');objShow.index = index;arry1.push(objShow);obj.show = arry1;
        } else {
          var objHide = {};objHide.title = $(item).attr('value');objHide.index = index;arry2.push(objHide);obj.hide = arry2;
        }
      });return obj;
    },
    doAction_uiControl66_nTLDwL: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl66_nTLDwL: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={this.props.customData} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: this.props.customData });\n  }\n});";
    }
  }, "chooseCategory");
})(window, ysp);