(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control8_HgZHZB: function (elem) {
      return '地址本';
    },
    doAction_uiControl8_zJstnR: function (data, elem) {},
    getTemplate_uiControl8_zJstnR: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\t\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control9_svNQW5: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];$(elem).children('tbody').children('tr').each(function (i, e) {
        var item = $(this).find('tbody').children('tr').eq(0).children('td').eq(1).text().trim();if (item != "组织架构") {
          data.push(item);
        }
      });return data;
    },
    doAction_uiControl9_Vs7ubk: function (data, elem) {
      var event = data.eventType;if (event == "click") {
        var data = data.dataCustom;var _tr = $(elem).children('tbody').children('tr').eq(data).find('tbody').children('tr').eq(0);var evt = document.createEvent("HTMLEvents");evt.initEvent("click", true, true);_tr[0].dispatchEvent(evt);var $rightframe = $(elem.ownerDocument.defaultView.parent.document).find("frame[name='rightFrame']").eq(0);$rightframe.contents().find("select.namelist").eq(0).html("");$rightframe.contents().find("select.namelist").eq(1).html("");
      }
    },
    getTemplate_uiControl9_Vs7ubk: function () {
      var selfTemplate = "const { Button,Tabs } = AMUITouch2\n\nmodule.exports = React.createClass({\n  click: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'click',\n        data: e\n      })\n    }\n    \n  },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    var items = data.map(function(d, i){\n      return (\n        <Tabs.Item title={data[i]}></Tabs.Item>\n      )\n    })\n    return (\n      <Tabs onAction={this.click}>\n        {items}\n      </Tabs>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Button = _AMUITouch.Button,\n    Tabs = _AMUITouch.Tabs;\n\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: e\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data || data.length == 0) {\n      return React.createElement('div', null);\n    }\n    var items = data.map(function (d, i) {\n      return React.createElement(Tabs.Item, { title: data[i] });\n    });\n    return React.createElement(\n      Tabs,\n      { onAction: this.click },\n      items\n    );\n  }\n});";
    },

    getData_control13_Cgqn1A: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];var searchs = {};var _search = $(elem).children('table').eq(0).find('tr').children('td');searchs.title = _search && _search.eq(0).text() && _search.eq(0).text().trim().replace("：", "");searchs.value = _search.eq(1).children('input').val();data.push(searchs);var inputs = {};var _input = $(elem).find('#div_manual_input').find('tbody').children('tr');inputs.title = _input && _input.eq(0).children('td') && _input.eq(0).children('td').eq(0).text() && _input.eq(0).children('td').eq(0).text().trim().replace("：", "");inputs.value = _input && _input.eq(0).children('td') && _input.eq(0).children('td').eq(1).find('textarea') && _input.eq(0).children('td').eq(1).find('textarea').val();inputs.words = _input && _input.eq(1).children('td') && _input.eq(1).children('td').eq(1).text() && _input.eq(1).children('td').eq(1).text().trim();data.push(inputs);return data;
    },
    doAction_uiControl14_VqcMgp: function (data, elem) {
      var event = data.eventType;var _search = $(elem).children('table').eq(0).find('tr').children('td');var _input = $(elem).find('#div_manual_input').find('tbody').find('td');if (event == "searchblur") {
        var value = data.dataCustom;_search.eq(1).children('input').val(value);
      }if (event == "addblur") {
        var value = data.dataCustom;_input.eq(1).find('textarea').val(value);
      }if (event == "searchclick") {
        _search.eq(2).find('input').click();
      }if (event == "addclick") {
        _input.eq(2).find('input').click();
      }
    },
    getTemplate_uiControl14_VqcMgp: function () {
      var selfTemplate = "const { \n  Field,\n  Icon,\n  Button \n} = AMUITouch2;\nmodule.exports = React.createClass({\n  searchBlur: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'searchblur',\n        data: e.target.value\n      })\n    }\n  },\n  addBlur: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'addblur',\n        data: e.target.value\n      })\n    }\n  },\n  searchClick: function(){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'searchclick'\n      })\n    }\n  },\n  addClick: function(){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'addclick'\n      })\n    }\n  },\n\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    var fields = data.map(function(d, i){\n      if(i == 0 && d.title != null){\n        return (\n          <div>\n            <strong>{data[i].title}</strong>\n            <AInput type='text' value={data[i].value} onBlur={_this.searchBlur}/>\n            <span onClick={_this.searchClick}><Icon name=\"search\"/></span>\n          </div>\n        )\n      }else if(i == 1 && d.title != null){\n        return(\n          <div>\n            <div style={{\"width\":\"100%\",\"height\":\"10px;\"}}></div>\n            <strong>{data[i].title}</strong>\n            <AInput type='text' value={data[i].value} onBlur={_this.addBlur}/>\n            <span onClick={_this.addClick}><Icon name=\"add-l\"/></span>\n            <div>{data[i].words}</div>\n          </div>\n        )\n      }\n      \n    })\n    return (\n      <div className='list-content-search'>\n        {fields}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Icon = _AMUITouch.Icon,\n    Button = _AMUITouch.Button;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  searchBlur: function searchBlur(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'searchblur',\n        data: e.target.value\n      });\n    }\n  },\n  addBlur: function addBlur(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'addblur',\n        data: e.target.value\n      });\n    }\n  },\n  searchClick: function searchClick() {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'searchclick'\n      });\n    }\n  },\n  addClick: function addClick() {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'addclick'\n      });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data || data.length == 0) {\n      return React.createElement('div', null);\n    }\n    var fields = data.map(function (d, i) {\n      if (i == 0 && d.title != null) {\n        return React.createElement(\n          'div',\n          null,\n          React.createElement(\n            'strong',\n            null,\n            data[i].title\n          ),\n          React.createElement(AInput, { type: 'text', value: data[i].value, onBlur: _this.searchBlur }),\n          React.createElement(\n            'span',\n            { onClick: _this.searchClick },\n            React.createElement(Icon, { name: 'search' })\n          )\n        );\n      } else if (i == 1 && d.title != null) {\n        return React.createElement(\n          'div',\n          null,\n          React.createElement('div', { style: { \"width\": \"100%\", \"height\": \"10px;\" } }),\n          React.createElement(\n            'strong',\n            null,\n            data[i].title\n          ),\n          React.createElement(AInput, { type: 'text', value: data[i].value, onBlur: _this.addBlur }),\n          React.createElement(\n            'span',\n            { onClick: _this.addClick },\n            React.createElement(Icon, { name: 'add-l' })\n          ),\n          React.createElement(\n            'div',\n            null,\n            data[i].words\n          )\n        );\n      }\n    });\n    return React.createElement(\n      'div',\n      { className: 'list-content-search' },\n      fields\n    );\n  }\n});";
    },

    getData_control16_dVSery: function (elem) {
      if (!elem) {
        return undefined;
      }var data = {};data.title = $(elem).find('font') && $(elem).find('font')[0].innerText.trim() + $(elem).find('span')[0].innerText.trim();var _input = $(elem).find('font').children('input');if (_input.is(':checked')) {
        data.choose = true;
      } else {
        data.choose = false;
      }return data;
    },
    doAction_uiControl18_zTdEW3: function (data, elem) {
      var event = data.eventType;if (event == 'click') {
        $(elem).children('td').find('font').children('input').click(); // elem.querySelector('td').children[0].children[1].click();
      }
    },
    getTemplate_uiControl18_zTdEW3: function () {
      var selfTemplate = "const { Switch } = AMUITouch2\nmodule.exports = React.createClass({\n   click:function(e){\n    var handler = this.props.customHandler;\n     \n    if(handler){\n      handler({\n        eventType:'click'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <div className=\"fw-describe\">\n        {\n          data.title ? <span className=\"fw-describe-con\"><Switch shape=\"checkbox\" checked={data.choose} onValueChange={this.click} /></span> : null\n        }\n        <span>{data.title}</span>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    Switch = _AMUITouch.Switch;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  click: function click(e) {\n    var handler = this.props.customHandler;\n\n    if (handler) {\n      handler({\n        eventType: 'click'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"fw-describe\" },\n      data.title ? React.createElement(\n        \"span\",\n        { className: \"fw-describe-con\" },\n        React.createElement(Switch, { shape: \"checkbox\", checked: data.choose, onValueChange: this.click })\n      ) : null,\n      React.createElement(\n        \"span\",\n        null,\n        data.title\n      )\n    );\n  }\n});";
    },

    getData_control18_LDwSiw: function (elem) {
      var _elem = $(elem).children('tbody').children('tr').eq(2);if (elem && _elem[0] && _elem[0].style.height == "400px") {
        var _table = _elem.children('td').find('tbody').children('tr').eq(1).children('td').eq(1).children('div').find('tr').eq(1).find('iframe')[0].contentDocument;function initGroupData(_table) {
          var data = [];$(_table).find('div').children('table').each(function (i) {
            var $tds = $(this).find('tbody>tr>td');var $imgs = $tds.eq(0).find('img');var text = $tds.eq(1).text();var item = { index: i, tableId: $(this).attr('id'), text: text, imgs: $imgs.length };if ($tds.eq(1)[0].style.backgroundColor == "rgb(255, 255, 204)") {
              item.choose = true;
            } else {
              item.choose = false;
            }$imgs.each(function (i, e) {
              if (this.src.indexOf('nodeminus') != -1 || this.src.indexOf('openfolder') != -1) {
                item.nodeminus = true;
              }if (this.src.indexOf('nodeplus') != -1 || this.src.indexOf('closedfolder') != -1) {
                item.nodeplus = true;
              }
            });data.push(item);
          });return data;
        }return initGroupData(_table);
      } else {
        return undefined;
      }
    },
    doAction_uiControl20_8bf8vS: function (data, elem) {
      var event = data.eventType;var data = data.dataCustom;var _elem = $(elem).children('tbody').children('tr').eq(2);var _table = _elem.children('td').find('tbody').children('tr').eq(1).children('td').eq(1).children('div').find('tr').eq(1).find('iframe')[0].contentDocument;var _newtable = $(_table).find('div').children('table[id="' + data.tableId + '"]');if (event === 'expendNode') {
        _newtable.find('td').eq(0).find('a').click();
      }if (event === 'treeClick') {
        _newtable.find('td').eq(1).find('a').click();
      }
    },
    getTemplate_uiControl20_8bf8vS: function () {
      var selfTemplate = "const { Field,Icon,Button,Title,Divide,Switch } = AMUITouch2;\n\nmodule.exports = React.createClass({\n  expendNode: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'expendNode',\n        data:e\n      })\n    }\n  },\n \ttreeClick: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'treeClick',\n        data:e\n      })\n    }\n  },\n  renderTree: function(data){\n    var _this = this;\n    return (\n      <div className='address-tree'>\n        {data.map(function(d, i){\n          var pLeft = (d.imgs)*10 + 'px';\n          var defalutStyle = {'text-algin':'left','padding-left':pLeft};\n          if(i == 0){\n            return (\n              <Title amStyle=\"primary\">{d.text}</Title>\n            )\n          }else{\n            return (\n              <div>\n                <div className=\"tree-item\" style={defalutStyle}>\n                  {d.nodeplus ? <span onClick={()=>{_this.expendNode(d)}} className='amt-tree-switcher amt-tree-noline_close'></span> : ''}\n                  {d.nodeminus ? <span onClick={()=>{_this.expendNode(d)}} className='amt-tree-switcher amt-tree-noline_open'></span> : ''}\n                  {!d.nodeminus && !d.nodeplus ? <span className='amt-tree-switcher'></span> : ''}\n                  <span onClick={()=>{_this.treeClick(d)}}>{d.text}</span>\n                </div>\n                <Switch shape=\"checkbox\" checked={d.choose} onValueChange={()=>{_this.treeClick(d)}} />\n                <Divide />\n              </div>\n            )\n          }\n        })}\n      </div>\n    )\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <div className=\"fw-treebox\">\n        {data ? this.renderTree(data) : ''}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Icon = _AMUITouch.Icon,\n    Button = _AMUITouch.Button,\n    Title = _AMUITouch.Title,\n    Divide = _AMUITouch.Divide,\n    Switch = _AMUITouch.Switch;\n\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  expendNode: function expendNode(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'expendNode',\n        data: e\n      });\n    }\n  },\n  treeClick: function treeClick(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'treeClick',\n        data: e\n      });\n    }\n  },\n  renderTree: function renderTree(data) {\n    var _this = this;\n    return React.createElement(\n      'div',\n      { className: 'address-tree' },\n      data.map(function (d, i) {\n        var pLeft = d.imgs * 10 + 'px';\n        var defalutStyle = { 'text-algin': 'left', 'padding-left': pLeft };\n        if (i == 0) {\n          return React.createElement(\n            Title,\n            { amStyle: 'primary' },\n            d.text\n          );\n        } else {\n          return React.createElement(\n            'div',\n            null,\n            React.createElement(\n              'div',\n              { className: 'tree-item', style: defalutStyle },\n              d.nodeplus ? React.createElement('span', { onClick: function onClick() {\n                  _this.expendNode(d);\n                }, className: 'amt-tree-switcher amt-tree-noline_close' }) : '',\n              d.nodeminus ? React.createElement('span', { onClick: function onClick() {\n                  _this.expendNode(d);\n                }, className: 'amt-tree-switcher amt-tree-noline_open' }) : '',\n              !d.nodeminus && !d.nodeplus ? React.createElement('span', { className: 'amt-tree-switcher' }) : '',\n              React.createElement(\n                'span',\n                { onClick: function onClick() {\n                    _this.treeClick(d);\n                  } },\n                d.text\n              )\n            ),\n            React.createElement(Switch, { shape: 'checkbox', checked: d.choose, onValueChange: function onValueChange() {\n                _this.treeClick(d);\n              } }),\n            React.createElement(Divide, null)\n          );\n        }\n      })\n    );\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement('div', null);\n    }\n    return React.createElement(\n      'div',\n      { className: 'fw-treebox' },\n      data ? this.renderTree(data) : ''\n    );\n  }\n});";
    },

    getData_control20_7v3uTe: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];$(elem).children('div').children("input").each(function (i, e) {
        data.push($(this).val());
      });return data;
    },
    doAction_uiControl22_T5udM1: function (data, elem) {
      var event = data.eventType;if (event == 'click') {
        var index = data.dataCustom;$(elem).children('div').children("input").eq(index).click();
      }
    },
    getTemplate_uiControl22_T5udM1: function () {
      var selfTemplate = "const { Button,ButtonContainer,ButtonGroup,ButtonBubble } = AMUITouch2\nmodule.exports = React.createClass({\n  click: function(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: e.target.getAttribute(\"data-index\")\n      });\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <div>\n        {\n          data.length == 1 ? <ButtonContainer>\n            <ButtonGroup amStyle=\"warning\" gapped justify>\n                <Button amStyle=\"warning\" data-index={0} onClick={this.click}>{data[0]}</Button>\n            </ButtonGroup>\n          </ButtonContainer> : null\n        }\n        {\n          data.length == 2 ? <ButtonContainer>\n          <ButtonGroup amStyle=\"warning\" gapped justify>\n            <Button amStyle=\"warning\" data-index={0} onClick={this.click}>{data[0]}</Button>\n            <Button amStyle=\"warning\" hollow data-index={1} onClick={this.click}>{data[1]}</Button>\n          </ButtonGroup>\n        </ButtonContainer> : null\n        }\n        {\n          data.length == 3 ? <div>\n          <ButtonContainer>\n            <ButtonGroup amStyle=\"warning\" gapped justify>\n              <Button amStyle=\"warning\" data-index={0} onClick={this.click}>{data[0]}</Button>\n              <Button amStyle=\"warning\" hollow data-index={1} onClick={this.click}>{data[1]}</Button>\n            </ButtonGroup>\n          </ButtonContainer>\n          <ButtonContainer>\n            <ButtonGroup amStyle=\"warning\" gapped justify>\n                <Button amStyle=\"warning\" hollow data-index={2} onClick={this.click}>{data[2]}</Button>\n            </ButtonGroup>\n          </ButtonContainer>\n        </div> : null\n        }\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    Button = _AMUITouch.Button,\n    ButtonContainer = _AMUITouch.ButtonContainer,\n    ButtonGroup = _AMUITouch.ButtonGroup,\n    ButtonBubble = _AMUITouch.ButtonBubble;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  click: function click(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: e.target.getAttribute(\"data-index\")\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      data.length == 1 ? React.createElement(\n        ButtonContainer,\n        null,\n        React.createElement(\n          ButtonGroup,\n          { amStyle: \"warning\", gapped: true, justify: true },\n          React.createElement(\n            Button,\n            { amStyle: \"warning\", \"data-index\": 0, onClick: this.click },\n            data[0]\n          )\n        )\n      ) : null,\n      data.length == 2 ? React.createElement(\n        ButtonContainer,\n        null,\n        React.createElement(\n          ButtonGroup,\n          { amStyle: \"warning\", gapped: true, justify: true },\n          React.createElement(\n            Button,\n            { amStyle: \"warning\", \"data-index\": 0, onClick: this.click },\n            data[0]\n          ),\n          React.createElement(\n            Button,\n            { amStyle: \"warning\", hollow: true, \"data-index\": 1, onClick: this.click },\n            data[1]\n          )\n        )\n      ) : null,\n      data.length == 3 ? React.createElement(\n        \"div\",\n        null,\n        React.createElement(\n          ButtonContainer,\n          null,\n          React.createElement(\n            ButtonGroup,\n            { amStyle: \"warning\", gapped: true, justify: true },\n            React.createElement(\n              Button,\n              { amStyle: \"warning\", \"data-index\": 0, onClick: this.click },\n              data[0]\n            ),\n            React.createElement(\n              Button,\n              { amStyle: \"warning\", hollow: true, \"data-index\": 1, onClick: this.click },\n              data[1]\n            )\n          )\n        ),\n        React.createElement(\n          ButtonContainer,\n          null,\n          React.createElement(\n            ButtonGroup,\n            { amStyle: \"warning\", gapped: true, justify: true },\n            React.createElement(\n              Button,\n              { amStyle: \"warning\", hollow: true, \"data-index\": 2, onClick: this.click },\n              data[2]\n            )\n          )\n        )\n      ) : null\n    );\n  }\n});";
    },
    getData_control169_IThR0u: function (elem) {
      if (elem) {
        var data;var $leftframe = $(elem).children("frame[name='leftFrame']").eq(0);var $rightframe = $(elem).children("frame[name='rightFrame']").eq(0);if ($leftframe.length || $rightframe) {
          function initGroupData(_table, type) {
            var orgData = [];$(_table).children('table').each(function (i) {
              var $tds = $(this).find('tbody>tr>td');var $imgs = $tds.eq(0).find('img');var text = $tds.eq(1).text();var item = { index: i, tableId: $(this).attr('id'), text: text, imgs: $imgs.length, type: type };if ($tds.eq(1)[0].style.backgroundColor == "rgb(255, 255, 204)") {
                item.selected = true;data.orgSelected = text;
              } else {
                item.selected = false;
              }$imgs.each(function (i, e) {
                if (this.src.indexOf('nodeminus') != -1 || this.src.indexOf('openfolder') != -1) {
                  item.nodeminus = true;
                }if (this.src.indexOf('nodeplus') != -1 || this.src.indexOf('closedfolder') != -1) {
                  item.nodeplus = true;
                }if (this.src.indexOf('up01') != -1) {
                  item.nodeup = true;
                }
              });orgData.push(item);
            });return orgData;
          }function initList($select, type) {
            var listData = [];$select.children('option').each(function (i, e) {
              if ($(this)[0].selected) {
                data.toSelected = $(this).text();
              }listData.push({ index: i, text: $(this).text(), value: $(this).val(), selected: $(this).attr("hasselected"), type: type });
            });return listData;
          }data = { orgData: [], toSelectData: [], selectedData: [] };var navindex;$leftframe.contents().find("table#obj").children("tbody").children("tr").each(function (navi, navtr) {
            if (this.style.height == "400px") {
              navindex = navi;return;
            }
          });if (navindex != 0) {
            return data;
          }var orgFrame = $leftframe.contents().find("iframe").eq(0).contents().find("#treeDiv");data.orgData = initGroupData(orgFrame, "orgData");var toSelectList = $rightframe.contents().find("select.namelist").eq(0);var selectedList = $rightframe.contents().find("select.namelist").eq(1);data.toSelectData = initList(toSelectList, "toSelectData");data.selectedData = initList(selectedList, "selectedData");
        }if (/sgl\./.test(elem.ownerDocument.defaultView.location.href)) {
          data.isRadio = true;
        }return data;
      }return;
    },
    doAction_uiControl106_3UUeci: function (data, elem) {
      if (/sgl\./.test(elem.ownerDocument.defaultView.location.href)) {
        var isRadio = true;
      }var _data = data.customData;var type = data.eventType;var $leftframe = $(elem).children("frame[name='leftFrame']").eq(0);var $rightframe = $(elem).children("frame[name='rightFrame']").eq(0);var orgFrame, _newtable;$leftframe.contents().find("table#obj").children("tbody").children("tr").each(function (navi, navtr) {
        if (this.style.height == "400px" && navi == 0) {
          orgFrame = $leftframe.contents().find("iframe").eq(navi).contents().find("#treeDiv");_newtable = orgFrame.children('table[id="' + _data.tableId + '"]');
        }
      });var toSelectList = $rightframe.contents().find("select.namelist").eq(0);var selectedList = $rightframe.contents().find("select.namelist").eq(1);switch (type) {case "expendNode":
          _newtable.find('td').eq(0).find('a').click();break;case "selected":
          if (_data.type == "orgData") {
            _newtable.find('td').eq(1).find('a').click();
          } else {
            if (!!isRadio) {
              toSelectList.children("option[hasselected]").each(function () {
                $(this).removeAttr("hasselected");
              });toSelectList.val(_data.value);toSelectList.children("option").eq(_data.index).click();toSelectList.children("option").eq(_data.index).attr("hasselected", "true");$rightframe.contents().find('input[name="btnAdd"]').click();
            } else {
              if (!toSelectList.children("option").eq(_data.index).attr("hasselected")) {
                toSelectList.val(_data.value);toSelectList.children("option").eq(_data.index).click();toSelectList.children("option").eq(_data.index).attr("hasselected", "true");$rightframe.contents().find('input[name="btnAdd"]').click();
              } else {
                toSelectList.children("option").eq(_data.index).removeAttr("hasselected");selectedList.val(_data.value);selectedList.click();$rightframe.contents().find('input[name="btnDel"]').click();
              }
            }
          }break;case "unselected":
          toSelectList.children("option").each(function () {
            if ($(this).val() == _data.value) {
              $(this).removeAttr("hasselected");
            }
          });selectedList.val(_data.value);selectedList.click();$rightframe.contents().find('input[name="btnDel"]').click();break;case "nodeup":
          _newtable.find('td').eq(0).find('a').eq(0).click();break;}
    },
    getTemplate_uiControl106_3UUeci: function () {
      var selfTemplate = "var DepartmentSelect = require('ysp-custom-components').DepartmentSelect;\nmodule.exports = React.createClass({\n  callback:function(data){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb(data);\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n    if(data.orgData.length==0&&data.toSelectData.length==0&&data.selectedData.length==0){\n      return <span></span>\n    }\n    return (<DepartmentSelect data={data} callback={_this.callback}></DepartmentSelect>)\n  }\n});";
      return "'use strict';\n\nvar DepartmentSelect = require('ysp-custom-components').DepartmentSelect;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  callback: function callback(data) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb(data);\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    if (data.orgData.length == 0 && data.toSelectData.length == 0 && data.selectedData.length == 0) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(DepartmentSelect, { data: data, callback: _this.callback });\n  }\n});";
    },
    getData_control232_KX7o3J: function (elem) {
      if (elem) {
        var data;var $leftframe = $(elem).children("frame[name='leftFrame']").eq(0);var $rightframe = $(elem).children("frame[name='rightFrame']").eq(0);if ($leftframe.length || $rightframe) {
          function initGroupData(_table, type) {
            var orgData = [];$(_table).children('table').each(function (i) {
              var $tds = $(this).find('tbody>tr>td');var $imgs = $tds.eq(0).find('img');var text = $tds.eq(1).text();var item = { index: i, tableId: $(this).attr('id'), text: text, imgs: $imgs.length, type: type };if ($tds.eq(1)[0].style.backgroundColor == "rgb(255, 255, 204)") {
                item.selected = true;data.orgSelected = text;
              } else {
                item.selected = false;
              }$imgs.each(function (i, e) {
                if (this.src.indexOf('nodeminus') != -1 || this.src.indexOf('openfolder') != -1) {
                  item.nodeminus = true;
                }if (this.src.indexOf('nodeplus') != -1 || this.src.indexOf('closedfolder') != -1) {
                  item.nodeplus = true;
                }if (this.src.indexOf('up01') != -1) {
                  item.nodeup = true;
                }
              });orgData.push(item);
            });return orgData;
          }function initList($select, type) {
            var listData = [];$select.children('option').each(function (i, e) {
              if ($(this)[0].selected) {
                data.toSelected = $(this).text();
              }listData.push({ index: i, text: $(this).text(), value: $(this).val(), selected: $(this).attr("hasselected"), type: type });
            });return listData;
          }data = { orgData: [], toSelectData: [], selectedData: [] };var navindex;$leftframe.contents().find("table#obj").children("tbody").children("tr").each(function (navi, navtr) {
            if (this.style.height == "400px") {
              navindex = navi;return;
            }
          });if (navindex != 1) {
            return data;
          }var orgFrame = $leftframe.contents().find("iframe").eq(1).contents().find("#treeDiv");data.orgData = initGroupData(orgFrame, "orgData");var toSelectList = $rightframe.contents().find("select.namelist").eq(0);var selectedList = $rightframe.contents().find("select.namelist").eq(1);data.toSelectData = initList(toSelectList, "toSelectData");data.selectedData = initList(selectedList, "selectedData");data.addressBook = true;
        }if (/sgl\./.test(elem.ownerDocument.defaultView.location.href)) {
          data.isRadio = true;
        }return data;
      }return;
    },
    doAction_uiControl10_PTeu3r: function (data, elem) {
      if (/sgl\./.test(elem.ownerDocument.defaultView.location.href)) {
        var isRadio = true;
      }var _data = data.customData;var type = data.eventType;var $leftframe = $(elem).children("frame[name='leftFrame']").eq(0);var $rightframe = $(elem).children("frame[name='rightFrame']").eq(0);var orgFrame, _newtable;$leftframe.contents().find("table#obj").children("tbody").children("tr").each(function (navi, navtr) {
        if (this.style.height == "400px" && navi == 1) {
          orgFrame = $leftframe.contents().find("iframe").eq(navi).contents().find("#treeDiv");_newtable = orgFrame.children('table[id="' + _data.tableId + '"]');
        }
      });var toSelectList = $rightframe.contents().find("select.namelist").eq(0);var selectedList = $rightframe.contents().find("select.namelist").eq(1);switch (type) {case "expendNode":
          _newtable.find('td').eq(0).find('a').click();break;case "selected":
          if (_data.type == "orgData") {
            _newtable.find('td').eq(1).find('a').click();
          } else {
            if (!!isRadio) {
              toSelectList.children("option[hasselected]").each(function () {
                $(this).removeAttr("hasselected");
              });toSelectList.val(_data.value);toSelectList.children("option").eq(_data.index).click();toSelectList.children("option").eq(_data.index).attr("hasselected", "true");$rightframe.contents().find('input[name="btnAdd"]').click();
            } else {
              if (!toSelectList.children("option").eq(_data.index).attr("hasselected")) {
                toSelectList.val(_data.value);toSelectList.children("option").eq(_data.index).click();toSelectList.children("option").eq(_data.index).attr("hasselected", "true");$rightframe.contents().find('input[name="btnAdd"]').click();
              } else {
                toSelectList.children("option").eq(_data.index).removeAttr("hasselected");selectedList.val(_data.value);selectedList.click();$rightframe.contents().find('input[name="btnDel"]').click();
              }
            }
          }break;case "unselected":
          toSelectList.children("option").each(function () {
            if ($(this).val() == _data.value) {
              $(this).removeAttr("hasselected");
            }
          });selectedList.val(_data.value);selectedList.click();$rightframe.contents().find('input[name="btnDel"]').click();break;case "nodeup":
          _newtable.find('td').eq(0).find('a').eq(0).click();break;}
    },
    getTemplate_uiControl10_PTeu3r: function () {
      var selfTemplate = "var DepartmentSelect = require('ysp-custom-components').DepartmentSelect;\nmodule.exports = React.createClass({\n  callback:function(data){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb(data);\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n    if(data.orgData.length==0&&data.toSelectData.length==0&&data.selectedData.length==0){\n      return <span></span>\n    }\n    return (<DepartmentSelect data={data} callback={_this.callback}></DepartmentSelect>)\n  }\n});";
      return "'use strict';\n\nvar DepartmentSelect = require('ysp-custom-components').DepartmentSelect;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  callback: function callback(data) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb(data);\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    if (data.orgData.length == 0 && data.toSelectData.length == 0 && data.selectedData.length == 0) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(DepartmentSelect, { data: data, callback: _this.callback });\n  }\n});";
    }
  }, "choosePeople");
})(window, ysp);