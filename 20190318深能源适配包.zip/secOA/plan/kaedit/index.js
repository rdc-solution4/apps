(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control150_4Qtu8N: function (elem) {
      if (elem) {
        var doc = elem.ownerDocument;var data = { show: [] };$(doc).find('table center input').each(function (index) {
          data.show.push({ index: index, title: this.value, value: this.value });
        });return data;
      }
    },
    doAction_uiControl137_Wp6mwd: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;var doc = elem.ownerDocument;if (eventType == "click") {
        $(doc).find('table center input').eq(customData).click();
      }
    },
    getTemplate_uiControl137_Wp6mwd: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control161_XJreP7: function (elem) {
      if (!elem) {
        return;
      }return elem.ownerDocument.title;
    },
    doAction_uiControl178_4Qezpp: function (data, elem) {},
    getTemplate_uiControl178_4Qezpp: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    var data = this.props.customData;\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return '"use strict";\n\nvar _appRenderer = require("appRenderer");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: "\u8FD4\u56DE",\n        icon: "left"\n      }]\n    });\n  }\n});';
    }
  }, "kaedit");
})(window, ysp);