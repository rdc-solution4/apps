(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control24_u0pvtV: function (elem) {},
    doAction_uiControl40_19odgq: function (data, elem) {},
    getTemplate_uiControl40_19odgq: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title=\"\u641C\u7D22\" \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: \"\\u641C\\u7D22\",\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },

    getData_control34_qSvVt7: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];data.push($(elem).find('input[name="SearchString"]').val());return data;
    },
    doAction_uiControl42_Wv21AQ: function (data, elem) {
      //回调
      if (data.eventType == 'blur') {
        $(elem).find('input[name="SearchString"]').val(data.customData);
      } else {
        $(elem).find('td').eq(1).find('a').click();
      }
    },
    getTemplate_uiControl42_Wv21AQ: function () {
      var selfTemplate = "module.exports = React.createClass({\n  handlerBlur: function(e){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'blur',\n        data: e.target.value\n      })\n    }\n  },\n  handlerClick: function(){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler ({\n        eventType: 'click'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    return (\n      \n     <div className='ui-gxf-relation-search'>\n        <div>\n        \t<AInput type='text' value={data} onBlur={this.handlerBlur}/>\n          <span className=\"amt-icon amt-icon-search\" onClick={this.handlerClick}></span>\n        </div>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  handlerBlur: function handlerBlur(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'blur',\n        data: e.target.value\n      });\n    }\n  },\n  handlerClick: function handlerClick() {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      'div',\n      { className: 'ui-gxf-relation-search' },\n      React.createElement(\n        'div',\n        null,\n        React.createElement(AInput, { type: 'text', value: data, onBlur: this.handlerBlur }),\n        React.createElement('span', { className: 'amt-icon amt-icon-search', onClick: this.handlerClick })\n      )\n    );\n  }\n});";
    },

    getData_control36_Ld9OuA: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];$(elem).find('b').each(function (i, e) {
        var obj = {};var _input = $(this).find('input[type="checkbox"]');if (_input[0].checked) {
          obj.checked = true;
        } else {
          obj.checked = false;
        }obj.title = _input.attr("text");obj.creator = $(this).next()[0].innerText;obj.creatTime = $(this).parent().children(':last-child').children('span').eq(0)[0].innerText;obj.model = $(this).parent().children(':last-child').children('span').eq(1)[0].innerText;obj.content = _input.attr("value");data.push(obj);
      });return data;
    },
    doAction_uiControl44_mPERX2: function (data, elem) {
      var eventType = data.eventType;if (eventType == "checkedClick") {
        var customData = data.customData;$(elem).find('input[type="checkbox"]').eq(customData).click();
      }if (eventType == "click") {
        var customI = data.customData;$(elem).find('b').eq(customI).find('a').click();
      }
    },
    getTemplate_uiControl44_mPERX2: function () {
      var selfTemplate = "const {Switch } = AMUITouch2;\nmodule.exports = React.createClass({\n  click:function(i){        \n    var callBack = this.props.customHandler;  \n    if(callBack) {\n      callBack({\n        data:i,\n        eventType:'click'\n      })\n    }\n  },\n  checkedClick:function(i){  \n    var callBack = this.props.customHandler;  \n    if(callBack) {\n      callBack({\n        data:i,\n        eventType:'checkedClick'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    var self = this;\n    if(!data){\n      return (<div style={{\"textAlign\":\"center\",\"padding\":\"20px 0 20px 0\"}}>\u6682\u65E0\u6570\u636E</div>)\n    }\n    return(\n    \t<ul className=\"amt-list ui-list\">\n      \t{\n          data.map(function(el,i){\n            return(\n            \t<li className=\"amt-item amt-item-content\">\n                 <span className=\"amt-item-media\">\n                    <Switch shape=\"checkbox\" defultChecked={el.checked} onValueChange={()=>  {self.checkedClick(i)}}/>\n                </span>\n               \n                <div className=\"amt-item-main\" onClick={function(){self.click(i)}}>\n                  <div className=\"amt-item-title\">{el.title}</div>\n                  <div className=\"amt-item-title-row\">\n                    <div className=\"amt-item-desc\">{el.creator}</div>\n                  </div>\n                  <div className=\"amt-item-title-row\">\n                    <div className=\"amt-item-desc\">{el.creatTime}</div>\n                  </div>\n                  <div className=\"amt-item-title-row\">\n                    <div className=\"amt-item-desc\">{el.model}</div>\n                  </div>\n                  <div className=\"amt-item-title-row\">\n                    <div className=\"amt-item-desc\">{el.content}</div>\n                  </div>\n                </div>\n                \n              </li>\n            )\n          })\n        }\n      </ul>\n    ) \n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Switch = _AMUITouch.Switch;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(i) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: i,\n        eventType: 'click'\n      });\n    }\n  },\n  checkedClick: function checkedClick(i) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: i,\n        eventType: 'checkedClick'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var self = this;\n    if (!data) {\n      return React.createElement(\n        'div',\n        { style: { \"textAlign\": \"center\", \"padding\": \"20px 0 20px 0\" } },\n        '\\u6682\\u65E0\\u6570\\u636E'\n      );\n    }\n    return React.createElement(\n      'ul',\n      { className: 'amt-list ui-list' },\n      data.map(function (el, i) {\n        return React.createElement(\n          'li',\n          { className: 'amt-item amt-item-content' },\n          React.createElement(\n            'span',\n            { className: 'amt-item-media' },\n            React.createElement(Switch, { shape: 'checkbox', defultChecked: el.checked, onValueChange: function onValueChange() {\n                self.checkedClick(i);\n              } })\n          ),\n          React.createElement(\n            'div',\n            { className: 'amt-item-main', onClick: function onClick() {\n                self.click(i);\n              } },\n            React.createElement(\n              'div',\n              { className: 'amt-item-title' },\n              el.title\n            ),\n            React.createElement(\n              'div',\n              { className: 'amt-item-title-row' },\n              React.createElement(\n                'div',\n                { className: 'amt-item-desc' },\n                el.creator\n              )\n            ),\n            React.createElement(\n              'div',\n              { className: 'amt-item-title-row' },\n              React.createElement(\n                'div',\n                { className: 'amt-item-desc' },\n                el.creatTime\n              )\n            ),\n            React.createElement(\n              'div',\n              { className: 'amt-item-title-row' },\n              React.createElement(\n                'div',\n                { className: 'amt-item-desc' },\n                el.model\n              )\n            ),\n            React.createElement(\n              'div',\n              { className: 'amt-item-title-row' },\n              React.createElement(\n                'div',\n                { className: 'amt-item-desc' },\n                el.content\n              )\n            )\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_undefined: function (elem) {},
    doAction_: function (data, elem) {},
    getTemplate_: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    },
    getData_control22_iJPtTx: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];var page = $(elem).find('a');data.push(page.first()[0] && page.first()[0].innerText);data.push(page.last()[0] && page.last()[0].innerText);return data;
    },
    doAction_uiControl28_eoryKi: function (data, elem) {
      var eventType = data.eventType; //上一页回调
      if (eventType == 'clickFirst') {
        $(elem).find('a').eq(0).first().click();
      } //下一页回调
      if (eventType == 'click') {
        $(elem).find('a').last().click();
      }
    },
    getTemplate_uiControl28_eoryKi: function () {
      var selfTemplate = "module.exports = React.createClass({\n  click:function(data){\n    var handler = this.props.customHandler;\n    if(handler) {\n      handler({\n        eventType:'click'\n      })\n    }\n  },\n  clickFirst:function(i){        \n    var callBack = this.props.customHandler;  \n    if(callBack) {\n      callBack({\n        eventType:'clickFirst'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(data[0]==null || !data || data && data.length==0){\n      return (\n      \t<div></div>\n      )\n    }\n    var self = this;\n    return (\n     <div className=\"amt-g amt-g-between\">\n       <div className=\"amt-col amt-col-2\">\n         <button className=\"amt-btn  amt-btn-sm\" style={{\"background\":\"#fff\"}} onClick={()=>{self.clickFirst()}}>\u4E0A\u4E00\u9875</button>\n       </div>\n       <div className=\"amt-col amt-col-2\">\n         <button className=\"amt-btn  amt-btn-sm amt-btn-warning\" onClick={()=>{self.click()}}>\u4E0B\u4E00\u9875</button>\n       </div>\n        </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click'\n      });\n    }\n  },\n  clickFirst: function clickFirst(i) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'clickFirst'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (data[0] == null || !data || data && data.length == 0) {\n      return React.createElement('div', null);\n    }\n    var self = this;\n    return React.createElement(\n      'div',\n      { className: 'amt-g amt-g-between' },\n      React.createElement(\n        'div',\n        { className: 'amt-col amt-col-2' },\n        React.createElement(\n          'button',\n          { className: 'amt-btn  amt-btn-sm', style: { \"background\": \"#fff\" }, onClick: function onClick() {\n              self.clickFirst();\n            } },\n          '\\u4E0A\\u4E00\\u9875'\n        )\n      ),\n      React.createElement(\n        'div',\n        { className: 'amt-col amt-col-2' },\n        React.createElement(\n          'button',\n          { className: 'amt-btn  amt-btn-sm amt-btn-warning', onClick: function onClick() {\n              self.click();\n            } },\n          '\\u4E0B\\u4E00\\u9875'\n        )\n      )\n    );\n  }\n});";
    },
    getData_control33_160R7C: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        if ($(item).attr('value') == '关联所选文档' || $(item).attr('value') == '关闭窗口') {
          var objShow = {};objShow.title = $(item).attr('value');objShow.index = index;arry1.push(objShow);obj.show = arry1;
        } else {
          var objHide = {};objHide.title = $(item).attr('value');objHide.index = index;arry2.push(objHide);obj.hide = arry2;
        }
      });return obj;
    },
    doAction_uiControl30_S2sE3A: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl30_S2sE3A: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={this.props.customData} />);\n  }\n});";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: this.props.customData });\n  }\n});";
    }
  }, "lks_Association_Search");
})(window, ysp);