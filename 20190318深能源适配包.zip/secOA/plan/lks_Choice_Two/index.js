(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({

    getData_control58_xoVrdi: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        var that = $(item).attr('value');if (that == '确 定' || that == '取 消') {
          arry1.push({ title: $(item).attr('value'), index: index, value: that });obj.show = arry1;
        } //else {
        //   if (that != "标准打印格式" && that != "封面打印" && that != "收藏" && that != "复制" && that != "流程挂接" && that != "发起挂接通知" && that != "打印公文正文" && that != "打印审批记录") {
        //     arry2.push({
        //       title: $(item).attr('value'),
        //       index: index,
        //       value: that
        //     });
        //     obj.hide = arry2;
        //   }
        // }
      });return obj;
    },
    doAction_uiControl71_qSh20V: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl71_qSh20V: function () {
      var selfTemplate = 'var GlobalFooterBtn = require(\'ysp-custom-components\').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});\n';
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control128_Kkf5hT: function (elem) {
      return '单位名称';
    },
    doAction_uiControl139_JqVX68: function (data, elem) {},
    getTemplate_uiControl139_JqVX68: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return '"use strict";\n\nvar _appRenderer = require("appRenderer");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: "\u8FD4\u56DE",\n        icon: "left"\n      }]\n    });\n  }\n});';
    },
    getData_control14_6oA995: function (elem) {
      if (elem) {
        var data;var $leftframe = $(elem).children("frame[name='leftFrame']").eq(0);var $rightframe = $(elem).children("frame[name='rightFrame']").eq(0);if ($leftframe.length || $rightframe) {
          function initGroupData(_table, type) {
            var orgData = [];$(_table).children('table').each(function (i) {
              var $tds = $(this).find('tbody>tr>td');var $imgs = $tds.eq(0).find('img');var text = $tds.eq(1).text();var item = { index: i, tableId: $(this).attr('id'), text: text, imgs: $imgs.length, type: type };if ($tds.eq(1)[0].style.backgroundColor == "rgb(255, 255, 204)") {
                item.selected = true;data.orgSelected = text;
              } else {
                item.selected = false;
              }$imgs.each(function (i, e) {
                if (this.src.indexOf('nodeminus') != -1 || this.src.indexOf('openfolder') != -1) {
                  item.nodeminus = true;
                }if (this.src.indexOf('nodeplus') != -1 || this.src.indexOf('closedfolder') != -1) {
                  item.nodeplus = true;
                }if (this.src.indexOf('up01') != -1) {
                  item.nodeup = true;
                }
              });orgData.push(item);
            });return orgData;
          }function initList($select, type) {
            var listData = [];$select.children('option').each(function (i, e) {
              if ($(this)[0].selected) {
                data.toSelected = $(this).text();
              }listData.push({ index: i, text: $(this).text(), value: $(this).val(), selected: $(this).attr("hasselected"), type: type });
            });return listData;
          }data = { orgData: [], toSelectData: [], selectedData: [] };var orgFrame = $leftframe.contents().find("iframe").eq(0).contents().find("#treeDiv");data.orgData = initGroupData(orgFrame, "orgData");var toSelectList = $rightframe.contents().find("select.namelist").eq(0);var selectedList = $rightframe.contents().find("select.namelist").eq(1);data.toSelectData = initList(toSelectList, "toSelectData");data.selectedData = initList(selectedList, "selectedData");
        }if (/sgl\./.test(elem.ownerDocument.defaultView.location.href)) {
          data.isRadio = true;
        }return data;
      }return;
    },
    doAction_uiControl15_VrKVwT: function (data, elem) {
      if (/sgl\./.test(elem.ownerDocument.defaultView.location.href)) {
        var isRadio = true;
      }var _data = data.customData;var type = data.eventType;var $leftframe = $(elem).children("frame[name='leftFrame']").eq(0);var $rightframe = $(elem).children("frame[name='rightFrame']").eq(0);var orgFrame = $leftframe.contents().find("iframe").eq(0).contents().find("#treeDiv");var toSelectList = $rightframe.contents().find("select.namelist").eq(0);var selectedList = $rightframe.contents().find("select.namelist").eq(1);var _newtable = orgFrame.children('table[id="' + _data.tableId + '"]');switch (type) {case "expendNode":
          _newtable.find('td').eq(0).find('a').click();break;case "selected":
          if (_data.type == "orgData") {
            _newtable.find('td').eq(1).find('a').click();
          } else {
            if (!!isRadio) {
              toSelectList.children("option[hasselected]").each(function () {
                $(this).removeAttr("hasselected");
              });toSelectList.val(_data.value);toSelectList.children("option").eq(_data.index).click();toSelectList.children("option").eq(_data.index).attr("hasselected", "true");$rightframe.contents().find('input[name="btnAdd"]').click();
            } else {
              if (!toSelectList.children("option").eq(_data.index).attr("hasselected")) {
                toSelectList.val(_data.value);toSelectList.children("option").eq(_data.index).click();toSelectList.children("option").eq(_data.index).attr("hasselected", "true");$rightframe.contents().find('input[name="btnAdd"]').click();
              } else {
                toSelectList.children("option").eq(_data.index).removeAttr("hasselected");selectedList.val(_data.value);selectedList.click();$rightframe.contents().find('input[name="btnDel"]').click();
              }
            }
          }break;case "unselected":
          toSelectList.children("option").each(function () {
            if ($(this).val() == _data.value) {
              $(this).removeAttr("hasselected");
            }
          });selectedList.val(_data.value);selectedList.click();$rightframe.contents().find('input[name="btnDel"]').click();break;case "nodeup":
          _newtable.find('td').eq(0).find('a').eq(0).click();break;}
    },
    getTemplate_uiControl15_VrKVwT: function () {
      var selfTemplate = 'var DepartmentSelect = require(\'ysp-custom-components\').DepartmentSelect;\nmodule.exports = React.createClass({\n  callback:function(data){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb(data);\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n    return (<DepartmentSelect data={data} callback={_this.callback}></DepartmentSelect>)\n  }\n});';
      return '\'use strict\';\n\nvar DepartmentSelect = require(\'ysp-custom-components\').DepartmentSelect;\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  callback: function callback(data) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb(data);\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    return React.createElement(DepartmentSelect, { data: data, callback: _this.callback });\n  }\n});';
    }
  }, "lks_Choice_Two");
})(window, ysp);