(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control139_zyZzqc: function (elem) {},
    doAction_uiControl152_OqSw4M: function (data, elem) {},
    getTemplate_uiControl152_OqSw4M: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title=\"\u53D1\u8D77\u6D41\u7A0B\u6302\u63A5\" \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: \"\\u53D1\\u8D77\\u6D41\\u7A0B\\u6302\\u63A5\",\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },

    getData_control143_LC8iRr: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        var that = $(item).attr('value');if (that == '确定' || that == '关闭') {
          arry1.push({ title: $(item).attr('value'), index: index });obj.show = arry1;
        } else {
          if (that != "标准打印格式" && that != "封面打印" && that != "收藏" && that != "复制" && that != "流程挂接" && that != "发起挂接通知" && that != "打印公文正文" && that != "打印审批记录") {
            arry2.push({ title: $(item).attr('value'), index: index });obj.hide = arry2;
          }
        }
      });return obj;
    },
    doAction_uiControl157_RCfU0L: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl157_RCfU0L: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control144_0wmgL2: function (elem) {
      if (!elem) {
        return undefined;
      }var data = { node: [] };var obj1 = { name: "", content: [] };obj1.name = $(elem).find('font')[0] && $(elem).find('font')[0].innerText;$(elem).find('input').each(function (i, e) {
        var obj2 = {};if (this.type == 'hidden') {
          return undefined;
        }obj2.index = i;obj2.value = this.nextSibling && this.nextSibling.textContent;obj2.type = this.type;obj2.checked = this.checked;obj1.content.push(obj2);
      });data.node.push(obj1);return data;
    },
    doAction_uiControl158_RPktTN: function (data, elem) {
      var oData = data.dataCustom;var event = data.eventType;if (event === 'onValueChange') {
        $(elem).find('input').eq(oData).click();
      }
    },
    getTemplate_uiControl158_RPktTN: function () {
      var selfTemplate = "const { CollapseCard } = AMUITouch2;\nmodule.exports = React.createClass({\n  onValueChange:function(index,data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'onValueChange',\n        data:data.index\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n   if(!data || data.length==0){\n      return(<span></span>)\n    }\n    return (\n      <div className=\"ui-content\">\n        <div className=\"amt-field-container\">\n          <div className=\"amt-field-label\" style={{\"fontWeight\":\"bolder\"}}>\n            <div>{data.title}</div>\n          </div>\n     {data.node && data.node.map(function(d,i){\n            return(\n              <div>\n               <div className=\"amt-field-label\"><div>{d.name}</div></div>\n                <div className=\"amt-field-wrap amt-field-wrap-custom\">\n                 <ul className=\"amt-choose-list\">\n                   {d.content && d.content.map((option,inx)=>{\n                      var className='amt-btn amt-btn-xs amt-btn-primary amt-btn-hollow amt-btn-selectable';\n                      if(option.checked){className = className + ' amt-btn-primary'}\n                      return(\n                        <li className=\"amt-choose-item\">\n                          <button onClick={()=>{self.onValueChange(option.value,option)}}  className={className}>{option.value}\n                            <span className=\"amt-btn-selectable-helper\">\n                              {option.checked ? <div><i className=\"amt-btn-selectable-helper-traingle\"></i><small className=\"amt-btn-selectable-helper-check\"><span className=\"amt-icon amt-icon-check\"></span></small></div> : ''}\n                            </span>\n                          </button>\n                        </li>\n                      )\n                   })}\n                 </ul>\n            </div>\n              </div>\n            )\n          })}\n        </div>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    CollapseCard = _AMUITouch.CollapseCard;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  onValueChange: function onValueChange(index, data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'onValueChange',\n        data: data.index\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement(\"span\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"ui-content\" },\n      React.createElement(\n        \"div\",\n        { className: \"amt-field-container\" },\n        React.createElement(\n          \"div\",\n          { className: \"amt-field-label\", style: { \"fontWeight\": \"bolder\" } },\n          React.createElement(\n            \"div\",\n            null,\n            data.title\n          )\n        ),\n        data.node && data.node.map(function (d, i) {\n          return React.createElement(\n            \"div\",\n            null,\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-label\" },\n              React.createElement(\n                \"div\",\n                null,\n                d.name\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-wrap amt-field-wrap-custom\" },\n              React.createElement(\n                \"ul\",\n                { className: \"amt-choose-list\" },\n                d.content && d.content.map(function (option, inx) {\n                  var className = 'amt-btn amt-btn-xs amt-btn-primary amt-btn-hollow amt-btn-selectable';\n                  if (option.checked) {\n                    className = className + ' amt-btn-primary';\n                  }\n                  return React.createElement(\n                    \"li\",\n                    { className: \"amt-choose-item\" },\n                    React.createElement(\n                      \"button\",\n                      { onClick: function onClick() {\n                          self.onValueChange(option.value, option);\n                        }, className: className },\n                      option.value,\n                      React.createElement(\n                        \"span\",\n                        { className: \"amt-btn-selectable-helper\" },\n                        option.checked ? React.createElement(\n                          \"div\",\n                          null,\n                          React.createElement(\"i\", { className: \"amt-btn-selectable-helper-traingle\" }),\n                          React.createElement(\n                            \"small\",\n                            { className: \"amt-btn-selectable-helper-check\" },\n                            React.createElement(\"span\", { className: \"amt-icon amt-icon-check\" })\n                          )\n                        ) : ''\n                      )\n                    )\n                  );\n                })\n              )\n            )\n          );\n        })\n      )\n    );\n  }\n});";
    },
    getData_control145_4sKEce: function (elem) {
      if (!elem) {
        return undefined;
      }var data = [];$(elem).find('input[type="checkbox"]').each(function (i, e) {
        var obj = {};if (this.type == 'hidden' || this.type != 'checkbox') {
          return undefined;
        } ///var _input = $(elem).find('input[type="checkbox"]');
        if (this.checked) {
          obj.checked = true;
        } else {
          obj.checked = false;
        }obj.title = this.nextSibling.textContent; //obj.checked = this.checked;
        obj.index = i;data.push(obj);
      });return data;
    },
    doAction_uiControl159_Lo7W6i: function (data, elem) {
      var eventType = data.eventType;if (eventType == "checkedClick") {
        var customData = data.customData;$(elem).find('input[type="checkbox"]').eq(customData).click();
      }
    },
    getTemplate_uiControl159_Lo7W6i: function () {
      var selfTemplate = "const {Switch} = AMUITouch2;\nmodule.exports = React.createClass({\ncheckedClick:function(i){  \n    var callBack = this.props.customHandler;  \n    if(callBack) {\n      callBack({\n        data:i,\n        eventType:'checkedClick'\n      })\n    }\n},\n  render: function() {\n    var data = this.props.customData;\n    var self = this;\n   return(\n    \t<ul className=\"amt-list ui-list\">\n      \t{\n          data.map(function(el,i){\n            return(\n            \t<li className=\"amt-item amt-item-content\" style={{\"marginTop\":\"-10px\"}}>\n                 <span className=\"amt-item-media\" >\n                    <Switch shape=\"checkbox\" checked={el.checked} onValueChange={()=>  {self.checkedClick(i)}}/>\n                </span>\n               \n                <div className=\"amt-item-main\" style={{\"fontSize\":\".875rem\"}}>\n                  {el.title}\n                </div>\n                \n              </li>\n            )\n          })\n        }\n      </ul>\n    ) \n  }\n});\n";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    Switch = _AMUITouch.Switch;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  checkedClick: function checkedClick(i) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: i,\n        eventType: 'checkedClick'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var self = this;\n    return React.createElement(\n      \"ul\",\n      { className: \"amt-list ui-list\" },\n      data.map(function (el, i) {\n        return React.createElement(\n          \"li\",\n          { className: \"amt-item amt-item-content\", style: { \"marginTop\": \"-10px\" } },\n          React.createElement(\n            \"span\",\n            { className: \"amt-item-media\" },\n            React.createElement(Switch, { shape: \"checkbox\", checked: el.checked, onValueChange: function onValueChange() {\n                self.checkedClick(i);\n              } })\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"amt-item-main\", style: { \"fontSize\": \".875rem\" } },\n            el.title\n          )\n        );\n      })\n    );\n  }\n});";
    }
  }, "lks_FM_FlowJoin");
})(window, ysp);