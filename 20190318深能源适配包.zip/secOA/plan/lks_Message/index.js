(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control8_AkC1hA: function (elem) {
      if (!elem) {
        return;
      }return "通过短信审批流程";
    },
    doAction_uiControl8_0w1q71: function (data, elem) {},
    getTemplate_uiControl8_0w1q71: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },

    getData_control11_n9fGLR: function (elem) {},
    doAction_uiControl11_D5PDrb: function (data, elem) {
      var doc = elem.ownerDocument;var aWin = doc.defaultView;if (doc.forms[0].F_Smscode.value.length == 0) {
        alert("请先获取短信验证码后，再提交");return false;
      }var queryurl = aWin.S_DbUrl + "/AG_CheckSmsCode?openagent&userad=" + doc.forms[0].ShortName.value + "&code=" + doc.forms[0].F_Smscode.value + "&m_Seq=" + Math.random();var xml = aWin.createXMLDomRequest();xml.async = false;xml.load(queryurl);var fromsms = xml.selectNodes("returnval/fromsms");var sms = aWin.trim(fromsms[0].text);if (sms != 'true') {
        aWin.alert(sms);return false;
      } // window.returnValue=document.all.F_Smscode.value;
      // window.close();
      var rtn = doc.all.F_Smscode.value;debugger;var opener = aWin.opener;setReturnVal(rtn);function setReturnVal(rtn) {
        if (rtn) {
          opener.document.all.F_SmsReviewCode.value = rtn;if (opener.parent.onFlowSubmit != null) {
            if (!opener.parent.onFlowSubmit()) {
              return;
            }
          }opener.presaveFlow();
        }
      }this.disabled = true;aWin.close();
    },
    getTemplate_uiControl11_D5PDrb: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onClick: function() {\n    this.props.customHandler({});\n  },\n  render: function() {\n    return (\n      <div className=\"ui-footer-button-flex\">\n      <div className=\"amt-btn amt-btn-warning amt-btn-block\"  onClick={this.onClick}>\n      \u63D0\u4EA4\n      </div></div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  onClick: function onClick() {\n    this.props.customHandler({});\n  },\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      { className: \"ui-footer-button-flex\" },\n      React.createElement(\n        \"div\",\n        { className: \"amt-btn amt-btn-warning amt-btn-block\", onClick: this.onClick },\n        \"\\u63D0\\u4EA4\"\n      )\n    );\n  }\n});";
    },
    getData_control124_PmwuEp: function (elem) {
      if (!elem) {
        return;
      }var data = { basicData: [], collapseData: [] };initData($(elem), data);return data;function initData($table, data) {
        var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (i, tr) {
          var trText = tr.innerText ? tr.innerText.trim() : '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
            return;
          }var $childTable = $tds.eq(0).find('table');if ($childTable.length && $childTable[0].style.display !== 'none' && $childTable[0].parentElement.style.display !== 'none') {
            data.basicData.push({ type: 'table', table: initEditTable($childTable) });return;
          }$tds.each(function (j, td) {
            if (j % 2 == 0 && $tds[j + 1]) {
              var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };var $select = $oddTd.find('select');if ($select.length) {
                initSelect($select, item);
              }var $inputs = $oddTd.find('input');if ($inputs.length) {
                initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a');if ($aLink.length) {
                initLinks($aLink, item);
              }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea) {
                item.content = content;
              }if (!label) {
                return;
              }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                data.collapseData.push(item);
              } else {
                data.basicData.push(item);
              }
            }
          });
        });
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden) {
            return;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';inputObj.readonly = false;
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.style.display == 'none') {
            return;
          }var select = {};select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none') {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.textContent };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none') {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.style.display == 'none') {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (trIndex == 0) {
              thead.push(td.textContent);
            } else {
              var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea) {
                tdObj.content = this.innerText.trim();
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl135_TNBSRi: function (data, elem) {
      var oData = data.dataCustom;var $tr = $(elem).children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var triggerElem = $tr.find('[name="' + oData.name + '"]');triggerElem.val(oData.value);
        } else if (oData.type == 'button') {
          $tr.find('[value="' + oData.value + '"]').click().attr('disabled', true);setTimeout(function () {
            $tr.find('[value="' + oData.value + '"]').removeAttr('disabled');
          }, 10000);
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          if (oData.name) {
            var $btn = $tr.find('[name="' + oData.name + '"]');$btn.click().attr('disabled', true);setTimeout(function () {
              $btn.removeAttr('disabled');
            }, 10000);
          } else {
            var $btn = $tr.find('[value="' + oData.value + '"]');$btn.click().attr('disabled', true);setTimeout(function () {
              $btn.removeAttr('disabled');
            }, 10000);
          }
        }
      }
    },
    getTemplate_uiControl135_TNBSRi: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});\n";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    }
  }, "lks_Message");
})(window, ysp);