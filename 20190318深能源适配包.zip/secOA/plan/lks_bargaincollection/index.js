(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control112_UHpN19: function (elem) {
      return elem.textContent.trim();
    },
    doAction_uiControl252_mUTVuQ: function (data, elem) {},
    getTemplate_uiControl252_mUTVuQ: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control123_CyJBnz: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "基本信息" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var data = [];if (!_elem) {
        return;
      }var $tabTr = _elem;var $table = $tabTr.find('table').first();if ($tabTr[0].style.display == 'none') {
        return;
      }var data = [];var collapseData = [];$table.children('tbody').children('tr').each(function (i, tr) {
        var trText = tr.innerText ? tr.innerText.trim() : '';var tableId = tr.parentElement.parentElement.getAttribute('id');var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：', '正文内容：', '合同附件：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
          return;
        }var $childTable = $tds.eq(0).find('table');if ($childTable.length && $childTable[0].style.display !== 'none' && $childTable[0].parentElement.style.display !== 'none') {
          data.push({ type: 'table', table: initEditTable($childTable) });
          return;
        }$tds.each(function (j, td) {
          if (j % 2 == 0 && $tds[j + 1]) {
            var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none' || this.isHidden) {
              return;
            }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };var $select = $oddTd.find('select');if ($select.length) {
              initSelect($select, item);
            }var $inputs = $oddTd.find('input');if ($inputs.length) {
              initInput($inputs, item);
            }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
              initTextArea($textarea, item);
            }var $aLink = $oddTd.find('a');if ($aLink.length) {
              initLinks($aLink, item);
            }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table) {
              item.content = content;
            }if (!label) {
              return;
            }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
              collapseData.push(item);
            } else {
              data.push(item);
            }
          } else if ($tds.length == 1 && $tds && $tds.text().match("：")) {
            var tempArr = $tds.text().split("：");data.push({ label: tempArr[0] + "：", tableId: tableId, trIndex: i, tdIndex: j, content: tempArr[1] });
          }
        });
      });return { basicData: data, collapseData: collapseData };function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden || this.iHidden) {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name,
            id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';
          if (sClick.indexOf('selectDate') != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }var tdText = td.innerText.trim().replace('〖 添 加 〗', '添加').trim();if (trIndex == 0) {
              thead.push({ colspan: this.getAttribute('colspan') || '', content: tdText });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex, colspan: this.getAttribute('colspan') || '' };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }
              var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }if (!!$(tr).attr("onclick")) {
                tdObj.hasClick = true;
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl253_R9QqPs: function (data, elem) {
      var oData = data.dataCustom;var $tabTr = $(elem).find('tbody>tr.trbg').eq(0);var $table = $tabTr.find('table').last();var $tr = $table.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var $triggerElem = $tr.find('[name="' + oData.name + '"]');$triggerElem.val(oData.value);if (oData.type == 'date') {
            var curWin = $triggerElem[0].ownerDocument.defaultView;curWin.onDateSelected && curWin.onDateSelected();
          }
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl253_R9QqPs: function () {
      var selfTemplate = "import {BasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<BasicInfo eventHandler={self.eventHandler} customData={data}></BasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.BasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control236_2Xg3GR: function (elem) {
      // 采集，注意选取的元素需要在统一window作用域内并且不要超出祖辈级tr元素的范围
      if (elem) {
        var $elem;var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
        var doc = elem.ownerDocument; // 获取当前文档对象
        if ($(elem).attr("id") == "labelTable") {
          $(elem).children("tbody").children("tr").each(function (tri, tr) {
            if ($(this)[0].style.display != "none" && $(elem).find(".labelbg1").val().indexOf("流程") == -1) {
              $elem = $(this).find('[id^="AttachmentDiv"]');
            } else {
              return;
            }
          });
        } else {
          $elem = $(elem).find('[id^="AttachmentDiv"]');
        }if ($elem && $elem.length == 0) {
          return;
        }var params = $(doc).find("#AttachmentOCX").children('param'); // 获取当前页面附件参数
        var _AttachmentObject = aWin.AttachmentObject; // 获取当前页面附件初始化对象
        var data = { Index: _AttachmentObject.Index };var existingfiles; // 初始化已存在的文件对象
        data.fileField = [];$elem && $elem.each(function (eli, fileitem) {
          existingfiles = [];$(fileitem).children("a").each(function (inputi, fileele) {
            existingfiles.push({ filename: $(fileele).text(), isUpload: $(fileele).prev("input").attr("isupload"), anchor: inputi });
          });data.fileField.push({ title: $(fileitem).closest("td").prev().text() && $(fileitem).closest("td").prev().text().trim() || "相关附件", isEdit: $(fileitem).children("input").length > 0, sqeNum: $(fileitem).attr('id').match(/\d+/)[0], existingfiles: existingfiles });
        });data.__Click = $(doc).find("input[name='__Click']").val();params.each(function (index, param) {
          switch (param.name) {case 'Server':
              data.Server = param.value;break;case 'Port':
              data.Port = param.value;break;case 'ReceiveForm':
              data.ReceiveForm = param.value;break;case 'FileInputName':
              data.FileInputName = param.value;break;case 'DocId':
              data.DocId = param.value;break;case 'FileLimits':
              data.FileLimits = param.value;break;case 'Encoding':
              data.Encoding = param.value;break;}
        });return data;
      }return;
    },
    doAction_uiControl254_1EAeoC: function (data, elem) {
      var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
      var doc = elem.ownerDocument; // 获取当前文档对象
      switch (data.eventType) {case "add":
          aWin.AttachmentObject.Add(data.customData.fieldindex, data.customData.path);break;case "delete":
          aWin.AttachmentObject.Delete(data.customData.fieldindex, data.customData.fileindex);break;case "filepreview":
          $(elem).find('#AttachmentDiv' + data.customData.index).find("a").eq(data.customData.value).click();break;}
    },
    getTemplate_uiControl254_1EAeoC: function () {
      var selfTemplate = "var AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return  data?<AttachmentUpload data={data} callback={callback}/>:\"\"\n  }\n});";
      return "\"use strict\";\n\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return data ? React.createElement(AttachmentUpload, { data: data, callback: callback }) : \"\";\n  }\n});";
    },
    getData_control237_c25Wkv: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('input').each(function (i) {
        var actived = this.className.indexOf('labelbg1') != -1;if (this.value == '发布' || this.value == '发布机制' || this.value == '权限' || this.value == '权限控制') {
          return;
        }var objInput = { id: this.getAttribute('id'), index: i, value: this.value, actived: actived, isRed: this.style.color == 'rgb(255, 0, 0)', disabled: this.getAttribute('rowdisabled') };data.push(objInput);
      });return data;
    },
    doAction_uiControl256_VvaFkE: function (data, elem) {
      if (data.eventType == 'click') {
        var index = data.customData;$(elem).find('input').eq(index).click();
      }
    },
    getTemplate_uiControl256_VvaFkE: function () {
      var selfTemplate = "var GlobalTab = require('ysp-custom-components').GlobalTab;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var _this = this;\n    return <GlobalTab callBack = {_this.clickLi} customData={this.props.customData} />;\n  }\n});";
      return "'use strict';\n\nvar GlobalTab = require('ysp-custom-components').GlobalTab;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var _this = this;\n    return React.createElement(GlobalTab, { callBack: _this.clickLi, customData: this.props.customData });\n  }\n});";
    },
    getData_control238_cJwTn9: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "版本变更记录" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var $tbReview = _elem.children('td').children('table');var data = { basicData: [], collapseData: [] };initData($tbReview, data);return data;
      } else {
        return undefined;
      }function initData($table, data) {
        var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (i, tr) {
          var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：', '相关附件：', '相关附件：\n暂无附件！'];if (td0Text.indexOf('相关附件：') != -1 || $.inArray(td0Text, hiddenRowText) != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }if (i == 0 && !tr.isHidden && $tds.length <= 1 && !this.isHidden) {
            if ($(this).find('#F_BodyView>*').length) {
              $(this).find('#F_BodyView>*').each(function () {
                var table = '';if ($(this).children('table').length == 1) {
                  table = $(this).children('table')[0].outerHTML;trText.push({ table: table });
                } else if ($(this).children('table').length == 0) {
                  trText.push({ text: this.innerText ? this.innerText.trim() : '', img: $(this).children('img').attr('src') ? $(this).children('img')[0].src : null });
                }
              });data.basicData.push({ TITLE: trText, id: $tds[0].getAttribute('id') });return;
            }
          }$tds.each(function (tdIndex, td) {
            if ($(this).find('img[src*="ecblank.gif"]').length && $tds[tdIndex + 1] && $tds[tdIndex + 1].innerText == '建筑工程') {
              $tds.splice(tdIndex, 1);
            }
          });$tds.each(function (j, td) {
            if (j % 2 == 0) {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds[j + 1] ? $tds.eq(j + 1) : $(this);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };var $childTable = $oddTd.find('table');$childTable.each(function () {
                if (this.isHidden) {
                  return;
                } else {
                  item.label = !$tds[j + 1] ? '' : item.label;if ($(this).attr("id") == "VW_VWVERSION") {
                    item.label = "所有版本";
                  }item.table = item.table || [];item.type = 'table';item.hasContent = true;item.table = initEditTable($(this));
                }
              });var $select = $oddTd.find('select').not($childTable.find('select'));if ($select.length) {
                initSelect($select, item);
              }var $inputs = $oddTd.find('input').not($childTable.find('input'));if ($inputs.length) {
                initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea').not($childTable.find('textarea'));if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a').not($childTable.find('a'));if ($aLink.length) {
                initLinks($aLink, item);
              } // if ($oddTd.find('font').length && $tds[j + 1]) {
              //   var fontText = '';
              //   $oddTd.find('font').each(function () {
              //     if (this.style.display != 'none' && !this.isHidden && this.innerText) {
              //       fontText = fontText + this.innerText + '\r\n';
              //     }
              //   });
              //   item.fontText = fontText;
              // }
              if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table && !item.fontText && $tds[j + 1]) {
                item.content = $oddTd[0].innerText.trim();
              }if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table && !item.fontText && !item.content && !$tds[j + 1]) {
                item.isConTitle = true;
              }if ($(this).find('[name="CF_No"]').length && $(this).find('[name="CF_Year"]').length) {
                item.label = this.innerHTML;delete item.inputs;
              }if (!label && !item.hasContent) {
                return;
              }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                data.collapseData.push(item);
              } else {
                data.basicData.push(item);
              }
            }
          });
        });
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.isHidden;if (isHidden || this.type == 'hidden' || this.style.display == 'none' || this.value == '导出至Excel') {
            return;
          }var type = input.type;data.type = type;data.hasContent = true;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : '', value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;inputObj.text = inputObj.text.replace('*', '');data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext && eleNext.tagName == 'A' || $(this).attr('datatype') == 'd') {
            if (!eleNext || eleNext && eleNext.tagName != 'A') {
              eleNext = $(this.parentNode.nextElementSibling).find('a')[0];
            }if (eleNext) {
              var sClick = eleNext.getAttribute('onClick') || '';if (eleNext.tagName == 'A' && sClick) {
                inputObj.text = '';
              }if (sClick.indexOf('selectDate') != -1) {
                inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = inputObj.value && aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;inputObj.readonly = eleNext.isHidden || eleNext.style.display == 'none';
              }if (sClick.indexOf('selectTime') != -1) {
                inputObj.type = 'time';inputObj.readonly = eleNext.isHidden || eleNext.style.display == 'none';
              }
            }
          }if (type == 'button' || type == 'text') {
            if (type == "text") {
              //修正授权期限不在一行的问题加入的新的属性。用于在css文件中好区分开，公共模板有修改  2018/6/22  金波
              inputObj.isInline = this.name == "CF_EndDay" ? true : false;
            }data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];data.hasContent = true;$select.each(function (i) {
          var visibility = $(this).css('visibility');if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.visibility = visibility;select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.hasContent = true;data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';var $img = $(this).parent().find('img[src*="code.gif"]');if ($img.length) {
            data.label = $(this).parent().find('font').text();this.style.display = '';
          }if (sClick.indexOf('selectDate') != -1 || sClick.indexOf('selectTime') != -1 || this.style.display == 'none' || this.isHidden) {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });if (data.link.length == 0) {
          delete data.link;
        }data.hasContent = true;
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }var tdText = td.innerText.trim().replace('〖 添 加 〗', '添加').trim();if (trIndex == 0) {
              thead.push({ colspan: this.getAttribute('colspan') || '', content: tdText });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex, colspan: this.getAttribute('colspan') || '' };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }if (!!$(tr).attr("onclick")) {
                tdObj.hasClick = true;
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl257_xIp8BT: function (data, elem) {
      var oData = data.dataCustom;var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "版本变更记录" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var $table = _elem.children('td').children('table');var $tr = $table.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var triggerElem = $tr.find('[name="' + oData.name + '"]');triggerElem.val(oData.value);
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        } else {
          $(elem).find("table#" + oData.tableId).children("tbody").children("tr").eq(oData.trIndex).click();
        }
      }
    },
    getTemplate_uiControl257_xIp8BT: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data || data.length==0){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control239_Kwi4Tm: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if ((this.value == "审批流程" || this.value == "流程") && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (!_elem || _elem && _elem[0].style.display == 'none') {
        return;
      }var arrData = { arrTitle: [], arrContent: [] };var $iframe = $(elem).find('iframe#ifFlow');if ($iframe.length) {
        _elem = $iframe[0].contentDocument;
      }var $font = $(_elem).find('#ReviewLog_TD').parent().find('td').eq(0).find('div').find('font');if ($font.length) {
        $font.each(function () {
          arrData.arrTitle.push({ title: this.textContent, color: this.getAttribute('color') });
        });
      }$(_elem).find('#FlowLog_MainTable').children('tbody').find('tr').each(function (trIndex, tr) {
        if (tr.style.display == 'none' || !this.hasAttribute('nodekey')) {
          return;
        }var $td = $(this).find('td');var tdData = {};var $userad = $td.eq(2).find('span[userad]');tdData.num = $td[0].innerText;tdData.time = $td[1].innerText;tdData.people = $td[2].innerText;tdData.oponion = $td[3].innerText;tdData.way = $td[4].innerText;var image = $td.eq(2).find('b').find('img');if (image) {
          tdData.img = [];image.each(function (imagei, img) {
            tdData.img.push(img.src);
          });
        }var $link = $td.eq(3).find('span[nodelog] a');if ($link.length) {
          tdData.links = [];tdData.oponion = $td.eq(3).find('span[nodelog]')[0].childNodes[0].textContent.trim();$link.each(function () {
            tdData.links.push({ text: this.innerText, href: this.href });
          });
        }arrData.arrContent.push(tdData);
      });return arrData;
    },
    doAction_uiControl258_zRwzKc: function (data, elem) {
      if (data.eventType == 'hrefClick') {
        var sHref = data.customData.href;if (ysp.appMain.isIOS()) {
          sHref = encodeURI(decodeURI(sHref));if (/.\pdf$/.test(sHref)) {
            ysp.appMain.openWindow(sHref + '?_ysp_forcepc=1');
          } else {
            ysp.appMain.openWindow(sHref + '?_ysp_filepreview=1');
          }
        } else {
          ysp.appMain.openWindow(sHref);
        }
      }
    },
    getTemplate_uiControl258_zRwzKc: function () {
      var selfTemplate = "\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  hrefClick:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  }, \n  render: function() {\n    var data = this.props.customData;\n    if(!data || (data && !data.arrContent.length)){\n      return(<span></span>)\n    }\n    return (\n\t\t\t\t<ProcessRecord  hrefClick={this.hrefClick} customData={data} />\n    )\n  }\n});";
      return "'use strict';\n\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  hrefClick: function hrefClick(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data && !data.arrContent.length) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(ProcessRecord, { hrefClick: this.hrefClick, customData: data });\n  }\n});";
    },
    getData_control240_I696rA: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "关联机制" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];_elem.children('td').children('table').children('tbody').children('tr').each(function (i, e) {
          var arr = { title: "", content: [], button: [] };if (i == 0) {
            arr.title = $(this).children('td')[0] && $(this).children('td')[0].innerText.trim().replace(".", "");var _table1 = $(this).next().children('td').find('table>tbody').eq(1);_table1.find('tr').eq(0).find('#dLinks').find('table>tbody').find('tr').each(function (i1, e1) {
              var _input = $(this).find('input[type="checkbox"]');var obj = {};obj.isEdit = _input.length;if (_input && _input[0] && _input[0].style.display != "none") {
                if (_input[0].checked) {
                  obj.checked = true;
                } else {
                  obj.checked = false;
                }obj.title = _input.attr("text");arr.content.push(obj);
              } else {
                obj.title = $(this).text();arr.content.push(obj);
              }
            });_table1.children("tr").eq(1).find("input").each(function (i2, e2) {
              var obj = {};obj.text = $(this).val();obj.index = i2;obj.disabled = this.disabled;arr.button.push(obj);
            });data.push(arr);
          }
        });return data;
      } else {
        return undefined;
      }
    },
    doAction_uiControl259_wdKLgh: function (data, elem) {
      var eventType = data.eventType;if (eventType == 'click') {
        var index = data.dataCustom;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
          if (this.value == "关联机制" && this.className == "labelbg1") {
            _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
          }
        });if (index == 0) {
          _elem.find('input[name="kbuAdd"]').click();
        }if (index == 1) {
          _elem.find('input[name="kbuDel"]').click();
        }if (index == 2) {
          _elem.find('input[name="kbuEdt"]').click();
        }if (index == 3) {
          _elem.find('input[name="kbuSearch"]').click();
        }
      }if (eventType == 'checkedClick') {
        var customData = data.customData;$(elem).find("#dLinks").find('input').eq(customData).click();
      }if (eventType == 'click2') {
        var customData = data.customData;$(elem).find("#dLinks").find('a').eq(customData).click();
      }
    },
    getTemplate_uiControl259_wdKLgh: function () {
      var selfTemplate = "import {GlobalAssociation} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n   if(!data){\n      return(<span></span>)\n    }\n    return(<GlobalAssociation eventHandler={self.eventHandler} customData={data}></GlobalAssociation>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.GlobalAssociation, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control241_iSFJVk: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "关联机制" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];_elem.children('td').children('table').children('tbody').children('tr').each(function (i, e) {
          var arr = { title: "", content: [] };if (i == 2) {
            arr.title = $(this).children('td')[0] && $(this).children('td')[0].innerText.trim().replace(".", "");var _table1 = $(this).next().children('td').find('table>tbody').eq(1);if (_table1[0]) {
              arr.content.push(_table1.find('#dLinks')[0] && _table1.find('#dLinks')[0].innerHTML.toLowerCase());
            }var _table2 = $(this).next();if (_table2[0]) {
              arr.content.push(_table2[0] && _table2[0].innerHTML.toLowerCase());
            }data.push(arr);
          }
        });return data;
      } else {
        return undefined;
      }
    },
    doAction_uiControl260_JeVLrs: function (data, elem) {},
    getTemplate_uiControl260_JeVLrs: function () {
      var selfTemplate = "const {\n  Field,\n  Group,\n  ButtonGroup,\n  Button,\n  Icon,\n  Title\n} = AMUITouch2;\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  onclick:function(index){\n    var handler = this.props.customHandler;\n    if(handler){\n       handler({\n         eventType:'click',\n         //\u83B7\u53D6\u81EA\u5B9A\u4E49\u5C5E\u6027\u503C\uFF08\u7D22\u5F15\u53F7\uFF09\n         data: index\n       })\n    }\n  },\n  click2:function(e){\n    var handler = this.props.customHandler;\n    var target = e.target;\n    var tbody = e.target.parentNode.parentNode.parentNode;\n    \n    var data = {tagName:target.tagName};\n    if(target.tagName ==\"INPUT\"){\n       var inputs = tbody.getElementsByTagName('input')||[];\n       for(var i = 0;i<inputs.length;i++){\n        if(target == inputs[i]){\n          \n          data.index = i;\n        }\n      }\n      data.value = target.value;\n    } else if(target.tagName =='A'){\n      var eleLinks = tbody.getElementsByTagName('a')||[];\n      for(var i = 0;i<eleLinks.length;i++){\n        if(target == eleLinks[i]){\n          data.index = i;\n        }\n      }\n      data.title = target.getAttribute('title');\n    }\n    \n    if(handler){\n       handler({\n         eventType:'click2',\n         data:data\n       })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(data && data.length == 0 || !data){\n      return (\n        <div></div>\n      )\n    }\n    var _this = this;\n    return (\n      <div className=\"ui-btn-box\">\n        {data.map(function(item,index){\n          var dat = data[index];\n          return(\n            <div className=\"ui-btn-box-inf-gxf\">\n              <Title amStyle=\"warning\">{item.title}</Title>\n              <div className=\"ui-text-Domain\">\n                 <table onClick={_this.click2} dangerouslySetInnerHTML={{__html:item.content}} className=\"ui-text-content-gxf\"></table>\n              </div>\n            </div>\n\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Group = _AMUITouch.Group,\n    ButtonGroup = _AMUITouch.ButtonGroup,\n    Button = _AMUITouch.Button,\n    Icon = _AMUITouch.Icon,\n    Title = _AMUITouch.Title;\n\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  onclick: function onclick(index) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        //\u83B7\u53D6\u81EA\u5B9A\u4E49\u5C5E\u6027\u503C\uFF08\u7D22\u5F15\u53F7\uFF09\n        data: index\n      });\n    }\n  },\n  click2: function click2(e) {\n    var handler = this.props.customHandler;\n    var target = e.target;\n    var tbody = e.target.parentNode.parentNode.parentNode;\n\n    var data = { tagName: target.tagName };\n    if (target.tagName == \"INPUT\") {\n      var inputs = tbody.getElementsByTagName('input') || [];\n      for (var i = 0; i < inputs.length; i++) {\n        if (target == inputs[i]) {\n\n          data.index = i;\n        }\n      }\n      data.value = target.value;\n    } else if (target.tagName == 'A') {\n      var eleLinks = tbody.getElementsByTagName('a') || [];\n      for (var i = 0; i < eleLinks.length; i++) {\n        if (target == eleLinks[i]) {\n          data.index = i;\n        }\n      }\n      data.title = target.getAttribute('title');\n    }\n\n    if (handler) {\n      handler({\n        eventType: 'click2',\n        data: data\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (data && data.length == 0 || !data) {\n      return React.createElement('div', null);\n    }\n    var _this = this;\n    return React.createElement(\n      'div',\n      { className: 'ui-btn-box' },\n      data.map(function (item, index) {\n        var dat = data[index];\n        return React.createElement(\n          'div',\n          { className: 'ui-btn-box-inf-gxf' },\n          React.createElement(\n            Title,\n            { amStyle: 'warning' },\n            item.title\n          ),\n          React.createElement(\n            'div',\n            { className: 'ui-text-Domain' },\n            React.createElement('table', { onClick: _this.click2, dangerouslySetInnerHTML: { __html: item.content }, className: 'ui-text-content-gxf' })\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control242_1tKmyk: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        var that = $(item).attr('value');if (that == '关闭' || that == '快速通过') {
          arry1.push({ title: $(item).attr('value'), index: index });obj.show = arry1;
        } else {
          if (that != "标准打印格式" && that != "封面打印" && that != "收藏" && that != "复制" && that != "流程挂接" && that != "发起挂接通知" && that != "打印公文正文" && that != "打印审批记录" && that != "发起督办" && that != "发布" && that != "传阅" && that != "点评" && that != "工作沟通" && that != "修改签发人" && that != "起草通知") {
            arry2.push({ title: $(item).attr('value'), index: index });obj.hide = arry2;
          }
        }
      });return obj;
    },
    doAction_uiControl261_7tfHBk: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl261_7tfHBk: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control252_lT29d1: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "款项支付记录" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var data = [];if (!_elem) {
        return;
      }var $tabTr = _elem;var $table = $tabTr.find('table#S_TablePayLog');if ($tabTr[0].style.display == 'none') {
        return;
      }if ($table.length && $table[0].style.display !== 'none' && $table[0].parentElement.style.display !== 'none') {
        data.push({ type: 'table', table: initEditTable($table) });
      }return { basicData: data };function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden || this.iHidden) {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }var tdText = td.innerText.trim().replace('〖 添 加 〗', '添加').trim();if (trIndex == 0) {
              thead.push({ colspan: this.getAttribute('colspan') || '', content: tdText });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex, colspan: this.getAttribute('colspan') || '' };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }if (!!$(tr).attr("onclick")) {
                tdObj.hasClick = true;
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl273_5zuKCu: function (data, elem) {},
    getTemplate_uiControl273_5zuKCu: function () {
      var selfTemplate = "import {BasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<BasicInfo eventHandler={self.eventHandler} customData={data}></BasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.BasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control253_Omi8pO: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "履约评价" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var data = [];if (!_elem) {
        return;
      }var $tabTr = _elem;var $table = $tabTr.find('table').first();if ($tabTr[0].style.display == 'none') {
        return;
      }var data = [];var collapseData = [];$table.children('tbody').children('tr').each(function (i, tr) {
        var trText = tr.innerText ? tr.innerText.trim() : '';var tableId = tr.parentElement.parentElement.getAttribute('id');var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：', '正文内容：', '合同附件：', '履约评价附件：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
          return;
        }var $childTable = $tds.eq(0).find('table');if ($childTable.length && $childTable[0].style.display !== 'none' && $childTable[0].parentElement.style.display !== 'none') {
          data.push({ type: 'table', table: initEditTable($childTable) });return;
        }$tds.each(function (j, td) {
          if (j % 2 == 0 && $tds[j + 1]) {
            var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none' || this.isHidden) {
              return;
            }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };var $select = $oddTd.find('select');if ($select.length) {
              initSelect($select, item);
            }var $inputs = $oddTd.find('input');if ($inputs.length) {
              initInput($inputs, item);
            }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
              initTextArea($textarea, item);
            }var $aLink = $oddTd.find('a');if ($aLink.length) {
              initLinks($aLink, item);
            }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table) {
              item.content = content;
            }if (!label) {
              return;
            }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
              collapseData.push(item);
            } else {
              data.push(item);
            }
          } else if ($tds.length == 1 && $tds && $tds.text().match("：")) {
            var tempArr = $tds.text().split("：");data.push({ label: tempArr[0] + "：", tableId: tableId, trIndex: i, tdIndex: j, content: tempArr[1] });
          }
        });
      });return { basicData: data, collapseData: collapseData };function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden || this.iHidden) {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }var tdText = td.innerText.trim().replace('〖 添 加 〗', '添加').trim();if (trIndex == 0) {
              thead.push({ colspan: this.getAttribute('colspan') || '', content: tdText });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex, colspan: this.getAttribute('colspan') || '' };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }if (!!$(tr).attr("onclick")) {
                tdObj.hasClick = true;
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl274_awlQWZ: function (data, elem) {},
    getTemplate_uiControl274_awlQWZ: function () {
      var selfTemplate = "import {BasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<BasicInfo eventHandler={self.eventHandler} customData={data}></BasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.BasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    }
  }, "lks_bargaincollection");
})(window, ysp);