(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control200_nTu7pf: function (elem) {
      if (elem) {
        var aText = elem.textContent.split('>>');var text = aText[aText.length - 1];var title = text;var yspTop = elem.ownerDocument.defaultView._ysp_top;if (yspTop) {
          var aHref = yspTop.location.href;if (aHref.indexOf('type=4') != -1) {
            title = '待阅';
          }
        }return '新建流程';
      } else {
        return '新建流程';
      }
    },
    doAction_uiControl218_WKbtzO: function (data, elem) {},
    getTemplate_uiControl218_WKbtzO: function () {
      var selfTemplate = 'import { back, closeWindow} from \'appRenderer\';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: "\u8FD4\u56DE",\n        icon: "left"\n      }]}\n  />);\n  }\n});';
      return '"use strict";\n\nvar _appRenderer = require("appRenderer");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: "\u8FD4\u56DE",\n        icon: "left"\n      }]\n    });\n  }\n});';
    },
    getData_control201_2V6Mo1: function (elem) {
      //viewTable
      if (!elem) {
        return;
      }var data = [];$(elem).find("tr").each(function (i, tr) {
        if (i > 0) {
          var obj = {};$(this).find("td").each(function (j, td) {
            var text = $(this).text() || '';if (j == 3) {
              obj.title = $(this).find("font").length ? this.innerHTML : text.trim();
            }
          });if (!!obj.title && obj.title !== '&nbsp;') {
            data.push(obj);
          }
        }
      });return data;
    },
    doAction_uiControl219_l2apeR: function (data, elem) {
      if (data.eventType === 'click') {
        var index = data.dataCustom;$(elem).find("tr").eq(index).click();
      }
    },
    getTemplate_uiControl219_l2apeR: function () {
      var selfTemplate = 'module.exports = React.createClass({\n  click:function(index){        \n    var callBack = this.props.customHandler;  \n    if(callBack) {\n      callBack({\n        data:index,\n        eventType:\'click\'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData;\n    var self = this;\n    if(!data){\n      return (<span></span>)\n    }\n    return(\n    \t<ul className="amt-list" style={{margin:\'0\',marginBottom:\'10px\'}}>\n      \t{\n          data.map(function(el,i){\n            return(\n            \t<li className="amt-item amt-item-linked"\n                onClick={function(){self.click(i+1)}}>\n               <a href="#">\n                 <h3 className="amt-item-title"  dangerouslySetInnerHTML={{__html:el.title}}></h3>\n                 <span className="amt-icon amt-icon-right amt-item-icon"></span>\n                </a>\n              \n              </li>\n            )\n          })\n        }\n      </ul>\n    ) \n  }\n});';
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  click: function click(index) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: index,\n        eventType: \'click\'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    var self = this;\n    if (!data) {\n      return React.createElement(\'span\', null);\n    }\n    return React.createElement(\n      \'ul\',\n      { className: \'amt-list\', style: { margin: \'0\', marginBottom: \'10px\' } },\n      data.map(function (el, i) {\n        return React.createElement(\n          \'li\',\n          { className: \'amt-item amt-item-linked\',\n            onClick: function onClick() {\n              self.click(i + 1);\n            } },\n          React.createElement(\n            \'a\',\n            { href: \'#\' },\n            React.createElement(\'h3\', { className: \'amt-item-title\', dangerouslySetInnerHTML: { __html: el.title } }),\n            React.createElement(\'span\', { className: \'amt-icon amt-icon-right amt-item-icon\' })\n          )\n        );\n      })\n    );\n  }\n});';
    },
    getData_control202_Nlut9R: function (elem) {
      if (!elem) {
        return;
      }var obj = {};$(elem).find("#EndPrev").attr("href") ? obj.prev = 1 : obj.prev = 0;$(elem).find("#EndNext").attr("href") ? obj.next = 1 : obj.next = 0;return obj;
    },
    doAction_uiControl220_aXUiNl: function (data, elem) {
      $(elem).find('[id="' + data.customData + '"]').click();
    },
    getTemplate_uiControl220_aXUiNl: function () {
      var selfTemplate = "const {\n  Button\n} = AMUITouch2;\nmodule.exports = React.createClass({\n  click: function(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        customData: data\n      });\n    }\n\n  },\n    render: function() {\n      var self = this;\n      var data = this.props.data.customData;\n      if(!data){\n        return(<span></span>)\n      }\n      return (\n        <div className=\"amt-g amt-g-between ui-between-PrevAndNext\" >\n         <div className=\"amt-col amt-col-2\">\n           {data.prev == 0?\n             <Button className=\"amt-btn  amt-btn-sm \"  disabled onClick={()=>{self.click('EndPrev')}}>\u4E0A\u4E00\u9875</Button>\n             :<Button className=\"amt-btn  amt-btn-sm \" style={{\"background\":\"#fff\"}} onClick={()=>{self.click('EndPrev')}}>\u4E0A\u4E00\u9875</Button>\n           }\n         </div>\n         <div className=\"amt-col amt-col-2\">\n           {data.next == 0?\n           \t\t<Button className=\"amt-btn   amt-btn-sm amt-btn-warning\" disabled onClick={()=>{self.click('EndNext')}}>\u4E0B\u4E00\u9875</Button>\n             :<Button className=\"amt-btn   amt-btn-sm amt-btn-warning\"  onClick={()=>{self.click('EndNext')}}>\u4E0B\u4E00\u9875</Button>\n           }\n         </div>\n          </div>\n      )\n    }\n  });\n";
      return '"use strict";\n\nvar _AMUITouch = AMUITouch2,\n    Button = _AMUITouch.Button;\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  click: function click(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'click\',\n        customData: data\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.data.customData;\n    if (!data) {\n      return React.createElement("span", null);\n    }\n    return React.createElement(\n      "div",\n      { className: "amt-g amt-g-between ui-between-PrevAndNext" },\n      React.createElement(\n        "div",\n        { className: "amt-col amt-col-2" },\n        data.prev == 0 ? React.createElement(\n          Button,\n          { className: "amt-btn  amt-btn-sm ", disabled: true, onClick: function onClick() {\n              self.click(\'EndPrev\');\n            } },\n          "\\u4E0A\\u4E00\\u9875"\n        ) : React.createElement(\n          Button,\n          { className: "amt-btn  amt-btn-sm ", style: { "background": "#fff" }, onClick: function onClick() {\n              self.click(\'EndPrev\');\n            } },\n          "\\u4E0A\\u4E00\\u9875"\n        )\n      ),\n      React.createElement(\n        "div",\n        { className: "amt-col amt-col-2" },\n        data.next == 0 ? React.createElement(\n          Button,\n          { className: "amt-btn   amt-btn-sm amt-btn-warning", disabled: true, onClick: function onClick() {\n              self.click(\'EndNext\');\n            } },\n          "\\u4E0B\\u4E00\\u9875"\n        ) : React.createElement(\n          Button,\n          { className: "amt-btn   amt-btn-sm amt-btn-warning", onClick: function onClick() {\n              self.click(\'EndNext\');\n            } },\n          "\\u4E0B\\u4E00\\u9875"\n        )\n      )\n    );\n  }\n});';
    }
  }, "lks_devconfigsec");
})(window, ysp);