(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control170_JqRkbf: function (elem) {
      if (!elem) {
        return;
      }$(elem).parent();var _elem = elem;var _url = elem.ownerDocument.location.href;if (_elem && _elem.style.display != "none") {
        var doc = _elem.contentDocument; // debugger
        var $tbReview = $(_elem);var data = [];var collapseData = [];$tbReview.children('tbody').children('tr').each(function (i, tr) {
          if (i == 0 && $(this).text()) {
            data.push({ TITLE: $(this).text() && $(this).text().trim() });
          }
          var $ysInformation = $tbReview.find('#tab_yusuan').find('tbody>tr').children('td');var $currency;if ($tbReview.find('tbody>tr').eq(1).find("table").length != 0) {
            $currency = $tbReview.find('tbody>tr').eq(1).find('td>table>tbody>tr>td').eq(1);
          } else if ($tbReview.find('tbody>tr').eq(1).text().indexOf("币种") != -1 || $tbReview.find('tbody>tr').eq(1).text().indexOf("单据及附件") != -1) {
            $currency = $tbReview.find('tbody>tr').eq(1).find("td").eq(0);
          }if ($($tbReview).find("#multiRowTable").size() != 0) {
            var $currencyTable;if ($($tbReview).find("#multiRowTable").next().length != 0) {
              $currencyTable = '<div class="ui-basicTable-scroll-nav"> ' + $($tbReview).find("#multiRowTable").attr("title") + ' </div>' + '<div class="ui-basicTable-scroll ui-basicTable-scroll-both1">' + $($tbReview).find("#multiRowTable")[0].outerHTML + '</div>' + '<div class="ui-basicTable-scroll ui-basicTable-scroll-both2">' + $($tbReview).find("#multiRowTable").next()[0].outerHTML + '</div>';
            } else {
              $currencyTable = '<div class="ui-basicTable-scroll-nav"> ' + $($tbReview).find("#multiRowTable").attr("title") + ' </div>' + '<div class="ui-basicTable-scroll ">' + $($tbReview).find("#multiRowTable")[0].outerHTML + '</div>';
            }
          }if (i == 1) {
            //预算信息
            $ysInformation.each(function (y, td1) {
              if (y == 0) {
                var label = $ysInformation.eq(y).find('b').eq(0).text();var content = $ysInformation.eq(y).find('b').eq(1).text().trim();var item1 = { label: label, bIndex: y, content: content };data.push(item1);
              }if (y == 1) {
                $ysInformation.eq(y).find('b').each(function (b, b1) {
                  label = $(this).text() && $(this).text().trim();var item1 = { label: label, bIndex: y };data.push(item1);
                });
              }
            }); //币种
            $currency.find('b').each(function (c, td2) {
              if (c == 0 || c == 1) {
                var label = $(this).text();if (c == 0) {
                  var content = this.nextSibling.textContent;
                }if (c == 1) {
                  var content = this.nextSibling.textContent + "张";
                }var item2 = { label: label, content: content };data.push(item2);
              }
            });
          }var trId = this.getAttribute('id') || '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
            return;
          }$tds.each(function (j, td) {
            if ($($tds).find("table#multiRowTable").length != 0 && $($tds).find("table#multiRowTable").eq(0).attr('style') != "") {
              var $nTables = 0;if ($($currencyTable).size() != 0) {
                var item = { table: $currencyTable };data.push(item);
              }return false;
            }if (j % 2 == 0 && $tds[j + 1]) {
              var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, trIndex: i };var $select = $oddTd.find('select');if ($select.length) {
                initSelect($select, item);
              }
              var $inputs = $oddTd.find('input');if ($inputs.length) {
                initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a');if ($aLink.length) {
                initLinks($aLink, item);
              }var content = $oddTd[0].innerText.trim();if (label == "申请借款金额") {
                content = $oddTd[0].innerText + "\r\n\r\n\r\n\r\n" + $oddTd.parent().next()[0].innerText;
              }if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table) {
                item.content = content;
              }if (!label) {
                return;
              }
              if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                collapseData.push(item);
              } else {
                data.push(item);
              }
            }
          });
        });return { basicData: data, collapseData: collapseData };
      } else {
        return undefined;
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden || this.isHidden) {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';inputObj.readonly = eleNext.isHidden;
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};
          select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }
      function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none') {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none' || this.isHidden) {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }
    }, doAction_uiControl186_PopBfL: function (data, elem) {}, getTemplate_uiControl186_PopBfL: function () {
      var selfTemplate = 'import {ReviewBasicInfo} from \'ysp-custom-components\';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data || !data.basicData[0]){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});';
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || !data.basicData[0]) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control172_ZzrKP5: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;_elem = $(elem).parent().children("div:last-of-type").children("table")[0];if (_elem && _elem.style.display != "none") {
        var doc = _elem.contentDocument;var $tbReview = $(_elem);var data = [];var collapseData = [];$tbReview.children('tbody').children('tr').each(function (i, tr) {
          if (i == 0 && $(this).text()) {
            data.push({ TITLE: $(this).text() && $(this).text().trim() });
          }var $ysInformation = $tbReview.find('#tab_yusuan').find('tbody>tr').children('td');var $currency;if ($tbReview.find('tbody>tr').eq(1).find("table").length != 0) {
            $currency = $tbReview.find('tbody>tr').eq(1).find('td>table>tbody>tr>td').eq(1);
          } else if ($tbReview.find('tbody>tr').eq(1).text().indexOf("币种") != -1 || $tbReview.find('tbody>tr').eq(1).text().indexOf("单据及附件") != -1) {
            $currency = $tbReview.find('tbody>tr').eq(1).find("td").eq(0);
          }if ($($tbReview).find("#multiRowTable").size() != 0) {
            var $currencyTable;if ($($tbReview).find("#multiRowTable").next().length != 0) {
              $currencyTable = '<div class="ui-basicTable-scroll-nav"> ' + $($tbReview).find("#multiRowTable").attr("title") + ' </div>' + '<div class="ui-basicTable-scroll ui-basicTable-scroll-both1">' + $($tbReview).find("#multiRowTable")[0].outerHTML + '</div>' + '<div class="ui-basicTable-scroll ui-basicTable-scroll-both2">' + $($tbReview).find("#multiRowTable").next()[0].outerHTML + '</div>';
            } else {
              $currencyTable = '<div class="ui-basicTable-scroll-nav"> ' + $($tbReview).find("#multiRowTable").attr("title") + ' </div>' + '<div class="ui-basicTable-scroll ">' + $($tbReview).find("#multiRowTable")[0].outerHTML + '</div>';
            }
          }if (i == 1) {
            //预算信息
            $ysInformation.each(function (y, td1) {
              if (y == 0) {
                var label = $ysInformation.eq(y).find('b').eq(0).text();var content = $ysInformation.eq(y).find('b').eq(1).text().trim();var item1 = { label: label, bIndex: y, content: content };data.push(item1);
              }if (y == 1) {
                $ysInformation.eq(y).find('b').each(function (b, b1) {
                  label = $(this).text() && $(this).text().trim();var item1 = { label: label, bIndex: y };data.push(item1);
                });
              }
            }); //币种
            $currency.find('b').each(function (c, td2) {
              if (c == 0 || c == 1) {
                if ($(this).text() == "凭证抬头") {
                  return false;
                }var label = $(this).text();if (c == 0) {
                  var content = this.nextSibling.textContent;
                }if (c == 1) {
                  var content = this.nextSibling.textContent + "张";
                }var item2 = { label: label, content: content };data.push(item2);
              }
            });
          }var trId = this.getAttribute('id') || '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
            return;
          }$tds.each(function (j, td) {
            if ($($tds).find("table#multiRowTable").length != 0 && $($tds).find("table#multiRowTable").eq(0).attr('style') != "") {
              var $nTables = 0;if ($($currencyTable).size() != 0) {
                var item = { table: $currencyTable };data.push(item);
              }return false;
            }if (j == 0 && $(td).find("table").eq(0).find("input").eq(0).attr("id") == "bc") {
              var item = { trIndex: i };var $inputs = $(td).find('input').slice(0, 2);if ($inputs.length) {
                initInput($inputs, item);
              }data.push(item);
            }if (j % 2 == 0 && $tds[j + 1]) {
              var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, trIndex: i };var $select = $oddTd.find('select');if ($select.length) {
                initSelect($select, item);
              }var $inputs = $oddTd.find('input');if ($inputs.length) {
                initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a');if ($aLink.length) {
                initLinks($aLink, item);
              }var content = $oddTd[0].innerText.trim();if (label == "申请借款金额") {
                content = $oddTd[0].innerText + "\r\n\r\n\r\n\r\n" + $oddTd.parent().next()[0].innerText;
              }if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table) {
                item.content = content;
              }if (!label) {
                return;
              }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                collapseData.push(item);
              } else {
                data.push(item);
              }
            }
          });
        });return { basicData: data, collapseData: collapseData };
      } else {
        return undefined;
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden || this.isHidden) {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          } // debugger;
          var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';inputObj.readonly = eleNext.isHidden;
            }
          }if (this.title.indexOf("凭证日期") != -1 || this.title.indexOf("过账日期") != -1) {
            inputObj.type = 'date';inputObj.readonly = this.isHidden;
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || ''; // console.log(inputObj.label);
            data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none') {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none' || this.isHidden) {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }
    },
    doAction_uiControl187_zP3CZN: function (data, elem) {
      var oData = data.dataCustom;var _elem;$(elem).parent().children("div:last-of-type").children("table").each((index, item) => {
        _elem = $(elem).parent().children("div:last-of-type").children("table")[0];
      });$tbReview = $(_elem);var $tr = $tbReview.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var $triggerElem = $tr.find('[name="' + oData.name + '"]');$triggerElem.val(oData.value);if (oData.type == 'date') {
            var curWin = $triggerElem[0].ownerDocument.defaultView;curWin.onDateSelected && curWin.onDateSelected();
          }
        } else if (oData.type == 'button') {
          $tr.find('[value="' + oData.value + '"]').click();
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl187_zP3CZN: function () {
      var selfTemplate = 'import {ReviewBasicInfo} from \'ysp-custom-components\';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data || !data.basicData[0]){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});';
      return '\'use strict\';\n\nvar _yspCustomComponents = require(\'ysp-custom-components\');\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || !data.basicData[0]) {\n      return React.createElement(\'span\', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});';
    },

    getData_control169_rJRxyu: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;_elem = $(elem).parent().children("div:last-of-type").find("#TABLE1")[0];var $scriptBind = $(elem).parent().children('table:last-of-type').find("tr").eq(1).children("td").children("script:last-of-type");if (_elem && _elem.style.display != "none") {
        var $tbReview = $(_elem).find("#tbin");var data = { basicData: [], collapseData: [] };initData($tbReview, data, $scriptBind);return data;
      } else {
        return undefined;
      }function initData($table, data, $scriptBind) {
        $table.children('tbody').children('tr').each(function (i, tr) {
          if (i == 0) {
            data.basicData.push({ TITLE: "凭证行项目" });return;
          }
        });$table.each(function () {
          if (this.isHidden) {
            return;
          } else {
            data.basicData.push({ type: 'table', table: initEditTable($(this), $scriptBind) });
          }
        });
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.isHidden;if (isHidden || this.type == 'hidden') {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          var visibility = $(this).css('visibility');if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.visibility = visibility;select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none' || this.isHidden) {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }function initEditTable($table, $scriptBind) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }if (trIndex == 0) {
              thead.push({ content: td.textContent });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl106_RXupf4: function (data, elem) {
      var oData = data.dataCustom;_elem = $(elem).parent().children("div:last-of-type").find("#TABLE1")[0];var $tbReview = $(_elem).find("#tbin");var $tr = $tbReview.children('tbody').children('tr').eq(oData.trIndex); // debugger;
      if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var $triggerElem = $tr.find('[name="' + oData.name + '"]');$triggerElem.val(oData.value);var curWin = $triggerElem[0].ownerDocument.defaultView;if (oData.type == 'date') {
            curWin.onDateSelected && curWin.onDateSelected();
          } // debugger;
          if (oData.name == 'CF_CGKSRQ_SJ' || oData.name == 'CF_CGJSRQ_SJ') {
            curWin.calcDifferDate && curWin.calcDifferDate('CF_CGKSRQ_SJ', 'CF_CGJSRQ_SJ', 'CF_CGTS_SJ');
          }if (oData.name == 'CF_CGKSRQ_JH' || oData.name == 'CF_CGJSRQ_JH') {
            curWin.calcDifferDate && curWin.calcDifferDate('CF_CGKSRQ_JH', 'CF_CGJSRQ_JH', 'CF_CGTS_JH');
          }
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          debugger;$tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl106_RXupf4: function () {
      var selfTemplate = 'import {ReviewBasicInfo} from \'ysp-custom-components\';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data  || !data.basicData[0]){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});';
      return '\'use strict\';\n\nvar _yspCustomComponents = require(\'ysp-custom-components\');\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || !data.basicData[0]) {\n      return React.createElement(\'span\', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});';
    }
  }, 'lks_financeflowreview_edit');
})(window, ysp);