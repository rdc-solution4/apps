(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control198_EeZVN5: function (elem) {
      if (elem) {
        var data = ["已办、阅的文档", "我发起的文档", "我授权他人处理的文档", "按创建时间"];
        return data;
      }return;
    },
    doAction_uiControl215_RoLmMC: function (data, elem) {
      var _data = data.customData;var type = data.eventType;var _elem;$(elem).find("a").each(function () {
        if ($(this).text() == _data) {
          _elem = $(this);
        }
      });switch (type) {
        case "itemClick":
          _elem.click();break;case "expandNode":
          var _btn = _elem.parent().prev("td").children("a[href]").eq(0);if (/nodeplus/.test(_btn.children("img").attr("src"))) {
            _btn.click();
          }break;}
    },
    getTemplate_uiControl215_RoLmMC: function () {
      var selfTemplate = "module.exports = React.createClass({\n  itemClick:function(data){\n    var cb = this.props.customHandler;\n    if(cb){\n      if(data==\"\u6211\u53D1\u8D77\u7684\u6587\u6863\"){\n        cb({\n          eventType:\"expandNode\",\n          data:data\n        })\n        cb({\n          eventType:\"section-trigger\",\n          data:'control201_cXUhTS'\n        })\n      } else {\n        cb({\n          eventType:\"itemClick\",\n          data:data\n        })\n      }\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n    var styleList = [\"icon-usercenter icon-usercenter-done\",\"icon-usercenter icon-usercenter-create\",\"icon-usercenter icon-usercenter-auth\",\"icon-usercenter icon-usercenter-createtime\"]\n    return (\n      <div className=\"usercenter-container\">\n        {\n          data?data.map(function(item,i){\n            return <div className=\"usercenter-list-item\" onClick={(e)=>{\n                _this.itemClick(item);\n              }}>\n              <div className=\"usercenter-list-icon\">\n                <span className={styleList[i]}></span>\n              </div>\n              <div className=\"usercenter-list-title\">{item}<span className=\"amt-icon amt-icon-right\"></span></div>\n            </div>\n          }):\"\"\n        }\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  itemClick: function itemClick(data) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      if (data == \"\u6211\u53D1\u8D77\u7684\u6587\u6863\") {\n        cb({\n          eventType: \"expandNode\",\n          data: data\n        });\n        cb({\n          eventType: \"section-trigger\",\n          data: 'control201_cXUhTS'\n        });\n      } else {\n        cb({\n          eventType: \"itemClick\",\n          data: data\n        });\n      }\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    var styleList = [\"icon-usercenter icon-usercenter-done\", \"icon-usercenter icon-usercenter-create\", \"icon-usercenter icon-usercenter-auth\", \"icon-usercenter icon-usercenter-createtime\"];\n    return React.createElement(\n      \"div\",\n      { className: \"usercenter-container\" },\n      data ? data.map(function (item, i) {\n        return React.createElement(\n          \"div\",\n          { className: \"usercenter-list-item\", onClick: function onClick(e) {\n              _this.itemClick(item);\n            } },\n          React.createElement(\n            \"div\",\n            { className: \"usercenter-list-icon\" },\n            React.createElement(\"span\", { className: styleList[i] })\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"usercenter-list-title\" },\n            item,\n            React.createElement(\"span\", { className: \"amt-icon amt-icon-right\" })\n          )\n        );\n      }) : \"\"\n    );\n  }\n});";
    },
    getData_control199_9BRZEb: function (elem) {
      if (elem) {
        return "用户中心";
      }return;
    },
    doAction_uiControl216_7eV0fU: function (data, elem) {},
    getTemplate_uiControl216_7eV0fU: function () {
      var selfTemplate = "import { back, closeWindow} from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    }
  }, "lks_hub");
})(window, ysp);