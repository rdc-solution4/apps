(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control178_JnLCT8: function (elem) {
      return elem && elem.textContent || '通知公告';
    },
    doAction_uiControl195_r78wps: function (data, elem) {},
    getTemplate_uiControl195_r78wps: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      data = '\u901A\u77E5\u516C\u544A';\n    }\n  \treturn (<NavBar \n      title={data}\n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "'use strict';\n\nvar _appRenderer = require('appRenderer');\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      data = '\u901A\u77E5\u516C\u544A';\n    }\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control186_D5LeAN: function (elem) {
      if (elem) {
        var data = {};var $table = $(elem).find("#htmlEdit").closest("table");var newscontent = $(elem).find("#htmlEdit").find("#F_BodyView").text();var aWin = elem.ownerDocument.defaultView;if (!$table.length) {
          $table = $(elem).children('table').last();
        }if ($table.length > 0) {
          if (aWin.location.href.indexOf("EditDocument") == -1) {
            data.isEdit = false;data.item = [];$table.children("tbody").children("tr").each(function (tri, tr) {
              // if (tri == 0 && $(this).children("td").length == 1) {
              //   data.title = $(this).text() && $(this).text().trim();
              // }
              if (tri == 1 && $(this).children("td").length == 1) {
                data.title = $(this).text() && $(this).text().trim();
              }if ($(this).children("td").length > 2) {
                $(this).children("td").each(function (tdi, td) {
                  data.item.push({ label: $(this).text() && $(this).text().split("：")[0], text: $(this).text() && $(this).text().split("：")[1] });
                });
              }if ($(this).children("td").length == 2 && $(this).text() && $(this)[0].style.display != "none" && $(this).text().indexOf("附件") == -1 && $(this).text().indexOf("审批记录") == -1 && $(this).text().indexOf("阅读记录") == -1 && $(this).text().indexOf("编辑记录 ") == -1) {
                data.item.push({ label: $(this).children("td").eq(0).text() && $(this).children("td").eq(0).text().trim(), text: $(this).children("td").eq(1).text() && $(this).children("td").eq(1).text().trim() });
              }if ($(this).children("td").length == 1 && $(this).find("#htmlEdit").length > 0) {
                data.item.push({ label: "正文", text: $(this).find("#htmlEdit").find("#F_BodyView").text().replace(/\s+/, "").replace(/\n/g, "").replace(" ", "") });
              }
            });
          } else {
            data.isEdit = true;
            data.item = [];$table.children("tbody").children("tr").each(function (tri, tr) {
              // debugger;
              if ($(this).children("td").length == 1 || !$(this).children("td").eq(0).text() || $(this)[0].style.display == "none" || $(this).text().indexOf("附件") != -1 || $(this).text().indexOf("编辑方式") != -1 || $(this).text().indexOf("审批记录") != -1 || $(this).text().indexOf("阅读记录") != -1 || $(this).text().indexOf("编辑记录") != -1) {
                return;
              }$(this).children("td").each(function (tdi, td) {
                var _content = [];if (tdi % 2 == 0) {
                  if ($(this).next().children("textarea").length > 0) {
                    _content.push({ tri: tri, tdi: tdi, type: "textarea", value: $(this).next().children("textarea").val() && $(this).next().children("textarea").val(), text: $(this).next().children("textarea").next()[0] && $(this).next().children("textarea").next()[0].nextSibling.nodeValue });
                  }if ($(this).next().find("select").length > 0) {
                    var options = [];$(this).next().find("select").children("option").each(function (optioni, option) {
                      options.push($(this).text() && $(this).text().trim());
                    });_content.push({ tri: tri, tdi: tdi, type: "select", options: options });
                  }if ($(this).next().find("input").length > 0) {
                    $(this).next().find("input").each(function (inputi, input) {
                      if ($(this).attr("type") == "hidden" || $(this).parent()[0].style.display == "none") {
                        return;
                      }if ($(this).attr("name") == "F_Importance") {// debugger;
                      }_content.push({ tri: tri, tdi: tdi, inputi: inputi, type: $(this).attr("type") || "text", value: $(this).val(), text: $(this)[0].nextSibling.nodeValue, checked: $(this).parent().find("input[name='F_Importance']:checked").val() == $(this).val(), readOnly: $(this).attr("readonly") });
                    });
                  }if (!!$(this).next().text() && $(this).next().find("input").length == 0 && $(this).next().children("textarea").length == 0 && $(this).next().find("select").length == 0) {
                    data.item.push({ label: $(this).text() && $(this).text().trim(), text: $(this).next().text() && $(this).next().text().replace(/\n/g, "<br>") });
                  } else {
                    data.item.push({ label: $(this).text() && $(this).text().trim(), content: _content });
                  }
                }
              });
            });
          }
        }return data;
      }return;
    },
    doAction_uiControl201_taSGr7: function (data, elem) {
      var $table = $(elem).find("#htmlEdit").closest("table");var aWin = elem.ownerDocument.defaultView;var type = data.eventType;var _data = data.customData;switch (type) {case "radioClick":
          $table.children("tbody").children("tr").eq(_data.tri).children("td").eq(_data.tdi + 1).find("input").eq(_data.inputi).click();break;case "valueChange":
          $table.children("tbody").children("tr").eq(_data.tri).children("td").eq(_data.tdi + 1).find("input").eq(_data.inputi).val(_data.value);break;case "textareaChange":
          $table.children("tbody").children("tr").eq(_data.tri).children("td").eq(_data.tdi + 1).children("textarea").val(_data.value);break;}
    },
    getTemplate_uiControl201_taSGr7: function () {
      var selfTemplate = "import {News} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  callback:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n \t\tif(!data || (!data.item)){\n      return(<span></span>)\n    }\n    return(<News data={data} callback={_this.callback}/>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  callback: function callback(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    if (!data || !data.item) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.News, { data: data, callback: _this.callback });\n  }\n});";
    },
    getData_control187_ZdyL4I: function (elem) {
      // 采集，注意选取的元素需要在统一window作用域内并且不要超出祖辈级tr元素的范围
      if (elem) {
        var $elem;var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
        var doc = elem.ownerDocument; // 获取当前文档对象
        if ($(elem).attr("id") == "labelTable") {
          $(elem).children("tbody").children("tr").each(function (tri, tr) {
            if ($(this)[0].style.display != "none" && $(elem).find(".labelbg1").val().indexOf("流程") == -1) {
              $elem = $(this).find('[id^="AttachmentDiv"]');
            } else {
              return;
            }
          });
        } else {
          $elem = $(elem).find('[id^="AttachmentDiv"]');
        }if ($elem && $elem.length == 0) {
          return;
        }var params = $(doc).find("#AttachmentOCX").children('param'); // 获取当前页面附件参数
        var _AttachmentObject = aWin.AttachmentObject; // 获取当前页面附件初始化对象
        var data = { Index: _AttachmentObject.Index };var existingfiles; // 初始化已存在的文件对象
        data.fileField = [];$elem && $elem.each(function (eli, fileitem) {
          existingfiles = [];$(fileitem).children("a").each(function (inputi, fileele) {
            existingfiles.push({ filename: $(fileele).text(), isUpload: $(fileele).prev("input").attr("isupload"), anchor: inputi });
          });data.fileField.push({ title: $(fileitem).closest("td").prev().text() && $(fileitem).closest("td").prev().text().trim() || "相关附件", isEdit: $(fileitem).children("input").length > 0, sqeNum: $(fileitem).attr('id').match(/\d+/)[0], existingfiles: existingfiles });
        });data.__Click = $(doc).find("input[name='__Click']").val();params.each(function (index, param) {
          switch (param.name) {case 'Server':
              data.Server = param.value;break;case 'Port':
              data.Port = param.value;break;case 'ReceiveForm':
              data.ReceiveForm = param.value;break;case 'FileInputName':
              data.FileInputName = param.value;break;case 'DocId':
              data.DocId = param.value;break;case 'FileLimits':
              data.FileLimits = param.value;break;case 'Encoding':
              data.Encoding = param.value;break;}
        });return data;
      }return;
    },
    doAction_uiControl202_9GLIZb: function (data, elem) {
      var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
      var doc = elem.ownerDocument; // 获取当前文档对象
      switch (data.eventType) {case "add":
          aWin.AttachmentObject.Add(data.customData.fieldindex, data.customData.path);break;case "delete":
          aWin.AttachmentObject.Delete(data.customData.fieldindex, data.customData.fileindex);break;case "filepreview":
          $(elem).find('#AttachmentDiv' + data.customData.index).find("a").eq(data.customData.value).click();break;}
    },
    getTemplate_uiControl202_9GLIZb: function () {
      var selfTemplate = "var AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return  data?<AttachmentUpload data={data} callback={callback}/>:\"\"\n  }\n});";
      return "\"use strict\";\n\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return data ? React.createElement(AttachmentUpload, { data: data, callback: callback }) : \"\";\n  }\n});";
    },
    getData_control188_6Arw8S: function (elem) {
      if (!elem) {
        return;
      }var $table = $(elem).find("#htmlEdit").closest("table");var aWin = elem.ownerDocument.defaultView;var _elem = $table;var arrData = { arrTitle: [], arrContent: [] };var $font = $(elem).find('#ReviewLog_TD').parent().find('td').eq(0).find('div').find('font');if ($font.length) {
        $font.each(function () {
          arrData.arrTitle.push({ title: this.textContent, color: this.getAttribute('color') });
        });
      }$(elem).find('#FlowLog_MainTable').children('tbody').find('tr').each(function (trIndex, tr) {
        if (tr.style.display == 'none' || !$(this).attr('nodekey')) {
          return;
        }var $td = $(this).find('td');var tdData = {};var $userad = $td.eq(2).find('[userad]');tdData.num = $td[0].innerText;tdData.time = $td[1].innerText;tdData.people = $td[2].innerText;;tdData.oponion = $td[3].innerText;tdData.way = $td[4].innerText;var $link = $td.eq(3).find('span[nodelog] a');if ($link.length) {
          tdData.links = [];tdData.oponion = $td.eq(3).find('span[nodelog]')[0].childNodes[0].textContent.trim();$link.each(function () {
            tdData.links.push({ text: this.innerText, href: this.href });
          });
        }arrData.arrContent.push(tdData);
      });return arrData;
    },
    doAction_uiControl203_ZgGKJQ: function (data, elem) {
      if (data.eventType == 'hrefClick') {
        var sHref = data.customData.href;if (ysp.appMain.isIOS()) {
          ysp.appMain.openWindow(sHref + '?_ysp_filepreview=1');
        } else {
          ysp.appMain.openWindow(sHref);
        }
      }
    },
    getTemplate_uiControl203_ZgGKJQ: function () {
      var selfTemplate = "\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  hrefClick:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  }, \n  render: function() {\n    var data = this.props.customData;\n    if(!data || (data && !data.arrContent.length)){\n      return(<span></span>)\n    }\n    return (\n\t\t\t\t<ProcessRecord  hrefClick={this.hrefClick} customData={data} />\n    )\n  }\n});";
      return "'use strict';\n\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  hrefClick: function hrefClick(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data && !data.arrContent.length) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(ProcessRecord, { hrefClick: this.hrefClick, customData: data });\n  }\n});";
    },
    getData_control189_2SMoQ4: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        var that = $(item).attr('value');if (that == '关闭' || that == '快速通过') {
          arry1.push({ title: $(item).attr('value'), index: index });obj.show = arry1;
        } else {
          if (that != "标准打印格式" && that != "封面打印" && that != "收藏" && that != "复制" && that != "流程挂接" && that != "发起挂接通知" && that != "打印公文正文" && that != "打印审批记录" && that != "发起督办" && that != "发布" && that != "传阅" && that != "点评" && that != "工作沟通" && that != "打印新闻正文" && that != "下载正文") {
            arry2.push({ title: $(item).attr('value'), index: index });obj.hide = arry2;
          }
        }
      });return obj;
    },
    doAction_uiControl204_aEuDas: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl204_aEuDas: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control194_HxlLw6: function (elem) {
      if (!elem) {
        return;
      }if (elem) {
        // 采集元素下载公文正文
        var aWin = elem.ownerDocument.defaultView;var attachmentObject = aWin.AttachmentObject;var attachments = attachmentObject ? attachmentObject.Attachments : [];var data;var attLength = attachments.length;for (var i = attLength - 1; i >= 0; i--) {
          var name = attachments[i];if (name.indexOf('LKS') != -1 && name.toLowerCase().indexOf('.pdf') != -1) {
            data = name;break;
          } else if (name.indexOf('LKS') != -1) {
            data = name;break;
          }
        }return data;
      }
    },
    doAction_uiControl210_OzTK0k: function (data, elem) {
      if (data.eventType === 'click') {
        var oData = data.dataCustom;var aWin = elem.ownerDocument.defaultView;var location = aWin.location;var fileName = oData;var path = location.origin + location.pathname;var downloadUrl = path + '/$FILE/' + fileName;if (ysp.appMain.isIOS()) {
          ysp.appMain.openWindow(downloadUrl + '?_ysp_filepreview=1');
        } else {
          aWin.location.href = downloadUrl;
        }
      }
    },
    getTemplate_uiControl210_OzTK0k: function () {
      var selfTemplate = "const { Button } = AMUITouch2;\nmodule.exports = React.createClass({\n  click:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'click',\n        data:data\n      });\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div className='amt-card'>\n       <Button block amStyle=\"warning\" onClick={()=>{self.click(data)}}>\u70B9\u51FB\u9884\u89C8\u6B63\u6587</Button>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Button = _AMUITouch.Button;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: data\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(\n      'div',\n      { className: 'amt-card' },\n      React.createElement(\n        Button,\n        { block: true, amStyle: 'warning', onClick: function onClick() {\n            self.click(data);\n          } },\n        '\\u70B9\\u51FB\\u9884\\u89C8\\u6B63\\u6587'\n      )\n    );\n  }\n});";
    }
  }, "lks_news");
})(window, ysp);