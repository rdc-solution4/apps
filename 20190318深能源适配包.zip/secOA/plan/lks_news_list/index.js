(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control179_GTKnRp: function (elem) {
      if (!elem) {
        return;
      }var data = []; // $(elem).find("tr").eq(0)
      var head = [];$(elem).find("tr").each(function (i, tr) {
        if (i == 0) {
          $(this).find('td').each(function () {
            head.push(this.textContent);
          });
        }if (i > 0 && $(tr).text().trim() != "") {
          obj = {};$(this).find('td').each(function (j, td) {
            if (head[j].indexOf('主题') != -1) {
              obj.subject = $(this).text();
            }if (head[j].indexOf('重要性') != -1) {
              obj.importance = $(this).text();
            }if (head[j].indexOf('提交者') != -1) {
              obj.committer = $(this).text();
            }
          });data.push(obj);
        }
      });return data;
    }, doAction_uiControl196_cZJLc4: function (data, elem) {
      if (data.eventType === 'click') {
        var index = data.dataCustom;
        $(elem).find("tr").eq(index).click();
      }
    },
    getTemplate_uiControl196_cZJLc4: function () {
      var selfTemplate = "module.exports = React.createClass({\n   haderClick:function(index){        \n    var callBack = this.props.customHandler;  \n    if(callBack) {\n      callBack({\n        data:index,\n        eventType:'click'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData;\n    var _this = this;\n    if(!data){\n      return(<span></span>)\n    }\n    return(\t<ul className=\"amt-list ui-list\">\n      \t{\n          data.map(function(el,i){\n            return(\n            \t<li className=\"amt-item amt-item-content\"\n                onClick={function(){_this.haderClick(i+1)}}>\n               \n                <div className=\"amt-item-main\">\n                    <div className=\"amt-item-title\" >{el.subject}</div>\n                  <div className=\"amt-item-title-row\">\n                  \t<div className=\"amt-item-desc\">{el.importance}</div>\n                  \t<div className=\"amt-item-after amt-item-desc\">{el.committer}</div>\n                  </div>\n                </div>\n              </li>\n            )\n          })\n        }\n      </ul>)\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  haderClick: function haderClick(index) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: index,\n        eventType: 'click'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    return React.createElement(\n      \"ul\",\n      { className: \"amt-list ui-list\" },\n      data.map(function (el, i) {\n        return React.createElement(\n          \"li\",\n          { className: \"amt-item amt-item-content\",\n            onClick: function onClick() {\n              _this.haderClick(i + 1);\n            } },\n          React.createElement(\n            \"div\",\n            { className: \"amt-item-main\" },\n            React.createElement(\n              \"div\",\n              { className: \"amt-item-title\" },\n              el.subject\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"amt-item-title-row\" },\n              React.createElement(\n                \"div\",\n                { className: \"amt-item-desc\" },\n                el.importance\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"amt-item-after amt-item-desc\" },\n                el.committer\n              )\n            )\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control176_cgJ2ns: function (elem) {
      var title = "通知公告列表";return title;
    },
    doAction_uiControl193_Zvx6cJ: function (data, elem) {},
    getTemplate_uiControl193_Zvx6cJ: function () {
      var selfTemplate = "import { back, closeWindow} from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control180_eefVLN: function (elem) {
      if (!elem) {
        return;
      }var obj = {};$(elem).find("#TopPrev").attr("href") ? obj.prev = 1 : obj.prev = 0;$(elem).find("#TopNext").attr("href") ? obj.next = 1 : obj.next = 0;return obj;
    },
    doAction_uiControl197_i4T7EM: function (data, elem) {
      $(elem).find('[id="' + data.customData + '"]').click();
    },
    getTemplate_uiControl197_i4T7EM: function () {
      var selfTemplate = "const {\n  Button\n} = AMUITouch2;\nmodule.exports = React.createClass({\n  click: function(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        customData: data\n      });\n    }\n\n  },\n    render: function() {\n      var self = this;\n      var data = this.props.data.customData;\n      if(!data){\n        return(<span></span>)\n      }\n      return (\n        <div className=\"amt-g amt-g-between ui-between-PrevAndNext\" >\n         <div className=\"amt-col amt-col-2\">\n           {data.prev == 0?\n             <Button className=\"amt-btn  amt-btn-sm \"  disabled onClick={()=>{self.click('TopPrev')}}>\u4E0A\u4E00\u9875</Button>\n             :<Button className=\"amt-btn  amt-btn-sm \" style={{\"background\":\"#fff\"}} onClick={()=>{self.click('TopPrev')}}>\u4E0A\u4E00\u9875</Button>\n           }\n         </div>\n         <div className=\"amt-col amt-col-2\">\n           {data.next == 0?\n           \t\t<Button className=\"amt-btn   amt-btn-sm amt-btn-warning\" disabled onClick={()=>{self.click('TopNext')}}>\u4E0B\u4E00\u9875</Button>\n             :<Button className=\"amt-btn   amt-btn-sm amt-btn-warning\"  onClick={()=>{self.click('TopNext')}}>\u4E0B\u4E00\u9875</Button>\n           }\n         </div>\n          </div>\n      )\n    }\n  });\n";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    Button = _AMUITouch.Button;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  click: function click(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        customData: data\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.data.customData;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"amt-g amt-g-between ui-between-PrevAndNext\" },\n      React.createElement(\n        \"div\",\n        { className: \"amt-col amt-col-2\" },\n        data.prev == 0 ? React.createElement(\n          Button,\n          { className: \"amt-btn  amt-btn-sm \", disabled: true, onClick: function onClick() {\n              self.click('TopPrev');\n            } },\n          \"\\u4E0A\\u4E00\\u9875\"\n        ) : React.createElement(\n          Button,\n          { className: \"amt-btn  amt-btn-sm \", style: { \"background\": \"#fff\" }, onClick: function onClick() {\n              self.click('TopPrev');\n            } },\n          \"\\u4E0A\\u4E00\\u9875\"\n        )\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"amt-col amt-col-2\" },\n        data.next == 0 ? React.createElement(\n          Button,\n          { className: \"amt-btn   amt-btn-sm amt-btn-warning\", disabled: true, onClick: function onClick() {\n              self.click('TopNext');\n            } },\n          \"\\u4E0B\\u4E00\\u9875\"\n        ) : React.createElement(\n          Button,\n          { className: \"amt-btn   amt-btn-sm amt-btn-warning\", onClick: function onClick() {\n              self.click('TopNext');\n            } },\n          \"\\u4E0B\\u4E00\\u9875\"\n        )\n      )\n    );\n  }\n});";
    }
  }, "lks_news_list");
})(window, ysp);