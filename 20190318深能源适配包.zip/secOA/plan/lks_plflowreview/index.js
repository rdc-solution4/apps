(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control72_Qkl4o9: function (elem) {
      if (elem) {
        return elem.textContent;
      }
    },
    doAction_uiControl88_WzrHmO: function (data, elem) {},
    getTemplate_uiControl88_WzrHmO: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      data = '\u8D22\u52A1\u6D41\u7A0B';\n    }\n  \treturn (<NavBar \n      title={data}\n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "'use strict';\n\nvar _appRenderer = require('appRenderer');\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      data = '\u8D22\u52A1\u6D41\u7A0B';\n    }\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control77_nHGfMH: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('tr').eq(0).find('input').each(function (i) {
        var actived = this.className.indexOf('labelbg1') != -1;if (this.value == '发布机制' || this.value == '权限') {
          return;
        }var objInput = { id: this.getAttribute('id'), value: this.value, actived: actived, index: i, isRed: this.style.color == 'rgb(255, 0, 0)', disabled: this.getAttribute('rowdisabled') };data.push(objInput);
      });return data;
    },
    doAction_uiControl89_0unIqN: function (data, elem) {
      if (data.eventType == 'click') {
        var index = data.customData;$(elem).find('tr').eq(0).find('input').eq(index).click();
      }
    },
    getTemplate_uiControl89_0unIqN: function () {
      var selfTemplate = "var GlobalTab = require('ysp-custom-components').GlobalTab;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var _this = this;\n    return <GlobalTab callBack = {_this.clickLi} customData={this.props.customData} />;\n  }\n});\n";
      return "'use strict';\n\nvar GlobalTab = require('ysp-custom-components').GlobalTab;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var _this = this;\n    return React.createElement(GlobalTab, { callBack: _this.clickLi, customData: this.props.customData });\n  }\n});";
    },
    getData_control78_RFJECV: function (elem) {
      if (!elem) {
        return;
      }var $tabTr = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "基本信息" && this.className == "labelbg1") {
          $tabTr = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var data = { basicData: [], collapseData: [] };if (!$tabTr) {
        return;
      }var $table = $tabTr.find('table').last();if ($tabTr[0].style.display == 'none') {
        return;
      }initData($table, data);return data;function initData($table, data) {
        var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (i, tr) {
          var trText = tr.innerText ? tr.innerText.trim() : '';var $tds = $(tr).children('td');if (i == 0 && trText && tr.style.display != 'none' && $tds.length <= 1) {
            data.basicData.push({ TITLE: trText });
          }var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
            return;
          }var $childTable = $tds.eq(0).find('table');if ($childTable.length && $childTable[0].style.display !== 'none' && $childTable[0].parentElement.style.display !== 'none' && !childTable.isHidden) {
            data.basicData.push({ type: 'table', table: initEditTable($childTable) });return;
          }$tds.each(function (j, td) {
            if (j % 2 == 0 && $tds[j + 1]) {
              var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };var $select = $oddTd.find('select');if ($select.length) {
                initSelect($select, item);
              }var $inputs = $oddTd.find('input');if ($inputs.length) {
                initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a');if ($aLink.length) {
                initLinks($aLink, item);
              }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table) {
                item.content = content;
              }if (!label) {
                return;
              }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                data.collapseData.push(item);
              } else {
                data.basicData.push(item);
              }
            }
          });
        });
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.type == 'hidden' || input.isHidden || input.parentNode.style.display == 'none';if (isHidden) {
            return;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || {
              type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
            }
          }if (type == 'button' || type == 'text') {
            data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          if (this.isHidden || this.style.display == 'none') {
            return;
          }var select = {};
          select.options = [];select.type = 'select';select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');
          select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex,
              tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.isHidden || this.style.display == 'none') {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.style.display == 'none') {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (trIndex == 0) {
              thead.push(td.textContent);
            } else {
              var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link) {
                tdObj.content = this.innerText.trim();
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl90_AGVbh9: function (data, elem) {
      var oData = data.dataCustom;var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "基本信息" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var $table = $(_elem).find('table').last();var $tr = $table.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var $triggerElem = $tr.find('[name="' + oData.name + '"]');$triggerElem.val(oData.value);if (oData.type == 'date') {
            var curWin = $triggerElem[0].ownerDocument.defaultView;curWin.onDateSelected && curWin.onDateSelected();
          }
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl90_AGVbh9: function () {
      var selfTemplate = "import {BasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<BasicInfo eventHandler={self.eventHandler} customData={data}></BasicInfo>)\n  }\n});\n";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.BasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },

    getData_control81_uWzSWD: function (elem) {
      if (!elem) {
        return;
      }var listAll = $(elem).find("input");var arry = [];listAll.map(function (index, item) {
        if (this.isHidden || this.type == 'hidden') {
          return;
        }if ($(item).attr("value") == "返回" || $(item).attr("value") == "内部沟通" || $(item).attr("value") == "提交内部沟通") {
          if (!$(item).attr("style")) {
            var obj = {};obj.title = $(this).attr("value");obj.index = index;arry.push(obj);
          }
        }if ($(item).parents().attr("id") == "viewbtn") {
          if (!$(item).parents().attr("style")) {
            var sValue = $(this).attr("value");if (sValue == "待办暂停" || sValue == "签名" || sValue == "一键审批短信审批" || sValue == '保存关注设置') {
              return false;
            }var obj = {};obj.title = $(this).attr("value");obj.index = index;if ($(this).attr("value") == "提交") {
              obj.cls = 'cus-submit';obj.show = "none";
            }arry.push(obj);
          }
        }
      });return arry;
    },
    doAction_uiControl93_aMavRi: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl93_aMavRi: function () {
      var selfTemplate = "var ProcessButtons = require('ysp-custom-components').ProcessButtons;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  \n  render: function(callBack) {\n    var _this = this;\n    var data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    return <ProcessButtons callBack = {_this.clickLi} customData={data} />;\n  }\n});";
      return "'use strict';\n\nvar ProcessButtons = require('ysp-custom-components').ProcessButtons;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n\n  render: function render(callBack) {\n    var _this = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(ProcessButtons, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control84_Tq8Tbx: function (elem) {
      if (!elem) {
        return;
      }var doc = elem.contentDocument;var $tbReview = $(doc).find('#tbReview');var data = [];var collapseData = [];function initSelect($select, item) {
        var select = {};select.options = [];select.type = 'select';select.trIndex = item.trIndex;select.name = $select.attr('name');select.id = $select.attr('id');$select.find('option').each(function () {
          if (this.selected) {
            select.value = $(this).val();
          }select.options.push({ value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
        });return select;
      }$tbReview.children('tbody').children('tr').each(function (i, tr) {
        var trId = this.getAttribute('id') || '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：', '上传附件：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none' || $(this).find('#ReviewLog_TD').length) {
          return;
        }$tds.each(function (j, td) {
          if (j % 2 == 0 && $tds[j + 1]) {
            var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
              return;
            }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, trIndex: i };var $select = $oddTd.find('select');if ($select.length) {
              item.select = [];$select.each(function (i, select) {
                var selectObj = initSelect($(select), item);item.select.push(selectObj);
              });
            }var $inputs = $oddTd.find('input');if ($inputs.length) {
              $inputs.each(function (index, input) {
                var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden) {
                  return;
                }var type = input.type;item.type = type;var inputObj = { trIndex: item.trIndex, index: index, type: type, text: this.nextSibling.textContent, value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
                  // inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;
                  inputObj.parentId = $(this).parent().attr('id');item.radios = item.radios || { trIndex: item.trIndex, type: type, name: this.name, options: [] };inputObj.value ? item.radios.options.push(inputObj) : "";
                }if (type == 'checkbox') {
                  // inputObj.text = $(this).next().text() || inputObj.text;
                  inputObj.parentId = $(this).parent().attr('id');item.checkbox = item.checkbox || { trIndex: item.trIndex, type: type, name: this.name, options: [] };inputObj.value ? item.checkbox.options.push(inputObj) : "";
                }if (type == 'button' || type == 'text') {
                  inputObj.text = this.value;item.inputs = item.inputs || [];inputObj.label = this.parentNode.innerText || '';item.inputs.push(inputObj);
                }if (item.radios) {
                  item.inputLabel = this.parentNode.innerText;
                }
              });
            }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
              item.textarea = [];$textarea.each(function () {
                var textareaObj = { type: 'textarea', trIndex: item.trIndex, name: this.name, disabled: this.disabled, placeholder: this.placeholder, value: this.value };item.textarea.push(textareaObj);
              });
            }var $aLink = $oddTd.find('a');if ($aLink.length) {
              item.link = [];$aLink.each(function (i, a) {
                if (a.href && a.href.indexOf('/lks/sys/lks_profile.nsf/AG_OpenDocument?OpenAgent&form=fm_flowtips') != -1 || a.isHidden) {
                  return;
                }item.link.push({ trIndex: item.trIndex, index: i, text: a.textContent, type: 'link' });
              });
            }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea) {
              item.content = content.replace('『选择』', '');
            }if (!label) {
              return;
            }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
              collapseData.push(item);
            } else {
              data.push(item);
            }
          }
        });
      });var $submitBtn = $tbReview.find("#viewbtn input[title='提交处理内容']");var isSubmit = $submitBtn.length && !$submitBtn[0].isHidden;return { isSubmit: isSubmit, basicData: data, collapseData: collapseData };
    },
    doAction_uiControl96_cVJp4f: function (data, elem) {
      var oData = data.dataCustom;var doc = elem.contentDocument;var $tbReview = $(doc).find('#tbReview');var $tr = $tbReview.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click(); //       var $input = $parent.find('[type="' + oData.type + '"]');
            //       if (oData.type == 'radio') {
            //         $tr.find('[type="' + oData.type + '"]').each(function () {
            //           if (this != $input[0]) {
            //             this.checked = false;
            //           }
            //         });
            //       }
            //       $input[0].checked = !$input[0].checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var triggerElem = $tr.find('[name="' + oData.name + '"]');triggerElem.val(oData.value);
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          var $a = $tr.find('a').eq(oData.index);if ($a.attr('target') == "blank") {
            var href = $a[0].href;elem.ownerDocument.defaultView.open(href); // $a.attr('target', '_ysp_top');
          } else {
            $a.click();
          }
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl96_cVJp4f: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nconst { CollapseCard } = AMUITouch2;\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(\n       <ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>\n      )\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nvar _AMUITouch = AMUITouch2,\n    CollapseCard = _AMUITouch.CollapseCard;\n\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },

    getData_control86_PXsML0: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        var that = $(item).attr('value');if (that == '关闭' || that == '快速通过') {
          arry1.push({ title: $(item).attr('value'), index: index });obj.show = arry1;
        } else {
          if (that != "标准打印格式" && that != "封面打印" && that != "收藏" && that != "复制" && that != "流程挂接" && that != "发起挂接通知" && that != "打印公文正文" && that != "打印审批记录" && that != '打印签字') {
            arry2.push({ title: $(item).attr('value'), index: index });obj.hide = arry2;
          }
        }
      });return obj;
    },
    doAction_uiControl99_HM01eQ: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl99_HM01eQ: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },

    getData_control88_kNIBuJ: function (elem) {
      if (!elem) {
        return;
      }var $lableTr = null;var trText = [];$(elem).children('tbody').children('tr').eq(0).find('input').each(function (inx, ele) {
        if (this.value == "审批内容" && this.className == "labelbg1") {
          // 获取审批内容对应的tr
          $lableTr = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if ($lableTr && $lableTr[0] && $lableTr[0].style.display != "none") {
        var doc = $lableTr[0].querySelector('iframe') && $lableTr[0].querySelector('iframe').contentDocument;var $tbReview = $lableTr.children('td').children('table');if ($tbReview.find("#F_BodyDvbbs_Container").length) {
          $tbReview.find("#F_BodyDvbbs_Container img").each(function () {
            $(this).attr('src', this.src);
          });data = { basicData: [1], type: "editTextarea", text: $(doc.body)[0].outerHTML };return data;
        }if (doc) {
          var $mainTable = $(doc.body).find('table#mainTable');$tbReview = $(doc.body).find('form>table[bgcolor="#c0c0c0"]').last();var $spanHTMLTable = $(doc.body).find('#spanHTMLTable');if ($tbReview[0] && !$tbReview[0].isHidden) {
            $tbReview = $tbReview;
          } else if ($mainTable.length && !$mainTable[0].isHidden) {
            $tbReview = $mainTable;
          } else if ($spanHTMLTable.length) {
            $tbReview = $spanHTMLTable.children('table').last();
          } else if (!$tbReview[0]) {
            $tbReview = $(doc.body).find('form table').last();
          }
        }var remark = [];if ($tbReview && $tbReview.length) {
          var $divRemark;if ($tbReview.parent().siblings('div').last().length) {
            $divRemark = $tbReview.parent().siblings('div').last();
          } else if ($tbReview.next()) {
            $divRemark = $tbReview.next();
          }var tageName = ['BR', 'SCRIPT'];if ($divRemark[0] && $.inArray($divRemark[0].tagName, tageName) == -1 && !$divRemark[0].isHidden && $divRemark[0].style.display != 'none') {
            remark.push($divRemark[0].innerText);
          }
        }var data = { basicData: [], collapseData: [], Remark: remark };initData($tbReview, data);return data;
      } else {
        return undefined;
      }function initData($table, data) {
        var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (i, tr) {
          var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：', '相关附件：', '相关附件：\n暂无附件！'];if (td0Text.indexOf('相关附件：') != -1 || $.inArray(td0Text, hiddenRowText) != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }if (i == 0 && !tr.isHidden && $tds.length <= 1 && !this.isHidden) {
            if ($(this).find('#F_BodyView>*').length) {
              $(this).find('#F_BodyView>*').each(function () {
                var table = '';if ($(this).children('table').length == 1) {
                  table = $(this).children('table')[0].outerHTML;trText.push({ table: table });
                } else if ($(this).children('table').length == 0) {
                  trText.push({ text: this.innerText ? this.innerText.trim() : '', img: $(this).children('img').attr('src') ? $(this).children('img')[0].src : null });
                }
              });data.basicData.push({ TITLE: trText, id: $tds[0].getAttribute('id') });return;
            }
          }$tds.each(function (tdIndex, td) {
            if ($(this).find('img[src*="ecblank.gif"]').length && $tds[tdIndex + 1] && $tds[tdIndex + 1].innerText == '建筑工程') {
              $tds.splice(tdIndex, 1);
            }
          });$tds.each(function (j, td) {
            if (j % 2 == 0) {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds[j + 1] ? $tds.eq(j + 1) : $(this);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };var $childTable = $oddTd.find('table');$childTable.each(function () {
                if (this.isHidden) {
                  return;
                } else {
                  item.label = !$tds[j + 1] ? '' : item.label;item.table = item.table || [];item.type = 'table';item.hasContent = true;item.table = initEditTable($(this));
                }
              });var $select = $oddTd.find('select').not($childTable.find('select'));if ($select.length) {
                initSelect($select, item);
              }var $inputs = $oddTd.find('input').not($childTable.find('input'));if ($inputs.length) {
                var aWin = $inputs[0].ownerDocument.defaultView;aWin.initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea').not($childTable.find('textarea'));if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a').not($childTable.find('a'));if ($aLink.length) {
                initLinks($aLink, item);
              }if ($oddTd.find('font').length && $tds[j + 1]) {
                var fontText = '';$oddTd.find('font').each(function () {
                  if (this.style.display != 'none' && !this.isHidden && this.innerText) {
                    fontText = fontText + this.innerText + '\r\n';
                  }
                });item.fontText = fontText;
              }if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table && !item.fontText && $tds[j + 1]) {
                item.content = $oddTd[0].innerText.trim();
              }if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table && !item.fontText && !item.content && !$tds[j + 1]) {
                item.isConTitle = true;
              }if ($(this).find('[name="CF_No"]').length && $(this).find('[name="CF_Year"]').length) {
                item.label = this.innerHTML;delete item.inputs;
              }if (!label && !item.hasContent) {
                return;
              }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                data.collapseData.push(item);
              } else {
                data.basicData.push(item);
              }
            }
          });
        });
      }function initSelect($select, data) {
        data.select = [];data.hasContent = true;$select.each(function (i) {
          var visibility = $(this).css('visibility');if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.visibility = visibility;select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.hasContent = true;data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';var $img = $(this).parent().find('img[src*="code.gif"]');if ($img.length) {
            data.label = $(this).parent().find('font').text();this.style.display = '';
          }if (sClick.indexOf('selectDate') != -1 || sClick.indexOf('selectTime') != -1 || this.style.display == 'none' || this.isHidden) {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });if (data.link.length == 0) {
          delete data.link;
        }data.hasContent = true;
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }var tdText = td.textContent.trim().replace('〖 添 加 〗', '添加').trim();if (trIndex == 0) {
              thead.push({ colspan: this.getAttribute('colspan') || '', content: tdText });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex, colspan: this.getAttribute('colspan') || '' };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                var aWin = $inputs[0].ownerDocument.defaultView;aWin.initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl95_Foihxb: function (data, elem) {
      var oData = data.dataCustom;$tableTr = $(elem).children('tbody').children('tr').not('[style*="display: none"]').eq(1);var doc = $tableTr[0].querySelector('iframe') && $tableTr[0].querySelector('iframe').contentDocument;var $tbReview = $tableTr.children('td').children('table');if (doc) {
        var $mainTable = $(doc.body).find('table#mainTable');$tbReview = $(doc.body).find('form>table[bgcolor="#c0c0c0"]').last();var $spanHTMLTable = $(doc.body).find('#spanHTMLTable');if ($tbReview[0] && !$tbReview[0].isHidden) {
          $tbReview = $tbReview;
        } else if ($mainTable.length && !$mainTable[0].isHidden) {
          $tbReview = $mainTable;
        } else if ($spanHTMLTable.length) {
          $tbReview = $spanHTMLTable.children('table').last();
        } else if (!$tbReview[0]) {
          $tbReview = $(doc.body).find('form table').last();
        }
      }if (oData.tableId && $tbReview.attr('id') != oData.tableId) {
        $tbReview = $tbReview.find('#' + oData.tableId);
      }var $tr = $tbReview.children('tbody').children('tr').eq(oData.trIndex);debugger;if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var $triggerElem = $tr.find('[name="' + oData.name + '"]');$triggerElem.val(oData.value);if (oData.type == 'date') {
            var curWin = $triggerElem[0].ownerDocument.defaultView;curWin.onDateSelected && curWin.onDateSelected();
          }
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl95_Foihxb: function () {
      var selfTemplate = "import {PropertyReviewBody} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n \t\tif(!data  || !data.basicData[0]){\n      return(<span></span>)\n    }\n    return(<PropertyReviewBody eventHandler={self.eventHandler} customData={data}></PropertyReviewBody>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || !data.basicData[0]) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.PropertyReviewBody, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },

    getData_control100_xneV6f: function (elem) {
      if (elem) {
        function getPoint(startPoint, endPoint) {
          var x, y, x1, y1;switch (startPoint.Position) {case "NodeBottom":
              x = startPoint.Node.Left + 90;y = startPoint.Node.Top * 2 + 80;break;case "NodeTop":
              x = startPoint.Node.Left + 90;y = startPoint.Node.Top * 2;break;case "NodeLeft":
              x = startPoint.Node.Left;y = startPoint.Node.Top * 2 + 40;break;case "NodeRight":
              x = startPoint.Node.Left + 180;y = startPoint.Node.Top * 2 + 40;break;default:
              x = startPoint.Node.Left;y = startPoint.Node.Top * 2;break;}switch (endPoint.Position) {case "NodeBottom":
              x1 = endPoint.Node.Left + 90;y1 = endPoint.Node.Top * 2 + 80;break;case "NodeTop":
              x1 = endPoint.Node.Left + 90;y1 = endPoint.Node.Top * 2;break;case "NodeLeft":
              x1 = endPoint.Node.Left;y1 = endPoint.Node.Top * 2 + 40;break;case "NodeRight":
              x1 = endPoint.Node.Left + 180;y1 = endPoint.Node.Top * 2 + 40;break;default:
              x1 = endPoint.Node.Left;y1 = endPoint.Node.Top * 2;break;}if (endPoint.Node.Type == "end") {
            x1 = endPoint.Node.Left + 50;y1 = endPoint.Node.Top * 2;
          }return [[x, y], [x1, y1]];
        }function getCenter(line) {
          if (line.length > 0) {
            var distanceX = Math.abs(line[0][0] - line[1][0]) / 2;var distanceY = Math.abs(line[0][1] - line[1][1]) / 2;var x = line[0][0] > line[1][0] ? line[1][0] + distanceX : line[0][0] + distanceX;var y = line[0][1] > line[1][1] ? line[1][1] + distanceY : line[0][1] + distanceY;return [x, y];
          }
        }var aWin = elem.ownerDocument.querySelector("#if_flowchart").contentWindow;var doc = aWin.document;var FlowChartObject = aWin.FlowChartObject;var $F_DisplayFlow = $(elem).find("#spanCondition").parent().find("input[name='F_DisplayFlow']");var data = { checked: $F_DisplayFlow[0] ? $F_DisplayFlow[0].checked : "noncheck", offsetBorder: 300, maxWidth: 0, maxHeight: 0, nodes: [] };if (FlowChartObject) {
          var flowNodes = aWin.FlowChartObject.Nodes.all;var flowLines = aWin.FlowChartObject.Lines.all;for (var i = 0; i < flowNodes.length; i++) {
            var node = {};node.Index = i;node.top = flowNodes[i].Top * 2;node.left = flowNodes[i].Left;node.type = flowNodes[i].Type;node.text = flowNodes[i].Text.split(/[/,、；;]/);node.title = flowNodes[i].Title;node.reviewer = flowNodes[i].Reviewer;node.image = flowNodes[i].Image;node.proImage = flowNodes[i].ProImage;node.IsOffshoot = flowNodes[i].IsOffshoot;node.IsSelected = flowNodes[i].IsSelected;node.name = flowNodes[i].Name;node.nodeNum = flowNodes[i].NodeNum;node.EditProperty = flowNodes[i].EditProperty;node.hasReview = flowNodes[i].hasReview;node.isCurrent = elem.ownerDocument.querySelector("input[name='F_ReviewNo']") && elem.ownerDocument.querySelector("input[name='F_ReviewNo']").value == flowNodes[i].NodeNum;var lines = flowNodes[i].LineStart;node.lines = { endPoint: [], lineTitle: [] };for (var l = 0; l < lines.length; l++) {
              node.lines.endPoint.push(getPoint(lines[l].StartPoint, lines[l].EndPoint));node.lines.lineTitle.push({ point: getCenter(node.lines.endPoint[l]), text: lines[l].title && lines[l].title });
            }data.offsetBorder = data.offsetBorder > node.left ? node.left : data.offsetBorder;data.maxWidth = data.maxWidth < node.left ? node.left : data.maxWidth;data.maxHeight = data.maxHeight < node.top ? node.top : data.maxHeight;data.nodes.push(node);
          }
        }return data;
      }return;
    },
    doAction_uiControl94_CK8xTa: function (data, elem) {
      var aWin = elem.ownerDocument.querySelector("#if_flowchart").contentWindow;var doc = aWin.document;var $elem = doc.querySelectorAll(".flownode_top")[data.customData];switch (data.eventType) {case "addReviewer":
          $($elem).find("input#NodeProImages").click();break;case "check":
          $(elem).find("#spanCondition").parent().find("input[name='F_DisplayFlow']").click();break;}
    },
    getTemplate_uiControl94_CK8xTa: function () {
      var selfTemplate = "/*\u9009\u53D6\u5143\u7D20\u4E3Atable#tbReview*/\nvar FlowChartView = require('ysp-custom-components').FlowChartView;\nmodule.exports = React.createClass({\n  callback:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    return (\n      data?<FlowChartView data={data} callback={_this.callback}/>:\"\"\n    )\n  }\n});";
      return "\"use strict\";\n\n/*\u9009\u53D6\u5143\u7D20\u4E3Atable#tbReview*/\nvar FlowChartView = require('ysp-custom-components').FlowChartView;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  callback: function callback(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    return data ? React.createElement(FlowChartView, { data: data, callback: _this.callback }) : \"\";\n  }\n});";
    },
    getData_control125_AiDRfw: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if ((this.value == "审批流程" || this.value == "流程") && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (!_elem || _elem && _elem[0].style.display == 'none') {
        return;
      }var arrData = { arrTitle: [], arrContent: [] };var $iframe = $(elem).find('iframe#ifFlow');if ($iframe.length) {
        _elem = $iframe[0].contentDocument;
      }var $font = $(_elem).find('#ReviewLog_TD').parent().find('td').eq(0).find('div').find('font');if ($font.length) {
        $font.each(function () {
          arrData.arrTitle.push({ title: this.textContent, color: this.getAttribute('color') });
        });
      }$(_elem).find('#FlowLog_MainTable').children('tbody').find('tr').each(function (trIndex, tr) {
        if (tr.style.display == 'none' || !this.hasAttribute('nodekey')) {
          return;
        }var $td = $(this).find('td');var tdData = {};var $userad = $td.eq(2).find('span[userad]');tdData.num = $td[0].innerText;tdData.time = $td[1].innerText;tdData.people = $td[2].innerText;tdData.oponion = $td[3].innerText;tdData.way = $td[4].innerText;var image = $td.eq(2).find('b').find('img');if (image) {
          tdData.img = [];image.each(function (imagei, img) {
            tdData.img.push(img.src);
          });
        }var $link = $td.eq(3).find('span[nodelog] a');if ($link.length) {
          tdData.links = [];tdData.oponion = $td.eq(3).find('span[nodelog]')[0].childNodes[0].textContent.trim();$link.each(function () {
            tdData.links.push({ text: this.innerText, href: this.href });
          });
        }arrData.arrContent.push(tdData);
      });return arrData;
    },
    doAction_uiControl19_PykPBr: function (data, elem) {
      if (data.eventType == 'hrefClick') {
        var sHref = data.customData.href;if (ysp.appMain.isIOS()) {
          if (/.\pdf$/.test(sHref)) {
            ysp.appMain.openWindow(sHref + '?_ysp_forcepc=1');
          } else {
            ysp.appMain.openWindow(sHref + '?_ysp_filepreview=1');
          }
        } else {
          ysp.appMain.openWindow(sHref);
        }
      }
    },
    getTemplate_uiControl19_PykPBr: function () {
      var selfTemplate = "\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  hrefClick:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  }, \n  render: function() {\n    var data = this.props.customData;\n    if(!data || !data.arrContent.length){\n      return(<span></span>)\n    }\n    return (\n\t\t\t\t<ProcessRecord  hrefClick={this.hrefClick} customData={data} />\n    )\n  }\n});";
      return "'use strict';\n\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  hrefClick: function hrefClick(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || !data.arrContent.length) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(ProcessRecord, { hrefClick: this.hrefClick, customData: data });\n  }\n});";
    },

    getData_control138_1C15rb: function (elem) {
      if (!elem) {
        return undefined;
      }var data = { title: "", node: [] };data.title = $(elem).find('font')[0] && $(elem).find('font')[0].innerText;var obj1 = { name: "", content: [] };obj1.name = $(elem).find('span>br').eq(0)[0].nextSibling.textContent;$(elem).find('span>input').each(function (i, e) {
        var obj2 = {};obj2.index = i;obj2.value = this.nextSibling && this.nextSibling.textContent;obj2.type = this.type;obj2.checked = this.checked;obj1.content.push(obj2);
      });data.node.push(obj1);return data;
    },
    doAction_uiControl151_Q9Qhvl: function (data, elem) {
      var oData = data.dataCustom;var event = data.eventType;if (event === 'onValueChange') {
        $(elem).find('span>input').eq(oData).click();
      }
    },
    getTemplate_uiControl151_Q9Qhvl: function () {
      var selfTemplate = "const { CollapseCard } = AMUITouch2;\nmodule.exports = React.createClass({\n  onValueChange:function(index,data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'onValueChange',\n        data:data.index\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n   if(!data || data.length==0){\n      return(<span></span>)\n    }\n    return (\n      <div className=\"ui-content\">\n        <div className=\"amt-field-container\">\n          <div className=\"amt-field-label\" style={{\"fontWeight\":\"bolder\"}}>\n            <div>{data.title}</div>\n          </div>\n     {data.node && data.node.map(function(d,i){\n            return(\n              <div>\n               <div className=\"amt-field-label\"><div>{d.name}</div></div>\n                <div className=\"amt-field-wrap amt-field-wrap-custom\">\n                 <ul className=\"amt-choose-list\">\n                   {d.content && d.content.map((option,inx)=>{\n                      var className='amt-btn amt-btn-xs amt-btn-primary amt-btn-hollow amt-btn-selectable';\n                      if(option.checked){className = className + ' amt-btn-primary'}\n                      return(\n                        <li className=\"amt-choose-item\">\n                          <button onClick={()=>{self.onValueChange(option.value,option)}}  className={className}>{option.value}\n                            <span className=\"amt-btn-selectable-helper\">\n                              {option.checked ? <div><i className=\"amt-btn-selectable-helper-traingle\"></i><small className=\"amt-btn-selectable-helper-check\"><span className=\"amt-icon amt-icon-check\"></span></small></div> : ''}\n                            </span>\n                          </button>\n                        </li>\n                      )\n                   })}\n                 </ul>\n            </div>\n              </div>\n            )\n          })}\n        </div>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar _AMUITouch = AMUITouch2,\n    CollapseCard = _AMUITouch.CollapseCard;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  onValueChange: function onValueChange(index, data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'onValueChange',\n        data: data.index\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement(\"span\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"ui-content\" },\n      React.createElement(\n        \"div\",\n        { className: \"amt-field-container\" },\n        React.createElement(\n          \"div\",\n          { className: \"amt-field-label\", style: { \"fontWeight\": \"bolder\" } },\n          React.createElement(\n            \"div\",\n            null,\n            data.title\n          )\n        ),\n        data.node && data.node.map(function (d, i) {\n          return React.createElement(\n            \"div\",\n            null,\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-label\" },\n              React.createElement(\n                \"div\",\n                null,\n                d.name\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-wrap amt-field-wrap-custom\" },\n              React.createElement(\n                \"ul\",\n                { className: \"amt-choose-list\" },\n                d.content && d.content.map(function (option, inx) {\n                  var className = 'amt-btn amt-btn-xs amt-btn-primary amt-btn-hollow amt-btn-selectable';\n                  if (option.checked) {\n                    className = className + ' amt-btn-primary';\n                  }\n                  return React.createElement(\n                    \"li\",\n                    { className: \"amt-choose-item\" },\n                    React.createElement(\n                      \"button\",\n                      { onClick: function onClick() {\n                          self.onValueChange(option.value, option);\n                        }, className: className },\n                      option.value,\n                      React.createElement(\n                        \"span\",\n                        { className: \"amt-btn-selectable-helper\" },\n                        option.checked ? React.createElement(\n                          \"div\",\n                          null,\n                          React.createElement(\"i\", { className: \"amt-btn-selectable-helper-traingle\" }),\n                          React.createElement(\n                            \"small\",\n                            { className: \"amt-btn-selectable-helper-check\" },\n                            React.createElement(\"span\", { className: \"amt-icon amt-icon-check\" })\n                          )\n                        ) : ''\n                      )\n                    )\n                  );\n                })\n              )\n            )\n          );\n        })\n      )\n    );\n  }\n});";
    },
    getData_control152_n0I2hW: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "流程挂接" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(7);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];var arr = { title: $(_elem.children('td').find('ul').children('table').children('tbody').find('td')).eq(0).text(), content: $(_elem.children('td').find('ul').children('table').children('tbody').find('td')).eq(1)[0].innerHTML, button: [] };data.push(arr);return data;
      } else {
        return undefined;
      }
    },
    doAction_uiControl166_0OEI4i: function (data, elem) {
      var eventType = data.eventType;if (eventType == 'click') {
        var index = data.dataCustom;var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
          if (this.value == "流程挂接" && this.className == "labelbg1") {
            _elem = $(elem).children('tbody').children('tr').eq(7);
          }
        });
      }if (eventType == 'click2') {
        var oData = data.dataCustom;if (oData.tagName == 'A') {
          $(elem).find("#FlowJoinLog_Td").find('a').eq(oData.index).click();
        }
      }
    },
    getTemplate_uiControl166_0OEI4i: function () {
      var selfTemplate = "const {\n  Field,\n  Group,\n  ButtonGroup,\n  Button,\n  Icon,\n  Title\n} = AMUITouch2;\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  onclick:function(index){\n    var handler = this.props.customHandler;\n    if(handler){\n       handler({\n         eventType:'click',\n         //\u83B7\u53D6\u81EA\u5B9A\u4E49\u5C5E\u6027\u503C\uFF08\u7D22\u5F15\u53F7\uFF09\n         data: index\n       })\n    }\n  },\n  click2:function(e){\n    var handler = this.props.customHandler;\n    var target = e.target;\n    var tbody = e.target.parentNode.parentNode.parentNode;\n    \n    var data = {tagName:target.tagName};\n    if(target.tagName ==\"INPUT\"){\n       var inputs = tbody.getElementsByTagName('input')||[];\n       for(var i = 0;i<inputs.length;i++){\n        if(target == inputs[i]){\n          \n          data.index = i;\n        }\n      }\n      data.value = target.value;\n    } else if(target.tagName =='A'){\n      var eleLinks = tbody.getElementsByTagName('a')||[];\n      for(var i = 0;i<eleLinks.length;i++){\n        if(target == eleLinks[i]){\n          data.index = i;\n        }\n      }\n      data.title = target.getAttribute('title');\n    }\n    \n    if(handler){\n       handler({\n         eventType:'click2',\n         data:data\n       })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(data && data.length == 0 || !data){\n      return (\n        <div></div>\n      )\n    }\n    var _this = this;\n    return (\n      <div className=\"ui-btn-box\">\n        {data.map(function(item,index){\n          var dat = data[index];\n          return(\n            <div className=\"ui-btn-box-inf-gxf\">\n              <Title amStyle=\"warning\">{item.title}</Title>\n              <div className=\"ui-text-Domain\">\n                 <table onClick={_this.click2} dangerouslySetInnerHTML={{__html:item.content}} className=\"ui-text-content-gxf\" style={{\"fontSize\":\"0.975rem\"}}></table>\n              </div>\n            </div>\n\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Group = _AMUITouch.Group,\n    ButtonGroup = _AMUITouch.ButtonGroup,\n    Button = _AMUITouch.Button,\n    Icon = _AMUITouch.Icon,\n    Title = _AMUITouch.Title;\n\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  onclick: function onclick(index) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        //\u83B7\u53D6\u81EA\u5B9A\u4E49\u5C5E\u6027\u503C\uFF08\u7D22\u5F15\u53F7\uFF09\n        data: index\n      });\n    }\n  },\n  click2: function click2(e) {\n    var handler = this.props.customHandler;\n    var target = e.target;\n    var tbody = e.target.parentNode.parentNode.parentNode;\n\n    var data = { tagName: target.tagName };\n    if (target.tagName == \"INPUT\") {\n      var inputs = tbody.getElementsByTagName('input') || [];\n      for (var i = 0; i < inputs.length; i++) {\n        if (target == inputs[i]) {\n\n          data.index = i;\n        }\n      }\n      data.value = target.value;\n    } else if (target.tagName == 'A') {\n      var eleLinks = tbody.getElementsByTagName('a') || [];\n      for (var i = 0; i < eleLinks.length; i++) {\n        if (target == eleLinks[i]) {\n          data.index = i;\n        }\n      }\n      data.title = target.getAttribute('title');\n    }\n\n    if (handler) {\n      handler({\n        eventType: 'click2',\n        data: data\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (data && data.length == 0 || !data) {\n      return React.createElement('div', null);\n    }\n    var _this = this;\n    return React.createElement(\n      'div',\n      { className: 'ui-btn-box' },\n      data.map(function (item, index) {\n        var dat = data[index];\n        return React.createElement(\n          'div',\n          { className: 'ui-btn-box-inf-gxf' },\n          React.createElement(\n            Title,\n            { amStyle: 'warning' },\n            item.title\n          ),\n          React.createElement(\n            'div',\n            { className: 'ui-text-Domain' },\n            React.createElement('table', { onClick: _this.click2, dangerouslySetInnerHTML: { __html: item.content }, className: 'ui-text-content-gxf', style: { \"fontSize\": \"0.975rem\" } })\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control71_qTaoWx: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "关联机制" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];_elem.children('td').children('table').children('tbody').children('tr').each(function (i, e) {
          var arr = { title: "", content: [], button: [] };if (i == 0) {
            arr.title = $(this).children('td')[0] && $(this).children('td')[0].innerText.trim().replace(".", "");var _table1 = $(this).next().children('td').find('table>tbody').eq(1);_table1.find('tr').eq(0).find('#dLinks').find('table>tbody').find('tr').each(function (i1, e1) {
              var _input = $(this).find('input[type="checkbox"]');var obj = {};obj.isEdit = _input.length;if (_input && _input[0] && _input[0].style.display != "none") {
                if (_input[0].checked) {
                  obj.checked = true;
                } else {
                  obj.checked = false;
                }obj.title = _input.attr("text");arr.content.push(obj);
              } else {
                obj.title = $(this).text();arr.content.push(obj);
              }
            });_table1.children("tr").eq(1).find("input").each(function (i2, e2) {
              var obj = {};obj.text = $(this).val();obj.index = i2;obj.disabled = this.disabled;arr.button.push(obj);
            });data.push(arr);
          }
        });return data;
      } else {
        return undefined;
      }
    },
    doAction_uiControl84_i7lmIJ: function (data, elem) {
      var eventType = data.eventType;if (eventType == 'click') {
        var index = data.dataCustom;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
          if (this.value == "关联机制" && this.className == "labelbg1") {
            _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
          }
        });if (index == 0) {
          _elem.find('input[name="kbuAdd"]').click();
        }if (index == 1) {
          _elem.find('input[name="kbuDel"]').click();
        }if (index == 2) {
          _elem.find('input[name="kbuEdt"]').click();
        }if (index == 3) {
          _elem.find('input[name="kbuSearch"]').click();
        }
      }if (eventType == 'checkedClick') {
        var customData = data.customData;$(elem).find("#dLinks").find('input').eq(customData).click();
      }if (eventType == 'click2') {
        var customData = data.customData;$(elem).find("#dLinks").find('a').eq(customData).click();
      }
    },
    getTemplate_uiControl84_i7lmIJ: function () {
      var selfTemplate = "import {GlobalAssociation} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n   if(!data){\n      return(<span></span>)\n    }\n    return(<GlobalAssociation eventHandler={self.eventHandler} customData={data}></GlobalAssociation>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.GlobalAssociation, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control159_BqvmNI: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "关联机制" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];_elem.children('td').children('table').children('tbody').children('tr').each(function (i, e) {
          var arr = { title: "", content: [] };if (i == 2) {
            arr.title = $(this).children('td')[0] && $(this).children('td')[0].innerText.trim().replace(".", "");var _table1 = $(this).next().children('td').find('table>tbody').eq(1);if (_table1[0]) {
              arr.content.push(_table1.find('#dLinks')[0] && _table1.find('#dLinks')[0].innerHTML);
            }var _table2 = $(this).next();if (_table2[0]) {
              arr.content.push(_table2[0] && _table2[0].innerHTML);
            }data.push(arr);
          }
        });return data;
      } else {
        return undefined;
      }
    },
    doAction_uiControl175_ABmoDG: function (data, elem) {},
    getTemplate_uiControl175_ABmoDG: function () {
      var selfTemplate = "const {\n  Field,\n  Group,\n  ButtonGroup,\n  Button,\n  Icon,\n  Title\n} = AMUITouch2;\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  onclick:function(index){\n    var handler = this.props.customHandler;\n    if(handler){\n       handler({\n         eventType:'click',\n         //\u83B7\u53D6\u81EA\u5B9A\u4E49\u5C5E\u6027\u503C\uFF08\u7D22\u5F15\u53F7\uFF09\n         data: index\n       })\n    }\n  },\n  click2:function(e){\n    var handler = this.props.customHandler;\n    var target = e.target;\n    var tbody = e.target.parentNode.parentNode.parentNode;\n    \n    var data = {tagName:target.tagName};\n    if(target.tagName ==\"INPUT\"){\n       var inputs = tbody.getElementsByTagName('input')||[];\n       for(var i = 0;i<inputs.length;i++){\n        if(target == inputs[i]){\n          \n          data.index = i;\n        }\n      }\n      data.value = target.value;\n    } else if(target.tagName =='A'){\n      var eleLinks = tbody.getElementsByTagName('a')||[];\n      for(var i = 0;i<eleLinks.length;i++){\n        if(target == eleLinks[i]){\n          data.index = i;\n        }\n      }\n      data.title = target.getAttribute('title');\n    }\n    \n    if(handler){\n       handler({\n         eventType:'click2',\n         data:data\n       })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    if(data && data.length == 0 || !data){\n      return (\n        <div></div>\n      )\n    }\n    var _this = this;\n    return (\n      <div className=\"ui-btn-box\">\n        {data.map(function(item,index){\n          var dat = data[index];\n          return(\n            <div className=\"ui-btn-box-inf-gxf\">\n              <Title amStyle=\"warning\">{item.title}</Title>\n              <div className=\"ui-text-Domain\">\n                 <table onClick={_this.click2} dangerouslySetInnerHTML={{__html:item.content}} className=\"ui-text-content-gxf\"></table>\n              </div>\n            </div>\n\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _AMUITouch = AMUITouch2,\n    Field = _AMUITouch.Field,\n    Group = _AMUITouch.Group,\n    ButtonGroup = _AMUITouch.ButtonGroup,\n    Button = _AMUITouch.Button,\n    Icon = _AMUITouch.Icon,\n    Title = _AMUITouch.Title;\n\nvar ProcessRecord = require('ysp-custom-components').ProcessRecord;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  onclick: function onclick(index) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        //\u83B7\u53D6\u81EA\u5B9A\u4E49\u5C5E\u6027\u503C\uFF08\u7D22\u5F15\u53F7\uFF09\n        data: index\n      });\n    }\n  },\n  click2: function click2(e) {\n    var handler = this.props.customHandler;\n    var target = e.target;\n    var tbody = e.target.parentNode.parentNode.parentNode;\n\n    var data = { tagName: target.tagName };\n    if (target.tagName == \"INPUT\") {\n      var inputs = tbody.getElementsByTagName('input') || [];\n      for (var i = 0; i < inputs.length; i++) {\n        if (target == inputs[i]) {\n\n          data.index = i;\n        }\n      }\n      data.value = target.value;\n    } else if (target.tagName == 'A') {\n      var eleLinks = tbody.getElementsByTagName('a') || [];\n      for (var i = 0; i < eleLinks.length; i++) {\n        if (target == eleLinks[i]) {\n          data.index = i;\n        }\n      }\n      data.title = target.getAttribute('title');\n    }\n\n    if (handler) {\n      handler({\n        eventType: 'click2',\n        data: data\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    if (data && data.length == 0 || !data) {\n      return React.createElement('div', null);\n    }\n    var _this = this;\n    return React.createElement(\n      'div',\n      { className: 'ui-btn-box' },\n      data.map(function (item, index) {\n        var dat = data[index];\n        return React.createElement(\n          'div',\n          { className: 'ui-btn-box-inf-gxf' },\n          React.createElement(\n            Title,\n            { amStyle: 'warning' },\n            item.title\n          ),\n          React.createElement(\n            'div',\n            { className: 'ui-text-Domain' },\n            React.createElement('table', { onClick: _this.click2, dangerouslySetInnerHTML: { __html: item.content }, className: 'ui-text-content-gxf' })\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control113_hsaPI2: function (elem) {
      // 采集，注意选取的元素需要在统一window作用域内并且不要超出祖辈级tr元素的范围
      if (elem) {
        var $elem;var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
        var doc = elem.ownerDocument; // 获取当前文档对象
        if ($(elem).attr("id") == "labelTable") {
          $(elem).children("tbody").children("tr").each(function (tri, tr) {
            if ($(this)[0].style.display != "none") {
              $elem = $(this).find('[id^="AttachmentDiv"]');
            } else {
              return;
            }
          });
        } else {
          $elem = $(elem).find('[id^="AttachmentDiv"]');
        }if ($elem.length == 0) {
          return;
        }var params = $(doc).find("#AttachmentOCX").children('param'); // 获取当前页面附件参数
        var _AttachmentObject = aWin.AttachmentObject; // 获取当前页面附件初始化对象
        var data = { Index: _AttachmentObject.Index };var existingfiles; // 初始化已存在的文件对象
        data.fileField = [];$elem && $elem.each(function (eli, fileitem) {
          existingfiles = [];$(fileitem).children("a").each(function (inputi, fileele) {
            existingfiles.push({ filename: $(fileele).text(), isUpload: $(fileele).prev("input").attr("isupload"), anchor: inputi });
          });data.fileField.push({ title: $(fileitem).closest("td").prev().text() && $(fileitem).closest("td").prev().text().trim() || "附件上传", isEdit: $(fileitem).children("input").length > 0, sqeNum: $(fileitem).attr('id').match(/\d+/)[0], existingfiles: existingfiles });
        });data.__Click = $(doc).find("input[name='__Click']").val();params.each(function (index, param) {
          switch (param.name) {case 'Server':
              data.Server = param.value;break;case 'Port':
              data.Port = param.value;break;case 'ReceiveForm':
              data.ReceiveForm = param.value;break;case 'FileInputName':
              data.FileInputName = param.value;break;case 'DocId':
              data.DocId = param.value;break;case 'FileLimits':
              data.FileLimits = param.value;break;case 'Encoding':
              data.Encoding = param.value;break;}
        });return data;
      }return;
    },
    doAction_uiControl133_gveE0l: function (data, elem) {
      var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
      var doc = elem.ownerDocument; // 获取当前文档对象
      switch (data.eventType) {case "add":
          aWin.AttachmentObject.Add(data.customData.fieldindex, data.customData.path);break;case "delete":
          aWin.AttachmentObject.Delete(data.customData.fieldindex, data.customData.fileindex);break;case "filepreview":
          $(elem).find('#AttachmentDiv' + data.customData.index).find("a").eq(data.customData.value).click();break;}
    },
    getTemplate_uiControl133_gveE0l: function () {
      var selfTemplate = "// \u6A21\u677F\u5F15\u7528\u793A\u4F8B\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return  data?<AttachmentUpload data={data} callback={callback}/>:\"\"\n  }\n});";
      return "\"use strict\";\n\n// \u6A21\u677F\u5F15\u7528\u793A\u4F8B\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return data ? React.createElement(AttachmentUpload, { data: data, callback: callback }) : \"\";\n  }\n});";
    },
    getData_control166_uKX5Qx: function (elem) {
      // 采集，注意选取的元素需要在统一window作用域内并且不要超出祖辈级tr元素的范围
      if (elem) {
        var $elem;var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
        var doc = elem.ownerDocument; // 获取当前文档对象
        if ($(elem).attr("id") == "labelTable") {
          $(elem).children("tbody").children("tr").each(function (tri, tr) {
            if ($(this)[0].style.display != "none") {
              $elem = $(this).find('[id^="AttachmentDiv"]');
            } else {
              return;
            }
          });
        } else {
          $elem = $(elem).find('[id^="AttachmentDiv"]');
        }if ($elem.length == 0) {
          return;
        }var params = $(doc).find("#AttachmentOCX").children('param'); // 获取当前页面附件参数
        var _AttachmentObject = aWin.AttachmentObject; // 获取当前页面附件初始化对象
        var data = { Index: _AttachmentObject.Index };var existingfiles; // 初始化已存在的文件对象
        data.fileField = [];$elem && $elem.each(function (eli, fileitem) {
          existingfiles = [];$(fileitem).children("a").each(function (inputi, fileele) {
            existingfiles.push({ filename: $(fileele).text(), isUpload: $(fileele).prev("input").attr("isupload"), anchor: inputi });
          });data.fileField.push({ title: $(fileitem).closest("td").prev().text() && $(fileitem).closest("td").prev().text().trim() || "附件上传", isEdit: $(fileitem).children("input").length > 0, sqeNum: $(fileitem).attr('id').match(/\d+/)[0], existingfiles: existingfiles });
        });data.__Click = $(doc).find("input[name='__Click']").val();params.each(function (index, param) {
          switch (param.name) {case 'Server':
              data.Server = param.value;break;case 'Port':
              data.Port = param.value;break;case 'ReceiveForm':
              data.ReceiveForm = param.value;break;case 'FileInputName':
              data.FileInputName = param.value;break;case 'DocId':
              data.DocId = param.value;break;case 'FileLimits':
              data.FileLimits = param.value;break;case 'Encoding':
              data.Encoding = param.value;break;}
        });return data;
      }return;
    },
    doAction_uiControl183_eJFigy: function (data, elem) {
      var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
      var doc = elem.ownerDocument; // 获取当前文档对象
      switch (data.eventType) {case "add":
          aWin.AttachmentObject.Add(data.customData.fieldindex, data.customData.path);break;case "delete":
          aWin.AttachmentObject.Delete(data.customData.fieldindex, data.customData.fileindex);break;case "filepreview":
          $(elem).find('#AttachmentDiv' + data.customData.index).find("a").eq(data.customData.value).click();break;}
    },
    getTemplate_uiControl183_eJFigy: function () {
      var selfTemplate = "// \u6A21\u677F\u5F15\u7528\u793A\u4F8B\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return  data?<AttachmentUpload data={data} callback={callback}/>:\"\"\n  }\n});";
      return "\"use strict\";\n\n// \u6A21\u677F\u5F15\u7528\u793A\u4F8B\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return data ? React.createElement(AttachmentUpload, { data: data, callback: callback }) : \"\";\n  }\n});";
    }
  }, "lks_plflowreview");
})(window, ysp);