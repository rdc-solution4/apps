(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control223_2Ue2rh: function (elem) {
      if (elem) {
        var data = $(elem).find("td[style]").text() || "常用审批语";return data;
      }return;
    }, doAction_uiControl237_CAtTR1: function (data, elem) {},
    getTemplate_uiControl237_CAtTR1: function () {
      var selfTemplate = "import { back, closeWindow} from 'appRenderer';\n\nconst { NavBar , Tabs } = AMUITouch2;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n  \treturn (<NavBar\n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar,\n    Tabs = _AMUITouch.Tabs;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control224_uobb4C: function (elem) {
      if (elem) {
        var data = { item: [] };function getContent($td, tri, tdi) {
          var tdcontent = { tri: tri, tdi: tdi };if ($td.children("input").length) {
            tdcontent.input = $td.children("input").attr("type") || "text";tdcontent.value = $td.children("input").val();
          } else if ($td.children("textarea").length) {
            tdcontent.textarea = true;tdcontent.value = $td.children("textarea").val();
          } else {
            tdcontent.content = $td.html();
          }return tdcontent;
        }$(elem).children("tbody").children("tr").each(function (tri, tr) {
          var item = {};$(this).children("td").each(function (tdi, td) {
            if (tdi == 0) {
              if ($(tr).children("td").length == 1) {
                item.TITLE = $(td).text() && $(td).text().trim();
              } else {
                item.label = $(td).text() && $(td).text().trim();
              }
            } else {
              item.content = getContent($(this), tri, tdi);
            }
          });data.item.push(item);
        });return data;
      }return;
    },
    doAction_uiControl238_xdKor2: function (data, elem) {
      var type = data.eventType;var _data = data.customData;switch (type) {case "onValueChange":
          $(elem).children("tbody").children("tr").eq(_data.tri).children("td").eq(_data.tdi).children().val(_data.value).blur();break;}
    },
    getTemplate_uiControl238_xdKor2: function () {
      var selfTemplate = "import {ProfileOpinion} from 'ysp-custom-components';\nmodule.exports = React.createClass({\n  callback:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data)\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    return (\n      <ProfileOpinion data={data} callback = {_this.callback}></ProfileOpinion>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  callback: function callback(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    return React.createElement(_yspCustomComponents.ProfileOpinion, { data: data, callback: _this.callback });\n  }\n});";
    },
    getData_control225_t0alaz: function (elem) {
      if (elem) {
        var data = [];$(elem).find("input[type='button']").each(function (btni, btn) {
          data.push($(this).val());
        });return data;
      }return;
    },
    doAction_uiControl239_FnWlfm: function (data, elem) {
      var type = data.eventType;var _data = data.customData;switch (type) {case "click":
          $(elem).find("input[type='button']").eq(_data).click();break;}
    },
    getTemplate_uiControl239_FnWlfm: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  callback:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data)\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    return (\n      <GlobalFooterBtn data={data} type=\"normal\" callback={_this.callback}></GlobalFooterBtn>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  callback: function callback(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { data: data, type: \"normal\", callback: _this.callback });\n  }\n});";
    }
  }, "lks_profile");
})(window, ysp);