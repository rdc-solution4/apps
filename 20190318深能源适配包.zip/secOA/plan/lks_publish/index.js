(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control186_SXUMT0: function (elem) {
      return elem.textContent;
    },
    doAction_uiControl201_eumyIa: function (data, elem) {},
    getTemplate_uiControl201_eumyIa: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control187_pOCeIr: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('input').each(function (i) {
        var actived = this.className.indexOf('labelbg1') != -1;if (this.value == '发布' || this.value == '发布机制' || this.value == '权限' || this.value == '阅读信息') {
          return;
        }var objInput = { id: this.getAttribute('id'), index: i, value: this.value, actived: actived, disabled: this.getAttribute('rowdisabled') };data.push(objInput);
      });return data;
    },
    doAction_uiControl202_90EhTn: function (data, elem) {
      if (data.eventType == 'click') {
        var index = data.customData;$(elem).find('input').eq(index).click();
      }
    },
    getTemplate_uiControl202_90EhTn: function () {
      var selfTemplate = "var GlobalTab = require('ysp-custom-components').GlobalTab;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var _this = this;\n    return <GlobalTab callBack = {_this.clickLi} customData={this.props.customData} />;\n  }\n});";
      return "'use strict';\n\nvar GlobalTab = require('ysp-custom-components').GlobalTab;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var _this = this;\n    return React.createElement(GlobalTab, { callBack: _this.clickLi, customData: this.props.customData });\n  }\n});";
    },

    getData_control189_Rf4UyS: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "版本" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (!elem) {
        return;
      }if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var $tbReview = $(_elem).find('table').eq(0);var data = { basicData: [], collapseData: [] };initData($tbReview, data);return data;
      } else {
        return undefined;
      }function initData($table, data) {
        var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (i, tr) {
          var $tds = $(tr).children('td');var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';var hiddenRowText = ['流程关注：', '流程记录：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.isHidden || this.style.display == 'none') {
            return;
          }var $childTable = $tds.eq(0).find('table');$childTable.each(function () {
            if (this.isHidden) {
              return;
            } else {
              data.basicData.push({ type: 'table', table: initEditTable($(this)) });
            }
          });$tds.each(function (j, td) {
            //用于解决“机要物品”、“授权书”不显示的问题   2018/6/22  金波
            if (j == 0 && $(td).find("div>b")[0] || $(td).find("div>font")[0]) {
              var label = this.innerText.trim();var item = { label: label, isConTitle: true };data.basicData.push(item);
            }if (j % 2 == 0 && $tds[j + 1]) {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, tableId: tableId, trIndex: i, tdIndex: j + 1 };$oddTd.find('table').each(function () {
                if (this.isHidden) {
                  return;
                } else {
                  item.table = item.table || [];item.type = 'table';item.table = initEditTable($(this));
                }
              });var $select = $oddTd.find('select');if ($select.length) {
                initSelect($select, item);
              }var $inputs = $oddTd.find('input');if ($inputs.length) {
                initInput($inputs, item);
              }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                initTextArea($textarea, item);
              }var $aLink = $oddTd.find('a');if ($aLink.length) {
                initLinks($aLink, item);
              }var content = $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table) {
                item.content = content;
              }if (!label) {
                return;
              }if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
                data.collapseData.push(item);
              } else {
                data.basicData.push(item);
              }
            }
          });
        });
      }function initInput($inputs, data) {
        $inputs.each(function (index, input) {
          var isHidden = input.isHidden;if (isHidden || this.type == 'hidden') {
            return;
          }if (this.disabled) {
            // disabled form 提交后会丢失
            this.disabled = false;this.readOnly = true;
          }var type = input.type;data.type = type;var nextSib = this.nextSibling;var inputObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: index, type: type, text: nextSib ? nextSib.textContent : $(this).parent().text().replace("〖", "").replace("〗", ""), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
            inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');data.radios = data.radios || { type: type, name: this.name, options: [] };data.radios.options.push(inputObj);
          }if (type == 'checkbox') {
            inputObj.text = $(this).next().text() || inputObj.text;inputObj.text = inputObj.text.replace('*', '');data.checkbox = data.checkbox || { type: type, name: this.name, options: [] };data.checkbox.options.push(inputObj);
          }var eleNext = this.nextElementSibling;if (eleNext) {
            var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
              inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
            }
          }if (type == 'button' || type == 'text') {
            if (type == "text") {
              //修正授权期限不在一行的问题加入的新的属性。用于在css文件中好区分开，公共模板有修改  2018/6/22  金波
              inputObj.isInline = this.name == "CF_EndDay" ? true : false;
            }data.inputs = data.inputs || [];inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';data.inputs.push(inputObj);
          }if (data.radios) {
            data.inputLabel = this.parentNode.innerText;
          }
        });
      }function initSelect($select, data) {
        data.select = [];$select.each(function (i) {
          var visibility = $(this).css('visibility');if (this.style.display == 'none' || this.isHidden) {
            return;
          }var select = {};select.options = [];select.type = 'select';select.visibility = visibility;
          select.tableId = data.tableId;select.trIndex = data.trIndex;select.tdIndex = data.tdIndex;select.name = $(this).attr('name');select.id = $(this).attr('id');select.disabled = $(this)[0].disabled;select.readonly = $(this)[0].readOnly;$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });data.select.push(select);
        });
      }function initTextArea($textarea, data) {
        data.textarea = [];$textarea.each(function () {
          if (this.style.display == 'none' || this.isHidden) {
            return;
          }var textareaObj = { tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, type: 'textarea', name: this.name, disabled: this.disabled, readonly: this.readOnly || this.readonly, placeholder: this.placeholder, value: this.value };data.textarea.push(textareaObj);
        });
      }function initLinks($aLink, data) {
        data.link = [];$aLink.each(function (i, a) {
          var sClick = a.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none' || this.isHidden) {
            return;
          }data.link.push({ tableId: data.tableId, trIndex: data.trIndex, tdIndex: data.tdIndex, index: i, text: a.textContent.replace("〖", "").replace("〗", ""), type: 'link' });
        });if (data.link.length == 0) {
          delete data.link;
        }
      }function initEditTable($table) {
        var thead = [];var tbody = [];var tableId = $table.attr('id');$table.children('tbody').children('tr').each(function (trIndex, tr) {
          if (tr.isHidden) {
            return;
          }var $td = $(this).children('td');var trData = [];$td.each(function (tdIndex, td) {
            if (td.isHidden) {
              return;
            }if (trIndex == 0) {
              thead.push({ colspan: this.getAttribute('colspan'), content: td.textContent });
            } else {
              var children = $(this).children();if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
                return;
              }var tdObj = { tableId: tableId, trIndex: trIndex, tdIndex: tdIndex, colspan: this.getAttribute('colspan') };var $select = $(td).find('select');if ($select.length) {
                initSelect($select, tdObj);
              }var $inputs = $(td).find('input');if ($inputs.length) {
                initInput($inputs, tdObj);
              }var $textarea = $(td).find('textarea');if ($textarea.length) {
                initTextArea($textarea, tdObj);
              }var $aLink = $(td).find('a');if ($aLink.length) {
                initLinks($aLink, tdObj);
              }if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
                tdObj.content = this.innerText.trim();
              }trData.push(tdObj);
            }
          });if (trIndex != 0 && trData.length) {
            tbody.push(trData);
          }
        });
        return { thead: thead, tbody: tbody };
      }
    },
    doAction_uiControl204_69H9PT: function (data, elem) {},
    getTemplate_uiControl204_69H9PT: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n     var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    const self = this;\n    const data = this.props.customData;\n \t\tif(!data || !data.basicData[0]){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data || !data.basicData[0]) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control190_gJ7k3Z: function (elem) {
      if (!elem) {
        return;
      }var _elem = $(elem);if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];var collapseData = [];var $onepxborder = _elem;var $table = $onepxborder.each(function (i1, e1) {
          data = data.concat(getTableData($(this), i1));
        });function initSelect($select, item) {
          var select = {};select.options = [];select.type = 'select';select.trIndex = item.trIndex;select.tableIndex = item.tableIndex;select.name = $select.attr('name');select.disabled = $select[0].disabled;select.readonly = $select[0].readOnly;select.id = $select.attr('id');$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });return select;
        }function getTableData($table, tableIndex) {
          // debugger;
          var data = [];tableIndex = tableIndex || 0;$table.children('tbody').children('tr').each(function (i, tr) {
            var trId = this.getAttribute('id') || '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0)[0] && $tds.eq(0)[0].innerText ? $tds.eq(0)[0].innerText : '';var hiddenRowText = ['流程关注：', '流程记录：', '文件附件：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
              return;
            }$tds.each(function (j, td) {
              if (j % 2 == 0 && $tds[j]) {
                var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                  return;
                }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, trIndex: i, tableIndex: tableIndex };if ($tds.length == 1) {
                  item.isSingle = true;
                }var $iframe = $oddTd.find('#F_BodyIframe');if ($iframe.length) {
                  item.iframes = [];$iframe.each(function (i, iframe) {
                    var _body = iframe.contentDocument.querySelector('body');$(_body).find('img').each(function (inx, ele) {
                      $(this).attr('src', this.src);
                    });item.iframes.push({ trIndex: item.trIndex, tableIndex: tableIndex, index: i, text: iframe.contentDocument.querySelector('body').innerHTML, type: 'edit' });
                  });
                } else {
                  var $select = $oddTd.find('select');if ($select.length) {
                    item.select = [];$select.each(function (i, select) {
                      var selectObj = initSelect($(select), item);item.select.push(selectObj);
                    });
                  }var $inputs = $oddTd.find('input');if ($inputs.length) {
                    $inputs.each(function (index, input) {
                      var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden) {
                        return;
                      }var type = input.type;item.type = type;var inputObj = { trIndex: item.trIndex, tableIndex: tableIndex, index: index, type: type, text: $(this).parent().text(), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
                        inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');item.radios = item.radios || { trIndex: item.trIndex, tableIndex: tableIndex, type: type, name: this.name, options: [] };item.radios.options.push(inputObj);
                      }if (type == 'checkbox') {
                        inputObj.text = $(this).next().text() || inputObj.text;if (~this.name.indexOf('F_Xgxx') || ~this.name.indexOf('F_Ztxg') || ~this.name.indexOf('F_Xdsm')) {
                          inputObj.text = this.value;
                        }item.checkbox = item.checkbox || { trIndex: item.trIndex, tableIndex: tableIndex, type: type, name: this.name, options: [] };item.checkbox.options.push(inputObj);
                      }var eleNext = this.nextElementSibling;if (eleNext) {
                        var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
                          inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate(inputObj.value);inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
                        }
                      }if (type == 'button' || type == 'text') {
                        item.inputs = item.inputs || [];inputObj.label = this.parentNode.innerText || '';item.inputs.push(inputObj);
                      }if (item.radios) {
                        item.inputLabel = this.parentNode && this.parentNode.innerText;
                      }
                    });
                  }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                    item.textarea = [];$textarea.each(function () {
                      if (this.style.display == 'none') {
                        return;
                      }var textareaObj = { type: 'textarea', trIndex: item.trIndex, tableIndex: tableIndex, name: this.name, disabled: this.disabled, readonly: this.readOnly, placeholder: this.placeholder, value: this.value };item.textarea.push(textareaObj);
                    });
                  }var $aLink = $oddTd.find('a');if ($aLink.length) {
                    item.link = [];$aLink.each(function (i, a) {
                      var sClick = a.getAttribute('onclick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none') {
                        return;
                      }item.link.push({ trIndex: item.trIndex, tableIndex: tableIndex, index: i, text: a.textContent, type: 'link' });
                    });
                  }var $img = $oddTd.find('img');if ($img.length) {
                    item.imgs = [];$img.each(function (i, img) {
                      if (this.style.display == 'none') {
                        return;
                      }item.imgs.push({ trIndex: item.trIndex, tableIndex: tableIndex, index: i, src: img.src, type: 'img' });
                    });
                  }var content = $oddTd[0] && $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link) {
                    item.content = content;
                  }
                }if (!label) {
                  return;
                }if (~label.indexOf("预定修改时间设置") || ~label.indexOf("预定修订时间") || ~label.indexOf("流程提示") || ~label.indexOf("制度使用效果") || ~label.indexOf("修订说明")) {
                  collapseData.push(item);
                } else {
                  data.push(item);
                }
              }
            });
          });return data;
        }return { basicData: data, collapseData: collapseData };
      } else {
        return undefined;
      }
    },
    doAction_uiControl205_ZHt58s: function (data, elem) {
      var oData = data.dataCustom;var $table = $(elem);var $tr = $table.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var $triggerElem = $tr.find('[name="' + oData.name + '"]');$triggerElem.val(oData.value);if (oData.type == 'date') {
            var curWin = $triggerElem[0].ownerDocument.defaultView;curWin.onDateSelected && curWin.onDateSelected();
          }
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl205_ZHt58s: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    const self = this;\n    const data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control191_DbcoZB: function (elem) {
      if (!elem) {
        return;
      }var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "主文档" && this.className == "labelbg1") {
          // debugger;
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });if (_elem && _elem[0] && _elem[0].style.display != "none") {
        var data = [];var collapseData = [];var $onepxborder = _elem.find('table');var $table = $onepxborder.each(function (i1, e1) {
          if (e1.style.display != "none") {
            data = data.concat(getTableData($(this), i1));
          }
        });function initSelect($select, item) {
          var select = {};select.options = [];select.type = 'select';select.trIndex = item.trIndex;select.tableIndex = item.tableIndex;select.name = $select.attr('name');select.disabled = $select[0].disabled;select.readonly = $select[0].readOnly;select.id = $select.attr('id');$select.find('option').each(function () {
            if (this.selected) {
              select.value = $(this).val();
            }select.options.push({ value: $(this).val(), text: $(this).text(), selected: this.selected, disabled: this.disabled });
          });return select;
        }function getTableData($table, tableIndex) {
          // debugger;
          var data = [];tableIndex = tableIndex || 0;$table.children('tbody').children('tr').each(function (i, tr) {
            var trId = this.getAttribute('id') || '';var $tds = $(tr).children('td');var td0Text = $tds.eq(0)[0] && $tds.eq(0)[0].innerText ? $tds.eq(0)[0].innerText : '';var hiddenRowText = ['流程关注：', '流程记录：', '文件附件：'];if ($.inArray(td0Text, hiddenRowText) != -1 || this.style.display == 'none') {
              return;
            }$tds.each(function (j, td) {
              if (j % 2 == 0 && $tds[j + 1]) {
                var children = $(this).children();if (this.style.display == 'none' || children.length == 1 && children[0].style.display == 'none') {
                  return;
                }var $oddTd = $tds.eq(j + 1);var label = this.innerText.trim();var item = { label: label, trIndex: i, tableIndex: tableIndex };var $iframe = $oddTd.find('#F_BodyIframe');if ($iframe.length) {
                  item.iframes = [];$iframe.each(function (i, iframe) {
                    var _body = iframe.contentDocument.querySelector('body');$(_body).find('img').each(function (inx, ele) {
                      $(this).attr('src', this.src);
                    });item.iframes.push({ trIndex: item.trIndex, tableIndex: tableIndex, index: i, text: iframe.contentDocument.querySelector('body').innerHTML, type: 'edit' });
                  });
                } else {
                  var $select = $oddTd.find('select');if ($select.length) {
                    item.select = [];$select.each(function (i, select) {
                      var selectObj = initSelect($(select), item);item.select.push(selectObj);
                    });
                  }var $inputs = $oddTd.find('input');if ($inputs.length) {
                    $inputs.each(function (index, input) {
                      var isHidden = input.type == 'hidden' || input.style.display == 'none' || input.parentNode.style.display == 'none';if (isHidden) {
                        return;
                      }var type = input.type;item.type = type;var inputObj = { trIndex: item.trIndex, tableIndex: tableIndex, index: index, type: type, text: $(this).parent().text(), value: this.value, name: this.name, id: $(this).attr('id'), checked: this.checked, disabled: this.disabled, readonly: this.readonly || this.readOnly, placeholder: this.placeholder };if (type == 'radio') {
                        inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;inputObj.parentId = $(this).parent().attr('id');item.radios = item.radios || { trIndex: item.trIndex, tableIndex: tableIndex, type: type, name: this.name, options: [] };item.radios.options.push(inputObj);
                      }if (type == 'checkbox') {
                        inputObj.text = $(this).next().text() || inputObj.text;if (~this.name.indexOf('F_Xgxx') || ~this.name.indexOf('F_Ztxg') || ~this.name.indexOf('F_Xdsm')) {
                          inputObj.text = this.value;
                        }item.checkbox = item.checkbox || { trIndex: item.trIndex, tableIndex: tableIndex, type: type, name: this.name, options: [] };item.checkbox.options.push(inputObj);
                      }var eleNext = this.nextElementSibling;if (eleNext) {
                        var sClick = eleNext.getAttribute('onClick') || '';if (sClick.indexOf('selectDate') != -1) {
                          inputObj.type = 'date';var aWIn = this.ownerDocument.defaultView;inputObj.value = aWIn.handleFormatDate(inputObj.value);inputObj.readonly = eleNext.isHidden || this.style.display == 'none';
                        }
                      }if (type == 'button' || type == 'text') {
                        item.inputs = item.inputs || [];inputObj.label = this.parentNode.innerText || '';item.inputs.push(inputObj);
                      }if (item.radios) {
                        item.inputLabel = this.parentNode && this.parentNode.innerText;
                      }
                    });
                  }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
                    item.textarea = [];$textarea.each(function () {
                      if (this.style.display == 'none') {
                        return;
                      }var textareaObj = { type: 'textarea', trIndex: item.trIndex, tableIndex: tableIndex, name: this.name, disabled: this.disabled, readonly: this.readOnly, placeholder: this.placeholder, value: this.value };item.textarea.push(textareaObj);
                    });
                  }var $aLink = $oddTd.find('a');if ($aLink.length) {
                    item.link = [];$aLink.each(function (i, a) {
                      var sClick = a.getAttribute('onclick') || '';if (sClick.indexOf('selectDate') != -1 || this.style.display == 'none') {
                        return;
                      }item.link.push({ trIndex: item.trIndex, tableIndex: tableIndex, index: i, text: a.textContent, type: 'link' });
                    });
                  }var $img = $oddTd.find('img');if ($img.length) {
                    item.imgs = [];$img.each(function (i, img) {
                      if (this.style.display == 'none') {
                        return;
                      }item.imgs.push({ trIndex: item.trIndex, tableIndex: tableIndex, index: i, src: img.src, type: 'img' });
                    });
                  }var content = $oddTd[0] && $oddTd[0].innerText.trim();if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link) {
                    item.content = content;
                  }
                }if (!label) {
                  return;
                }if (~label.indexOf("预定修改时间设置") || ~label.indexOf("预定修订时间") || ~label.indexOf("流程提示") || ~label.indexOf("制度使用效果") || ~label.indexOf("修订说明")) {
                  collapseData.push(item);
                } else {
                  data.push(item);
                }
              }
            });
          });return data;
        }return { basicData: data, collapseData: collapseData };
      } else {
        return undefined;
      }
    },
    doAction_uiControl206_smvOTT: function (data, elem) {
      var oData = data.dataCustom;var _elem = null;var _input = $(elem).children('tbody').children('tr').eq(0).find('input');_input.each(function (inx, ele) {
        if (this.value == "主文档" && this.className == "labelbg1") {
          _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
        }
      });var $onepxborder = _elem.find('table');var $table = $(elem).find('table').eq(oData.tableIndex);var $tr = $table.children('tbody').children('tr').eq(oData.trIndex);if (data.eventType === 'onValueChange') {
        if (oData.type == 'select') {
          var $select = $tr.find('select[name="' + oData.name + '"]');if (!$select.length && oData.id) {
            $select = $tr.find('select[id="' + oData.id + '"]');
          }$select.val(oData.value).change();
        } else if (oData.type == 'radio' || oData.type == 'checkbox') {
          var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');if ($curRadio.length) {
            $curRadio[0].click();
          } else if (oData.id) {
            $tr.find('[id="' + oData.id + '"]').click();
          } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
            var $parent = $tr.find('[id="' + oData.parentId + '"]');$parent.click();$parent.find('[type="radio"]')[0].checked = !oData.checked;
          }
        } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
          var triggerElem = $tr.find('[name="' + oData.name + '"]');triggerElem.val(oData.value);
        }
      } else if (data.eventType === 'click') {
        if (oData.type == 'link') {
          $tr.find('a').eq(oData.index).click();
        } else if (oData.type == 'button') {
          $tr.find('[name="' + oData.name + '"]').click();
        }
      } else if (data.eventType === 'blur') {
        var $onepxborder = $(elem).find('table.onepxborder');var firstTrText = $onepxborder.eq(0).find('tr').eq(0);firstTrText.find('input[name="Subject"]')[0].value = oData;firstTrText.find('input[name="Subject"]')[0].setAttribute("value", oData);
      }
    },
    getTemplate_uiControl206_smvOTT: function () {
      var selfTemplate = "import {ReviewBasicInfo} from 'ysp-custom-components';\n\nmodule.exports = React.createClass({\n  eventHandler:function(data){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  },\n\n  render: function() {\n    const self = this;\n    const data = this.props.customData;\n \t\tif(!data){\n      return(<span></span>)\n    }\n    return(<ReviewBasicInfo eventHandler={self.eventHandler} customData={data}></ReviewBasicInfo>)\n  }\n});";
      return "'use strict';\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  eventHandler: function eventHandler(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler(data);\n    }\n  },\n\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(_yspCustomComponents.ReviewBasicInfo, { eventHandler: self.eventHandler, customData: data });\n  }\n});";
    },
    getData_control192_42HZ9Z: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        if ($(item).attr('value') == '关闭' || $(item).attr('value') == '快速通过' || $(item).attr('value') == '提交') {
          var objShow = {};objShow.title = $(item).attr('value');objShow.index = index;arry1.push(objShow);obj.show = arry1;
        } else if ($(item).attr('value') == '阅知保留' || $(item).attr('value') == '提交' || $(item).attr('value') == '暂存') {
          var objHide = {};objHide.title = $(item).attr('value');objHide.index = index;arry2.push(objHide);obj.hide = arry2;
        }
      });return obj;
    },
    doAction_uiControl208_HaJnTq: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl208_HaJnTq: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={this.props.customData} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: this.props.customData });\n  }\n});";
    },
    getData_control193_KS6oRT: function (elem) {
      // 采集，注意选取的元素需要在统一window作用域内并且不要超出祖辈级tr元素的范围
      if (elem) {
        var $elem;var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
        var doc = elem.ownerDocument; // 获取当前文档对象
        if ($(elem).attr("id") == "labelTable") {
          $(elem).children("tbody").children("tr").each(function (tri, tr) {
            // debugger
            if ($(this)[0].style.display != "none" && $(elem).find(".labelbg1").val().indexOf("版本") == -1) {
              $elem = $(this).find('[id^="AttachmentDiv"]');
            } else {
              return;
            }
          });
        } else {
          $elem = $(elem).find('[id^="AttachmentDiv"]');
        }if ($elem && $elem.length == 0) {
          return;
        }var params = $(doc).find("#AttachmentOCX").children('param'); // 获取当前页面附件参数
        var _AttachmentObject = aWin.AttachmentObject; // 获取当前页面附件初始化对象
        var data = { Index: _AttachmentObject.Index };var existingfiles; // 初始化已存在的文件对象
        data.fileField = [];$elem && $elem.each(function (eli, fileitem) {
          existingfiles = [];$(fileitem).children("a").each(function (inputi, fileele) {
            existingfiles.push({ filename: $(fileele).text(), isUpload: $(fileele).prev("input").attr("isupload"), anchor: inputi });
          });data.fileField.push({ title: $(fileitem).closest("td").prev().text() && $(fileitem).closest("td").prev().text().trim() || "相关附件", isEdit: $(fileitem).children("input").length > 0, sqeNum: $(fileitem).attr('id').match(/\d+/)[0], existingfiles: existingfiles });
        });data.__Click = $(doc).find("input[name='__Click']").val();params.each(function (index, param) {
          switch (param.name) {case 'Server':
              data.Server = param.value;break;case 'Port':
              data.Port = param.value;break;case 'ReceiveForm':
              data.ReceiveForm = param.value;break;case 'FileInputName':
              data.FileInputName = param.value;break;case 'DocId':
              data.DocId = param.value;break;case 'FileLimits':
              data.FileLimits = param.value;break;case 'Encoding':
              data.Encoding = param.value;break;}
        });return data;
      }return;
    },
    doAction_uiControl209_ZCOgvE: function (data, elem) {
      var aWin = elem.ownerDocument.defaultView; // 获取当前窗口对象
      var doc = elem.ownerDocument; // 获取当前文档对象
      switch (data.eventType) {case "add":
          aWin.AttachmentObject.Add(data.customData.fieldindex, data.customData.path);break;case "delete":
          aWin.AttachmentObject.Delete(data.customData.fieldindex, data.customData.fileindex);break;case "filepreview":
          $(elem).find('#AttachmentDiv' + data.customData.index).find("a").eq(data.customData.value).click();break;}
    },
    getTemplate_uiControl209_ZCOgvE: function () {
      var selfTemplate = "var AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return  data?<AttachmentUpload data={data} callback={callback}/>:\"\"\n  }\n});";
      return "\"use strict\";\n\nvar AttachmentUpload = require('ysp-custom-components').AttachmentUpload;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n    var callback = this.props.customHandler;\n    return data ? React.createElement(AttachmentUpload, { data: data, callback: callback }) : \"\";\n  }\n});";
    }
  }, "lks_publish");
})(window, ysp);