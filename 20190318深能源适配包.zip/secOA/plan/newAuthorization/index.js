(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control197_pTWu2S: function (elem) {
      return elem.textContent.trim();
    },
    doAction_uiControl214_5mwKbK: function (data, elem) {
      "use strict";
    },
    getTemplate_uiControl214_5mwKbK: function () {
      var selfTemplate = "import { back } from 'appRenderer';\n\nconst { NavBar } = AMUITouch2;\nmodule.exports = React.createClass({\n  \n  render: function() {\n    const data = this.props.customData;\n\n  \treturn (<NavBar \n      title={data} \n      leftNav={[{\n        onClick: back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]}\n  />);\n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nvar _AMUITouch = AMUITouch2,\n    NavBar = _AMUITouch.NavBar;\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n\n  render: function render() {\n    var data = this.props.customData;\n\n    return React.createElement(NavBar, {\n      title: data,\n      leftNav: [{\n        onClick: _appRenderer.back,\n        title: \"\u8FD4\u56DE\",\n        icon: \"left\"\n      }]\n    });\n  }\n});";
    },
    getData_control198_rG3DeC: function (elem) {
      if (!elem) {
        return;
      }var inputAll = $(elem).find("input");var obj = {};var arry1 = [];var arry2 = [];inputAll.map((index, item) => {
        var that = $(item).attr('value');arry1.push({ title: $(item).attr('value'), index: index });obj.show = arry1;
      });return obj;
    },
    doAction_uiControl216_qn6W9B: function (data, elem) {
      var eventType = data.eventType;var customData = data.customData;if (eventType == "click") {
        $(elem).find("input").eq(customData).click();
      }
    },
    getTemplate_uiControl216_qn6W9B: function () {
      var selfTemplate = "var GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n\n  clickLi: function(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      })\n    }\n\n  },\n  render: function(callBack) {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var _this = this;\n    return (<GlobalFooterBtn callBack = {_this.clickLi} customData={data} />);\n  }\n});\n";
      return "'use strict';\n\nvar GlobalFooterBtn = require('ysp-custom-components').GlobalFooterBtn;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  clickLi: function clickLi(data) {\n    var callBack = this.props.customHandler;\n\n    if (callBack) {\n      callBack({\n        eventType: data.eventType,\n        customData: data.customData\n      });\n    }\n  },\n  render: function render(callBack) {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    var _this = this;\n    return React.createElement(GlobalFooterBtn, { callBack: _this.clickLi, customData: data });\n  }\n});";
    },
    getData_control199_qT5DOG: function (elem) {
      if (!elem) {
        return;
      }var data = [].map.call($(elem).find("td[bgcolor='#F7F7F7']"), function (el, i) {
        var $con = $(el).next(),
            content;if (!$con.find("a,input").length) {
          content = $con.text();
        } else if ($con.attr("class") == "qtksqdw") {
          content = { type: 'a', href: $con.find("a").attr("href"), text: $con.find("a").text(), tip: $con[0].childNodes[2].textContent, trIndex: i };
        } else if ($con.find("input[readonly]").length) {
          var $inp = $con.find("input[readonly]");var judgeName = $inp.attr("name");if (judgeName.indexOf("DisCreator") != -1) {
            content = $inp.val();
          }var aWin = elem.ownerDocument;if (judgeName.indexOf("BeginDate") != -1) {
            content = { type: 'time', begin: aWin.handleFormatDate ? aWin.handleFormatDate($inp.eq(0).val()) : $inp.eq(0).val(), end: aWin.handleFormatDate ? aWin.handleFormatDate($inp.eq(1).val()) : $inp.eq(1).val(), tip: $con.find("font").text().split(/；/g)[0] + '；<br/>' + $con.find("font").text().split(/；/g)[1] };
          }if (judgeName.indexOf("Com") != -1) {
            content = { type: 'choosePeo', text: $inp.val(), placeholder: $inp.val(), tip: $con[0].childNodes[0].textContent.trim().replace(/：/g, ''), trIndex: i };
          }
        } else if ($con.find("input[type='checkbox']").length) {
          content = [].map.call($con.find("input[type='checkbox']").not("[id='checkAll']"), function (ip, k) {
            return { id: ip.getAttribute('id'), type: 'checkbox', name: ip.name ? ip.name : ip.value, val: ip.name ? ip.name.indexOf('Send') != -1 ? ip.nextSibling.textContent.trim() : ip.value : ip.getAttribute("text"), checked: ip.checked, trIndex: i, curindex: k };
          });
        } else if ($con.find("input[type='radio']").length) {
          content = [].map.call($con.find("input[type='radio']"), function (ip, k) {
            return { type: 'radio', name: ip.name, val: ip.value, checked: ip.checked, text: ip.nextSibling.textContent.trim(), trIndex: i, curindex: k };
          });
        }if (el.textContent == '模块名称：') {
          return { label: el.textContent, checked: elem.querySelector("#checkAll").checked, content: content };
        } else {
          return { label: el.textContent, content: content };
        }
      });return data;
    },
    doAction_uiControl217_feLU4T: function (data, elem) {
      var evt = data.eventType,
          d = data.dataCustom;switch (evt) {case "change":
          d.name == 'start' ? $(elem).find("input[name*='BeginDate']").val(d.val) : '';d.name == 'end' ? $(elem).find("input[name*='EndDate']").val(d.val) : '';break;case "click":
          switch (d.type) {case "a":
              ysp.appMain.getActiveWindow().location.href = d.href;break;case "checkbox":case "radio":
              $(elem).find("td[bgcolor='#F7F7F7']").eq(d.trIndex).next().find("input[type='checkbox'],input[type='radio']").not('[id="checkAll"]').eq(d.curindex).click();break;case "choosePeo":
              $(elem).find("td[bgcolor='#F7F7F7']").eq(d.trIndex).next().find("a").click();break;case "chooseAll":
              $(elem).find("#checkAll").click();break;}break;}
    },
    getTemplate_uiControl217_feLU4T: function () {
      var selfTemplate = "import {\n  NewAuth\n} from 'ysp-custom-components';\nexport default class extends React.Component {\n  eventHandler = (data) =>{\n    var handler = this.props.customHandler;\n    if(handler){\n      handler(data);\n    }\n  }\n  \n  render() {\n    let self = this;\n    let customData = this.props.customData;\n    if (customData) {\n      return <NewAuth eventHandler={self.eventHandler} customData = {customData} />\n    } else {\n      return <div></div>\n    }\n  }\n\n}\n\n";
      return "'use strict';\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if (\"value\" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();\n\nvar _yspCustomComponents = require('ysp-custom-components');\n\nfunction _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError(\"Cannot call a class as a function\"); } }\n\nfunction _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError(\"this hasn't been initialised - super() hasn't been called\"); } return call && (typeof call === \"object\" || typeof call === \"function\") ? call : self; }\n\nfunction _inherits(subClass, superClass) { if (typeof superClass !== \"function\" && superClass !== null) { throw new TypeError(\"Super expression must either be null or a function, not \" + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }\n\nvar _class = function (_React$Component) {\n  _inherits(_class, _React$Component);\n\n  function _class() {\n    var _ref;\n\n    var _temp, _this, _ret;\n\n    _classCallCheck(this, _class);\n\n    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {\n      args[_key] = arguments[_key];\n    }\n\n    return _ret = (_temp = (_this = _possibleConstructorReturn(this, (_ref = _class.__proto__ || Object.getPrototypeOf(_class)).call.apply(_ref, [this].concat(args))), _this), _this.eventHandler = function (data) {\n      var handler = _this.props.customHandler;\n      if (handler) {\n        handler(data);\n      }\n    }, _temp), _possibleConstructorReturn(_this, _ret);\n  }\n\n  _createClass(_class, [{\n    key: 'render',\n    value: function render() {\n      var self = this;\n      var customData = this.props.customData;\n      if (customData) {\n        return React.createElement(_yspCustomComponents.NewAuth, { eventHandler: self.eventHandler, customData: customData });\n      } else {\n        return React.createElement('div', null);\n      }\n    }\n  }]);\n\n  return _class;\n}(React.Component);\n\nexports.default = _class;";
    }
  }, "newAuthorization");
})(window, ysp);