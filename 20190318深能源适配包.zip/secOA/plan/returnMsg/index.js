(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control38_Uf0TZp: function (elem) {
      if (!elem) {
        return;
      }var data = [];if ($(elem).length > 0) {
        data.push($(elem).text() && $(elem).text().trim());
      } else {
        return;
      }return data;
    },
    doAction_uiControl50_LtI2C4: function (data, elem) {},
    getTemplate_uiControl50_LtI2C4: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <span>\n        {data}\n      </span>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"span\",\n      null,\n      data\n    );\n  }\n});";
    },
    getData_control39_Ln6mh7: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).children().each(function (i, e) {
        data.push(this.innerText);
      });return data;
    },
    doAction_uiControl51_K3vor6: function (data, elem) {},
    getTemplate_uiControl51_K3vor6: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data || data.length == 0){\n      return(\n      \t<div></div>\n      )\n    }\n    return (\n      <div>\n        {data}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data || data.length == 0) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      data\n    );\n  }\n});";
    }
  }, "returnMsg");
})(window, ysp);