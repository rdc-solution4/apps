import {HrReviewBody} from 'ysp-custom-components';

module.exports = React.createClass({
  eventHandler:function(data){
    var handler = this.props.customHandler;
    if(handler){
      handler(data);
    }
  },

  render: function() {
    var self = this;
    var data = this.props.customData;
 		if(!data  || !data.basicData[0]){
      return(<span></span>)
    }
    return(<HrReviewBody eventHandler={self.eventHandler} customData={data}></HrReviewBody>)
  }
});

if (!elem) {
  return;
}
var $lableTr = null;
var trText = [];
$(elem).children('tbody').children('tr').eq(0).find('input').each(function (inx, ele) {
  if (this.value == "审批内容" && this.className == "labelbg1") {
    // 获取审批内容对应的tr
    $lableTr = $(elem).children('tbody').children('tr').eq(inx + 1);
  }
});
if ($lableTr && $lableTr[0] && $lableTr[0].style.display != "none") {
  var doc = $lableTr[0].querySelector('iframe') && $lableTr[0].querySelector('iframe').contentDocument;
  var $tbReview = $lableTr.children('td').children('table');

  if ($tbReview.find("#F_BodyDvbbs_Container").length) {
    $tbReview.find("#F_BodyDvbbs_Container img").each(function () {
      $(this).attr('src', this.src);
    });
    data = {
      basicData: [1],
      type: "editTextarea",
      text: $(doc.body)[0].outerHTML
    };
    return data;
  }

  if (doc) {
    var $mainTable = $(doc.body).find('table#mainTable');
    $tbReview = $(doc.body).find('form>table[bgcolor="#c0c0c0"]').last();

    if ($tbReview[0] && !$tbReview[0].isHidden) {
      $tbReview = $tbReview;
    } else if ($mainTable.length && !$mainTable[0].isHidden) {
      $tbReview = $mainTable;
    } else if (!$tbReview[0]) {
      $tbReview = $(doc.body).find('form>table').last();
    }
  }

  var remark = [];

  if ($tbReview && $tbReview.length) {
    var $divRemark;

    if ($tbReview.parent().siblings('div').last().length) {
      $divRemark = $tbReview.parent().siblings('div').last();
    } else if ($tbReview.next()) {
      $divRemark = $tbReview.next();
    }

    var tageName = ['BR', 'SCRIPT'];

    if ($divRemark[0] && $.inArray($divRemark[0].tagName, tageName) == -1 && !$divRemark[0].isHidden && $divRemark[0].style.display != 'none') {
      remark.push($divRemark[0].innerText);
    }
  }

  var data = {
    basicData: [],
    collapseData: [],
    Remark: remark
  };

  if ($(doc).find("table[id^='mainTable']").length && $tbReview[0] != $(doc).find("table[id^='mainTable']")[0]) {
    $(doc).find("table[id^='mainTable']").each(function () {
      if ($(this)[0] != $tbReview[0] && $(this).children("tbody").children("tr")[0].style.display != "none") {
        initData($(this), data);
      }
    });
  }

  initData($tbReview, data);
  var $divJudge = $tbReview.parent().find('[id^="divJudge"]'); // divJudge9

  if ($divJudge.length) {
    data.Remark = '';
    $divJudge.each(function (i, div) {
      var $talbe = $(this).find('table');
      $talbe.attr('id', 'judgeTable' + i);
      initData($talbe.eq(0), data);
    });
  }

  return data;
} else {
  return undefined;
}
function initData($table, data) {
  var tableId = $table.attr('id');
  var scrollTable = {
    type: 'table',
    hasContent: true,
    table: {
      thead: [],
      tbody: []
    }
  };
  $table.children('tbody').children('tr').each(function (i, tr) {
    var $tds = $(tr).children('td');
    var td0Text = $tds.eq(0).text() ? $tds.eq(0).text().trim() : '';
    var hiddenRowText = ['流程关注：', '流程记录：', '相关附件：', '相关附件：\n暂无附件！'];

    if ($(tr).attr("enumtablecontent") && $tds.length == $(tr).attr("enumtablecontentlen")) {
      var tdContent = [];
      $tds.each(function (tdi, td) {
        var children = $(this).children();

        if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
          return;
        }

        var tdObj = {
          tableId: tableId,
          colspan: this.getAttribute('colspan') || ''
        };
        var $select = $(td).find('select');

        if ($select.length) {
          initSelect($select, tdObj);
        }

        var $inputs = $(td).find('input');

        if ($inputs.length) {
          initInput($inputs, tdObj);
        }

        var $textarea = $(td).find('textarea');

        if ($textarea.length) {
          initTextArea($textarea, tdObj);
        }

        var $aLink = $(td).find('a');

        if ($aLink.length) {
          initLinks($aLink, tdObj);
        }

        if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
          tdObj.content = this.innerText.trim();
        }

        tdContent.push(tdObj);
      });
      scrollTable.table.tbody.push(tdContent);

      if ($(tr).next().children("td").length != $tds.length) {
        data.basicData.push(scrollTable);
      } else {
        $(tr).next().attr("enumtablecontent", true);
        $(tr).next().attr("enumtablecontentlen", $tds.length);
      }

      return;
    }

    if ($(tr).attr("enumtable") && $tds.eq(0).text() == "序号") {
      $(tr).next().attr("enumtablecontent", true);
      $(tr).next().attr("enumtablecontentlen", $tds.length);
      $tds.each(function () {
        scrollTable.table.thead.push({
          colspan: this.getAttribute('colspan') || '',
          content: $(this).text()
        });
      });
      return;
    }

    if (td0Text.indexOf('查看实际行为事例') != -1 || td0Text.indexOf('相关附件：') != -1 || $.inArray(td0Text, hiddenRowText) != -1 || this.isHidden || this.style.display == 'none') {
      return;
    }

    if (i == 0 && !tr.isHidden && $tds.length <= 1 && !this.isHidden) {
      if ($(this).find('#F_BodyView>*').length) {
        $(this).find('#F_BodyView>*').each(function () {
          var table = '';

          if ($(this).children('table').length == 1) {
            table = $(this).children('table')[0].outerHTML;
            trText.push({
              table: table
            });
          } else if ($(this).children('table').length == 0) {
            trText.push({
              text: this.innerText ? this.innerText.trim() : '',
              img: $(this).children('img').attr('src') ? $(this).children('img')[0].src : null
            });
          }
        });
        data.basicData.push({
          TITLE: trText,
          id: $tds[0].getAttribute('id')
        });
        return;
      }
    }

    if ($tds.length == 1 && $tds.children("b").length > 1) {
      data.basicData.push({
        introduce: $tds.eq(0).html()
      });
      return;
    }

    $tds.each(function (tdIndex, td) {
      if ($(this).find('img[src*="ecblank.gif"]').length && $tds[tdIndex + 1] && $tds[tdIndex + 1].innerText == '建筑工程') {
        $tds.splice(tdIndex, 1);
      }
    });
    $tds.each(function (j, td) {
      if (j % 2 == 0) {
        if ($(this).attr("id") == "td_button") {
          return;
        }

        var children = $(this).children();

        if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
          return;
        }

        var $oddTd = $tds[j + 1] ? $tds.eq(j + 1) : $(this);
        var label = this.id == "yc_pf" ? $(this).html() : this.innerText.trim();
        var $childTable = $oddTd.find('table');

        if ($childTable.length) {
          $childTable.each(function () {
            var tableitem = {
              label: label,
              tableId: tableId,
              trIndex: i,
              tdIndex: j + 1
            };

            if (this.isHidden) {
              return;
            } else {
              tableitem.label = !$tds[j + 1] ? '' : tableitem.label;
              tableitem.table = tableitem.table || [];
              tableitem.type = 'table';
              tableitem.hasContent = true;
              tableitem.table = initEditTable($(this));
            }

            if ($(this).parent().attr("id") == "spanNewTable") {
              var tableIndex = $(this).attr("id").split("_")[1];

              var _tableId = "#dtable_" + tableIndex; // debugger;


              var eles = $(this.ownerDocument).find(_tableId);
              data.basicData.push(parseTableTitle(eles));
            }

            data.basicData.push(tableitem);
          });
          return;
        }

        var item = {
          label: label,
          tableId: tableId,
          trIndex: i,
          tdIndex: j + 1
        };
        var $select = $oddTd.find('select').not($childTable.find('select'));

        if ($select.length) {
          initSelect($select, item);
        }

        var $inputs = $oddTd.find('input').not($childTable.find('input'));

        if ($inputs.length) {
          initInput($inputs, item);
        }

        var $textarea = $oddTd.find('textarea').not($childTable.find('textarea'));

        if ($textarea.length) {
          initTextArea($textarea, item);
        }

        var $aLink = $oddTd.find('a').not($childTable.find('a'));

        if ($aLink.length) {
          initLinks($aLink, item);
        }

        if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table && $tds[j + 1]) {
          item.content = $oddTd[0].innerText.trim();
        }

        if (!item.select && !item.checkbox && !item.radios && !item.inputs && !item.textarea && !item.link && !item.table && !item.content && !$tds[j + 1]) {
          item.isConTitle = true;
        }

        if ($(this).find('[name="CF_No"]').length && $(this).find('[name="CF_Year"]').length) {
          item.label = this.innerHTML;
          delete item.inputs;
        }

        if (!label && !item.hasContent) {
          return;
        }

        if (item.isConTitle) {
          $(tr).next().attr("enumtable", true);
        }

        if ($.inArray(td0Text, ['当前处理人：', '已处理人：', '特权人：']) != -1) {
          data.collapseData.push(item);
        } else {
          data.basicData.push(item);
        }
      }
    });
  });
}
function parseTableTitle(eles) {
  eles.prev("div").prev("div").find("input").each(function () {
    var color = this.getAttribute("name").split("_")[1].toLowerCase();
    this.style.background = color;
  });

  if (eles.prev("div").prev("div")[0] && eles.prev("div").prev("div")[0].childNodes.length && eles.prev("div").prev("div")[0].childNodes[0].tagName == "BR") {
    eles.prev("div").prev("div")[0].removeChild(eles.prev("div").prev("div")[0].childNodes[0]);
  }

  return {
    dtabletitle: eles.prev("div").text(),
    lenged: eles.prev("div").prev("div").html()
  };
}
function initInput($inputs, data) {
  $inputs.each(function (index, input) {
    var isHidden = input.isHidden;

    if (isHidden || this.type == 'hidden' || this.style.display == 'none' || this.value == '导出至Excel') {
      return;
    }

    var type = input.type;
    data.type = type;
    data.hasContent = true;
    var nextSib = this.nextSibling;
    var inputObj = {
      tableId: data.tableId,
      trIndex: data.trIndex,
      tdIndex: data.tdIndex,
      index: index,
      type: type,
      text: nextSib ? nextSib.textContent : '',
      value: this.value,
      name: this.name,
      id: $(this).attr('id'),
      checked: this.checked,
      disabled: this.disabled,
      readonly: this.readonly || this.readOnly,
      placeholder: this.placeholder,
      hasBlur: $(this).attr("onblur") ? true : false
    };

    if (type == 'radio') {
      inputObj.text = this.name == 'F_Result' ? inputObj.value : inputObj.text;
      inputObj.parentId = $(this).parent().attr('id');
      data.radios = data.radios || {
        type: type,
        name: this.name,
        options: []
      };
      data.radios.options.push(inputObj);
    }

    if (type == 'checkbox') {
      inputObj.text = $(this).next().text() || inputObj.text;
      inputObj.text = inputObj.text.replace('*', '');
      data.checkbox = data.checkbox || {
        type: type,
        name: this.name,
        options: []
      };
      data.checkbox.options.push(inputObj);
    }

    var eleNext = this.nextElementSibling;

    if (eleNext && eleNext.tagName == 'A' || $(this).attr('datatype') == 'd') {
      if (!eleNext || eleNext && eleNext.tagName != 'A') {
        eleNext = $(this.parentNode.nextElementSibling).find('a')[0];
      }

      if (eleNext) {
        var sClick = eleNext.getAttribute('onClick') || '';

        if (eleNext.tagName == 'A' && sClick) {
          inputObj.text = '';
        }

        if (sClick.indexOf('selectDate') != -1) {
          inputObj.type = 'date';
          var aWIn = this.ownerDocument.defaultView;
          inputObj.value = inputObj.value && aWIn.handleFormatDate ? aWIn.handleFormatDate(inputObj.value) : inputObj.value;
          inputObj.readonly = eleNext.isHidden || eleNext.style.display == 'none';
        }

        if (sClick.indexOf('selectTime') != -1) {
          inputObj.type = 'time';
          inputObj.readonly = eleNext.isHidden || eleNext.style.display == 'none';
        }
      }
    }

    var sClick = $(this).attr('onclick') || '';

    if ($(this).attr('datatype') == 's' && sClick.indexOf('selProposer') != -1) {
      inputObj.doClick = true;
    }

    if (type == 'button' || type == 'text') {
      if (type == "text") {
        //修正授权期限不在一行的问题加入的新的属性。用于在css文件中好区分开，公共模板有修改  2018/6/22  金波
        inputObj.isInline = this.name == "CF_EndDay" || this.name == "CF_E_P9500__ZZHRKHENDDA" || this.name == "CF_E_P9500__ZZHRKHBEGDA" ? true : false;
      }

      inputObj.bgcolor = this.style.backgroundColor;
      data.inputs = data.inputs || [];
      inputObj.label = this.parentNode.innerText.replace("〖", "").replace("〗", "") || '';
      data.inputs.push(inputObj);
    }

    if (data.radios) {
      data.inputLabel = this.parentNode.innerText;
    }
  });
}
function initSelect($select, data) {
  data.select = [];
  data.hasContent = true;
  $select.each(function (i) {
    var visibility = $(this).css('visibility');

    if (this.style.display == 'none' || this.isHidden) {
      return;
    }

    var select = {};
    select.options = [];
    select.type = 'select';
    select.visibility = visibility;
    select.tableId = data.tableId;
    select.trIndex = data.trIndex;
    select.tdIndex = data.tdIndex;
    select.name = $(this).attr('name');
    select.id = $(this).attr('id');
    select.disabled = $(this)[0].disabled;
    select.readonly = $(this)[0].readOnly;
    $select.find('option').each(function () {
      if (this.selected) {
        select.value = $(this).val();
      }

      select.options.push({
        tableId: data.tableId,
        trIndex: data.trIndex,
        tdIndex: data.tdIndex,
        value: $(this).val(),
        text: $(this).text(),
        selected: this.selected,
        disabled: this.disabled
      });
    });
    data.select.push(select);
  });
}
function initTextArea($textarea, data) {
  data.textarea = [];
  $textarea.each(function () {
    if (this.style.display == 'none' || this.isHidden) {
      return;
    }

    var textareaObj = {
      tableId: data.tableId,
      trIndex: data.trIndex,
      tdIndex: data.tdIndex,
      type: 'textarea',
      name: this.name,
      disabled: this.disabled,
      readonly: this.readOnly || this.readonly,
      placeholder: this.placeholder,
      value: this.value
    };
    data.hasContent = true;
    data.textarea.push(textareaObj);
  });
}
function initLinks($aLink, data) {
  data.link = [];
  $aLink.each(function (i, a) {
    var sClick = a.getAttribute('onClick') || '';
    var $img = $(this).parent().find('img[src*="code.gif"]');

    if ($img.length) {
      data.label = $(this).parent().find('font').text();
      this.style.display = '';
    }

    if (sClick.indexOf('selectDate') != -1 || sClick.indexOf('selectTime') != -1 || this.style.display == 'none' || this.isHidden) {
      return;
    }

    data.link.push({
      tableId: data.tableId,
      trIndex: data.trIndex,
      tdIndex: data.tdIndex,
      index: i,
      text: a.textContent.replace("〖", "").replace("〗", ""),
      type: 'link'
    });
  });

  if (data.link.length == 0) {
    delete data.link;
  }

  data.hasContent = true;
}
function initEditTable($table) {
  var thead = [];
  var tbody = [];
  var tableId = $table.attr('id');
  $table.children('tbody').children('tr').each(function (trIndex, tr) {
    if (tr.isHidden) {
      return;
    }

    var $td = $(this).children('td');
    var trData = [];
    $td.each(function (tdIndex, td) {
      if (td.isHidden) {
        return;
      }

      var tdText = td.textContent.trim().replace('〖 添 加 〗', '添加').trim();

      if (tdText == "添加" || tdText == "修改") {
        return;
      }

      if (trIndex == 0) {
        thead.push({
          colspan: this.getAttribute('colspan') || '',
          content: tdText
        });
      } else {
        var children = $(this).children();

        if (this.isHidden || children.length == 1 && children[0].style.display == 'none') {
          return;
        }

        var tdObj = {
          tableId: tableId,
          trIndex: trIndex,
          tdIndex: tdIndex,
          colspan: this.getAttribute('colspan') || '',
          bgcolor: this.style.backgroundColor
        };
        var $select = $(td).find('select');

        if ($select.length) {
          initSelect($select, tdObj);
        }

        var $inputs = $(td).find('input');

        if ($inputs.length) {
          initInput($inputs, tdObj);
        }

        var $textarea = $(td).find('textarea');

        if ($textarea.length) {
          initTextArea($textarea, tdObj);
        }

        var $aLink = $(td).find('a');

        if ($aLink.length) {
          initLinks($aLink, tdObj);
        }

        if (!tdObj.select && !tdObj.checkbox && !tdObj.radios && !tdObj.inputs && !tdObj.textarea && !tdObj.link && !tdObj.table) {
          tdObj.content = this.innerText.trim();
        }

        trData.push(tdObj);
      }
    });

    if (trIndex != 0 && trData.length) {
      tbody.push(trData);
    }
  });
  return {
    thead: thead,
    tbody: tbody
  };
}


var oData = data.dataCustom;
$(elem).children('tbody').children('tr').eq(0).find('input').each(function (inx, ele) {
  if (this.value == "审批内容" && this.className == "labelbg1") {
    _elem = $(elem).children('tbody').children('tr').eq(inx + 1);
  }
});
var doc = _elem[0].querySelector('iframe') && _elem[0].querySelector('iframe').contentDocument;
var $table = _elem.find('table').eq(oData.tableIndex);
if (oData.tableId && oData.tableId != $table.attr('id')) {
  var $table = $(doc).find('table#' + oData.tableId);
}
var $tr = $table.children('tbody').children('tr').eq(oData.trIndex);
if (data.eventType === 'onValueChange') {
  if (oData.type == 'select') {
    var $select = $tr.find('select[name="' + oData.name + '"]');

    if (!$select.length && oData.id) {
      $select = $tr.find('select[id="' + oData.id + '"]');
    }

    $select.val(oData.value).change();
  } else if (oData.type == 'radio' || oData.type == 'checkbox') {
    var $curRadio = $tr.find('[name="' + oData.name + '"]').filter('[value="' + oData.value + '"]');

    if ($curRadio.length) {
      $curRadio[0].click();
    } else if (oData.id) {
      $tr.find('[id="' + oData.id + '"]').click();
    } else if (oData.parentId && oData.parentId.indexOf('tjrListSpan') != -1) {
      var $parent = $tr.find('[id="' + oData.parentId + '"]');
      $parent.click();
      $parent.find('[type="radio"]')[0].checked = !oData.checked;
    }
  } else if (oData.type == 'date' || oData.type == 'text' || oData.type == 'textarea' || oData.type == 'number') {
    var $triggerElem = $tr.find('[name="' + oData.name + '"]');
    $triggerElem.val(oData.value);
    var curDoc = $triggerElem[0].ownerDocument;
    var curWin = curDoc.defaultView;

    if (oData.type == 'date') {
      curWin.onDateSelected && curWin.onDateSelected();
    }

    debugger;

    if (/CF_TLead.*YJ/.test(oData.name) || oData.name == 'CF_LeadYJ' || oData.name == 'CF_TLeadYJ' || oData.name == 'CF_LeadFS' || oData.name == 'CF_TLeadFS' || oData.hasBlur) {
      var event = curDoc.createEvent('HTMLEvents');
      event.initEvent("blur", true, true);
      $triggerElem[0].dispatchEvent(event);
    }
  }
} else if (data.eventType === 'click') {
  if (oData.type == 'link') {
    $tr.find('a').eq(oData.index).click();
  } else if (oData.type == 'button') {
    $tr.find('[name="' + oData.name + '"]').click();
  }
}
