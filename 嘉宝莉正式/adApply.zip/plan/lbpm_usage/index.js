(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control9_iBzARJ: function (elem) {
      return elem.textContent;
    },
    doAction_uiControl9_G2Vw46: function (data, elem) {},
    getTemplate_uiControl9_G2Vw46: function () {
      var selfTemplate = "import { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  click:function(){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'addClick',\n        data:''\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData ||'\u5E38\u7528\u5BA1\u6279\u8BED';\n    return (\n      <header className=\"am2-navbar am2-navbar-primary\">\n        <h2 className=\"am2-navbar-title am2-navbar-center\">{data}</h2>\n        <div className=\"am2-navbar-nav am2-navbar-left\">\n          <a onClick={back} className=\"am2-navbar-nav-item\"><span className=\"am2-icon am2-icon-left-nav am2-navbar-icon am2-navbar-icon-sibling-of-title\"></span><span className=\"am2-navbar-nav-title\">\u8FD4\u56DE</span></a>\n        </div>\n       \n      </header>\n    )\n  }\n});";
      return "'use strict';\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click() {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'addClick',\n        data: ''\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData || '\u5E38\u7528\u5BA1\u6279\u8BED';\n    return React.createElement(\n      'header',\n      { className: 'am2-navbar am2-navbar-primary' },\n      React.createElement(\n        'h2',\n        { className: 'am2-navbar-title am2-navbar-center' },\n        data\n      ),\n      React.createElement(\n        'div',\n        { className: 'am2-navbar-nav am2-navbar-left' },\n        React.createElement(\n          'a',\n          { onClick: _appRenderer.back, className: 'am2-navbar-nav-item' },\n          React.createElement('span', { className: 'am2-icon am2-icon-left-nav am2-navbar-icon am2-navbar-icon-sibling-of-title' }),\n          React.createElement(\n            'span',\n            { className: 'am2-navbar-nav-title' },\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control10_qObC8A: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).children('tbody').children('tr').each(function (i, tr) {
        if (this.style.display == 'none') {
          return;
        }var $tds = $(tr).children('td');$tds.each(function (j, td) {
          if (j % 2 == 0 && $tds[j + 1]) {
            var $oddTd = $tds.eq(j + 1);var label = $(this).text().trim();var item = { label: label, index: i };var $select = $oddTd.find('select');if ($select.length) {
              item.options = [];item.type = 'select';item.name = $select[0].name;$select.find('option').each(function () {
                if (this.selected) {
                  item.value = $(this).val();
                }item.options.push({ value: $(this).val(), text: $(this).text(), selected: this.selected });
              });
            }var $inputs = $oddTd.find('input');if ($inputs.length) {
              item.options = [];$inputs.each(function (index, input) {
                var type = input.type;item.type = type;if (type == 'radio') {
                  item.options.push({ value: $(this).val(), name: this.name, text: $(this).parent().text(), checked: this.checked });
                }if (type == 'button' || type == 'text') {
                  item.value = this.value;item.name = this.name;item.disabled = this.disabled;item.placeholder = this.placeholder;
                }
              });
            }var $textarea = $oddTd.find('textarea');if ($textarea.length) {
              item.type = 'textarea';item.name = $textarea[0].name;item.disabled = $textarea[0].disabled, item.value = $textarea.val();
            }var content = $oddTd[0].innerText.trim();item.content = content;data.push(item);
          }
        });
      });return data;
    },
    doAction_uiControl10_n7ACMk: function (data, elem) {
      var d = data.dataCustom;var $tr = $(elem).children('tbody').children('tr').eq(d.index);if (data.eventType === 'onValueChange') {
        if (d.type == 'select') {
          $tr.find('select[name="' + d.name + '"]').val(d.value).change();
        } else if (d.type == 'radio') {
          $tr.find('[value="' + d.value + '"]').click();
        } else if (d.type == 'text' || d.type == 'textarea') {
          $tr.find('[name="' + d.name + '"]').val(d.value);
        }
      } else if (data.eventType === 'click') {
        if (d.type == 'button') {
          $tr.find('[name="' + d.name + '"]').click();
        }
      }
    },
    getTemplate_uiControl10_n7ACMk: function () {
      var selfTemplate = "const Field = AMUI2.Field;\nconst Choose = AMUI2.Choose;\nconst Title = AMUI2.Title;\nmodule.exports = React.createClass({\n  onValueChange:function(e,data){\n    var handler = this.props.customHandler;\n    if(data.type == 'radio'){\n      data.value = e;\n    }\n    if(e.target){\n      data.value = e.target.value;\n    }\n    \n    if(handler){\n      handler({\n        eventType:'onValueChange',\n        data:data\n      })\n    }\n  },\n  click:function(data){\n    var handler = this.props.customHandler;\n    \n    if(handler){\n      handler({\n        eventType:'click',\n        data:data\n      })\n    }\n  },\n  renderSelect:function(data){\n    var self = this;\n    return(<Field\n            label={data.label}\n            type=\"select\"\n            ref=\"select\"\n            defaultValue={data.value}\n            underline=\"part\"\n            onChange={(e)=>{self.onValueChange(e,data)}}\n            single\n          >\n        {data.options.map((option,i)=>{\n          return(<option value={option.value}>{option.text}</option>)\n        })}\n          </Field>)\n  },\n  renderRadio:function(data){\n    var self = this;\n    return (<Field\n            label={data.label}\n            type=\"custom\"\n            underline=\"part\"  \n            single\n          >\n            <Choose amSize=\"xs\" multiple={false} onValueChange={(e)=>{self.onValueChange(e,data)}}>\n              {data.options.map((option,i)=>{\n                return(<Choose.Item defaultSelected={option.checked} value={option.value}>{option.text}</Choose.Item>)\n              })}\n            </Choose>\n          </Field>)\n  },\n  render: function() {\n    const self = this;\n    const data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div className='ui-content'>\n        {data.map((item,i)=>{\n          if(item.type == 'select'){\n            return self.renderSelect(item);\n          } else if(item.type == 'radio'){\n            return self.renderRadio(item);\n          } else if(item.type =='text' ||item.type == 'textarea'){\n            return (<Field\n            label={item.label}\n            type={item.type}\n            placeholder={item.placeholder}\n            defaultValue={item.value}\n            onChange={(e)=>{self.onValueChange(e,item)}}\n            underline=\"part\"\n            single\n          />)\n          } else if(item.type == 'button'){\n                    return (<div className=\"am2-field-single am2-field-underline-part\">\n                <div className=\"am2-field-label\"><div>{item.label}</div></div>\n                <div className=\"am2-field-wrap\" style={{'justify-content': 'center'}}><button onClick={()=>{self.click(item)}} className=\"am2-field am2-btn am2-btn-sm\">{item.value}</button></div></div>)\n                    } else {\n            return (<div className=\"am2-field-single am2-field-underline-part\">\n                <div className=\"am2-field-label\"><div>{item.label}</div></div>\n                <div className=\"am2-field-wrap\" style={{'justify-content': 'center'}}><span className=\"am2-field\">{item.content}</span></div></div>)\n          }\n           \n        })}\n        \n        \n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar Field = AMUI2.Field;\nvar Choose = AMUI2.Choose;\nvar Title = AMUI2.Title;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  onValueChange: function onValueChange(e, data) {\n    var handler = this.props.customHandler;\n    if (data.type == 'radio') {\n      data.value = e;\n    }\n    if (e.target) {\n      data.value = e.target.value;\n    }\n\n    if (handler) {\n      handler({\n        eventType: 'onValueChange',\n        data: data\n      });\n    }\n  },\n  click: function click(data) {\n    var handler = this.props.customHandler;\n\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: data\n      });\n    }\n  },\n  renderSelect: function renderSelect(data) {\n    var self = this;\n    return React.createElement(\n      Field,\n      {\n        label: data.label,\n        type: 'select',\n        ref: 'select',\n        defaultValue: data.value,\n        underline: 'part',\n        onChange: function onChange(e) {\n          self.onValueChange(e, data);\n        },\n        single: true\n      },\n      data.options.map(function (option, i) {\n        return React.createElement(\n          'option',\n          { value: option.value },\n          option.text\n        );\n      })\n    );\n  },\n  renderRadio: function renderRadio(data) {\n    var self = this;\n    return React.createElement(\n      Field,\n      {\n        label: data.label,\n        type: 'custom',\n        underline: 'part',\n        single: true\n      },\n      React.createElement(\n        Choose,\n        { amSize: 'xs', multiple: false, onValueChange: function onValueChange(e) {\n            self.onValueChange(e, data);\n          } },\n        data.options.map(function (option, i) {\n          return React.createElement(\n            Choose.Item,\n            { defaultSelected: option.checked, value: option.value },\n            option.text\n          );\n        })\n      )\n    );\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(\n      'div',\n      { className: 'ui-content' },\n      data.map(function (item, i) {\n        if (item.type == 'select') {\n          return self.renderSelect(item);\n        } else if (item.type == 'radio') {\n          return self.renderRadio(item);\n        } else if (item.type == 'text' || item.type == 'textarea') {\n          return React.createElement(Field, {\n            label: item.label,\n            type: item.type,\n            placeholder: item.placeholder,\n            defaultValue: item.value,\n            onChange: function onChange(e) {\n              self.onValueChange(e, item);\n            },\n            underline: 'part',\n            single: true\n          });\n        } else if (item.type == 'button') {\n          return React.createElement(\n            'div',\n            { className: 'am2-field-single am2-field-underline-part' },\n            React.createElement(\n              'div',\n              { className: 'am2-field-label' },\n              React.createElement(\n                'div',\n                null,\n                item.label\n              )\n            ),\n            React.createElement(\n              'div',\n              { className: 'am2-field-wrap', style: { 'justify-content': 'center' } },\n              React.createElement(\n                'button',\n                { onClick: function onClick() {\n                    self.click(item);\n                  }, className: 'am2-field am2-btn am2-btn-sm' },\n                item.value\n              )\n            )\n          );\n        } else {\n          return React.createElement(\n            'div',\n            { className: 'am2-field-single am2-field-underline-part' },\n            React.createElement(\n              'div',\n              { className: 'am2-field-label' },\n              React.createElement(\n                'div',\n                null,\n                item.label\n              )\n            ),\n            React.createElement(\n              'div',\n              { className: 'am2-field-wrap', style: { 'justify-content': 'center' } },\n              React.createElement(\n                'span',\n                { className: 'am2-field' },\n                item.content\n              )\n            )\n          );\n        }\n      })\n    );\n  }\n});";
    },
    getData_undefined: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('.lui_widget_btn').each(function () {
        data.push($(this).text().trim());
      });return data;
    },
    doAction_uiControl12_ecDtxp: function (data, elem) {
      if (data.eventType === 'click') {
        var d = data.dataCustom;console.log(d);$(elem).find('.lui_widget_btn').eq(d).click();
      }
    },
    getTemplate_uiControl12_ecDtxp: function () {
      var selfTemplate = "module.exports = React.createClass({\n  click:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'click',\n        data:i\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    return (\n      <div className='btn-footer'>\n       <div className=\"am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify\">\n        {\n           data.map((item,i)=>{\n             var className = item=='\u5173\u95ED'? 'am2-btn am2-btn-primary am2-btn-hollow':'am2-btn am2-btn-primary';\n             return(<button onClick={()=>{self.click(i)}} className={className}>{item}</button>)\n           })\n         }\n        </div>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: i\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    return React.createElement(\n      'div',\n      { className: 'btn-footer' },\n      React.createElement(\n        'div',\n        { className: 'am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify' },\n        data.map(function (item, i) {\n          var className = item == '\u5173\u95ED' ? 'am2-btn am2-btn-primary am2-btn-hollow' : 'am2-btn am2-btn-primary';\n          return React.createElement(\n            'button',\n            { onClick: function onClick() {\n                self.click(i);\n              }, className: className },\n            item\n          );\n        })\n      )\n    );\n  }\n});";
    },
    getData_control14_wIZuXI: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('.lui_widget_btn').each(function () {
        data.push($(this).text().trim());
      });return data;
    },
    doAction_uiControl17_xyC4P2: function (data, elem) {
      if (data.eventType === 'click') {
        var d = data.dataCustom;console.log(d);$(elem).find('.lui_widget_btn').eq(d).click();
      }
    },
    getTemplate_uiControl17_xyC4P2: function () {
      var selfTemplate = "module.exports = React.createClass({\n  click:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'click',\n        data:i\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div className='btn-footer'>\n       <div className=\"am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify\">\n        {\n           data.map((item,i)=>{\n             var className = item=='\u5173\u95ED'? 'am2-btn am2-btn-primary am2-btn-hollow':'am2-btn am2-btn-primary';\n             return(<button onClick={()=>{self.click(i)}} className={className}>{item}</button>)\n           })\n         }\n        </div>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: i\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement('span', null);\n    }\n    return React.createElement(\n      'div',\n      { className: 'btn-footer' },\n      React.createElement(\n        'div',\n        { className: 'am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify' },\n        data.map(function (item, i) {\n          var className = item == '\u5173\u95ED' ? 'am2-btn am2-btn-primary am2-btn-hollow' : 'am2-btn am2-btn-primary';\n          return React.createElement(\n            'button',\n            { onClick: function onClick() {\n                self.click(i);\n              }, className: className },\n            item\n          );\n        })\n      )\n    );\n  }\n});";
    },
    getData_control21_7fIA9A: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('.lui_widget_btn').each(function () {
        data.push($(this).text().trim());
      });return data;
    },
    doAction_uiControl18_cOWCCM: function (data, elem) {
      if (data.eventType === 'click') {
        var d = data.dataCustom;console.log(d);$(elem).children('.lui_widget_btn').eq(d).click();
      }
    },
    getTemplate_uiControl18_cOWCCM: function () {
      var selfTemplate = "module.exports = React.createClass({\n  click:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'click',\n        data:i\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    return (\n      <div className='btn-footer'>\n       <div className=\"am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify\">\n        {\n           data.map((item,i)=>{\n             var className = item=='\u53D6\u6D88'? 'am2-btn am2-btn-primary am2-btn-hollow':'am2-btn am2-btn-primary';\n             return(<button onClick={()=>{self.click(i)}} className={className}>{item}</button>)\n           })\n         }\n        </div>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  click: function click(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click',\n        data: i\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    return React.createElement(\n      'div',\n      { className: 'btn-footer' },\n      React.createElement(\n        'div',\n        { className: 'am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify' },\n        data.map(function (item, i) {\n          var className = item == '\u53D6\u6D88' ? 'am2-btn am2-btn-primary am2-btn-hollow' : 'am2-btn am2-btn-primary';\n          return React.createElement(\n            'button',\n            { onClick: function onClick() {\n                self.click(i);\n              }, className: className },\n            item\n          );\n        })\n      )\n    );\n  }\n});";
    }
  });
})(window, ysp);