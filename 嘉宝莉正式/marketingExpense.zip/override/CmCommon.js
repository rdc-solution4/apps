window.setStoreTypeSelect = function(cmBaseBrandId,obj,objId){
	var parameter = {
		cmBaseBrandId : cmBaseBrandId
	}
	$.ajax({
		   type: 'POST',
		   async : false,
		   url: Com_Parameter.ContextPath + 'cm/core/cm_core_info/cmCoreInfo.do?method=findStoreTypeByBrand&timeStame='+new Date().getTime(),//添加时间戳
		   data: parameter,   
		   success: function(rtnStr){
			   var rtnObj = eval("(" + rtnStr + ")");
			   var rtnArray = rtnObj.cmStoreTypes;
			   $("#"+objId).empty();
			   $("#"+objId).append("<option value=''>==请选择==</option>");
			   if(rtnArray!=null && rtnArray.length > 0){
				   for(var i =0;i<rtnArray.length;i++){
					   var eachObj = rtnArray[i];
					   $("#"+objId).append("<option value='"+eachObj.fdId+"'>"+eachObj.fdName+"</option>");
				   }
				   var method = "${cmStorefrontRunstoreForm.method_GET}";
				   if(method == 'edit'){
					   $("#"+objId).val("${cmStorefrontRunstoreForm.cmStorefrontStoreTypeId}");
				   }
			   }
		   },
		   error : function(){
			   alert("error");
		   }
	});
}


//根据业务公司获取业务部门
function companyChanged(companyId,deptId){
	var cmBaseCompanyId = $("#"+companyId+" option:selected").val();
	//alert("cmBaseCompanyId:"+cmBaseCompanyId);
	$("#"+deptId).empty();
	$("#"+deptId).append("<option value=''>==请选择==</option>");
	parameter = {
		cmBaseCompanyId : cmBaseCompanyId
	};
	$.ajax({
		   type: 'POST',
		   async : false,
		   url: Com_Parameter.ContextPath + 'cm/core/cm_core_info/cmCoreInfo.do?method=getCmBaseCompanyByDept&timeStame='+new Date().getTime(),//添加时间戳
		   data: parameter,   
		   success: function(jsonStr){
			   var rtnArray = eval("(" + jsonStr + ")");
			   if(rtnArray && rtnArray.length > 0){
				   for(var i=0;i<rtnArray.length;i++){
					   $("#"+deptId).append("<option value='"+rtnArray[i].fdId+"'>"+rtnArray[i].fdName+"</option>");
				   }
			   }
		   }
	});
}

//格式化日期
function dateFormat (date,fmt) { //author: meizz 
    var o = {
        "M+": date.getMonth() + 1, //月份 
        "d+": date.getDate(), //日 
        "h+": date.getHours(), //小时 
        "m+": date.getMinutes(), //分 
        "s+": date.getSeconds(), //秒 
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度 
        "S": date.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}

//格式化金额
function moneyFormat(s, n){ 
	n = n > 0 && n <= 20 ? n : 2; 
	s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + ""; 
	var l = s.split(".")[0].split("").reverse();
	var r = s.split(".")[1]; 
	var t = ""; 
	for(var i = 0; i < l.length; i ++ ) { 
		t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : ""); 
	} 
	return t.split("").reverse().join("") + "." + r; 
}

//判断是否为空值
function isNull(variable){
	if(typeof(variable) == "undefined" 
		|| variable == null 
		|| trim(variable) == ""){
		return true;
	}else{
		return false;
	}
}

//判断是否不为空值
function isNotNull(variable){
	return !isNull(variable);
}

function trim(variable){
	return variable.replace(/(^\s*)|(\s*$)/g, ""); 
}

function changeURLArg(url,arg,arg_val){
	var pattern=arg+'=([^&]*)'; 
    var replaceText=arg+'='+arg_val; 
    if(url.match(pattern)){ 
        var tmp='/('+ arg+'=)([^&]*)/gi'; 
        tmp=url.replace(eval(tmp),replaceText); 
        return tmp; 
    }else{ 
        if(url.match('[\?]')){ 
            return url+'&'+replaceText; 
        }else{ 
            return url+'?'+replaceText; 
        } 
    } 
    return url+'\n'+arg+'\n'+arg_val; 
}
