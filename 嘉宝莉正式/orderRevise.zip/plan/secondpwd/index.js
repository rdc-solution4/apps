(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control48_usEOil: function (elem) {},
    doAction_uiControl52_3d29Dp: function (data, elem) {},
    getTemplate_uiControl52_3d29Dp: function () {
      var selfTemplate = "import { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  render: function() {\n    return (\n      <header className=\"am2-navbar am2-navbar-primary\">\n        <h2 className=\"am2-navbar-title am2-navbar-center\">\u4E8C\u7EA7\u5BC6\u7801</h2>\n        <div className=\"am2-navbar-nav am2-navbar-left\">\n          <a onClick={back} className=\"am2-navbar-nav-item\"><span className=\"am2-icon am2-icon-left-nav am2-navbar-icon am2-navbar-icon-sibling-of-title\"></span><span className=\"am2-navbar-nav-title\">\u8FD4\u56DE</span></a>\n        </div>\n         \n      </header>\n    )\n    \n  }\n});";
      return "\"use strict\";\n\nvar _appRenderer = require(\"appRenderer\");\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"header\",\n      { className: \"am2-navbar am2-navbar-primary\" },\n      React.createElement(\n        \"h2\",\n        { className: \"am2-navbar-title am2-navbar-center\" },\n        \"\\u4E8C\\u7EA7\\u5BC6\\u7801\"\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"am2-navbar-nav am2-navbar-left\" },\n        React.createElement(\n          \"a\",\n          { onClick: _appRenderer.back, className: \"am2-navbar-nav-item\" },\n          React.createElement(\"span\", { className: \"am2-icon am2-icon-left-nav am2-navbar-icon am2-navbar-icon-sibling-of-title\" }),\n          React.createElement(\n            \"span\",\n            { className: \"am2-navbar-nav-title\" },\n            \"\\u8FD4\\u56DE\"\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control49_IwENi1: function (elem) {
      if (elem) {
        var data;var $table = $(elem).find('table.tb_normal').eq(0);data = $table.find('input[name="entPwd"]').val();return data;
      }return;
    },
    doAction_uiControl53_0DsqwB: function (data, elem) {
      var type = data.eventType;switch (type) {case "pwd":
          $(elem).find('table.tb_normal').eq(0).find('input[name="entPwd"]').val(data.dataCustom);break;}
    },
    getTemplate_uiControl53_0DsqwB: function () {
      var selfTemplate = "module.exports = React.createClass({\n  getInitialState:function(){\n    var data = this.props.customData;\n    return {\n      pwd:data\n    }\n  },\n  pwd:function(e){\n    var callback = this.props.customHandler\n    var value = e.target.value;\n    this.setState({\n      pwd:value\n    })\n    if(callback){\n      callback({\n        eventType:\"pwd\",\n        data:value\n      })\n    }\n  },\n  render: function() {\n    var _this = this;\n    var data = this.props.customData;\n    if(!this.state.pwd){\n      this.state.pwd = data\n    }\n    return (\n      <div className=\"secondpwd-container\">\n        \u8BF7\u8F93\u5165\u4E8C\u7EA7\u5BC6\u7801\uFF1A\n        <input type=\"text\" value={_this.state.pwd} onChange={_this.pwd}/>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  getInitialState: function getInitialState() {\n    var data = this.props.customData;\n    return {\n      pwd: data\n    };\n  },\n  pwd: function pwd(e) {\n    var callback = this.props.customHandler;\n    var value = e.target.value;\n    this.setState({\n      pwd: value\n    });\n    if (callback) {\n      callback({\n        eventType: \"pwd\",\n        data: value\n      });\n    }\n  },\n  render: function render() {\n    var _this = this;\n    var data = this.props.customData;\n    if (!this.state.pwd) {\n      this.state.pwd = data;\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"secondpwd-container\" },\n      \"\\u8BF7\\u8F93\\u5165\\u4E8C\\u7EA7\\u5BC6\\u7801\\uFF1A\",\n      React.createElement(\"input\", { type: \"text\", value: _this.state.pwd, onChange: _this.pwd })\n    );\n  }\n});";
    },
    getData_control50_tRmZ2K: function (elem) {
      if (elem) {
        var bts = $(elem).find('a[title]');var data = [];bts.each(function (i, btn) {
          data.push($(btn).text());
        });return data;
      }return;
    },
    doAction_uiControl54_IkMJT9: function (data, elem) {
      var type = data.eventType;switch (type) {case "click":
          $(elem).find('a[title]').eq(data.customData).click();break;}
    },
    getTemplate_uiControl54_IkMJT9: function () {
      var selfTemplate = "module.exports = React.createClass({\n  click:function(index){\n    debugger;\n    var callback = this.props.customHandler;\n    if(callback){\n      callback({\n        eventType:\"click\",\n        data:index\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    return (\n      <div className=\"foot-btn\">\n        {\n          data && data.map((btn,btni)=>{\n            return <button onClick={()=>{_this.click(btni)}}>{btn}</button>\n          })\n        }\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  click: function click(index) {\n    debugger;\n    var callback = this.props.customHandler;\n    if (callback) {\n      callback({\n        eventType: \"click\",\n        data: index\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    return React.createElement(\n      \"div\",\n      { className: \"foot-btn\" },\n      data && data.map(function (btn, btni) {\n        return React.createElement(\n          \"button\",\n          { onClick: function onClick() {\n              _this.click(btni);\n            } },\n          btn\n        );\n      })\n    );\n  }\n});";
    }
  });
})(window, ysp);