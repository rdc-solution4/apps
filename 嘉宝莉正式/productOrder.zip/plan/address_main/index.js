(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control28_ZuIfd0: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).children('li').each(function () {
        var actived = $(this).hasClass('active');data.push({ text: $(this).text(), actived: actived });
      });return data;
    },
    doAction_uiControl36_LWM5cq: function (data, elem) {
      if (data.eventType === 'click') {
        var d = data.dataCustom;console.log(d);
        $(elem).children('li').eq(d).click(); //1
      }
    },
    getTemplate_uiControl36_LWM5cq: function () {
      var selfTemplate = 'const Tabs = AMUI2.Tabs\nmodule.exports = React.createClass({\n  handleAction(key) {\n    var handler = this.props.customHandler;\n    this.setState({\n      activeTab: key\n    });\n    if(handler){\n      handler({\n        eventType:\'click\',\n        data:key\n      })\n    }\n  },\n \n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      return (<span></span>)\n    }\n    var activeTab = 0;\n    data.map((item,i)=>{\n      if(item.actived){\n        activeTab = i;\n      }\n    });\n    return (\n      <Tabs\n        className=\'list-tab\'\n        activeKey={activeTab}\n        onAction={this.handleAction}\n        >\n          {data.map((ablum, i) => {\n            return (\n              <Tabs.Item\n                actived={ablum.actived}\n                title={ablum.text}\n                key={i}\n              >\n               \n              </Tabs.Item>\n            )\n          })}\n        </Tabs>\n    )\n  }\n});';
      return '\'use strict\';\n\nvar Tabs = AMUI2.Tabs;\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n  handleAction: function handleAction(key) {\n    var handler = this.props.customHandler;\n    this.setState({\n      activeTab: key\n    });\n    if (handler) {\n      handler({\n        eventType: \'click\',\n        data: key\n      });\n    }\n  },\n\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\'span\', null);\n    }\n    var activeTab = 0;\n    data.map(function (item, i) {\n      if (item.actived) {\n        activeTab = i;\n      }\n    });\n    return React.createElement(\n      Tabs,\n      {\n        className: \'list-tab\',\n        activeKey: activeTab,\n        onAction: this.handleAction\n      },\n      data.map(function (ablum, i) {\n        return React.createElement(Tabs.Item, {\n          actived: ablum.actived,\n          title: ablum.text,\n          key: i\n        });\n      })\n    );\n  }\n});';
    },

    getData_control30_JvAc9G: function (elem) {
      return elem.textContent.trim();
    },
    doAction_uiControl38_XWDyxy: function (data, elem) {
      $(elem).find('[data-lui-mark="dialog.nav.close"]').click();
    },
    getTemplate_uiControl38_XWDyxy: function () {
      var selfTemplate = 'import { back } from \'appRenderer\';\nmodule.exports = React.createClass({\n  click:function(){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\'close\',\n        data:\'\'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.customData ||\'\u4EA7\u54C1\u8BA2\u5355\u7533\u8BF7\';\n    return (\n      <header className="am2-navbar am2-navbar-primary">\n        <h2 className="am2-navbar-title am2-navbar-center">{data}</h2>\n        <div className="am2-navbar-nav am2-navbar-left">\n          <a onClick={this.click} className="am2-navbar-nav-item"><span className="am2-icon am2-icon-left-nav am2-navbar-icon am2-navbar-icon-sibling-of-title"></span><span className="am2-navbar-nav-title">\u8FD4\u56DE</span></a>\n        </div>\n        \n      </header>\n    )\n  }\n});';
      return '\'use strict\';\n\nvar _appRenderer = require(\'appRenderer\');\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  click: function click() {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'close\',\n        data: \'\'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData || \'\u4EA7\u54C1\u8BA2\u5355\u7533\u8BF7\';\n    return React.createElement(\n      \'header\',\n      { className: \'am2-navbar am2-navbar-primary\' },\n      React.createElement(\n        \'h2\',\n        { className: \'am2-navbar-title am2-navbar-center\' },\n        data\n      ),\n      React.createElement(\n        \'div\',\n        { className: \'am2-navbar-nav am2-navbar-left\' },\n        React.createElement(\n          \'a\',\n          { onClick: this.click, className: \'am2-navbar-nav-item\' },\n          React.createElement(\'span\', { className: \'am2-icon am2-icon-left-nav am2-navbar-icon am2-navbar-icon-sibling-of-title\' }),\n          React.createElement(\n            \'span\',\n            { className: \'am2-navbar-nav-title\' },\n            \'\\u8FD4\\u56DE\'\n          )\n        )\n      )\n    );\n  }\n});';
    },

    getData_control42_SQy5hZ: function (elem) {
      if (!elem) {
        return;
      }var data = [];var $li = $(elem).children('li');$li.each(function (i, li) {
        var name = $(this).find('.name').text();var dep = $(this).find('.dep').text();var $radiobox = $(this).find('[data-lui-selectid]');var selected = $radiobox.hasClass('selected');var imgSrc = $(this).find('img')[0].src;var selectid = $(this).attr('data-lui-selectid');data.push({ index: i, selectid: selectid, name: name, dep: dep, imgSrc: imgSrc, selected: selected });
      });return data;
    },
    doAction_uiControl53_bZa0HB: function (data, elem) {
      var d = data.dataCustom;debugger;if (data.eventType === 'click') {
        $(elem).find('[data-lui-selectid="' + d.selectid + '"]').find('.lui-address-selectedbox-del').click();
      }
    },
    getTemplate_uiControl53_bZa0HB: function () {
      var selfTemplate = 'module.exports = React.createClass({\n   click:function(data){\n    var handler= this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\'click\',\n        data:data\n      });\n    }\n  },\n  render: function() {\n    var self =this;\n    var data = this.props.customData || [];\n    return (\n      <div className=\'am2-badge-group address-selected-list\'>\n      {data.map((item,i)=>{\n          return(<span className=\'am2-badge am2-badge-primary\'>{item.name}<span onClick={()=>{self.click(item)}} className=\'icon icon-close\'></span></span>)\n        })}\n      </div>\n    )\n  }\n});';
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  click: function click(data) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'click\',\n        data: data\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData || [];\n    return React.createElement(\n      \'div\',\n      { className: \'am2-badge-group address-selected-list\' },\n      data.map(function (item, i) {\n        return React.createElement(\n          \'span\',\n          { className: \'am2-badge am2-badge-primary\' },\n          item.name,\n          React.createElement(\'span\', { onClick: function onClick() {\n              self.click(item);\n            }, className: \'icon icon-close\' })\n        );\n      })\n    );\n  }\n});';
    },
    getData_control47_vPyuwC: function (elem) {
      if (!elem) {
        return;
      } // return elem.className
      var data = {};var $selectPanel = $(elem).children('.lui-address-select-panel');$selectPanel.each(function () {
        var luiMark = $(this).attr('data-lui-panelid');var $component = $(this).children('.lui-component');var isHidden = true;if ($component && $component.length) {
          isHidden = $(this).children('.lui-component')[0].style.display == 'none';
        }if (!isHidden && luiMark == 'address.tabs.recent') {
          data.select = initRecentData($component);
        } else if (!isHidden && luiMark == 'address.tabs.org') {
          data.tree = initGroupData($component.find('.innerbar.lui-component')[0]);data.select = initRecentData($(this).find('.lui-address-panel-right')[0]);
        } else if (!isHidden && luiMark == 'address.tabs.group') {
          data.tree = initGroupData($component.find('.innerbar.lui-component')[0]);data.select = initRecentData($(this).find('.lui-address-panel-right')[0]);
        } else if (!isHidden && luiMark == 'address.tabs.search') {
          data.select = initRecentData($(this).find('.lui-address-search-list')[0]);
        }
      });function initRecentData(elem) {
        var data = [];var $li = $(elem).find('.lui-address-panel-selectlist').children('li');var multiple = $li.eq(0).hasClass('selectAll');$li.each(function (i, li) {
          if (multiple && i == 0) {
            return;
          }if ($(this).hasClass('noData')) {
            return;
          }var name = $(this).find('.name').text();var dep = $(this).find('.dep').text();var $radiobox = $(this).find('[data-lui-selectid]');var selected = $radiobox.hasClass('selected');var imgSrc = $(this).find('img')[0] ? $(this).find('img')[0].src : '';var value = $radiobox.attr('data-lui-selectid');data.push({ index: i, selectid: value, name: name, dep: dep, imgSrc: imgSrc, selected: selected });
        });return { type: 'recent', data: data, multiple: multiple };
      }function initGroupData(elem) {
        var data = [];$(elem).children('table').each(function (i) {
          var $tds = $(this).find('tbody>tr>td');var $imgs = $tds.eq(0).find('img');var text = $tds.eq(1).text();var item = { index: i, tableId: $(this).attr('id'), text: text, imgs: $imgs.length };$imgs.each(function () {
            var imgSrc = this.src;if (imgSrc.indexOf('nodeminus') != -1 || imgSrc.indexOf('openfolder') != -1) {
              item.nodeminus = true;
            }if (imgSrc.indexOf('nodeplus') != -1 || imgSrc.indexOf('closedfolder') != -1) {
              item.nodeplus = true;
            }
          });data.push(item);
        });return data;
      }return data;
    },
    doAction_uiControl58_ErVeKI: function (data, elem) {
      var d = data.dataCustom;debugger;var $table = $(elem).find('table[id="' + d.tableId + '"]');if (data.eventType === 'expendNode') {
        $table.find('td').eq(0).find('a').click();console.log(d); //1
      }if (data.eventType === 'treeClick') {
        $table.find('td').eq(1).find('a').click();console.log(d); //1
      }if (data.eventType === 'select') {
        debugger;var $li = $(elem).find('[data-lui-selectid="' + d.selectid + '"]').parent('li');var d = data.dataCustom;$li.click();
      }
    },
    getTemplate_uiControl58_ErVeKI: function () {
      var selfTemplate = "module.exports = React.createClass({\n  expendNode:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'expendNode',\n        data:i\n      })\n    }\n  },\n treeClick:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'treeClick',\n        data:i\n      })\n    }\n  },\n  select:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'select',\n        data:i\n      })\n    }\n  },\n  renderTree:function(data){\n    var self =this;\n    return (\n      <div className='address-tree'>\n        {data.map((item,i)=>{\n          var pLeft = (item.imgs) *10 + 'px';\n          var defalutStyle = {'text-align':'left','padding-left':pLeft};\n          \n          return (<div item={pLeft} style={defalutStyle}>\n              {item.nodeplus ? <span onClick={()=>{self.expendNode(item)}} className='am2-tree-switcher am2-tree-noline_close'></span> : ''}\n              {item.nodeminus ? <span onClick={()=>{self.expendNode(item)}} className='am2-tree-switcher am2-tree-noline_open'></span> : ''}\n              {!item.nodeminus && !item.nodeplus ? <span className='am2-tree-switcher'></span> : ''}\n              <span onClick={()=>{self.treeClick(item)}}>{item.text}</span>\n            </div>);\n        })}\n      </div>\n    )\n  },\n  renderSelectList:function(data){\n    \tvar self =this;\n    return (<ul className=\"am2-list address-list\">{\n           data.data.map((item,i)=>{\n             return(<li onClick={()=>{self.select(item)}} className=\"am2-item am2-item-content\"><label className=\"am2-switch am2-select-item-switch\"><input type=\"checkbox\" checked={item.selected} value=\"on\" />\n                 {data.multiple ?  <span className=\"am2-switch-checkbox\"></span> :  <span className=\"am2-switch-radio\"></span>}\n                \n                 </label><div className=\"am2-item-media\"><img width=\"48\" src={item.imgSrc} /></div><div className=\"am2-item-main\"><div class=\"am2-item-title-row\"><h3 className=\"am2-item-title\">{item.name}</h3><div className=\"am2-item-after am2-item-desc\">{item.dep}</div></div></div></li>)\n           })\n         }</ul>)\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div>\n        {data.tree ? self.renderTree(data.tree) : ''}\n        {data.select ? self.renderSelectList(data.select) : ''}\n      </div>\n      \n    )\n  }\n});";
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  expendNode: function expendNode(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'expendNode\',\n        data: i\n      });\n    }\n  },\n  treeClick: function treeClick(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'treeClick\',\n        data: i\n      });\n    }\n  },\n  select: function select(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'select\',\n        data: i\n      });\n    }\n  },\n  renderTree: function renderTree(data) {\n    var self = this;\n    return React.createElement(\n      \'div\',\n      { className: \'address-tree\' },\n      data.map(function (item, i) {\n        var pLeft = item.imgs * 10 + \'px\';\n        var defalutStyle = { \'text-align\': \'left\', \'padding-left\': pLeft };\n\n        return React.createElement(\n          \'div\',\n          { item: pLeft, style: defalutStyle },\n          item.nodeplus ? React.createElement(\'span\', { onClick: function onClick() {\n              self.expendNode(item);\n            }, className: \'am2-tree-switcher am2-tree-noline_close\' }) : \'\',\n          item.nodeminus ? React.createElement(\'span\', { onClick: function onClick() {\n              self.expendNode(item);\n            }, className: \'am2-tree-switcher am2-tree-noline_open\' }) : \'\',\n          !item.nodeminus && !item.nodeplus ? React.createElement(\'span\', { className: \'am2-tree-switcher\' }) : \'\',\n          React.createElement(\n            \'span\',\n            { onClick: function onClick() {\n                self.treeClick(item);\n              } },\n            item.text\n          )\n        );\n      })\n    );\n  },\n  renderSelectList: function renderSelectList(data) {\n    var self = this;\n    return React.createElement(\n      \'ul\',\n      { className: \'am2-list address-list\' },\n      data.data.map(function (item, i) {\n        return React.createElement(\n          \'li\',\n          { onClick: function onClick() {\n              self.select(item);\n            }, className: \'am2-item am2-item-content\' },\n          React.createElement(\n            \'label\',\n            { className: \'am2-switch am2-select-item-switch\' },\n            React.createElement(\'input\', { type: \'checkbox\', checked: item.selected, value: \'on\' }),\n            data.multiple ? React.createElement(\'span\', { className: \'am2-switch-checkbox\' }) : React.createElement(\'span\', { className: \'am2-switch-radio\' })\n          ),\n          React.createElement(\n            \'div\',\n            { className: \'am2-item-media\' },\n            React.createElement(\'img\', { width: \'48\', src: item.imgSrc })\n          ),\n          React.createElement(\n            \'div\',\n            { className: \'am2-item-main\' },\n            React.createElement(\n              \'div\',\n              { \'class\': \'am2-item-title-row\' },\n              React.createElement(\n                \'h3\',\n                { className: \'am2-item-title\' },\n                item.name\n              ),\n              React.createElement(\n                \'div\',\n                { className: \'am2-item-after am2-item-desc\' },\n                item.dep\n              )\n            )\n          )\n        );\n      })\n    );\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\'span\', null);\n    }\n    return React.createElement(\n      \'div\',\n      null,\n      data.tree ? self.renderTree(data.tree) : \'\',\n      data.select ? self.renderSelectList(data.select) : \'\'\n    );\n  }\n});';
    },
    getData_control24_EgK2th: function (elem) {
      if (!elem) {
        return;
      }var data = { input: [], checkbox: [] };$(elem).find('input').each(function () {
        data.input.push({ value: this.value, name: this.name, placeholder: this.placeholder });
      });$(elem).find('.lui-address-searchbar-ul li').each(function (i, li) {
        var text = $(this).find('.txt').text().trim();var checked = $(this).find('.checkbox').hasClass('checked');data.checkbox.push({ text: text, checked: checked });
      });return data;
    },
    doAction_uiControl30_uQJQRw: function (data, elem) {
      var d = data.dataCustom;debugger;if (data.eventType === 'onValueChange') {
        $(elem).find('.lui-address-searchbar-ul li').eq(d).click();
      }if (data.eventType === 'click') {
        $(elem).find('.lui_widget_btn_txt').click();
      }if (data.eventType === 'inputValueChange') {
        $(elem).find('input').val(d);
      }
    },
    getTemplate_uiControl30_uQJQRw: function () {
      var selfTemplate = 'const Field = AMUI2.Field;\nconst Icon = AMUI2.Icon;\nconst Button = AMUI2.Button;\nconst Choose = AMUI2.Choose;\nmodule.exports = React.createClass({\n  onValueChange:function(data){\n    var handler= this.props.customHandler;\n    debugger\n    if(handler){\n      handler({\n        eventType:\'onValueChange\',\n        data:data\n      });\n    }\n  },\n  click:function(){\n    var handler= this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\'click\',\n        data:\' lui_widget_btn_txt\'\n      });\n    }\n  },\n  inputValueChange:function(e){\n    var handler= this.props.customHandler;\n    var value = e.target.value;\n    if(handler){\n      handler({\n        eventType:\'inputValueChange\',\n        data:value\n      });\n    }\n  },\n  render: function() {\n    var self= this;\n    var data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    var input = data.input[0];\n    return (\n      <div style={{background:"#f2f2f2",padding: "5px 2px"}}>\n         <Field\n            onChange={(e)=>{self.inputValueChange(e)}}\n            defaultValue={input.value}\n            placeholder={input.placeholder}\n            labelBefore={<Icon name="search" />}\n            btnAfter={<Button onClick={self.click} amStyle="primary">\u641C\u7D22</Button>}\n          />\n        <div style={{"text-align":"center","margin-top":"10px"}}>\n        <Choose>\n            {\n              data.checkbox.map((item,i)=>{\n                return (<Choose.Item onClick={()=>{self.onValueChange(i)}} value={i} defaultSelected={item.checked}> {item.text}</Choose.Item>)\n              })\n            }\n          </Choose>\n        </div>\n      </div>\n    )\n  }\n});';
      return '\'use strict\';\n\nvar Field = AMUI2.Field;\nvar Icon = AMUI2.Icon;\nvar Button = AMUI2.Button;\nvar Choose = AMUI2.Choose;\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  onValueChange: function onValueChange(data) {\n    var handler = this.props.customHandler;\n    debugger;\n    if (handler) {\n      handler({\n        eventType: \'onValueChange\',\n        data: data\n      });\n    }\n  },\n  click: function click() {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'click\',\n        data: \' lui_widget_btn_txt\'\n      });\n    }\n  },\n  inputValueChange: function inputValueChange(e) {\n    var handler = this.props.customHandler;\n    var value = e.target.value;\n    if (handler) {\n      handler({\n        eventType: \'inputValueChange\',\n        data: value\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\'span\', null);\n    }\n    var input = data.input[0];\n    return React.createElement(\n      \'div\',\n      { style: { background: "#f2f2f2", padding: "5px 2px" } },\n      React.createElement(Field, {\n        onChange: function onChange(e) {\n          self.inputValueChange(e);\n        },\n        defaultValue: input.value,\n        placeholder: input.placeholder,\n        labelBefore: React.createElement(Icon, { name: \'search\' }),\n        btnAfter: React.createElement(\n          Button,\n          { onClick: self.click, amStyle: \'primary\' },\n          \'\\u641C\\u7D22\'\n        )\n      }),\n      React.createElement(\n        \'div\',\n        { style: { "text-align": "center", "margin-top": "10px" } },\n        React.createElement(\n          Choose,\n          null,\n          data.checkbox.map(function (item, i) {\n            return React.createElement(\n              Choose.Item,\n              { onClick: function onClick() {\n                  self.onValueChange(i);\n                }, value: i, defaultSelected: item.checked },\n              \' \',\n              item.text\n            );\n          })\n        )\n      )\n    );\n  }\n});';
    }
  });
})(window, ysp);