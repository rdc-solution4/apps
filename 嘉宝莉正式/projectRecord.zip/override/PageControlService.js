function PageControlService(){
	//普通异常处理
	this.commonErrorHandler = function(errMsg){
		seajs.use([ 'lui/dialog' ], function(dialog) {
			dialog.alert(errMsg);
		});
		return false;
	}
	//ajax异常处理
	this.ajaxErrorHandler = function(msg){
		alert("获取数据过程中出现异常！");
	}
}

PageControlService.prototype = {
	construtctor : PageControlService,
	
	//获取统一代号类型select的值
	getSelectValueById : function(selectId){
		var selectTypeObj = $("#"+selectId+" option:selected");
		var selectTypeValue = "";
		if(selectTypeObj!=null){
			selectTypeValue = $(selectTypeObj).val()
		}
		return selectTypeValue;
	},
	//获取下拉框的值
	getSelectValueByName : function(propertyName){
		var selectObj = $("select[name='"+propertyName+"'] option:selected");
		var selectValue = "";
		if(selectObj != null){
			selectValue = $(selectObj).val();
			return selectValue;
		}
	},
	//ajax 调用后台action
	ajaxCall : function(url,param,callBack){
		$.ajax({
		   type: 'POST',
		   async : false,
		   url: url,//含有时间戳
		   data: param,   
		   success: callBack,
		   error : this.ajaxErrorHandler
		});
	},
	//弹出提示
	divAlter : function(msg){
		seajs.use([ 'lui/dialog' ], function(dialog) {
			dialog.alert(msg);
		})
	},
	//根据属性名和下拉框内容设置下拉框的内容
	setSelectDatas : function(propertyName,datas){
		var selectObj = $("select[name='"+propertyName+"']");
		$(selectObj).empty();
		$(selectObj).append("<option value=''>==请选择==</option>");
		if(datas != null && datas.length > 0){
			for(var i = 0;i < datas.length; i++){
				$(selectObj).append("<option value='"+datas[i].value+"'>"+datas[i].text+"</option>");
			}
		}
	},
	
	setSelectDataByIds : function(propertyName,datas){
		var selectObj = $("select[name='"+propertyName+"']");
		$(selectObj).empty();
		$(selectObj).append("<option value=''>==请选择==</option>");
		if(datas != null && datas.length > 0){
			for(var i = 0;i < datas.length; i++){
				$(selectObj).append("<option value='"+datas[i].fdId+"'>"+datas[i].fdName+"</option>");
			}
		}
	},
	
	//根据样式名更新下拉框
	setSelectDatasByClassName : function(className,datas){
		$("."+className).each(function(){
			$(this).empty();
			$(this).append("<option value=''>==请选择==</option>");
			if(datas!=null && datas.length > 0){
				for(var i =0;i<datas.length;i++){
					$(this).append("<option value='"+datas[i].value+"'>"+datas[i].text+"</option>");
				}
			}
		})
	}
	
}