(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control7_sVkwLy: function (elem) {
      if (!elem) {
        return;
      }var select = { data: [] };var $select = $(elem).find('select[name="F_OptionList"]');var $selectedList = $(elem).find('select[name="F_SelectedList"]');select.name = $select.attr('name');select.multiple = $select[0].multiple;$select.find('option').each(function (i, option) {
        var value = this.value;var selected = $selectedList.find('option[value="' + value + '"]').length > 0;select.data.push({ text: this.textContent, value: value, selected: selected });
      });return select;
    },
    doAction_uiControl25_fpprWL: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'select') {
        debugger;var $select = $(elem).find('select[name="F_OptionList"]');var $selectedList = $(elem).find('select[name="F_SelectedList"]');if (!d.selected) {
          $select.find('option[value="' + d.value + '"]')[0].selected = true;$(elem).find('#btnAdd').click();
        } else {
          $selectedList.find('option[value="' + d.value + '"]')[0].selected = true;$(elem).find('#btnDelete').click();$select.find('option[value="' + d.value + '"]')[0].selected = false;
        }
      }
    },
    getTemplate_uiControl25_fpprWL: function () {
      var selfTemplate = 'module.exports = React.createClass({\n  select:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\'select\',\n        data:i\n      })\n    }\n  },\n \n  renderSelectList:function(data){\n    \tvar self =this;\n    return (<ul className="am2-list address-list">{\n           data.data.map((item,i)=>{\n             return(<li onClick={()=>{self.select(item)}} className="am2-item am2-item-content"><label className="am2-switch am2-select-item-switch"><input type="checkbox" checked={item.selected} value="on" />\n                 {data.multiple ?  <span className="am2-switch-checkbox"></span> :  <span className="am2-switch-radio"></span>}\n                \n                 </label><div className="am2-item-main"><div class="am2-item-title-row"><h3 className="am2-item-title">{item.text}</h3><div className="am2-item-after am2-item-desc">{item.dep}</div></div></div></li>)\n           })\n         }</ul>)\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div>\n        {data ? self.renderSelectList(data) : \'\'}\n      </div>\n      \n    )\n  }\n});';
      return '"use strict";\n\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  select: function select(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'select\',\n        data: i\n      });\n    }\n  },\n\n  renderSelectList: function renderSelectList(data) {\n    var self = this;\n    return React.createElement(\n      "ul",\n      { className: "am2-list address-list" },\n      data.data.map(function (item, i) {\n        return React.createElement(\n          "li",\n          { onClick: function onClick() {\n              self.select(item);\n            }, className: "am2-item am2-item-content" },\n          React.createElement(\n            "label",\n            { className: "am2-switch am2-select-item-switch" },\n            React.createElement("input", { type: "checkbox", checked: item.selected, value: "on" }),\n            data.multiple ? React.createElement("span", { className: "am2-switch-checkbox" }) : React.createElement("span", { className: "am2-switch-radio" })\n          ),\n          React.createElement(\n            "div",\n            { className: "am2-item-main" },\n            React.createElement(\n              "div",\n              { "class": "am2-item-title-row" },\n              React.createElement(\n                "h3",\n                { className: "am2-item-title" },\n                item.text\n              ),\n              React.createElement(\n                "div",\n                { className: "am2-item-after am2-item-desc" },\n                item.dep\n              )\n            )\n          )\n        );\n      })\n    );\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement("span", null);\n    }\n    return React.createElement(\n      "div",\n      null,\n      data ? self.renderSelectList(data) : \'\'\n    );\n  }\n});';
    },
    getData_control22_tCCLFV: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('tr').eq(2).find('input.btndialog').each(function () {
        data.push(this.value.trim());
      });return data;
    },
    doAction_uiControl26_ifzVWt: function (data, elem) {
      if (data.eventType === 'click') {
        var d = data.dataCustom;console.log(d);debugger;$(elem).find('tr').eq(2).find('input.btndialog').eq(d).click();
      }
    },
    getTemplate_uiControl26_ifzVWt: function () {
      var selfTemplate = 'module.exports = React.createClass({\n  click:function(e,data){\n    var handler = this.props.customHandler;\n    var target = e.target;\n    \n    if(handler){\n      handler({\n        eventType:\'click\',\n        data:data\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    return (\n      <div className=\'btn-footer\'>\n       <div className="am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify">\n        {\n           data.map((item,i)=>{\n             if(item !=\'\u6682\u5B58\'){\n               var className = item==\'\u53D6\u6D88\'? \'am2-btn am2-btn-primary am2-btn-hollow\':\'am2-btn am2-btn-primary\';\n             return(<a onClick={(e)=>{self.click(e,i)}} className={className}>{item}</a>)\n             }\n            \n           })\n         }\n        </div>\n      </div>\n    )\n  }\n});';
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  click: function click(e, data) {\n    var handler = this.props.customHandler;\n    var target = e.target;\n\n    if (handler) {\n      handler({\n        eventType: \'click\',\n        data: data\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    return React.createElement(\n      \'div\',\n      { className: \'btn-footer\' },\n      React.createElement(\n        \'div\',\n        { className: \'am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify\' },\n        data.map(function (item, i) {\n          if (item != \'\u6682\u5B58\') {\n            var className = item == \'\u53D6\u6D88\' ? \'am2-btn am2-btn-primary am2-btn-hollow\' : \'am2-btn am2-btn-primary\';\n            return React.createElement(\n              \'a\',\n              { onClick: function onClick(e) {\n                  self.click(e, i);\n                }, className: className },\n              item\n            );\n          }\n        })\n      )\n    );\n  }\n});';
    }
  });
})(window, ysp);