(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control51_AN6CZ4: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find('input.btnmsg').each(function () {
        data.push($(this).val().trim());
      });return data;
    },
    doAction_uiControl54_69E7fN: function (data, elem) {
      if (data.eventType === 'click') {
        if (data.dataCustom.text == "关闭") {
          ysp.appMain.closeWindow();
        }var d = data.dataCustom.i;$(elem).find('input.btnmsg').eq(d).click();
      }
    },
    getTemplate_uiControl54_69E7fN: function () {
      var selfTemplate = 'module.exports = React.createClass({\n  click:function(i,data){\n    var handler = this.props.customHandler;\n    var _data = {\n      i:i,\n      text:data\n    }\n    if(handler){\n      handler({\n        eventType:\'click\',\n        data:_data\n      })\n    }\n  },\n  render: function() {\n    var self = this;\n    var data = this.props.customData;\n    return (\n      <div className=\'btn-footer\'>\n       <div className="am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify">\n        {\n           data.map((item,i)=>{\n             var className = item==\'\u53D6\u6D88\'? \'am2-btn am2-btn-primary am2-btn-hollow\':\'am2-btn am2-btn-primary\';\n             return(<button onClick={()=>{self.click(i,item)}} className={className}>{item}</button>)\n           })\n         }\n        </div>\n      </div>\n    )\n  }\n});';
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  click: function click(i, data) {\n    var handler = this.props.customHandler;\n    var _data = {\n      i: i,\n      text: data\n    };\n    if (handler) {\n      handler({\n        eventType: \'click\',\n        data: _data\n      });\n    }\n  },\n  render: function render() {\n    var self = this;\n    var data = this.props.customData;\n    return React.createElement(\n      \'div\',\n      { className: \'btn-footer\' },\n      React.createElement(\n        \'div\',\n        { className: \'am2-btn-group am2-btn-group-primary am2-btn-group-gapped am2-btn-group-justify\' },\n        data.map(function (item, i) {\n          var className = item == \'\u53D6\u6D88\' ? \'am2-btn am2-btn-primary am2-btn-hollow\' : \'am2-btn am2-btn-primary\';\n          return React.createElement(\n            \'button\',\n            { onClick: function onClick() {\n                self.click(i, item);\n              }, className: className },\n            item\n          );\n        })\n      )\n    );\n  }\n});';
    }
  });
})(window, ysp);