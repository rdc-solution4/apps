/**
 * Baidu Google Piwik分析加载js by l00356902
 */

var BuriedPoinStat = function() {
};

BuriedPoinStat.prototype = {
	settings : {
		baidu : {
			flag : true,// 百度统计开关 true:开启，false:关闭
			signKey : 'c2ec3eeca0fe46e5143a8bb722b65673',// 百度统计中网站签名
			URL : '//hm.baidu.com/',
		},
		google : {
			flag : true,// 谷歌统计开关 true:开启，false:关闭
			signKey : 'UA-74062948-1',// 谷歌统计中网站签名
			URL : '//www.google-analytics.com/',
		},
		piwik : {
			flag : true,// piwik统计开关 true:开启，false:关闭
			URL : '//10.171.49.254:8085/piwik/',// piwik地址
			siteId : 2
		// piwik统计中网站签名
		}
	},


	businessParams : {
		curEmployeeId : '',

	},

	pvstat : function() {
		debugger;
		var _this = this;
		var settings = _this.settings;
		var busiParams = _this.businessParams;
		if (settings.piwik.flag == 'true') {
			var piwik = new PiwikStat();
			piwik.pv(settings.piwik.URL, settings.piwik.signKey,
					busiParams.curEmployeeId);
		}
		if (settings.baidu.flag == 'true') {
			var baidu = new BaiduStat();
			baidu.pv(settings.baidu.URL, settings.baidu.signKey,
					busiParams.curEmployeeId);
		}

		if (settings.google.flag == 'true') {
			var google = new GoogleStat();
			google.pv(settings.google.URL, settings.google.signKey,
                    busiParams.curEmployeeId);
		}
	},

	/**
	 * 用户登录埋点
	 */
	loginstat : function(userId) {
		debugger;
		var _this = this;
		var settings = _this.settings;

		if (settings.piwik.flag == 'true') {
			var piwik = new PiwikStat();
			piwik.setUserId(userId);
		}
	},

	/**
	 * 创建订单
	 */
	trackEcommerceOrder : function(ecommerceItems, orderInfo) {
		debugger;
		var _this = this;
		var settings = _this.settings;
			if (settings.piwik.flag == 'true') {
			var piwik = new PiwikStat();
			piwik.trackEcommerceOrder(ecommerceItems, orderInfo);
		}
		if (settings.google.flag == 'true') {
			var google = new GoogleStat();
			google.trackEcommerceOrder(ecommerceItems, orderInfo);
		}
		
		if (settings.baidu.flag == 'true') {			
			var baidu = new BaiduStat();
			baidu.trackEcommerceOrder(ecommerceItems, orderInfo);
		}

	},
	/**
	 * 添加购物车
	 */
	addEcommerceItem:function(ecommerceItems,totalFee){
		debugger;
		var _this = this;
		var settings = _this.settings;
		if(settings.google.flag == 'true'){
			var google = new GoogleStat();
			google.addEcommerceItem(ecommerceItems);
		}
		if(settings.piwik.flag == 'true'){
			var piwik = new PiwikStat();
				piwik.addEcommerceItem(ecommerceItems,totalFee);
		}
	},
	/**
	 * 移除购物车
	 */
	removeEcommerceItem:function(ecommerceItems,totalFee){
		debugger;
		var _this = this;
		var settings = _this.settings;
		if(settings.google.flag == 'true'){
			var google = new GoogleStat();
			google.removeEcommerceItem(ecommerceItems);
		}
		if(settings.piwik.flag == 'true'){
			var piwik = new PiwikStat();
			piwik.addEcommerceItem(ecommerceItems,totalFee);
		}
	},

	

	/**
	 * 站内搜索统计
	 */
	searchstat : function(keyword, category, searchResults, searchPage) {
		debugger;
		var _this = this;
		var settings = _this.settings;

		if (settings.piwik.flag == 'true') {
			var piwik = new PiwikStat();
			piwik.trackSiteSearch(keyword, category, searchResults, searchPage);
		}
	},
	  
	/**
     * 商品详情页
     */
    setEcommerceView : function(ecommerceItem) {
        debugger;
        var _this = this;
        var settings = _this.settings;
        
        if (settings.google.flag == 'true') {
            var google = new GoogleStat();
            google.setEcommerceView(ecommerceItem);
        }

        if (settings.piwik.flag == 'true') {
            var piwik = new PiwikStat();
            piwik.setEcommerceView(ecommerceItem);
        }
    }

};

/**
 * piwik统计js封装
 */

var PiwikStat = function() {
};
var _paq = _paq || [];
PiwikStat.prototype = {

    pv : function(URL, siteId, curEmployeeId) {
        debugger;
        var _this = this;
        
        //操作员记录
        _paq.push(['setCustomVariable', 1, 'employeeId', curEmployeeId, 
                   'visit' ]);
        _paq.push([ 'trackPageView' ]);
        _paq.push([ 'enableLinkTracking' ]);
        (function() {
            debugger;
            var u = URL;
            _paq.push([ 'setTrackerUrl', u + 'piwik.php' ]);
            _paq.push([ 'setSiteId', siteId ]);
            var d = document, g = d.createElement('script'), s = d
                    .getElementsByTagName('script')[0];
            g.type = 'text/javascript';
            g.async = true;
            g.defer = true;
            g.src = u + 'piwik.js';
            s.parentNode.insertBefore(g, s);
        })();
    },
    
	/**
	 * 用户登录
	 */
	setUserId : function(userId) {
		debugger;
		window._paq.push([ 'setUserId', userId + '' ]);
		window._paq.push([ 'trackPageView' ]);
	},

	/**
	 * 搜索请求统计代码
	 * 
	 * @param keyword:关键词
	 * @param category:种类，类别，类目
	 * @param searchResults:搜索结果，0为无结果，1为有结果
	 * @param searchPage:搜索页数
	 */
	trackSiteSearch : function(keyword, category, searchResults, searchPage) {
        debugger;
        var _this = this;
        _paq.push(['setCustomVariable',2,'search_cat_id',category,'page']);
        _paq.push(['setCustomVariable',3,'search_page_no',searchPage,'page']);
        _paq.push(['trackSiteSearch',keyword,category,searchResults]);
    },
	/*
	 * 生成订单
	 */
	trackEcommerceOrder : function(ecommerceItems, orderInfo) {
		debugger;
		$(ecommerceItems).each(function() {
			// 添加购物车中当前存在的所有产品信息
			_paq.push([ 'addEcommerceItem', this.offerCode + '', // (required) SKU: Product unique identifier
			this.offerName + '', // (optional) Product name
			this.offerClassfication + '', // 最多上报5个所属的商品类别，至少上报一个商品类别
			this.productUnitPrice + '', // (recommended) Product price
			this.productQuantity + '' // (optional, default to 1) Product quantity
			]);
		});
		// 设置订单信息
		_paq.push([ 'trackEcommerceOrder', orderInfo.orderId + '', // (required) Unique Order ID
		orderInfo.grandTotal + '', // (required) Order Revenue grand total (includes tax, shipping, and subtracted discount)
		orderInfo.subTotal + '', // (optional) Order sub total (excludes shipping)
		orderInfo.tax + '', // (optional) Tax amount
		orderInfo.shipping + '', // (optional) Shipping amount
		false // (optional) Discount offered (set to false for unspecified parameter)
		]);
		// 回传统计信息
		_paq.push([ 'trackPageView' ]);
	},
	/*
	 * 添加购物车 @param ecommerceItems 购物车项集合，ecommerceItem数据结构如下：
	 * 
	 */
	addEcommerceItem : function(ecommerceItems, totalFee) {
		debugger;
		_paq.push([ 'extendDeletEcommerceItem' ]);
		$(ecommerceItems).each(
				function() {

					// 添加购物车中当前存在的所有产品信息
					_paq.push([ 'addEcommerceItem',
							this.productSKU == null ? '' : this.productSKU+'', // (required) SKU: Product unique identifier
							this.productName + '', // (optional) Product name
							this.productCategory, // 最多上报5个所属的商品类别，至少上报一个商品类别
							this.price, // (recommended) Product price
							this.quantity // (optional, default to 1)
							// Product quantity
					]);
				});

		// 在“Add to cart”按钮逻辑中添加刷新购物车信息调用
		_paq.push([ 'trackEcommerceCartUpdate', totalFee ]); // (required) Cart amount 回传统计信息
		_paq.push([ 'trackPageView' ]);
	},
	/*
	 * 移除购物车 @param ecommerceItems 购物车项集合，ecommerceItem数据结构如下： { productSKU
	 * SKU:产品唯一标识 productName 产品名称 productCategory 产品类别数组，最多五个 price 单价 quantity
	 * 数量 variant 变量，piwik不需要 brand 品牌，piwik不需要 }
	 */
	removeEcommerceItem : function(sku) {
		debugger;
		_paq.push([ 'extendDeletEcommerceItem' ]); // (required) Cart amount
		_paq.push([ 'trackPageView' ]);
	},
	
	/*
     * 商品详情
     */
   setEcommerceView : function(ecommerceItem) {
        debugger;
        var price = ecommerceItem.priceValue;
        if (price && price !=''){
            price = price.substring(1,price.length);
        }
        // 填写商品详细信息，要求填写全部商品信息，包括SKU、名称、价格和类别
        _paq.push([ 'setEcommerceView',
        ecommerceItem.offeringCode||'', // (required) SKU: Product unique identifier
        ecommerceItem.offeringName||'', // (optional) Product name
        ecommerceItem.classificationId||'', // 最多上报5个所属的商品类别，至少上报一个商品类别
        price||''  // (optional) Product Price as displayed on the page
        ]);

        _paq.push([ 'trackPageView' ]);
    }

};

/**
 * 百度统计js封装
 */
var BaiduStat = function() {
};
var _hmt = _hmt || [];
BaiduStat.prototype = {
	pv : function(URL, signkey, curEmployeeId) {
		_hmt.push([ '_setCustomVar', 1, 'employeeId', curEmployeeId ,1]);
		
		var hm = document.createElement("script");
		hm.src = URL + "hm.js" + "?" + signkey;
		var s = document.getElementsByTagName("script")[0];
		s.parentNode.insertBefore(hm, s);
	},
	/**
	 * 百度订单统计
	 */
	trackEcommerceOrder : function(ecommerceItems, orderInfo) {
		debugger;
		var orderDetail = {
			"orderId" : orderInfo.orderId,
			"orderTotal" : orderInfo.grandTotal,
			"item" : []
		};
		var lenth = ecommerceItems.length;
		for ( var i = 0; i < lenth; i++) {
			orderDetail.item.push({
				"skuId" : ecommerceItems[i].offerCode,
				"skuName" : ecommerceItems[i].offerName,
				"category" : ecommerceItems[i].offerClassfication,
				"Price" : ecommerceItems[i].productUnitPrice,
				"Quantity" : ecommerceItems[i].productQuantity
			});
		}
		
		_hmt.push(['_trackOrder', orderDetail]);
	}
	

};

/**
 * google统计js封装
 */
var GoogleStat = function() {
};
GoogleStat.prototype = {
    pv : function(URL, signkey, curEmployeeId) {
        (function(i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function() {
                (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o), m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
        })(window, document, 'script', URL + 'analytics.js', 'ga');

       
        ga('create', signkey, 'auto');
        ga('set', 'dimension1', curEmployeeId);
        ga('require', 'ec');
        ga('send', 'pageview');
    },
	
	/**
	 * ecommerceItems购物车中商品项ecommerceItem结构如下
	 */
	addEcommerceItem : function(ecommerceItems) {
		debugger;
		try{
			$(ecommerceItems).each(function() {
				// 添加当前被加入购物车，或者中购物车中被删除的商品。与Piwik不同，GA仅仅添加当前商品
				ga('ec:addProduct', {
					'id' : this.productSKU,
					'name' : this.productName,
					'category' : this.productCategory,
					'brand' : this.brand,
					'variant' : this.variant,
					'price' : this.price,
					'quantity' : this.quantity
				});
			});
			// 如果当前代码是增加购物车代码，则使用下面代码
			ga('ec:setAction', 'add');
			ga('send', 'event', 'UX', 'click', 'add to cart'); // Send data using
			// an event.
		}
		catch(error){
			console.log(error);
		}
	},
	removeEcommerceItem : function(ecommerceItems) {
		debugger;
		try{
			$(ecommerceItems).each(function() {
				// 添加当前被加入购物车，或者中购物车中被删除的商品。与Piwik不同，GA仅仅添加当前商品
				ga('ec:addProduct', {
					'id' : this.productSKU,
					'name' : this.productName,
					'category' : this.productCategory,
					'brand' : this.brand,
					'variant' : this.variant,
					'price' : this.price,
					'quantity' : this.quantity
				});
			});

			// 如果是当前代码是删除购物车代码，则使用下面代码， 与上面两行代码不可同时出现！
			ga('ec:setAction', 'remove');
			ga('send', 'event', 'UX', 'click', ' remove from cart'); // Send data
			// using an
			// event.
		}
		catch(error){
			console.log(error);
		}
		
	},
	/**
	 * orderInfo 表单信息 { orderId,// 订单号 grandTotal:,//销售额,总计 subTotal，// 小计
	 * tax:,//税 shipping：,//运送，物流 discount：,//优惠劵 affiliation:// 附属 }
	 */
	trackEcommerceOrder : function(ecommerceItems, orderInfo) {
		debugger;
		ga('require', 'ec');
		$(ecommerceItems).each(function() {
			// 添加当前被加入购物车，或者中购物车中被删除的商品。与Piwik不同，GA仅仅添加当前商品
			ga('ec:addProduct', {
				'id' : this.offerCode,
				'name' : this.offerName,
				'category' : this.offerClassfication,
				'brand' : this.brand,
				'variant' : this.variant,
				'price' : this.productUnitPrice,
				'quantity' : this.productQuantity
			});
		});
		// 添加订单信息.
		ga('ec:setAction', 'purchase', {
			'id' : orderInfo.orderId,
			'affiliation' : orderInfo.affiliation,
			'revenue' : orderInfo.grandTotal,
			'tax' : orderInfo.tax,
			'shipping' : orderInfo.shipping,
			'coupon' : orderInfo.discount
		// User added a coupon at checkout.
		});
		// 发送订单数据到服务器
		ga('send', 'pageview'); // Send transaction data with initial pageview.

	},
	
	/**
     * 商品详情页埋点
     */
    setEcommerceView : function(ecommerceItem) {
        debugger;
        var price = ecommerceItem.priceValue;
        if (price && price !=''){
            price = price.substring(1,price.length);
        }
        ga('ec:addProduct', {
            'id' : ecommerceItem.offeringCode,
            'name' : ecommerceItem.offeringName,
            'category' : ecommerceItem.classificationId,
            'price':price
        });
        // 设置动作为：查看商品详情
        ga('ec:setAction', 'detail'); // Detail action.

        ga('send', 'pageview'); // Send the product data with initial pageview.
    }
    

};

var ContexInfo = function() {
	var scope = scope || $("html").scope();
	$Fire = scope.$Get("$Fire");
	$Fire({
		service : "bes.oc.querycontextservice/querycontextinfo",
		target : "$Page.contextForBuriedPoints",
		onafter : function() {
			debugger;
			return $Page.contextForBuriedPoints.loginId;
		}
	});

};

/**
 * 页面加载完执行
 */

$(document).ready(function() {
    (function() {
        debugger;

        $Page=$(document).scope().$Page;
        
        // 如果统计已经执行，不作操作
        if (window.$BuriedPoinStat) {
            return;
        }

        var scope = scope || $("html").scope();
        $Fire = scope.$Get("$Fire");

        // 统计变量
        window.$BuriedPoinStat = new BuriedPoinStat();
        // 查询上下文登录id
        $Fire({
            service : "bes.oc.querycontextservice/querycontextinfo",
            target : "$Page.contextForBuriedPoints",
            onafter : function() {
                debugger;

                // 设置登录操作员Id
                $BuriedPoinStat.businessParams.curEmployeeId = $Page.contextForBuriedPoints.loginId;

                // 获取系统配置
                var keylist = ["OC_PiwikFlag","OC_PiwikURL","OC_PiwikPageId","OC_GoogleFlag","OC_GoogleURL","OC_GooglePageId","OC_BaiduFlag","OC_BaiduURL","OC_BaiduPageId"];
                $Fire({
                    service : 'ucec/v1/common/qrysystemparamlistbykey',
                    params : {
                        keylist : keylist
                    },
                    target : '$Page.sysParams',
                    onafter : function() {
                        debugger;
                        var settings = {
                            piwik : {
                                flag : $Page.sysParams[0],// piwik统计开关 true:开启，false:关闭
                                URL : $Page.sysParams[1],// piwik地址
                                signKey : $Page.sysParams[2],// piwik网站签名
                            },
                            google : {
                                flag : $Page.sysParams[3],// google开关 true:开启，false:关闭
                                URL : $Page.sysParams[4],
                                signKey : $Page.sysParams[5],// google统计中网站签名
                            },
                            baidu : {
                                flag : $Page.sysParams[6],// 百度统计开关 true:开启，false:关闭
                                URL : $Page.sysParams[7],
                                signKey : $Page.sysParams[8],// 百度统计中网站签名
                            }
                        };

                        //设置配置参数
                        $BuriedPoinStat.settings = settings;
                        //开始统计
                        $BuriedPoinStat.pvstat();
                    }
                });//end fire
            }//end onafter
        });//end fire

    })();
});
