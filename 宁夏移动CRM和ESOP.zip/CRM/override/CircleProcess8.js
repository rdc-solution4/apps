var UCD = UCD || {Core:jQuery};
(function(ucd, $){
	 /**
     * 圆环图
     * @param container-jQuery selector
	 * @param isLegendSur:是否环绕显示圆环图例。默认为false
	 *  内外圈比例:1:1.2
	 *  settings.r/2     为图例与圆环图间距
	 *  settings.r*0.6   圆环里文本大小的比例
     * @constructor
     */
	window.CircleProcess = function(container){
		this._settings = {
			container: $(container),
			root: $("<div class='UCDChart Circle'></div>"),
			infoLayer: $("<div class='infoLayer'></div>"),
			strokeWidth: 20,  //圆环大小
			r: 70,              //半径
			minR: 50,           //最小圆环半径
			maxR: 500,          //最大圆环半径
			fontSizeRatio:0.6,  //圆环里文本大小与r的比例
			animateTime: 1000,         //动画执行时间
			isAnimate: true,    //默认启用动画
			centerText: {color:"#1694db",fontFamily:"Century Gothic"},//圆环中心内容样式
			backColor: "#d3d3d3",    //背景颜色效果
			defaultColor: "#66CC52",  //默认颜色
			rotate: -90                  //初始角度
		};
		var settings = this._settings;
		settings.self = this;
		settings.root.addClass(window.getStyle());//设置风格
		settings.frags = $("<div class='Frags'></div>").css({"overflow":"visible"});
		settings.cord = new window.Cords(settings.root);
		_infoLayer(settings, "no data loaded.");
		settings.pi = Math.PI;
		settings.textLine = [];   //存储文本内容
		
		settings.container.empty().append(settings.root);
		settings.root.append(settings.infoLayer, settings.frags);
		if(settings.cord.isSVG()){
			settings.svg = settings.cord.createElement("svg",{version:"1.1"},settings.frags[0]);
		}else{
			settings.svg = $("<div></div>").css("position","absolute").appendTo(settings.frags)[0];
		}
		settings.gDashBoard = settings.cord.createElement("g",{"desc":"仪表盘容器"},settings.svg);
	}
	
	function _infoLayer(settings, tip) {
		settings.infoLayer.show();
		settings.infoLayer.html(tip);
	}
	function _setFragsSize(settings) {
		//如果环形显示图例
		var _ysp_top = (settings.container.height()-settings.r*2)/2 < 0 ? 10 : (settings.container.height()-settings.r*2)/2; 
		var left = (settings.container.width()-settings.r*2 - settings.r/2)/2 < 0 ? 0 : (settings.container.width()-settings.r*2 - settings.r/2)/2;
		settings.frags.css({"left":left,"_ysp_top":_ysp_top,"bottom":0,"right":0});

		settings.width = settings.r*2;	
		settings.height = settings.r*2;
		var ieH = $.browser.msie ? 4 : 0;  //兼容IE bug处理滚动条问题
		settings.cord.setAttributes(settings.svg,{"width":settings.width,"height":settings.height-ieH})
		settings.cord._settings.root.css({"z-index":3,"position":"relative","height":"auto","overflow":"visible"});
	}
	function _setData(settings,type){
		settings.angles=[];
		settings.center=[];
		
		_setR(settings);
		_setFragsSize(settings);
		if(settings.cord.isSVG()){
			_linearGradient(settings);
		}
		_savePath(settings,type);
	}
	//设置半径
	function _setR(settings){
		var dia = settings.container.width() > settings.container.height() ? settings.container.height() : settings.container.width();
		settings.r = (settings.bigCirleR && settings.bigCirleR > 0) ? settings.bigCirleR : dia/3;
		settings.r = settings.r < settings.minR ? settings.minR : settings.r;
		settings.r = settings.r > settings.maxR ? settings.maxR : settings.r;
		settings.strokeWidth = settings.smallCircleR >= 0 ? settings.r-settings.smallCircleR : settings.r*1.2-settings.r;
	}
	//颜色渐变
	function _linearGradient(settings){
		settings.linearGradientId = new Date().getTime()+(Math.random()*100000).toString();
		var linearGradient = settings.cord.createElement("linearGradient",{"id":settings.linearGradientId,"x1":"0.1","y1":1,"x2":0,"y2":0,"gradientTransform":"matrix(1,0,0,1,0,0)"},settings.svg);
		var stop1 = settings.cord.createElement("stop",{"offset":"0%","stop-color":settings.colors || settings.defaultColor},linearGradient);
		var stop2 = settings.cord.createElement("stop",{"offset":"100%","stop-color":settings.endColor || settings.defaultColor},linearGradient);
		
		if(settings.backColor.indexOf(".") != -1){
			settings.patternId = new Date().getTime()+(Math.random()*100000).toString();
			var pattern = settings.cord.createElement("pattern",{"id":settings.patternId,"width":3,"height":2,"patternUnits":"userSpaceOnUse","x":0,"y":0,"patternTransform":"matrix(1,0,0,1,0,0) translate(0,0)"},settings.svg);
			var image = settings.cord.createElement("image",{"xlink:href":settings.backColor,"width":3,"height":2,"x":0,"y":0,"style":"-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"},pattern);
		}
	}
	function _savePath(settings,type){
		rotate = settings.pi*2*(settings.rotate/360);
		settings.center[0] = ((settings.width)/2);
		settings.center[1] = settings.height/2;
		settings.angles.push(rotate);
		settings.bigAngle = settings.pi+rotate;
		var tempAngel,align = 0;
		//如果修复数据时数据跟初始数据条数不同，刚重新创建
		if(type == "modify"){
			type = "create";
			$(settings.gDashBoard).empty();	
		}
		var align = settings.value/100;
		var tempAngel = settings.angles[0]+settings.pi*2*(align);   //算出在2pi中所占的比例
		if(align==1){
			tempAngel-=0.0001;
		}
		settings.angles.push(tempAngel);
		if(type == "create"){
			var pathFill = settings.patternId ? "url(#"+settings.patternId+")" : settings.backColor;
			settings.itemPath = settings.cord.createElement("path",{"fill":pathFill},settings.gDashBoard);  //底部dom
			settings.path = settings.cord.createElement("path",{"fill":"url(#"+settings.linearGradientId+")"},settings.gDashBoard);  //当前dom
			if(!settings.cord.isSVG()){
				var fill = settings.cord.createElement("fill",{"rotate":"t","src":settings.backColor,"type":"tile"},settings.itemPath);
				var fillPath = settings.cord.createElement("fill",{"type":"gradient","color2":settings.endColor,"colors":".0 "+settings.colors+";.0 "+settings.colors},settings.path);  //当前dom
				
			}
		}
		if(settings.onCreateItem && typeof settings.onCreateItem == "function"){
			settings.onCreateItem(settings.path,0);	
		}
		
		var centerText = settings.centerText;
		var textValue = centerText.text;
		var cx = (settings.center[0]);
		var cy =(settings.center[1]);
		var fontWeight=centerText.fontWeight||"normal";
		if(!settings.text){
			settings.text = $("<div></div>").css({"position":"absolute","color":centerText.color,"font-family":centerText.fontFamily}).appendTo(settings.cord._settings.root);
		}
		
		_createCir(settings,settings.data,0,type);
	}
	function _createCir(settings,data,index,type){
		var tempSAngle,tempEAngle,inittempSAngle,path,flag,newAngle=0,outR = settings.r,innerR = outR-settings.strokeWidth,tempIndex=0;
		var addAngle =0,animateTime = settings.animateTime/36;
		tempSAngle = settings.angles[index];
		inittempSAngle = tempSAngle;
		newAngle = tempSAngle;
		tempEAngle = settings.angles[index+1];
		
		path = _getDoubleCilclePath(settings,3.14,9.4231,innerR,outR,1,settings.center);
		if(settings.cord.isSVG()){
			settings.cord.setAttributes(settings.itemPath,{"d":path,"stroke":"none"});
		}else{
			settings.cord.IECom(settings,settings.itemPath,path);
		}
		var angCount=settings.value/Math.ceil((tempEAngle-newAngle)/(Math.PI*2*1/36)); //计算出value值每次执行的步长值
		
		if(type == "create" && settings.isAnimate){
			var time = window.setInterval(function(){
				if(tempIndex!=0){
					addAngle=Math.PI*2*1/36;
				}
				newAngle =newAngle + addAngle;
				if(newAngle>tempEAngle){
					newAngle = tempEAngle;
				}
				if(newAngle == inittempSAngle) {
					newAngle = newAngle + 0.00001;
				}
				flag =((newAngle-tempSAngle) >Math.PI) ? 1:0;/*大小弧度*/	
				path = _getDoubleCilclePath(settings,tempSAngle,newAngle,innerR,outR,flag,settings.center);
				if(settings.cord.isSVG()){
					settings.cord.setAttributes(settings.path,{"d":path,"stroke":"none"});
				}else{  //IE兼容
					if(settings.value != 0){
						settings.cord.IECom(settings,settings.path,path);
					}
				}
				var strText = parseInt(angCount*tempIndex);
				tempIndex++;
				if(settings.onCreateMark && typeof settings.onCreateMark == "function"){
					settings.onCreateMark(settings.text,strText);	
				}
				var fontSize = (settings.smallCircleR && settings.smallCircleR > 0) ? settings.smallCircleR*settings.fontSizeRatio : settings.r*settings.fontSizeRatio;
				settings.text.css({"font-size":parseInt(fontSize)});
				var fragsLeft = settings.frags.css('left'), fragsTop = settings.frags.css('_ysp_top');
		
				var left = (settings.r*2-settings.text.width())/2+parseInt(fragsLeft === 'auto' ? 0 : fragsLeft);
				var _ysp_top = (settings.r*2+10-settings.text.height())/2+parseInt(fragsTop === 'auto' ? 0 : fragsTop);
				settings.text.css({"left":left,"_ysp_top":_ysp_top});	
					
				if(newAngle==tempEAngle){
					if(index+1<=data.length-1){
						_createCir(settings,data,index+1,type);
					}
					clearInterval(time);
				}
			},animateTime);
		}else{
			flag =((tempEAngle-tempSAngle) >Math.PI) ? 1:0;/*大小弧度*/		
			path = _getDoubleCilclePath(settings,tempSAngle,tempEAngle,innerR,outR,flag,settings.center);
			if(settings.cord.isSVG()){
				settings.cord.setAttributes(settings.path,{"d":path,"stroke":"none"});
			}else{
				if(settings.value != 0){
					settings.cord.IECom(settings,settings.path,path);
				}
			}
			if(index+1<=data.length-1){
				_createCir(settings,data,index+1,type);
			}
			if(settings.onCreateMark && typeof settings.onCreateMark == "function"){
				settings.onCreateMark(settings.text,settings.value);	
			}		
			var fontSize = (settings.smallCircleR && settings.smallCircleR > 0) ? settings.smallCircleR*settings.fontSizeRatio : settings.r*settings.fontSizeRatio;
			settings.text.css({"font-size":parseInt(fontSize)});
			var fragsLeft = settings.frags.css('left'), fragsTop = settings.frags.css('_ysp_top');
	
			var left = (settings.r*2-settings.text.width())/2+parseInt(fragsLeft === 'auto' ? 0 : fragsLeft);
			var _ysp_top = (settings.r*2+10-settings.text.height())/2+parseInt(fragsTop === 'auto' ? 0 : fragsTop);
			settings.text.css({"left":left,"_ysp_top":_ysp_top});	
		}
	}
	/*
	*算法：1、圆周长=2piR，算出当前块在2pi中所占的比例;2、x=Math.cos()*r;y=Math.sin()*r;
	*/
	function _getDoubleCilclePath(settings,sdeg,edeg,rInner, rOuter,flag,center){//获取圆环路径
		/*外弧起点坐标*/
		startX = center[0] + Math.cos(sdeg) * rOuter;
		startY = center[1] + Math.sin(sdeg) * rOuter;
		/*内弧起点坐标*/
		startInnerX = center[0] + Math.cos(sdeg) * rInner;
		startInnerY = center[1] + Math.sin(sdeg) * rInner;
		
		/*外弧结束坐标*/
		endX = center[0] + Math.cos(edeg) * rOuter;
		endY = center[1] + Math.sin(edeg) * rOuter;
		/*内弧结束坐标*/
		endInnerX = center[0] + Math.cos(edeg) * rInner;
		endInnerY = center[1] + Math.sin(edeg) * rInner;

		var path = "M"+startX+","+startY+"A"+rOuter+","+rOuter+" 0 "+flag+" 1 "+endX+","+endY+"L"+endInnerX+","+endInnerY+"A"+rInner+","+rInner+" 0 "+flag+" 0 "+startInnerX+","+startInnerY+"Z";
		return path;
	}
	function _getLinePath(settings,edeg, rOuter,center){//获取文本线路径
		var items = {};
		/*外弧起点坐标*/
		startX = Math.round(center[0] + Math.cos(edeg) * (rOuter+7));
		startY = Math.round(center[1] + Math.sin(edeg) * (rOuter+7));
		
		/*外弧结束坐标*/
		endX = Math.round(center[0] + Math.cos(edeg) * (rOuter+3));
		endY = Math.round(center[1] + Math.sin(edeg) * (rOuter+3));
		
		items.x = startX;
		items.y = startY;
		items.path = "M"+startX+","+startY+"L"+endX+","+endY;
		return items;
	}
	window.CircleProcess.prototype = {
		constructor: window.CircleProcess,
		init: function(){
			var settings = this._settings;
			if (!settings.data || (settings.data && !settings.data.value && settings.data.value != 0)) {
				_infoLayer(settings, "no data loaded.");
				return;
			}
			
			if(!settings.path){
				_setData(settings, "create");
			}else{
				_setData(settings, "modify");	
			}
		},
		/**
		*
		* @param data
		* @param onCreateItem(path, index)
		* @param onCreateMark(text)
		*/
		setData: function (data, onCreateItem, onCreateMark) {
			var settings = this._settings;
			if (!data || (data && !data.value && data.value != 0)) {
				return;
			}
			settings.infoLayer.hide();
			settings.data = data;
			settings.colors = data.color;
			settings.value = data.value > 100 ? 100 : data.value;
			settings.value = data.value < 0 ? 0 : settings.value;
			settings.endColor = data.endColor || settings.colors;
			settings.backColor = data.backColor || settings.backColor;
			settings.onCreateItem = onCreateItem;
			settings.onCreateMark = onCreateMark;
			settings.centerText = data.centerText || settings.centerText;
		},
		resize: function () {
			var settings = this._settings;
			if (!settings.data || (settings.data && !settings.data.value && settings.data.value != 0)) {
				_infoLayer(settings, "no data loaded.");
				return;
			}
			_setData(settings,"modify");
		},
		setRotate: function(rotate){
			this._settings.rotate = rotate;
		},
		setR: function(bigCirleR, smallCircleR){
			this._settings.bigCirleR = bigCirleR;
			this._settings.smallCircleR = smallCircleR;
		},
		//是否启用动画
		enableAnimate: function(flag,time){
			this._settings.isAnimate = flag;
			this._settings.animateTime = time;
		}
	}
})(UCD, UCD.Core);