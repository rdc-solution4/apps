var UCD = UCD || {Core:jQuery};
(function(ucd, $){
	/********************平台公用函数************************/
	//按id取元素
	function $id(id){
		return $("#"+id);
	}
	//按标签名取
	function $tagName(ele,tagName){
		if(ele instanceof $){
			ele = ele[0];
		}
		if(!tagName){
			tagName = "*";
		}
		if(!ele) return $();
		return $(ele.getElementsByTagName(tagName));
	}
	//取所有子元素
	function $children(ele){
		return $tagName(ele);
	}
	//替换jq find方法，解决IE7下效率问题
	function $find(context,selector){
		if(context instanceof $){
			context = context[0];
		}
		if(!context){
			return $();
		}
		var $child = $children(context);
		return $child.filter(selector);
	}
	
	//执行一个回调
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}
	/********************平台公用函数结束************************/
	var COUNT = 0;//计数器
	//var DATEFORMAT = "YYYY-MM-dd hh:mm:ss";//默认日期格式
	var DATEFORMAT = "YYYY-MM-DD";//默认日期格式
	function _getInputString(element,code){
	  var p={text:'',start:0,end:0};
	  var value=$(element).val();
	  if(document.selection){
	    var range=document.selection.createRange();
		var text=range.text;
		var length=value.length;
		var count=text.length;
		range.moveStart("character",-length);
		var text2=range.text;
		var count2=text2.length;
		var start=count2-count;
		range.moveStart("character",length);
		//p.text=text;
		p.start=start;
		p.end=start+count;
	  }else{
		  p.start=element.selectionStart;
		  p.end=element.selectionEnd;
		  }
	  var bString=value.substring(0,p.start);
	  var aString=value.substring(p.end,value.length)
	  var valueString=bString+String.fromCharCode(code)+aString; 	  
	  return valueString;
	}
	/*时、分、秒时间失去焦点*/
	function inputBlur(e){
		 var value=$(this).val();
		 if(value.length==1){
		  $(this).val("0"+value);
		 }
		 if(value.length<1){
			  $(this).val("00");
			 }
		 }
	/*分、秒keypress*/	 
	function inputTimePress(e){
	   var which = e.which;
		var $this = $(this);
		if(which>=48&&which<=57){
		 var inputValue=_getInputString(this,which);
		 if(inputValue.length>1){
		   var f=inputValue.substring(0,1);
		   if(f!="0"){
		   var inputInt=parseInt(inputValue);
			if(inputInt>=60){
				 e.preventDefault();
				}
		   }
		 }
		
		}	
	}
				 
		
	//创建时间区DOM及时间绑定
	function createTime(ins,date){
		var settings = ins._settings;
		var timeVisible = settings.timeVisible = getDateformatInfo(settings.dateFormat).timeVisible;
		var $time = settings.$time.empty();
		if(timeVisible){
			//$("<div class='timeTip'>"+settings.timeTip+"</div>").appendTo($time);
			$('<div class="time"><input type="text" class="hour" maxlength="2"><span class="split">:</span><input type="text" class="minute" maxlength="2"><span class="split">:</span><input type="text" class="second" maxlength="2"></div>').appendTo($time);
			$('<div class="control"><div class="up"></div><div class="down"></div></div>').appendTo($time);
			
			//事件绑定
			var $hour = $find($time,".hour");
			var $minute = $find($time,".minute");
			var $second = $find($time,".second");
			
			date && setPanelTime(ins,date);
			
			var $up = $find($time,".up");
			var $down = $find($time,".down");
			var inputObj = $hour;
			var maxTime = 23;
			var flag = false;
			$hour.keydown(function(e){
				var which = e.which;
				//禁止输入字母，符号
				if(which != 9 && ((which >= 65 && which <= 90) 
				|| which == 192 
				|| which >= 186 && which <= 191 
				|| which >= 106 && which <= 111 
				|| which >= 219 && which <= 222
				|| which == 38
				|| which ==40)){
					e.preventDefault(); 
				}
				if(which==38){
					upMouseDown(inputObj,maxTime);
					inputObj.focus();
					}else if(which==40){
						downMouseDown(inputObj,maxTime);
					    inputObj.focus();
						}
				
			});
			$hour.blur(inputBlur);
			$hour.keypress(function(e){
               var which = e.which;
				var $this = $(this);
				if(which>=48&&which<=57){
				 var inputValue=_getInputString(this,which);
				 if(inputValue.length>1){
				   var f=inputValue.substring(0,1);
				   if(f!="0"){
				   var inputInt=parseInt(inputValue);
				    if(inputInt>=24){
						 e.preventDefault();
						}
				   }
				 }
				
				}			
			});
			$minute.keydown(function(e){
				timeKey($(this),e);
			});
			$second.keydown(function(e){
				timeKey($(this),e)
			});
			$minute.keypress(inputTimePress);
			$second.keypress(inputTimePress);
			$minute.blur(inputBlur);
			$second.blur(inputBlur);
			var timeKey = function($inp,e){
				var which = e.which;
				//禁止输入字母，符号
				if(which != 9 && ((which >= 65 && which <= 90) 
				|| which == 192 
				|| which >= 186 && which <= 191 
				|| which >= 106 && which <= 111 
				|| which >= 219 && which <= 222
				|| which == 38
				|| which ==40)){
					e.preventDefault(); 
				}
				//键盘方向键上进行时间的累加
			  if(which == 38){
					upMouseDown(inputObj,maxTime);
					inputObj.focus();
				}
				//键盘方向键下进行时间的累减
				else if(which == 40){
					downMouseDown(inputObj,maxTime);
					inputObj.focus();
				}
			}
			
			var upMouseDown = function(pThis,number){
				var num = pThis.val();
				pThis.val(parseInt(num,10)+1);
				if(pThis.val() > number){
					pThis.val(0)	
				}
				if(pThis.val() < 10){
					pThis.val("0"+pThis.val());	
				}
			}
			var downMouseDown = function(pThis,number){
				var num = pThis.val();
				pThis.val(parseInt(num,10)-1);
				if(pThis.val() < 0){
					pThis.val(number);	
				}
				if(pThis.val() < 10){
					pThis.val("0"+pThis.val());	
				}
			}
			
			$hour.focus(function(){
				var $this = $(this);
				$this.select(function(){
					flag = true;
				});
				$this.select();
				inputObj = $this;
				maxTime = 23;
			});
			$minute.focus(function(){
				var $this = $(this);
				$this.select(function(){
					flag = true;
				});
				$this.select();
				inputObj = $this;
				maxTime = 59;
			});
			$second.focus(function(){
				var $this = $(this);
				$this.select(function(){
					flag = true;
				});
				$this.select();
				inputObj = $this;
				maxTime = 59;	
			});
			//禁用粘贴功能
			$hour.add($minute).add($second).bind("paste",function(e){
				e.preventDefault();
			});
			$up.unbind("click").bind("click",function(e){
				upMouseDown(inputObj,maxTime);
				inputObj.focus();
			});
			$down.unbind("click").bind("click",function(e){
				downMouseDown(inputObj,maxTime);
				inputObj.focus();
			});
			
		}
	}
	
	//设置面板时间区DOM时分秒
	function setTime(ins,date){
		//事件绑定
		var $time = ins._settings.$time;
		if(!$time || !$time[0]){
			return;
		}
		var $hour = $find($time,".hour");
		var $minute = $find($time,".minute");
		var $second = $find($time,".second");
		var thisHour = ("0"+date.getHours()).slice(-2);
		var thisMinute = ("0"+date.getMinutes()).slice(-2);
		var thisSecond = ("0"+date.getSeconds()).slice(-2);	
		$hour.val(thisHour);
		$minute.val(thisMinute);
		$second.val(thisSecond);
	}
	
	//设置底部功能按钮区DOM
	function createFooter(ins){
		var $okBtn,$closeBtn,$todayBtn,settings = ins._settings;
		//非嵌入模式才显示ok、close按钮
		if( !settings.isEmbedded && settings.toolbarVisible ){
			var labels = settings.label;
			/*ok按钮*/
			$okBtn=$("<a href='javascript:void(0)' class='dateBtn'>"+ escapeHtml(labels.ok) +"</a>");
			/*ok按钮事件处理*/
			$okBtn.bind("click",function(){
				if(ins._settings.selected){
					var date = getPanelDate(ins);
					date = formatDate(date,settings.dateFormat);
					ins.setValue(date);
				}
				ins.hide();
				$(".dateCover", window._ysp_top.document.body).hide();
			});
			/*close按钮*/
			$closeBtn = $("<a href='javascript:void(0)' class='dateBtn'>"+ escapeHtml(labels.close) +"</a>");
			/*close按钮事件处理*/
			$closeBtn.bind("click",function(){
				ins.hide();
				$(".dateCover", window._ysp_top.document.body).hide();
			});
            settings.$time = $("<div class='timeBox'/>");
            settings.$footer.append(settings.$time).append($okBtn).append($closeBtn);
		}
	}
	
	//创建星期提示
	//panel panel对象
	//label 文字
	function createDay(ins,panel,label){
		var settings = ins._settings;
		var html = "";
		var firstDay = settings.firstDayOfWeek;
		var dayArray_0 = label.slice(0,firstDay);
		var dayArray_1 = label.slice(firstDay);
		label = dayArray_1.concat(dayArray_0);
		for(var i=0;i<7;i++){
			html += "<div class='di'>"+label[i]+"</div>";
		}
		panel.$day.html(html);
	}
	
	//日期对象
	function D(ins,y,m,d,clazz,$con){
		var now = new Date();
		var ny = now.getFullYear();
		var nm = now.getMonth();
		var nd = now.getDate();
		var date = new Date(y,m,d);
		var	isToday = (y == ny && m == nm && d == nd);
		this.year = y;
		this.month = m;
		this.date = d;
		this.$dom = $("<div class='di "+clazz+(isToday?" today":"")+"' title="+dispose(ins._settings.dateFormat,date)+">"+d+"</div>").appendTo($con);
		ins._settings.date.push(this);
		if(ins._settings.validation){
			var disabled = _callback(ins._settings.validation,this,new Date(this.year,this.month,this.date));
			if(disabled){
				this.disabled = true;
				this.$dom.addClass("disabled");
			}
		}
	}
	
	D.prototype.select = function(flag){
		if( flag !== false ){
			flag = true;
		}
		this.$dom[flag?"addClass":"removeClass"]("selected");
	}
	
	//创建面板中的日期
	function createDates(ins,panel,year,month){
		var settings = ins._settings;
		//var date = 1;
		var $datePanel = panel.$dates;
		//创建上一个月遗留的天，使得第一行占满7个天数
		var thisMonthFirstDay = new Date(year,month,1);
		var day = thisMonthFirstDay.getDay();//星期几
		var df = settings.firstDayOfWeek;
		var dis;
		//面板开始星期几大于当月第一天星期几
		if(df > day){
			dis = 7 - df + day;
		} else {
			dis = day - df;//遗留天数
		}
		var prevMonth = getPrevMonth(thisMonthFirstDay);
		var y = prevMonth.getFullYear(),m = prevMonth.getMonth(),d,days;
		days = getDaysOfMonth(y,m);//上月天数
		for(var i = dis; i > 0; i--){
			d = days-i+1;
			new D(ins,y,m,d,"lastMonthDay",$datePanel);
		}
		y = year;
		m = month;
		//创建当月的天
		days = getDaysOfMonth(y,m);//当月天数
		for(var j = 1; j <= days; j++){
			d = j;
			new D(ins,y,m,d,"thisMonthDay",$datePanel);
		}
		if( settings.mode === 1 ){
			//创建下个月的天数，使得最后一行满7个天数
			var leave = 7 - ((new Date(year,month,days)).getDay() - settings.firstDayOfWeek) - 1;
			var nextMonth = getNextMonth(thisMonthFirstDay);
			y = nextMonth.getFullYear();
			m = nextMonth.getMonth();
			for(var k = 1; k <= leave; k++){
				d = k;
				new D(ins,y,m,d,"nextMonthDay",$datePanel);
			}
		}
	}
	
	//取当前显示面板的日期
	//获取时、分、秒
	function getTime(ins){
		var settings = ins._settings;
		var $time = settings.$time;
		return {
			hour : $find($time,".hour").val()||0,
			minute : $find($time,".minute").val()||0,
			second : $find($time,".second").val()||0
		}
	}
	function getPanelDate(ins){
		var settings = ins._settings;
		var time = getTime(ins);
		var selectedDate = settings.selected;
		if(selectedDate){
			var year = selectedDate.year;
			var month = selectedDate.month;
			var date = selectedDate.date;
			return new Date(year,month,date,time.hour,time.minute,time.second);
		} else {
			//return settings.value;
			var panel = settings.panel[0];
			return new Date(panel.year,panel.month,1,time.hour,time.minute,time.second);
		}
	}
	//获取date对象
	function getDate(ins,year,month,date){
		var o,settings = ins._settings;
		o = $.grep(settings.date,function(n){
			if($.isFunction(year)){
				return _callback(year,null,n);
			}
			return n.year == year && n.month == month && n.date == date;
		});
		return o[0];
	}
	//在面板中选中某天
	function selectDay(ins,year,month,day){
		var settings = ins._settings;
		var date = getDate(ins,year,month,day);
		if(date){
			var selected = settings.selected;
			if(selected){
				selected.select(false);
				settings.selected = null;
			}
			if(!date.disabled){
				date.select();
				settings.selected = date;
			}
		}
	}
	//取某年月的面板对象
	function getPanel(ins,year,month){
		var settings = ins._settings;
		var panels = settings.panel;
		var panel = panels.filter(function(i,n){
			return n.year === year && n.month === month;
		});
		return (!panel || (panel.length == 0)) ? null : panel[0];
	}
	//某月有多少天
	function getDaysOfMonth(year,month){
		var enddate = [31,28,31,30,31,30,31,31,30,31,30,31];
		if (year%4==0){
			enddate[1]=29;
		}
		return enddate[month];
	}
	//日期提示信息
  function dispose(dateFormat,date){
		var dateFormatInfo = getDateformatInfo(dateFormat);
		var dateTipFormat = dateFormatInfo.dateTipFormat;
		return formatDateToDateformat(dateTipFormat,date.getFullYear(),date.getMonth(),date.getDate());	
	}
	/*修改日期格式
	  YYYY-MM-dd hh:mm:ss
	  yyyy 替换成Y
	  yy 替换成y
	  MM替换成m
	  hh替换成h
	  mm替换成i
	  ss替换成s  
	*/	
	function changeDateformat(format){
		format = $.trim(format);
		format = format.replace(/m/g,"i");
		format = format.toUpperCase();
		format = format.replace(/YYYY/g,"Y");
		format = format.replace(/YY/g,"y");
		format = format.indexOf("MM")!= -1?format.replace(/MM/g,"M"):format.replace(/M/g,"m");
		format = format.indexOf("DD")!= -1?format.replace(/DD/g,"D"):format.replace(/D/g,"d");
		format = format.indexOf("HH")!= -1?format.replace(/HH/g,"H"):format.replace(/H/g,"h");
		format = format.indexOf("II")!= -1?format.replace(/II/g,"I"):format.replace(/I/g,"i");
		format = format.indexOf("SS")!= -1?format.replace(/SS/g,"S"):format.replace(/S/g,"s");
		return format;
	}
	//按日期格式格式化日期
	function formatDate(date,dateFormat){
		if(date instanceof Date){
			return formatDateToDateformat(dateFormat,date.getFullYear(),date.getMonth(),date.getDate(),date.getHours(),date.getMinutes(),date.getSeconds());
		}
		return null;
	}
	// 将年月日时分秒按format格式转换成字符串 
	function formatDateToDateformat(format,year,month,day,hour,minute,second){
		/*修改日期格式 YYYY-MM-dd hh:mm:ss yyyy 替换成Y yy 替换成y MM替换成m hh替换成h mm替换成i ss替换成s */	
		format = changeDateformat(format);
		var date="";
		for(var i=0;i<format.length;i++){
			var chart = format.charAt(i);
			switch(chart){
				case "Y":
					date += year;
					break;
				case "y":
					year = ""+year;
					date += year.substring(year.length-2);
					break;
				case "M":
					month = parseInt(month,10)+1;
					if(month<10){ month = "0"+month;}
					date += month;
					break;
				case "m":
					date += parseInt(month,10)+1;
					break;	
				case "D":
					if(day<10){ day = "0"+parseInt(day,10);}
					date += day;
					break;
				case "d":
					date += parseInt(day,10);
					break;	
				case "H":
					if(hour<10){ hour = "0"+parseInt(hour,10);}
					date += hour;
					break;
				case "h":
					date += parseInt(hour,10);
					break;
				case "I":
					if(minute<10){ minute = "0"+parseInt(minute,10);}
					date += minute;
					break;
				case "i":
					date += parseInt(minute,10);
					break;
				case "S":
					if(second<10){ second = "0"+parseInt(second,10);}
					date += second;
					break;
				case "s":
					date += parseInt(second,10);
					break;
				default:
					date += chart;
					break;
			}
		}
		return date;
	}
	/* 获取日期格式的信息
	   返回值： Object	
	   {
	     reg: RegExp对象，用来匹配string
	 	 indexArray:Array 按顺序记录年月日等出现的顺序，格式类似于：["H","I"] 表示第一位是时，第二位是分
	 	 dateVisible:Boolean 是否显示日期
	 	 timeVisible:Boolean 是否显示时间
	 	 dateTipFormat:String 日期提示格式（只会截取年月日）
	  }*/
	function getDateformatInfo(format){
		/*更换日期格式
		 	 YYYY-MM-dd hh:mm:ss  更换成Y-m-d h:i:s
		 */
		format = changeDateformat(format);
		var reg="";
		var j=0;
		var indexArray = [];
		var dateVisible=false;//日期是否显示
		var timeVisible=false;//时间是否显示
		var dateTipFormat = "";
		var fn = function(i,str) {
			if(i==0){
				dateTipFormat += str;
			} else {
				dateTipFormat += _chart+str;
			}   
		}
		for(var i=0;i<format.length;i++){
			var chart = format.charAt(i);
			var _chart = format.charAt(i-1);
			switch(chart){
				case "Y":
					reg += "([0-9]{4})";
					indexArray[j++] = "Y";
					if(!dateVisible) dateVisible = true;
					fn(i,"YYYY");
					break;
				case "y":
					reg += "([0-9]{2})";
					indexArray[j++] = "Y";
					if(!dateVisible) dateVisible = true;
					fn(i,"YY");
					break;
				case "M":
					reg += "(0[1-9]|1[0-2])";
					indexArray[j++] = "M";
					if(!dateVisible) dateVisible = true;
					fn(i,"MM");
					break;
				case "m":
					reg += "([1-9]|1[0-2])";
					indexArray[j++] = "M";
					if(!dateVisible) dateVisible = true;
					fn(i,"M");
					break;
				case "D":
					reg += "(0[1-9]|[1-2][0-9]|30|31)";
					indexArray[j++] = "D";
					if(!dateVisible) dateVisible = true;
					fn(i,"DD");
					break;
				case "d":
					reg += "([1-9]|[1-2][0-9]|30|31)";
					indexArray[j++] = "D";
					if(!dateVisible) dateVisible = true;
					fn(i,"D");
					break;
				case "H":
					reg += "([0-1][0-9]|20|21|22|23)";
					indexArray[j++] = "H";
					if(!timeVisible) timeVisible = true;
					break;		
				case "h":
					reg += "([0-9]|1[0-9]|20|21|22|23)";
					indexArray[j++] = "H";
					if(!timeVisible) timeVisible = true;
					break;
				case "I":
					reg += "([0-5][0-9])";
					indexArray[j++] = "I";
					if(!timeVisible) timeVisible = true;
					break;	
				case "i":
					reg += "([0-9]|[1-5][0-9])";
					indexArray[j++] = "I";
					if(!timeVisible) timeVisible = true;
					break;
				case "S":
					reg += "([0-5][0-9])";
					indexArray[j++] = "S";
					if(!timeVisible) timeVisible = true;
					break;
				case "s":
					reg += "([0-9]|[1-5][0-9])";
					indexArray[j++] = "S";
					if(!timeVisible) timeVisible = true;
					break;	
				default:
					reg += chart;
					break;
			}
		}	
		return {reg:new RegExp("^"+reg+"$"),indexArray:indexArray,timeVisible:timeVisible,dateVisible:dateVisible,dateTipFormat:dateTipFormat};
	}
	//将与format匹配的dateString转换成日期对象
	//否则取当前时间
	function getDateTime(dateString,format){
		/*获取系统时间*/
		/*未传入参数，则返回当前时间*/
		if(!dateString || !format){
			return new Date();
		}
		/*获取 正则符串*/
		var dateformatInfo = getDateformatInfo(format);
		var reg = dateformatInfo.reg;
		/*dateString区配reg，则将dateString转换成日期对象*/
		if(reg.test(dateString)){
			/*反回回包含该查找结果的一个数组*/
			var timeArray = reg.exec(dateString);
			/*年月日显示顺序*/
			var indexArray = dateformatInfo.indexArray;
			var year=month=day=hour=minute=second=null;
			$.each(dateformatInfo.indexArray,function(i){
				var each = timeArray[i+1];
				/*年份*/
				if(this == "Y"){ 
					//year = timeArray[i+1]>=0?timeArray[i+1]:now.getFullYear();
					year = each;
				}
				/*月份*/
				else if(this == "M"){ 
					//month = timeArray[i+1]>=0?parseInt(timeArray[i+1]-1,10):now.getMonth();
					month = each-1;
				}
				/*日期*/
				else if(this == "D"){ 
					//day = timeArray[i+1]>=0?timeArray[i+1]:now.getDate();
					day = each;
				}
				/*小时*/
				else if(this == "H"){ 
					//hour = timeArray[i+1]>=0?timeArray[i+1]:now.getHours();
					hour = each;
				}
				/*分钟*/
				else if(this == "I"){ 
					//minute = timeArray[i+1]>=0?timeArray[i+1]:now.getMinutes();
					minute = each; 
				}
				/*秒*/
				else if(this == "S"){ 
					//second = timeArray[i+1]>=0?timeArray[i+1]:now.getSeconds();
					second = each;
				}
			});
			return new Date(year,month,day,hour,minute,second);
		}	
		return new Date();	
	}
	//取上个月所在日期对象
	//day未指定时，返回date对应上一月的日期，如 12.1 返回11.1,12.31则返回11.30
	function getPrevMonth(date,day){
		var year = date.getFullYear();
		var month = date.getMonth();
		if( month == 0 ){
			month = 11;
			year -= 1;
		} else {
			month -= 1;
		}
		var days = getDaysOfMonth(year,month);
		if( day === undefined || day === null ){
			day = date.getDate();
		} else {
			day = parseInt(day,10);
		}
		if( day < 1 || isNaN(day) ){
			day = 1;
		} else if( day > days ){
			day = days;
		}
		return new Date(year,month,day);
	}
	//取下个月所在日期对象
	function getNextMonth(date,day){
		var year = date.getFullYear();
		var month = date.getMonth();
		if( month == 11 ){
			month = 0;
			year += 1;
		} else {
			month += 1;
		}
		var days = getDaysOfMonth(year,month);
		if( day === undefined || day === null ){
			day = date.getDate();
		} else {
			day = parseInt(day,10);
		}
		if( day < 1 || isNaN(day) ){
			day = 1;
		} else if( day > days ){
			day = days;
		}
		return new Date(year,month,day);
	}
	//设置面板位置
	function setPosition(ins,left,_ysp_top){
		var settings = ins._settings;
		if(left !== null && left !== undefined){
			settings.$dom.css({left:left});
		}
		if(_ysp_top !== null && _ysp_top !== undefined){
			settings.$dom.css({_ysp_top:_ysp_top});
		}
	}
	
	function _init(ins){
		var settings = ins._settings;
		settings.namespace = "datetime"+(COUNT++);
		var $container = settings.$container = $(settings.container);
		var $dom = settings.$dom = $("<div class='calendar'/>").attr("onselectstart","return false;");
		var $prev = settings.$prev = $("<div class='prev'/>");
		var $next = settings.$next = $("<div class='next'/>");
		var $panel = settings.$panel = $("<div class='panel'/>");
		var $footer = settings.$footer = $("<div class='footer'/>");
		ins.setMode(settings.mode);
		ins.setFirstDayOfWeek(settings.firstDayOfWeek);
		createFooter(ins);
		createTime(ins);//如果后续提供修改日期格式方法，则需考虑放入show方法中执行
		$panel.appendTo($dom);
		$footer.appendTo($dom);
		$prev.appendTo($dom);
		$next.appendTo($dom);
//		var $obj = window._ysp_top != window.self && settings.isShowInTop ?  window._ysp_top.document.body : document.body; 
		var $obj = document.body; 
		$dom.appendTo($obj);
		var prev = function(e){
			var ins = e.data.ins;
			var settings = ins._settings;
			var date;
			if( settings.mode == 1 ){
				date = getPanelDate(ins);
			} else {
				var panel = settings.panel[0];
				date = new Date(panel.year,panel.month,1);
			}
			var _date = getPrevMonth(date);
			ins.show(_date);
		}
		$prev.bind("click",{ins:ins},prev);
		var next = function(e){
			var ins = e.data.ins;
			var settings = ins._settings;
			var date;
			if( settings.mode == 1 ){
				date = getPanelDate(ins);
			} else {
				var panel = settings.panel[0];
				date = new Date(panel.year,panel.month,1);
			}
			var _date = getNextMonth(date);
			ins.show(_date);
		}
		$next.bind("click",{ins:ins},next);
	}
	
	//面板对象
	function createPanel(ins,year,month){
		var panel = {},settings = ins._settings;
		panel.year = year;
		panel.month = month;
		var mode = settings.mode;
		var monthList = settings.label.month;
		var $con = settings.$panel;
		var $dom = panel.$dom = $("<div class='item'/>");
		var $header = panel.$header = (mode != 1 ? $("<div class='header'><div class='value'><div class='v'><span class='y'></span><span class='split'>-</span><span class='m'></span></div></div>"):$("<div class='header'><div class='value'><div class='v'><span class='y'></span><span class='split'>-</span><span class='m'></span><span class='trigger'></span></div><div class='drop'><div class='yBox'><div class='track'></div><ul class='y'></ul></div><ul class='m'></ul></div></div></div>"));
		var $body = panel.$body = $("<div class='body'/>");
		var $day = panel.$day = $("<div class='day'/>");
		var $date = panel.$dates = $("<div class='dates'/>");
		createDay(ins,panel,settings.label.day);
		createDates(ins,panel,year,month);
		$body.append($day).append($date);
		$dom.append($header).append($body).appendTo($con);
		
		//设置头部年月文字
		var set = function(year,month){
			var $year = $find($header,".value .y");
			var $month = $find($header,".value .m");
			$year.text(year);
			//$month.text(monthList[month]);
			$month.text(("0"+(month+1)).slice(-2));
		}
		set(year,month);

		if( mode == 1 ){
			//选中年月
			var setYearStyle = function(panel,year){
				var $years = $find($header,".drop .y li");
				var $year = $years.filter(function(i,n){
					return $(n).text() == year;
				});
				if($year[0]){
					$years.removeClass("selected");
					$year.addClass("selected");
				}
			}
			var setMonthStyle = function(panel,month){
				var $months = $find(panel.$header,".drop .m li");
				var $month = $months.eq(month);
				if($month[0]){
					$months.removeClass("selected");
					$month.addClass("selected");
				}
			}
			
			//创建年下拉
			var setYearHtml = function(ins,panel,year){
				var html = "";
				var length = ins._settings.yearLength;
				var _year = settings.startYear;
				
				for(var i = 0; i < settings.yearLength; i++){
					html += "<li>"+(_year + i)+"</li>";
				}
				$find(panel.$header,".drop .y").html(html);
			}
			setYearHtml(ins,panel,year);
			
			$header.delegate(".drop .yBox > .track","mousedown",function(e){
				var startY = e.pageY;
				var $box = $find($header,".yBox");
				var $track = $(this);
				var $content = $find($box,".y");
				var viewboxHeight = $box.height();
				var trackHeight = $track.height();
				var contentHeight = $content.height();
				var startTop = $track.css("_ysp_top").slice(0,-2)-0;
				var maxDis = viewboxHeight - trackHeight;
				var oldScroll = $content.css("margin-_ysp_top").slice(0,-2)-0;
				var maxScroll = viewboxHeight - contentHeight;
				
				var move = function(e){
					var dis = e.pageY - startY; 
					var newPos = dis + startTop;
					if( newPos < 0 ){
						newPos = 0;
					} else if( newPos > maxDis ){
						newPos = maxDis;
					}
					$track.css("_ysp_top",newPos);
					$content.css("margin-_ysp_top",maxScroll*(newPos/maxDis));
				}

				$(document).bind("mousemove",move).bind("mouseup",function(){
					$(this).unbind("mousemove",move);
				});
				e.preventDefault();
			});

            //设置当前年在最中间
            var reviseYearPosition = function(){
                var $box = $find($header,".yBox");
                var $track =  $find($header,".track");
                var $content = $find($box,".y");
                var viewboxHeight = $box.height();
                var trackHeight = $track.height();
                var contentHeight = $content.height();
                var startTop = $track.css("_ysp_top").slice(0,-2)-0;
                var maxDis = viewboxHeight - trackHeight;
                var oldScroll = $content.css("margin-_ysp_top").slice(0,-2)-0;
                var maxScroll = viewboxHeight - contentHeight;

                var index = $(".drop .y li.selected").index();
                var contentDistance = (index-6)*22;
                if(contentDistance<0){
                    contentDistance = 0;
                }else if(contentDistance>-maxScroll){
                    contentDistance = -maxScroll;
                }
                var newPos = startTop-maxDis*contentDistance/maxScroll;
                if( newPos < 0 ){
                    newPos = 0;
                } else if( newPos > maxDis ){
                    newPos = maxDis;
                }
                $track.css("_ysp_top",newPos);
                $content.css("margin-_ysp_top",-contentDistance);
            }

			//创建月下拉
			var setMonthHtml = function(ins,panel,monthList){
				var html = "";
				for(var i = 1; i <= 12; i++){
					html += "<li>"+("0"+i).slice(-2)+"</li>";
				}
				$find(panel.$header,".drop .m").html(html);
			}
			setMonthHtml(ins,panel,monthList);
			setYearStyle(panel,year);
			setMonthStyle(panel,month);
			

            //年月日下拉
			$find($header,".trigger").click(function(e){
				$find($header,".value").toggleClass("show");
                reviseYearPosition();
			});
			
			$header.find(".drop .y li").on("click",function(e){
				var year = $(this).text();
				var month = $find($header,".value .v .m").text()-1;
				var time = getTime(ins);
                $(".drop .y li").removeClass("selected");
                $(this).addClass("selected");
				//ins.show(new Date(year,month,1,time.hour,time.minute,time.second));
				e.stopPropagation();//不可缺少
			});
			
			$header.delegate(".drop .m li","click",function(e){
				var year = $find($header,".drop .y li.selected").text();
				var month = $(this).index();
				var time = getTime(ins);
				ins.show(new Date(year,month,1,time.hour,time.minute,time.second));
				e.stopPropagation();//不可缺少
			});
			
		}

		var clickEvent = function(ins,e){
			var tar = e.target;
			var $date = $(tar);
			var date = getDate(ins,function(n){
				return n.$dom[0] == tar;
			});
			if(date.disabled){
				return;
			}
			var mode = ins._settings.mode;
			if($date.is(".thisMonthDay:not('.selected')")){
				selectDay(ins,date.year,date.month,date.date);
			} else {
				var time = getTime(ins);
				date = new Date(date.year,date.month,date.date,time.hour,time.minute,time.second);
				ins.show(date);
				var date = getPanelDate(ins);
				date = formatDate(date,settings.dateFormat);
				ins.setValue(date);
				ins.hide();
				$(".dateCover", window._ysp_top.document.body).hide();
			}
			
		}

		$dom.delegate(".di","click",function(e){
		/*	e.stopPropagation();
			e.preventDefault();*/
			clickEvent(ins,e);
		})
		return panel;
	}
	
	function createDateCover(settings){
		var $dateCover;
		if(window._ysp_top != window.self) {
			$dateCover = $(".dateCover", window._ysp_top.document.body);
			if($dateCover.length == 0) {
				$("<div></div>").addClass("dateCover").css({"position":"absolute","width":"100%","height":"100%"}).appendTo(window._ysp_top.document.body);
			}else {
				$dateCover.show();
			}
		}else {
			$dateCover = $("<div></div>").addClass("dateCover").appendTo("body");
		}
	}
	
	function getOffset(obj,offset){
		obj = obj ||  window;
		offset = offset || {"left":0,"_ysp_top":0};
		var parent = obj.parent;
		var ifra = parent.document.getElementsByTagName("iframe");
		var len = ifra.length;
		if(len == 0) {return offset;}
		var flag = false,tOffset;
		for(var i=0;i<len;i++) {
			if(ifra[i].contentWindow == window) {
				tOffset = $(ifra[i]).offset();
				offset.left = tOffset.left + offset.left-$(obj.document).scrollLeft();
				offset._ysp_top = tOffset._ysp_top + offset._ysp_top-$(obj.document).scrollTop();
				flag = true;
				break;
			}
		}
		if(!flag) {
			getOffset(parent,offset);
		}else {
			return offset;
		}
		
	}
	
	function _ajustPosition(self){
	   
      var settings = self._settings;
	  var $inp=settings.$anchor;
	  var offset = $inp.offset(),teOffset;
		if(settings.isShowInTop) {
			teOffset = getOffset();
			offset.left = offset.left + teOffset.left;
			offset._ysp_top = offset._ysp_top + teOffset._ysp_top;
		}
		var domH = settings.$dom.outerHeight(true);
		var referValue = $(window).height() - $inp.position()._ysp_top;
		
		var screenHeight=$(window._ysp_top).outerHeight();
	/*	if($inp.outerHeight(true)+domH+offset._ysp_top>screenHeight){
		  offset._ysp_top = offset._ysp_top - domH;
		}else{
		  offset._ysp_top = offset._ysp_top+$inp.outerHeight(true);
		}*/
        offset._ysp_top = offset._ysp_top+$inp.outerHeight(true);
		setPosition(self,offset.left,offset._ysp_top);
	}
	
	function _bindEventHand(self,$input,$inp){
		self.show($input.val());
	}
	ucd.Date = function(options){
		var self = this;
		//显示文字国际化的方法，改变变量window.ucdDateDefaultText的值（以English为例）：
        /*		window.ucdDateDefaultText = {
			day:	["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],//日期所在星期几对应的文字。
			month:	["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
			prev:	"PreMonth",
			next:	"NextMonth",
			close:	"Cancel",
			ok:		"Ok"
		}*/
        //默认显示文字为“中文”
		var defaultLabel = {
				day:	["日","一","二","三","四","五","六"],//日期所在星期几对应的文字。
				month:	["一","二","三","四","五","六","七","八","九","十","十一","十二"],
				prev:	"上一月",
				next:	"下一月",
				close:	"取消",
				ok:		"确定"
		};
		//规范国际化文字变量为{}对象
		if(typeof(window.ucdDateDefaultText)=="object"){
			window.ucdDateDefaultText.day = window.ucdDateDefaultText.day || defaultLabel.day;
			window.ucdDateDefaultText.month = window.ucdDateDefaultText.month || defaultLabel.month;
			window.ucdDateDefaultText.prev = window.ucdDateDefaultText.prev || defaultLabel.prev;
			window.ucdDateDefaultText.next = window.ucdDateDefaultText.close || defaultLabel.close;
			window.ucdDateDefaultText.ok = window.ucdDateDefaultText.ok || defaultLabel.ok;
		}
		this._settings = $.extend({
			container:document.body,
			target:null,//目标输入框
			isEmbedded:false,//是否是嵌入模式，默认为false，即不是嵌入模式。嵌入模式会直接显示，而不需要click等触发。
			dateFormat: DATEFORMAT,//日期格式,默认为"YYYY-MM-dd hh:mm:ss"。
			value:null,//formatDate(new Date(),DATEFORMAT)默认值。会将值与日期格式匹配，转换成合法的日期。
			firstDayOfWeek : 0,  //0-6的数字。表示一周从星期几算起，默认值为0，表示从星期天开始。0表示星期天，
			label: window.ucdDateDefaultText || defaultLabel,
            startYear:1900,
			yearLength:200,//年下拉选择框年数量
			mode:1,
			hidden:true,
			toolbarVisible:true,
			events:{},
			panel:[],//存储面板对象
			date:[],//存储日期对象
			validation:false,//日期验证规则函数
			isShowInTop:false,
			selected:null,//用来记录面板上被选中的日期所在对象
			formatCallBack:null
		}, options);
		//_init(this);
	}
	
	ucd.Date.prototype = {
		constructor: ucd.Date,
		init:function(){ 
			_init(this);
		},/*
		setDirection:function(direction){
			this._settings.direction = direction;
		},*/
		/*setcssHref:function(url){
			this._settings.cssHref = url;
		},*//*
		setValidationRule:function(rule){
			if( typeof rule == "function" ){
				this._settings.validation = rule;
			}
		},*/
		//是否开放？
		/*setFormat:function(format){
			if(typeof format == "string"){
				this._settings.value=formatDate(getDateTime(this._settings.value,this._settings.dateFormat),format);
				this._settings.dateFormat = format;
			}
		},*/
		setFormatCallBack:function(fn) {
			this._settings.formatCallBack = fn;
		},
		setMode: function(mode){
			// mode: 1,2,3，同时显示几个月份，默认为1
			//对于设置为1的情况，在显示日期时，也要显示本月相临的前后一个月的几天日期。
			if( mode != 2 && mode != 3 ){
				mode = 1;
			}
			this._settings.mode = mode;
		}/*,
		setIsShowInTop:function(flag){
			this._settings.isShowInTop = flag;
		}*/,
		//设置面板起始日
		setFirstDayOfWeek: function(val){
			var settings = this._settings;
			// val: 0,1,2,3,4,5,6，分别表示周日、一、二、三...周六
			val = parseInt(val,10);
			if( val < 0 ){
				val = 0;
			}
			if( val > 6 ){
				val = 6;
			}
			//值未改变
			if(settings.oldDayOfWeek !== undefined && settings.oldDayOfWeek == val){
				return;
			}
			settings.firstDayOfWeek = settings.oldDayOfWeek = val;
			/*createDay(this);
			if(!settings.hidden){
				var date = getPanelDate(this);
				createDates(this,date);
				setPanelTime(this,date);
			}*/
		},
		//设置值
		setValue:function(value){
			var settings = this._settings;
			value = getDateTime(value,settings.dateFormat);
			var tempDate;
			if(settings.formatCallBack && $.isFunction(settings.formatCallBack)) {
				tempDate =_callback(settings.formatCallBack,this,value); 
			}
			settings.value = tempDate ? tempDate : formatDate(value,settings.dateFormat);
			this._settings.$anchor.find(".calendarInput").val(settings.value);
			_callback(settings.events.change,this,this);
		},
		//获取值
		getValue:function(){
			return this._settings.value;
		},
		//设置值改变时执行的回调，会在setValue时执行
		setOnChanged: function(fn){
			if( $.isFunction(fn) ){
				this._settings.events.change = fn;
			}
		},
		//显示
		//date创建该日期对应的面板，并将该日期选中
		show: function(date){
            $(".calendar").hide();
			//date可选，如果指定，则显示时以date为基准，不指定，则以组件value为基准
			var settings = this._settings;
			if(date instanceof Date){
				date = date;
			} else if(typeof date === "string"){
				date = getDateTime(date,settings.dateFormat);
			} else {
				date = getDateTime(settings.value,settings.dateFormat);
			}
			var $dom = settings.$dom;
			//重置
			(function reset(settings){
				settings.$dom.removeClass("multiple");
				settings.panel = [];
				settings.date = [];
				settings.$panel.empty();
			})(settings);
			
			var mode = settings.mode;
			if( mode !== 1 ){
				$dom.addClass("multiple");
			}
			var _date = date;
			for(var i = 0; i < mode; i++){
				settings.panel.push(createPanel(this,_date.getFullYear(),_date.getMonth()));
				_date = getNextMonth(_date,1);
			}
			selectDay(this,date.getFullYear(),date.getMonth(),date.getDate());
			setTime(this,date);
			if(settings.isShowInTop) {
                createDateCover(settings);
			}
			settings.$dom.show();
			settings.$anchor.addClass("showCalendar");
			settings.hidden = false;
			_ajustPosition(this);
		},
		//隐藏
		hide: function(){
			this._settings.$dom.hide();
			this._settings.$anchor.removeClass("showCalendar");
			this._settings.hidden = true;
		},
		//设置锚点
		setAnchor:function($inp){
			var settings = this._settings;
			//保证锚点是输入框，且不是原锚点
			if(settings.$anchor && settings.$anchor[0] && settings.$anchor[0] == $inp[0]) return;
			settings.$anchor = $inp;
			var $input = $("<input/>").attr("type","text").addClass("calendarInput").appendTo($inp);
			$("<span></span>").addClass("calendarDateIcon").appendTo($inp);
			var self = this;
			var value = settings.value?new Date(settings.value):new Date();
			var tempDate;
			if(settings.formatCallBack && $.isFunction(settings.formatCallBack)) {
				tempDate =_callback(settings.formatCallBack,this,value); 
			}
			settings.value = tempDate ? tempDate : formatDate(value,DATEFORMAT);
			
			$input.val(settings.value).unbind("focus").bind("focus",function(e){
				e.stopPropagation();
				_bindEventHand(self,$input,$inp);
				window.setTimeout(function(){
				  $input.unbind("blur").bind("blur",function(){
				    settings.timer = window.setTimeout(function(){
					self.hide();
				    },200); 
				  });
				},0);
			});
			/*.unbind("blur").bind("blur",function(){
			  console.log("blur b timer");
				settings.timer = window.setTimeout(function(){
					self.hide();
					console.log("blur a timer");
				},200); 
			});*/
			$inp.unbind("click").bind("click",function(e){
				e.stopPropagation();
				_bindEventHand(self,$input,$inp);
			})
			settings.$dom.unbind("mouseenter").bind("mouseenter",function(e){
				//$input.blur();
				$input.unbind("blur");
				e.stopPropagation();
				window.clearTimeout(settings.timer);
				// console.log("mouseenter");
			});
			$(document).bind("click."+settings.namespace,function(e){
				var tar = e.target;
				if( !$(tar).closest(settings.$dom)[0] && tar != $input[0] ){
					self.hide();
				}
			});
			$(".dateCover", window._ysp_top.document.body).on("click",function(){
				self.hide();
				$(".dateCover", window._ysp_top.document.body).hide();
			})
		}
	}
})(UCD,UCD.Core);