/*
	自定义滚动条
	修改日志：
	2013-12-6:修改了IE8下 height（）函数效率低的问题
	2013-12-10:修改了多次绑定滚轮事件的bug
*/

var ucd = ucd||{};
(function(NS){
	function DefaultScroll(options){
		var settings = this._settings = $.extend({
			scrollObj:"",
			scrollHbarObj:"",
			scrollVbarObj:"",
			hScrollVisible:true,         //是否支持水平滚动。默认true，支持。
			vScrollVisible:true,	      //是否支持垂直滚动。默认true，支持。
			DefaultScrollVisible:true,
			scrollToBottomCallback:null
		},options || {});
		
		this.scrollObj = validateParamType(settings.scrollObj);
		//内容容器对象
		this.scrollConObj = this.scrollObj.find(">div:eq(0)"); 
		this.scrollConObj.css("position","absolute").css("_ysp_top","0px"); 
		this._init();
		var self = this;
		this.isScrollToBottom = false;
		$(window).resize(function() {
				self.refreshScroll();
		});
	}
	DefaultScroll.prototype = {
		constructor:"DefaultScroll",
		_jquery:"1.7.2",//jquery版本
		_getSettings:function(){
			return this._settings;
		},
		_init:function(self){
			var settings = this._getSettings();
			this.width=this.scrollObj.width();
			this.height=this.scrollObj.height();

			var Xwidth=this.scrollConObj.width();
			var Hheight=this.scrollConObj.height();
			var hScrollVisible=settings.hScrollVisible;
			var vScrollVisible=settings.vScrollVisible;
			var parent = this.scrollObj.parent();
			this.parentWidth = parent.width();
			this.parentHeight = parent.height();
			
			this.scroller = new Scroller(this.scrollObj,this.width,this.height);
			this.scrollObj.css({ "position":"relative","overflow":"hidden" });
			//水平滚动条
			this.$LeftxScrollBar=$("<div class='LeftxScrollBar'></div>").css({width:this.width}).appendTo(this.scrollObj);
			this.$trackOne=$("<div class='ScrollbarTrack'></div>").width(this.width).appendTo(this.$LeftxScrollBar);
			this.$handleOne=$("<div class='ScrollbarHandle'><span class='ScrollbarHandleR'><span class='ScrollbarHandleC' /></span></div>").appendTo(this.$trackOne);
			this.$arrowOne=$("<span class='ScrollbarArrow1' />").appendTo(this.$LeftxScrollBar);
			this.$arrowTwo=$("<span class='ScrollbarArrow2' />").appendTo(this.$LeftxScrollBar);
			
			//垂直滚动条
			this.$LeftyScrollBarOne=$("<div class='LeftScrollBar2'></div>").height(this.height).appendTo(parent);
			this.$trackTwo=$("<div class='ScrollbarTrack'></div>").height(this.height).appendTo(this.$LeftyScrollBarOne);
			this.$handleTwo=$("<div class='ScrollbarHandle' style='_ysp_top:4px' ><span class='ScrollbarHandleR'><span class='ScrollbarHandleC' /></span></div>").appendTo(this.$trackTwo);
			this.$arrowOne2=$("<span class='ScrollbarArrow12' />").appendTo(this.$LeftyScrollBarOne);
			this.$arrowTwo2=$("<span class='ScrollbarArrow22' />").appendTo(this.$LeftyScrollBarOne);
			
			if(!settings.DefaultScrollVisible){
				this.$LeftxScrollBar = 	$(settings.scrollHbarObj);
				this.$LeftyScrollBar = 	$(settings.scrollVbarObj);
			}
			if(hScrollVisible){
				 if(Xwidth > this.scrollObj.width()){
					scrollbar(this,this.$LeftxScrollBar, this.scroller, null,"x");
				 }else{
					this.$LeftxScrollBar.hide();
				 }
			}else{
					this.$LeftxScrollBar.hide();
			}
			if(vScrollVisible){

				 if(Hheight > this.scrollObj.height()){
					scrollbar(this,this.$LeftyScrollBarOne, this.scroller,null,"y");
				 }else{
					this.$LeftyScrollBarOne.hide();
				 }
			} else{
				this.$LeftyScrollBarOne.hide();
			}
			
			this._binEvents();
				
		},
		//注意绑定对象的时机
		_binEvents : function(){
			var self = this;
			//水平
			this.$arrowOne.click(function(){ 
				self.scrollBy(-40,"x");
				return false;
			});
			this.$arrowTwo.click(function(){ 
				self.scrollBy(40,"x");
				return false;
			}); 
			//垂直
			this.$arrowOne2.click(function(){ 
				self.scrollBy(-40,"y");
				return false;
			});
			this.$arrowTwo2.click(function(){
				scrollPosition = "y";
				self.scrollBy(40,"y");
				return false;
			});
			//窗口大小改变时，刷新滚动条
			
		},
		ScrollTween : function () {
			//private variables
			var self    = this;
			var _steps  = [0,25,50,70,85,95,97,99,100];
			var _values = [];
			var _idle   = true;
			var o, _inc, _timer;
			
			//private functions
			function tweenTo (y) {
				if (!_idle) return false;
				
				var d = o.getDimensions();
				if (y < 0) y = 0;
				if (y > d.theight - d.vheight)
					y = d.theight - d.vheight;
					
				var dist = y - d.y;
				_inc     = 0;
				_timer   = null;
				_values  = [];
				_idle    = false;
				
				for (var i = 0; i < _steps.length; i++) {
					_values[i] = Math.round(d.y + dist * (_steps[i] / 100));
				}
		
				_timer = window.setInterval(function () {
					o.scrollTo(_values[_inc]); 
					if (_inc == _steps.length - 1) {
						window.clearInterval(_timer);
						_idle = true;
					} else _inc++;
				}, o.stepSpeed);
			};
			
			function tweenBy (y) {
				o.tweenTo(o.getDimensions().y + y);
			};
			
			function setSteps (s) {
				_steps = s;
			};
			//public functions
			this.apply = function (p) {
				o = p;
				o.tweenTo   = tweenTo;
				o.tweenBy   = tweenBy;
				o.setSteps  = setSteps;
				o.stepSpeed = 30;
			}
		},
		//获取垂直滚动条的位置
		getScrollPositionY:function(){
			return this.Y
		},
		//获取水平滚动条的位置
		getScrollPositionX:function(){
			return this.X
		},
		//设置滚动条默认初始位置
		setScrollPosition:function(o){
			 var self = this;
			 var width=self.width;
			 var height=self.height;
			 var Xwidth=self.scrollConObj.width();
			 var Hheight=self.scrollConObj.height();
		     if(o.x && self._settings.hScrollVisible && Xwidth > width){
		     	this.scroll(o.x,"x");
		    }
		    if(o.y && self._settings.vScrollVisible && Hheight>height){
		     	this.scroll(o.y,"y");
		     }
		},
		scrollToBottom:function(flag){
            var Hheight=this.scrollConObj.height();
            var position = {x:0,y:Hheight};
            this.setScrollPosition(position);
		},
		getScrollToBottom:function(){
			return this.isScrollToBottom;
		},
		//动画滚动一定的距离
		//组件滚动条显示
		show : function(){
			var settings = this._getSettings();
			if(settings.DefaultScrollVisible ){
				this.$LeftxScrollBar.show();
				this.$LeftyScrollBarOne.show();
			}else{
				settings.scrollHbarObj.show();
				settings.scrollVbarObj.show();
			}
	  	},
	
	    //组件滚动条隐藏
	 	hide : function(){ 
	 		var settings = this._getSettings();
			if(settings.DefaultScrollVisible ){
				this.$LeftxScrollBar.hide();
				this.$LeftyScrollBarOne.hide();
			}else{
				settings.scrollHbarObj.hide();
				settings.scrollVbarObj.hide();
			}
		 },
	 
		//组件滚动条销毁
		remove : function(){
			var settings = this._getSettings();
			if(settings.DefaultScrollVisible ){
				this.$LeftxScrollBar.remove();
				this.$LeftyScrollBarOne.remove();
			}else{
				settings.scrollHbarObj.remove();
				settings.scrollVbarObj.remove();
			}
		},
		//组件滚动条动态刷新，主要用来实现滚动条的自适应
		refreshScroll:function(){
			//console.log("#"+this.scrollConObj.parent().attr("id")+" is scrollRefresh!");
			//记录当前滚动条的位置
			var x=this.getScrollPositionX();
			var y=this.getScrollPositionY();
			var _ysp_top = parseInt(this.scrollConObj.css("_ysp_top"));
			var Hheight=this.scrollConObj.height();
			var height = this.scrollObj.height();
		
			//重新生成滚动条
			this.$LeftxScrollBar.remove();
			this.$LeftyScrollBarOne.remove();
	
			this._init();
			var ratio = Math.abs(_ysp_top/(Hheight-height));
			y = ratio*(this.scrollObj.height()-this.$handleTwo.height());
			//_ratio = ratio;//w00223307
			//滚动条的位置使内容保持不动
			this.setScrollPosition({x:x,y:y});
   		},
		onMouseDown:$.noop,
		onMouseUp:$.noop,
		onScroll:$.noop,
		scroll:$.noop,
		scrollAmount:5,
		scrollSpeed:30,
		disabled:false,
		onMouseDown:null,
		onMouseDown:null
	}
	/*
		滚动器的构造函数，实现对象的滚动
		o是滚动对象，w宽，h高，t是false,
	*/
	function Scroller(o, w, h, t){
			var obj = o;
			//真正的滚动对象是o的子元素
			o=$(o).find(">div:eq(0)")[0];
						
			var self  = this;
			var _vwidth   = w;
			var _vheight  = h;
			var _twidth   = o.offsetWidth
			var _theight  = o.offsetHeight;
			var _hasTween = t ? true : false;
			var _timer, _x, _y;
			
			//public variables
			this.onScrollStart = function (){};
			this.onScrollStop  = function (){};
			this.onScroll      = function (){};
			this.scrollSpeed   = 30;
			
			/*实现内容的滚动*/
			function setPosition (x,y,scrollPosition,time) {
				if(null == time){
					time = 0;
				}
			
				if(scrollPosition == "y"){
					if (y <= _vheight - o.offsetHeight) 
						y = _vheight - o.offsetHeight;//console.log(" _vheight :"+ _vheight+" _o.offsetHeight: "+o.offsetHeight);
					if (y > 0) y = 0;
					_y = y;
					//时间为0则没有动画
					if(0==time){
						$(o).css("_ysp_top",_y);
					}else{
						$(o).animate({"_ysp_top":_y},time);
						
					}
					
				}
				else if(scrollPosition == "x"){
					if (x < _vwidth - _twidth) 
						x = _vwidth - _twidth;
					if (x > 0) x = 0;
					_x = x;
					if(0==time){
						$(o).css("left",_x)
					}else{
						$(o).animate({"left":_x},time);
					}
					
				}
			};
			
			//public functions,注意这是scroller的scrollBy方法，而不是组件的scroller的scrollBy方法
			this.scrollBy = function (x, y,time) {
				setPosition(_x - x, _y - y,scrollPosiction,time);
				this.onScroll();
			};
			
			this.scrollTo = function (x, y,scrollPosition,time) { 
				setPosition(-x, -y,scrollPosition,time);
				this.onScroll();
			};
			
			this.startScroll = function (x, y) {
				this.stopScroll();
				this.onScrollStart();
				_timer = window.setInterval(
					function () { self.scrollBy(x, y); }, this.scrollSpeed
				);
			};
				
			this.stopScroll  = function () { 
				if (_timer) window.clearInterval(_timer);
				this.onScrollStop();
			};
			
			this.reset = function () {
				_twidth  = o.offsetWidth
				_theight = o.offsetHeight;
				_x = 0;
				_y = 0;
				$(o).css({"left":0,"_ysp_top":0});
				if (_hasTween) t.apply(this);
			};
			
			this.swapContent = function (c, w, h) {
				o = c;
				o=$(o).find(">div:eq(0)")[0];
				if (w) _vwidth  = w;
				if (h) _vheight = h;
				reset();
			};
			//获取尺寸
			this.getDimensions = function () {
				return {
					vwidth  : _vwidth,//外容器的宽
					vheight : _vheight,//外容器的高
					twidth  : _twidth,//内容器的宽
					theight : _theight,//内容器的高
					x : -_x, y : -_y
				};
			};
			
			this.getContent = function () {
				return o;
			};
			this.getObj = function(){
				return obj;	
			}
			this.reset();
		}
	
	
	function validateParamType(obj){
		if(!obj) return;
		if(typeof obj=="string"&&obj.indexOf("#")==-1&&obj.indexOf(".")==-1&&obj.indexOf(":")==-1&&$(obj).length == 0){
			obj = $("#"+obj);
		} else {
			obj = $(obj);
		}
		return obj;
	}
	/*滚动条,不是构造函数
	 *参数是scroller
	 */
	function scrollbar(self,o, s, t,scrollPosition) {
			var _components = {};
			var _dimensions = {};
			var _temporary  = {};
			var _hasTween   = t ? true : false;
			//_ratio
			var _timer, _ratio;
			//滚动条的方向，这是个全局变量
			scrollPosition = scrollPosition || "y"; 
			//public variables
			self.onMouseDown   = function (){};
			self.onMouseUp     = function (){};
			self.onScroll      = function (){};
			self.scroll  = function(){};
			self.scrollAmount  = 5;
			self.scrollSpeed   = 30;
			self.disabled      = false;
			var toWindowTop  = 0;
			var toWindowLeft = 0;
			
			//private functions
			var initialize = function() {
				var c = _components;
				var d = _dimensions;
				var g = s.getDimensions();
				c.up     = findComponent("ScrollbarUp", o);
				c.down   = findComponent("ScrollbarDown", o);
				c.track  = findComponent("ScrollbarTrack", o);
				c.handle = findComponent("ScrollbarHandle", $(c.track));
				//获取滚动栏和滚动槽的宽高
				d.trackTop     = findOffsetTop(c.track);
				d.trackLeft    = findOffsetLeft(c.track);
				
				d.trackHeight  = c.track.offsetHeight;
				d.trackWidth  = c.track.offsetWidth;
				d.handleHeight = c.handle.offsetHeight;
				d.handleWidth = c.handle.offsetWidth;
				d.x = 0;
				d.y = 0;
				if (_hasTween) t.apply(self);
				if(scrollPosition == "y"){
					//兼容firefox的滚轮事件， by lhm
					$(s.getContent()).unbind("mousewheel");
					$(s.getContent()).unbind("DOMMouseScroll"); //firfox 滚轮事件
					$(s.getContent()).bind("mousewheel", scrollbarWheel);
					$(s.getContent()).bind("DOMMouseScroll", scrollbarWheel); //firfox 滚轮事件
				}
				$(o).bind( "mousedown", scrollbarClickPrimer);
				self.reset();
			};
			
			var findOffsetTop = function (o) {
				var t = 0;
				if (o.offsetParent) {
					while (o.offsetParent) {
						t += o.offsetTop;
						o  = o.offsetParent;
					}
				}
				return t;
			};
			var findOffsetLeft = function(o) {
				var t = 0;
				if (o.offsetParent) {
					while (o.offsetParent) {
						t += o.offsetLeft;
						o  = o.offsetParent;
					}
				}
				return t;
			};
			var findComponent = function(c, o) {
				var kids = o.children();
				for (var i = 0; i < kids.length; i++) {
					if (kids[i].className && kids[i].className.indexOf(c) >= 0) {
						return kids[i];
					}
				}
			};
			/*
				滚动条滚动的核心算法,p是滚动方向
			*/
			var scroll = function (y, p,time) {

				scrollPosition=p||scrollPosition;
				var track;
				if(scrollPosition == "y"){
					track  = findComponent("ScrollbarTrack", self.$LeftyScrollBarOne);
				}
				else if(scrollPosition == "x"){
					track  = findComponent("ScrollbarTrack", self.$LeftxScrollBar);	
				}
				var handle = findComponent("ScrollbarHandle", $(track));
				var trackHeight  = track.offsetHeight;
				var trackWidth  = track.offsetWidth;
				var handleHeight = handle.offsetHeight;
				var handleWidth = handle.offsetWidth;
				if(scrollPosition == "y"){
					
					var theight = s.getContent().offsetHeight;
					var vheight = $(s.getObj()).height();
					var ratio = (theight - vheight) / (trackHeight - handleHeight);
					
					if(y>0 && y <(trackHeight - handleHeight)){
						self.isScrollToBottom = false;
					}
					else if (y <= 0){
						y = 0;
					} 
					else{
						y = trackHeight - handleHeight;
						if(self._settings.scrollToBottomCallback && !self.isScrollToBottom){
							if(typeof self._settings.scrollToBottomCallback=="function"){
								self.isScrollToBottom = true;
								self._settings.scrollToBottomCallback();
							}
						}
					}
					
					//滚动杆的移动
					$(handle).css("_ysp_top",y);
					_dimensions.y = y;
					self.Y=_dimensions.y;
					//内容的移动
					s.scrollTo(0,Math.round(_dimensions.y * ratio),scrollPosition,time);
					self.onScroll();
				}
				
				else if(scrollPosition == "x"){
					var twidth = s.getContent().offsetWidth;
					var vwidth = $(s.getObj()).width();
					var ratio = (twidth - vwidth) / (trackWidth - handleWidth);
					
					if (y < 0) y = 0;
					if (y > trackWidth - handleWidth)
						y = trackWidth - handleWidth;
					$(handle).css("left",y);
					_dimensions.x = y;
					self.X=_dimensions.x;
					s.scrollTo(Math.round(_dimensions.x * ratio),0,scrollPosition,time);
					self.onScroll();	
				}
			};
			//!!!!!!!!!!!!!!!!!!!!
			self.scroll=scroll;
			
			var scrollbarClickPrimer = function (e) {
				$(".calendar").hide();
				//if (self.disabled) return false;
				e = e?e:event;
				if (!e.target) e.target = e.srcElement;
				scrollbarClick(e.target.className, e);
			};
			var scrollbarClick = function (c, e) {
				var d  = _dimensions;
				var t  = _temporary;
				
				//cPosition:鼠标距离document顶部的高度（考虑窗口自身滚动距离）
				//e.clientY : 鼠标距离文档顶部 高度 
			   var cPosition = e.clientY +$(window).scrollTop();
				if(scrollPosition == "x"){
					 cPosition = e.clientX + $(window).scrollLeft();
				}
				if (c.indexOf("ScrollbarUp") >= 0)
					startScroll(-self.scrollAmount);
				if (c.indexOf("ScrollbarDown") >= 0) 
					startScroll(self.scrollAmount);
				if (c.indexOf("ScrollbarTrack") >= 0)
					if(scrollPosition == "y"){
						if (_hasTween) self.tweenTo((cy - d.trackTop - d.handleHeight / 2) * _ratio);
						else scroll(cPosition - d.trackTop - d.handleHeight / 2);	
					}
					else if(scrollPosition == "x"){
						if (_hasTween) self.tweenTo((cy - d.trackLeft - d.handleWidth / 2) * _ratio);
						else scroll(cPosition - d.trackLeft - d.handleWidth / 2);		
					}
				//findOffsetTop(_components.handle) ： scrollTrack距离文档顶部的高度：90px
				if (c.indexOf("ScrollbarHandle") >= 0) {
					if(scrollPosition == "y"){
						toWindowTop = $(window).scrollTop()- findOffsetTop(_components.track);
						//鼠标down时，鼠标据滚动条顶部的距离高度
						t.grabPoint = cPosition - findOffsetTop(_components.handle); 
						$(document).bind("mousemove", scrollbarDrag);
					}else {
						toWindowLeft = $(window).scrollLeft()- findOffsetLeft(_components.track);
						t.grabPoint = cPosition - findOffsetLeft(_components.handle);
						$(document).bind("mousemove", scrollbarDrag);
					}
				}
				t.target = e.target;
				t.select = document.onselectstart;
				document.onselectstart = function (){ return false; };
				self.onMouseDown(e.target, c, e);
				$(document).bind("mouseup click", stopScroll);
			};
			
		var scrollbarDrag = function (e) {
				e = e?e:event;
				var d = s.getDimensions();//_dimensions;
				var v;
				if(scrollPosition == "y"){
					//====cPosition:鼠标距离document顶部的高度（考虑窗口自身滚动)
					//findOffsetTop(_components.track) 距离文档顶部的距离，定值90
					v = e.clientY + toWindowTop;
					if (v >= d.trackHeight - d.handleHeight + _temporary.grabPoint){
						v = d.trackHeight - d.handleHeight; 
					}
					else if (v <= _temporary.grabPoint){
						v = 0;
					}
					else{
						v = v - _temporary.grabPoint;
					}
				}
				else if(scrollPosition == "x"){
					v = e.clientX + toWindowLeft;
					if (v >= d.trackWidth - d.handleWidth + _temporary.grabPoint){
						v = d.trackWidth - d.handleWidth;
					}
					else if (v <= _temporary.grabPoint){
						v = 0;
					}
					else{
						v = v - _temporary.grabPoint;
					} 
				}
				scroll(v);
			};
		//滚轮事件,只支持垂直滚动	
		var scrollbarWheel = function (e) {
			    $(".DroplistOption").hide();
			    $(".calendar").hide();
			
                if (self.disabled) return false;
				e = e ? e : event;
				e.preventDefault();
				var dir = 0;
				//判断滑轮的方向
				if(e.originalEvent.detail){  //firefox使用
					if (e.originalEvent.detail == -3) dir = -1;
					if (e.originalEvent.detail == 3) dir = 1;
				}
				else if(e.originalEvent.wheelDelta){ //firefox之外的其他浏览器使用
					if (e.originalEvent.wheelDelta >= 120) dir = -1;
					if (e.originalEvent.wheelDelta <= -120) dir = 1;
				}
				self.scrollBy(dir * 20,"y");
				//m2m 项目需要，添加删除日历空间弹窗
				if($(this).parent().hasClass("itHasDateTimeCtrl")){//这里的this是scrollbar_container_inner的dom对象
					$("div.dateTime").remove();//删除日历控件弹窗
				}
			    e.returnValue = false;
				return false;
			};
		var startScroll =	function (y) {
				_temporary.disty = y;
				_timer = window.setInterval(function () {
					self.scrollBy(_temporary.disty);
				}, self.scrollSpeed);
			};
		var stopScroll = function  (e) {
				e = e?e:event;
				$(document).unbind("mousemove", scrollbarDrag);
				$(document).unbind("mouseup", stopScroll);
				document.onselectstart = _temporary.select;
				if (_timer) window.clearInterval(_timer);
				
				self.onMouseUp(_temporary.target, _temporary.target.className, e);
			};
		//public functions
		self.reset = function () {
			var d = _dimensions;
			var c = _components;
			var g = s.getDimensions();
			//重新设置滚动条中bar的高度或宽度
			if(scrollPosition == "y"){
				var handleHeight = parseInt(d.trackHeight-(g.theight - g.vheight)/5-20);
				if(handleHeight<30){
					handleHeight =30;
				}
				self.$handleTwo.css("height",handleHeight);
				//一定要用outerHeight（）
				d.handleHeight = self.$handleTwo.outerHeight(); 
			}
			else if(scrollPosition == "x"){
				var handleWidth = parseInt(d.trackWidth-(g.twidth - g.vwidth)/5-20);
				if(handleWidth<30){
					handleWidth = 30;
				}
				self.$handleOne.css("width",handleWidth);
				//一定要用outerWidth（）
				d.handleHeight = self.$handleTwo.outerWidth();
			}
			//计算滚动条滚动的距离和内容滚动距离之间的比例
			if(scrollPosition == "y"){
				_ratio = (g.theight - g.vheight) / (d.trackHeight - d.handleHeight);
			}
			else if(scrollPosition == "x"){
				_ratio = (g.twidth - g.vwidth) / (d.trackWidth - d.handleWidth);
			}
			c.handle.ondragstart = function (){ return false; };
			c.handle.onmousedown = function (){ return false; };
			$(c.handle).css("_ysp_top","0px");
			d.y = 0;
			
			s.reset();
			scroll(0);
			if (g.theight < g.vheight) {
				self.disabled = true;
				o.className  += " ScrollbarDisabled";
			}
		};
		self.scrollTo = function (y,p,time) {
			scroll(y / _ratio,p,time);
		};
		self.scrollBy = function (y,p,time) {
			scrollPosition=p||scrollPosition;
			if(scrollPosition == "y"){
				scroll((s.getDimensions().y + y) / _ratio,p,time);
			}
			else if(scrollPosition == "x"){
				scroll((s.getDimensions().x + y) / _ratio,p,time);
			}
		};
		self.swapContent = function (n, w, h) {
			o = n;
			s.swapContent(o, w, h);
			initialize();
		};
		self.disable = function () {
			self.disabled = true;
			o.className  += "ScrollbarDisabled";
		};
		self.enable = function () {
			self.disabled = false;
			o.className = o.className.replace(/Scrollbar\-Disabled/, "");
		};
		self.getContent = function () {
			return s.getContent();
		};
		self.getComponents = function () {
			return _components;
		};
		self.getDimensions = function () {
			var d = s.getDimensions();
			d.trackHeight  = _dimensions.trackHeight;
			d.handleHeight = _dimensions.handleHeight;
			 d.trackWidth=_dimensions.trackWidth;
			 d.handleWidth=_dimensions.handleWidth;
			return d;
		};
		
			initialize();
		}
	
	NS.DefaultScroll = DefaultScroll;	
})(ucd);

//滚动时候需要删去悬浮的dateTime窗口
/*
 //2015-1-22 m2m项目更改
 //由于滚动条内容区出现了dateTime组件，在滚动过程中不会消失，所以做如下更改
 第638行~641行: 加入如下代码
 //m2m 项目需要，添加删除日历空间弹窗，只需要在class='scrollbar_container'的节点上加上itHasDateTimeCtrl类就可以删除了
 if($(this).parent().hasClass("itHasDateTimeCtrl")){//这里的this是scrollbar_container_inner的dom对象
 	$("div.dateTime").remove();//删除日历控件弹窗
 }
*/