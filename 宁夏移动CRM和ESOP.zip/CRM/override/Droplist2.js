var UCD = UCD || {Core:jQuery};
/**模拟html select组件，并提供丰富的设置\方式。
 *  包括样式，事件，每个option项的定制。支持多选和单选下拉菜单
 * @id Droplist
 */
function preventScroll(ele){
    var _this = ele;
    if(navigator.userAgent.indexOf("Firefox")>0){
        _this.addEventListener('DOMMouseScroll',function(e){
            _this.scrollTop += e.detail > 0 ? 20 : -20;
            e.preventDefault();
        },false);
    }else{
        _this.onmousewheel = function(e){
            e = e || window.event;
            _this.scrollTop += e.wheelDelta > 0 ? -20 : 20;
            return false;
        };
    }
    return this;
}

(function(ucd,$){
	var COUNT = 0;
	ucd.Droplist = function(container, data, onCreateItem, optionClass){
		this._settings = $.extend({
			container:container,
			data:data,
			inputEnable:false,
			isSingle:true,
			onValueChange:null,
			onCreateItem:onCreateItem,
			optionClass:optionClass
		},{});
		
		_initDom(this);
		_initEvent(this);
	}

	//初始化dropList
	function _initDom(self){
		var settings = self._settings;
		self.hidden = true;
		self.itemsArray = [];
		var uuid = self.uuid = createMarker("udrop");
		self.$container = validateParamType(settings.container);
		self._settings.width = self.$container.width() != 0 ? self.$container.width() : self._settings.width;
		self.$dom = $("<div class='Droplist' data-uuid='"+uuid+"'/>").appendTo(self.$container);
		self.$header = $("<div class='DroplistHeader'/>");
        if(settings.inpuEnable){
            self.$input = $("<input type='text' class='inputbox' />").appendTo(self.$header);
        }else{
            self.$input = $("<input type='text' readonly='readonly' unselectable='on' onfocus='this.blur()' class='inputbox' />").appendTo(self.$header);
        }
		self.$trigger = $("<span class='trigger'/>").appendTo(self.$header);
		self.$options = $("<div  class='DroplistOption' data-uuid='"+uuid+"'><ul></ul></div>").appendTo(document.body);//下拉选项
		if(settings.optionClass) self.$options.addClass(settings.optionClass);
		if(self.$container.hasClass("searchDrop")) {
			self.$options.addClass("searchDropOption");
		}
		self.$optionUl = self.$options.children("ul");
		self.$dom.append(self.$header);
		self.setData(settings.data);
        preventScroll(self.$options.get(0));
	}
	function _initEvent(self){
		self.$header.bind("mousedown" ,function(){
			var display = self.$options.css("display");
			if(display == "none"){
				var left = self.$dom.offset().left;
				var _ysp_top = self.$dom.offset()._ysp_top+self.$dom.outerHeight(true);
				var width = self.$dom.outerWidth(true);
                $(".DroplistHeader").removeClass("blueBorder");
                $(".DroplistHeader").removeClass("down");
                $(".DroplistOption").hide();
                self.$header.addClass("down");
				self.$options.css({"left":left,"_ysp_top":_ysp_top,"width":self._settings.optionClass?width-2:width-4}).show();
				$(this).parent().addClass("blueBorder");
			}else{
				$(this).parent().removeClass("blueBorder");
                self.$header.removeClass("down");
                $(".DroplistHeader").removeClass("blueBorder");
                $(".DroplistHeader").removeClass("down");
                $(".DroplistOption").hide();
				self.$options.hide();
			}
            return false;
		});

		//点选项
		self.$options.delegate(".dropItem","mousedown",function(e){
			var target = e.target;
			var $target = $(target);
			var index = $(this).index();
			_select(self,index);
            return false;
		});
		var timeStamp=new Date();//Date.valueOf();
		//点文档空白处隐藏
        self.$options.bind("mousedown."+timeStamp,function(e){
            return false;
        });
		$("body").unbind("mousedown."+timeStamp).bind("mousedown."+timeStamp,function(e){
			var $target = $(e.target);
		//	if( $target.closest(".Droplist")[0] != self.$dom[0] && $target.closest(".DroplistOption")[0] != self.$options[0] ){
                $(".DroplistOption").hide();
                $(".DroplistHeader").removeClass("blueBorder");
                $(".DroplistHeader").removeClass("down");
				self.$options.hide();
		//	}
		});
	}
	
	function _createItem(data,self,index){
		var settings = self._settings;
		var items = {};
		items.params = $.extend({
			key:"key",
			value:null,
			selected:false
		},data || {});
		items.index = index;
		items._key = items.params.value.replace(/</gim,"&lt;").replace(/>/gim,"&gt;");
		var multiple = this.multiple = !settings.isSingle;//多选模式
		var html = multiple ? ("<li class='dropItem' key='"+items.params.key+"'><ins></ins><span>"+items._key+"</span></li>") : ("<li class='dropItem' key='"+items.params.key+"'><span>"+items._key+"</span></li>")
		items.$li = $(html).appendTo(self.$optionUl);
		self.itemsArray.push(items);
		if(items.params.selected){
			_select(self,index);
		}
		if($.isFunction(self._settings.onCreateItem)){
			_callback(self._settings.onCreateItem,self,[items]);
		}
	}
	//选中
	function _select(self,index,isSelectAll){
		var li = self.$options.find("li:eq("+index+")");
		self.selectItemArray = [];
		if(self._settings.isSingle){   //单选
			self.$header.removeClass("blueBorder");
			self.$options.find("li").removeClass("selected");
			li.addClass("selected");
			self.$input.val(li.text());
            self.$input.attr("key",li.attr("key"));
			self.$options.hide();
            self.$header.removeClass("down");
			self.selectItemArray.push(li.text());	
		}else{
			if(isSelectAll == true){
				li.addClass("selected");
			}
			else if(isSelectAll == false){
				li.removeClass("selected");
			}else{
				var selected = li.hasClass("selected");
				if(selected){
					li.removeClass("selected");
				}else{
					li.addClass("selected");
				}
			}
			self.$options.find("li").each(function(){
				if($(this).hasClass("selected")){
					self.selectItemArray.push($(this).attr("key"));
				}
			});
			self.$input.val(self.selectItemArray.join(","));
		}
		if($.isFunction(self._settings.onValueChange)){
			_callback(self._settings.onValueChange,self,[self,self.itemsArray[index]]);
		}
	}
	function validateParamType(obj){
		if(!obj) return;
		if(typeof obj=="string"&&obj.indexOf("#")==-1&&obj.indexOf(".")==-1&&obj.indexOf(":")==-1&&$(obj).length == 0){
			obj = $("#"+obj);
		} else {
			obj = $(obj);
		}
		return obj;
	}
	
	//创建一个唯一标识
	function createMarker(pre){
		return pre+("00000000"+(++COUNT)).substr(-5);
	}
	
	ucd.Droplist.prototype = {
		init: function(){
			this.itemsArray = [];//清空子对象
			//清空DOM
			this.$optionUl.html("");
			//添加子对象
			for(var i=0;i<this.data.length;i++){
				this.addItem(this.data[i],i);
			}
		},
		//设置数据
		setData: function(data){
			var settings = this._settings;
			if(!data){
				return;
			}
			this.data = data;
		},
		/**
		 * 添加一条数据	
		 * @option:Object, 
		*/
		addItem: function(data,index){
			if(typeof index == "undefined"){
				index = this.data.length;
				this.data.push(data);
			}
			var item = _createItem(data,this,index);
		},
		/**
		 * 选中项	 根据标题选中对应item项
		 */
		selectItem : function(key){
			var settings = this._settings;
			for(var i=0;i<this.itemsArray.length;i++){
				if(this.itemsArray[i].params.key == key){
					_select(this,i);	
				}
			}
		},
		selectAll: function(flag){
			if(!this._settings.isSingle){
				for(var i=0;i<this.itemsArray.length;i++){
					_select(this,i,flag);	
				}	
			}
		},
		/**
		 * 设置输入框能否支持输入
		 * @isEnable Boolean
		 */
		enableInput: function(flag){
			this._inputEnable = flag;
			if(flag){
				this.$input.removeAttr("readonly");
			}else{
				this.$input.attr("readonly","true");
			}
		},
		enableSingle: function(flag){
			this._settings.isSingle = flag;	
		},
		setOnValueChange: function(fn){
			this._settings.onValueChange = fn;
		}
	}
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}

})(UCD,UCD.Core);