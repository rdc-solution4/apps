var UCD = UCD || {Core:jQuery};

(function(ucd,$){
	var _M = "Pages";
	var $doc = $(document);
	var COUNT = 0;
	
	var M = ucd[_M] = function(container,total,showing,showList,selectedPage,onSelect){
		this._settings = $.extend({
			container:document.body,
			bindEvents:{},
			selected:null,
			pages:0,//总页数
			page:1,//显示第几页
			showing:10,
			showList:[10,20,50,100],
			selectedPage:1,//默认在第几页
			onSelect:null//选中第几页时回调
		},{
			container:container,
			total:total,
			showing:showing,
			showList:showList,
			selectedPage:selectedPage,
			onSelect:onSelect
		});
		init(this);
	}
	
	M.ins = {};
	M.init = function(){
		$doc.undelegate(".uPages","click.upage").delegate(".uPages","click.upage",function(e){
			var target = e.target;
			var $target = $(target);
			var actived = M.actived;
			var ins = M.ins[$target.closest(".uPages").attr("data-uuid")];
			if(ins.isDisabled()){
				return;
			}
			//下拉箭头显隐
			if($target.is(".uShowlist .trigger")){
				if( actived ==ins ){
					hideSLP();
				} else {
					showSLP(ins);
				}
			}
			//页码
			else if($target.is(".ctrl .uPage")){
				var page = $target.text();
				ins.setSelection(page);
			}
			//上一页
			else if($target.is(".ctrls .prev")){
				ins.setSelection(ins.getSelection()-1);
			}
			//下一页
			else if($target.is(".ctrls .next")){
				ins.setSelection(ins.getSelection()+1);
			}
			//跳转
			else if($target.is(".pgo .trigger")){
				var $pgo = ins._settings.$goto.children(":text");
				var page = $pgo.val()-0;
				if(!isNaN(page)){
					ins.setSelection(page,function(ins,_page){
						page != _page && $pgo.val(_page);
					});
				}
			}

		}).undelegate(".uPages","mousedown.upage").delegate(".uPages","mousedown.upage",function(e){
			var target = e.target;
			var $target = $(target);
			$target.is(":not(:text)") && e.preventDefault();
		}).undelegate(".pgo :text","keyup.upage").delegate(".pgo :text","keyup.upage",function(e){
			if(e.keyCode == 13){
				var target = e.target;
				var $target = $(target);
				var ins = M.ins[$target.closest(".uPages").attr("data-uuid")];
				if(ins.isDisabled()){
					return;
				}
				var $pgo = $(this);
				var page = $pgo.val()-0;
				if(!isNaN(page)){
					ins.setSelection(page,function(ins,_page){
						page != _page && $pgo.val(_page);
					});
				}
			}
		}).undelegate(".pgo :text","focus.upage").delegate(".pgo :text","focus.upage",function(e){
			var target = e.target;
			var $target = $(target);
			var ins = M.ins[$target.closest(".uPages").attr("data-uuid")];
			if(ins.isDisabled()){
				$(this).blur();
			}
		});
		
		//点空白处隐藏下拉
		$doc.unbind("mousedown.hideSLP").bind("mousedown.hideSLP",function(e){
			var target = e.target;
			var $target = $(target);
			if( !$target.closest(".uPages")[0] && !$target.closest(".uslp")[0] ){
				hideSLP();
			}
		});
		
		//点下拉选项设置每页显示条数
		$doc.undelegate(".uslp > div","click.setshowing").delegate(".uslp > div","click.setshowing",function(e){
			var actived = M.actived;
			if(actived){
				actived.setShowing($(e.target).attr("data-showing")-0);
				actived.setSelection(1);
			}
			hideSLP();
		});
	}
	M.showList = {}//记录每页显示条数dom，同一个显示列表只创建一个dom，如，实例a、b showList都是[5,10,15]，则只创建一次dom，保存在M.showList.i5_10_15
	M.actived = null;//处于激活的实例
	M.init();
	
	var FN = M.prototype;
	//设置每页显示数量
	FN.setShowing = function(showing,callback){
		debugger;
		var settings = this._settings;
		var showList = settings.showList;
		var index = $.inArray(showing,showList);
		if( index == -1 ){
			if(console && console.error && console.trace){
				console.error("页码不在列表中。");
				console.trace();
			} else {
				alert("页码不在列表中。");
			}
			return;
		}
		var oldShowing = settings.showing;
		//初始化后，showing必须有改变才进行以下操作
		if( settings.hasInit.state() !== "pending" && oldShowing === showing ){
			return;
		}
		settings.showing = showing;
		settings.pages = Math.ceil(settings.total/settings.showing);
		settings.$showList.children(".v").text(showing+"条");
		selectShowList(this,index);
		settings.page = null;//重置当前页。必须的步骤
		/*//初始化时不强制显示第一页
		if( settings.hasInit.state() !== "pending" ){
			this.setSelection(1);
		}*/
		_callback(callback,this,[this,this.getSelection()]);
	}
	//设置数据总条数
	FN.setTotal = function(total,callback){
		total = total - 0;
		if(isNaN(total)){
			return;
		}
		var settings = this._settings;
		settings.total = total;
		settings.pages = Math.ceil(settings.total/settings.showing);
		settings.$total.html("共<span>"+total+"</span>条");
		_callback(callback,this,[this,this.getSelection()]);
	}
	//显示第几页
	//callback传null时不会执行任何回调
	//传入函数时执行函数，
	//否则执行onSelect参数
	FN.setSelection = function(page,callback){
		var settings = this._settings;
		page -= 0;
		if( page <= 1 ){
			page = 1;
		} else if( page >= settings.pages ){
			page = settings.pages;
		}
		var oldPage = this._settings.page;
		//初始化后，page必须有改变才进行以下操作
		settings.haveNoChange = false;
		if( settings.hasInit.state() !== "pending" && oldPage === page ){
			settings.haveNoChange = true;
			return;
		}
		settings.$prev.removeClass("disabled");
		settings.$next.removeClass("disabled");
		(page <= 1) ? settings.$prev.addClass("disabled") : ((page >= settings.pages) ? settings.$next.addClass("disabled") : null );
		if( settings.pages == 1 ){
			settings.$prev.addClass("disabled");
			settings.$next.addClass("disabled");
		}
		this._settings.page = page;
		setPagesListHTML(this);
		callback = ( callback === null ) ? null : ( $.isFunction(callback) ? callback : settings.onSelect );
		_callback(callback,this,[this,page]);
	}
	FN.getSelection = function(){
		return this._settings.page;
	}
	//绑定事件
	FN.bind = function(type,fn,handlerData){
		if(!$.isFunction(fn) && $.type(type) != "string"){
			return;
		}
		var self = this;
		var settings = this._settings;
		var bindEvents = settings.bindEvents;
		//找出对应type事件的勾子
		var evt = bindEvents[type];
		//没绑定过事件，则先绑定
		if(!evt){
			//返回false时，停止执行之后绑定的事件
			//同一事件不允许多次绑定
			evt = bindEvents[type] = {
				length:0,//记录已绑回调数量
				handler:$.Callbacks("unique stopOnFalse")
			};
			settings.$dom.bind(type,handlerData,function(e){
				if(!self.isDisabled()){
					evt.handler.fireWith(null,[e,self]);
				}
			});
		}
		if(!evt.handler.has(fn)){
			evt.length++;
			evt.handler.add(fn);
		}
	}

	FN.unbind = function(type,fn){
		if($.type(type) != "string" || (fn && !$.isFunction(fn))){
			return;
		}
		var settings = this._settings;
		var bindEvents = settings.bindEvents;
		//找出对应type事件的勾子
		var evt = bindEvents[type];
		//未绑定过type对应的事件
		if(!evt){
			return;
		}
		//传入了fn参数
		if(fn){
			//清空对应的回调，并将计数器-1
			if(evt.handler.has(fn)){
				evt.handler.remove(fn);
				evt.length--;
			}
		} else {
			evt.handler.empty();//清空所有回调
			evt.length = 0;
		}
		//当回调个数为0时，解绑事件
		if( evt.length == 0 ){
			delete bindEvents[type];
			this._settings.$dom.unbind(type);
		}
	}

	FN.trigger = function(type){
		this._settings.$dom.trigger(type,[this,this._settings.$dom,this.isChecked()]);
	}

	FN.enable = function(flag){
		var settings = this._settings;
		var $dom = settings.$dom;
		if( flag !== false ){
			$dom.removeClass("disabled");
			settings.disabled = false;
		} else {
			$dom.addClass("disabled");
			settings.disabled = true;
		}
	}

	FN.isDisabled = function(){
		return this._settings.disabled;
	}
		
	//执行一个回调
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}
	
	//创建一个唯一标识
	function createMarker(pre){
		return pre+("00000000"+(++COUNT)).substr(-5);
	}

	function init(ins){
		var settings = ins._settings;
		settings.hasInit = $.Deferred();
		var $container = settings.$container = $(settings.container).eq(0);
		var mark = createMarker("upages");
		var $dom = settings.$dom = $('<div class="uPages" data-uuid="'+mark+'"/>');
		settings.$showList = $("<div class='uShowlist'><span class='v'></span><span class='trigger'></span></div>").appendTo($dom);
		setShowListPop(ins,settings.showList);
		settings.$total = $("<div class='uTotal'/>").appendTo($dom);
		settings.$ctrl = $("<div class='ctrls'><div class='prev'></div><div class='ctrl'></div><div class='next'></div></div>").appendTo($dom);
		settings.$goto = $("<div class='pgo'><span>跳转</span><input type='text' value='1'/><span class='trigger'></span></div>").appendTo($dom);
		settings.$prev = settings.$ctrl.children(".prev");
		settings.$next = settings.$ctrl.children(".next");
		ins.setTotal(settings.total);
		ins.setShowing(settings.showing);
		ins.setSelection(settings.selectedPage);
		$dom.appendTo($container);
		M.ins[mark] = ins;
		settings.hasInit.resolve();
	}
	//获取showlist对应的弹出层
	function getShowListPop(showList){
		var n = "i"+(showList.join("_"));
		return M.showList[n];
	}
	//设置每页显示条数列表
	function setShowListPop(ins,showList){
		var settings = ins._settings;
		settings.showList = showList;
		var $slp = getShowListPop(showList);
		if(!$slp){
			var len = showList.length;
			var slp = "<div class='uslp'>"
			for(var i = 0; i < len; i++){
				slp += "<div data-showing='"+showList[i]+"'>"+showList[i]+"条</div>";
			}
			slp += "</div>";
			$slp = $(slp).appendTo("body");
			M.showList["i"+showList.join("_")] = $slp;
		}
	}
	//选中样式
	function selectShowList(ins){
		var settings = ins._settings;
		var $slp = getShowListPop(ins._settings.showList);
		var index = $.inArray(settings.showing,settings.showList);
		$slp.children().removeClass("selected").eq(index).addClass("selected");
	}
	//显示
	function showSLP(ins){
		var settings = ins._settings;
		var $slp = getShowListPop(settings.showList);
		var $showList = settings.$showList;
		var offset = $showList.offset();
		selectShowList(ins);
		$slp.width(settings.$showList.innerWidth()).css({
			left:offset.left,
			_ysp_top:offset._ysp_top + $showList.outerHeight()
		}).show();
		M.actived = ins;
	}
	function hideSLP(){
		//var settings = ins._settings;
		//var $slp = getShowListPop(settings.showList);
		//$slp.hide();
		$(document.body).children(".uslp").hide();
		M.actived = null;
	}
	//设置显示页码
	function setPagesListHTML(ins){
		var settings = ins._settings;
		var pages = settings.pages;
		var page = settings.page;
		var html = "";
		if( pages <= 8 ){
			for(var i = 1; i <= pages; i++){
				html += "<span class='"+(i==page?"selected ":"")+"uPage'>"+i+"</span>";
				//html += "<span"+( i==page ? " class='selected'":"")+">"+i+"</span>";
			}
		} else if( page <= 3 ){
			for(var i = 1; i <= 5; i++){
				html += "<span class='"+(i==page?"selected ":"")+"uPage'>"+i+"</span>";
			}
			html += "<span class='thn'>…</span>";
			html += "<span class='uPage'>"+pages+"</span>";
		} else if( page >= pages - 2 ) {
			html += "<span class='uPage'>1</span>";
			html += "<span class='thn'>…</span>";
			for(var i = pages - 4; i <= pages; i++){
				html += "<span class='"+(i==page?"selected ":"")+"uPage'>"+i+"</span>";
			}
		} else {
			html += "<span class='uPage'>1</span>";
			html += "<span class='thn'>…</span>";
			for(var i = page - 1; i <= page + 2; i++){
				html += "<span class='"+(i==page?"selected ":"")+"uPage'>"+i+"</span>";
			}
			html += "<span class='thn'>…</span>";
			html += "<span class='uPage'>"+pages+"</span>";
		}
		settings.$ctrl.children(".ctrl").html(html);
	}

})(UCD,UCD.Core);