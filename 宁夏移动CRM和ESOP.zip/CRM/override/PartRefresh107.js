function getXMLHTTP(){
	if(typeof ActiveXObject!="undefined"){
		
		try{
			return new ActiveXObject("Microsoft.XMLHTTP");
		}catch(a){
			//alert(a);	
		}
	}

	if(typeof XMLHttpRequest!="undefined"){
		
		return new XMLHttpRequest();
	}
	return null;
}



 /*
 *返回XML
 *url			提交的路径
 *parameters	参数对（例如：param1=v1&param2=v2）
 *callback		回调函数
 */
function getXML(url, parameters, callback) 
{
	var xmlhttp = newXMLHttpRequest();
	
	if(xmlhttp == null)
	{
		alert("初始化失败");
		return ;
	}
	var async = false;
	if (arguments.length == 3)
	{ 
		async=true;
	}
	xmlhttp.open("POST", url, async);
	
	xmlhttp.setRequestHeader("Cache-Control","no-cache");
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	if(async)
	{ 
		var f = function()
		{
			if (xmlhttp.readyState==4)
			{
				callback(xmlhttp.responseXML);
			}
		}
		xmlhttp.onreadystatechange = f;
	}
	parameters=encodeURI(parameters);
	parameters=encodeURI(parameters);
	xmlhttp.send(parameters);
	
	if (!async)
	{
		var obj = xmlhttp.responseXML;
		if(typeof(obj) =='string' || typeof(obj) =='function' || typeof(obj) =='object')
		{
			return xmlhttp.responseXML;
		}
	}
}

/*
 * Returns a new XMLHttpRequest object, or false if this browser
 * doesn't support it
 */
function newXMLHttpRequest() {

  var xmlreq = false;

  if (window.XMLHttpRequest) {

    // Create XMLHttpRequest object in non-Microsoft browsers
    xmlreq = new XMLHttpRequest();

  } else if (window.ActiveXObject) {

    // Create XMLHttpRequest via MS ActiveX
    try {
      // Try to create XMLHttpRequest in later versions
      // of Internet Explorer

      xmlreq = new ActiveXObject("Msxml2.XMLHTTP");

    } catch (e1) {

      // Failed to create required ActiveXObject

      try {
        // Try version supported by older versions
        // of Internet Explorer

        xmlreq = new ActiveXObject("Microsoft.XMLHTTP");

      } catch (e2) {

        // Unable to create an XMLHttpRequest with ActiveX
      }
    }
  }
	
  return xmlreq;
}
  
/**
 *url			提交的路径
 *parameters	参数对（例如：param1=v1&param2=v2）
 *callback		回调函数
 *
 *如果要传输的数据过长需要将数据组织成参数对的形式传到parameters
 *服务器端程序在取数据时候需要增加UTF-8编码，例如
 *String curValue = java.net.URLDecoder.decode(request.getParameter(param), "UTF-8");
 *修改人：wangzhaowu 20070724
 */
function execService(url, parameters,callback) {
	var xmlhttp = newXMLHttpRequest();
	
	if(xmlhttp == null){
		alert("初始化失败");
		return ;
	}
	var async = false;
	if (arguments.length == 3){ 
		async=true;
	}
	xmlhttp.open("POST", url, async);
	//修改url超长的问题 add by wangzhaowu 20070724
	xmlhttp.setRequestHeader("Cache-Control","no-cache");
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	if (async) { 
		var f = function() {
			if (xmlhttp.readyState==4) {
				callback(xmlhttp.responseText);
			}
		}
		xmlhttp.onreadystatechange = f;
	}
	parameters=encodeURI(parameters);
	parameters=encodeURI(parameters);
	xmlhttp.send(parameters);
	
	if (!async) {
	    var obj = xmlhttp.responseText;
		if(typeof(obj) =='string' || typeof(obj) =='function' || typeof(obj) =='object')
		{
		  return xmlhttp.responseText;
		}
	}
}

function refresh(url,freshID){
	if(url == null || url == "" || freshID == null || freshID == ""){
		alert("参数输入不全，无法进行局部刷新");
		return false;
	}

	var refreshContent = execService(url,"");
	var freshObj  = document.getElementById(freshID);
	//alert(freshObj.outerHTML);
	freshObj.innerHTML = refreshContent;

}

function execService_xml(xmlDataUrl){
	var ob = new ActiveXObject("Microsoft.XMLDOM"); //创建一个微软的ActiveX控件XMLDOM
	ob.async = false;  //设置异步状态标志为假。
	ob.load(xmlDataUrl);
}
function appendParamForUrl(url,paramStr,message){
    if(url==""){
        url=obtainWebContextPath("ngcustcare")+"/common/getIsInnerBoss.action?act=getIsInnerBoss";
    }
    var getValue=execService(url);
    var returnValue="";
    if(confirm(message)){
        returnValue=paramStr+"="+getValue;
    }else{
        return "";
    }
    return returnValue;
}

/**
 * BME 手动调用trigger时 同步调用
 * @param obj 对象是FireTag
 * @return
 */
function doSync(obj)
{
    obj.options["async"]=false;
    return true;	
} 

/**
 * 利用BME的局部刷新render实现类AJAX效果
 * @param view  当前页面的路径，如：/WEB-INF/bundles/commonCommit/commitUsl.usl
 * @param targetid 需要刷新的区域，如：ngcommon_jsp_js
 * @param service 调用的service ,如#BMEAttr.elecWorkService.ifNeedPrintEvms('"+recType+"','"+servNumber+"')
 * @return
 * 注意，如果无需返回值，则view,targetid可以为空
 */
function execAjaxService(view,targetid,service)
{
	var j = new jBME.FireTag();
    j.setMode("render");
    
    if(view != null && view != '')
    {
    	j.setView(view);
    }	
		
	j.setTargetid(targetid);
	
	j.setOnbefore("doSync(this)");//同步
	j.setValidation(true);	
	
	j.setService(service);
	
	jBME.Fire.execute(j);
}

/**
 * BME瞬息会话和showModalDialog结合模拟AJAX
 * @param params 主要包含serviceBean 和 initMethod 此两项不可少
 * @return 返回结果值
 * 注意：不建议使用,作为execAjaxService的补充
 */
function execBMEService(params)
{
	var url = "business.action?BMEBusiness=bundles.showModalDialog&rand="+Math.random();
	url = url+"&"+params + "&view=/WEB-INF/bundles/common/execBMEService.usl"
	var _ysp_top = (window.screen.height-35-100)/2;
	var left = (window.screen.width-10-100)/2;
	var style = "status:no;help:no;dialogHeight:100px;dialogWidth:100px;dialogLeft:"+left+"px;dialogTop:"+_ysp_top+"px";
    var retVal = window.showModalDialog(url, window, style);
    return retVal;
}

/**
 * BME瞬息会话和showModalDialog结合模拟弹框
 * @param params 主要包含serviceBean 和 initMethod 此两项成对出现，view为必须参数
 * 
 * @return 返回结果值
 * 
 */
function showBMEModalDialog(params,style)
{
	var url = "business.action?BMEBusiness=bundles.showModalDialog&rand="+Math.random();
	url = url+"&"+params;	
    var retVal = window.showModalDialog(url, window, style);
    return retVal;
}

