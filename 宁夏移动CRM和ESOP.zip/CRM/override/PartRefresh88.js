function getXMLHTTP(){
	if(typeof ActiveXObject!="undefined"){
		
		try{
			return new ActiveXObject("Microsoft.XMLHTTP");
		}catch(a){
			//alert(a);	
		}
	}

	if(typeof XMLHttpRequest!="undefined"){
		
		return new XMLHttpRequest();
	}
	return null;
}
/*
 * Returns a new XMLHttpRequest object, or false if this browser
 * doesn't support it
 */
function newXMLHttpRequest() {

  var xmlreq = false;

  if (window.XMLHttpRequest) {

    // Create XMLHttpRequest object in non-Microsoft browsers
    xmlreq = new XMLHttpRequest();

  } else if (window.ActiveXObject) {

    // Create XMLHttpRequest via MS ActiveX
    try {
      // Try to create XMLHttpRequest in later versions
      // of Internet Explorer

      xmlreq = new ActiveXObject("Msxml2.XMLHTTP");

    } catch (e1) {

      // Failed to create required ActiveXObject

      try {
        // Try version supported by older versions
        // of Internet Explorer

        xmlreq = new ActiveXObject("Microsoft.XMLHTTP");

      } catch (e2) {

        // Unable to create an XMLHttpRequest with ActiveX
      }
    }
  }
	
  return xmlreq;
}
  
/**
 *url			提交的路径
 *parameters	参数对（例如：param1=v1&param2=v2）
 *callback		回调函数
 *
 *如果要传输的数据过长需要将数据组织成参数对的形式传到parameters
 *服务器端程序在取数据时候需要增加UTF-8编码，例如
 *String curValue = java.net.URLDecoder.decode(request.getParameter(param), "UTF-8");
 *修改人：wangzhaowu 20070724
 */
function execService(url, parameters,callback,addParameter) {
	
	
	parameters = ssoInit(parameters);

	var xmlhttp = newXMLHttpRequest();
	
	if(xmlhttp == null){
		alert("初始化失败");
		return ;
	}
	var async = false;
	if (arguments.length >= 3){ 
		async=true;
	}
	xmlhttp.open("POST", url, async);
	//修改url超长的问题 add by wangzhaowu 20070724
	xmlhttp.setRequestHeader("Cache-Control","no-cache");
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	if (async) { 
		var f = function() {
			if (xmlhttp.readyState==4) {
				if(addParameter)
				{
					callback(xmlhttp.responseText, addParameter);
				}
				else
				{
					callback(xmlhttp.responseText);
				}
			}
		}
		xmlhttp.onreadystatechange = f;
	}
	parameters=encodeURI(parameters);
	parameters=encodeURI(parameters);
	xmlhttp.send(parameters);
	
	if (!async) {
	    var obj = xmlhttp.responseText;
		if(typeof(obj) =='string' || typeof(obj) =='function' || typeof(obj) =='object')
		{
		  return xmlhttp.responseText;
		}
	}
}

/**
* 单点登录初始化
* @remark create w00190463 2013-11-12 bug_53546_for_OR_huawei_201309_238
*/
function ssoInit(parameters)
{
	if(parameters == null || parameters == "")
	{
		return 	"noCrmSSO=1";
	}
	
	parameters += "&noCrmSSO=1";
	return parameters;
}

function refresh(url,freshID){
	if(url == null || url == "" || freshID == null || freshID == ""){
		alert("参数输入不全，无法进行局部刷新");
		return false;
	}

	var refreshContent = execService(url,"");
	var freshObj  = document.getElementById(freshID);
	//alert(freshObj.outerHTML);
	freshObj.innerHTML = refreshContent;

}

function execService_xml(xmlDataUrl){
	var ob = new ActiveXObject("Microsoft.XMLDOM"); //创建一个微软的ActiveX控件XMLDOM
	ob.async = false;  //设置异步状态标志为假。
	ob.load(xmlDataUrl);
}

/**
 * 获取顶级窗口
 */ 
function obtainTopWindowByWin(winObj)
{
    try
    {
        if (winObj.dialogArguments && !winObj.dialogArguments.closed && winObj.dialogArguments._ysp_top && !winObj.dialogArguments._ysp_top.closed)
        {
            return obtainTopWindowByWin(winObj.dialogArguments._ysp_top);
        }
        else if (winObj.opener && !winObj.opener.closed && winObj.opener._ysp_top && !winObj.opener._ysp_top.closed)
        {
            return obtainTopWindowByWin(winObj.opener._ysp_top);
        }
    }
    catch (e)
    {
    }
    return winObj;
}
/**
 * 获取应用上下文根
 */ 
function obtainWebContextPath(pathStr)
{
    var rtnContextPath = "/" + pathStr;
    try
    {
        var topWin = obtainTopWindowByWin(window._ysp_top);
        if (topWin && topWin.getCrmWebContext)
        {
            rtnContextPath = topWin.getCrmWebContext(pathStr);
        }
    }
    catch (e)
    {
    }
    return rtnContextPath;
}
