function leftShortMenu() {
	
	this.init = function ($Scope, menus){
		var leftMenu = new leftShortMenu();
		if(menus){
			$Model = $Scope.$Model;
			var $Fire = $Scope.$Get("$Fire");
			var $Model = $Scope.$Model;
			$Fire({
				"service" : "/gadget/sm/SysParamAction/queryLeftShortMenuSize",
				"target" : "$Model.leftShortMenuSize"
			}, $Scope).onafter(function() {
					for(var index = 0;index<menus.length;index++){
						if(index < $Model.leftShortMenuSize){
							var liNodoDom = leftMenu.liNode(menus[index]);
							$("#leftMenu").append(liNodoDom);	
						}
					}
				});
		}
			
	};
	
	this.liNode = function(menu){
		if(menu){
			var imgUrl = menu.imgUrl;
			
			if(!imgUrl ||  imgUrl == ""){
				imgUrl = "resource.root/bes/sm/login/img/tool4v1.png";
			}
			
			var liNode = $("<li class = \"tool1\" id = \"" + menu.menuId +"\" style=\"background-image:url('"+ imgUrl +"')\"></li>");
			var divMask = $("<div class=\"tc-mask\"></div>");
			var divPopUp = $("<div class=\"tc-popup\"></div>");
			
			var aNode = this.create_A_Node(menu);
			
			if(menu.children){
				var div = $("<div></div>");			
				this.firstLevel(div,menu);
				divPopUp.append(div);
			}else{
				liNode.addClass("openwithtab");
				var span = '<span class="inlineTitle">' + escapeHtml(menu.name) + '</span>';
				divPopUp.addClass("tc-tip").html(span);	
				
						
				//divMask.attr({href:"#",destUrl:menu.menuUrl,innerId:menu.menuId,isHttps:menu.httpsFlag});
				
				liNode.append(aNode.html("").attr("name",escapeHtml(menu.name)));
			}
			divMask.append(divPopUp);
			
			liNode.append(divMask);
			
			return liNode;
		}
		return "";
	};
	
	this.firstLevel = function(parent, menu){
		if(menu){
			var firstNode = $("<div title='"+menu.name+"' class=\"fontH ft-h4 \"></div>");
			if(menu.menuUrl){
				
				var aNode = this.create_A_Node(menu);
				
				firstNode.append(aNode);
			}else{
				firstNode.append( escapeHtml(menu.name));
			}
			parent.append(firstNode);
			
			if(menu.children){
				var firstNodeSibling = $("<div class=\"tc-content \"></div>");
				
				for(var idx =0;idx<menu.children.length;idx++){
					this.secondLevel(firstNodeSibling,menu.children[idx]);
				}
				
				//firstNode.after(firstNodeSibling);
				parent.append(firstNodeSibling);
			}
		
		
		}
	};
	
	this.secondLevel = function(parent, menu){
		if(menu){
			var secondNode;
			if(menu.menuUrl){

				secondNode = $("<div class=\"clearfix\" title='"+menu.name+"'><div class=\"fontH ft-h5\"></div></div>");
				//<a href=\"#\" destUrl = \""+ menu.menuUrl +"\">" + menu.name + "</a>
				var aNode = this.create_A_Node(menu);
				secondNode.find(".fontH").append(aNode);
				
				
			}else{
				secondNode = $("<div class=\"clearfix\" title='"+menu.name+"'><div class=\"fontH ft-h5\">" + escapeHtml(menu.name) + "</div></div>");
			}
			if(menu.children){				
				var secondNodeSibling = $("<div class=\"mdSubTitle\"></div>").css("position","relative");
				
				for(var idx = 0 ;idx <menu.children.length;idx++){
					this.thirdLevel(secondNodeSibling,menu.children[idx]);
				}
				
				secondNode.append(secondNodeSibling);
			}
			
			parent.append(secondNode);
		}
	};
	
	this.thirdLevel = function(parent,menu){
		if(menu){
			var divHiden = $("<div title='"+menu.name+"'></div>").css({"width": "70px", "height": "20px", "overflow": "hidden", "text-overflow":"ellipsis","float":"left"});
			var nor = $("<nobr></nobr>");
			var aValue = this.create_A_Node(menu);
			nor.append(aValue);
			divHiden.append(nor);
			
			parent.append(divHiden);
		}
		
	};
	
	this.create_A_Node = function(menu){		
		var aValue =  $("<a></a>").attr({href:"#", innerId:menu.menuId}).append(escapeHtml(menu.name));
		aValue.data('destUrl', menu.menuUrl);
		aValue.data('isHttps', menu.httpsFlag);
		return aValue;
	};
};