function portalRightHeadMenu(){
	this.init = function(menus){
		if(menus){
			var topParent = $("#rightheadermenu");
			for(var idx = 0;idx<menus.length;idx++){
				var menu = menus[idx];
				if(menu.children){
					//���ӽڵ�
					var twoLevelNode = $("<div></div>").addClass("accountOpt");
					var firstChild = $("<div class=\"ao-droplist\"></div>");
					var imgChild = $("<img></img>").addClass("ao-header");
					
					if(menu.imgUrl){
						imgChild.attr("src",menu.imgUrl);
					}else{
						imgChild.attr("src","resource.root/bes/sm/login/img/displayMode1.png");
					}
					
					var lastChild = $("<div></div>").addClass("ao-popup");
					var lastChildInnerUl = $("<ul></ul>");
					
					this.childLevel(lastChildInnerUl,menu.children);
					
					lastChild.append(lastChildInnerUl);
					
					twoLevelNode.append(firstChild);
					twoLevelNode.append(imgChild);
					twoLevelNode.append(lastChild);
					
					topParent.append(twoLevelNode);
					
				}else{
					//û���ӽڵ�
					
					var imgUrl = menu.imgUrl;
					if(!imgUrl || imgUrl == ""){
						imgUrl = "resource.root/bes/sm/login/img/header2.png";
					}
					
					var oneLevelNode = $("<div></div>").addClass("headerMenu");
					var divHeadMenu = $("<div></div>").addClass("headerMenu0");
					var divNode = $("<div></div>").addClass("openwithtab").css("background","url(\"" + imgUrl +"\") no-repeat center");
					
					var aNode = this.create_A_Node(menu);
					
					aNode.attr("name",escapeHtml(menu.name)).html("");
					
					divNode.append(aNode);
					divHeadMenu.append(divNode);
					oneLevelNode.append(divHeadMenu);
					
					topParent.append(oneLevelNode);
				}
			}
			
			
		}
	};
	
	this.childLevel = function(parent,menus){
		for(var ind = 0;ind<menus.length;ind++){
			var childMenu = menus[ind];
			
			if(childMenu){			
				var liNode = $("<li></li>");
				if(childMenu.imgUrl){
					liNode.addClass("ao-lock").css("background","url(\"" + childMenu.imgUrl +"\") no-repeat center");
				}
		
				if(childMenu.menuUrl){
					var divHiden = $("<div></div>").css({"width": "70px", "overflow": "hidden", "text-overflow":"ellipsis"});
					var nor = $("<nobr></nobr>");
					var aValue = this.create_A_Node(childMenu);
					nor.append(aValue);
					divHiden.append(nor);
					
					liNode.append(divHiden);
				}else{
					liNode.html(escapeHtml(childMenu.name));
				}
				parent.append(liNode);
			}
			
		}
	};
	this.create_A_Node = function(menu){		
		var aValue =  $("<a></a>").attr({href:"#", innerId:menu.menuId}).append(escapeHtml(menu.name));
		aValue.data('destUrl', menu.menuUrl);
		aValue.data('isHttps', menu.httpsFlag);
		return aValue;
	};
};