var UCD = UCD || {Core:jQuery};
(function(ucd, $){
	/********************平台公用函数************************/
	//按id取元素
	function $id(id){
		return $("#"+id);
	}
	//按标签名取
	function $tagName(ele,tagName){
		if(ele instanceof $){
			ele = ele[0];
		}
		if(!tagName){
			tagName = "*";
		}
		if(!ele) return $();
		return $(ele.getElementsByTagName(tagName));
	}
	//取所有子元素
	function $children(ele){
		return $tagName(ele);
	}
	//替换jq find方法，解决IE7下效率问题
	function $find(context,selector){
		if(context instanceof $){
			context = context[0];
		}
		if(!context){
			return $();
		}
		var $child = $children(context);
		return $child.filter(selector);
	}
	
	//执行一个回调
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}
	/********************平台公用函数结束************************/
	var MIN =0,MAX = 100;
	//进度条样式
	function setBarStyle(ins,val,animation){
		var settings = ins._settings;
		var isVertical = settings.isVertical;
		//isGrow增长趋势
		//frameVal帧值
		//val最终值
		var set = function(ins,frameVal,val,isGrow){
			var settings = ins._settings;
			if((isGrow === true && frameVal > val) || (isGrow === false && frameVal < val)){
				frameVal = val;
				window.clearInterval(ins._growAni);
			}
			if(frameVal < MIN){
				frameVal = MIN;
			}
			if(frameVal > MAX){
				frameVal = MAX;
			}
			//var dot = self._number2Dot(newNumber);
			if( frameVal == 0 ){
				settings.$innerWrap.css(isVertical?{height:0}:{width:0});
			} else {
				var w = settings.$dom[isVertical?"outerHeight":"outerWidth"]() * frameVal/100;
				var min = parseInt(settings.$inner.css(isVertical?"padding-_ysp_top":"padding-left"))+1;
				if(w < min ){
					settings.$innerWrap.css(isVertical?{height:min}:{width:min});
				} else {
					settings.$innerWrap.css(isVertical?{height:frameVal+"%"}:{width:frameVal+"%"});
				}
			}
			settings.value = frameVal.toFixed(settings.fraction);
			_callback(settings.events.change,ins,ins);
		}
		
		settings.growAni && window.clearInterval(settings.growAni);
		if(animation){
			var step = settings.step;
			var change = Math.abs(val - ins.getValue());
			var frames = Math.ceil(change/step);//动画帧数
			var speed = 10;//帧时长
			var flag = val > settings.value;
			settings.growAni = window.setInterval(function(){
				var frameVal = flag ? (ins.getValue() - 0 + step) : (ins.getValue() - 0 - step);
				set(ins,frameVal,val,flag);
			},speed);
		} else {
			set(ins,val,val);
		}
	}
	//初始化
	function init(ins){
		var settings = ins._settings;
		settings.events = {};
		var $container = settings.$container = $(settings.container);
		var $dom = settings.$dom = $("<div class='processBar"+(settings.isVertical?" verticalProcessbar":"")+"'/>");
		var rounded = true;//v2版本有rounded参数，暂时强制设置成圆角
		var $outer = settings.$outer = $(rounded?"<div class='processBarOuter'><div class='processBarOuterStart'></div><div class='processBarOuterMid'></div><div class='processBarOuterEnd'></div></div>":"<div class='processBarOuter'><div class='processBarOuterMid'></div></div>");//外层
		var $innerWrap = settings.$innerWrap = $("<div class='processBarInnerWrap' style='"+(settings.isVertical?"height:0;":"width:0;")+"'></div>");
		var $inner = settings.$inner = $(rounded?"<div class='processBarInner'><div class='processBarInnerStart'></div><div class='processBarInnerMid'></div><div class='processBarInnerEnd'></div></div>":"<div class='processBarInner'><div class='processBarInnerMid'></div></div>");
		$innerWrap.append($inner);
		$outer.appendTo($dom);
		$innerWrap.appendTo($dom);
		var $text = settings.$text = $("<div class='processBarText'/>").appendTo($dom);//用来接收当前值
		$container.append($dom);
		//ins.setWidth(settings.width);
		//ins.setStep(settings.step);
		ins.setValue(settings.value);
	}
	
	ucd.ProcessBar = function(container, value, isVertical){
		this._settings = $.extend({
			container:document.body,
			value:0,
			dur:400,//动画耗时
			fraction:2,//分数位数
			step:1
		},{
			container:container,
			value:value,
			isVertical:isVertical
		});
		init(this);
	}
	
	ucd.ProcessBar.prototype = {
		constructor: ucd.ProcessBar,
		getValue: function(){
			return this._settings.value;
		},
		setValue: function(val){
			if( val < MIN ){
				val = MIN;
			} else if( val > MAX ){
				val = MAX;
			}
			setBarStyle(this,val,true);
		},
		/*setStep:function(step){
			if( step < MAX && step > MIN ){
				this._settings.step = step;
			}
		},*/
		setOnChanged:function(fn){
			if( $.isFunction(fn) ){
				this._settings.events.change = fn;
			}
		},
		//设置宽度
		setWidth:function(width){
			var settings = this._settings;
			var $dom = settings.$dom.width(width);
			width = $dom.outerWidth();
			var $outer = settings.$outer;
			var $outerStart = $find($outer,".processBarOuterStart");
			var $outerEnd = $find($outer,".processBarOuterEnd");
			var $outerMid = $find($outer,".processBarOuterMid");
			$outerMid.width(width - $outerStart.outerWidth() - $outerEnd.outerWidth());
			var $inner = settings.$inner;
			var __width = $inner.width();
			var _ouerWidth = $inner.outerWidth(true);
			$inner.width( width - ( _ouerWidth - __width ) );
			var _width = $inner.innerWidth();
			var $innerStart = $find($inner,".processBarInnerStart");
			var $innerEnd = $find($inner,".processBarInnerEnd");
			var $innerMid = $find($inner,".processBarInnerMid");
			$innerMid.width(_width - $innerStart.outerWidth() - $innerEnd.outerWidth());
		},
		//设置高度
		setHeight:function(height){
			var settings = this._settings;
			var $dom = settings.$dom.height(height);
			width = $dom.outerHeight();
			var $outer = settings.$outer;
			var $outerStart = $find($outer,".processBarOuterStart");
			var $outerEnd = $find($outer,".processBarOuterEnd");
			var $outerMid = $find($outer,".processBarOuterMid");
			$outerMid.height(height - $outerStart.outerHeight() - $outerEnd.outerHeight());
			var $inner = settings.$inner;
			var __height = $inner.height();
			var _outerHeight = $inner.outerHeight(true);
			$inner.height( height - ( _outerHeight - __height ) );
			var _height = $inner.innerHeight();
			var $innerStart = $find($inner,".processBarInnerStart");
			var $innerEnd = $find($inner,".processBarInnerEnd");
			var $innerMid = $find($inner,".processBarInnerMid");
			$innerMid.height(_height - $innerStart.outerHeight() - $innerEnd.outerHeight());
		},
		/*setOrientation: function(isVertical){
			//默认为false水平, true为垂直
		}*/
		//动画增长
		enableAnimation:function(flag){
			this._settings.animation = flag;
		}
	}
})(UCD,UCD.Core);