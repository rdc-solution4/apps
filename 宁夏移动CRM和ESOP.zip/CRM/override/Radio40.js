var UCD = UCD || {Core:jQuery};

(function(ucd,$){
	var _M = "Radio";
	var $doc = $(document);
	var browser = $.browser;
	var isIE = browser.msie;
	var browserVersion = browser.version;
	var needToFix = (isIE && browserVersion < 9);
	var COUNT = 0;
    var lastContainer;

	var M = ucd[_M] = function(container,text,group,onChange){
		this._settings = $.extend({
			container:document.body,
			text:"Checkbox",
			//icon:null,
			disabled:false,
			onChange:null,
			bindEvents:{},
			checked:false,
			group:null
		},{
			container:container,
			text:text,
			group:group,
			onChange:onChange
		});
		init(this);
	}
	
	M.group = {}
	M.ins = {};
	M.init = function(){	
		var selector = needToFix?".radio":".radio > :radio";
		
		$doc.delegate(selector,"click",function(e){
			
			var $radio = $(this);
			var $label = $radio.closest(".radio");
			if($label.is(".disabled")){
				return;
			}
			var ins = M.ins[$label.attr("data-uuid")];
			if(ins){
				ins.check(true);
				e.stopPropagation();
			}
		});
	}
	
	M.init();
	
	var FN = M.prototype;
	//绑定事件
	FN.bind = function(type,fn,handlerData){
		if(!$.isFunction(fn) && $.type(type) != "string"){
			return;
		}
		var self = this;
		var settings = this._settings;
		var bindEvents = settings.bindEvents;
		//找出对应type事件的勾子
		var evt = bindEvents[type];
		//没绑定过事件，则先绑定
		if(!evt){
			//返回false时，停止执行之后绑定的事件
			//同一事件不允许多次绑定
			evt = bindEvents[type] = {
				length:0,//记录已绑回调数量
				handler:$.Callbacks("unique stopOnFalse")
			};
			settings.$dom.bind(type,handlerData,function(e){
				if(!self.isDisabled()){
					evt.handler.fireWith(null,[e,self]);
				}
			});
		}
		if(!evt.handler.has(fn)){
			evt.length++;
			evt.handler.add(fn);
		}
	}
	
	FN.unbind = function(type,fn){
		if($.type(type) != "string" || (fn && !$.isFunction(fn))){
			return;
		}
		var settings = this._settings;
		var bindEvents = settings.bindEvents;
		//找出对应type事件的勾子
		var evt = bindEvents[type];
		//未绑定过type对应的事件
		if(!evt){
			return;
		}
		//传入了fn参数
		if(fn){
			//清空对应的回调，并将计数器-1
			if(evt.handler.has(fn)){
				evt.handler.remove(fn);
				evt.length--;
			}
		} else {
			evt.handler.empty();//清空所有回调
			evt.length = 0;
		}
		//当回调个数为0时，解绑事件
		if( evt.length == 0 ){
			delete bindEvents[type];
			this._settings.$dom.unbind(type);
		}
	}
	
	FN.trigger = function(type){
		this._settings.$dom.trigger(type,[this,this._settings.$dom,this.isChecked()]);
	}
	
	FN.enable = function(flag){
		var settings = this._settings;
		var $dom = settings.$dom;
		if( flag !== false ){
			$dom.removeClass("disabled");
			settings.disabled = false;
		} else {
			$dom.addClass("disabled");
			settings.disabled = true;
		}
	}
	
	FN.check = function(flag,callback){
		if(flag !== false){
			flag = true;
		} else {
			flag = false;
		}
		//由于涉及到执行回调的问题，只有状态改变才执行。
		//即，原来是选中状态，flag传入true；或原来是非选中状态，flag传入false时，不会执行以下代码
		if( flag == this.isChecked() ){
			return;
		}
		var settings = this._settings;
		var $radio = settings.$radio;
		$radio.prop("checked",flag);
		settings.checked = flag;
		settings.$dom[flag?"addClass":"removeClass"]("checked");
		var group = settings.group;
		if(group){
			var _group = M.group[group];
			var checked = _group.checked;
			flag && checked && checked.check(false);
			if(!flag){
				_group.checked = null;
			} else {
				_group.checked = this;
			}
		}
		if( callback !== null ){
			callback = $.isFunction(callback) ? callback : settings.onChange;
			_callback(callback,this,[this,settings.$radio,flag]);
		}
	}
	
	FN.isChecked = function(){
		return this._settings.checked;
	}
	
	FN.isDisabled = function(){
		return this._settings.disabled;
	}
	
	function init(ins){
		var settings = ins._settings;
		var $container = settings.$container = $(settings.container).eq(0);
        if(lastContainer==null){
            lastContainer = $container;
        }
        if(lastContainer.attr("id")!=$container.attr("id")){
            COUNT = 0;
            lastContainer = $container;
        }

		var mark = $container.attr("id")+""+createMarker("ur");
		var $dom = settings.$dom = $('<label class="radio" data-uuid="'+mark+'"><ins class="uIcon" id="'+mark+'"></ins><input type="radio" /><span class="label">'+settings.text+'</span></label>');
		var $radio = settings.$radio = $dom.children(":radio");
		var _group = settings.group;
		if($.type(_group) != "string"){
			settings.group = null;
		} else {
			var group = M.group[_group];
			if(!group){
				group = M.group[_group] = {
					checked:null//单选按钮组中选中的
				};
			}
			$radio.attr("name",_group);
			$dom.attr("data-group",_group);
		}
		$dom.appendTo($container);
		M.ins[mark] = ins;
	}
	
	//执行一个回调
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}
	
	//创建一个唯一标识
	function createMarker(pre){
		//var count = G.count = ++G.count;
		return pre+("00000000"+(COUNT++)).substr(-5);
	}

})(UCD,UCD.Core);