var UCD = UCD || {Core:jQuery};
(function(ucd, $){
	
	/********************平台公用函数************************/
	//按id取元素
	function $id(id){
		return $("#"+id);
	}
	//按标签名取
	function $tagName(ele,tagName){
		if(ele instanceof $){
			ele = ele[0];
		}
		if(!tagName){
			tagName = "*";
		}
		if(!ele) return $();
		return $(ele.getElementsByTagName(tagName));
	}
	//取所有子元素
	function $children(ele){
		return $tagName(ele);
	}
	//替换jq find方法，解决IE7下效率问题
	function $find(context,selector){
		if(context instanceof $){
			context = context[0];
		}
		if(!context){
			return $();
		}
		var $child = $children(context);
		return $child.filter(selector);
	}
	
	//执行一个回调
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}
	/********************平台公用函数结束************************/
	
	function setRangeDom(isVertical){
		return $(['<div class="sliderOC '+(isVertical?"vSliderOC":"hSliderOC")+'">','<div class="sliderOuterOC">','<div class="sliderStartOC"></div>','<div class="sliderCenterOC"></div>','<div class="sliderEndOC"></div>','</div>','<div class="viewBoxOC">','<div class="sliderInnerOC">','<div class="sliderStartOC"></div>','<div class="sliderCenterOC"></div>','<div class="sliderEndOC"></div>','</div>','</div>','<div class="trackOC"></div>','</div>'].join(""));
	}
	
	//创建一个唯一标识
	var COUNT = 0;
	function createMarker(prefix){
		return prefix+("00000000"+(++COUNT)).substr(-5);
	}
	
	var init = function(ins){
		var settings = ins._settings;
		var $container = settings.$container = $(settings.container);
		var $dom = settings.$dom = setRangeDom(settings.isVertical).appendTo($container);
		var $outer = settings.$outer = $find($dom,".sliderOuterOC");//外层轮廓
		var $inner = settings.$inner = $find($dom,".sliderInnerOC");//数据层轮廓
		var $viewBox = settings.$viewBox = $find($dom,".viewBoxOC");//视窗，用来遮盖数据层
		var $track = settings.$track = $find($dom,".trackOC");//调节器
		//var size = settings.size;
		settings.mark = createMarker("sliderOC");//唯一标识
		settings.events = {};
		ins.setRange(settings.min,settings.max);
		ins.setStep(settings.step);
		if(settings.isVertical){
			ins.setHeight($dom.height());
		} else {
			ins.setWidth($dom.width());
		}
		ins.setValue(settings.value);
		ins.enableChange();
	}
	
	//根据值设置track位置
	var _setTrackPos = function(range,val){
		var size = _valueToSize(range,val);
		var settings = range._settings;
		var prop = {};
		prop[settings.isVertical?"_ysp_top":"left"] = (size)+"px";
		settings.$track.css(prop);
		settings.dataSize = size;//记录句柄位置，拖动时根据上一位置设置新位置
	},
	//将值转成宽/高
	_valueToSize = function(range,val){
		var settings = range._settings;
		return settings.totalSize * ((val-settings.min)/( settings.totalValue ));
	},
	//将宽、高转换成值
	_sizeToValue = function(range,size){
		var settings = range._settings;
		return (settings.min + settings.totalValue * (size / settings.totalSize));
	},
	
	//修正值
	_fixValue = function(range,val){
		var settings = range._settings;
		var min = settings.min;
		var max = settings.max;
		var step = settings.step;
		if(val < min){
			val = min;
		} else if( val > max ){
			val = max;
		}
		
		if( step != 1 ){
			val = min + Math.round((val-min) / step) * step;
		}
		
		return val;//(val-0).toFixed(settings.fraction);
	}

	//CBB的根节点必须是inline-block类型
	ucd.RangeOC = function(container, value, isVertical){
		var settings = this._settings = $.extend({
			container: document.body,
			value: 1,
			isVertical:false,
			//width :300,//宽
			//height:18,//高
			min:0,//开始数值
			max:2000,//结束数值
			step:1
			//,fraction:2
		},{
			container: container,
			value: value,
			isVertical:isVertical
		});
		init(this);
	}

	ucd.RangeOC.prototype = {
		constructor: ucd.RangeOC,
		getValue: function(){
			return this._settings.value - 0;
		},
		setValue: function(val){
			var settings = this._settings;
			val = _fixValue(this,val);
			var size = _valueToSize(this,val);
			settings.$viewBox[settings.isVertical?"height":"width"](size);
			_setTrackPos(this,val);
			settings.value = val;
			settings.$track.attr("title",this.getValue());
			_callback(settings.events.change,this);
		},
		setStep: function(step){
			//设置步长，默认为1
			this._settings.step = step;
		},
		setRange: function(min, max){
			var settings = this._settings;
			settings.min = min;
			settings.max = max;
			settings.totalValue = max - min;
			this.setValue(settings.value);
		},
		setOnChanged:function(fn){
			if( $.isFunction(fn) ){
				this._settings.events.change = fn;
			}
		},
		setWidth: function(width){
			if( width !== null && width !== undefined ){
				var settings = this._settings;
				var m = "width";
				var m2 = "outerWidth";
				settings.$dom[m](width);
				settings.$outer[m](width);
				if(!settings.isVertical){
					settings.totalSize = width - (settings.$inner[m2]()-settings.$inner[m]());//数据条尺寸
				}
				settings.$inner[m](settings.totalSize);
				this.setValue(settings.value);
			}
		},
		setHeight: function(height){
			if( height !== null && height !== undefined ){
				var settings = this._settings;
				var m = "height";
				var m2 = "outerHeight";
				settings.$dom[m](height);
				settings.$outer[m](height);
				if(settings.isVertical){
					settings.totalSize = height - (settings.$inner[m2]()-settings.$inner[m]());//数据条尺寸
				}
				settings.$inner[m](settings.totalSize);
				this.setValue(settings.value);
			}
		},
		enableChange: function(flag){
			var $doc = $(document);
			var self = this;
			var settings = this._settings;
			var mark = settings.mark;
			settings.$track.unbind("mousedown."+mark);
			if( flag === false ){
				return;
			}
			settings.$track.bind("mousedown."+mark,function(e){
				var vertical = settings.isVertical;
				var baseSize = settings.dataSize;
				var basePos;
	
				var beforeDrag = function(e){
					basePos = vertical?e.pageY:e.pageX;
					$doc.bind("mousemove."+mark,draging);
					$doc.bind("mouseup."+mark,dragend);
				}
				
				var draging = function(e){
					var dis = (vertical?e.pageY:e.pageX) - basePos;
					var size = baseSize + dis;
					var val = _sizeToValue(self,size);
					self.setValue(val);
				}
				
				var dragend = function(e){
					settings.$container.trigger("change");
					$doc.unbind("mousemove."+mark);
					$doc.unbind("mouseup."+mark);
				}
				
				beforeDrag(e);
				e.preventDefault();
			});
		}
	}
})(UCD,UCD.Core);


