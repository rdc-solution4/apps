var ucd;
(function (ucd) {
    var Tab = (function () {
        function Tab($dom, minWidth) {
            if (minWidth === void 0) { minWidth = 100; }
            this.$dom = $dom;
            this.minWidth = minWidth;
            var that = this;
			$dom.find("li").each(function(index){
				$(this).attr({'index':index});
				})
            $dom.find("li").click($.proxy(this._onClickLi,this));
            $dom.find(".tab_close").click($.proxy(this._onCloseBt,this));
            $dom.find(".tab_menu").click(function (e) {
				
				var popup = $dom.find(".tab_popup");
				if($(this).hasClass('on')){
					popup.hide();
					$(this).removeClass('on');
				}else{
					popup.show();
					$(this).addClass('on');					
				}
                /*if (popup.data("open")) {
                    popup.data("open", false);
                    popup.hide();
                }
                else {
                    popup.data("open", true);
                    popup.show();
                }*/
           //     that.tabPopupScrollbar.refreshScroll();
                e.stopPropagation();
            });
            $dom.find(".tab_popup").click(function(e){
                e.stopPropagation();
            })
            $(document).click(function (e) {
                var popup = $(".tab_popup");
                if (popup.data("open")) {
                    popup.data("open", false);
                    popup.hide();
                }
            });
            $(window).resize(function () {
                that.resize();
            });
            $("body").resize(function (e) {
                that.resize();
                e.stopPropagation();
            });

            //自定义滚动条样式
      //      this.tabPopupScrollbar = new ucd.DefaultScroll({
      //          scrollObj: $("#tab-scrollbar")
      //      });

            this.resize();

            $.cookie().json = true;
            var tabs = $.cookie("tabs");
            if(tabs && (tabs instanceof Array)){
                for(var i in tabs){
                    this._addItem(tabs[i].name,tabs[i].url,tabs[i].deletable);
                }
            }else{
                $.cookie().tabs = [];
            }

            var tab = window.location.href.match(/tab=\d*/);
            if(tab){
                var i = parseInt(tab&&tab.length>0?tab[0].substring(4):0);
                this.selected(i);
            }
        }

        Tab.prototype._onClickLi = function(e){
            var t = $(e.currentTarget);
            this.selected(t);
			var $temp = this.$dom;
            if(this.$dom.closest('.tab_cont').length){
				this.$dom.find('li').each(function(index, element) {
					if($(this).hasClass('selected')){
						var $parent = $(this).closest('.tab_cont').siblings('.tab_content:eq(0)');
						$parent.children().hide().eq( parseInt($(this).attr('index')) ).show();
						if(!$(this).closest('.floatCon').length){
							 var cont_index = $temp.find("ul:eq(0) li").last().index();
							 $temp.find("ul:eq(0) li").last().insertBefore($(this));
							 $(this).appendTo($temp.find("ul:eq(0)"));
							 $temp.find(".tab_popup").hide();
							 $temp.find(".tab_menu").removeClass('on');
							}	
						}
				});
			}else{
				var url = t.attr("data-href");
				if(url){
					window.location.href = url;
				}
			}
			
        }
        Tab.prototype._onCloseBt=function(e){
            this.removeItem($(e.currentTarget).parent().index());
            e.stopPropagation();
        }
        Tab.prototype.length = function () {
            return this.$dom.find("li").length;
        };
        Tab.prototype.addItem = function (name,url,deletable) {
            var index = this._addItem(name,url,deletable);
            this.resize();
            return index;
        };
        Tab.prototype.addItems = function(names){
            for(var i in names){
                this._addItem(names[i][0],names[i][1]);
            }
            this.resize();
        }
        Tab.prototype.navigate = function(i){
            window.location.href = this.$dom.find("li").eq(i).attr("data-href");
        }
        Tab.prototype.removeItem = function(i,toNext){
            if(toNext===void 0) toNext = true;
            if(i == null || i===void 0){
                i = this.selected();
            }
            try{console.log("removeItem:",i,toNext);}catch(e){}

            var t = (typeof i == "number")?this.$dom.find("li").eq(i):i;
            if(t.data("enableDel")=="false") return this;

            if(toNext){
                var t = t.remove();
                if (t.hasClass("selected")) {
                    i += (i < this.length() - 1 ? 0 : -1);
                    this.selected(i);
                    window.location.href = this.$dom.find("li").eq(i).attr("data-href");
                }
                this.resize();
            }

            var tabs = $.cookie("tabs");
            for(var ii in tabs){
                if(tabs[ii].name == t.text()){
                    tabs.splice(ii,1);
                    $.cookie("tabs",tabs);
                    break;
                }
            }
            return this;
        }
        Tab.prototype._addItem = function(name,url,deletable){
            $.cookie.json = true;
            var tabs = $.cookie("tabs");
            if(!tabs) { tabs= [];}
            if (deletable === void 0) { deletable = true };

            if($('.tab_title:contains('+name+')').length==0){
                $('<li class="'+(deletable?"":"undeletable")+'" data-href="'+url+'"><div class="selector"></div><div class="tab_close"></div><div class="tab_title"><span>'+name+'</span></div></li>')
                    .appendTo(this.$dom.find("ul:last-child"))
                    .click($.proxy(this._onClickLi,this))
                    .find(".tab_close").click($.proxy(this._onCloseBt,this));
            }

            var hasi = -1;
            for(var n=0;n<tabs.length;n++){
                if(tabs[n].name==name){
                    hasi = n;
                    break;
                }
            }
            if(hasi==-1){
                tabs.push({name:name,url:url,deletable:deletable});
                $.cookie("tabs",tabs/*,{expires:-1}*/);
                var test = $.cookie("tabs");
                return tabs.length-1;
            }else{
                return hasi;
            }

        }
        Tab.prototype.selected = function (v) {
            //if((v==void 0)||v==null)
            var sel = "selected";
            if (typeof v == "number") {
                if (v >= 0 && v < this.length()) {
                    var li = this.$dom.find("li").eq(v);
                    if(li.hasClass(sel)) return;
                    this.$dom.find("li.selected").removeClass(sel);
                    this.$dom.find("li").eq(v).addClass(sel);
                }
            }
            else if(v instanceof jQuery) {
                if(v.hasClass(sel)) return;
                this.$dom.find("li.selected").removeClass(sel);
                v.addClass(sel);
            }else{
                //console.log("getSelectedIndex");
            }
            var i = this.$dom.find("li.selected").index();
            return i;
        };

        Tab.prototype.resize = function () {
            var that = this;
			var pw;
			if(this.$dom.closest('.tab_cont').length){
				pw = this.$dom.width() - 20;
			}else{
				pw = this.$dom.width() - 20 - 55;
			}
            that.isFirst=false;
            var lis = this.$dom.find("li").css("width", this.minWidth - 4);
            var il = lis.length;
            if (il * this.minWidth > pw) {
				
                var tl = Math.floor(pw / (this.minWidth));
                var pl = il - tl;
                for (var i = 0; i < il; i++) {
                    if (i < tl) {
                        this.$dom.find("ul:eq(0)").append(lis.eq(i));//qzl pay attention
                    }
                    else {
                        this.$dom.find("ul:eq(1)").append(lis.eq(i));
                    }
                }
				this.$dom.find(".tab_menu").show();
				if(this.$dom.closest('.tab_cont').length){
					this.$dom.find(".tab_menu").css({'width':this.$dom.width() - tl*(this.minWidth-3)})
				}
                this.$dom.find(".tab_popup").css({ "margin-left": this.$dom.find(".tab_menu").offset().left - 35 });
                if (this.$dom.find(".tab_popup").data("open")) {
                    this.$dom.find(".tab_popup").show();
                }
            }
            else {
				
				this.$dom.find(".tab_popup").hide();
				this.$dom.find(".tab_menu").hide();
                this.$dom.find("ul:eq(1) li").each(function(i,li){
                    that.$dom.find("ul:eq(0)").append(li);
                })
            }


           // this.tabPopupScrollbar.refreshScroll();
        };
        return Tab;
    })();
    ucd.Tab = Tab;
})(ucd || (ucd = {}));