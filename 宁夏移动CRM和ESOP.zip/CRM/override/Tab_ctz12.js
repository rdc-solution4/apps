var ucd;
(function (ucd) {
    var Tab = (function () {
        function Tab($dom, minWidth) {
            if (minWidth === void 0) { minWidth = 100; }
            this.$dom = $dom;
            this.minWidth = minWidth; 
            window.that = this;
            var that = this;
            $dom.delegate("li", 'click', function (e) {
                that.selected($(this));
            });
            $dom.delegate(".tab-close", 'click', function (e) {
            	
            	//DD-AR-D01886788 退出系统时进行知识库的退出-关闭tab菜单
            	debugger;
            	var menuId = _ysp_top.$BES.$Portal.tabpanel.getTabItem().key;
            	var knowledgeBaseStatus = _ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus;
            	var onlineKnowledgeLogOut = _ysp_top.$BES.$Portal.tabpanel.onlineKnowledgeLogOut;
        		
            	if (menuId == "6013120180426111501" && knowledgeBaseStatus == true)
            	{
            		debugger;
            		if (onlineKnowledgeLogOut)
            		{
            			//_ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus = false;
            			//跨域请求
                       	jQuery.ajax({
              		 	    type: "get",
              				url: onlineKnowledgeLogOut,
              				dataType: "jsonp",
              				success: function (suc) {
              				    debugger;
              					_ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus = false;
              		        },
              		        error: function (err) {
              		            debugger;
              		        }
              			 });
                        	
            		}
            	}
            	//DD-AR-D01886788 退出系统时进行知识库的退出
            	
                if($(this).data("enableDel")=="false") return;
                var li = $(this).parent();                
                var flag = that.closeCallback(li);
                // 只有返回false才不关闭
                if (flag == false) {
                	return;
                }
                debugger;
                //var i = li.index();
                //DTS2018020600892，如果菜单打开较多超出屏幕范围后，关闭隐藏的菜单时，li.index()获取的是当前菜单在隐藏菜单中的位置
                var i = that.selectIndex(li)
                
                var li = li.remove();
                
                if (li.hasClass("selected")) {
                    i += (i < that.length() - 1 ? 0 : -1);
                    that.selected(i);
                }
                that.resize();
                e.stopPropagation();
            });
            $dom.find(".tab-menu").click(function (e) {
                var popup = $(".tab-popup");
                if (popup.data("open")) {
                    popup.data("open", false);
                    popup.hide();
                }
                else {
                    popup.data("open", true);
                    popup.show();
                }
                that.tabPopupScrollbar.refreshScroll();
                e.stopPropagation();
            });
            $(document).click(function () {
                var popup = $(".tab-popup");
                if (popup.data("open")) {
                    popup.data("open", false);
                    popup.hide();
                }
            });
            $(window).resize(function () {
                that.resize();
            });

            // 自定义滚动条样式
            this.tabPopupScrollbar = new ucd.DefaultScroll({
                scrollObj: $("#tab-scrollbar")
            });

            this.resize();
        }
        Tab.prototype.selectedCallback =  function(){};        
        
        Tab.prototype.setSecCallBack =  function(secCallBack){
        	 Tab.prototype.selectedCallback = secCallBack;
        };
        
        Tab.prototype.closeCallback =  function(){};        
        
        Tab.prototype.setCloseCallBack =  function(cloCallBack){
        	 Tab.prototype.closeCallback = cloCallBack;
        };
        
        Tab.prototype.selectIndex = function (oldLi) {
        	
            var length = this.$dom.find("li").length;
            var liList = this.$dom.find("li");
            var oldInnerId = oldLi.attr("innerId");
            
            for (var i = 0; i < length; i++)
            {
            	var li = liList.eq(i);
            	if (oldInnerId == li.attr("innerId")) 
            	{
            		return i;
            	}	
            }
            return 0;
        };
        
        Tab.prototype.length = function () {
            return this.$dom.find("li").length;
        };
        Tab.prototype.addItem = function (li) {
            this.$dom.find("ul:eq(0)").append(li);
            this.resize();
        };
        Tab.prototype.selectedItem = function () {
        	var lis = this.$dom.find("li");
        	for (var i = 0; i < lis.length; i++) {
        		var tmpli = lis.eq(i);
 						if (tmpli.hasClass("selected")) {
 							return tmpli;
 						}
          }
        	return null;
        };        
        Tab.prototype.findLiExist = function (id) {
        	var lis = this.$dom.find("li");
        	for (var i = 0; i < lis.length; i++) {
        		var tmpli = lis.eq(i);
 						if (tmpli.attr('innerId') == id) {
 							return tmpli;
 						}
          }
          return null;
        };

        Tab.prototype.closeTab =  function(tabId){
        	var li = this.findLiExist(tabId);
			if (li != null) {
				li.children('.tab-close').click();
			}
        };

        Tab.prototype.closeAllTab =  function(){
        	$('.tab-close').click();
        };
        

        Tab.prototype.closeAllTabExceptOne =  function(tabId){
        	var lis = this.$dom.find("li");
        	lis.filter('[innerid!="' + tabId + '"]').find('.tab-close').click();
        };        

        Tab.prototype.getAllTabs = function () {
        	return $('li[innerid][menuid]');        	
        };  
        
        
        
        Tab.prototype.selected = function (v) {
            var sel = "selected";
            if (typeof v == "number") {
                if (v >= 0 && v < this.length()) {
                    var li = this.$dom.find("li").eq(v);
                    this.$dom.find("li.selected").removeClass(sel);
                    var selectedTab = this.$dom.find("li").eq(v);
                    selectedTab.addClass(sel);
                    this.selectedCallback(selectedTab);
                }
            }
            else {
                this.$dom.find("li.selected").removeClass(sel);
                v.addClass(sel);
                this.selectedCallback(v);
            }
            
            return this.$dom.find("li.selected").index();
        };
        Tab.prototype.resize = function () {
            //var pw = this.$dom.width() - 22;
        	var pw = window.innerWidth - 55 - 17;//55 是左侧快捷菜单栏宽度，17是右侧小按钮宽度
            var lis = this.$dom.find("li").css("width", this.minWidth - 2);
            var il = lis.length;
            var relizeWidth = this.minWidth + 5;
            if (il * relizeWidth > pw) {
                var tl = Math.floor(pw / relizeWidth);
                var pl = il - tl;
                for (var i = 0; i < il; i++) {
                    if (i < tl) {
                        this.$dom.find("ul:eq(0)").append(lis.eq(i));
                    }
                    else {
                        this.$dom.find("ul:eq(1)").append(lis.eq(i));
                    }
                }
                $(".tab-menu").show();
                $(".tab-popup").css({ "margin-left": $(".tab-menu").offset().left - 35 });
                if ($(".tab-popup").data("open")) {
                    $(".tab-popup").show();
                }
            }
            else {
                $(".tab-popup").hide();
                $(".tab-menu").hide();
                this.$dom.find("ul:eq(1) li").each(function(i,li){
                    //that.$dom.find("ul:eq(0)").append(li);
                	window.that.$dom.find("ul:eq(0)").append(li);
                })
            }

            this.tabPopupScrollbar.refreshScroll();
        };
        return Tab;
    })();
    ucd.Tab = Tab;
})(ucd || (ucd = {}));