/** 
 * @version 1.0 
 * @date 2016/05/24
 * @author l00185610
 * 用于实现页面 AdMap 对象，Key只能是String，对象随意 
 */
var AdMap = function() {
	this._MapEntrys = new Array();

	this.put = function(key, value) {
		if (key == null || key == undefined) {
			return;
		}
		var index = this.getIndex(key);
		if (index == -1) {
			var entry = new Object();
			entry.key = key;
			entry.value = value;
			this._MapEntrys[this._MapEntrys.length] = entry;
		} else {
			this._MapEntrys[index].value = value;
		}
	};
	this.get = function(key) {
		var index = this.getIndex(key);
		return (index != -1) ? this._MapEntrys[index].value : null;
	};
	this.remove = function(key) {
		var index = this.getIndex(key);
		if (index != -1) {
			this._MapEntrys.splice(index, 1);
		}
	};
	this.clear = function() {
		this._MapEntrys.length = 0;
	};
	this.contains = function(key) {
		var index = this.getIndex(key);
		return (index != -1) ? true : false;
	};
	this.getCount = function() {
		return this._MapEntrys.length;
	};
	this.getEntrys = function() {
		return this._MapEntrys;
	};
	this.getIndex = function(key) {
		if (key == null || key == undefined) {
			return -1;
		}
		var _length = this._MapEntrys.length;
		for ( var i = 0; i < _length; ++i) {
			var entry = this._MapEntrys[i];
			if (entry == null || entry == undefined) {
				continue;
			}
			if (entry.key === key) {//equal  
				return i;
			}
		}
		return -1;
	};
}

/** 
 * @version 1.0 
 * @date 2016/05/24
 * @author l00185610
 * ad paramters 根据参数id获取参数值 
 */
var AdParameter = function() {
	this._ParameterEntrys = new AdMap();

	/**
	 * 读取系统参数的值
	 * varId ：请传 < '$Page.xxx' > 的格式；或者传function类型；或者传''
	 */
	this.read = function(paramId, defaultValue, varIdOrFunc) {
		debugger;

		if (!paramId) {
			return;
		}

		var $scope = $(document).scope();
		var $Page = $scope.$Page;
		
		var cachedIndex = this._ParameterEntrys.getIndex(paramId);
		if (-1 < cachedIndex) {
			var val = this._ParameterEntrys.getEntrys()[cachedIndex].value;
			if(varIdOrFunc){
				if (typeof varIdOrFunc === 'function'){
					varIdOrFunc(val);
				}else if(typeof defaultValue === 'string'){
					eval(varIdOrFunc + "=\'" + val + "\'");
				}else{
					eval(varIdOrFunc + "=" + val + "");
				} 
			}
			return;
		}
		
		if(varIdOrFunc){
			if (typeof varIdOrFunc === 'function'){
				varIdOrFunc(defaultValue);
			}else if(typeof defaultValue === 'string'){
				eval(varIdOrFunc + "=\'" + defaultValue + "\'");
			}else{
				eval(varIdOrFunc + "=" + defaultValue + "");
			} 
		}
		
		var paraObj = this;
		$Page.varAdParameterParamvalue = null;
		
		$scope.$Get("$Fire")(
				{
					service : 'ucec/v1/common/qrysystemparambykey',
					params : {
						"key" : paramId
					},
					target : "$Page.varAdParameterParamvalue",
					onafter : function() {
						debugger;
						
						if(varIdOrFunc){
							if (typeof varIdOrFunc === 'function'){
								varIdOrFunc($Page.varAdParameterParamvalue);
							}else if(typeof defaultValue === 'string'){
								eval(varIdOrFunc + "=\'" + $Page.varAdParameterParamvalue + "\'");
							}else{
								eval(varIdOrFunc + "=" + $Page.varAdParameterParamvalue + "");
							} 
						}
						
						paraObj._ParameterEntrys.put(paramId,
								$Page.varAdParameterParamvalue);
						
						delete $Page.varAdParameterParamvalue;
					},
					onerror : function() {
						debugger;
						
						delete $Page.varAdParameterParamvalue;
					}
				}, $scope);
	};

	this.value = function(paramId) {
		return this._ParameterEntrys.get(paramId);
	};
}

/** 
 * @version 1.0 
 * @date 2016/05/24
 * @author l00185610
 * ad Dictionary 根据字典id获取枚举值 
 */
var AdDictionary = function() {

	this._DictionaryEntrys = new AdMap();

	//读取单个字典项
	this.read = function(dictCode, varFunc) {
		debugger;

		if (!dictCode) {
			return;
		}

		var dictCodeList = [];
		dictCodeList.push(dictCode);

		this.readn(dictCodeList, varFunc);
	};

	//读取数组中多个字典项
	this.readn = function(dictCodeList, varFunc) {
		debugger;

		if (!dictCodeList) {
			return;
		}

		var $scope = $(document).scope();
		var $Page = $scope.$Page;
		
		var cachedIndex = 0;
		for ( var n = 0; n < dictCodeList.length; ++n) {
			var cachedIndex = this._DictionaryEntrys.getIndex(dictCodeList[n]);
			if (-1 < cachedIndex) {
				if (typeof varFunc === 'function'){
					varFunc(dictCodeList[n], this._DictionaryEntrys.getEntrys(cachedIndex));
				}
				dictCodeList.splice(n, 1);
				--n;
			}
		}

		if (0 == dictCodeList.length) {
			return;
		}

		var paraObj = this;
		$Page.varAdDictMap = null;
		
		$scope.$Get("$Fire")({
			service : "/common/dictkey",
			params : {
				"dictkeylist" : dictCodeList
			},
			target : "$Page.varAdDictMap",
			onafter : function() {
				debugger;
				for ( var n = 0; n < dictCodeList.length; ++n) {
					var dictCode = dictCodeList[n];
					var dictItems = $Page.varAdDictMap[dictCode];
					var list = [];

					$.each(dictItems, function(i, val) {
						var obj = {
							"key" : val.itemCode,
							"value" : val.itemName,
							"ext1" : val.extMap.ext1,
							"ext2" : val.extMap.ext2
						};

						list.push(obj);
					});

					if (typeof varFunc === 'function'){
						varFunc(dictCode, list);
					}
					paraObj._DictionaryEntrys.put(dictCode, list);
					
				}
				delete $Page.varAdDictMap;
			},
			onerror : function() {
				debugger;
				
				delete $Page.varAdDictMap;
			}
		}, $scope);
	};

	this.items = function(dictCode) {
		return this._DictionaryEntrys.get(dictCode);
	};
	
	this.item = function(dictCode, key) {
		var oneItem = null;
		var allItems = this._DictionaryEntrys.get(dictCode);
		for ( var n = 0; n < allItems.length; ++n) {
			var oneItem = allItems[n];
			if(oneItem.key == key){
				return oneItem;
			}
		}
		return null;
	};
}

/*when page is loaded,create parameter and dictionary . by l00185610 at 20160513
 parameter :  paramid(string) - paramvalue(string)
 dictionary : dictcode(string) - dictitemArray[{key,value}...] .
 */
$(function() {
	debugger;

	var $scope = $(document).scope();
	var $Page = $scope.$Page;

	//自定义Map对象parameter  
	if(!$Page.parameter){
		$Page.parameter = new AdParameter();	
	}

	//局点，如NINGXIA、JIANGSU，存于全局变量$Page.Corporation，默认为空
	$Page.parameter.read('60107061880414', 'BASE', '$Page.Corporation');
	
	//自定义Map对象dictionary
	if(!$Page.dictionary){
		$Page.dictionary = new AdDictionary();
	}	
})