/* jQuery UI Date Picker v3.4.3 (previously jQuery Calendar)
   Written by Marc Grabanski (m@marcgrabanski.com) and Keith Wood (kbwood@virginbroadband.com.au).

   Copyright (c) 2007 Marc Grabanski (http://marcgrabanski.com/code/ui-datetimepicker)
   Dual licensed under the MIT (MIT-LICENSE.txt)
   and GPL (GPL-LICENSE.txt) licenses.
   Date: 09-03-2007  */
/*
 * Time functionality added by Stanislav Dobry (stanislav.dobry@datesoft.cz)
 * Date: 2008-06-04
 */

;(function($) { // hide the namespace

function matchDateFormat(dateformat) {
    dateformat = dateformat.replace(":mm", ":ii");
    dateformat = dateformat.replace("mm:", "ii:");
    dateformat = dateformat.replace("m:", "i:");
    if(-1!=dateformat.indexOf("MMMMM"))
    {
        dateformat = dateformat.replace("MMMMM", "MM");
    }
    else
    {        
        if(-1!=dateformat.indexOf("MMM"))
        {
            dateformat = dateformat.replace("MMM", "M");
        }
        else
        {
            dateformat = dateformat.replace("MM", "mm");
            dateformat = dateformat.replace("M", "m");
        }
    }
    if(-1!=dateformat.indexOf("yyyy"))
    {
        dateformat = dateformat.replace("yyyy", "yy");
    }
    else
    {
        dateformat = dateformat.replace("yy", "y");
    }
    return dateformat;
}

/*
 * Date picker manager. Use the singleton instance of this class,
 * $.datetimepicker, to interact with the date picker. Settings for (groups of)
 * date pickers are maintained in an instance object (DatepickerInstance),
 * allowing multiple different settings on the same page.
 */

function DateTimepicker() {
    this.debug = false; // Change this to true to start debugging
    this._nextId = 0; // Next ID for a date picker instance
    this._inst = []; // List of instances indexed by ID
    this._curInst = null; // The current instance in use
    this._disabledInputs = []; // List of date picker inputs that have been
								// disabled
    this._datetimepickerShowing = false; // True if the popup picker is
											// showing , false if not
    this._inDialog = false; // True if showing within a "dialog", false if not
    this.regional = []; // Available regional settings, indexed by language code
    this.regional[''] = { // Default regional settings
        clearText: 'Clear', // Display text for clear link
        clearStatus: 'Erase the current date', // Status text for clear link
        closeText: 'Close', // Display text for close link
        closeStatus: 'Close without change', // Status text for close link
        prevText: '&#x3c;Prev Month', // Display text for previous month link
        prevYearText: '&#x3c;Prev Year', // Display text for previous month
											// link
        okLabel: 'OK', // ok button label
        cancelLabel: 'Cancel', //ok button label
        clearLabel:'Clear',
        prevStatus: 'Show the previous month', // Status text for previous
												// month link
        nextText: 'Next Month&#x3e;', // Display text for next month link
        nextYearText: 'Next Year&#x3e;', // Display text for next month link
        nextStatus: 'Show the next month', // Status text for next month link
        currentText: 'Today', // Display text for current month link
        currentStatus: 'Show the current month', // Status text for current
													// month link
        monthNames: ['January','February','March','April','May','June',
            'July','August','September','October','November','December'], // Names
																			// of
																			// months
																			// for
																			// drop-down
																			// and
																			// formatting
        monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], // For
																												// formatting
        defaultMonthNames: ['January','February','March','April','May','June',
                    'July','August','September','October','November','December'], // Names
																					// of
																					// months
																					// for
																					// drop-down
																					// and
																					// formatting
        defaultMonthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], // For
																														// formatting
        monthStatus: 'Show a different month', // Status text for selecting a
												// month
        yearStatus: 'Show a different year', // Status text for selecting a
												// year
        weekHeader: 'Wk', // Header for the week of the year column
        weekStatus: 'Week of the year', // Status text for the week of the year
										// column
        dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], // For
																									// formatting
        dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], // For
																			// formatting
        dayNamesMin: ['Su','Mo','Tu','We','Th','Fr','Sa'], // Column headings
															// for days starting
															// at Sunday
        dayStatus: 'Set DD as first week day', // Status text for the day of
												// the week selection
        dateStatus: 'Select DD, M d', // Status text for the date selection
        dateFormat: 'mm/dd/yy', // See format options on parseDate
        dateFormatHeader: 'mm/yy',
        displaytime: true,
        // timeFormat: 'HH:ii:ss',
        firstDay: 0, // The first day of the week, Sun = 0, Mon = 1, ...
        dayInFirstWeek: 1, // The day in firstWeek of year,1=1月1号在第一周
        weekstrSeparator: '~',// The weekstr Separator
        year:"year",// 年国际化
        week:"week",// 周国际化
        initStatus: 'Select a date', // Initial Status text on opening
        isRTL: false, // True if right-to-left language, false if
						// left-to-right
        pickertitle:'local',
        dst:true
    };
    this._defaults = { // Global defaults for all the date picker instances
        showOn: 'focus', // 'focus' for popup on focus,
            // 'button' for trigger button, or 'both' for either
        showAnim: 'show', // Name of jQuery animation for popup
        defaultDate: null, // Used when field is blank: actual date,
            // +/-number for offset from today, null for today
        appendText: '', // Display text following the input box, e.g. showing
						// the format
        buttonText: '...', // Text for trigger button
        buttonImage: '', // URL for trigger button image
        buttonImageOnly: false, // True if the image appears alone, false if it
								// appears on a button
        closeAtTop: false, // True to have the clear/close at the _ysp_top,
                            // false to have them at the bottom
        closeHide: true,    // True to hide clear/close bar , false to show
							// clear/close bar
        mandatory: false, // True to hide the Clear link, false to include it
        hideIfNoPrevNext: false, // True to hide next/previous month links
            // if not applicable, false to just disable them
        changeMonth: true, // True if month can be selected directly, false if
							// only prev/next
        changeYear: true, // True if year can be selected directly, false if
							// only prev/next
        yearRange: '-100:+100', // Range of years to display in drop-down,
            // either relative to current year (-nn:+nn) or absolute (nnnn:nnnn)
        changeFirstDay: false, // True to click on day name to change, false to
								// remain as set
        showOtherMonths: true, // True to show dates in other months, false to
								// leave blank
        showWeeks: false, // True to show week of the year, false to omit
        clean:false,
        pickByWeeks:false,// True to pick by week
        calculateWeek: this.iso8601Week, // How to calculate the week of the
											// year,
            // takes a Date and returns the number of the week for it
        shortYearCutoff: '+10', // Short year values < this are in the current
								// century,
            // > this are in the previous century,
            // string value starting with '+' for current year + value
        showStatus: false, // True to show status bar at bottom, false to not
							// show it
        statusForDate: this.dateStatus, // Function to provide status text for a
										// date -
            // takes date and instance as parameters, returns display text
        minDate: null, // The earliest selectable date, or null for no limit
        maxDate: null, // The latest selectable date, or null for no limit
        speed: 'normal', // Speed of display/closure
        beforeShowDay: null, // Function that takes a date and returns an
								// array with
            // [0] = true if selectable, false if not,
            // [1] = custom CSS class name(s) or '', e.g.
			// $.datetimepicker.noWeekends
        beforeShow: null, // Function that takes an input field and
            // returns a set of custom settings for the date picker
        onSelect: null, // Define a callback function when a date is selected
        onClose: null, // Define a callback function when the datetimepicker is
						// closed
        numberOfMonths: 1, // Number of months to show at a time
        stepMonths: 1, // Number of months to step back/forward
        rangeSelect: false, // Allows for selecting a date range on one date
							// picker
        rangeSeparator: ' - ', // Text between two dates in a range
        showDst:true
    };
    $.extend(this._defaults, this.regional['']);
    this._datetimepickerDiv = $('<div id="datetimepicker_div"></div>');
}

$.extend(DateTimepicker.prototype, {
    /*
	 * Class name added to elements to indicate already configured with a date
	 * picker.
	 */
    markerClassName: 'hasDatepicker',

    /* Debug logging (if enabled). */
    log: function () {
        if (this.debug)
            console.log.apply('', arguments);
    },

    /* Register a new date picker instance - with custom settings. */
    _register: function(inst) {
        var id = this._nextId++;
        this._inst[id] = inst;
        return id;
    },

    /* Retrieve a particular date picker instance based on its ID. */
    _getInst: function(id) {
        return this._inst[id] || id;
    },

    /*
	 * Override the default settings for all instances of the date picker.
	 * @param settings object - the new settings to use as defaults (anonymous
	 * object) @return the manager object
	 */
    setDefaults: function(settings) {
        if(!settings){
            settings = $.datetimepicker.getRegional('en');
        }
        var temp = settings.dateFormat;
        if(temp){
            settings.dateFormat = matchDateFormat(temp);
        }
        temp = settings.localDateFormat;
        if(temp){
            settings.localDateFormat = matchDateFormat(temp);
        }
        extendRemove(this._defaults, settings || {});
        return this;
    },

    /*
	 * Attach the date picker to a jQuery selection. @param target element - the
	 * target input field or division or span @param settings object - the new
	 * settings to use for this date picker instance (anonymous)
	 */
    _attachDatepicker: function(target, settings) {
        if(!$.datetimepicker.datetimeCssStyleReady)
        {
            $(document).find("head").append('<style type="text/css">.uee-view {min-height:340px;}</style>')
            $.datetimepicker.datetimeCssStyleReady = true;
        }
        settings = settings || {};
        // check for settings on the control itself - in namespace 'date:'
        var inlineSettings = null;
        for (attrName in this._defaults) {
            var attrValue = target.getAttribute('date:' + attrName);
            if (attrValue) {
                inlineSettings = inlineSettings || {};
                try {
                    inlineSettings[attrName] = eval(attrValue);
                } catch (err) {
                    inlineSettings[attrName] = attrValue;
                }
            }
        }
        var nodeName = target.nodeName.toLowerCase();
        var instSettings = inlineSettings ?  $.extend(settings, inlineSettings ) : settings;
        if (nodeName == 'input') {
            var inst = (inst && !inlineSettings ? inst :
                new DateTimepickerInstance(instSettings, false));
            this._connectDatepicker(target, inst);
            var provide_chars = " 0123456789";
            if(inst._settings.dateFormat)
            {
                provide_chars += inst._settings.dateFormat;
            }
            if(inst._settings.timeFormat)
            {
                provide_chars += inst._settings.timeFormat;
            }
            var re = /[mydhis]/gim;
            provide_chars = provide_chars.replace(re,"");
            provide_chars = provide_chars.replace(/\-/gim, "\\-");
            provide_chars = provide_chars.replace(/\//gim, "\\/");
            provide_chars = provide_chars.replace(/\./gim, "\\.");
            // dst is false when it is init. TODO:can be set to jBME.context
            if(inst._get("dst"))
            {
                // 如果开关设为false，不支持前台显示dst图标
                if(!$.datetimepicker._defaults.showDst)
                {
                    $("#"+settings.id+"_bmeDSTImg").hide();
                }
                inst.targetInput = $(target);
                (inst.targetInput).bind("focus",function(){
                    $(this).data("lastVal",$(this).val());
                });
                (inst.targetInput).bind("blur",function(){
                    $(this).data("newVal",$(this).val());
                    $.datetimepicker._dstTips(inst, $(this).val(), inst._get("olddateFormat"), false);
                });
            }
        } else if (nodeName == 'div' || nodeName == 'span') {
            var inst = new DateTimepickerInstance(instSettings, true);
            this._inlineDatepicker(target, inst);
        }
    },

    /*
	 * Detach a datetimepicker from its control. @param target element - the
	 * target input field or division or span
	 */
    _destroyDatepicker: function(target) {
        var nodeName = target.nodeName.toLowerCase();
        var calId = target._calId;
        target._calId = null;
        var $target = $(target);
        if (nodeName == 'input') {
            $target.siblings('.datetimepicker_append').replaceWith('').end()
                .siblings('.datetimepicker_trigger').replaceWith('').end()
                .removeClass(this.markerClassName)
                .unbind('focus', this._showDatepicker)
                .unbind('keydown', this._doKeyDown)
                .unbind('keypress', this._doKeyPress);
            var wrapper = $target.parents('.datetimepicker_wrap');
            if (wrapper)
                wrapper.replaceWith(wrapper.html());
        } else if (nodeName == 'div' || nodeName == 'span')
            $target.removeClass(this.markerClassName).empty();
        if ($('input[_calId=' + calId + ']').length == 0)
            // clean up if last for this ID
            this._inst[calId] = null;
    },

    /*
	 * Enable the date picker to a jQuery selection. @param target element - the
	 * target input field or division or span
	 */
    _enableDatepicker: function(target) {
        target.disabled = false;
        $(target).siblings('button.datetimepicker_trigger').each(function() { this.disabled = false; }).end()
            .siblings('img.datetimepicker_trigger').css({opacity: '1.0', cursor: ''});
        this._disabledInputs = $.map(this._disabledInputs,
            function(value) { return (value == target ? null : value); }); // delete
																			// entry
    },

    /*
	 * Disable the date picker to a jQuery selection. @param target element -
	 * the target input field or division or span
	 */
    _disableDatepicker: function(target) {
        target.disabled = true;
        $(target).siblings('button.datetimepicker_trigger').each(function() { this.disabled = true; }).end()
            .siblings('img.datetimepicker_trigger').css({opacity: '0.5', cursor: 'default'});
        this._disabledInputs = $.map($.datetimepicker._disabledInputs,
            function(value) { return (value == target ? null : value); }); // delete
																			// entry
        this._disabledInputs[$.datetimepicker._disabledInputs.length] = target;
    },

    /*
	 * Is the first field in a jQuery collection disabled as a datetimepicker?
	 * @param target element - the target input field or division or span
	 * @return boolean - true if disabled, false if enabled
	 */
    _isDisabledDatepicker: function(target) {
        if (!target)
            return false;
        for (var i = 0; i < this._disabledInputs.length; i++) {
            if (this._disabledInputs[i] == target)
                return true;
        }
        return false;
    },

    /*
	 * Update the settings for a date picker attached to an input field or
	 * division. @param target element - the target input field or division or
	 * span @param name string - the name of the setting to change or object -
	 * the new settings to update @param value any - the new value for the
	 * setting (omit if above is an object)
	 */
    _changeDatepicker: function(target, name, value) {
        var settings = name || {};
        if (typeof name == 'string') {
            settings = {};
            settings[name] = value;
        }
        if (inst = this._getInst(target._calId)) {
            extendRemove(inst._settings, settings);
            this._updateDatepicker(inst);
        }
    },

    /*
	 * Set the dates for a jQuery selection. @param target element - the target
	 * input field or division or span @param date Date - the new date @param
	 * endDate Date - the new end date for a range (optional)
	 */
    _setDateDatepicker: function(target, date, endDate) {
        if (inst = this._getInst(target._calId)) {
            inst._setDate(date, endDate);
            this._updateDatepicker(inst);
        }
    },

    /*
	 * Get the date(s) for the first entry in a jQuery selection. @param target
	 * element - the target input field or division or span @return Date - the
	 * current date or Date[2] - the current dates for a range
	 */
    _getDateDatepicker: function(target) {
        var inst = this._getInst(target._calId);
        return (inst ? inst._getDate() : null);
    },

    /* Handle keystrokes. */
    _doKeyDown: function(e) {
        var inst = $.datetimepicker._getInst(this._calId);
        if ($.datetimepicker._datetimepickerShowing)
            switch (e.keyCode) {
                case 9:
                        $.datetimepicker._hideDatepicker(null, '');
                        break; // hide on tab out
                case 13: $.datetimepicker._selectDay(inst, inst._selectedMonth, inst._selectedYear,
                            $('td.datetimepicker_daysCellOver', inst._datetimepickerDiv)[0]);
                        return false; // don't submit the form
                        break; // select the value on enter
                case 27: $.datetimepicker._hideDatepicker(null, inst._get('speed'));
                        break; // hide on escape
                case 33: $.datetimepicker._adjustDate(inst,
                            (e.ctrlKey ? -1 : -inst._get('stepMonths')), (e.ctrlKey ? 'Y' : 'M'));
                        break; // previous month/year on page up/+ ctrl
                case 34: $.datetimepicker._adjustDate(inst,
                            (e.ctrlKey ? +1 : +inst._get('stepMonths')), (e.ctrlKey ? 'Y' : 'M'));
                        break; // next month/year on page down/+ ctrl
                case 35: if (e.ctrlKey) $.datetimepicker._clearDate(inst);
                        break; // clear on ctrl+end
                case 36: if (e.ctrlKey) $.datetimepicker._gotoToday(inst);
                        break; // current on ctrl+home
                case 37: if (e.ctrlKey) $.datetimepicker._adjustDate(inst, -1, 'D');
                        break; // -1 day on ctrl+left
                case 38: if (e.ctrlKey) $.datetimepicker._adjustDate(inst, -7, 'D');
                        break; // -1 week on ctrl+up
                case 39: if (e.ctrlKey) $.datetimepicker._adjustDate(inst, +1, 'D');
                        break; // +1 day on ctrl+right
                case 40: if (e.ctrlKey) $.datetimepicker._adjustDate(inst, +7, 'D');
                        break; // +1 week on ctrl+down
        }
        else if (e.keyCode == 36 && e.ctrlKey) // display the date picker on
												// ctrl+home
            $.datetimepicker._showDatepicker(this);
    },

    /* Filter entered characters - based on date format. */
    _doKeyPress: function(e) {
        var inst = $.datetimepicker._getInst(this._calId);
        var chars = $.datetimepicker._possibleChars(inst._get('dateFormat'));
        var chr = String.fromCharCode(e.charCode == undefined ? e.keyCode : e.charCode);
        return e.ctrlKey || (chr < ' ' || !chars || chars.indexOf(chr) > -1);
    },

    /* Attach the date picker to an input field. */
    _connectDatepicker: function(target, inst) {
        var input = $(target);
        input.attr("instId", inst._id);
		input.attr("readonly", "readonly");
        // if (input.is('.' + this.markerClassName))
          // return;
        var appendText = inst._get('appendText');
        var isRTL = inst._get('isRTL');
        if (appendText) {
            if (isRTL)
                input.before('<span class="datetimepicker_append">' + appendText);
            else
                input.after('<span class="datetimepicker_append">' + appendText);
        }

        if(inst._get("showWeeks") && inst._get("pickByWeek"))
        {
            var datestr = target.value;
            if(datestr)
            {
                var date = inst._getDateFromField(target);
                var week = this.iso8601Week(date);
                var datestr = this.getWeekStr(date,week,inst);
                $("#"+input.attr('id')+"_showweek").val(datestr);
            }
        }
        var showOn = inst._get('showOn');
        if (showOn == 'focus' || showOn == 'both') // pop-up date picker when
													// in the marked field
            input.focus(this._showDatepicker);
        if (showOn == 'button' || showOn == 'both') { // pop-up date picker
														// when button clicked
            if(input.disabled)
            {
                return;
            }
            var buttonText = inst._get('buttonText');
            var trigger;
            var parentElement = input.parent();
			var ocDate = parentElement.hasClass('oc-date');
			var ocDatetime = parentElement.hasClass('oc-datetime');
            if(!ocDate && !ocDatetime){
                var dv = input.closest(".uee-border");
                trigger = dv.next();
            }
            else{
                trigger = input.next();
            }
            trigger.attr({title: buttonText});
            trigger.click(function() {
                // ticker("start",1);
                if ($.datetimepicker._datetimepickerShowing && $.datetimepicker._lastInput == target)
                    $.datetimepicker._hideDatepicker();
                else
                    $.datetimepicker._showDatepicker(target);
                // ticker("end");
            });
        }
        input.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress)
            .bind("setData.datetimepicker", function(event, key, value) {
                inst._settings[key] = value;
            }).bind("getData.datetimepicker", function(event, key) {
                return inst._get(key);
            });
        input[0]._calId = inst._id;
    },

    /* Attach an inline date picker to a div. */
    _inlineDatepicker: function(target, inst) {
        var input = $(target);
        if (input.is('.' + this.markerClassName))
            return;
        input.addClass(this.markerClassName).append(inst._datetimepickerDiv)
            .bind("setData.datetimepicker", function(event, key, value){
                inst._settings[key] = value;
            }).bind("getData.datetimepicker", function(event, key){
                return inst._get(key);
            });
        input[0]._calId = inst._id;
        this._updateDatepicker(inst);
    },

    /* Tidy up after displaying the date picker. */
    _inlineShow: function(inst) {
        var numMonths = inst._getNumberOfMonths(); // fix width for dynamic
													// number of date pickers
        inst._datetimepickerDiv.width(numMonths[1] * $('.datetimepicker', inst._datetimepickerDiv[0]).width());
    },

    /*
	 * Pop-up the date picker in a "dialog" box. @param input element - ignored
	 * @param dateText string - the initial date to display (in the current
	 * format) @param onSelect function - the function(dateText) to call when a
	 * date is selected @param settings object - update the dialog date picker
	 * instance's settings (anonymous object) @param pos int[2] - coordinates
	 * for the dialog's position within the screen or event - with x/y
	 * coordinates or leave empty for default (screen centre) @return the
	 * manager object
	 */
    _dialogDatepicker: function(input, dateText, onSelect, settings, pos) {
        var inst = this._dialogInst; // internal instance
        if (!inst) {
            inst = this._dialogInst = new DateTimepickerInstance({}, false);
            this._dialogInput = $('<input type="text" size="1" style="position: absolute; _ysp_top: -100px;"/>');
            this._dialogInput.keydown(this._doKeyDown);
            $('body').append(this._dialogInput);
            this._dialogInput[0]._calId = inst._id;
        }
        extendRemove(inst._settings, settings || {});
        this._dialogInput.val(dateText);

        this._pos = (pos ? (pos.length ? pos : [pos.pageX, pos.pageY]) : null);
        if (!this._pos) {
            var browserWidth = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
            var browserHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
            var scrollX = document.documentElement.scrollLeft || document.body.scrollLeft;
            var scrollY = document.documentElement.scrollTop || document.body.scrollTop;
            this._pos = // should use actual width/height below
                [(browserWidth / 2) - 100 + scrollX, (browserHeight / 2) - 150 + scrollY];
        }

        // move input on screen for focus, but hidden behind dialog
        this._dialogInput.css('left', this._pos[0] + 'px').css('_ysp_top', this._pos[1] + 'px');
        inst._settings.onSelect = onSelect;
        this._inDialog = true;
        this._datetimepickerDiv.addClass('datetimepicker_dialog');
        this._showDatepicker(this._dialogInput[0]);
        if ($.blockUI)
            $.blockUI(this._datetimepickerDiv);
        return this;
    },

    /*
	 * Pop-up the date picker for a given input field. @param input element -
	 * the input field attached to the date picker or event - if triggered by
	 * focus
	 */
    _showDatepicker: function(input) {
        // Doesn't response the event if the input is disabled.
        if(input.disabled)
        {
            return;
        }

        this._datetimepickerDiv.bind("click mousedown",function(e){
        	e.stopPropagation();
        	return;
        });

        $(input).keydown(this._doKeyDown);
        input = input.target || input;
        if (input.nodeName.toLowerCase() != 'input') // find from
														// button/image trigger
            input = $('input', input.parentNode)[0];
        if ($.datetimepicker._isDisabledDatepicker(input) || $.datetimepicker._lastInput == input) // already
																									// here
            return;
        var inst = $.datetimepicker._getInst(input._calId);
        var beforeShow = inst._get('beforeShow');
        extendRemove(inst._settings, (beforeShow ? beforeShow.apply(input, [input, inst]) : {}));
        $.datetimepicker._hideDatepicker(null, '');
        $.datetimepicker._lastInput = input;
        inst._setDateFromField(input);
        if ($.datetimepicker._inDialog) // hide cursor
            input.value = '';
// if (!$.datetimepicker._pos) { // position below input
// $.datetimepicker._pos = $.datetimepicker._findPos(input);
// $.datetimepicker._pos[1] += input.offsetHeight; // add the height
// }
// var isFixed = false;
// $(input).parents().each(function() {
// isFixed |= $(this).css('position') == 'fixed';
// });
// if (isFixed && $.browser.opera) { // correction for Opera when fixed and
// scrolled
// $.datetimepicker._pos[0] -= document.documentElement.scrollLeft;
// $.datetimepicker._pos[1] -= document.documentElement.scrollTop;
// }
// inst._datetimepickerDiv.css('position', ($.datetimepicker._inDialog &&
// $.blockUI ?
// 'static' : (isFixed ? 'fixed' : 'absolute')))
// .css({ left: $.datetimepicker._pos[0] + 'px', _ysp_top: $.datetimepicker._pos[1] +
// 'px' });
// $.datetimepicker._pos = null;
        inst._rangeStart = null;
        $.datetimepicker._updateDatepicker(inst);
        if (!inst._inline) {
            var speed = inst._get('speed');

            // 当配置了选择周，以 _showweek的input为基准弹出
            if(inst._settings.showWeeks && inst._settings.pickByWeek)
            {
                var showtarget = $("#"+input.id+"_showweek");
                inst.poper.show(showtarget,{'adjustHeight':21});
            }
            else
            {
                inst.poper.show($(input),{'adjustHeight':21});
            }

            $.datetimepicker._afterShow(inst);
            $.datetimepicker._datetimepickerShowing = true;

            if (speed == '')
                postProcess();
// if (inst._input[0].type != 'hidden')
// inst._input[0].focus();
            $.datetimepicker._curInst = inst;
        }
    },
    /* Generate the date picker content. */
    _updateDatepicker: function(inst) {
        var genPicker=inst._generateDatepicker();
        inst._datetimepickerDiv.empty().append(genPicker);
        var df = inst._get('dateFormat');
        var tf = df.split(" ")[1];
        if(!tf||tf==""||tf=="undefined")
        {
            tf = "HH:mm:ss";
        }
        if(inst._get('displaytime'))
        {
            this._hideTimePickerPoper();
            inst._datetimepickerDiv.find(".datetimepicker_timepicker").timePicker({"onchange": function(val) {
                $.datetimepicker._selectTimeFull(inst, val);
            }, "containerStyle": "absolute", timeFormat: tf,datetime:true});
        }
        var numMonths = inst._getNumberOfMonths();
        if (numMonths[0] != 1 || numMonths[1] != 1)
            inst._datetimepickerDiv.addClass('datetimepicker_multi');
        else
            inst._datetimepickerDiv.removeClass('datetimepicker_multi');

        if (inst._get('isRTL'))
            inst._datetimepickerDiv.addClass('datetimepicker_rtl');
        else
            inst._datetimepickerDiv.removeClass('datetimepicker_rtl');
// if (inst._input && inst._input[0].type != 'hidden')
// $(inst._input[0]).focus();
    },

    /* Tidy up after displaying the date picker. */
    _afterShow: function(inst) {
        var numMonths = inst._getNumberOfMonths(); // fix width for dynamic
													// number of date pickers
        inst._datetimepickerDiv.width(numMonths[1] * $('.datetimepicker', inst._datetimepickerDiv[0])[0].offsetWidth);
// if ($.browser.msie && parseInt($.browser.version) < 7) { // fix IE < 7 select
// problems
// $('iframe.datetimepicker_cover').css({width: inst._datetimepickerDiv.width()
// + 4,
// height: inst._datetimepickerDiv.height() + 4});
// }
        // re-position on screen if necessary
// var isFixed = inst._datetimepickerDiv.css('position') == 'fixed';
// var pos = inst._input ? $.datetimepicker._findPos(inst._input[0]) : null;
// var browserWidth = window.innerWidth || document.documentElement.clientWidth
// || document.body.clientWidth;
// var browserHeight = window.innerHeight ||
// document.documentElement.clientHeight || document.body.clientHeight;
// var scrollX = (isFixed ? 0 : document.documentElement.scrollLeft ||
// document.body.scrollLeft);
// var scrollY = (isFixed ? 0 : document.documentElement.scrollTop ||
// document.body.scrollTop);
// // reposition date picker horizontally if outside the browser window
// if ((inst._datetimepickerDiv.offset().left + inst._datetimepickerDiv.width()
// -
// (isFixed && $.browser.msie ? document.documentElement.scrollLeft : 0)) >
// (browserWidth + scrollX)) {
// inst._datetimepickerDiv.css('left', Math.max(scrollX,
// pos[0] + (inst._input ? $(inst._input[0]).width() : null) -
// inst._datetimepickerDiv.width() -
// (isFixed && $.browser.opera ? document.documentElement.scrollLeft : 0)) +
// 'px');
// }
// // reposition date picker vertically if outside the browser window
// if ((inst._datetimepickerDiv.offset()._ysp_top +
// Math.max(inst._datetimepickerDiv.height(),
// inst._datetimepickerShadow.jqShadow.outerHeight()) -
// (isFixed && $.browser.msie ? document.documentElement.scrollTop : 0)) >
// (browserHeight + scrollY) ) {
// inst._datetimepickerDiv.css('_ysp_top', Math.max(scrollY,
// pos[1] - (this._inDialog ? 0 : inst._datetimepickerDiv.height()) -
// (isFixed && $.browser.opera ? document.documentElement.scrollTop : 0) - 6) +
// 'px');
// }
    },

    // 点击复选框设置dstChecked，避免选中后切换日期会导致复选框未选中
    setDstChecked:function(inst, c){
        // var input=$(".datetimepicker_dsl input",inst._datetimepickerDiv);
        var dstHidden = $("#"+inst._get("idPrefix")+"_bmeDSTChecked");
        var dstImg = $("#"+inst._get("idPrefix")+"_bmeDSTImg");
        var container = $("#"+inst._get("idPrefix"));
        if(c){
            dstHidden.val("true");
            container.scope().$Dstshow = true;
        }
        else{
            dstHidden.val("false");
            container.scope().$Dstshow = false;
        }
        // check again
        inst.targetInput.valid();
    },

    /* Find an object's position on the screen. */
    _findPos: function(obj) {
        while (obj && (obj.type == 'hidden' || obj.nodeType != 1)) {
            obj = obj.nextSibling;
        }
        var position = $(obj).offset();
        return [position.left, position._ysp_top];
    },

    /*
	 * Hide the date picker from view. @param input element - the input field
	 * attached to the date picker @param speed string - the speed at which to
	 * close the date picker
	 */
    _hideDatepicker: function(input, speed) {
        var inst = this._curInst;
        if (!inst)
            return;

        this._datetimepickerDiv.unbind("click mousedown");

        var rangeSelect = inst._get('rangeSelect');
        if (rangeSelect && this._stayOpen) {
            this._selectDate(inst, inst._formatDateTime(
                inst._currentDay, inst._currentMonth, inst._currentYear, inst._currentHour, inst.currentMinute, inst.currentSecond));
        }
        this._stayOpen = false;
        if (this._datetimepickerShowing) {
            inst.poper.hide();
            speed = (speed != null ? speed : inst._get('speed'));
            var showAnim = inst._get('showAnim');
            inst._datetimepickerDiv[(showAnim == 'slideDown' ? 'slideUp' :
                (showAnim == 'fadeIn' ? 'fadeOut' : 'hide'))](speed, function() {
                $.datetimepicker._tidyDialog(inst);
            });
            if (speed == '')
                this._tidyDialog(inst);
            var onClose = inst._get('onClose');
            if (onClose) {
                onClose.apply((inst._input ? inst._input[0] : null),
                    [inst._getDate(), inst]);  // trigger custom callback
            }
            this._datetimepickerShowing = false;
            this._lastInput = null;
            inst._settings.prompt = null;
            if (this._inDialog) {
                this._dialogInput.css({ position: 'absolute', left: '0', _ysp_top: '-100px' });
                if ($.blockUI) {
                    $.unblockUI();
                    $('body').append(this._datetimepickerDiv);
                }
            }
            this._inDialog = false;
        }
        this._curInst = null;
        inst._datetimepickerDiv.empty();
        if (inst._get('displaytime'))
        {
            this._hideTimePickerPoper();
        }
    },

    /* Tidy up after a dialog display. */
    _tidyDialog: function(inst) {
        inst._datetimepickerDiv.removeClass('datetimepicker_dialog').unbind('.datetimepicker');
        $('.datetimepicker_prompt', inst._datetimepickerDiv).remove();
    },

    /* Close date picker if clicked elsewhere. */
    _checkExternalClick: function(event) {
        if (!$.datetimepicker._curInst)
            return;
        var $target = $(event.target);
        if (($target.parents("#datetimepicker_div").length == 0) &&
                $.datetimepicker._datetimepickerShowing && !($.datetimepicker._inDialog && $.blockUI) &&
                (!$target.hasClass('timepicker_selectlist')) && (!$target.parent().hasClass('timepicker_selectlist')) &&
                (!$target.hasClass('datetimepicker_trigger'))) {
            $(".timepicker_selectlist:visible").hide();
            $.datetimepicker._hideDatepicker(null, '');
        }
    },

    /* Adjust one of the date sub-fields. */
    _adjustDate: function(id, offset, period) {
        var inst = this._getInst(id);
        inst._adjustDate(offset, period);
        this._updateDatepicker(inst);
    },

    /* Action for current link. */
    _gotoToday: function(id) {
        var date = new Date();
        var inst = this._getInst(id);
        inst._selectedDay = date.getDate();
        inst._drawMonth = inst._selectedMonth = date.getMonth();
        inst._drawYear = inst._selectedYear = date.getFullYear();
        inst._drawHour = inst._selectedHour = date.getHours();
        inst._drawMinute = inst._selectedMinute = date.getMinutes();
        inst._drawSecond = inst._selectedSecond = date.getSeconds();
        this._adjustDate(inst);
    },

    /* Action for selecting a new month/year. */
    _selectMonthYear: function(id, select, period) {
        if(select && select.selectedIndex > -1){
            var selectclass = $(select).attr("class");
            var inst = this._getInst(id);
            inst._selectingMonthYear = false;
            inst[period == 'M' ? '_drawMonth' : '_drawYear'] =
                select.options[select.selectedIndex].value - 0;
            this._adjustDate(inst);
            $("."+selectclass).focus();
        }
    },
    _selectTime: function(id, select, period) {
        var inst = this._getInst(id);
        inst._selectingMonthYear = false;
        var periodStr;
        if(period == 'S')
        {
            periodStr = '_drawSecond';
        }
        else if(period == 'M')
        {
            periodStr = '_drawMinute';
        }
        else
        {
            periodStr = '_drawHour';
        }
        inst[periodStr] =
            select.options[select.selectedIndex].value - 0;
        this._adjustDate(inst);

        this._doNotHide = true;
        $('td.datetimepicker_currentDay').each(function(){
            $.datetimepicker._selectDay(inst, inst._selectedMonth, inst._selectedYear, $(this));
        });
        this._doNotHide = false;
    },
    _selectTimeFull: function(inst, timeStr) {
        var timeArr = timeStr.split(':');
        inst['_drawHour'] = inst['_selectedHour'] = timeArr[0]-0;
        inst['_drawMinute'] = inst['_selectedMinute'] = timeArr[1]-0;
        inst['_drawSecond'] = inst['_selectedSecond'] = timeArr[2]-0;
    },

    /* Restore input focus after not changing month/year. */
    _clickMonthYear: function(id) {
        var inst = this._getInst(id);
// if (inst._input && inst._selectingMonthYear && !$.browser.msie)
// inst._input[0].focus();
        inst._selectingMonthYear = !inst._selectingMonthYear;
    },

    _clickTime: function(id) {
        var inst = this._getInst(id);
        if (inst._input && inst._selectingTime && !$.browser.msie)
            inst._input[0].focus();
        inst._selectingTime = !inst._selectingTime;
    },

    /* Action for changing the first week day. */
    _changeFirstDay: function(id, day) {
        var inst = this._getInst(id);
        inst._settings.firstDay = day;
        this._updateDatepicker(inst);
    },

    /* Action for selecting a day. */
    _selectDay: function(id, month, year, td) {
        if ($(td).is('.datetimepicker_unselectable'))
            return;
        var inst = this._getInst(id);
        if(inst._get("showWeeks") && inst._get("pickByWeek"))
        {
            td = $(td).parent().children("td.firstDayOfWeek")
        }
        var rangeSelect = inst._get('rangeSelect');
        if (rangeSelect) {
            if (!this._stayOpen) {
                $('.datetimepicker td').removeClass('datetimepicker_currentDay');
                $(td).addClass('datetimepicker_currentDay');
            }
            this._stayOpen = !this._stayOpen;
        }
            inst._selectedDay = inst._currentDay = $('a', td).attr("value");
        inst._selectedMonth = inst._currentMonth = month;
        inst._selectedYear = inst._currentYear = year;
        var selectedDay = inst._currentDay;
        var selectedMonth = inst._currentMonth;
        var selectedYear = inst._currentYear;
        if(inst._selectedYear>1893 && inst._selectedYear<2044 && inst._get("calendric"))
        {
            var calendric = parseInt(inst._get("calendric"));
// inst._selectedMonth = inst._drawMonth = inst._currentMonth = month;
// inst._selectedYear = inst._drawYear = inst._currentYear = year;
            var lDate = gregorianToLocal(calendric, year, (month+1), inst._currentDay);
            /*
			 * selectedDay = lDate.day; selectedMonth = lDate.month-1;
			 * selectedYear = lDate.year;
			 */
        }
        if (inst._get('displaytime'))
        {
            inst._selectedHour = inst._currentHour = inst._drawHour;
            inst._selectedMinute = inst._currentMinute = inst._drawMinute;
            inst._selectedSecond = inst._currentSecond = inst._drawSecond;
            this._updateDatepicker(inst);
            // 选择的不是当月时间的时候日历控件跳转到选择月
            if(inst._selectedYear > inst._drawYear)
            {
                $.datetimepicker._adjustDate(id,1,"M");
            }
            else if(inst._selectedYear < inst._drawYear)
            {
                $.datetimepicker._adjustDate(id,-1,"M");
            }
            else
            {
                if(inst._selectedMonth > inst._drawMonth)
                {
                    $.datetimepicker._adjustDate(id,1,"M");
                }
                else if(inst._selectedMonth < inst._drawMonth)
                {
                    $.datetimepicker._adjustDate(id,-1,"M");
                }
            }
            // 当我选中状态或者当天状态 再次点击实现选择日期功能,模拟双击事件
            if($(td).is(":not('.datetimepicker_today')") && $(td).is(":not('.datetimepicker_currentDay')"))
                {
                    return;
               }
        }
        else
        {
            inst._selectedHour = inst._currentHour = 0;
            inst._selectedMinute = inst._currentMinute = 0;
            inst._selectedSecond = inst._currentSecond = 0;
        }
        if(inst._get('displaytime') || (inst._settings.kind =="date" && inst._settings.timepoint))
        {
            var datetimepoint = inst._settings.kind =="date" && inst._settings.timepoint;
            if(inst._get("dst")){
            var t = inst._formatDateTime(selectedDay, selectedMonth, selectedYear, inst._drawHour, inst._drawMinute, inst._drawSecond);
            var f = inst._settings["olddateFormat"];
            // 时期是date类型并且配置了timepoint并且默认的displayformat没有时分秒，在计算是否处于夏令时的时候，给时间补上时分秒
            if(datetimepoint && f.indexOf("HH")<0 && f.indexOf("hh")<0)
            {
                if(inst._settings.timepoint == "begin")
                {
                    t = t+" 00:00:00";
                }
                else if(inst._settings.timepoint == "end")
                {
                    t = t+" 23:59:59";
                }
                else
                {
                    t = t + " " + inst._settings.timepoint;
                }
                f = f+ " HH:mm:ss";
            }
            this._dstTips(inst, t, f, true);
            }
        }
        var date = new Date(selectedYear,selectedMonth,selectedDay);
        this._selectDate(id, inst._formatDateTime(
                selectedDay, selectedMonth, selectedYear, inst._currentHour, inst._currentMinute, inst._currentSecond)
                    ,(inst._get("showWeeks") && inst._get("pickByWeek"))?this.getWeekStr(date,this.iso8601Week(date),inst):null);

        this._dstAdjustTip(inst, selectedYear, selectedMonth, selectedDay, inst._drawHour, inst._drawMinute, inst._drawSecond);

        if (this._stayOpen) {
            inst._endDay = inst._endMonth = inst._endYear = null;
            inst._rangeStart = new Date(inst._currentYear, inst._currentMonth, inst._currentDay);
            this._updateDatepicker(inst);
        }
        else if (rangeSelect) {
            inst._endDay = inst._currentDay;
            inst._endMonth = inst._currentMonth;
            inst._endYear = inst._currentYear;
            inst._selectedDay = inst._currentDay = inst._rangeStart.getDate();
            inst._selectedMonth = inst._currentMonth = inst._rangeStart.getMonth();
            inst._selectedYear = inst._currentYear = inst._rangeStart.getFullYear();
            inst._rangeStart = null;
            if (inst._inline)
                this._updateDatepicker(inst);
        }
    },

    /* Erase the input field and hide the date picker. */
    _clearDate: function(id) {
        var inst = this._getInst(id);
        if (inst._get('mandatory'))
            return;
        this._stayOpen = false;
        inst._endDay = inst._endMonth = inst._endYear = inst._rangeStart = null;
        this._selectDate(inst, '');
    },

    /* Update the input field with the selected date. */
    _selectDate: function(id, dateStr, weekstr) {
        var inst = this._getInst(id);
        dateStr = (dateStr != null ? dateStr : inst._formatDateTime());
        if (inst._rangeStart)
            dateStr = inst._formatDateTime(inst._rangeStart) + inst._get('rangeSeparator') + dateStr;
        if (inst._input)
            inst._input.val(dateStr);

        // 当日期控件是选择周模式的时候，还需要向用于展示的input回填周相关信息
        if(weekstr && inst._settings.showWeeks && inst._settings.pickByWeek)
        {
            $("#"+inst._input.attr("id")+"_showweek").val(weekstr);
        }

        var onSelect = inst._get('onSelect');
        if (onSelect)
            onSelect.apply((inst._input ? inst._input[0] : null), [dateStr, inst]);  // trigger
																						// custom
																						// callback
        else if (inst._input)
            inst._input.trigger('change'); // fire the change event
        if (inst._inline)
            this._updateDatepicker(inst);
        else if (!this._stayOpen) {
            if (! this._doNotHide) {
                this._hideDatepicker(null, inst._get('speed'));
                this._lastInput = inst._input[0];
                if (typeof(inst._input[0]) != 'object')
                    inst._input[0].focus(); // restore focus
                this._lastInput = null;
            }
        }
        $(inst._input[0]).valid();
    },

    // IE下点击日期单元格等,时间控件下拉选项不会隐藏
    _hideTimePickerPoper:function(){
        if($.timePicker.hotPoper){
            $.timePicker.hotPoper.hide();
            $.timePicker.hotPoper = null;
        }
    },

    /*
	 * Dst时区提示 flag 标识是否是来自日期选择面板的提示
	 */
    _dstTips: function(inst, time, datetimeFormat, flag){
	    if(!$.datetimepicker._defaults.showDst)
	    {
	        return;
	    }
        if(inst.targetInput.data("newVal") == inst.targetInput.data("lastVal") && !flag){return;}
        var property = inst.targetInput.attr("name");
        if(property){
        	var config = inst.targetInput.scope().$eval(property);
        }

        // string类型的数据不进行夏令时转换
        if(config && angular.isNumber(config)){
            if($UEE.$Tz && $UEE.$Tz.dstdisplay){
            	if($UEE.$Tz.browserTimezone.name != "u-browserTz"){
            		var scope = $(document.body).scope();
                	var $Date = scope.$Get("$Date");
                	var displayformat = inst.targetInput.scope().$input.displayformat;
                	var _time = gcu_LocalString2Date(time,displayformat);
                	if(!time){return;}

                	var i = $Date.inDst($Date.parseDateFromFormat(displayformat, time));
                    switch(i)
                    {
                    case 1:
                        var d = _time;
                        // 若时间处于空白区，使用gcu_LocalString2Date转换后的hour会向后+1，
                        // 而这里的处理方式是向前-1，所以_formatDateTime里传入的时间要-2
                        var _d = inst._formatDateTime(d.getDate(), d.getMonth(), d.getFullYear(), d.getHours()-1, d.getMinutes(), d.getSeconds());
                        var _d1 = inst._formatDateTime(d.getDate(), d.getMonth(), d.getFullYear(), d.getHours(), d.getMinutes(), d.getSeconds());
                        if(_d == _d1){
                        	_d = inst._formatDateTime(d.getDate(), d.getMonth(), d.getFullYear(), d.getHours()-2, d.getMinutes(), d.getSeconds())
                        }
                        inst.targetInput.val(_d);
        				inst._drawHour = inst._drawHour-1;
        				inst._selectedHour = inst._selectedHour-1;

        				this.setDstChecked(inst, false);
                        alert(inst._get("adjustTip"));
                        break;
                    case -1:
                        // 正常时间
                        this.setDstChecked(inst, false);
                        break;
                    case 0:
                        // 重复区
                        // $.dialog.confirm("提示信息","指定时间为重复时间，是否使用DST时间",_check,_uncheck);
                        // 由于使用$.dialog.confirm会导致日期控件隐藏，暂时用confirm
                        if(confirm(inst._get("dstConfirmMsg"))){
                            this.setDstChecked(inst, true);
                        }
                        else{
                            this.setDstChecked(inst, false);
                        }
                        break;
                    case 2:
                        // 夏令时
                        this.setDstChecked(inst, true);
                        break;
                    }
            	}else{
                    var i = gcu_isSwitchTime(time, datetimeFormat);

                    switch(i)
                    {
                    case -1:
                        var d = gcu_LocalString2Date(time ,inst._get("olddateFormat"));
                        var _d = inst._formatDateTime(d.getDate(), d.getMonth(), d.getFullYear(), d.getHours(), d.getMinutes(), d.getSeconds());
                        inst.targetInput.val(_d);
        				inst._drawHour = inst._drawHour-1;
        				inst._selectedHour = inst._selectedHour-1;
                        this.setDstChecked(inst, false);
                        alert(inst._get("adjustTip"));
                        break;
                    case 0:
                        // 正常时间
                        this.setDstChecked(inst, false);
                        break;
                    case 1:
                        // 重复区
                        // $.dialog.confirm("提示信息","指定时间为重复时间，是否使用DST时间",_check,_uncheck);
                        // 由于使用$.dialog.confirm会导致日期控件隐藏，暂时用confirm
                        if(confirm(inst._get("dstConfirmMsg"))){
                            this.setDstChecked(inst, true);
                        }
                        else{
                            this.setDstChecked(inst, false);
                        }
                        break;
                    case 2:
                        // 夏令时
                        this.setDstChecked(inst, true);
                        break;
                    }
            	}
            }
        }

    },

    _dstAdjustTip: function(inst, year, month, day, hour, minute, second){
        // 由于_formatDateTime方法会将空白区时间转换为非空白区时间,所以使用getFormatedHour来获取转换后的 小时,
        // 并与转换前的小时对比
	    if(!$.datetimepicker._defaults.showDst)
	    {
	        return;
	    }
        if(inst._get("dst") && inst._get('displaytime')){
            var _hour = (new Date(year, month, day, hour, minute, second)).getHours();
            if(_hour != inst._selectedHour){
                alert(inst._get("adjustTip"));
            }
        }

    },

    /* Click event for Ok button */
    _selectDateByButton: function(id, day, month, year) {
        var inst = this._getInst(id);
        if(inst._get("dst") && inst._get('displaytime')){
            var t = inst._formatDateTime(day, month, year, inst._drawHour, inst._drawMinute, inst._drawSecond);
            var f = inst._settings["olddateFormat"];
            this._dstTips(inst, t, f, true);
        }
        if(inst.isSelectable(inst._settings.filter, new Date(year,month,day,0,0,0)))
        {
            if(inst._get("showWeeks") && inst._get("pickByWeek"))
            {
                var date = new Date(year,month,day);
                var weekstr = this.getWeekStr(date,this.iso8601Week(date),inst);
                this._selectDate(id, inst._formatDateTime(day, month, year, inst._drawHour, inst._drawMinute, inst._drawSecond),weekstr);
            }
            else
            {
                this._selectDate(id, inst._formatDateTime(day, month, year, inst._drawHour, inst._drawMinute, inst._drawSecond));
            }
            this._dstAdjustTip(inst, year, month, day, inst._drawHour, inst._drawMinute, inst._drawSecond);
        }
    },

    /*
	 * Set as beforeShowDay function to prevent selection of weekends. @param
	 * date Date - the date to customise @return [boolean, string] - is this
	 * date selectable?, what is its CSS class?
	 */
    noWeekends: function(date) {
        var day = date.getDay();
        return [(day > 0 && day < 6), ''];
    },

    /*
	 * Set as calculateWeek to determine the week of the year based on the ISO
	 * 8601 definition. @param date Date - the date to get the week for @return
	 * number - the number of the week within the year that contains this date
	 */
    iso8601Week: function(date) {
        var firstday = $.datetimepicker._defaults.firstDay?$.datetimepicker._defaults.firstDay:0;
        var dayInFirstWeek = $.datetimepicker._defaults.dayInFirstWeek?$.datetimepicker._defaults.dayInFirstWeek:1;
        if(dayInFirstWeek > 8){dayInFirstWeek = 1;}
        var checkDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), (date.getTimezoneOffset() / -60));
        var firstMon = new Date(checkDate.getFullYear(), 1 - 1, dayInFirstWeek); // First
																					// week
																					// always
																					// contains
																					// 4
																					// Jan
        var firstDay = (firstday == 0)?firstMon.getDay():(firstMon.getDay()||7); // Day
																					// of
																					// week:
																					// Mon
																					// = 1,
																					// ...,
																					// Sun
																					// = 7
        firstMon.setDate(firstMon.getDate() + firstday - firstDay); // Preceding
																	// Monday
        if (firstDay < dayInFirstWeek && checkDate < firstMon) { // Adjust
																	// first
																	// three
																	// days in
																	// year if
																	// necessary
            checkDate.setDate(checkDate.getDate() - dayInFirstWeek-1); // Generate
																		// for
																		// previous
																		// year
            return $.datetimepicker.iso8601Week(checkDate);
        } else if (new Date(checkDate.getFullYear(),checkDate.getMonth(),checkDate.getDate()+6) > new Date(checkDate.getFullYear(), 12 - 1, 31)) { // Check
																																					// last
																																					// three
																																					// days
																																					// in
																																					// year
                // 如果当前周中含有下一年的日期，以一周最后一天的日期（下年日期）计算本周
                if(new Date(checkDate.getFullYear(),checkDate.getMonth(),checkDate.getDate()+6) >= new Date(checkDate.getFullYear()+1,0,dayInFirstWeek))
                {
                    return $.datetimepicker.iso8601Week(new Date(checkDate.getFullYear(),checkDate.getMonth(),checkDate.getDate()+6));
                }
            }
        return Math.floor(((checkDate - firstMon) / 86400000) / 7) + 1; // Weeks
																		// to
																		// given
																		// date
    },

    /*
	 * 获取回填的周信息 默认显示格式年:xx,周:xx（firstdate-lastdate）
	 */
    getWeekStr: function(date,week,inst)
    {
        // get firstday of week
        var day = date.getDay();
        if(day%7 != inst._get("firstDay"))
        {
            date.setDate(date.getDate()-(day%7-inst._get("firstDay")))
        }

        // get formatDateTime
        var beginetime = inst._formatDateTime(date.getDate(),date.getMonth(),date.getFullYear());
        var endtime = inst._formatDateTime((date.getDate()+6),date.getMonth(),date.getFullYear());
        // join weekstr
        return [inst._get("year")
                ,":"
                ,(date.getMonth() == 11 && week == 1)?(date.getFullYear()+1):date.getFullYear()
                ,","
                ,inst._get("week")
                ,":"
                ,week
                ,"("
                ,beginetime
                ,inst._get("weekstrSeparator")
                ,endtime
                ,")"].join("") ;
    },
    /*
	 * Provide status text for a particular date. @param date the date to get
	 * the status for @param inst the current datetimepicker instance @return
	 * the status display text for this date
	 */
    dateStatus: function(date, inst) {
        return $.datetimepicker.formatDate(inst._get('dateStatus'), date, inst._getFormatConfig());
    },

    /*
	 * Parse a string value into a date object. The format can be combinations
	 * of the following: d - day of month (no leading zero) dd - day of month
	 * (two digit) D - day name short DD - day name long m - month of year (no
	 * leading zero) mm - month of year (two digit) M - month name short MM -
	 * month name long y - year (two digit) yy - year (four digit) '...' -
	 * literal text '' - single quote
	 *
	 * @param format String - the expected format of the date @param value
	 * String - the date in the above format @param settings Object - attributes
	 * include: shortYearCutoff Number - the cutoff year for determining the
	 * century (optional) dayNamesShort String[7] - abbreviated names of the
	 * days from Sunday (optional) dayNames String[7] - names of the days from
	 * Sunday (optional) monthNamesShort String[12] - abbreviated names of the
	 * months (optional) monthNames String[12] - names of the months (optional)
	 * @return Date - the extracted date value or null if value is blank
	 */
    parseDate: function (format, value, settings) {
        if (format == null || value == null)
            throw 'Invalid arguments';
        value = (typeof value == 'object' ? value.toString() : value + '');
        if (value == '')
            return null;
        var shortYearCutoff = (settings ? settings.shortYearCutoff : null) || this._defaults.shortYearCutoff;
        var dayNamesShort = (settings ? settings.dayNamesShort : null) || this._defaults.dayNamesShort;
        var dayNames = (settings ? settings.dayNames : null) || this._defaults.dayNames;
        var monthNamesShort = (settings ? settings.monthNamesShort : null) || this._defaults.monthNamesShort;
        var monthNames = (settings ? settings.monthNames : null) || this._defaults.monthNames;
        var year = -1;
        var month = -1;
        var day = -1;
        var hour = -1;
        var minute = -1;
        var second = -1;
        var literal = false;
        // Check whether a format character is doubled
        var lookAhead = function(match) {
            var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) == match);
            if (matches)
                iFormat++;
            return matches;
        };
        // Extract a number from the string value
        var getNumber = function(match) {
            lookAhead(match);
            var size = (match == 'y' ? 4 : 2);
            var num = 0;
            while (size > 0 && iValue < value.length &&
                    value.charAt(iValue) >= '0' && value.charAt(iValue) <= '9') {
                num = num * 10 + (value.charAt(iValue++) - 0);
                size--;
            }
            if (size == (match == 'y' ? 4 : 2))
                throw 'Missing number at position ' + iValue;
            return num;
        };
        // Extract a name from the string value and convert to an index
        var getName = function(match, shortNames, longNames) {
            var names = (lookAhead(match) ? longNames : shortNames);
            var size = 0;
            for (var j = 0; j < names.length; j++)
                size = Math.max(size, names[j].length);
            var name = '';
            var iInit = iValue;
            while (size > 0 && iValue < value.length) {
                name += value.charAt(iValue++);
                for (var i = 0; i < names.length; i++)
                    if (name == names[i])
                        return i + 1;
                size--;
            }
            throw 'Unknown name at position ' + iInit;
        };
        // Confirm that a literal character matches the string value
        var checkLiteral = function() {
            if (value.charAt(iValue) != format.charAt(iFormat))
                throw 'Unexpected literal at position ' + iValue;
            iValue++;
        };
        var iValue = 0;
        for (var iFormat = 0; iFormat < format.length; iFormat++) {
            if (literal)
                if (format.charAt(iFormat) == "'" && !lookAhead("'"))
                    literal = false;
                else
                    checkLiteral();
            else
                switch (format.charAt(iFormat)) {
                    case 'h':
                        hour = getNumber('h');
                        break;
                    case 'H':
                        hour = getNumber('H');
                        break;
                    case 'i':
                        minute = getNumber('i');
                        break;
                    case 's':
                        second = getNumber('s');
                        break;
                    case 'd':
                        day = getNumber('d');
                        break;
                    case 'D':
                        getName('D', dayNamesShort, dayNames);
                        break;
                    case 'm':
                        month = getNumber('m');
                        break;
                    case 'M':
                        month = getName('M', monthNamesShort, monthNames);
                        break;
                    case 'y':
                        year = getNumber('y');
                        break;
                    case "'":
                        if (lookAhead("'"))
                            checkLiteral();
                        else
                            literal = true;
                        break;
                    default:
                        checkLiteral();
                }
        }
        if (year < 100) {
            year += new Date().getFullYear() - new Date().getFullYear() % 100 +
                (year <= shortYearCutoff ? 0 : -100);
        }
        else if(year>=100&&year<1000)
        {
            year = (new Date().getFullYear()-(year+1000))-((year+2000)-new Date().getFullYear())<0?(year+1000):(year+2000);
        }
        var date;
        if(second==-1&&hour==-1&&minute==-1)
        {
            date = new Date(year, month - 1, day);
        }
        else
        {
            hour   = (hour==-1)?0:hour;
            minute = (minute==-1)?0:minute;
            second = (second==-1)?0:second;
            date = new Date(year, month - 1, day, hour, minute, second);
        }
        if (date.getFullYear() != year || date.getMonth() + 1 != month || date.getDate() != day) {
            throw 'Invalid date'; // E.g. 31/02/*
        }
        return date;
    },
    parseTime : function (format, value)
    {
        var thisArray = value.split(":");

        var hour = thisArray[0] == undefined ? "00" : thisArray[0];
        var minute = thisArray[1] == undefined ? "00" : thisArray[1];
        var second = thisArray[2] == undefined ? "00" : thisArray[2];

        return new Date(1970, 1, 1, hour, minute, second);
    },
    /*
	 * Format a date object into a string value. The format can be combinations
	 * of the following: d - day of month (no leading zero) dd - day of month
	 * (two digit) D - day name short DD - day name long m - month of year (no
	 * leading zero) mm - month of year (two digit) M - month name short MM -
	 * month name long y - year (two digit) yy - year (four digit) '...' -
	 * literal text '' - single quote
	 *
	 * @param format String - the desired format of the date @param date Date -
	 * the date value to format @param settings Object - attributes include:
	 * dayNamesShort String[7] - abbreviated names of the days from Sunday
	 * (optional) dayNames String[7] - names of the days from Sunday (optional)
	 * monthNamesShort String[12] - abbreviated names of the months (optional)
	 * monthNames String[12] - names of the months (optional) @isLocal display
	 * as local, use local month string @return String - the date in the above
	 * format
	 */
    formatDate: function (format, date, settings, isLocal, isTransition) {
        if (!date)
            return '';
        var dayNamesShort = (settings ? settings.dayNamesShort : null) || this._defaults.dayNamesShort;
        var dayNames = (settings ? settings.dayNames : null) || this._defaults.dayNames;
        var monthNamesShort = (settings ? settings.monthNamesShort : null) || this._defaults.monthNamesShort;
        var monthNames = (settings ? settings.monthNames : null) || this._defaults.monthNames;
        // Check whether a format character is doubled
        var lookAhead = function(match) {
            var matches = (iFormat + 1 < format.length && format.charAt(iFormat + 1) == match);
            if (matches)
                iFormat++;
            return matches;
        };
        // Format a number, with leading zero if necessary
        var formatNumber = function(match, value) {
            return (lookAhead(match) && value < 10 ? '0' : '') + value;
        };
        // Format a name, short or long as requested
        var formatName = function(match, value, shortNames, longNames) {
            return (lookAhead(match) ? longNames[value] : shortNames[value]);
        };

        if(isLocal){
            format=format.replace(/m/g,"M");
        }

        var output = '';
        var literal = false;
        if (date) {
            for (var iFormat = 0; iFormat < format.length; iFormat++) {
                if (literal)
                    if (format.charAt(iFormat) == "'" && !lookAhead("'"))
                        literal = false;
                    else
                        output += format.charAt(iFormat);
                else
                    switch (format.charAt(iFormat)) {
                        case 'h':
                            output += formatNumber('h', date.getHours());
                            break;
                        case 'H':
                        	output += formatNumber('H', (isTransition) ? (date.getHours() -1) : date.getHours());
                            break;
                        case 'i':
                            output += formatNumber('i', date.getMinutes());
                            break;
                        case 's':
                            output += formatNumber('s', date.getSeconds());
                            break;
                        case 'd':
                            output += formatNumber('d', isLocal ? date.day : date.getDate());
                            break;
                        case 'D':
                            output += formatName('D', date.getDay(), dayNamesShort, dayNames);
                            break;
                        case 'm':
                            output += formatNumber('m', date.getMonth() + 1);
                            break;
                        case 'M':
                            output += formatName('M', (isLocal ? date.month - 1 : date.getMonth()), monthNamesShort, monthNames);
                            break;
                        case 'y':
                            var year = (isLocal ? date.year : date.getYear());
                            var fullYear = (isLocal ? date.year : date.getFullYear());
                            output += (lookAhead('y') ? fullYear : (year % 100 < 10 ? '0' : '') + year % 100);
                            break;
                        case "'":
                            if (lookAhead("'"))
                                output += "'";
                            else
                                literal = true;
                            break;
                        default:
                            output += format.charAt(iFormat);
                    }
            }
        }
        return output;
    },

    formatYearMonth: function(format, dateStr) {

    },

    /* Extract all possible characters from the date format. */
    _possibleChars: function (format) {
        var chars = '';
        var literal = false;
        for (var iFormat = 0; iFormat < format.length; iFormat++)
            if (literal)
                if (format.charAt(iFormat) == "'" && !lookAhead("'"))
                    literal = false;
                else
                    chars += format.charAt(iFormat);
            else
                switch (format.charAt(iFormat)) {
                    case 'd':
                    case 'm':
                    case 'y':
                    case 'H':
                    case 'i':
                    case 's':
                        // case 'd': case 'm': case 'y': case 'H': case 'i':
						// case 'H':
                        if (null == chars.match(/0123456789/i))
                        chars += '0123456789';
                        break;
                    case 'D':
                    case 'M':
                        return null; // Accept anything
                    case "'":
                        if (lookAhead("'"))
                            chars += "'";
                        else
                            literal = true;
                        break;
                    default:
                        chars += format.charAt(iFormat);
                }
        return chars;
    },


	_digitReShape:function(date,srcLocale,aimLocale){
		date = date+'';
		var aimdigits =aimLocale.digits;
		var srcdigits = srcLocale.digits;
		// include the digits item and source digits item is not the aim digits
		// item.
		if(aimdigits && srcdigits && aimdigits[0] && srcdigits[0] && aimdigits[0] != srcdigits[0])
		{
			var output = "";
			for (var iDate = 0; iDate < date.length; iDate++){
				var index = $.inArray(date.charAt(iDate),srcdigits);
					if(index !=-1)
						output += aimdigits[index];
					else
						output += date.charAt(iDate);
				}
			return output;
		}
		return date;
	},
	formatDigit:function(date){
		return $.datetimepicker._digitReShape(date,$.datetimepicker.getRegional("en"),this._defaults);
	}
});

/*
 * Individualised settings for date picker functionality applied to one or more
 * related inputs. Instances are managed and manipulated through the Datepicker
 * manager.
 *  @ settings={ dateFormat:as yyyy-mm-dd hh:mm:ss - highest }
 */
function DateTimepickerInstance(settings, inline) {
    if(settings.dateFormat){
        settings.olddateFormat = settings.dateFormat;
        settings.dateFormat = matchDateFormat(settings.dateFormat);
    }
    if(settings.localFormat){
        settings.localFormat = matchDateFormat(settings.localFormat);
    }
    // alert(settings.dateFormat);
    this._id = $.datetimepicker._register(this);
    this._selectedDay = 0; // Current date for selection
    this._selectedMonth = 0; // 0-11
    this._selectedYear = 0; // 4-digit year
    this._selectedHour = 0;
    this._selectedMinute = 0;
    this._selectedSecond = 0;
    this._drawMonth = 0; // Current month at start of datetimepicker
    this._drawYear = 0;
    this._drawHour = 0;
    this._drawMinute = 0;
    this._drawSecond = 0;
    this._input = null; // The attached input field
    this._inline = inline; // True if showing inline, false if used in a popup
    this._datetimepickerDiv = (!inline ? $.datetimepicker._datetimepickerDiv :
        $('<div id="datetimepicker_div_' + this._id + '" class="datetimepicker_inline">'));
    // alert(this._datetimepickerDiv.parent());
    if(!this._datetimepickerDiv.parent().is("body"))
    {
        $(document.body).append($.datetimepicker._datetimepickerDiv);
        $(document).mousedown($.datetimepicker._checkExternalClick);
    }
    this.poper = new jBME.Poper($(this._datetimepickerDiv));
    this.poper.mask = true;
    var poper = this.poper;

    this.poper.wrapperFunc = function()
    {
        var jqWrapper = poper.createShadowWrapper(poper.jqPopFrom);
        jqWrapper.addClass("bf_shadow_datetime");
        return jqWrapper;
    };
    // customise the date picker object - uses manager defaults if not
	// overridden
    this._settings = extendRemove(settings || {}); // clone
    if (inline)
        this._setDate(this._getDefaultDate());
    return;
}

$.extend(DateTimepickerInstance.prototype, {
    /* Get a setting value, defaulting if necessary. */
    _get: function(name) {
        return this._settings[name] !== undefined ? this._settings[name] : $.datetimepicker._defaults[name];
    },

    _set: function(name, value) {
        return this._settings[name] = value;
    },

    _setDateformat: function(value) {
        if(value){
            value = matchDateFormat(value);
        }
        this._settings['dateFormat'] = value;
    },

    /* Parse existing date and initialise date picker. */
    _setDateFromField: function(input) {
        var date = this._getDateFromField(input);
        var dates = input ? $(input).val().split(this._get('rangeSeparator')) : null;
        this._selectedDay = date.getDate();
        this._drawMonth = this._selectedMonth = date.getMonth();
        this._drawYear = this._selectedYear = date.getFullYear();
        this._drawHour = this._selectedHour = date.getHours();
        this._drawMinute = this._selectedMinute = date.getMinutes();
        this._drawSecond = this._selectedSecond = date.getSeconds();
        this._currentDay = (dates[0] ? date.getDate() : 0);
        this._currentMonth = (dates[0] ? date.getMonth() : 0);
        this._currentYear = (dates[0] ? date.getFullYear() : 0);
        this._adjustDate();
    },

    /* Parse existing date */
    _getDateFromField: function(input) {
        this._input = $(input);
        var dateFormat;
            dateFormat = this._get('dateFormat');
        var dates = this._input ? this._input.val().split(this._get('rangeSeparator')) : null;
        this._endDay = this._endMonth = this._endYear = null;
        var date = defaultDate = this._getDefaultDate();
        if (dates.length > 0) {
            var settings = this._getFormatConfig();
            if (dates.length > 1) {
                date = $.datetimepicker.parseDate(dateFormat, dates[1], settings) || defaultDate;
                this._endDay = date.getDate();
                this._endMonth = date.getMonth();
                this._endYear = date.getFullYear();
            }
            try {
                date = $.datetimepicker.parseDate(dateFormat, dates[0], settings) || defaultDate;
            } catch (e) {
                $.datetimepicker.log(e);
                date = defaultDate;
            }
        }
        return date;
    },

    /* Retrieve the default date shown on opening. */
    _getDefaultDate: function() {
    	var date = new Date();

    	// when support timezone convert,default date is from current special
		// timezone in server
    	if(this._get("dst")){
        	var scope = $(document.body).scope();
        	if(scope){
        		var str = scope.$Get('$filter')('tz')(date.getTime(),"yyyy-MM-dd HH:mm:ss");
        	}
        	date = $.datetimepicker.parseDate(matchDateFormat("yyyy-MM-dd HH:mm:ss"), str)
    	}

        date = this._determineDate('defaultDate', date);
        var minDate = this._getMinMaxDate('min', true);
        var maxDate = this._getMinMaxDate('max');
        date = (minDate && date < minDate ? minDate : date);
        date = (maxDate && date > maxDate ? maxDate : date);
        return date;
    },

    /* A date may be specified as an exact value or a relative one. */
    _determineDate: function(name, defaultDate) {
        var offsetNumeric = function(offset) {
            var date = new Date();
            date.setDate(date.getDate() + offset);
            return date;
        };
        var offsetString = function(offset, getDaysInMonth) {
            var date = new Date();
            var matches = /^([+-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?$/.exec(offset);
            if (matches) {
                var year = date.getFullYear();
                var month = date.getMonth();
                var day = date.getDate();
                switch (matches[2] || 'd') {
                    case 'd' : case 'D' :
                        day += (matches[1] - 0); break;
                    case 'w' : case 'W' :
                        day += (matches[1] * 7); break;
                    case 'm' : case 'M' :
                        month += (matches[1] - 0);
                        day = Math.min(day, getDaysInMonth(year, month));
                        break;
                    case 'y': case 'Y' :
                        year += (matches[1] - 0);
                        day = Math.min(day, getDaysInMonth(year, month));
                        break;
                }
                date = new Date(year, month, day);
            }
            return date;
        };
        var date = this._get(name);
        return (date == null ? defaultDate :
            (typeof date == 'string' ? offsetString(date, this._getDaysInMonth) :
            (typeof date == 'number' ? offsetNumeric(date) : date)));
    },

    /* Set the date(s) directly. */
    _setDate: function(date, endDate) {
        this._selectedDay = this._currentDay = date.getDate();
        this._drawMonth = this._selectedMonth = this._currentMonth = date.getMonth();
        this._drawYear = this._selectedYear = this._currentYear = date.getFullYear();
        this._drawHour = this._selectedHour = this._currentHour = date.getHours();
        this._drawMinute = this._selectedMinute = this._currentMinute = date.getMinutes();
        this._drawSecond = this._selectedSecond = this._currentSecond = date.getSeconds();
        if (this._get('rangeSelect')) {
            if (endDate) {
                this._endDay = endDate.getDate();
                this._endMonth = endDate.getMonth();
                this._endYear = endDate.getFullYear();
            } else {
                this._endDay = this._currentDay;
                this._endMonth = this._currentMonth;
                this._endYear = this._currentYear;
            }
        }
        this._adjustDate();
    },

    /* Retrieve the date(s) directly. */
    _getDate: function() {
        var startDate = (!this._currentYear || (this._input && this._input.val() == '') ? null :
            new Date(this._currentYear, this._currentMonth, this._currentDay));
        if (this._get('rangeSelect')) {
            return [startDate, (!this._endYear ? null :
                new Date(this._endYear, this._endMonth, this._endDay))];
        } else
            return startDate;
    },

    isSelectable :function(filter,printDate)
    {
        var datefilter = undefined;
        var $this = this;
        function beforeToday(printDate)
        {
            if($this.today == undefined)
            {
                $this.today = new Date();
                $this.today.setHours(0);
                $this.today.setMinutes(0);
                $this.today.setSeconds(0);
                $this.today.setMilliseconds(0);
            }
            return printDate >= $this.today;
        }
        try{ datefilter = eval(filter); } catch(e){ return true; }
        if(!(datefilter instanceof Function))
        {
            return true;
        }
        return datefilter(printDate);
    },
    /* Generate the HTML for the current state of the date picker. */
    _generateDatepicker: function() {
        var today = new Date();
        today = new Date(today.getFullYear(), today.getMonth(), today.getDate()); // clear
																					// time
        var showStatus = this._get('showStatus');
        var isRTL = this._get('isRTL');
        // build the date picker HTML
        var clear = (this._get('mandatory') ? '' :
            '<div class="datetimepicker_clear"><a onclick="jQuery.datetimepicker._clearDate(' + this._id + ');"' +
            (showStatus ? this._addStatus(this._get('clearStatus') || '&#xa0;') : '') + '>' +
            this._get('clearText') + '</a></div>');
        var controls = '<div class="datetimepicker_control">' + (isRTL ? '' : clear) +
            '<div class="datetimepicker_close"><a onclick="jQuery.datetimepicker._hideDatepicker();"' +
            (showStatus ? this._addStatus(this._get('closeStatus') || '&#xa0;') : '') + '>' +
            this._get('closeText') + '</a></div>' + (isRTL ? clear : '')  + '</div>';
        var prompt = this._get('prompt');
        var closeAtTop = this._get('closeAtTop');
        var closeHide = this._get('closeHide');
        var hideIfNoPrevNext = this._get('hideIfNoPrevNext');
        var numMonths = this._getNumberOfMonths();
        var stepMonths = this._get('stepMonths');
        var isMultiMonth = (numMonths[0] != 1 || numMonths[1] != 1);
        var minDate = this._getMinMaxDate('min', true);
        var maxDate = this._getMinMaxDate('max');
        var drawDay = this._selectedDay;
        var drawMonth = this._drawMonth;  // 逻辑月份 (0-11)
        var drawYear = this._drawYear;
        var drawHour = this._drawHour;
        var drawMinute = this._drawMinute;
        var drawSecond = this._drawSecond;
        var showYear = drawYear;
        var showMonth = drawMonth;
        var showDay = drawDay;
        if (maxDate) {
            var maxDraw = new Date(maxDate.getFullYear(),
                maxDate.getMonth() - numMonths[1] + 1, maxDate.getDate());
            maxDraw = (minDate && maxDraw < minDate ? minDate : maxDraw);
            while (new Date(drawYear, drawMonth, 1) > maxDraw) {
                drawMonth--;
                if (drawMonth < 0) {
                    drawMonth = 11;
                    drawYear--;
                }
            }
        }
        var prev = '<div class="datetimepicker_prev">' +
            // prev year
            (this._canAdjustMonth(-12, drawYear, drawMonth) ?
            '<span class="datetimepicker_prev_year"><a onclick="jQuery.datetimepicker._adjustDate(' + this._id + ', -' + 12 + ', \'M\');"' +
            (showStatus ? this._addStatus(this._get('prevStatus') || '&#xa0;') : '') +
            'title="' + this._get('prevYearText') + '"' +
            '>' +
            '</a></span>' :
            (hideIfNoPrevNext ? '' : '<span class="datetimepicker_prev_year"><a class="prev_disabled"></a></span>')) +
            // prev month
            (this._canAdjustMonth(-1, drawYear, drawMonth) ?
            '<a onclick="jQuery.datetimepicker._adjustDate(' + this._id + ', -' + stepMonths + ', \'M\');"' +
            (showStatus ? this._addStatus(this._get('prevStatus') || '&#xa0;') : '') +
            'title="' + this._get('prevText') + '"' +
            '>' +
            '</a>' :
            (hideIfNoPrevNext ? '' : '<a class="prev_disabled"></a>')) + '</div>';
        var next = '<div class="datetimepicker_next">' +
            // next month
            (this._canAdjustMonth(+1, drawYear, drawMonth) ?
            '<a onclick="jQuery.datetimepicker._adjustDate(' + this._id + ', +' + stepMonths + ', \'M\');"' +
            (showStatus ? this._addStatus(this._get('nextStatus') || '&#xa0;') : '') +
            'title="' + this._get('nextText') + '"' +
            '>' +
            '</a>' :
            (hideIfNoPrevNext ? '' : '<a class="next_disabled"></a>')) +
            // next year
            (this._canAdjustMonth(+12, drawYear, drawMonth) ?
            '<span class="datetimepicker_next_year"><a onclick="jQuery.datetimepicker._adjustDate(' + this._id + ', +' + 12 + ', \'M\');"' +
            (showStatus ? this._addStatus(this._get('nextStatus') || '&#xa0;') : '') +
            'title="' + this._get('nextYearText') + '"' +
            '>' +
            '</a></span>' :
            (hideIfNoPrevNext ? '' : '<span class="datetimepicker_next_year"><a class="next_disabled"></a></span>')) +
            '</div>';
        // HTML String Builder!
        var sb = [(prompt ? '<div class="datetimepicker_prompt">' + prompt + '</div>' : '')
                   , (closeAtTop && !this._inline && !closeHide ? controls : '')
                   , '<div class="datetimepicker_links">'
                   , (isRTL ? next : prev)
                   , '<div class="datetimepicker_current">'
                   ,  this._generateMonthYearHeader(drawSecond,drawMinute,drawHour,drawMonth, drawYear, minDate, maxDate, selectedDate, row > 0 || col > 0)// draw
																																							// month
																																							// headers
                   ,  '</div>'
                   , (isRTL ? prev : next)
                   , '</div>'];
        var showWeeks = this._get('showWeeks');
        var pickByWeek = this._get('pickByWeek');
        var date9999_9_9 = new Date(9999, 9, 9);  // the end of world?
        for (var row = 0; row < numMonths[0]; row++)
            for (var col = 0; col < numMonths[1]; col++) {
                var selectedDate = new Date(drawYear, drawMonth, this._selectedDay, drawHour, (drawMinute ? drawMinute : 0), (drawSecond ? drawSecond : 0));
                var selectedDateLocalCache={};
                sb.push('<div class="datetimepicker_oneMonth');
                if(pickByWeek){sb.push(' pickbyweek ');}
                if(col == 0)
                {
                    sb.push(' datetimepicker_newRow');
                }
                sb.push('">');
                sb.push('<table class="datetimepicker" cellpadding="0" cellspacing="0"><thead>');
                sb.push('<tr class="datetimepicker_titleRow">');
                sb.push(showWeeks ? '<td>' + this._get('weekHeader') + '</td>' : '');
                var firstDay = this._get('firstDay');
                var changeFirstDay = this._get('changeFirstDay');
                var dayNames = this._get('dayNames');
                var dayNamesShort = this._get('dayNamesShort');
                var dayNamesMin = this._get('dayNamesMin');
                for (var dow = 0; dow < 7; dow++) { // days of the week
                    var day = (dow + firstDay) % 7;
                    var status = this._get('dayStatus') || '&#xa0;';
                    status = (status.indexOf('DD') > -1 ? status.replace(/DD/, dayNames[day]) :
                        status.replace(/D/, dayNamesShort[day]));
                    sb.push('<td' + ((dow + firstDay + 6)%7 >= 5 ? ' class="datetimepicker_weekEndCell"' : '') + '>');
                    sb.push(!changeFirstDay ? '<span' : '<a onclick="jQuery.datetimepicker._changeFirstDay('+this._id+', '+day+');"');
                    sb.push(showStatus ? this._addStatus(status) : '');
                    sb.push(' title="'+dayNames[day]+'">');
                    sb.push(dayNamesMin[day]);
                    sb.push(changeFirstDay ? '</a>' : '</span>');
                    sb.push('</td>');
                }
                sb.push('</tr></thead><tbody>');
                var daysInMonth = this._getDaysInMonth(drawYear, drawMonth);
                if (drawYear == this._selectedYear && drawMonth == this._selectedMonth) {
                    drawDay = this._selectedDay = Math.min(this._selectedDay, daysInMonth);
                }
                var leadDays = (this._getFirstDayOfMonth(drawYear, drawMonth) - firstDay + 7) % 7;
                var currentDate = (this._currentDay ? new Date(this._currentYear, this._currentMonth, this._currentDay) : date9999_9_9);
                var endDate = (this._endDay ? new Date(this._endYear, this._endMonth, this._endDay) : currentDate);
                var printDate = new Date(drawYear, drawMonth, 1 - leadDays);
                var numRows = (isMultiMonth ? 6 : Math.ceil((leadDays + daysInMonth) / 7)); // calculate
																							// the
																							// number
																							// of
																							// rows
																							// to
																							// generate
                // GCU LocalCalendard
                var isLocal = false;
                var local_printDate;
                var localDateCache;// 被选择填对应的本地历的日期
                if(drawYear>1893 && drawYear<2044 && this._get("calendric"))
                {
                    isLocal = true;
                    var calendric = parseInt(this._get("calendric"));
                    var localDate = gregorianToLocal(calendric, this._selectedYear || drawYear, (this._selectedYear?this._selectedMonth:drawMonth)+1, drawDay); // 10-31
                    selectedDateLocalCache={
                            year:localDate.year,
                            month:localDate.month,
                            day:localDate.day
                    };
                    var gDateOfFirst = localToGregorian(calendric, localDate.year, localDate.month, 1);
                    var gYearOfFirst = gDateOfFirst.year;
                    var gMonthOfFirst = gDateOfFirst.month;
                    var gDayOfFirst = gDateOfFirst.day;

                    var local_daysInMonth = getMonthDays(calendric, localDate.year, localDate.month);
                    var local_leadDays = (new Date(gYearOfFirst, gMonthOfFirst-1, gDayOfFirst).getDay() - firstDay + 7) % 7;
                    local_printDate = new Date(gYearOfFirst, gMonthOfFirst-1, gDayOfFirst - leadDays);

                }
                var beforeShowDay = this._get('beforeShowDay');
                var showOtherMonths = this._get('showOtherMonths');
                var calculateWeek = this._get('calculateWeek') || $.datetimepicker.iso8601Week;
                var dateStatus = this._get('statusForDate') || $.datetimepicker.dateStatus;
                var highlightOtherMonth = false;
                var firstDayOfWeek = {};
                for (var dRow = 0; dRow < numRows; ++dRow) { // create date
																// picker rows
                    sb.push('<tr class="datetimepicker_daysRow">');
                    if(showWeeks)
                    {
                        sb.push('<td class="datetimepicker_weekCol">');
                        var firstcmd = new Date(printDate.getFullYear(),printDate.getMonth(),printDate.getDate())
                        sb.push(calculateWeek(firstcmd));
                        sb.push('</td>');
                    }
                    for (var dow = 0; dow < 7; dow++) { // create date picker
														// days
                        if(dow == 0)
                        {
                            firstDayOfWeek.year = printDate.getFullYear();
                            firstDayOfWeek.month = printDate.getMonth();
                        }
                        var daySettings = (beforeShowDay ?
                            beforeShowDay.apply((this._input ? this._input[0] : null), [printDate]) : [true, '']);
                        var otherMonth = (printDate.getMonth() != drawMonth);
                        var unselectable = !daySettings[0] ||
                            (minDate && printDate < minDate) || (maxDate && printDate > maxDate);
                        var localDay,printDay,localMonth,printMonth,localYear,printYear;  // 要显示的年月日和真实年月日

                        localDay=printDay = printDate.getDate();
                        localMonth=printMonth = drawMonth;
                        localYear=printYear = drawYear;
                        if(isLocal)
                        {
                            var printLocalDate = gregorianToLocal(calendric, printDate.getFullYear(),(printDate.getMonth()+1),printDate.getDate());
                            localDay = printLocalDate.day;
                            localMonth = printLocalDate.month;
                            localYear = printLocalDate.year;
                        }

                        var localdatestr="";
                        if(this._get("displayLocal") && isLocal){

                            localdatestr = $.datetimepicker.formatDigit($.datetimepicker.formatDate((this._get('localFormat') || this._get('dateFormat')).split(" ")[0], printLocalDate, this._getFormatConfig(), true));
                            localdatestr = ' '+this._get('pickertitle')+': '+ localdatestr;
                        }
                        var titleStr = (showWeeks && pickByWeek)?"":$.datetimepicker.formatDate(this._get('dateFormat').split(" ")[0], new Date(printDate.getFullYear(), printDate.getMonth(), printDay), this._getFormatConfig())
                                      + localdatestr;
                        // attr: class.
                        sb.push('<td class="datetimepicker_daysCell');
                        if(dow == 0)
                        {
                            sb.push(' firstDayOfWeek')
                        }
                        if((dow + firstDay + 6) % 7 >= 5)
                        {// highlight weekends
                            sb.push(' datetimepicker_weekEndCell');
                        }
                        if(otherMonth)
                        {// highlight days from other months
                            sb.push(' datetimepicker_otherMonth');
                        }
                        if(printDate.getYear() == selectedDate.getYear() &&  printDate.getMonth() == selectedDate.getMonth() &&  printDate.getDate() == selectedDate.getDate()&& drawMonth == this._selectedMonth)
                        {// highlight selected day
                            sb.push(' datetimepicker_currentDay');
                            highlightOtherMonth = true;
                        }
                        if(unselectable)
                        {// highlight unselectable days
                            sb.push(' datetimepicker_unselectable');
                        }
                        if(!otherMonth)
                        {// highlight today (if different)
                            sb.push(' ');
                            sb.push(daySettings[1]);
                            if(!highlightOtherMonth && date9999_9_9.getTime()==currentDate.getTime() && printDate.getTime() == today.getTime())
                            {
                                sb.push(' datetimepicker_today');
                            }
                        }
                        if(this._settings.filter && !this.isSelectable(this._settings.filter ,printDate))
                        {
                            sb.push(' datetimepicker_unselectable');
                        }
                        sb.push('"');

                        // attr: onxxx
                        if(!unselectable)
                        {
                            // onmouseover
                            sb.push(' onmouseover="jQuery(this).addClass(\'datetimepicker_daysCellOver\');');
                            if(showStatus && (!otherMonth || showOtherMonths))
                            {
                                sb.push('jQuery(\'#datetimepicker_status_');
                                sb.push(this._id);
                                sb.push('\').html(\'');
                                sb.push( dateStatus.apply( (this._input?this._input[0]:null), [printDate, this] ) || '&#xa0;' );
                                sb.push('\');');
                            }
                            sb.push('"');

                            // onmouseout
                            sb.push(' onmouseout="jQuery(this).removeClass(\'datetimepicker_daysCellOver\');');
                            if(showStatus && (!otherMonth || showOtherMonths))
                            {
                                sb.push('jQuery(\'#datetimepicker_status_');
                                sb.push(this._id);
                                sb.push('\').html(\'&#xa0;\');');
                            }
                            sb.push('"');

                            // onclick
                            sb.push(' onmouseup="jQuery.datetimepicker._selectDay(');
                            sb.push(this._id);
                            sb.push(',');
                            sb.push((showWeeks && pickByWeek)?firstDayOfWeek.month:printDate.getMonth());
                            sb.push(',');
                            sb.push((showWeeks && pickByWeek)?firstDayOfWeek.year:printDate.getFullYear());
                            // sb.push(', ');
                            // sb.push(drawHour);
                            // sb.push(', ');
                            // sb.push(drawMinute);
                            // sb.push(', ');
                            // sb.push(drawSecond);
                            sb.push(', this);"');
                        }

                        // attr: title
                        sb.push(' title="');
                        sb.push(titleStr);
                        sb.push('">');

                        // <a>
                        sb.push('<a value="');
                        sb.push(printDate.getDate());
                        sb.push('">');
                        sb.push(printDay);
                        if(isLocal && this._get("displayLocal"))
                        {
                            sb.push('<div class="secondary">');

                            sb.push(($.datetimepicker.formatDigit(localDay==1?
											this._get("monthNames")[localMonth-1]
											:localDay)));
                            sb.push('</div>');
                        }
                        sb.push('</a>')

                        // </td>
                        sb.push('</td>');

                        printDate.setDate(printDate.getDate() + 1);
                    }// end for-dow.
                    sb.push('</tr>');
                }// end for-dRow
                drawMonth++;
                if (drawMonth > 11) {
                    drawMonth = 0;
                    drawYear++;
                }
                sb.push('</tbody></table>');

                sb.push('<div class="nofloat"></div>');
                sb.push('<div class="datetimepicker_time">');
                sb.push('<div class="datetimepicker_selecteddate">');
                sb.push($.datetimepicker.formatDate(this._get('dateFormat').split(" ")[0], new Date(this._currentYear==0?showYear:this._currentYear,this._currentYear==0?showMonth:this._currentMonth, this._currentDay==0?showDay:this._currentDay), this._getFormatConfig()));
                if(this._get("displayLocal") && isLocal){
                    var calendric = parseInt(this._get("calendric"));
                    var localDate = gregorianToLocal(calendric, this._selectedYear || drawYear, (this._selectedYear?this._selectedMonth:drawMonth)+1, drawDay); // 10-31
                    localDate={
                        year:localDate.year,
                        month:localDate.month,
                        day:localDate.day
                    };
                    sb.push('<div>');

                    sb.push($.datetimepicker.formatDigit($.datetimepicker.formatDate((this._get('localFormat') || this._get('dateFormat')).split(" ")[0], new Date(selectedDateLocalCache.year, selectedDateLocalCache.month, selectedDateLocalCache.day), this._getFormatConfig())));
                    sb.push('</div>');
                }
                sb.push('</div>');
                if (this._get('displaytime'))
                {
                    var drawHourStr = drawHour<10?'0'+drawHour:drawHour;
                    var drawMinuteStr = drawMinute<10?'0'+drawMinute:drawMinute;
                    var drawSecondStr = drawSecond<10?'0'+drawSecond:drawSecond;
                    sb.push('<div id="'+this._get("id")+'_time'+'"class="datetimepicker_timepicker"><input id="'+this._get("id")+'_time_value" type="hidden" value="'+drawHourStr+':'+drawMinuteStr+':'+drawSecondStr+'" /></div>');
                }
                sb.push('</div>');
                if (this._get('displaytime'))
                {
                    sb.push('<div class="nofloat"></div>');
                    sb.push('<div class="datetimepicker_button">');
                    sb.push('<span class="uee-button bc" onclick="jQuery.datetimepicker._selectDateByButton('+this._id+', '+ this._selectedDay+', '+this._selectedMonth+', '+this._selectedYear+');"><div><div>'+this._get('okLabel')+'</div></div></span>');
                    sb.push('<span class="uee-button bc" onclick="$.datetimepicker._hideDatepicker();"><div><div>'+this._get('cancelLabel')+'</div></div></span>');

                    if(this._get('clean'))
                    {
                        sb.push('<span class="uee-button bc" onclick="jQuery.datetimepicker._clearDate('+this._id+');"><div><div>'+this._get('clearLabel')+'</div></div></span>');
                    }
                    sb.push('</div>');
                }
                else if(this._get('clean')){
                    sb.push('<div class="nofloat"></div>');
                    sb.push('<div class="datetimepicker_button">');
                    sb.push('<span class="uee-button bc" onclick="jQuery.datetimepicker._clearDate('+this._id+');"><div><div>'+this._get('clearLabel')+'</div></div></span>');
                    sb.push('</div>');
                }
                sb.push('<div class="nofloat"></div>');
                sb.push('<div class="footerspace">&nbsp;</div></div>');
            }//
        sb.push(showStatus ? '<div style="clear: both;"></div><div id="datetimepicker_status_'+this._id+'" class="datetimepicker_status">' + (this._get('initStatus') || '&#xa0;') + '</div>' : '')
        sb.push(!closeAtTop && !this._inline && !closeHide ? controls : '');
        sb.push('<div style="clear: both;"></div>');
        sb.push($.browser.msie && parseInt($.browser.version) < 7 && !this._inline ? '<iframe src="javascript:false;" class="datetimepicker_cover"></iframe>' : '');
        return sb.join("");
    },

    /* Generate the month and year header. */
    _generateMonthYearHeader: function(drawSecond,drawMinute,drawHour,drawMonth, drawYear, minDate, maxDate, selectedDate, secondary) {
        minDate = (this._rangeStart && minDate && selectedDate < minDate ? selectedDate : minDate);
        var showStatus = this._get('showStatus');

        // HTML String Builder!
        var sb = ['<div class="datetimepicker_header">'];
        // month selection
        var monthNames = this._get('monthNames');

        var printYear = drawYear;
        var printMonth = drawMonth;
        var localYear=printYear;
        var localMonth=printMonth;
        if(drawYear>1893 && drawYear<2044 && this._get("calendric")) {
            var calendric = parseInt(this._get("calendric"));
            var localDate = gregorianToLocal(calendric, drawYear, drawMonth, this._selectedDay); // 公历转换本地历法
            localMonth = localDate.month-1;
            localYear = localDate.year;
        }
        if (secondary || !this._get('changeMonth'))
            sb.push(monthNames[printMonth] + '&#xa0;');

        else {
            var inMinYear = (minDate && minDate.getFullYear() == drawYear);
            var inMaxYear = (maxDate && maxDate.getFullYear() == drawYear);
            sb.push('<select class="datetimepicker_newMonth" ');
            sb.push('onchange="jQuery.datetimepicker._selectMonthYear(');
            sb.push(this._id);
            sb.push(', this, \'M\');" ');
            sb.push('onclick="jQuery.datetimepicker._clickMonthYear(');
            sb.push(this._id);
            sb.push(');"');
            if(showStatus)
            {
                sb.push(this._addStatus(this._get('monthStatus') || '&#xa0;'));
            }
            sb.push('>');

            // if use fa calendar, then display month with local language
            if(this._get("thisType") && this._get("thisType") == 'fa')
            {
	            var localMonthList = getLocaleMonthList(this._get("calendric"), drawYear, drawMonth, this._selectedDay);
	            for (var month = 0; month < localMonthList.length; month++) {
	                    sb.push('<option  value="');
	                    sb.push(localMonthList[month]);
	                    sb.push('"');
	                    if((localMonthList[month]-1) == localMonth)
	                    {
	                        sb.push(' selected="selected"');
	                    }
	                    sb.push('>');
	                    sb.push(this._get("monthNames")[localMonthList[month]-1]);
	                    sb.push('</option>');
	            }
            }
            else
            {
				for (var month = 0; month < 12; month++) {
	                if ((!inMinYear || month >= minDate.getMonth()) && (!inMaxYear || month <= maxDate.getMonth())) {
	                    sb.push('<option  value="');
	                    sb.push(month);
	                    sb.push('"');
	                    if(month == printMonth)
	                    {
	                        sb.push(' selected="selected"');
	                    }
	                    sb.push('>');
	                    sb.push(month+1);
	                    sb.push('</option>');
	                }
	            }
            }

            sb.push('</select>&nbsp;')
        }
        // year selection
        if (secondary || !this._get('changeYear'))
            sb.push( printYear );
        else {
            // determine range of years to display
            var years = this._get('yearRange').split(':');
            var year = 0;
            var endYear = 0;
            if (years.length != 2) {
                year = printYear - 10;
                endYear = printYear + 10;
            } else if (years[0].charAt(0) == '+' || years[0].charAt(0) == '-') {
                year = printYear + parseInt(years[0], 10);
                endYear = printYear + parseInt(years[1], 10);
            } else {
                year = parseInt(years[0], 10);
                endYear = parseInt(years[1], 10);
            }
            year = (minDate ? Math.max(year, minDate.getFullYear()) : year);
            endYear = (maxDate ? Math.min(endYear, maxDate.getFullYear()) : endYear);
            sb.push('<select class="datetimepicker_newYear" ');
            sb.push('onchange="jQuery.datetimepicker._selectMonthYear(');
            sb.push(this._id);
            sb.push(', this, \'Y\');" ');
            sb.push('onclick="jQuery.datetimepicker._clickMonthYear(');
            sb.push(this._id);
            sb.push(');"');
            if(showStatus)
            {
                sb.push(this._addStatus(this._get('yearStatus') || '&#xa0;'));
            }
            sb.push('>');

            for (; year <= endYear; year++) {
                sb.push('<option value="');
                sb.push(year);
                sb.push('"');
                if(year == printYear)
                {
                    sb.push(' selected="selected"');
                }
                sb.push('>');

                sb.push($.datetimepicker.formatDigit(year));
                sb.push('</option>');
            }
            sb.push('</select>');
        }

        sb.push('</div>'); // Close datetimepicker_header
        return sb.join("");
    },

    /* Provide code to set and clear the status panel. */
    _addStatus: function(text) {
        return ' onmouseover="jQuery(\'#datetimepicker_status_' + this._id + '\').html(\'' + text + '\');" ' +
            'onmouseout="jQuery(\'#datetimepicker_status_' + this._id + '\').html(\'&#xa0;\');"';
    },

    /* Adjust one of the date sub-fields. 调整日期 */
    _adjustDate: function(offset, period) {
        var year = this._drawYear + (period == 'Y' ? offset : 0);
        var month = this._drawMonth + (period == 'M' ? offset : 0);
        var day = Math.min(this._selectedDay, this._getDaysInMonth(year, month)) +
            (period == 'D' ? offset : 0);
        var hour = this._drawHour + (period == 'H' ? offset : 0);
        var minute = this._drawMinute + (period == 'I' ? offset : 0);
        var second = this._drawSecond + (period == 'S' ? offset : 0);
        var date = new Date(year, month, day, hour, minute, second);
        // ensure it is within the bounds set
        var minDate = this._getMinMaxDate('min', true);
        var maxDate = this._getMinMaxDate('max');
        date = (minDate && date < minDate ? minDate : date);
        date = (maxDate && date > maxDate ? maxDate : date);
        this._currentDay = this._selectedDay = date.getDate();
        this._currentMonth = this._drawMonth = this._selectedMonth = date.getMonth();
        this._currentYear = this._drawYear = this._selectedYear = date.getFullYear();
        this._drawHour = this._selectedHour = date.getHours();
        this._drawMinute = this._selectedMinute = date.getMinutes();
        this._drawSecond = this._selectedSecond = date.getSeconds();
    },

    /* Determine the number of months to show. */
    _getNumberOfMonths: function() {
        var numMonths = this._get('numberOfMonths');
        return (numMonths == null ? [1, 1] : (typeof numMonths == 'number' ? [1, numMonths] : numMonths));
    },

    /*
	 * Determine the current maximum date - ensure no time components are set -
	 * may be overridden for a range.
	 */
    _getMinMaxDate: function(minMax, checkRange) {
        var date = this._determineDate(minMax + 'Date', null);
        if (date) {
            date.setHours(0);
            date.setMinutes(0);
            date.setSeconds(0);
            date.setMilliseconds(0);
        }
        return date || (checkRange ? this._rangeStart : null);
    },

    /* Find the number of days in a given month. */
    _getDaysInMonth: function(year, month) {
        return 32 - new Date(year, month, 32).getDate();
    },

    /* Find the day of the week of the first of a month. */
    _getFirstDayOfMonth: function(year, month) {
        return new Date(year, month, 1).getDay();
    },

    /* Determines if we should allow a "next/prev" month display change. */
    _canAdjustMonth: function(offset, curYear, curMonth) {
        var numMonths = this._getNumberOfMonths();
        // var date = new Date(curYear, curMonth + (offset < 0 ? offset :
		// numMonths[1]), 1);
        var date = new Date(curYear, curMonth + offset, 1);
        if (offset < 0)
            date.setDate(this._getDaysInMonth(date.getFullYear(), date.getMonth()));
        return this._isInRange(date);
    },

    /* Is the given date in the accepted range? */
    _isInRange: function(date) {
        // during range selection, use minimum of selected date and range start
        var newMinDate = (!this._rangeStart ? null :
            new Date(this._selectedYear, this._selectedMonth, this._selectedDay));
        newMinDate = (newMinDate && this._rangeStart < newMinDate ? this._rangeStart : newMinDate);
        var minDate = newMinDate || this._getMinMaxDate('min');
        var maxDate = this._getMinMaxDate('max');
        return ((!minDate || date >= minDate) && (!maxDate || date <= maxDate));
    },

    /* */
    _isDateInDST: function()
    {
        return "true" == this._get("dst") && "true" == $("#"+this._get("idPrefix")+"_bmeDSTChecked").val();
    },

    /* Provide the configuration settings for formatting/parsing. */
    _getFormatConfig: function() {
        var shortYearCutoff = this._get('shortYearCutoff');
        shortYearCutoff = (typeof shortYearCutoff != 'string' ? shortYearCutoff :
            new Date().getFullYear() % 100 + parseInt(shortYearCutoff, 10));
        return {shortYearCutoff: shortYearCutoff,
            dayNamesShort: this._get('dayNamesShort'), dayNames: this._get('dayNames'),
            monthNamesShort: this._get('monthNamesShort'), monthNames: this._get('monthNames')};
    },

    /* Format the given date for display. */
    _formatDateTime: function(day, month, year, hour, minute, second) {
        hour=hour||0; // wl: 暂时加，防止回填时的nan现象，以后测试
        minute=minute||0;
        second=second||0;
        if (!day) {
            this._currentDay = this._selectedDay;
            this._currentMonth = this._selectedMonth;
            this._currentYear = this._selectedYear;
            this._currentHour = this._selectedHour;
            this._currentMinute = this._selectedMinute;
            this._currentSecond = this._selectedSecond;
        }
        var date = (day ? (typeof day == 'object' ? day : new Date(year, month, day, hour, minute, second)) :
            new Date(this._currentYear, this._currentMonth, this._currentDay, this._currentHour, this._currentMinute, this._currentSecond));

        return $.datetimepicker.formatDate(this._get('dateFormat'), date, this._getFormatConfig(), null, hour != date.getHours());
    }
});

/* jQuery extend now ignores nulls! */
function extendRemove(target, props) {
    $.extend(target, props);
    for (var name in props)
        if (props[name] == null)
            target[name] = null;
    return target;
};

/*
 * Invoke the datetimepicker functionality. @param options String - a command,
 * optionally followed by additional parameters or Object - settings for
 * attaching new datetimepicker functionality @return jQuery object
 */
$.fn.datetimepicker = function(options){
    var otherArgs = Array.prototype.slice.call(arguments, 1);
    if (typeof options == 'string' && (options == 'isDisabled' || options == 'getDate')) {
        return $.datetimepicker['_' + options + 'Datepicker'].apply($.datetimepicker, [this[0]].concat(otherArgs));
    }
    this.each(function() {
        typeof options == 'string' ?
            $.datetimepicker['_' + options + 'Datepicker'].apply($.datetimepicker, [this].concat(otherArgs)) :
            $.datetimepicker._attachDatepicker(this, options);
    });
    $(this[0]).bind("reset", function()
    {

        var dstChecked = $("#" + options.id + "_bmeDSTChecked")[0];
        if(dstChecked != undefined)
        {
            var dstImg = $("#" + options.id + "_bmeDSTImg");
            if(dstChecked.defaultValue == "true")
            {
                dstImg.show();
            }else
            {
                dstImg.hide();
            }
        }
    });
    return this;
};

$.datetimepicker = new DateTimepicker(); // singleton instance
var rootscope = $(document.body).scope();
if(rootscope){
	var $Date = rootscope.$Get("$Date");
	if($Date && $Date.parseDateFromFormat){
		$.datetimepicker.parseDateFromFormat = $Date.parseDateFromFormat;
	}
}
})(jQuery);


/** Time picker * */
(function($) {
$.timePicker = function( s ) {
    var _defaults = {
        timeFormat: "hh:ii:ss",
        label: "hh:mm:ss",
        hourOptions: ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"],
        minuteOptions: ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"],
        secondOptions: ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59"]
    };

    var container;
    var isOver = null;
    var hourObj;
    var hourInp;
    var hourSel;

    var minuteObj;
    var minuteInp;
    var minuteSel;

    var secondObj;
    var secondInp;
    var secondSel;

    if(s.timeFormat)
    {
        s.timeFormat = s.timeFormat.replace("mm", "ii");
    }
    var conf = $.extend({}, _defaults, s);
    var targetInp = conf.target;

    var labelArr = conf.label.split(":");
    var defaultV = (targetInp.val() || conf.label);
    //DTS2017090807801,企业名片的预约失效时间的时间盘的时分秒默认设置成23:59：59.
    if('JIANGSU' == $Page.projectVersion && ('GroupInstall' == $Page.businessCode || 'GroupChangeProduct' == $Page.businessCode)
      && '1100006346' == $Page.offeringDetail.body.offeringInfo.offeringId)
    {
    	$.each($Page.offeringDetail.body.offeringInfo.attributeGroups || [], function(i, vali){
    		$.each(vali.attributes || [], function(j, valj){
    			if('reservationFails' == valj.attrCode){
    				defaultV = '23:59:59';
    			}
    		});
    	});
    	
    }
    var defaultVArr = defaultV.split(":");
    var timeFormatArr = conf.timeFormat.split(":");
    var labelObj = {};
    var defaultVObj = {};
    for(var i=0; i<timeFormatArr.length; i++)
    {
        labelObj[timeFormatArr[i]] = labelArr[i];
        defaultVObj[timeFormatArr[i]] = defaultVArr[i];
    }
    var newLabelArr = new Array();
    var newDefaultVArr = new Array();
    if(labelObj["hh"])
    {
        newLabelArr.push(labelObj["hh"]);
        newDefaultVArr.push(defaultVObj["hh"]);
    }
    else if(labelObj["HH"])
    {
        newLabelArr.push(labelObj["HH"]);
        newDefaultVArr.push(defaultVObj["HH"]);
    }
    else
    {
        newLabelArr.push("hh");
        newDefaultVArr.push("hh");
    }
    if(labelObj["ii"])
    {
        newLabelArr.push(labelObj["ii"]);
        newDefaultVArr.push(defaultVObj["ii"]);
    }
    else
    {
        newLabelArr.push("ii");
        newDefaultVArr.push("ii");
    }
    if(labelObj["ss"])
    {
        newLabelArr.push(labelObj["ss"]);
        newDefaultVArr.push(defaultVObj["ss"]);
    }
    else
    {
        newLabelArr.push("ss");
        newDefaultVArr.push("ss");
    }
    conf.label = newLabelArr.join(":");
    labelArr = newLabelArr;
    defaultVArr = newDefaultVArr;

    var targetId = targetInp.attr("id");
    var id = conf.containerid;
    var hourOptions = conf.hourOptions;
    var minuteOptions = conf.minuteOptions;
    var secondOptions = conf.secondOptions;

    var isDisabled = false;
    var disabledClass = "";
    if(targetInp.is(":disabled"))
    {
        isDisabled = true;
    }

    if(s.datetime)
    {
        initDom();
    }

    initEvent();

    return {
        setDefaults: _setDefaults
    };

    function _setDefaults( opts ) {
        conf = $.extend({}, _defaults, opts);
    }

    function initDom() {
        // targetInp.attr("type", "hidden");
        // HTML String Builder.
        var sb = ['<ul class="timepicker" id="' , targetId , '_ul"', (isDisabled ? ' disabled="disabled" ': ''),  ' >'
                 ,'   <li id="',targetId,'hour_li"',' class="timepicker_hour">'
                 ,'       <div id="',targetId,'hourSel" class="timepicker_selectlist">'];
        for(var i=0; i<hourOptions.length; i++)
        {
            sb.push('           <a>');
            sb.push(hourOptions[i]);
            sb.push('</a>');
        }
        var defaultHour = defaultVArr[0];

        sb.push('       </div>');
        sb.push('       <input id="'+targetId+'HourInp" type="text" maxlength="2" ', (isDisabled?' disabled="disabled"  ':''), ' />');
        sb.push('       <ins id="'+targetId+'hour_ins" onclick="$.timePicker.onclickhour(\''+id+'\', this)"');
        sb.push('        ></ins>');
        sb.push('   </li>');
        sb.push('   <li id="'+targetId+'hmsplit" class="timepicker_split">:</li>');
        sb.push('   <li id="',targetId,'minute_li" class="timepicker_minute">');
        sb.push('       <div id="'+targetId+'minuteSel" class="timepicker_selectlist">');
        for(var i=0; i<minuteOptions.length; i++)
        {
            sb.push('           <a>'+minuteOptions[i]+'</a>');
        }
        sb.push('       </div>');
        sb.push('       <input id="',targetId,'MinuteInp" type="text" maxlength="2" ', (isDisabled?' disabled="disabled"  ':''), ' />');
        sb.push('       <ins id="'+targetId+'minu_ins" onclick="$.timePicker.onclickminute(\''+id+'\', this)"');
        sb.push('       ></ins>');
        sb.push('   </li>');
        sb.push('   <li id="'+targetId+'mssplit" class="timepicker_split">:</li>');
        sb.push('   <li id="',targetId,'second_li" class="timepicker_second">');
        sb.push('       <div id="'+targetId+'secondSel" class="timepicker_selectlist">');
        for(var i=0; i<secondOptions.length; i++)
        {
            sb.push('           <a>'+secondOptions[i]+'</a>');
        }
        sb.push('       </div>');
        sb.push('       <input id="'+targetId+'SecondInp" type="text" maxlength="2" ', (isDisabled?' disabled="disabled"  ':''), ' />');
        sb.push('       <ins id="'+targetId+'second_ins" onclick="$.timePicker.onclicksecond(\''+id+'\', this)"');
        sb.push('       ></ins>');
        sb.push('   </li>');
        sb.push('</ul>');

        container = $(sb.join("")).insertAfter(targetInp);
        // var $viewinputs = container.find(":input").not(s.target[0]);
        // jBME.EFT.install( $viewinputs );
    }

    function initEvent(){
        var defaultHour = defaultVArr[0];
        var defaultMinute = defaultVArr[1];
        var defaultSecond = defaultVArr[2];
        if(!container)
        {
            container = $(targetInp.siblings("ul"));
        }
        hourObj = container.find("#"+targetId+"hour_li");
        hourInp = hourObj.find("#"+targetId+"HourInp");
        hourSel = hourObj.find("#"+targetId+"hourSel");

        minuteObj = container.find("#"+targetId+"minute_li");
        minuteInp = minuteObj.find("#"+targetId+"MinuteInp");
        minuteSel = minuteObj.find("#"+targetId+"minuteSel");

        secondObj = container.find("#"+targetId+"second_li");
        secondInp = secondObj.find("#"+targetId+"SecondInp");
        secondSel = secondObj.find("#"+targetId+"secondSel");

        var hmspilt = container.find("#"+targetId+"hmsplit");
        var mssplit = container.find("#"+targetId+"mssplit");

        if(hourInp[0].value=="")
        {
            if(defaultHour<10 && defaultHour.length==1)
            {
                defaultHour = '0' + defaultHour;
            }
            hourInp[0].value = defaultHour;
            hourInp[0].defaultValue = defaultHour;
        }
        if(minuteInp[0].value == "")
        {
            if(defaultMinute<10 && defaultMinute.length==1)
            {
                defaultMinute = '0' + defaultMinute;
            }
            minuteInp[0].value = defaultMinute;
            minuteInp[0].defaultValue = defaultMinute;
        }
        if(secondInp[0].value == "")
        {
            if(defaultSecond<10 && defaultSecond.length==1)
            {
                defaultSecond = '0' + defaultSecond;
            }
            secondInp[0].value = defaultSecond;
            secondInp[0].defaultValue = defaultSecond;
        }

        // when init,make sure all obj is show;
        hmspilt.show();
        hourObj.show();
        minuteObj.show();
        mssplit.show();
        secondObj.show()

        if(-1==conf.timeFormat.indexOf("hh")&&-1==conf.timeFormat.indexOf("HH"))
        {
            hmspilt.hide();
            hourObj.hide();
        }
        if(-1==conf.timeFormat.indexOf("ii"))
        {
            if(-1==conf.timeFormat.indexOf("ss"))
            {
                mssplit.hide();
            }
            hmspilt.hide();
            minuteObj.hide();
        }
        if(-1==conf.timeFormat.indexOf("ss"))
        {
            mssplit.hide();
            secondObj.hide();
        }

        if(labelArr[0]==hourInp.val())
        {
            hourInp.removeClass("_fill");
        }
        else
        {
            hourInp.addClass("_fill");
        }
        if(labelArr[1]==minuteInp.val())
        {
            minuteInp.removeClass("_fill");
        }
        else
        {
            minuteInp.addClass("_fill");
        }
        if(labelArr[2]==secondInp.val())
        {
            secondInp.removeClass("_fill");
        }
        else
        {
            secondInp.addClass("_fill");
        }

        if(!isDisabled && !conf.reload)
        {
            container.bind("reset",function(e){
                if(-1 != conf.label.search($(e.target).val()))
                {
                    $(e.target).removeClass("_fill");
                }
            });

            // 时
            hourInp.bind("blur", function(event) {
                timeCom(hourInp);
                if(""==hourInp.val())
                {
                    hourInp.val(labelArr[0]);
                }
                if(labelArr[0]==hourInp.val()||""==hourInp.val())
                {
                    hourInp.removeClass("_fill");
                }
                else
                {
                    hourInp.addClass("_fill");
                }

                // 手动输入场景下，需跟下拉列表选择时间保持一致，值发生变化，均需绑定change事件
                $target = $(event.target);
                var oldHourInpVal = hourInp.val();
                if(oldHourInpVal!=$target.text())
                {
                     hourInp.trigger("change");
                }

            });
            hourInp.bind("focus", function() {
                hourInp.select();
                if(labelArr[0]==hourInp.val())
                {
				    if(!hourInp.is("[disabled]"))
                    {
                        hourInp.val('');
                    }
                    hourInp.removeClass("_fill");
                }
                else
                {
                    hourInp.addClass("_fill");
                }
            });

            hourSel.click(function(event){
                $target = $(event.target);
                // IE下多选也会触发click事件,如果是多选忽略
                if($target.text().length > 2)
                {
                    return;
                }
                var oldHourInpVal = hourInp.val();
                hourInp.val($target.text());
                hourInp.focus();
                hourInp.addClass("_fill");
                updateTime();
                if(oldHourInpVal!=$target.text())
                {
                     hourInp.trigger("change");
                }
                $target.removeClass("over");
		    hourSel.hide();
		    event.stopPropagation();
            });
            hourSel.mouseover(function(event){
                $target = $(event.target);
                if($target[0].nodeName == "A")
                {
                    $target.addClass("over");
                }
            });
            hourSel.mouseout(function(event){
                $target = $(event.target);
                if($target[0].nodeName == "A")
                {
                    $target.removeClass("over");
                }
            });

            // 分
            minuteInp.bind("blur", function(event) {
                timeCom(minuteInp);
                if(""==minuteInp.val())
                {
                    minuteInp.val(labelArr[1]);
                }
                if(labelArr[1]==minuteInp.val()||""==minuteInp.val())
                {
                    minuteInp.removeClass("_fill");
                }
                else
                {
                    minuteInp.addClass("_fill");
                }

                // 手动输入场景下，需跟下拉列表选择时间保持一致，值发生变化，均需绑定change事件
                $target = $(event.target);
                var oldMinuteInpVal = minuteInp.val();
                if(oldMinuteInpVal!=$target.text())
                {
                     minuteInp.trigger("change");
                }
            });
            minuteInp.bind("focus", function() {
                minuteInp.select();
                if(labelArr[1]==minuteInp.val())
                {
				    if(!minuteInp.is("[disabled]"))
                    {
                        minuteInp.val('');
                    }
                    minuteInp.removeClass("_fill");
                }
                else
                {
                    minuteInp.addClass("_fill");
                }
            });

            minuteSel.click(function(event){
                $target = $(event.target);
                // IE下多选也会触发click事件,如果是多选忽略
                if($target.text().length > 2)
                {
                    return;
                }
                var oldMinuteInpVal = minuteInp.val();
                minuteInp.val($target.text());
                minuteInp.focus();
                minuteInp.addClass("_fill");
                updateTime();
                if(oldMinuteInpVal!=$target.text())
                {
                     minuteInp.trigger("change");
                }
                $target.removeClass("over");
		        minuteSel.hide();
		        event.stopPropagation();
            });
            minuteSel.mouseover(function(event){
                $target = $(event.target);
                if($target[0].nodeName == "A")
                {
                    $target.addClass("over");
                }
            });
            minuteSel.mouseout(function(event){
                $target = $(event.target);
                if($target[0].nodeName == "A")
                {
                    $target.removeClass("over");
                }
            });

            // 秒
            secondInp.bind("blur", function(event) {
                timeCom(secondInp);
                if(""==secondInp.val())
                {
                    secondInp.val(labelArr[2]);
                }
                if(labelArr[2]==secondInp.val()||""==secondInp.val())
                {
                    secondInp.removeClass("_fill");
                }
                else
                {
                    secondInp.addClass("_fill");
                }

                // 手动输入场景下，需跟下拉列表选择时间保持一致，值发生变化，均需绑定change事件
                $target = $(event.target);
                var oldSecondInpVal = secondInp.val();
                if(oldSecondInpVal!=$target.text())
                {
                    secondInp.trigger("change");
                }
            });
            secondInp.bind("focus", function() {
                secondInp.select();
                if(labelArr[2]==secondInp.val())
                {
				    if(!secondInp.is("[disabled]"))
                    {
                        secondInp.val('');
                    }
                    secondInp.removeClass("_fill");
                }
                else
                {
                    secondInp.addClass("_fill");
                }
            });

            secondSel.click(function(event)
               {
                $target = $(event.target);
                // IE下多选也会触发click事件,如果是多选忽略
                if($target.text().length > 2)
                {
                    return;
                }
                var oldSecondInpVal = secondInp.val();
                secondInp.val($target.text());
                secondInp.focus();
                secondInp.addClass("_fill");
                updateTime();
                if(oldSecondInpVal!=$target.text())
                {
                    secondInp.trigger("change");
                }
                $target.removeClass("over");
		secondSel.hide();
		event.stopPropagation();
            });
            secondSel.mouseover(function(event){
                $target = $(event.target);
                if($target[0].nodeName == "A")
                {
                    $target.addClass("over");
                }
            });
            secondSel.mouseout(function(event){
                $target = $(event.target);
                if($target[0].nodeName == "A")
                {
                    $target.removeClass("over");
                }
            });

            hourInp.keypress(function(e) {
                if((e.which<48||e.which>57)&&e.which!=8&&e.which!=0)
                {
                    return false;
                }
                if((hourInp.val()>23&&conf.kind != "time24") || (hourInp.val()>24&&conf.kind == "time24"))
                {
                    return false;
                }
            });

            hourInp.keyup(function(e) {
                var v = hourInp.val();
                if((v>23&&conf.kind != "time24") || (v>24&&conf.kind == "time24"))
                {
                    hourInp.val(parseInt(v/10));
                    return false;
                }

                if(((e.which>=48&&e.which<=57)||(e.which>=96&&e.which<=105))&&hourInp.val().length>=2&&hourInp.val()!=labelArr[0])
                {
                    var oldValue = targetInp.val().substring(0,2);
                    var newValue = hourInp.val();
                    setTimeout(function(){
                        hourInp.blur();
                        minuteInp.focus();
                        minuteInp.select();
                        updateTime();
                        if(oldValue!=newValue)
                        {
                            hourInp.trigger("change");
                        }
                    },120)
                    // return;
                }
                if(e.which==9)
                {
                    hourInp.focus();
                    hourInp.select();
                    updateTime();
                    return;
                }
                var newVal = hourInp.val().replace(/[^\d]/gim,"");
                hourInp.val(newVal);
                updateTime();
            });
            minuteInp.keypress(function(e) {
                if((e.which<48||e.which>57)&&e.which!=8&&e.which!=0)
                {
                    return false;
                }
                if(minuteInp.val()>59)
                {
                    return false;
                }
            });
            minuteInp.keyup(function(e) {
                var v = minuteInp.val();
                if(v>59)
                {
                    minuteInp.val(parseInt(v/10));
                    return false;
                }
                if(conf.timeFormat.indexOf('ss')==-1)
                {
                    return;
                }
                if(((e.which>=48&&e.which<=57)||(e.which>=96&&e.which<=105))&&minuteInp.val().length>=2&&minuteInp.val()!=labelArr[1])
                {
                    var oldValue = targetInp.val().substring(3,5);
                    var newValue = minuteInp.val();
                    setTimeout(function(){
                        minuteInp.blur();
                        secondInp.focus();
                        secondInp.select();
                        if(oldValue!=newValue)
                        {
                            minuteInp.trigger("change");
                        }
                    },120);
                    // return;
                }
                if(e.which==9)
                {
                    // alert(event.shiftKey);
                    minuteInp.focus();
                    minuteInp.select();
                    updateTime();
                    return;
                }
                var newVal = minuteInp.val().replace(/[^\d]/gim,"");
                minuteInp.val(newVal);
                updateTime();
            });
            secondInp.keypress(function(e) {
                if((e.which<48||e.which>57)&&e.which!=8&&e.which!=0)
                {
                    return false;
                }
                if(secondInp.val()>59)
                {
                    return false;
                }
            });
            secondInp.keyup(function(e) {
                var v = secondInp.val();
                if(v>59)
                {
                    secondInp.val(parseInt(v/10));
                    return false;
                }
                if(e.which==9)
                {
                    secondInp.focus();
                    secondInp.select();
                    updateTime();
                    return;
                }
                var newVal = secondInp.val().replace(/[^\d]/gim,"");
                secondInp.val(newVal);
                updateTime();
            });

            // 绑定change事件 当通过中文输入法输入中文或拷贝等其他方式输入非法字符时 自动恢复成正常的数字
            hourInp.change(function(e){
            	var val = hourInp.val();
                var newVal = val.replace(/[^\d]/gim,"");
                if(val != newVal){
                	hourInp.val(newVal);
                	updateTime();
                }
            })
            minuteInp.change(function(e){
            	var val = minuteInp.val();
            	var newVal = val.replace(/[^\d]/gim,"");
            	if(val != newVal){
                    minuteInp.val(newVal);
                    updateTime();
            	}
            })
            secondInp.change(function(e){
            	var val = secondInp.val();
                var newVal = val.replace(/[^\d]/gim,"");
                if(val != newVal){
                    secondInp.val(newVal);
                    updateTime();
                }
            })
        }
    }

    function updateTime() {
        var val = new Array();
        var labelArr = conf.label.split(":");
        var hourVal = hourInp.val();
        var minuteVal = minuteInp.val();
        var secondVal = secondInp.val();
        if(hourVal.length == 0){
        	hourVal = "00"
        }else if(hourVal.length == 1){
        	hourVal = "0"+minuteVal;
        }
        if(minuteVal.length == 0){
        	minuteVal = "00"
        }else if(minuteVal.length == 1){
        	minuteVal = "0"+minuteVal;
        }
        if(secondVal.length == 0){
        	secondVal = "00"
        }else if(secondVal.length == 1){
        	secondVal = "0"+minuteVal;
        }
        var valStr = "";

        if((""==hourVal||hourVal==labelArr[0])&&""==(minuteVal||minuteVal==labelArr[1])&&(""==secondVal||secondVal==labelArr[2]))
        {
            valStr = "";
        }
        else
        {
            hourVal = (hourVal==""||hourVal==labelArr[0])?"00":hourVal;
            minuteVal = (minuteVal==""||minuteVal==labelArr[1])?"00":minuteVal;
            secondVal = (secondVal==""||secondVal==labelArr[2])?"00":secondVal;
            if(-1!=conf.timeFormat.indexOf("hh")||-1!=conf.timeFormat.indexOf("HH"))
            {
                val.push(hourVal);
            }
            else
            {
                if(conf.kind != "time")
                {
                    val.push("00");
                }
            }
            if(-1!=conf.timeFormat.indexOf("ii"))
            {
                val.push(minuteVal);
            }
            else
            {
                if(conf.kind != "time")
                {
                    val.push("00");
                }
            }
            if(-1!=conf.timeFormat.indexOf("ss"))
            {
                val.push(secondVal);
            }
            else
            {
                if(conf.kind != "time")
                {
                    val.push("00");
                }
            }
            valStr = val.join(":");
        }
        targetInp.val(valStr);
        if(conf.onchange)
        {
            conf.onchange.call(this, targetInp.val());
        }
        if(hourVal==24 && conf.kind == "time24")
        {
            minuteInp.val("00");
            secondInp.val("00");
        }
    }
    function timeCom(timeobj)
    {
        if (timeobj.val().length < 2)
        {
            if(timeobj.val().length == 0)
            {
                timeobj.val('00');
                if($.browser.mozilla)
                {
                    timeobj.trigger("change");
                }
            }
            else
            {
                timeobj.val('0' + timeobj.val());
            }
        }
        updateTime();
    }
};

$.timePicker.onclickhour = function(id)
{
    var timePoper = new jBME.Poper($("#"+id+"_valuehourSel"));
    var timer = $("#"+id+"_valuehour_li");
    timePoper.show(timer);
    var datetimepicker = $.datetimepicker._datetimepickerDiv;
    if(datetimepicker.children().length != 0)
    {
        datetimepicker.unbind("click.valuehour_"+id).bind("click.valuehour_"+id,function(jEvent){
            if(jEvent.target.id != (id+"_valuehourSel") && jEvent.target.id != (id+"_valuehour_ins"))
                {
                    timePoper.hide();
                }
	    jEvent.stopPropagation();
        });
    }
    else
    {
        $(document).unbind("click.valuehour_"+id).bind("click.valuehour_"+id,function(jEvent){
             if(jEvent.target.id != (id+"_valuehourSel") && jEvent.target.id != (id+"_valuehour_ins"))
             {
                 timePoper.hide();
             }
        });
    }

    $.timePicker.hotPoper = timePoper;
};

$.timePicker.onclickminute = function(id, target)
{
    var timePoper = new jBME.Poper($("#"+id+"_valueminuteSel"));
    var timer = $("#"+id+"_valueminute_li");
    timePoper.show(timer);
	var datetimepicker = $.datetimepicker._datetimepickerDiv;
	if(datetimepicker.children().length != 0)
	{
	    datetimepicker.unbind("click.valueminute_"+id).bind("click.valueminute_"+id,function(jEvent){
            var target = jEvent.target;
            if(jEvent.target.id != (id+"_valueminuteSel") && jEvent.target.id != (id+"_valueminu_ins"))
            {
                timePoper.hide();
            }
		   jEvent.stopPropagation();
        });
    }
	else
	{
	    $(document).unbind("click.valueminute_"+id).bind("click.valueminute_"+id,function(jEvent){
            if(jEvent.target.id != (id+"_valueminuteSel") && jEvent.target.id != (id+"_valueminu_ins"))
            {
                timePoper.hide();
            }
        });
	}
    $.timePicker.hotPoper = timePoper;
};
//
$.timePicker.onclicksecond = function(id, target)
{
    var timePoper = new jBME.Poper($("#"+id+"_valuesecondSel"));
    var timer = $("#"+id+"_valuesecond_li");
	var datetimepicker = $.datetimepicker._datetimepickerDiv;
    timePoper.show(timer);
	if(datetimepicker.children().length != 0)
	{
        datetimepicker.unbind("click.valuesecond_"+id).bind("click.valuesecond_"+id,function(jEvent){
            var target = jEvent.target;
            if(jEvent.target.id != (id+"_valuesecondSel") && jEvent.target.id != (id+"_valuesecond_ins"))
            {
                 timePoper.hide();
            }
		    jEvent.stopPropagation();
        });
	}
	else
	{
	    $(document).unbind("click.valuesecond_"+id).bind("click.valuesecond_"+id,function(jEvent){
            var target = jEvent.target;
            if(jEvent.target.id != (id+"_valuesecondSel") && jEvent.target.id != (id+"_valuesecond_ins"))
            {
                timePoper.hide();
            }
        });
	}
    $.timePicker.hotPoper = timePoper;
};

$.fn.timePicker = function( s ) {
    var containerid = this[0].id;
    var $modelinput = $("#"+this[0].id+"_value");
    var conf = $.extend(
    {
        "target": $modelinput,
        "containerid":containerid,
        /**
		 * @require validate plugin.
		 */
       onchange : function()
       {
          $modelinput.valid();
       }
   }, s);

        $.timePicker( conf );

};
})(jQuery);
/* Arabic Translation for jQuery UI date picker plugin. */
/* Khaled Al Horani -- koko.dw@gmail.com */
/* خالد الحوراني -- koko.dw@gmail.com */
/*
 * NOTE: monthNames are the original months names and they are the Arabic names,
 * not the new months name فبراير - يناير and there isn't any Arabic roots for
 * these months
 */
;(function($){
    /*
	 * Get Reginal by local(en-US) or country(en) @param lang: Take as
	 * local(en-US) first, if can't find one, then pick the country part(en) and
	 * find again.
	 */
	$.datetimepicker.getRegional = function(lang){
		return ($.datetimepicker.regional[lang] || $.datetimepicker.regional[lang.split("-")[0]]);
	};
})(jQuery);
(function($){
	$.datetimepicker.regional['ar'] = {
		displayLocal:true,
		calendric: 2,
		closeText: 'إغلاق',
		prevText: '&#x3c;السابق',
		nextText: 'التالي&#x3e;',
		prevYearText: '&#x3c;السنة السابقة',
		nextYearText: 'السنة التالية&#x3e;',
		currentText: 'اليوم',
		monthNames:['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
		// monthNames: ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'آذار',
		// 'حزيران',
		// 'تموز', 'آب', 'أيلول', 'تشرين الأول', 'تشرين الثاني', 'كانون الأول'],
		monthNamesShort: ['1','2','3','4','5','6','7','8','9','10','11','12'],
		dayNames: ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'],
		dayNamesShort: ['سبت', 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'],
		dayNamesMin: ['سبت', 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'],
		okLabel: 'موافق',
		cancelLabel: 'إلغاء',
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		pickertitle:'Hegira Calendar',
		isRTL: true,
		buttonText: 'تحديد التاريخ',
		dstConfirmMsg:"الوقت المحدد هو نفس الوقت الأصلي. هل تعني بذلك استخدام نظام التوقيت الصيفي (DTS)؟",
		adjustTip:"لقد اخترت التوقيت الصيفي الغير صحيح. فقد تم تغيير الوقت  تلقائيا إلى نظام التوقيت المحلي القياسي."};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ar']);
})(jQuery);/* Bulgarian initialisation for the jQuery UI date picker plugin. */
/* Written by Stoyan Kyosev (http://svest.org). */
(function($){
    $.datetimepicker.regional['bg'] = {
        closeText: 'затвори',
        prevText: '&#x3c;назад',
        nextText: 'напред&#x3e;',
		nextBigText: '&#x3e;&#x3e;',
        currentText: 'днес',
        monthNames: ['Януари','Февруари','Март','Април','Май','Юни',
        'Юли','Август','Септември','Октомври','Ноември','Декември'],
        monthNamesShort: ['Яну','Фев','Мар','Апр','Май','Юни',
        'Юли','Авг','Сеп','Окт','Нов','Дек'],
        dayNames: ['Неделя','Понеделник','Вторник','Сряда','Четвъртък','Петък','Събота'],
        dayNamesShort: ['Нед','Пон','Вто','Сря','Чет','Пет','Съб'],
        dayNamesMin: ['Не','По','Вт','Ср','Че','Пе','Съ'],
        dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
        isRTL: false,
		dstConfirmMsg:"confirmMsg for bg ",
		adjustTip:"adjustTip for bg"};
    // $.datetimepicker.setDefaults($.datetimepicker.regional['bg']);
})(jQuery);
/* Inicialitzaci� en catal� per a l'extenci� 'calendar' per jQuery. */
/* Writers: (joan.leon@gmail.com). */
(function($){
	$.datetimepicker.regional['ca'] = {
		closeText: 'Tancar',
		prevText: '&#x3c;Ant',
		nextText: 'Seg&#x3e;',
		currentText: 'Avui',
		monthNames: ['Gener','Febrer','Mar&ccedil;','Abril','Maig','Juny',
		'Juliol','Agost','Setembre','Octubre','Novembre','Desembre'],
		monthNamesShort: ['Gen','Feb','Mar','Abr','Mai','Jun',
		'Jul','Ago','Set','Oct','Nov','Des'],
		dayNames: ['Diumenge','Dilluns','Dimarts','Dimecres','Dijous','Divendres','Dissabte'],
		dayNamesShort: ['Dug','Dln','Dmt','Dmc','Djs','Dvn','Dsb'],
		dayNamesMin: ['Dg','Dl','Dt','Dc','Dj','Dv','Ds'],
		dateFormat: 'mm/dd/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for ca ",
		adjustTip:"adjustTip for ca"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ca']);
})(jQuery);/* Czech initialisation for the jQuery UI date picker plugin. */
/* Written by Tomas Muller (tomas@tomas-muller.net). */
(function($){
	$.datetimepicker.regional['cs'] = {
		closeText: 'Zavřít',
		prevText: '&#x3c;Dříve',
		nextText: 'Později&#x3e;',
		currentText: 'Nyní',
		monthNames: ['leden','únor','březen','duben','květen','červen',
        'červenec','srpen','září','říjen','listopad','prosinec'],
		monthNamesShort: ['led','úno','bře','dub','kvě','čer',
		'čvc','srp','zář','říj','lis','pro'],
		dayNames: ['neděle', 'pondělí', 'úterý', 'středa', 'čtvrtek', 'pátek', 'sobota'],
		dayNamesShort: ['ne', 'po', 'út', 'st', 'čt', 'pá', 'so'],
		dayNamesMin: ['ne','po','út','st','čt','pá','so'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for cs ",
		adjustTip:"adjustTip for cs"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['cs']);
})(jQuery);/* Danish initialisation for the jQuery UI date picker plugin. */
/* Written by Jan Christensen ( deletestuff@gmail.com). */
(function($){
    $.datetimepicker.regional['da'] = {
		closeText: 'Luk',
        prevText: '&#x3c;Forrige',
		nextText: 'Næste&#x3e;',
		currentText: 'Idag',
        monthNames: ['Januar','Februar','Marts','April','Maj','Juni',
        'Juli','August','September','Oktober','November','December'],
        monthNamesShort: ['Jan','Feb','Mar','Apr','Maj','Jun',
        'Jul','Aug','Sep','Okt','Nov','Dec'],
		dayNames: ['Søndag','Mandag','Tirsdag','Onsdag','Torsdag','Fredag','Lørdag'],
		dayNamesShort: ['Søn','Man','Tir','Ons','Tor','Fre','Lør'],
		dayNamesMin: ['Sø','Ma','Ti','On','To','Fr','Lø'],
        dateFormat: 'dd-mm-yy', dateFormatHeader: 'mm-yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for da ",
		adjustTip:"adjustTip for da"};
    // $.datetimepicker.setDefaults($.datetimepicker.regional['da']);
})(jQuery);/* German initialisation for the jQuery UI date picker plugin. */
/* Written by Milian Wolff (mail@milianw.de). */
(function($){
	$.datetimepicker.regional['de'] = {
		closeText: 'schließen',
		prevText: '&#x3c;zurück',
		nextText: 'Vor&#x3e;',
		currentText: 'heute',
		monthNames: ['Januar','Februar','März','April','Mai','Juni',
		'Juli','August','September','Oktober','November','Dezember'],
		monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun',
		'Jul','Aug','Sep','Okt','Nov','Dez'],
		dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
		dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
		dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for de ",
		adjustTip:"adjustTip for de"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['de']);
})(jQuery);/* Greek (el) initialisation for the jQuery UI date picker plugin. */
/* Written by Alex Cicovic (http://www.alexcicovic.com) */
(function($){
	$.datetimepicker.regional['el'] = {
		closeText: 'Κλείσιμο',
		prevText: 'Προηγούμενος',
		nextText: 'Επόμενος',
		currentText: 'Τρέχων Μήνας',
		monthNames: ['Ιανουάριος','Φεβρουάριος','Μάρτιος','Απρίλιος','Μάιος','Ιούνιος',
		'Ιούλιος','Αύγουστος','Σεπτέμβριος','Οκτώβριος','Νοέμβριος','Δεκέμβριος'],
		monthNamesShort: ['Ιαν','Φεβ','Μαρ','Απρ','Μαι','Ιουν',
		'Ιουλ','Αυγ','Σεπ','Οκτ','Νοε','Δεκ'],
		dayNames: ['Κυριακή','Δευτέρα','Τρίτη','Τετάρτη','Πέμπτη','Παρασκευή','Σάββατο'],
		dayNamesShort: ['Κυρ','Δευ','Τρι','Τετ','Πεμ','Παρ','Σαβ'],
		dayNamesMin: ['Κυ','Δε','Τρ','Τε','Πε','Πα','Σα'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for el ",
		adjustTip:"adjustTip for el"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['el']);
})(jQuery);/* Esperanto initialisation for the jQuery UI date picker plugin. */
/* Written by Olivier M. (olivierweb@ifrance.com). */
(function($){
	$.datetimepicker.regional['eo'] = {
		closeText: 'Fermi',
		prevText: '&lt;Anta',
		nextText: 'Sekv&gt;',
		currentText: 'Nuna',
		monthNames: ['Januaro','Februaro','Marto','Aprilo','Majo','Junio',
		'Julio','Aŭgusto','Septembro','Oktobro','Novembro','Decembro'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Maj','Jun',
		'Jul','Aŭg','Sep','Okt','Nov','Dec'],
		dayNames: ['Dimanĉo','Lundo','Mardo','Merkredo','Ĵaŭdo','Vendredo','Sabato'],
		dayNamesShort: ['Dim','Lun','Mar','Mer','Ĵaŭ','Ven','Sab'],
		dayNamesMin: ['Di','Lu','Ma','Me','Ĵa','Ve','Sa'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for eo ",
		adjustTip:"adjustTip for eo"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['eo']);
})(jQuery);
/* Inicializaci�n en espa�ol para la extensi�n 'UI date picker' para jQuery. */
/* Traducido por Vester (xvester@gmail.com). */
(function($){
	$.datetimepicker.regional['es'] = {
		closeText: 'Cerrar',
		prevText: '&#x3c;Ant',
		nextText: 'Sig&#x3e;',
		currentText: 'Hoy',
		monthNames: ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
		'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
		monthNamesShort: ['Ene','Feb','Mar','Abr','May','Jun',
		'Jul','Ago','Sep','Oct','Nov','Dic'],
		dayNames: ['Domingo','Lunes','Martes','Mi&eacute;rcoles','Jueves','Viernes','S&aacute;bado'],
		dayNamesShort: ['Dom','Lun','Mar','Mi&eacute;','Juv','Vie','S&aacute;b'],
		dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','S&aacute;'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		okLabel: 'Aceptar',
		cancelLabel: 'Cancelar',
		isRTL: false,
		dstConfirmMsg:"confirmMsg for es ",
		adjustTip:"adjustTip for es"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['es']);
})(jQuery);/* Persian (Farsi) Translation for the jQuery UI date picker plugin. */
/* Javad Mowlanezhad -- jmowla@gmail.com */
/*
 * Jalali calendar should supported soon! (Its implemented but I have to test
 * it)
 */
(function($) {
	$.datetimepicker.regional['fa'] = {
		displayLocal:true,
		calendric: 1,
		closeText: 'بستن',
		prevText: '&#x3c;قبلي',
		nextText: 'بعدي&#x3e;',
		currentText: 'امروز',
		monthNames: ['فروردين','ارديبهشت','خرداد','تير','مرداد','شهريور',
		'مهر','آبان','آذر','دي','بهمن','اسفند'],
		monthNamesShort: ['1','2','3','4','5','6','7','8','9','10','11','12'],
		dayNames: ['يکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه'],
		dayNamesShort: ['ي','د','س','چ','پ','ج', 'ش'],
		dayNamesMin: ['ي','د','س','چ','پ','ج', 'ش'],
		dateFormat: 'yy/mm/dd', dateFormatHeader: 'yy/mm', firstDay: 6,
		pickertitle:'تقویم فارسی',
        isRTL: true,
		dstConfirmMsg:"confirmMsg for fa ",
		adjustTip:"adjustTip for fa",

		okLabel: 'تأیید',
		cancelLabel: 'لغو',
		clearText: 'پاک کردن',
        digits:['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'],
        thisType: 'fa'
  };
	// $.datetimepicker.setDefaults($.datetimepicker.regional['fa']);
})(jQuery);/* Finnish initialisation for the jQuery UI date picker plugin. */
/* Written by Harri Kilpi� (harrikilpio@gmail.com). */
(function($){
    $.datetimepicker.regional['fi'] = {
		closeText: 'Sulje',
		prevText: '&laquo;Edellinen',
		nextText: 'Seuraava&raquo;',
		currentText: 'T&auml;n&auml;&auml;n',
        monthNames: ['Tammikuu','Helmikuu','Maaliskuu','Huhtikuu','Toukokuu','Kes&auml;kuu',
        'Hein&auml;kuu','Elokuu','Syyskuu','Lokakuu','Marraskuu','Joulukuu'],
        monthNamesShort: ['Tammi','Helmi','Maalis','Huhti','Touko','Kes&auml;',
        'Hein&auml;','Elo','Syys','Loka','Marras','Joulu'],
		dayNamesShort: ['Su','Ma','Ti','Ke','To','Pe','Su'],
		dayNames: ['Sunnuntai','Maanantai','Tiistai','Keskiviikko','Torstai','Perjantai','Lauantai'],
		dayNamesMin: ['Su','Ma','Ti','Ke','To','Pe','La'],
        dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for fi ",
		adjustTip:"adjustTip for fi"};
    // $.datetimepicker.setDefaults($.datetimepicker.regional['fi']);
})(jQuery);
/* French initialisation for the jQuery UI date picker plugin. */
/*
 * Written by Keith Wood (kbwood@virginbroadband.com.au) and Stéphane Nahmani
 * (sholby@sholby.net).
 */
(function($){
	$.datetimepicker.regional['fr'] = {
		closeText: 'Fermer',
		prevText: '&#x3c;Préc',
		nextText: 'Suiv&#x3e;',
		currentText: 'Courant',
		monthNames: ['Janvier','Février','Mars','Avril','Mai','Juin',
		'Juillet','Août','Septembre','Octobre','Novembre','Décembre'],
		monthNamesShort: ['Jan','Fév','Mar','Avr','Mai','Jun',
		'Jul','Aoû','Sep','Oct','Nov','Déc'],
		dayNames: ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'],
		dayNamesShort: ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'],
		dayNamesMin: ['Di','Lu','Ma','Me','Je','Ve','Sa'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for fr ",
		adjustTip:"adjustTip for fr"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['fr']);
})(jQuery);/* Hebrew initialisation for the UI datetimepicker extension. */
/* Written by Amir Hardon (ahardon at gmail dot com). */
(function($){
	$.datetimepicker.regional['he'] = {
		closeText: 'סגור',
		prevText: '&#x3c;הקודם',
		nextText: 'הבא&#x3e;',
		currentText: 'היום',
		monthNames: ['ינואר','פברואר','מרץ','אפריל','מאי','יוני',
		'יולי','אוגוסט','ספטמבר','אוקטובר','נובמבר','דצמבר'],
		monthNamesShort: ['1','2','3','4','5','6',
		'7','8','9','10','11','12'],
		dayNames: ['ראשון','שני','שלישי','רביעי','חמישי','שישי','שבת'],
		dayNamesShort: ['א\'','ב\'','ג\'','ד\'','ה\'','ו\'','שבת'],
		dayNamesMin: ['א\'','ב\'','ג\'','ד\'','ה\'','ו\'','שבת'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: true,
		dstConfirmMsg:"confirmMsg for he ",
		adjustTip:"adjustTip for he"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['he']);
})(jQuery);
/* Croatian i18n for the jQuery UI date picker plugin. */
/* Written by Vjekoslav Nesek. */
(function($){
	$.datetimepicker.regional['hr'] = {
		closeText: 'Zatvori',
		prevText: '&#x3c;',
		nextText: '&#x3e;',
		currentText: 'Danas',
		monthNames: ['Siječanj','Veljača','Ožujak','Travanj','Svibanj','Lipani',
		'Srpanj','Kolovoz','Rujan','Listopad','Studeni','Prosinac'],
		monthNamesShort: ['Sij','Velj','Ožu','Tra','Svi','Lip',
		'Srp','Kol','Ruj','Lis','Stu','Pro'],
		dayNames: ['Nedjalja','Ponedjeljak','Utorak','Srijeda','Četvrtak','Petak','Subota'],
		dayNamesShort: ['Ned','Pon','Uto','Sri','Čet','Pet','Sub'],
		dayNamesMin: ['Ne','Po','Ut','Sr','Če','Pe','Su'],
		dateFormat: 'dd.mm.yy.', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for hr ",
		adjustTip:"adjustTip for hr"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['hr']);
})(jQuery);/* Hungarian initialisation for the jQuery UI date picker plugin. */
/* Written by Istvan Karaszi (jquerycalendar@spam.raszi.hu). */
(function($){
	$.datetimepicker.regional['hu'] = {
		closeText: 'bezárás',
		prevText: '&laquo;&nbsp;vissza',
		nextText: 'előre&nbsp;&raquo;',
		currentText: 'ma',
		monthNames: ['Január', 'Február', 'Március', 'Április', 'Május', 'Június',
		'Július', 'Augusztus', 'Szeptember', 'Október', 'November', 'December'],
		monthNamesShort: ['Jan', 'Feb', 'Már', 'Ápr', 'Máj', 'Jún',
		'Júl', 'Aug', 'Szep', 'Okt', 'Nov', 'Dec'],
		dayNames: ['Vasámap', 'Hétfö', 'Kedd', 'Szerda', 'Csütörtök', 'Péntek', 'Szombat'],
		dayNamesShort: ['Vas', 'Hét', 'Ked', 'Sze', 'Csü', 'Pén', 'Szo'],
		dayNamesMin: ['V', 'H', 'K', 'Sze', 'Cs', 'P', 'Szo'],
		dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for hu ",
		adjustTip:"adjustTip for hu"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['hu']);
})(jQuery);
/* Armenian(UTF-8) initialisation for the jQuery UI date picker plugin. */
/* Written by Levon Zakaryan (levon.zakaryan@gmail.com) */
(function($){
	$.datetimepicker.regional['hy'] = {
		closeText: 'Փակել',
		prevText: '&#x3c;Նախ.',
		nextText: 'Հաջ.&#x3e;',
		currentText: 'Այսօր',
		monthNames: ['Հունվար','Փետրվար','Մարտ','Ապրիլ','Մայիս','Հունիս',
		'Հուլիս','Օգոստոս','Սեպտեմբեր','Հոկտեմբեր','Նոյեմբեր','Դեկտեմբեր'],
		monthNamesShort: ['Հունվ','Փետր','Մարտ','Ապր','Մայիս','Հունիս',
		'Հուլ','Օգս','Սեպ','Հոկ','Նոյ','Դեկ'],
		dayNames: ['կիրակի','եկուշաբթի','երեքշաբթի','չորեքշաբթի','հինգշաբթի','ուրբաթ','շաբաթ'],
		dayNamesShort: ['կիր','երկ','երք','չրք','հնգ','ուրբ','շբթ'],
		dayNamesMin: ['կիր','երկ','երք','չրք','հնգ','ուրբ','շբթ'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for hyr ",
		adjustTip:"adjustTip for hy"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['hy']);
})(jQuery);/* Indonesian initialisation for the jQuery UI date picker plugin. */
/* Written by Deden Fathurahman (dedenf@gmail.com). */
(function($){
	$.datetimepicker.regional['id'] = {
		closeText: 'Tutup',
		prevText: '&#x3c;mundur',
		nextText: 'maju&#x3e;',
		currentText: 'hari ini',
		monthNames: ['Januari','Februari','Maret','April','Mei','Juni',
		'Juli','Agustus','September','Oktober','Nopember','Desember'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Mei','Jun',
		'Jul','Agus','Sep','Okt','Nop','Des'],
		dayNames: ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'],
		dayNamesShort: ['Min','Sen','Sel','Rab','kam','Jum','Sab'],
		dayNamesMin: ['Mg','Sn','Sl','Rb','Km','jm','Sb'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for id ",
		adjustTip:"adjustTip for id"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['id']);
})(jQuery);/* Icelandic initialisation for the jQuery UI date picker plugin. */
/* Written by Haukur H. Thorsson (haukur@eskill.is). */
(function($){
	$.datetimepicker.regional['is'] = {
		closeText: 'Loka',
		prevText: '&#x3c; Fyrri',
		nextText: 'N&aelig;sti &#x3e;',
		currentText: '&Iacute; dag',
		monthNames: ['Jan&uacute;ar','Febr&uacute;ar','Mars','Apr&iacute;l','Ma&iacute','J&uacute;n&iacute;',
		'J&uacute;l&iacute;','&Aacute;g&uacute;st','September','Okt&oacute;ber','N&oacute;vember','Desember'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Ma&iacute;','J&uacute;n',
		'J&uacute;l','&Aacute;g&uacute;','Sep','Okt','N&oacute;v','Des'],
		dayNames: ['Sunnudagur','M&aacute;nudagur','&THORN;ri&eth;judagur','Mi&eth;vikudagur','Fimmtudagur','F&ouml;studagur','Laugardagur'],
		dayNamesShort: ['Sun','M&aacute;n','&THORN;ri','Mi&eth;','Fim','F&ouml;s','Lau'],
		dayNamesMin: ['Su','M&aacute;','&THORN;r','Mi','Fi','F&ouml;','La'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for is ",
		adjustTip:"adjustTip for is"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['is']);
})(jQuery);/* Italian initialisation for the jQuery UI date picker plugin. */
/* Written by Apaella (apaella@gmail.com). */
(function($){
	$.datetimepicker.regional['it'] = {
		closeText: 'Chiudi',
		prevText: '&#x3c;Prec',
		nextText: 'Succ&#x3e;',
		currentText: 'Oggi',
		monthNames: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno',
		'Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
		monthNamesShort: ['Gen','Feb','Mar','Apr','Mag','Giu',
		'Lug','Ago','Set','Ott','Nov','Dic'],
		dayNames: ['Domenica','Luned&#236','Marted&#236','Mercoled&#236','Gioved&#236','Venerd&#236','Sabato'],
		dayNamesShort: ['Dom','Lun','Mar','Mer','Gio','Ven','Sab'],
		dayNamesMin: ['Do','Lu','Ma','Me','Gio','Ve','Sa'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for it ",
		adjustTip:"adjustTip for it"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['it']);
})(jQuery);
/* Japanese initialisation for the jQuery UI date picker plugin. */
/* Written by Kentaro SATO (kentaro@ranvis.com). */
(function($){
	$.datetimepicker.regional['ja'] = {
		closeText: '閉じる',
		prevText: '&#x3c;前',
		nextText: '次&#x3e;',
		currentText: '今日',
		monthNames: ['1月','2月','3月','4月','5月','6月',
		'7月','8月','9月','10月','11月','12月'],
		monthNamesShort: ['1月','2月','3月','4月','5月','6月',
		'7月','8月','9月','10月','11月','12月'],
		dayNames: ['日曜日','月曜日','火曜日','水曜日','木曜日','金曜日','土曜日'],
		dayNamesShort: ['日','月','火','水','木','金','土'],
		dayNamesMin: ['日','月','火','水','木','金','土'],
		dateFormat: 'yy/mm/dd', dateFormatHeader: 'yy/mm', firstDay: 0,
		isRTL: false,
		showMonthAfterYear: true,
		dstConfirmMsg:"confirmMsg for ja",
		adjustTip:"adjustTip for ja"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ja']);
})(jQuery);/* Korean initialisation for the jQuery calendar extension. */
/* Written by DaeKwon Kang (ncrash.dk@gmail.com). */
(function($){
	$.datetimepicker.regional['ko'] = {
		closeText: '닫기',
		prevText: '이전달',
		nextText: '다음달',
		currentText: '오늘',
		monthNames: ['1월(JAN)','2월(FEB)','3월(MAR)','4월(APR)','5월(MAY)','6월(JUN)',
		'7월(JUL)','8월(AUG)','9월(SEP)','10월(OCT)','11월(NOV)','12월(DEC)'],
		monthNamesShort: ['1월(JAN)','2월(FEB)','3월(MAR)','4월(APR)','5월(MAY)','6월(JUN)',
		'7월(JUL)','8월(AUG)','9월(SEP)','10월(OCT)','11월(NOV)','12월(DEC)'],
		dayNames: ['일','월','화','수','목','금','토'],
		dayNamesShort: ['일','월','화','수','목','금','토'],
		dayNamesMin: ['일','월','화','수','목','금','토'],
		dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for ko",
		adjustTip:"adjustTip for ko"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ko']);
})(jQuery);/*
			 * Lithuanian (UTF-8) initialisation for the jQuery UI date picker
			 * plugin.
			 */
/* @author Arturas Paleicikas <arturas@avalon.lt> */
(function($){
	$.datetimepicker.regional['lt'] = {
		closeText: 'Uždaryti',
		prevText: '&#x3c;Atgal',
		nextText: 'Pirmyn&#x3e;',
		currentText: 'Šiandien',
		monthNames: ['Sausis','Vasaris','Kovas','Balandis','Gegužė','Birželis',
		'Liepa','Rugpjūtis','Rugsėjis','Spalis','Lapkritis','Gruodis'],
		monthNamesShort: ['Sau','Vas','Kov','Bal','Geg','Bir',
		'Lie','Rugp','Rugs','Spa','Lap','Gru'],
		dayNames: ['sekmadienis','pirmadienis','antradienis','trečiadienis','ketvirtadienis','penktadienis','šeštadienis'],
		dayNamesShort: ['sek','pir','ant','tre','ket','pen','šeš'],
		dayNamesMin: ['Se','Pr','An','Tr','Ke','Pe','Še'],
		dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for lt ",
		adjustTip:"adjustTip for lt"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['lt']);
})(jQuery);/*
			 * Latvian (UTF-8) initialisation for the jQuery UI date picker
			 * plugin.
			 */
/* @author Arturas Paleicikas <arturas.paleicikas@metasite.net> */
(function($){
	$.datetimepicker.regional['lv'] = {
		closeText: 'Aizvērt',
		prevText: 'Iepr',
		nextText: 'Nāka',
		currentText: 'Šodien',
		monthNames: ['Janvāris','Februāris','Marts','Aprīlis','Maijs','Jūnijs',
		'Jūlijs','Augusts','Septembris','Oktobris','Novembris','Decembris'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Mai','Jūn',
		'Jūl','Aug','Sep','Okt','Nov','Dec'],
		dayNames: ['svētdiena','pirmdiena','otrdiena','trešdiena','ceturtdiena','piektdiena','sestdiena'],
		dayNamesShort: ['svt','prm','otr','tre','ctr','pkt','sst'],
		dayNamesMin: ['Sv','Pr','Ot','Tr','Ct','Pk','Ss'],
		dateFormat: 'dd-mm-yy', dateFormatHeader: 'mm-yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for lv ",
		adjustTip:"adjustTip for lv"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['lv']);
})(jQuery);/* Malaysian initialisation for the jQuery UI date picker plugin. */
/* Written by Mohd Nawawi Mohamad Jamili (nawawi@ronggeng.net). */
(function($){
	$.datetimepicker.regional['ms'] = {
		closeText: 'Tutup',
		prevText: '&#x3c;Sebelum',
		nextText: 'Selepas&#x3e;',
		currentText: 'hari ini',
		monthNames: ['Januari','Februari','Mac','April','Mei','Jun',
		'Julai','Ogos','September','Oktober','November','Disember'],
		monthNamesShort: ['Jan','Feb','Mac','Apr','Mei','Jun',
		'Jul','Ogo','Sep','Okt','Nov','Dis'],
		dayNames: ['Ahad','Isnin','Selasa','Rabu','Khamis','Jumaat','Sabtu'],
		dayNamesShort: ['Aha','Isn','Sel','Rab','kha','Jum','Sab'],
		dayNamesMin: ['Ah','Is','Se','Ra','Kh','Ju','Sa'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for ms ",
		adjustTip:"adjustTip for ms"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ms']);
})(jQuery);/*
			 * Dutch (UTF-8) initialisation for the jQuery UI date picker
			 * plugin.
			 */
/* Written by Mathias Bynens <http://mathiasbynens.be/> */
(function($){
	$.datetimepicker.regional.nl = {
		closeText: 'Sluiten',
		prevText: '←',
		nextText: '→',
		currentText: 'Vandaag',
		monthNames: ['januari', 'februari', 'maart', 'april', 'mei', 'juni',
		'juli', 'augustus', 'september', 'oktober', 'november', 'december'],
		monthNamesShort: ['jan', 'feb', 'maa', 'apr', 'mei', 'jun',
		'jul', 'aug', 'sep', 'okt', 'nov', 'dec'],
		dayNames: ['zondag', 'maandag', 'dinsdag', 'woensdag', 'donderdag', 'vrijdag', 'zaterdag'],
		dayNamesShort: ['zon', 'maa', 'din', 'woe', 'don', 'vri', 'zat'],
		dayNamesMin: ['zo', 'ma', 'di', 'wo', 'do', 'vr', 'za'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for nl",
		adjustTip:"adjustTip for nl"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional.nl);
})(jQuery);/* Norwegian initialisation for the jQuery UI date picker plugin. */
/* Written by Naimdjon Takhirov (naimdjon@gmail.com). */
(function($){
    $.datetimepicker.regional['no'] = {
		closeText: 'Lukk',
        prevText: '&laquo;Forrige',
		nextText: 'Neste&raquo;',
		currentText: 'I dag',
        monthNames: ['Januar','Februar','Mars','April','Mai','Juni',
        'Juli','August','September','Oktober','November','Desember'],
        monthNamesShort: ['Jan','Feb','Mar','Apr','Mai','Jun',
        'Jul','Aug','Sep','Okt','Nov','Des'],
		dayNamesShort: ['Søn','Man','Tir','Ons','Tor','Fre','Lør'],
		dayNames: ['Søndag','Mandag','Tirsdag','Onsdag','Torsdag','Fredag','Lørdag'],
		dayNamesMin: ['Sø','Ma','Ti','On','To','Fr','Lø'],
        dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for no",
		adjustTip:"adjustTip for no"};
    // $.datetimepicker.setDefaults($.datetimepicker.regional['no']);
})(jQuery);
/* Nepal initialisation for the jQuery UI date picker plugin. */
/* Written by shuosuo (shuosuo@163.com). */
(function($){
	$.datetimepicker.regional['ne-NP'] = {
		displayLocal:true,
		calendric: 3,
		closeText: 'Close',
		prevText: '&#x3c;Prev Month',
		nextText: 'Next Month&#x3e;',
		prevYearText: '&#x3c;Prev Year',
		nextYearText: 'Next Year&#x3e;',
		currentText: 'आज',
		monthNames: ['Baishākh', 'Jeṭha', 'Asār', 'Sāun', 'Bhadau', 'Asoj' , 'Kartik', 'Mangsir', 'Push', 'Magh', 'Falgun', 'Chaitra'],
		monthNamesShort: ['बैशाख','जेष्ठ','आषाढ़','श्रावण','भाद्र','आश्विन',
		'कार्तिक','मार्ग','पौष','माघ','फाल्गुन','चैत्र'],
		dayNames: ['आइतबार्','सोम्बार्','मङल्बार्','बुधबार्','बिहिबार्','शुक्रबार्','शनिबार्'],
		dayNamesShort: ['आइतबार्','सोम्बार्','मङल्बार्','बुधबार्','बिहिबार्','शुक्रबार्','शुक्रबार्'],
		dayNamesMin: ['Su','Mo','Tu','We','Th','Fr','Sa'],
		okLabel: 'OK',
		cancelLabel: 'Cancel',
		dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 0,
		isRTL: false,
		pickertitle:'नेपाली पात्रो',
		buttonText: 'Open',
		dstConfirmMsg:"जनाइएको समय सामान्य समयसँग मिल्दो छ। के तपाईं डिएसटि समय प्रयोग गर्न चाहनु हुन्छ?",
		adjustTip:"तपाईंले अवैध समय चयन गर्नुभयो । समयलाई स्वत: सही स्थानीय प्रामाणिक समयमा परिवर्तित गरिएको छ । "};
})(jQuery);
/* Polish initialisation for the jQuery UI date picker plugin. */
/* Written by Jacek Wysocki (jacek.wysocki@gmail.com). */
(function($){
	$.datetimepicker.regional['pl'] = {
		closeText: 'Zamknij',
		prevText: '&#x3c;Poprzedni',
		nextText: 'Następny&#x3e;',
		currentText: 'Dziś',
		monthNames: ['Styczeń','Luty','Marzec','Kwiecień','Maj','Czerwiec',
		'Lipiec','Sierpień','Wrzesień','Październik','Listopad','Grudzień'],
		monthNamesShort: ['Sty','Lu','Mar','Kw','Maj','Cze',
		'Lip','Sie','Wrz','Pa','Lis','Gru'],
		dayNames: ['Niedziela','Poniedzialek','Wtorek','Środa','Czwartek','Piątek','Sobota'],
		dayNamesShort: ['Nie','Pn','Wt','Śr','Czw','Pt','So'],
		dayNamesMin: ['N','Pn','Wt','Śr','Cz','Pt','So'],
		dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for pl ",
		adjustTip:"adjustTip for pl"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['pl']);
})(jQuery);
/* Brazilian initialisation for the jQuery UI date picker plugin. */
/* Written by Leonildo Costa Silva (leocsilva@gmail.com). */
(function($){
	$.datetimepicker.regional['pt-BR'] = {
		closeText: 'Fechar',
		prevText: '&#x3c;Anterior',
		nextText: 'Pr&oacute;ximo&#x3e;',
		currentText: 'Hoje',
		monthNames: ['Janeiro','Fevereiro','Mar&ccedil;o','Abril','Maio','Junho',
		'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
		monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun',
		'Jul','Ago','Set','Out','Nov','Dez'],
		dayNames: ['Domingo','Segunda-feira','Ter&ccedil;a-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sabado'],
		dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'],
		dayNamesMin: ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for pt-BR ",
		adjustTip:"adjustTip for pt-BR"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['pt-BR']);
})(jQuery);/*
			 * Romanian initialisation for the jQuery UI date picker plugin.
			 *
			 * Written by Edmond L. (ll_edmond@walla.com) and Ionut G. Stan
			 * (ionut.g.stan@gmail.com)
			 */
(function($){
	$.datetimepicker.regional['ro'] = {
		closeText: 'Închide',
		prevText: '&laquo; Luna precedentă',
		nextText: 'Luna următoare &raquo;',
		currentText: 'Azi',
		monthNames: ['Ianuarie','Februarie','Martie','Aprilie','Mai','Iunie',
		'Iulie','August','Septembrie','Octombrie','Noiembrie','Decembrie'],
		monthNamesShort: ['Ian', 'Feb', 'Mar', 'Apr', 'Mai', 'Iun',
		'Iul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		dayNames: ['Duminică', 'Luni', 'Marţi', 'Miercuri', 'Joi', 'Vineri', 'Sâmbătă'],
		dayNamesShort: ['Dum', 'Lun', 'Mar', 'Mie', 'Joi', 'Vin', 'Sâm'],
		dayNamesMin: ['Du','Lu','Ma','Mi','Jo','Vi','Sâ'],
		dateFormat: 'dd MM yy', dateFormatHeader: 'MM yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for ro ",
		adjustTip:"adjustTip for ro"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ro']);
})(jQuery);
/* Russian (UTF-8) initialisation for the jQuery UI date picker plugin. */
/* Written by Andrew Stromnov (stromnov@gmail.com). */
(function($){
	$.datetimepicker.regional['ru'] = {
		closeText: 'Закрыть',
		prevText: '&#x3c;Пред',
		nextText: 'След&#x3e;',
		currentText: 'Сегодня',
		monthNames: ['Январь','Февраль','Март','Апрель','Май','Июнь',
		'Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'],
		monthNamesShort: ['Янв','Фев','Мар','Апр','Май','Июн',
		'Июл','Авг','Сен','Окт','Ноя','Дек'],
		dayNames: ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'],
		dayNamesShort: ['вск','пнд','втр','срд','чтв','птн','сбт'],
		dayNamesMin: ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for ru ",
		adjustTip:"adjustTip for ru"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['ru']);
})(jQuery);/* Slovak initialisation for the jQuery UI date picker plugin. */
/* Written by Vojtech Rinik (vojto@hmm.sk). */
(function($){
	$.datetimepicker.regional['sk'] = {
		closeText: 'Zavrieť',
		prevText: '&#x3c;Predchádzajúci',
		nextText: 'Nasledujúci&#x3e;',
		currentText: 'Dnes',
		monthNames: ['Január','Február','Marec','Apríl','Máj','Jún',
		'Júl','August','September','Október','November','December'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Máj','Jún',
		'Júl','Aug','Sep','Okt','Nov','Dec'],
		dayNames: ['Nedel\'a','Pondelok','Utorok','Streda','Štvrtok','Piatok','Sobota'],
		dayNamesShort: ['Ned','Pon','Uto','Str','Štv','Pia','Sob'],
		dayNamesMin: ['Ne','Po','Ut','St','Št','Pia','So'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for sk ",
		adjustTip:"adjustTip for sk"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['sk']);
})(jQuery);
/* Slovenian initialisation for the jQuery UI date picker plugin. */
/* Written by Jaka Jancar (jaka@kubje.org). */
/* c = &#x10D;, s = &#x161; z = &#x17E; C = &#x10C; S = &#x160; Z = &#x17D; */
(function($){
	$.datetimepicker.regional['sl'] = {
		closeText: 'Zapri',
		prevText: '&lt;Prej&#x161;nji',
		nextText: 'Naslednji&gt;',
		currentText: 'Trenutni',
		monthNames: ['Januar','Februar','Marec','April','Maj','Junij',
		'Julij','Avgust','September','Oktober','November','December'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Maj','Jun',
		'Jul','Avg','Sep','Okt','Nov','Dec'],
		dayNames: ['Nedelja','Ponedeljek','Torek','Sreda','&#x10C;etrtek','Petek','Sobota'],
		dayNamesShort: ['Ned','Pon','Tor','Sre','&#x10C;et','Pet','Sob'],
		dayNamesMin: ['Ne','Po','To','Sr','&#x10C;e','Pe','So'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for sl ",
		adjustTip:"adjustTip for sl"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['sl']);
})(jQuery);
/* Albanian initialisation for the jQuery UI date picker plugin. */
/* Written by Flakron Bytyqi (flakron@gmail.com). */
(function($){
	$.datetimepicker.regional['sq'] = {
		closeText: 'mbylle',
		prevText: '&#x3c;mbrapa',
		nextText: 'Përpara&#x3e;',
		currentText: 'sot',
		monthNames: ['Janar','Shkurt','Mars','Prill','Maj','Qershor',
		'Korrik','Gusht','Shtator','Tetor','Nëntor','Dhjetor'],
		monthNamesShort: ['Jan','Shk','Mar','Pri','Maj','Qer',
		'Kor','Gus','Sht','Tet','Nën','Dhj'],
		dayNames: ['E Diel','E Hënë','E Martë','E Mërkurë','E Enjte','E Premte','E Shtune'],
		dayNamesShort: ['Di','Hë','Ma','Më','En','Pr','Sh'],
		dayNamesMin: ['Di','Hë','Ma','Më','En','Pr','Sh'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for sq ",
		adjustTip:"adjustTip for sq"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['sq']);
})(jQuery);
/* Serbian i18n for the jQuery UI date picker plugin. */
/* Written by Dejan Dimić. */
(function($){
	$.datetimepicker.regional['sr-SR'] = {
		closeText: 'Zatvori',
		prevText: '&#x3c;',
		nextText: '&#x3e;',
		currentText: 'Danas',
		monthNames: ['Januar','Februar','Mart','April','Maj','Jun',
		'Jul','Avgust','Septembar','Oktobar','Novembar','Decembar'],
		monthNamesShort: ['Jan','Feb','Mar','Apr','Maj','Jun',
		'Jul','Avg','Sep','Okt','Nov','Dec'],
		dayNames: ['Nedelja','Ponedeljak','Utorak','Sreda','Četvrtak','Petak','Subota'],
		dayNamesShort: ['Ned','Pon','Uto','Sre','Čet','Pet','Sub'],
		dayNamesMin: ['Ne','Po','Ut','Sr','Če','Pe','Su'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for sr-SR ",
		adjustTip:"adjustTip for sr-SR"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['sr-SR']);
})(jQuery);
/* Serbian i18n for the jQuery UI date picker plugin. */
/* Written by Dejan Dimić. */
(function($){
	$.datetimepicker.regional['sr'] = {
		closeText: 'Затвори',
		prevText: '&#x3c;',
		nextText: '&#x3e;',
		currentText: 'Данас',
		monthNames: ['Јануар','Фебруар','Март','Април','Мај','Јун',
		'Јул','Август','Септембар','Октобар','Новембар','Децембар'],
		monthNamesShort: ['Јан','Феб','Мар','Апр','Мај','Јун',
		'Јул','Авг','Сеп','Окт','Нов','Дец'],
		dayNames: ['Недеља','Понедељак','Уторак','Среда','Четвртак','Петак','Субота'],
		dayNamesShort: ['Нед','Пон','Уто','Сре','Чет','Пет','Суб'],
		dayNamesMin: ['Не','По','Ут','Ср','Че','Пе','Су'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for sr ",
		adjustTip:"adjustTip for sr"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['sr']);
})(jQuery);
/* Swedish initialisation for the jQuery UI date picker plugin. */
/* Written by Anders Ekdahl ( anders@nomadiz.se). */
(function($){
    $.datetimepicker.regional['sv'] = {
		closeText: 'Stäng',
        prevText: '&laquo;Förra',
		nextText: 'Nästa&raquo;',
		currentText: 'Idag',
        monthNames: ['Januari','Februari','Mars','April','Maj','Juni',
        'Juli','Augusti','September','Oktober','November','December'],
        monthNamesShort: ['Jan','Feb','Mar','Apr','Maj','Jun',
        'Jul','Aug','Sep','Okt','Nov','Dec'],
		dayNamesShort: ['Sön','Mån','Tis','Ons','Tor','Fre','Lör'],
		dayNames: ['Söndag','Måndag','Tisdag','Onsdag','Torsdag','Fredag','Lördag'],
		dayNamesMin: ['Sö','Må','Ti','On','To','Fr','Lö'],
        dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy-mm', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for sv ",
		adjustTip:"adjustTip for sv"};
    // $.datetimepicker.setDefaults($.datetimepicker.regional['sv']);
})(jQuery);
/* Thai initialisation for the jQuery UI date picker plugin. */
/* Written by pipo (pipo@sixhead.com). */
(function($){
	$.datetimepicker.regional['th'] = {
		closeText: 'ปิด',
		prevText: '&laquo;&nbsp;ย้อน',
		nextText: 'ถัดไป&nbsp;&raquo;',
		currentText: 'วันนี้',
		monthNames: ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน',
		'กรกฏาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'],
		monthNamesShort: ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.',
		'ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'],
		dayNames: ['อาทิตย์','จันทร์','อังคาร','พุธ','พฤหัสบดี','ศุกร์','เสาร์'],
		dayNamesShort: ['อา.','จ.','อ.','พ.','พฤ.','ศ.','ส.'],
		dayNamesMin: ['อา.','จ.','อ.','พ.','พฤ.','ศ.','ส.'],
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 0,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for th ",
		adjustTip:"adjustTip for th"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['th']);
})(jQuery);/* Turkish initialisation for the jQuery UI date picker plugin. */
/* Written by Izzet Emre Erkan (kara@karalamalar.net). */
(function($){
	$.datetimepicker.regional['tr'] = {
		closeText: 'kapat',
		prevText: '&#x3c;geri',
		nextText: 'ileri&#x3e',
		currentText: 'bugün',
		monthNames: ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
		'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'],
		monthNamesShort: ['Oca','Şub','Mar','Nis','May','Haz',
		'Tem','Ağu','Eyl','Eki','Kas','Ara'],
		dayNames: ['Pazar','Pazartesi','Salı','Çarşamba','Perşembe','Cuma','Cumartesi'],
		dayNamesShort: ['Pz','Pt','Sa','Ça','Pe','Cu','Ct'],
		dayNamesMin: ['Pz','Pt','Sa','Ça','Pe','Cu','Ct'],
		dateFormat: 'dd.mm.yy', dateFormatHeader: 'mm.yy', firstDay: 1,
		isRTL: false,
		dstConfirmMsg:"confirmMsg for tr ",
		adjustTip:"adjustTip for tr"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['tr']);
})(jQuery);/*
			 * Ukrainian (UTF-8) initialisation for the jQuery UI date picker
			 * plugin.
			 */
/* Written by Maxim Drogobitskiy (maxdao@gmail.com). */
(function($){
	$.datetimepicker.regional['uk'] = {
		clearText: 'Очистити', clearStatus: '',
		closeText: 'Закрити', closeStatus: '',
		prevText: '&#x3c;',  prevStatus: '',
		prevBigText: '&#x3c;&#x3c;', prevBigStatus: '',
		nextText: '&#x3e;', nextStatus: '',
		nextBigText: '&#x3e;&#x3e;', nextBigStatus: '',
		currentText: 'Сьогодні', currentStatus: '',
		monthNames: ['Січень','Лютий','Березень','Квітень','Травень','Червень',
		'Липень','Серпень','Вересень','Жовтень','Листопад','Грудень'],
		monthNamesShort: ['Січ','Лют','Бер','Кві','Тра','Чер',
		'Лип','Сер','Вер','Жов','Лис','Гру'],
		monthStatus: '', yearStatus: '',
		weekHeader: 'Не', weekStatus: '',
		dayNames: ['неділя','понеділок','вівторок','середа','четвер','п’ятниця','субота'],
		dayNamesShort: ['нед','пнд','вів','срд','чтв','птн','сбт'],
		dayNamesMin: ['Нд','Пн','Вт','Ср','Чт','Пт','Сб'],
		dayStatus: 'DD', dateStatus: 'D, M d',
		dateFormat: 'dd/mm/yy', dateFormatHeader: 'mm/yy', firstDay: 1,
		initStatus: '', isRTL: false,
		dstConfirmMsg:"confirmMsg for uk ",
		adjustTip:"adjustTip for uk"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['uk']);
})(jQuery);/* Chinese initialisation for the jQuery UI date picker plugin. */
/* Written by Cloudream (cloudream@gmail.com). */
(function($){
	$.datetimepicker.regional['zh-CN'] = {
		clearText: '清除', clearStatus: '',
		closeText: '关闭',
		prevText: '&#x3c;上个月',
		nextText: '下个月&#x3e;',
		prevYearText: '&#x3c;上一年',
		nextYearText: '下一年&#x3e;',
		currentText: '今天',
		monthNames: ['一月','二月','三月','四月','五月','六月',
		'七月','八月','九月','十月','十一月','十二月'],
		monthNamesShort: ['一','二','三','四','五','六',
		'七','八','九','十','十一','十二'],
		weekHeader:'周',
		dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
		dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'],
		dayNamesMin: ['日','一','二','三','四','五','六'],
		okLabel: '确定',
		cancelLabel: '取消',
		clearLabel: '清空',
		dateFormat: 'yy-mm-dd', dateFormatHeader: 'yy年mm月',
		firstDay: 0,dayInFirstWeek:4,weekstrSeparator: '~',
		year: '年',week: '周',
		isRTL: false,
		buttonText: '日期选择',
		dstConfirmMsg:"指定时间为重复时间，是否使用DST时间？",
		adjustTip:"指定时间为夏令时空白区，已自动完成转换。"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['zh-CN']);
})(jQuery);
/* Chinese initialisation for the jQuery UI date picker plugin. */
/* Written by Ressol (ressol@gmail.com). */
(function($){
	$.datetimepicker.regional['zh-TW'] = {
		closeText: '關閉',
		prevText: '&#x3c;上月',
		nextText: '下月&#x3e;',
		currentText: '今天',
		monthNames: ['一月','二月','三月','四月','五月','六月',
		'七月','八月','九月','十月','十一月','十二月'],
		monthNamesShort: ['一','二','三','四','五','六',
		'七','八','九','十','十一','十二'],
		dayNames: ['星期日','星期一','星期二','星期三','星期四','星期五','星期六'],
		dayNamesShort: ['周日','周一','周二','周三','周四','周五','周六'],
		dayNamesMin: ['日','一','二','三','四','五','六'],
		okLabel: '确定',
		cancelLabel: '取消',
		clearLabel:'清空',
		dateFormat: 'yy/mm/dd', dateFormatHeader: 'yy年mm月', firstDay: 0,
		isRTL: false,
		buttonText: '日期選擇',
		dstConfirmMsg:"confirmMsg for zh-TW ",
		adjustTip:"adjustTip for zh-TW"};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['zh-TW']);
})(jQuery);
/* english initialisation for the jQuery UI date picker plugin. */
/* Written by Ressol (ressol@gmail.com). */
(function($){
	$.datetimepicker.regional['en'] = {
		closeText: 'Close',
		prevText: '&#x3c;Prev Month',
		nextText: 'Next Month&#x3e;',
		prevYearText: '&#x3c;Prev Year',
		nextYearText: 'Next Year&#x3e;',
		currentText: 'Today',
		monthNames: ['January','February','March','April','May','June',
		 			'July','August','September','October','November','December'],
		monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
		weekHeader:'wk',
		dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
		dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
		dayNamesMin: ['Su','Mo','Tu','We','Th','Fr','Sa'],
		dateFormat: 'mm/dd/yy', dateFormatHeader: 'mm/yy',
		firstDay: 0,dayInFirstWeek:1,weekstrSeparator: ' to ',
		isRTL: false,
		buttonText: 'Select Date',
		dstConfirmMsg:"The time specified is the same with the normal time. Do you mean to use the DTS?",
		adjustTip:"You have selected an invalid DST. The time has automatically been changed.",

		digits:['0','1','2','3','4','5','6','7','8','9']};
	// $.datetimepicker.setDefaults($.datetimepicker.regional['en-US']);
})(jQuery);
// 设置全局的语言信息默认为中文
$(function() {

	var $scope = $(document).scope();

	$Page = $scope.$Page;

	// 调用服务
	$Page.contextInited = false;

	// 要放在入口服务中了，下面服务中有读取系统参数修改这里的地方
	$Page.tzDateTime = "yyyy-MM-dd HH:mm:ss";
	$Page.tzDate = "yyyy-MM-dd";
	$Page.contextInfo = $Page.contextInfo || {};

	if (window._ysp_top.tzDateTime)
	{
		$Page.tzDateTime = window._ysp_top.tzDateTime;
		$Page.tzDate = window._ysp_top.tzDate;
		$Page.contextInfo = window._ysp_top.entrenceContxtInfo;
	}
	
	/*//US-20171121180045-2031051954 
	if (sessionStorage.getItem("isOperIdWhitelist")){
		window._ysp_top.isOperIdWhitelist = sessionStorage.getItem("isOperIdWhitelist") || 'N';
	}*/

	/*
	 * AD大整改，将所有调用的服务通过入口即调的服务统一调用
	 * 其返回结果可以直接在功能代码中的任何地方直接使用
	 *
	 * 经过初步评估此服务可用
	 *
	 * 服务的返回结构如下
	 *
	 * header
	 * body
	 * 	--dataDictList  预置查询的字典列表
	 * 	--sysParamList	预置查询的系统参数列表
	 * 	--sysAuthList   预置查询的权限列表
	 *  --i18n  预置查询的国际化相关数据列表
	 *  --context  预置查询的上下文列表
	 *
	 *  禁止在ad-util.js中新增加其他入口即调的方法
	 *  如果有其他全局参数的诉求，请在本服务中添加。
	 *
	 * 	如果有功能中使用相关数据异常，请在页面的init方法中增加对$Page.contextInited的依赖，例如
	 *
	 * <uee:fire init="$Page.contextInited"
		script="$Controller.bes.oc.batchordertrailoffer.init($Gadget, $Get('$Fire'), $Page)"></uee:fire>
	 *
	 * 可以确保当前页面的加载在/adentrenceservice/queryentrencemsg服务调用完成之后
	 *
	 */
	$scope.$Get("$Fire")(
	{
		service : "/adentrenceservice/queryentrencemsg",
		target : "$Page.entrenceBack",
		onafter : function() {
			debugger

			if ($Page.entrenceBack && $Page.entrenceBack.body)
			{
				// --------------- 处理几个字典 ------------------
				$Page.dictList = $Page.entrenceBack.body.dataDictList;

				var certLengths = ($Page.dictList || {}).CertLentghValidateConfig || [];
				$Page.certLengthDicts = {};
				$.each(certLengths,function(i,val){
					$Page.certLengthDicts[val.key] = val.value.replace(/\\\\/g,"\\");
				});

                //前端日志开关判断
                var frontLogDictCfg = $Page.dictList && $Page.dictList["FRONT_LOG_CTRLPARAM"];
                if (frontLogDictCfg && frontLogDictCfg.length > 0) {
                    try {
                        frontLogUtil.checkIsOpenLog(frontLogDictCfg);
                    } catch (e) {
                    }
                }
                
				// --------------- 处理几个系统参数 ------------------

				$Page.sysParamList =
					[
				      $Page.entrenceBack.body.sysParamList["IsNeedCheckIVR"],
				      $Page.entrenceBack.body.sysParamList["60107061880414"],
				      $Page.entrenceBack.body.sysParamList["PercentPrecision"],
				      $Page.entrenceBack.body.sysParamList["GroupBusinessContextPath"],
				      $Page.entrenceBack.body.sysParamList["60108007"],
				      $Page.entrenceBack.body.sysParamList["AGE_NEED_GUARDIAN"],
				      $Page.entrenceBack.body.sysParamList["THINGNET_NUM_REG"],
				      $Page.entrenceBack.body.sysParamList["IoTContextPath"],
				    ]

				// 处理几个系统参数
				$Page.isNeedCheckIVR = $Page.sysParamList[0];

				//  用于判断局点，如NINGXIA、JIANGSU、POLAND
	            $Page.projectVersion = $Page.sysParamList[1];

	            //百分比转换精度，2表示存储100实际1%
	            $Page.percentPrecision = $Page.sysParamList[2] || 2;

	            //集团业务上下文根
	            $Page.GroupBusinessContextPath = $Page.sysParamList[3];

	            //DTS2016101409774  pc增加了系统参数是60108007。例如：如果系统参数是#，那么就是#商品名称#
	            $Page.highLightKeyword = $Page.sysParamList[4];

	            $Page.ageNeedGuardian = $Page.sysParamList[5] || 16;

	            //  用于获取13位物联网号码号段格式匹配正则，如'/^(14400\\d{8})|(14401\\d{8})|(1064\\d{9})$/'
	            $Page.thingNetNumReg = $Page.sysParamList[6];
	            
	            //集团业务上下文根
	            $Page.IoTContextPath = $Page.sysParamList[7];
				// ----------- 处理操作员权限的东西----------------

	            $Page.operatorAuthRightMap = {};

	            if ($Page.entrenceBack.body.sysAuthList["VoyeurSensitiveInfo"] == "Y")
	            {
	            	$Page.operatorAuthRightMap["VoyeurSensitiveInfo"] = true;
	            }
	            else
	            {
	            	$Page.operatorAuthRightMap["VoyeurSensitiveInfo"] = false;
	            }

	            // ---------- 处理上下文的东西----------------------
	            $Page.contextInfo = $Page.entrenceBack.body.context;

	            // ---------- 处理国际化的东西-----------------------
	        	// 多时区
	            // $Page.tzDateTime = "yyyy-MM-dd HH:mm:ss";
	        	// $Page.tzDate = "yyyy-MM-dd";

	            var i18n = $Page.entrenceBack.body["i18n"];

	            $Page.tzDateTime = i18n.tzDateTime;
	            $Page.tzDate = i18n.tzDate;

				window._ysp_top.tzDateTime = i18n.tzDateTime;
				window._ysp_top.tzDate = i18n.tzDate;
				window._ysp_top.entrenceContxtInfo = $Page.contextInfo;

	            $Page.TimeUtil = i18n.time;

	            // 多货币  很可能有问题
	        	$Page.displayPriceInfo = {
	        			currencyName : "元",
	        			currencySymbol : "¥",
	        			precision : 3,
	        			approxPrecision : 1
	        		// 金额进位标识,去掉最后一位
	        		};

				$Page.displayPriceInfo.beId = $Page.contextInfo.operBeId;

				var SMCurrencyMeasurementLangVO = i18n.currency.measurmentVO.SMCurrencyMeasurementLangVO;

				$.each(SMCurrencyMeasurementLangVO,function(i,val){

					if (val["locale"] == $Page.contextInfo.locale)
					{
						$Page.displayPriceInfo.currencyName = val["currencyMeasurementName"];
					}
				});

				$Page.displayPriceInfo.currencySymbol = i18n.currency.beCurrencyVO.currencySymbol;

				$Page.displayPriceInfo.precision = i18n.currency.transRate

				$Page.displayPriceInfo.precision = Math
						.log($Page.displayPriceInfo.precision || 1)
						/ Math.LN10;
				$Page.displayPriceInfo.precision = $Page.displayPriceInfo.precision
						.toFixed(0);

				$Page.displayPriceInfo.approxPrecision = $Page.entrenceBack.body.sysParamList["OC_CASH_APPROX_PRECISION"] || 1;

				$Page.displayPriceInfo.defaultCurrencyId = i18n.currency.beCurrencyVO.currencyId;
			}

			$scope.$Page.contextInited = true;
		}
	}, $scope);

	// 设置初始化发票号cookie MaxAge
	// 不知道是不是有用，暂时不敢删除
	var invoiceNumberCookie = $.cookie("invoiceNumber");
	if (invoiceNumberCookie)
	{
		$.cookie("invoiceNumber", invoiceNumberCookie, {path:'/'});
	}

	// 正数/负数输入框
	$(document).on("keypress", ".keypressInput", function(e) {
		var precision = parseInt($scope.$Page.displayPriceInfo.precision)
				- parseInt($scope.$Page.displayPriceInfo.approxPrecision);
		adutil.inputKeypress($(this), e, new RegExp("^(\-)$|^((\-)?\\d+\\.?(\\d{1," + precision + "})?)$", "ig"));
	});
	$(document).on("click","#popwin_close",function(){
		$(document).find('body').removeAttr("style");
	});
	// 正数输入框
	$(document).on("keypress", ".posKeypressInput", function(e) {
		var precision = parseInt($scope.$Page.displayPriceInfo.precision)
				- parseInt($scope.$Page.displayPriceInfo.approxPrecision);
		adutil.inputKeypress($(this), e, new RegExp("^\\d+\\.?(\\d{1," + precision + "})?$", "ig"));
	});

	// 判断是否为家庭产品
	$scope.isFamilyProd = function(offering) {
		debugger;
		if (offering.isbindOffer == "Y" || offering.isBundled) {
			var subOfferings = offering.ocOfferInfoVA || offering.subOfferings || [];
			// 如果已选产品是家庭网产品包
			for ( var i = 0; i < subOfferings.length; i++) {
				if (subOfferings[i].isbindOffer == "N" || !subOfferings[i].isBundled) {
					var product = subOfferings[i].ocProductInfoVA || subOfferings[i].product;
					product = product || [];
					if (product && product.length > 0) {
						if (product[0].prodType == "JTW"
								|| product[0].prodType == "JTVW" || product[0].prodType == "WPMP"
								|| product[0].prodType == "KSJTW")
						{
							return product[0];
						}
					}
				}
			}
		} else {
			// 如果是单个产品
			var product = offering.ocProductInfoVA || offering.product;
			product = product || [];
			if (product && product.length > 0) {
				if (product[0].prodType == "JTW"
						|| product[0].prodType == "JTVW"
						|| product[0].prodType == "JTGX"  || product[0].prodType == "WPMP"
						|| product[0].prodType == "KSJTW") 
				{
					return product[0];
				}
			}
		}
		return null;
	};

	// 判断是否是旺铺商品
	$scope.isWangPuProd = function(offering) {
		if (offering.isbindOffer == "Y" || offering.isBundled) {
			var subOfferings = offering.ocOfferInfoVA || offering.subOfferings || [];
			// 如果已选产品是家庭网产品包
			for ( var i = 0; i < subOfferings.length; i++) {
				if (subOfferings[i].isbindOffer == "N" || !subOfferings[i].isBundled) {
					var product = subOfferings[i].ocProductInfoVA || subOfferings[i].product;
					product = product || [];
					if (product && product.length > 0) {
						if (product[0].prodType == "WPMP") {
							return product[0];
						}
					}
				}
			}
		} else {
			// 如果是单个产品
			var product = offering.ocProductInfoVA || offering.product;
			product = product || [];
			if (product && product.length > 0) {
				if (product[0].prodType == "WPMP") {
					return product[0];
				}
			}
		}
		return null;
	};

	// 判断是否为家庭产品，个人开户使用
	$scope.fillFamilyProd = function(offering) {
		var prodTypeList = offering.prodTypeList || [];
		if (prodTypeList && prodTypeList.length > 0) {
			for ( var i = 0; i < prodTypeList.length; i++) {
				if(prodTypeList[i] == "JTW"
					|| prodTypeList[i] == "JTVW") {
					var prodId = "";
					if(offering.productList) {
						if(offering.productList.length >= i) {
							prodId = offering.productList[i];
						} else {
							prodId = offering.productList[0];
						}
					}
					var product = {
						prodType : prodTypeList[i],
						productId : prodId
					};
					return product;
				}
			}
		}
		return null;
	};
});

// 集成OC菜单的源系统
var tabSet = _ysp_top.TabSet || {};
var portalName = tabSet.portalName || {};
var ocActionSource = portalName == "BES" ? "SM" : "iCRM";// iCRM或SM，空表示从menu.html打开。
// var ocActionSource = "SM";

/** **********SM start********* */
window.onmessage = function(e) {

	e = e || window.event;
	var data;
	if (navigator.userAgent.indexOf("MSIE") != -1) {
		data = JSON.parse(e.data);
	} else {
		data = e.data;
	}

	var operation = data.operation;
	if (undefined == operation) {
		return;
	}

	if ("On_Tab_Show" == operation) {
		$BES.$Portal.tabpanel.onShowTab();
	} else if ("On_Tab_Close" == operation) {
		$BES.$Portal.tabpanel.onCloseTab();
	}
};

window.$BES = window.$BES || {};

$BES.$Portal = {
	tabpanel : {}
};

$BES.$Portal.tabpanel = jQuery.extend($BES.$Portal.tabpanel, {

	/*
	 * 使用方式  $BES.$Portal.tabpanel.getTabItem()
	 * 返回在SM portal中打开的当前TAB页签的相关信息
	 *
	 * 返回结果结构如下
	 *  {
	 *  "key":"60131_oclogintemp",
	 *  "title":"360-Degree Custom View",
	 *  "url":"https://10.120.237.159:18090/oc/resource.root/bes/ad/person/telecomm/osbasi…er.html&menuid=60131_oclogintemp&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 *  }
	 *
	 * 说明
	 * 此方法只有在SM portal框架之下才有效果
	 * 如果不是在SM框架（例如客服系统），调用$BES.$Portal.tabpanel.getTabItem()返回结果是 undefined
	 * 因此获取相关信息的时候，一定要注意判空
	 *
	 */
	getTabItem : function() {
		if (window.location.protocol == "http:" || window.location.protocol == "https:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				try {
					return _ysp_top.TabSet.getTabItem();
				} catch (e) {
				}
			}
		}
	},

	/*
	 * 使用方式  $BES.$Portal.tabpanel.getAllTabItems()
	 *
	 * 返回在SM portal中打开的全部TAB页签的相关信息
	 *
	 * 返回结果结构如下
	 *
	 * [
	 * 		{
	 * 			"key":"6010100090012",
	 * 			"title":"My Workbench",
	 * 			"url":"https://10.120.237.159:18090/oc/resource.root/bes/sm/login/pages/workbench-cz.html?menuid=6010100090012&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 * 		},
	 * 		{
	 * 			"key":"sitemap",
	 * 			"title":"Sitemap",
	 * 			"url":"https://10.120.237.159:18090/oc/resource.root/bes/sm/login/sitemap.html?menuid=sitemap&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 * 		},
	 * 		{
	 * 			"key":"60131_oclogintemp",
	 * 			"title":"360-Degree Custom View",
	 * 			"url":"https://10.120.237.159:18090/oc/resource.root/bes/ad/person/telecomm/osbasi…er.html&menuid=60131_oclogintemp&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 * 		}
	 * ]
	 *
	 * 说明
	 * 此方法只有在SM portal框架之下才有效果
	 * 如果不是在SM框架（例如客服系统），调用$BES.$Portal.tabpanel.getAllTabItems()返回结果是 undefined
	 * 因此获取相关信息的时候，一定要注意判空
	 *
	 */
	getAllTabItems : function() {
		if (window.location.protocol == "http:" || window.location.protocol == "https:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				return _ysp_top.TabSet.getAllTabItems();
			}
		}
	},

	/*
	 * 使用方式  ：$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp")
	 *
	 * 执行效果为，关闭key值为 60131_oclogintemp 的Tab页面
	 *
	 * 如果不传入key值，会默认关闭当前Tab页面
	 *
	 * 说明
	 * 此方法只有在SM portal框架之下才有效果
	 * 在非SM portal框架下执行，返回结果是 undefined
	 *
	 */
	// close tab
	closeTabItem : function(tabId) {

		// debugger;

		if (window.location.protocol == "http:" || window.location.protocol == "https:") {
			if (_ysp_top.TabSet && _ysp_top.TabSet.portalName){
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.closeTabItem(tabId);
				} else {
					_ysp_top.TabSet.prototype.removeTabByCode(tabId);
				}
			}
		} else {
			if (_ysp_top.TabSet){
				_ysp_top.TabSet.closeTabItem(tabId);
			}
		}
	},

	/*
	 * 使用方式  ：$BES.$Portal.tabpanel.closeAllTabItem()
	 *
	 * 执行效果为关闭SM portal 中打开的全部Tab页
	 *
	 * 说明
	 * 此方法只有在SM portal框架之下才有效果
	 * 在非SM portal框架下执行，返回结果是 undefined
	 */
	// close all tab
	closeAllTabItem : function() {
		debugger;
		if (window.location.protocol == "http:" || window.location.protocol == "https:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				_ysp_top.TabSet.closeAllTabItem();
			}
		} else {
			_ysp_top.TabSet.closeAllTabItem();
		}
	},

	/*
	 * 使用方式  ：$BES.$Portal.tabpanel.closeAllTabItemExceptSelf()
	 *
	 * 执行效果为关闭SM portal 中非当前Tab页
	 *
	 * 说明
	 * 此方法只有在SM portal框架之下才有效果
	 * 在非SM portal框架下执行，返回结果是 undefined
	 *
	 */
	// close all tab except one tab
	closeAllTabItemExceptSelf : function(tabId) {
		if (window.location.protocol == "http:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				_ysp_top.TabSet.closeAllTabItemExceptOne(tabId);
			}
		} else {
			_ysp_top.TabSet.closeAllTabItemExceptSelf(tabId);
		}
	},

	/*
	 * 使用方式 ：
	 *
	 * var  item = {
                    "title" : "mytitle",
                    "url" : "resource.root/bes/ad/html/bes.oc.index.reserveorder.base.business.html",
                    "id" : "myid"
                };

       $BES.$Portal.tabpanel.createTabItem(item);

       	使用效果：在SM portal中新开一个Tab页，地址类似为
       	https://10.120.237.159:18090/oc/resource.root/bes/ad/html/bes.oc.index.reserveorder.base.business.html

       	tab标题为：mytitle
       	tab的key为myid

		说明
	 	此方法只有在SM portal框架之下才有效果
	 	在非SM portal框架下执行，返回结果是 undefined

	 */
	// create tab
	createTabItem : function(item) {
		if (window.location.protocol == "http:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				_ysp_top.TabSet.createTabItem(item);
			} else {
				_ysp_top.TabSet.appendTab(item.id, item.title, item.url);
			}
		} else {
			_ysp_top.TabSet.createTabItem(item);
		}
	},

	/*
	 *  使用方式：
	 *  $BES.$Portal.tabpanel.createTabItemByConf("myid", "mytitle",
	 *  "resource.root/bes/ad/html/bes.oc.index.reserveorder.base.business.html")
	 *  一般用于集成第三方页面的时候打开
	 *
	 *  可以参考江苏个人统一视图中打开营销工作台的代码
	 *
	 *  var urlStr = window.location.protocol + "//" + window.location.host + "/ngrecmaster/custsvc/business.action?BMEBusiness=rec.salesconsole";
		window.$BES.$Portal.tabpanel
			.createTabItemByConf(
				"60131workbench",
				$UEE.i18n("ad.person.title.easyCRM"),//"营销工作台",
				urlStr,
				"workbench");
	 *
	 *
	 */
	createTabItemByConf : function(id, title, url, pageid, httpsFlag) {
		if (window.location.protocol == "http:" || window.location.protocol == "https:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {

				debugger;
				_ysp_top.TabSet.createTabItemByConf(id, title, url, pageid,
						httpsFlag);
			} else {
				_ysp_top.TabSet.appendTab(id, title, url);
			}
		} else {
			_ysp_top.TabSet.createTabItemByConf(id, title, url, pageid, httpsFlag);
		}
	},

	/*
	 *  使用方式：$BES.$Portal.tabpanel.showTabItem("60131319")
	 *
	 *  功能效果：在SM portal中根据tabId使得指定Tab页获得焦点，也就是Tab页签切换
	 *
	 *  例如，执行命令$BES.$Portal.tabpanel.getAllTabItems()
	 *
	 * 返回结果结构如下
	 *
	 * [
	 * 		{
	 * 			"key":"6010100090012",
	 * 			"title":"My Workbench",
	 * 			"url":"https://10.120.237.159:18090/oc/resource.root/bes/sm/login/pages/workbench-cz.html?menuid=6010100090012&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 * 		},
	 * 		{
	 * 			"key":"sitemap",
	 * 			"title":"Sitemap",
	 * 			"url":"https://10.120.237.159:18090/oc/resource.root/bes/sm/login/sitemap.html?menuid=sitemap&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 * 		},
	 * 		{
	 * 			"key":"60131_oclogintemp",
	 * 			"title":"360-Degree Custom View",
	 * 			"url":"https://10.120.237.159:18090/oc/resource.root/bes/ad/person/telecomm/osbasi…er.html&menuid=60131_oclogintemp&build=8.2.10.2.1025-SNAPSHOT-201702212145"
	 * 		}
	 * ]
	 *
	 * 如果当前打开的窗口是360-Degree Custom View
	 *
	 * 执行命令$BES.$Portal.tabpanel.showTabItem("sitemap")
	 *
	 * 就可以让当前页面的光标定位到Sitemap中。
	 *
		说明
	 	此方法只有在SM portal框架之下才有效果
	 	在非SM portal框架下执行，执行会报错，使用的时候需要先判断(_ysp_top.TabSet||{}).portalName是否存在
	 */
	showTabItem : function(tabId) {
		if (window.location.protocol == "http:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				_ysp_top.TabSet.showTabItem(tabId);
			}
		} else {
			_ysp_top.TabSet.showTabItem(tabId);
		}
	},

	/*
	 * 使用方式 ：  $BES.$Portal.tabpanel.addShortCut("myid","mytitle","resource.root/bes/ad/html/bes.oc.index.reserveorder.base.business.html")
	 *
	 * 在SM工作台增加快捷按钮，AD开发一般用不到
	 */
	addShortCut : function(menuId, menuName, menuUrl, menuImg, httpsFlag) {
		if (window.location.protocol == "http:") {
			if ("BES" == (_ysp_top.TabSet||{}).portalName) {
				_ysp_top.TabSet.addShortCut(menuId, menuName, menuUrl, menuImg,
						httpsFlag);
			}
		} else {
			_ysp_top.TabSet.addShortCut(menuId, menuName, menuUrl, menuImg, httpsFlag);
		}
	},

	onShowTab : function() {
	},

	onCloseTab : function() {
	},

	init : function() {
		if (navigator.userAgent.indexOf("MSIE") != -1) {
			window.attachEvent('onmessage', onmessage);
		} else {
			window.addEventListener('message', onmessage, false);
		}
	}
});
/** *********** SM end******** */

/**
 * 哎，这是之前一直延续下来的关闭tab页的方法，不建议再使用了
 * 想统一整改了，但是发现用的地放太多了，根本整改不动
 * 就留着吧 建议使用$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp")方法
 * @param tabid
 */
function closePortalTab(tabid) {
    if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist(tabid)) {
        if (_ysp_top.window.$BES && _ysp_top.window.$BES.$Portal
            && _ysp_top.window.$BES.$Portal.tabpanel) {
            _ysp_top.window.$BES.$Portal.tabpanel.closeTabItem(tabid);
        }
    }
}


/** *****iCRM start*********** */
/*
 * 添加新用户接口  需要迁移走
 */
Container_newUser = function(id, custType, name, contentId, city, grade, type,
		state, cardType, cardNo, servNo, region, custname, custlevel,
		custproduct, certype, certno, linkname, linkphone, linkaddress, email,
		creditlevel, currstatus, custmanager, brandName, balance, loginName,
		subsAdditionalInfo) {
	/*
	 * alert("servNo"+servNo); if(_ysp_top.publicObject) { alert("publicOjbect");
	 * alert(_ysp_top.publicObject); }
	 */
	var container = _ysp_top.publicObject["container"];

	// alert("container"+container);
	// 先判断该用户是否已经登录，如果已经登陆提示操作员切换到该用户视图
	var tmpArray = container.customers;
	for ( var tmp in tmpArray) {
		if (tmpArray[tmp].id == id) {
			alert("\u8BE5\u7528\u6237\u5DF2\u7ECF\u767B\u5F55\uFF0C\u8BF7\u5207\u6362\u7528\u6237\u540E\u8FDB\u884C\u64CD\u4F5C");
			var tabCode = "valida";
			var oTab = _ysp_top.publicObject["mainTab"];
			oTab.removeTabByCode(tabCode);
			return false;
		}
	}
	// modify begin by s00227425 2014-08-21 V200R003C14LG0801_EHUB
	// OR_HUB_201404_1329 一线提速- 关键业务增加星级服务判断和显示
	// 新用户登录时，清空购物车数量
	if (typeof (_ysp_top.refreshBuyBus) == 'function') {
		_ysp_top.refreshBuyBus('+', 0, true);
	}

	container.add(id, name, contentId, city, grade, type, state, cardType,
			cardNo, servNo, region, custname, custlevel, custproduct, certype,
			certno, linkname, linkphone, linkaddress, email, creditlevel,
			currstatus, custmanager, null, custType, loginName);

	// 左角添加用户记录
	WorkArea_addUser(id, name);

	if (typeof (_ysp_top.refreshClientInfo) == 'function') {
		if (subsAdditionalInfo && subsAdditionalInfo instanceof Object) {
			_ysp_top.refreshClientInfo(1, name, servNo, certno, brandName, balance,
					subsAdditionalInfo);
		} else {
			_ysp_top.refreshClientInfo(1, name, servNo, certno, brandName, balance);
		}
	}
	// modify end by 2014-08-21 V200R003C14LG0801_EHUB OR_HUB_201404_1329 一线提速-
	// 关键业务增加星级服务判断和显示

	container.evalAfterNewUserEvent();
	return true;
};
/*
 * 系统添加新的user  需要迁移走
 */
WorkArea_addUser = function(id, name) {
	var workArea = _ysp_top.publicObject["workArea"];
	if (workArea && workArea.add(id, name)) {
		var customerArea = _ysp_top.publicObject["customerArea"];
		workArea.get(id).htmlObj = customercloseTabItemArea.doAddRowWithInnerHTML(
				"customerArea",
				"<div align='absmiddle' nowrap style='cursor:hand;width:120;overflow:hidden;'>"
						+ name + "&nbsp;" + id + "</div>", id);
		customerArea.focusUser(id);
	}
};

/*
 * ICRM相关 需要迁移走
 */
Close_tabSet = function() {
	debugger;
	var isCSP = $.cookie("bsacKF");
	if (null != isCSP && "NGCRM_CSP" == isCSP)
	{
		var TabSet = _ysp_top.publicObject["mainTab"];
		TabSet.closeCurrentTab();
	}
	if ("SM" == ocActionSource) {
		window.$BES.$Portal.tabpanel.closeTabItem();
	} else {
		//window.close();
		//ICRM系统关闭Tab页的方法，window.close()不起作用
		//var TabSet = _ysp_top.publicObject["mainTab"];
		//TabSet.closeCurrentTab();
		//新已开
		_ysp_top.window.close("mainTab");
	}
};

Refresh_puView = function() {
	window.location.reload();
};

/** *****iCRM end*********** */

//判断数组元素是否存在，存在返回true，不存在返回false
Array.prototype.contain = function(elt) {
    var index;
    for (index in this) {
    	if (angular.equals(this[index], elt))
            return true;
    }
    return false;
};

//数组元素存在时删除数组中的相同元素，反之添加元素
Array.prototype.toggle = function(elt) {
    var index;
    for (index in this) {
    	if (this.contain(elt)){
            this.splice(index, 1);
            return;
    	}
    }
    
    this.push(elt)
};

// 给string增加len()方法计算string字节数，一个字符算3个字符，推荐的使用方式
String.prototype.len = function() {
	return this.replace(/[^\x00-\xff]/g, "xx").length;
};

// 给string增加byteLength()方法，同样是计算string字节数，一个字符算3个字符，推荐使用len()替换，计划要全量刷掉
String.prototype.byteLength = function() {
	var byteLen = 0, len = this.length;
	if (!this)
		return 0;
	for ( var i = 0; i < len; i++) {
		byteLen += this.charCodeAt(i) > 255 ? 2 : 1;
	}
	return byteLen;
};

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S") ==> 2006-7-2 8:9:4.18
Date.prototype.Format = function(fmt) {
	var o = {
		"M+" : this.getMonth() + 1, // 月份
		"d+" : this.getDate(), // 日
		"D+" : this.getDate(), // 日
		"h+" : this.getHours(), // 小时
		"H+" : this.getHours(), // 小时
		"m+" : this.getMinutes(), // 分
		"s+" : this.getSeconds(), // 秒
		"q+" : Math.floor((this.getMonth() + 3) / 3), // 季度
		"S" : this.getMilliseconds()
	// 毫秒
	};
	if (/(y+)/.test(fmt) || /(Y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "")
				.substr(4 - RegExp.$1.length));
	for ( var k in o) {
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k])
					: (("00" + o[k]).substr(("" + o[k]).length)));
	}
	return fmt;
};

// 二代身份证证件类型
var ICCARD2 = "IdCard";
var ICCARD2_FRONT = "1";
var ICCARD2_BACK = "10";
var ICCARD2_ALL = "11";
var UNSUPPORTED = "UNSUPPORTED";
// 江苏移动测试
var WATERMARK = $UEE.i18n("ad.person.message.JSYDCS");
// 证件信息是否可靠
var isInfoCredible = true;
var useMultiCardReader = true;

var CERT_IMAGE_ON_CLIENT_BASE_PATH = "C:\\temp\\certifications\\";
var CERT_IMAGE_IN_EINVOICE_TAG = "CERTIFICATIONSIMAGES";
var CERT_IMAGE_ON_CLIENT_BASE_FOLDER = "C:\\temp\\certifications";
var REC_NUMBER_WITHOUT_AUTH = "00000000000";

/**
 * 使用控件读取证件 return 证件信息
 *
 * @param kind
 *            性质 serv：本人；delegate：代办人
 * @remark modify w00187892 2013-05-27 R003C13LG0501 OR_JS_201305_437 增加kind参数
 */
function readCardFromOcx(certificateType, kind, multiCardReaderOCX,
		bossICCardOCX, $UI, $Page) {
	debugger;
	/*
	 * $Page.servcard = null; $Page.delegcard = null;
	 */

	window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};
	if ("serv" == kind) {
		$.cookie('besservcard', "");
		$.cookie('besdelegcard', "");
		window._ysp_top.EinvoiceIdCardInfo.besservcard = null;
	}
	if ("delegate" == kind) {
		$.cookie('besdelegcard', "");
		window._ysp_top.EinvoiceIdCardInfo.besdelegcard = null;
	}
	if ("newserv" == kind) {
		$.cookie('besnewservcard', "");
		window._ysp_top.EinvoiceIdCardInfo.besnewservcard = null;
	}
	if ("newdelegate" == kind) {
		$.cookie('besnewdelegcard', "");
		window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = null;
	}

	// 1 如果特性参数开启，使用多功能设备读卡 --%>
	var resultReadCardOcx = "";
	var deviceType = "";
	/**
	if (useMultiCardReader) {
		var cardType = certificateType;

		// <%-- 1.1 多功能设备读卡成功，直接返回 --%>
		// var resultReadCardFromMultiOcx = readCardFromMultiOcx($Page,
		// cardType, kind, $UI, multiCardReaderOCX);
		// if (resultReadCardFromMultiOcx)
		// {
		// return resultReadCardFromMultiOcx;
		// }
		resultReadCardOcx = readCardFromMultiOcx($Page, cardType, kind, $UI,
				multiCardReaderOCX);
		if (ICCARD2 != cardType) {
			return "";
		}
		// <%-- 1.2 多功能设备读卡失败，使用单功能设备读卡 --%>
		// return readCardFromSimpleOcx($Page, kind, cardType, $UI,
		// bossICCardOCX);
		if (!resultReadCardOcx) {
			resultReadCardOcx = readCardFromSimpleOcx($Page, kind, cardType,
					$UI, bossICCardOCX);
		}
	}
	// <%-- 2 特性参数未开启，使用单功能读取 --%>
	else {
		// return readCardFromSimpleOcx($Page, kind, certificateType, $UI,
		// bossICCardOCX);
		resultReadCardOcx = readCardFromSimpleOcx($Page, kind, certificateType,
				$UI, bossICCardOCX);
	}
	// 读到信息后，不需要提示
	// if(resultReadCardOcx) {
	// $UI.msgbox.info("提示", "读取证件信息成功。");
	// }
	**/

	var cardType = certificateType;
	if (ICCARD2 == cardType || 'IdCardEx' == cardType
     || 'IdCardGA' == cardType || 'IdCardTW' == cardType)
	{
		resultReadCardOcx = readCardFromSimpleOcx($Page, kind, cardType,
				$UI, bossICCardOCX);
		deviceType = "AloneDevice";

		if (!resultReadCardOcx) {
			resultReadCardOcx = readCardFromMultiOcx($Page, cardType, kind, $UI,
					multiCardReaderOCX);
			deviceType = "MultiDevice";
		}
		
		if (!resultReadCardOcx && 'IdCardEx' == cardType) {
		    //神思二代身份证
	        if (!SDRdCardExOCXObj) {
	            $('body').append("<object classid=\"CLSID:F1317711-6BDE-4658-ABAA-39E31D3704D3\" id=\"SDRdCardExOCX\" width=\'0\' height=\'0\'></object>");
	            SDRdCardExOCXObj = document.getElementById("SDRdCardExOCX");
	        }
	        resultReadCardOcx = readCardFromSimpleOcx($Page, kind, cardType,
	                $UI, SDRdCardExOCXObj);
		}
	}
	else
	{
		resultReadCardOcx = readCardFromMultiOcx($Page, cardType, kind, $UI,
				multiCardReaderOCX);
		deviceType = "MultiDevice";
	}

	if (!resultReadCardOcx) {
		
		//单功能设备读取二代证异常。未读到数据！
		//$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SingleFunctionalDeviceFailedReadIDCard"));
		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.informationCARD"));
		return;
	}

    // 江苏定制需求，增加二代身份证失效时间校验
    if ('JIANGSU' === $Page.projectVersion) {

        var endDate = resultReadCardOcx.endDate;

        if (endDate && endDate.indexOf('-') > 0) {
            endDate = endDate.replace(/-/g, '/');
        }

        if ((new Date(endDate)).getTime() < $Page.TimeUtil.nowDate) {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.CEDSFZJYGQSXJYSBQCSYXZJJXBL"));
            return "";
        }
    }

	$Page.lastIdCardInfo = {
		cardNo: resultReadCardOcx.cardNo
	};
	
	if ($(document).scope().recDeviceType == 'Y') {
	    $Page.lastIdCardInfo.deviceType = deviceType;
	}
	return resultReadCardOcx;
}

/**
 * 转换民族信息
 */
function transRaceStr($Page, racestr) {

	var raceListData = $Page.raceListData || getRaceList();

	if (raceListData && raceListData.length > 0) {
		for ( var i = 0; i < raceListData.length; i++) {
			var raceObj = raceListData[i];
			if (raceObj.value.indexOf(racestr) > -1) {
				return raceObj.key;
			}
		}
	}
	return '0';
}

/**
 * 简单设备读取证件信息
 *
 * @param kind
 *            性质 serv：本人；delegate：代办人
 * @remark modify w00187892 2013-05-27 R003C13LG0501 OR_JS_201305_437 增加kind参数
 *         short InitMachine(); 返回1正常，其他失败 BSTR GetTextInfo();
 *         返回身份证的文字信息,字串格式为：身份证号码|姓名|地址|性别|证件生效日期|证件失效日期 性别：1－－男 0－－女
 *         日期格式：yyyy-mm-dd BSTR GetImage(); 返回生成的图片的全路径文件名 short PrintImage();
 *         返回1正常，其他失败 short CloseMachine(); 返回1正常，其他失败 void SetTest();
 *         将控件设置为测试状态，上面的接口不连接硬件，返回测试信息
 */
function readCardFromSimpleOcx($Page, kind, cardType, $UI, bossICCardOCX) {
	debugger;

	try {
		// <%-- 1.读卡 --%>
		var obj = $("#" + bossICCardOCX)[0];
		var isInit = false;
		obj.Flag = 0;
		var rst = "";

		// DTS2016080308374 在读取之前，先清掉上一个用户的头像
		try {
		    var fso = new ActiveXObject("Scripting.FileSystemObject");
		    var tmpfolder = fso.GetSpecialFolder(2);
			if ('SHANDONG' == $Page.projectVersion) {
		     var fzp = fso.GetFile(tmpfolder.Path+"//zp.jpg");
		     fzp.Delete();
			 }
			 var f = fso.GetFile(tmpfolder.Path+"//image.bmp");
		     f.Delete();

		} catch (e) {
		}

		try {
			var loginTicket = $Page.SessionID;
			rst = obj.ReadCard(loginTicket);
			if(null == obj.CardNo() || "" == obj.CardNo())
			{
				// DTS2015120600725 add by xiaoyan没有读到数据的时候但是也没有报错，再读一遍
				rst = obj.ReadCard();
			}
		} catch (e) {
		    if('ReadCard' in obj)
		    {
		        rst = obj.ReadCard();
		    }
		    else
		    {
		        return readCardFromBossICCardOCX($Page, kind, cardType, $UI);
		    }
		}

		//外国人证件读取，适配不同厂商的读卡器，减少外围改动
		if ('IdCardEx' == cardType) {
	        obj = adaptToSimpleOcx(obj);
		}
		
		if(null == obj.CardNo() || "" == obj.CardNo()){
			return "";
		}

		var cardInfo2Cookie = {
			"cardNo" : "",
			"name" : "",
			"sex" : "",
			"nation" : "",
			"birth" : "",
			"address" : "",
			"police" : "",
			"effectDate" : "",
			"endDate" : ""
		};
		// 创建pdf时需要传的证件信息 字符串,若能读到
		// 字符串结构为"IdCard|身份证号码|姓名|男女性别|民族|19700101生日|住址|公安局|2009.01.24-2029.01.24有效期"
		var cardInfo2CookieStr = "";

		// <%-- 2.设置返回信息 --%>
		var tempiccardInfo = new Object();
		tempiccardInfo = new Object();
		// <%-- 证件号码 --%>
		tempiccardInfo.cardNo = obj.CardNo();
		cardInfo2Cookie.cardNo = obj.CardNo();
		// <%-- 姓名 --%>
		tempiccardInfo.name = obj.NameL();
		cardInfo2Cookie.name = obj.NameL();
		// <%-- 地址 --%>
		tempiccardInfo.address = obj.Address();
		cardInfo2Cookie.address = obj.Address();
		// <%-- 性别(1.男;0.女) --%>
		tempiccardInfo.sex = obj.Sex();

		// <%-- 性别(1.男;2.女) for bes --%>
		if (tempiccardInfo.sex == "0") {
			//tempiccardInfo.sex = "2"; 2015-11-28 DTSDTS2015112806772
			cardInfo2Cookie.sex = "女";
		} else {
			cardInfo2Cookie.sex = "男";
		}

		// <%-- 生效日期(yyyymmdd) --%>
		var strEffectDate = obj.ActivityLFrom();
		if (strEffectDate && strEffectDate.length && strEffectDate.length >= 8) {
			tempiccardInfo.effectDate = strEffectDate.substr(0, 4) + "/"
					+ strEffectDate.substr(4, 2) + "/"
					+ strEffectDate.substr(6, 2);
			cardInfo2Cookie.effectDate = tempiccardInfo.effectDate.replace(
					new RegExp('-', "gm"), ".");
		}
		// <%-- 失效日期(yyyymmdd-->yyyy-mm-dd) --%>
		var strEndDate = obj.ActivityLTo();
		if (strEndDate && strEndDate.length && strEndDate.length >= 8 && $.isNumeric(strEndDate.substr(0, 8))) {
			tempiccardInfo.endDate = strEndDate.substr(0, 4) + "/"
					+ strEndDate.substr(4, 2) + "/" + strEndDate.substr(6, 2);
			cardInfo2Cookie.endDate = tempiccardInfo.endDate.replace(
					new RegExp('-', "gm"), ".");
		}else{
			strEndDate = "20990101";
			tempiccardInfo.endDate = "2099/01/01";
			cardInfo2Cookie.endDate = "2099/01/01";
		}
		// <%-- 证件类型 --%>
		tempiccardInfo.certType = cardType;
		// <%-- 证件信息是否可靠 --%>
		tempiccardInfo.isInfoCredible = isInfoCredible;

		// <%-- 民族，例：“汉” --%>
		tempiccardInfo.nation = obj.NationL();
		cardInfo2Cookie.nation = obj.NationL();

		// 生日和签发机构
		cardInfo2Cookie.birth = obj.CardNo().substring(6, 14);
		cardInfo2Cookie.police = obj.police();

		if (tempiccardInfo.nation && '' != tempiccardInfo.nation) {
			tempiccardInfo.nation = transRaceStr($Page, tempiccardInfo.nation);
		} else {
			tempiccardInfo.nation = '0';
		}

		var cardInfo2CookieStr = cardType + "|" + cardInfo2Cookie.cardNo + "|"
				+ cardInfo2Cookie.name + "|" + cardInfo2Cookie.sex + "|"
				+ cardInfo2Cookie.nation + "|" + cardInfo2Cookie.birth + "|"
				+ cardInfo2Cookie.address + "|" + cardInfo2Cookie.police + "|"
				+ cardInfo2Cookie.effectDate + "-" + cardInfo2Cookie.endDate;

		//wwx230437
		var HWUtilOCXObj = document.getElementById("HWUtilOCX") || document.getElementById("HWUtilOCXS");
		if (!HWUtilOCXObj)
		{
			$('body').append("<object classid=\"CLSID:0731C2E2-0FD4-41A0-9899-37BA8F8518D5\" id=\"HWUtilOCX\" width=\'0\' height=\'0\'></object>");
			HWUtilOCXObj = document.getElementById("HWUtilOCX");
		}

		window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};

		if (tempiccardInfo.cardNo && tempiccardInfo.cardNo != "" && (HWUtilOCXObj))
		{
			try{
			    var fso = new ActiveXObject("Scripting.FileSystemObject");
				var tmpfolder = fso.GetSpecialFolder(2);
                if ('SHANDONG' == $Page.projectVersion) {
					var path = obj.PhotoPath();
					f = fso.GetFile(path);
					//f = fso.GetFile(tmpfolder.Path + "//zp.jpg");
					f.Copy(tmpfolder.Path+"//image.bmp");
				}
					var bmpFile = "//image.bmp";



				//人证比对
				var pathTemp = tmpfolder.Path + bmpFile;
				var $scope = $(document).scope();
				$Page = $scope.$Page;
				$Page.realNameIdImg  = getBase64OfImage(pathTemp);

				f = fso.GetFile(tmpfolder.Path + bmpFile);

				//过户时需要保存户主、经办人、过户户主、经办人
				if (kind == 'serv') {
					f.Copy(tmpfolder.Path+"//servimage.jpg");
					$.cookie('besservcard', cardInfo2CookieStr);
					window._ysp_top.EinvoiceIdCardInfo.besservcard = cardInfo2CookieStr;
				}
				else if (kind == 'newserv'){
					f.Copy(tmpfolder.Path + "//newservimge.jpg");
					$.cookie('besnewservcard', cardInfo2CookieStr);
					window._ysp_top.EinvoiceIdCardInfo.besnewservcard = cardInfo2CookieStr;
				}
				else if (kind == 'delegate'){
					f.Copy(tmpfolder.Path + "//delegimge.jpg");
					$.cookie('besdelegcard', cardInfo2CookieStr);
					window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
				}
				else if (kind == 'newdelegate'){
					f.Copy(tmpfolder.Path + "//newdelegimge.jpg");
					$.cookie('besnewdelegcard', cardInfo2CookieStr);
					window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = cardInfo2CookieStr;
				}
				else {
					f.Copy(tmpfolder.Path+"//delegimge.jpg");
					$.cookie('besdelegcard', cardInfo2CookieStr);
					window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
				}

            	window.singleFunctionCardReaderId = obj || window.singleFunctionCardReaderId;

				if ('SHANDONG' == $Page.projectVersion) {
					showIDImg(pathTemp + "?version=" + Math.random(), kind);
				}
				else
				{
					var combinePath = combineIDCard(window.singleFunctionCardReaderId, tmpfolder, kind, cardType);
					addWatermarkText(combinePath);
					showIDImg(combinePath + "?version=" + Math.random(), kind);
				}

            }
            catch (e)
            {
            }

		}

		try {
			tempiccardInfo.iccardkey = obj.Key();
		} catch (e) {
			tempiccardInfo.iccardkey = '';
		}
		
		try {
			tempiccardInfo.ocxname = obj.OcxName();
		} catch (e) {
			tempiccardInfo.ocxname = '';
		}
		
		try {
			tempiccardInfo.ocxversion = obj.OcxVersion();
		} catch (e) {
			tempiccardInfo.ocxversion = '';
		}

		var $scope = $(document).scope();
		$scope
				.$Get("$Fire")
				(
						{
							service : "/recordcontrolinformationserviceboservice/recordcontrolinformation",
							params : {
								body : {
									ocxVersion : tempiccardInfo.ocxversion,
									ocxName : tempiccardInfo.ocxname
								}
							}
						}, $scope);
		// <%-- 3.展示文字信息 --%>
		return tempiccardInfo;
	}
	// <%-- 异常情况全部反馈，提供定位信息 --%>
	catch (e) {
		/*
		 * $UI.msgbox.info("提示", "单功能设备读取二代证异常," + "name:"+ e.name +
		 * ",errorNumber:"+(e.number & 0xFFFF )+",message:"+e.message);
		 */
		//单功能设备读取二代证异常。
		//$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SingleFunctionalDeviceFailedReadIDCard"));
		return "";
	}
}

//适配不同厂商的读卡器，减少外围改动
function adaptToSimpleOcx(obj) {    
    var cardNoProp = obj.CardNo;
    if (typeof cardNoProp == 'function') {
        return obj;
    }
    
	try {
		var funcPropMap = {
				CardNo : 'CardNo',
				Name : 'NameL',
				NameL : 'NameL',
                NameS :  obj.NameS ? 'NameS':'NameL',
				Sex : 'Sex',
				SexL : 'SexL',
				NationL : 'NationL',
				Address : 'Address',
				police : 'Police',
				Police : 'Police',
				ActivityLFrom : obj.ActivityFrom ? 'ActivityFrom':'ActivityLFrom',
				ActivityLTo : obj.ActivityTo ? 'ActivityTo':'ActivityLTo',
				ActivityL : 'ActivityL',
				Born : 'Born',
				PhotoPath:'PhotoPath',
			};

		var newObj = {
			srcObj: obj
		};

		function setNewObj(funcName) {
			newObj[funcName] = function () {
			    var info = "";
			    try {
			        info = this.srcObj[funcPropMap[funcName]];
			    } catch(e) {}
				return info;
			}
		}

		for (var funcName in funcPropMap) {
			setNewObj(funcName);
		}

		return newObj;
	} catch(e) {}

	return obj;
}

/**
 * 二代证读卡器读取身份证时合并身份证正反面
 *
 * @remark create jKF10813 2013-04-26 R003C13L03n01 OR_JS_201303_817
 */

function combineIDCard(BossICCardOCX, sysFolder, kind, cardType) {
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	var systemFolder = fso.GetSpecialFolder(1); // 获得系统文件夹对象
	if (!fso.FileExists(systemFolder.Path + "\\HWUtilOCX.ocx")) {
		//return "";
	}

	/* 头像图片存放路径 */
	//00383635
	//var idimg = sysFolder + "/zp.jpg";
	var idimg = sysFolder + "/image.bmp";
	var idstr = makeIdInfo(BossICCardOCX, idimg, true);
    if (cardType == 'IdCardGA' || cardType == 'IdCardTW') {
        var passCode = "NULL";
        try {
            passCode = BossICCardOCX.PassCode();
        } catch (e) {}
        idstr += "|" + passCode;
    }
	var picPath = buildCertImagePath(kind);
	idstr = idstr + "|" + picPath;
	var HWUtilOCX = document.getElementById("HWUtilOCX") || document.getElementById("HWUtilOCXS");
	if (cardType == 'IdCardGA' || cardType == 'IdCardTW') {
        var CombinePicOCX = document.getElementById("CombinePicOCX");
        if (CombinePicOCX) {
            try {
                CombinePicOCX.CreateIdCardPic(idstr, cardType);
            } catch (e) {}
        }
	} else if (cardType != 'IdCardEx') {
		HWUtilOCX.CreateIdCardPic(idstr);
	} else {
	    var foreignName = '';
	    try {
	        foreignName = BossICCardOCX.NameS();
	    } catch(e) {}
	    
		idstr += "|" + foreignName;
		HWUtilOCX.CreateIdCardExPic(idstr);
	}
	return picPath;
}

/**
 * 二代证读卡器读取身份证时合并身份证正反面
 *
 * @remark create jKF10813 2013-04-26 R003C13L03n01 OR_JS_201303_817
 *
 */
function makeIdInfo(BossICCardOCX, idImg, btype) {
	/* 格式：公民身份号码|姓名|性别|民族|出生年|出生月|出生日|住址|头像图片存放路径|发证机关|有效期限|合成图片名（全路径） */
  /*if ('SHANDONG' == $Page.projectVersion) {
	// 身份证号码
	var CardNo = BossICCardOCX.CardNo();

	// 姓名，两个字的姓名中间有空格
	var Name = BossICCardOCX.NameL();

	// 性别，“男”或“女”
	var SexL = BossICCardOCX.Sex()=="0"?"女":"男";

	// 民族，例：“汉”
	var NationL = BossICCardOCX.NationL();

	// 生日，格式：yyyymmdd
	var Born = BossICCardOCX.CardNo().substring(6,14);
	var year = "";
	var month = "";
	var day = "";
	if (Born && Born != "") {
		year = Born.substring(0, 4);
		month = parseInt(Born.substring(4, 6), 10);
		day = Born.substring(6, 8);
	}

	// 地址
	var Address = BossICCardOCX.Address();

	// 签发机关
	var Police = BossICCardOCX.police();

	// 有效期限，格式：yyyy.mm.dd-yyyy.mm.dd
	//var ActivityL = BossICCardOCX.ActivityL;
	var ActivityL = BossICCardOCX.ActivityLFrom().substring(0, 4) + '.' + parseInt(BossICCardOCX.ActivityLFrom().substring(4, 6), 10) + '.' + BossICCardOCX.ActivityLFrom().substring(6, 8) + '-' + BossICCardOCX.ActivityLTo().substring(0, 4) + '.' + parseInt(BossICCardOCX.ActivityLTo().substring(4, 6), 10) + '.' + BossICCardOCX.ActivityLTo().substring(6, 8);
   }
  else{*/
	  // 身份证号码
	var CardNo = BossICCardOCX.CardNo();

	try {
		// 姓名，两个字的姓名中间有空格
		var Name = BossICCardOCX.Name();
	} catch (e) {
		var Name = BossICCardOCX.NameL();
	}

	// 性别，“男”或“女”
	var SexL = BossICCardOCX.SexL();

	// 民族，例：“汉”
	var NationL = BossICCardOCX.NationL();

	// 生日，格式：yyyymmdd
	var Born = BossICCardOCX.Born();
	var year = "";
	var month = "";
	var day = "";
	if (Born && Born != "") {
		year = Born.substring(0, 4);
		month = parseInt(Born.substring(4, 6), 10);
		day = Born.substring(6, 8);
	}

	// 地址
	var Address = BossICCardOCX.Address();

	// 签发机关
	var Police = BossICCardOCX.Police();

	// 有效期限，格式：yyyy.mm.dd-yyyy.mm.dd
	var ActivityL = BossICCardOCX.ActivityL();
	if (!ActivityL) {
		try {
			var activityLFrom = BossICCardOCX.ActivityLFrom();
			var activityLTo = BossICCardOCX.ActivityLTo();
			var ActivityL = activityLFrom.substring(0, 4) + '.' + parseInt(activityLFrom.substring(4, 6), 10) + '.' + activityLFrom.substring(6, 8) 
				+ '-' + activityLTo.substring(0, 4) + '.' + parseInt(activityLTo.substring(4, 6), 10) + '.' + activityLTo.substring(6, 8);
		} catch(e) {}
	}
 // }
	var idstr = "";
	if (btype) {
		idstr = CardNo + "|" + Name + "|" + SexL + "|" + NationL + "|" + year
				+ "|" + month + "|" + day + "|" + Address + "|" + idImg + "|"
				+ Police + "|" + ActivityL;
	} else {
		idstr = "IdCard" + "|" + CardNo + "|" + $.trim(Name) + "|" + SexL + "|"
				+ NationL + "|" + Born + "|" + Address + "|" + Police + "|"
				+ ActivityL + "|" + idImg;
	}
	return idstr;
}

/**
 * 显示读取到的证件图片
 *
 * @remark create jKF10813 2013-05-06 R003C13L03n01 OR_JS_201303_817
 * @remark modify w00187892 2013-05-27 R003C13LG0501 OR_JS_201305_437 增加kind参数
 */

function showIDImg(path, kind) {
	debugger;
	var $Page = $(document).scope().$Page;
	var iccardImage = "iccardImg";
	var iccardProxyImage = "iccardProxyImg";
	if ($Page.isReadCardAuth) {
		iccardImage = "iccardImg_serv_auth";
		iccardProxyImage = "iccardImg_delegate_auth";
	}
	// wwx230437
	if (kind == "serv" || kind == "newserv")
	{
		if ($("#" + iccardImage)[0])
		{
			$("#" + iccardImage)[0].style.filter =
				"progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\""	+ path + "\")";
			document.getElementById(iccardImage).style.display = "block";
		}
	}
	else if (kind == "delegate" || kind == "newdelegate")
	{
		if ($("#" + iccardProxyImage)[0])
		{
			$("#" + iccardProxyImage)[0].style.filter =
				"progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\""	+ path + "\")";
			document.getElementById(iccardProxyImage).style.display = "block";
		}
	}

}

/**
 * 给指定的图片添加水印内容 path：图片全路径
 */
function addWatermarkText(path) {
	debugger;
	try
	{
		var content = WATERMARK;
		if ("" == content)
		{
			return;
		}
		// wwx230437
		var HWUtilObj = document.getElementById("HWUtil") || document.getElementById("HWUtilS");
		if (!HWUtilObj)
		{
			$('body').append("<object id=\"HWUtil\" name=\"HWUtil\" width=\"0\" height=\"0\" classid=\'clsid:B3CAF006-A947-4e82-A377-4963B3C0DC11\'></object>");
			HWUtilObj = document.getElementById("HWUtil");
		}
		HWUtilObj.AddWatermarkText(path, content,"C:\\Windows\\System32\\watermarkback.bmp", 40);
	}
	catch (e)
	{
		// 添加水印失败：
		alert($UEE.i18n("ad.person.message.AddWatermarkFailed") + e.message);
	}

}

/**
 * 多功能设备读取证件（支持多种证件类型） MultiCardReaderOCX
 * BSTR Message; 描述信息
 * BSTR idInfo; 证件文字信息
 * BSTR FrontImageFileName; 正面图片绝对路径，如果只有一个面，则保存在此路径
 * BSTR BackImageFileName; 背面图片绝对路径，如果只有一个面，此路径为空
 * BSTR CombineFileName; 合并图片绝对路径，正、背面合成后的图片路径
 * long OpenDevice(port); 由指定端口打开读卡设备
 * port:-1表示根据配置文件指定端口 return:0表示成功，其他失败
 * long CloseDevice(); 关闭多功能设备，清理临时图片 return:0表示成功，其他失败
 * long getImageMsg(cardType,imagePath); 读取证件图片
 * cardType:证件类型
 * imagePath:图片临时路径，传空表示默认 return:0表示成功，其他失败
 * long CombineImages(type); 合并证件图片
 * type:合并类型 0 横 1 竖 return:0表示成功，其他失败
 *
 * @return if成功读取到证件信息true else false
 */
function readCardFromMultiOcx($Page, cardType, kind, $UI, multiCardReaderOCX) {
	debugger;
	// 校验毛线类型，支持类型这么多
	// var cardTypeArray = [ "IdCard", "HuKouBu", "Passport", "PLA" ];

	if (!cardType) {
		// 请先选择证件类型。
		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SelectCertificateTypeFirst"));
		return "";
	}
//	if ($.inArray(cardType, cardTypeArray) == -1) {
//		// 您读取的证件类型目前系统不支持使用。\n请更换证件类型再进行读取。
//		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NotSupportCurrentCertificateType"));
//		return "";
//	}

	try {
		// <%-- 1 获取多功能设备 --%>
		var multiCardReader = document.getElementById(multiCardReaderOCX);
		multiCardReader.CombineFileName = buildCertImagePath(kind);
		var $scope = $(document).scope();
		$Page = $scope.$Page;
		//$Page.realNameIdImg  = getBase64OfImage(multiCardReader.CombineFileName);

		if (!multiCardReader) {
			// 多功能设备读卡控件在页面注册失败，请联系维护人员。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.MultiFunctionalDeviceFailBeRegistered"));
			return "";
		}
		// <%-- 2 打开多功能设备 --%>
		var openFlag = multiCardReader.OpenDevice(-1);
		if (0 != openFlag) {
			return "";
		}
		// <%-- 3 读取证件信息 --%>
		var readFlag = -1;
		// <%-- 3.1 二代证优先使用感应读取，失败后使用扫描读取 --%>
		if (ICCARD2 == cardType || 'IdCardEx' == cardType || 'IdCardGA' == cardType || 'IdCardTW' == cardType) {
			return read2IdCard($Page, multiCardReader, kind, cardType, $UI);
		}
		// <%-- 3.2 其他证件使用扫描读取 --%>
		else {
			var cardTypeTemp = "11";
			readFlag = multiCardReader.getImageMsg(cardTypeTemp,
					multiCardReader.CombineFileName);
			if (0 != readFlag) {
				// 多功能设备读取证件失败。\n错误码：" + readFlag+ "。错误信息：" +
				// multiCardReader.Message+ "。\n可能是证件无效或放置不正确。
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.MultiFunctionalDeviceFailedReadCardErrorInfo",[readFlag, multiCardReader.Message]));
				return "";
			}
			isInfoCredible = false;
			return setCardInfo($Page, multiCardReader, kind, cardType, $UI);
		}
	}
	// <%-- 异常情况全部反馈，提供定位信息 --%>
	catch (e) {
		if (ICCARD2 != cardType) {
			// $UI.msgbox.info("提示", "多功能设备读卡出现异常:" + "name:"+ e.name +
			// ",errorNumber:"+(e.number & 0xFFFF )+",message:"+e.message);
			// DTS2015082807861 要求去掉英文描述
			// 多功能设备读卡出现异常。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.MultiFunctionalDeviceFailedReadCard"));
		}
		return "";
	}
	// <%-- 执行关闭设备，出现异常不做处理 --%>
	finally {
		try {
			multiCardReader.CloseDevice();
		} catch (ef) {
		}
	}
	return "";
}

/**
 * 读取二代身份证
 *
 * @param multiCardReader
 *            多功能读卡设备
 * @param kind
 *            读卡类型
 * @return if读卡成功 true else false
 */
function read2IdCard($Page, multiCardReader, kind, cardType, $UI) {
	debugger;
	// <%-- 读取标志 --%>
	var readFlag = -1;
	// <%-- 1 使用感应读取 --%>
	while (true) {
		readFlag = multiCardReader.getImageMsg(ICCARD2_ALL, "");
		if (0 == readFlag) {
			isInfoCredible = true;
			// <%-- 合并图片 --%>
			readFlag = multiCardReader.CombineImages(1);
			if (0 != readFlag) {
				// 使用感应合并二代身份证正、背面失败。" + "\n错误码："+ readFlag + "。错误信息：" +
				// multiCardReader.Message + "。
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.MultiDeviceFailedInteractionBothSide",[readFlag, multiCardReader.Message]));
				return "";
			}

			/*
			 * if (kind == 'serv') { $Page.servcard = multiCardReader.idInfo; }
			 * else { $Page.delegcard = multiCardReader.idInfo; }
			 */
			return setCardInfo($Page, multiCardReader, kind, cardType, $UI);
		} else {
			// 使用感应读取二代身份证失败。" + "\n错误码：" + readFlag + "。错误信息："+
			// multiCardReader.Message + "。"+ "\n点击 确定 可重新使用侧面感应读取。\n点击 取消
			// 将使用顶部扫描读取。
			if (confirm($UEE.i18n("ad.person.message.MultiDeviceFailedReadBothSide",[readFlag, multiCardReader.Message]))) {
				continue;
			} else {
				break;
			}
		}
	}
	// <%-- 2 使用扫描读取 --%>
	// <%-- 2.1 读取正面 --%>
	// 下面使用扫描读取二代身份证。" + "\n请将二代身份证正面朝下放置到扫描板。
	$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IdCardRightSideUp"));
	readFlag = multiCardReader.getImageMsg(ICCARD2_FRONT,
			multiCardReader.FrontImageFileName);
	if (0 != readFlag) {
		// "使用扫描读取二代身份证正面失败。" + "\n错误码：" + readFlag + "。错误信息：" +
		// multiCardReader.Message + "。"
		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IdCardRightSideReadFail", [readFlag, multiCardReader.Message]));
		return "";
	}
	// <%-- 2.2 读取背面 --%>
	// var tempCardInfo = multiCardReader.idInfo;
	// 使用扫描读取二代身份证正面成功。" + "\n请将二代身份证背面朝下放置到扫描板。
	$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IdCardBackSideUp"));
	readFlag = multiCardReader.getImageMsg(ICCARD2_BACK,
			multiCardReader.BackImageFileName);
	if (0 != readFlag) {
		// "使用扫描读取二代身份证背面失败。" + "\n错误码：" + readFlag + "。错误信息：" +
		// multiCardReader.Message + "。"
		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IdCardBackSideReadFail", [readFlag, multiCardReader.Message]));
		return "";
	}
	// <%-- 2.3 合并图片 --%>
	readFlag = multiCardReader.CombineImages(1);
	if (0 != readFlag) {
		// 使用扫描合并二代身份证正、背面失败。" + "\n错误码：" + readFlag+ "。错误信息：" +
		// multiCardReader.Message + "。"
		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.MultiDeviceFailedScanBothSide", [readFlag, multiCardReader.Message]));
		return "";
	}
	isInfoCredible = false;
	return setCardInfo($Page, multiCardReader, kind, cardType, $UI);
}

/**
 * 设置证件信息 将证件文字信息保存到返回对象 将图片路径信息保存到返回对象并设置预览 return 默认设置成功，不处理异常
 *
 * @ramark modify l00227362 2013-12-09 R003C13LG11n01 OR_JS_201311_34
 *         关于无纸化免填单二次推送相关优化需求
 */
function setCardInfo($Page, multiCardReader, kind, cardType, $UI, uploadFlag) {
	debugger;
	var tempiccardInfo = {};
	var cardInfo2Cookie = {
		"cardNo": "",
		"name": "",
		"sex": "",
		"nation": "",
		"birth": "",
		"address": "",
		"police": "",
		"effectDate": "",
		"endDate": ""
	};
	// 创建pdf时需要传的证件信息 字符串,若能读到
	// 字符串结构为"IdCard|身份证号码|姓名|男女性别|民族|19700101生日|住址|公安局|2009.01.24-2029.01.24有效期"
	var cardInfo2CookieStr = "";
	var cardInfo = multiCardReader.idInfo;
	// <%-- 1. 设置返回信息 --%>
	if (cardInfo) {
		var infor = cardInfo.split('|');
		// <%-- 证件号码 --%>
		tempiccardInfo.cardNo = infor[0];
		cardInfo2Cookie.cardNo = infor[0];
		// <%-- 姓名 --%>
		tempiccardInfo.name = infor[1];
		cardInfo2Cookie.name = infor[1];
		// <%-- 地址 --%>
		tempiccardInfo.address = infor[2];
		cardInfo2Cookie.address = infor[2];
		// <%-- 性别(1.男;0.女) --%>
		tempiccardInfo.sex = infor[3];

		tempiccardInfo.authority = infor[8];
		cardInfo2Cookie.authority = infor[8];

		// <%-- 性别(1.男;2.女) for bes --%>
		// 应该是1男 0女 上面的注释错了，读卡器读出来的内容和下拉列表中显示的是一样的
		if (tempiccardInfo.sex == "0") {
			// tempiccardInfo.sex = "2";
			cardInfo2Cookie.sex = "女";
		} else {
			cardInfo2Cookie.sex = "男";

		}

		var dateFmt = /^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})/;
		// <%-- 生效日期(yyyy-mm-dd) --%>
		tempiccardInfo.effectDate = "";
		if (dateFmt.test(infor[4])) {
			tempiccardInfo.effectDate = infor[4];
			cardInfo2Cookie.effectDate = infor[4].replace(
					new RegExp('-', "gm"), ".");
		}
		// <%-- 失效日期(yyyy-mm-dd) --%>
		tempiccardInfo.endDate = "";
		if (dateFmt.test(infor[5])) {
			tempiccardInfo.endDate = infor[5];
			cardInfo2Cookie.endDate = infor[5].replace(new RegExp('-', "gm"),
					".");
		}

		tempiccardInfo.effectDate = tempiccardInfo.effectDate.replace(
				new RegExp('-', "gm"), "/");
		tempiccardInfo.endDate = tempiccardInfo.endDate.replace(new RegExp('-',
					"gm"), "/");

		if (uploadFlag) {
			tempiccardInfo.certType = "Other"; // 证件类型
			tempiccardInfo.isInfoCredible = false;
		} else {
			// <%-- 证件类型 --%>
			tempiccardInfo.certType = cardType;
			// <%-- 证件是否可靠 --%>
			tempiccardInfo.isInfoCredible = isInfoCredible;
		}

		// <%-- 民族 --%>
		if (infor.length >= 6 && infor[6]) {
			tempiccardInfo.nation = infor[6];
			cardInfo2Cookie.nation = infor[6];

			if (tempiccardInfo.nation && '' != tempiccardInfo.nation) {
				tempiccardInfo.nation = transRaceStr($Page,
						tempiccardInfo.nation);
			} else {
				tempiccardInfo.nation = '0';
			}
		}

		// 出生日期
		cardInfo2Cookie.birth = infor[0].substring(6, 14);

		if (isInfoCredible && (tempiccardInfo.certType == "IdCard" || tempiccardInfo.certType == "TempId")
				&& infor.length >= 10) {
// certInfo += "IdCard|" + infor[0] + "|" + infor[1] + "|" + infor[3]
// + "|" + infor[6] + "|" + infor[7]; // CardType|CardNo|Name|Sex|Nation|Birth
// certInfo += "|" + infor[2] + "|" + infor[8] + "|"
// + infor[4].replace(/\-/g, ".") + "-"
// + infor[5].replace(/\-/g, ".") + "|" + infor[9];//
// Address|Police|Activity|IdImg
			cardInfo2Cookie.birth = infor[7];
			cardInfo2Cookie.police = infor[8];
		}
	}

	cardInfo2CookieStr = "IdCard|" + cardInfo2Cookie.cardNo + "|"
		 + cardInfo2Cookie.name + "|" + cardInfo2Cookie.sex + "|"
		 + cardInfo2Cookie.nation + "|" + cardInfo2Cookie.birth + "|"
		 + cardInfo2Cookie.address + "|" + cardInfo2Cookie.police + "|"
		 + cardInfo2Cookie.effectDate + "-" + cardInfo2Cookie.endDate;

	if ("serv" == kind && tempiccardInfo.certType != "Other") {
		iccardInfo = tempiccardInfo;
	}

	// 230437
	if ($Page.showID2CardImage) {
		// 增加水印
		addWatermarkText(multiCardReader.CombineFileName);
		showIDImg(multiCardReader.CombineFileName + "?version=" + Math.random(), kind);
		$Page.showID2CardImage = false;
	}
	// <%-- 2.设置页面文字信息 --%>

	// 保存tempiccardInfo对象 TODO

	var fso = new ActiveXObject("Scripting.FileSystemObject");
	var tmpfolder = fso.GetSpecialFolder(2);

	// wwx230437 bes调用ngpdf工程生成pdf只是实现了一种接口：通过各种组件合成方式 因而必须传头像路径
	// 但是多功能读卡器不支持读取头像 因此fso.GetFile会报错跳转到单功能
	// 目前只有神思二代（读卡时会听到两次读卡声音）和只有单功能读卡器才可用 易普森不支持读取头像也没有单功能读卡功能
	try
	{
		// 使用多功能设备时，有时下面这句会报错
		// 人证比对
		//
	/* if ('SHANDONG' == $Page.projectVersion) {
	var pathTemp = tmpfolder.Path+"//zp.jpg";
	}
	else{ */
	var pathTemp = tmpfolder.Path+"//image.bmp";
	//}
        var $scope = $(document).scope();
    	$Page = $scope.$Page;
    	$Page.realNameIdImg = getBase64OfImage(pathTemp);

		// 多功能读卡获取身份证正面图片
		if (!$Page.realNameIdImg) {
			$Page.realNameIdImg = getBase64OfImage(multiCardReader.FrontImageFileName);
		}

    	// 多功能读卡器获取身份证合并后的图片
    	if(!$Page.realNameIdImg){
    		$Page.realNameIdImg = getBase64OfImage(multiCardReader.CombineFileName);
    	}
		//383635
/*     	if ('SHANDONG' == $Page.projectVersion) {
			f = fso.GetFile(tmpfolder.Path + "//zp.bmp");
		}
		else{ */
			f = fso.GetFile(tmpfolder.Path + "//image.bmp");
		//}
		if (tempiccardInfo.cardNo && tempiccardInfo.cardNo != "")
		{
		// 过户时需要保存户主、经办人、过户户主、经办人
        if (kind == 'serv') {
        	f.Copy(tmpfolder.Path+"//servimage.jpg");
        	$.cookie('besservcard', cardInfo2CookieStr);
        	window._ysp_top.EinvoiceIdCardInfo.besservcard = cardInfo2CookieStr;
        }
        else if (kind == 'newserv'){
			f.Copy(tmpfolder.Path + "//newservimge.jpg");
			$.cookie('besnewservcard', cardInfo2CookieStr);
			window._ysp_top.EinvoiceIdCardInfo.besnewservcard = cardInfo2CookieStr;
		}
        else if (kind == 'delegate'){
			f.Copy(tmpfolder.Path + "//delegimge.jpg");
			$.cookie('besdelegcard', cardInfo2CookieStr);
			window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
		}
		else if (kind == 'newdelegate'){
			f.Copy(tmpfolder.Path + "//newdelegimge.jpg");
			$.cookie('besnewdelegcard', cardInfo2CookieStr);
			window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = cardInfo2CookieStr;
		}
        else {
        	f.Copy(tmpfolder.Path+"//delegimge.jpg");
        	$.cookie('besdelegcard', cardInfo2CookieStr);
        	window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
        }
		}
	}
	catch(error)
	{
		if (tempiccardInfo.cardNo && tempiccardInfo.cardNo != "")
		{
		// 过户时需要保存户主、经办人、过户户主、经办人
        if (kind == 'serv') {
        	$.cookie('besservcard', cardInfo2CookieStr);
        	window._ysp_top.EinvoiceIdCardInfo.besservcard = cardInfo2CookieStr;
        }
        else if (kind == 'newserv'){
			$.cookie('besnewservcard', cardInfo2CookieStr);
			window._ysp_top.EinvoiceIdCardInfo.besnewservcard = cardInfo2CookieStr;
		}
        else if (kind == 'delegate'){
			$.cookie('besdelegcard', cardInfo2CookieStr);
			window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
		}
		else if (kind == 'newdelegate'){
			$.cookie('besnewdelegcard', cardInfo2CookieStr);
			window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = cardInfo2CookieStr;
		}
        else {
        	$.cookie('besdelegcard', cardInfo2CookieStr);
        	window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
        }
		}

	}
	return tempiccardInfo;
}

/*
 * <%-- 创建证件图片保存路径 @remark create w00187892 2013-05-29 R003C13LG0501
 * OR_JS_201305_437 --%>
 */
function buildCertImagePath(kind) {
	debugger;
	var $Page = $(document).scope().$Page;
	// 是否鉴权调用
	var isAuth = $Page.isReadCardAuth;
	// modify begin l00201782 2014-01-18 R003C13LG1201
	// 调用号码
	var recNumber = "";// $.trim("${#BMEStepAttr.ServNumber}");
	if (!isAuth) {
		var recNumber = "";
	}
	// <%-- modify end l00201782 2014-01-18 R003C13LG1201 --%>

	return buildCertImagePathOnClient(isAuth, recNumber, kind);
}

function buildCertImagePathOnClient(isAuth, recNumber, kind) {
	debugger;

	/*
	 * if (isAuth) { var authImageFolder = CERT_IMAGE_ON_CLIENT_BASE_PATH; if
	 * (recNumber != "") { authImageFolder = authImageFolder + recNumber + "\\"; }
	 * checkAndCreateFolder(authImageFolder); return authImageFolder + kind +
	 * "card.jpg"; }
	 */

	if (recNumber == "") {
		recNumber = REC_NUMBER_WITHOUT_AUTH;
	}
	var recImageFolder = CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber + "\\";

	var $scope = $(document).scope();
	var $Fire = $scope.$Get('$Fire');
	var $Page = $scope.$Page;
	
	window._ysp_top.certImageDirectory = window._ysp_top.certImageDirectory || {};
	if(undefined == window._ysp_top.certImageDirectory.timestamp){
	    var nowDateTS = $Page.TimeUtil.localNowDate;
	    var today = $(document).scope().$Get('$filter')('tz')(nowDateTS, $Page.tzDate);

	    window._ysp_top.certImageDirectory.timestamp = nowDateTS;
	    window._ysp_top.certImageDirectory.directory = today;
	}
	
	$Fire({
	    onafter: function() {
            deleteUnuserFolder();
        }
	}, $scope);

	recImageFolder = recImageFolder + window._ysp_top.certImageDirectory.directory + "\\";

	checkAndCreateFolder(recImageFolder);
	
	debugger;
	var imgPath = recImageFolder + window._ysp_top.certImageDirectory.timestamp + "new" + kind + "card.jpg";
	// 使用登录手机号给证件图片命名 c00311908
	if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
	{
		imgPath = recImageFolder + window._ysp_top.certImageDirectory.timestamp + "new" + kind + "card_"+window._ysp_top.serviceNumberForCardName+".jpg";
	}
	return imgPath;
}

/**
 * 之前双IE会出现，身份证头像被其他用户冲掉的问题。解决方案是每次打开一个IE，就记录下时间戳，一个IE保存一份。
 * 这样会有一个问题，打开IE办完业务，头像一直存在，无法删除。解决方案是每天建立一个文件夹，定时去清理。 现在是创建一个异步任务，删除两天之前的文件夹。
 */
function deleteUnuserFolder(){
    var filePath = CERT_IMAGE_ON_CLIENT_BASE_PATH + REC_NUMBER_WITHOUT_AUTH + "\\";

    if(window._ysp_top.certImageDirectory.alreadyclean == true){
        return;
    }
    try
    {
        var fso = new ActiveXObject('Scripting.FileSystemObject');
        var parentFolder = fso.GetFolder(filePath);
        var underFolders = new Enumerator(parentFolder.SubFolders);
        for (;!underFolders.atEnd();underFolders.moveNext()){
            var item = underFolders.item();
            var itemName = ""+item.Name;
            itemName = itemName.split('-');
            var date = new Date();
            date.setUTCFullYear(itemName[0], itemName[1] - 1, itemName[2]);
            date.setUTCHours(0, 0, 0, 0);

            var foldTime = new Date(date).getTime();

            if(foldTime < (window._ysp_top.certImageDirectory.timestamp - 2*24*60*60*1000 )){
                fso.DeleteFolder(item.Path);
            }
        }
    }
    catch(error)
    {
    }

    window._ysp_top.certImageDirectory.alreadyclean = true
}

function checkAndCreateFolder(path) {
	debugger;
	var paths = path.split("\\");
	if (paths.length < 1) {
		return "";
	}
	path = paths[0] + "\\";
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	for ( var i = 1; i < paths.length; i++) {
		if (paths[i] == "") {
			continue;
		}
		path += paths[i] + "\\";
		if (!fso.FolderExists(path)) {
			fso.CreateFolder(path);
		}
	}
	return path;
}

// 宁夏华视也是单功能读卡器，但和江苏的单功能控件不同，接口也不同
function readCardFromBossICCardOCX($Page, kind, cardType, $UI) {
    debugger;
    var ocxObj = document.getElementById('BossICCardOCX');
    if('' == ocxObj)
    {
        return "";
    }
    try
    {
        if (ocxObj.InitMachine()){
            var tempiccardInfo = {};
            var cardInfo2Cookie = {
                "cardNo" : "",
                "name" : "",
                "sex" : "",
                "nation" : "",
                "birth" : "",
                "address" : "",
                "police" : "",
                "effectDate" : "",
                "endDate" : ""
            };
            // 创建pdf时需要传的证件信息 字符串,若能读到
            // 字符串结构为"IdCard|身份证号码|姓名|男女性别|民族|19700101生日|住址|公安局|2009.01.24-2029.01.24有效期"
            var cardInfo2CookieStr = "";
            var cardInfo = ocxObj.GetTextInfo();

            if('' == cardInfo)
            {
                return "";
            }
            var infor = cardInfo.split('|');
            // <%-- 证件号码 --%>
            tempiccardInfo.cardNo = infor[0];
            cardInfo2Cookie.cardNo = infor[0];
            // <%-- 姓名 --%>
            tempiccardInfo.name = infor[1];
            cardInfo2Cookie.name = infor[1];
            // <%-- 地址 --%>
            tempiccardInfo.address = infor[2];
            cardInfo2Cookie.address = infor[2];
            // <%-- 性别(1.男;0.女) --%>
            tempiccardInfo.sex = infor[3];

            // <%-- 性别(1.男;2.女) for bes --%>
            // 应该是1男 0女 上面的注释错了，读卡器读出来的内容和下拉列表中显示的是一样的
            if (tempiccardInfo.sex == "0") {
                // tempiccardInfo.sex = "2";
                cardInfo2Cookie.sex = "女";
            } else {
                cardInfo2Cookie.sex = "男";

            }

            var dateFmt = /^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})/;
            // <%-- 生效日期(yyyy-mm-dd) --%>
            tempiccardInfo.effectDate = "";
            if (dateFmt.test(infor[4])) {
                tempiccardInfo.effectDate = infor[4];
                cardInfo2Cookie.effectDate = infor[4].replace(
                        new RegExp('-', "gm"), ".");
            }
            // <%-- 失效日期(yyyy-mm-dd) --%>
            tempiccardInfo.endDate = "";
            if (dateFmt.test(infor[5])) {
                tempiccardInfo.endDate = infor[5];
                cardInfo2Cookie.endDate = infor[5].replace(new RegExp('-', "gm"),
                        ".");
            }

            tempiccardInfo.effectDate = tempiccardInfo.effectDate.replace(
                    new RegExp('-', "gm"), "/");
            tempiccardInfo.endDate = tempiccardInfo.endDate.replace(new RegExp('-',
                    "gm"), "/");

            // <%-- 证件类型 --%>
            tempiccardInfo.certType = cardType;
            // <%-- 证件是否可靠 --%>
            tempiccardInfo.isInfoCredible = isInfoCredible;

            // <%-- 民族 --%>
            if (infor.length >= 6 && infor[6]) {
                tempiccardInfo.nation = infor[6];
                cardInfo2Cookie.nation = infor[6];

                if (tempiccardInfo.nation && '' != tempiccardInfo.nation) {
                    tempiccardInfo.nation = transRaceStr($Page,
                            tempiccardInfo.nation);
                } else {
                    tempiccardInfo.nation = '0';
                }
            }

            // 出生日期
            cardInfo2Cookie.birth = infor[0].substring(6, 14);

            if (isInfoCredible && (tempiccardInfo.certType == "IdCard" || tempiccardInfo.certType == "TempId")
                    && infor.length >= 10) {
                cardInfo2Cookie.birth = infor[7];
                cardInfo2Cookie.police = infor[8];
            }

            cardInfo2CookieStr = "IdCard|" + cardInfo2Cookie.cardNo + "|"
                    + cardInfo2Cookie.name + "|" + cardInfo2Cookie.sex + "|"
                    + cardInfo2Cookie.nation + "|" + cardInfo2Cookie.birth + "|"
                    + cardInfo2Cookie.address + "|" + cardInfo2Cookie.police + "|"
                    + cardInfo2Cookie.effectDate + "-" + cardInfo2Cookie.endDate;

            try
            {
                var fso = new ActiveXObject("Scripting.FileSystemObject");

                // CRV100U设备的图像保存在ocxObj.GetImage()
                var crv100uImagePath = ocxObj.GetImage();   // 不是小头像，是完整的身份证，包括正反面
                f = fso.GetFile(crv100uImagePath);

                if (tempiccardInfo.cardNo && tempiccardInfo.cardNo != "")
                {
                    var tmpfolder = buildCertImagePath(kind);   // C:\Temp\certifications\00000000000
                    f.Copy(tmpfolder);

                    if ($Page.showID2CardImage) {
                        // 增加水印
                        addWatermarkText(tmpfolder);
                        showIDImg(tmpfolder + "?version=" + Math.random(), kind);

                        $Page.showID2CardImage = false;
                    }

                    // 过户时需要保存户主、经办人、过户户主、经办人
                    if (kind == 'serv') {
                        // f.Copy(tmpfolder.Path+"//servimage.jpg");
                        $.cookie('besservcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besservcard = cardInfo2CookieStr;
                    }
                    else if (kind == 'newserv'){
                        // f.Copy(tmpfolder.Path + "//newservimge.jpg");
                        $.cookie('besnewservcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besnewservcard = cardInfo2CookieStr;
                    }
                    else if (kind == 'delegate'){
                        // f.Copy(tmpfolder.Path + "//delegimge.jpg");
                        $.cookie('besdelegcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
                    }
                    else if (kind == 'newdelegate'){
                        // f.Copy(tmpfolder.Path + "//newdelegimge.jpg");
                        $.cookie('besnewdelegcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = cardInfo2CookieStr;
                    }
                    else {
                        // f.Copy(tmpfolder.Path+"//delegimge.jpg");
                        $.cookie('besdelegcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
                    }
                }
            }
            catch(error)
            {
                if (tempiccardInfo.cardNo && tempiccardInfo.cardNo != "")
                {
                    // 过户时需要保存户主、经办人、过户户主、经办人
                    if (kind == 'serv') {
                        $.cookie('besservcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besservcard = cardInfo2CookieStr;
                    }
                    else if (kind == 'newserv'){
                        $.cookie('besnewservcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besnewservcard = cardInfo2CookieStr;
                    }
                    else if (kind == 'delegate'){
                        $.cookie('besdelegcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
                    }
                    else if (kind == 'newdelegate'){
                        $.cookie('besnewdelegcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = cardInfo2CookieStr;
                    }
                    else {
                        $.cookie('besdelegcard', cardInfo2CookieStr);
                        window._ysp_top.EinvoiceIdCardInfo.besdelegcard = cardInfo2CookieStr;
                    }
                }

            }
            return tempiccardInfo;
        }
    }
    catch(error)
    {
        //$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SingleFunctionalDeviceFailedReadIDCard"));
        //$UI.msgbox.info($UEE.i18n('ad.person.message.information'), '未读取到二代证信息，检查是否正常连接设备或重新放置二代身份证');
        return "";
    }
}

/**
 * 上传的图片进行免填单预览中展示
 *
 * @param $Page
 * @param kind
 * @param cardType
 * @param $UI
 * @param bossICCardOCX
 * @returns
 */
function upLoadIDCardForPrint(path, kind) {
	debugger;
		window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};
		
		window._ysp_top.certImageDirectory = window._ysp_top.certImageDirectory || {};
		if(undefined == window._ysp_top.certImageDirectory.timestamp){
		    var nowDateTS = $Page.TimeUtil.localNowDate;
		    var today = $(document).scope().$Get('$filter')('tz')(nowDateTS, $Page.tzDate);

		    window._ysp_top.certImageDirectory.timestamp = nowDateTS;
		    window._ysp_top.certImageDirectory.directory = today;
		}

		var fso = new ActiveXObject("Scripting.FileSystemObject");
		var tmpfolder = fso.GetSpecialFolder(2);
		// 获取图片路径
		var f = fso.GetFile(path);
		// 将图片存放到免填单预览的图片目录中
		var REC_NUMBER_WITHOUT_AUTH = "00000000000";
		
		var recImageFolder = "C:\\temp\\certifications\\"+REC_NUMBER_WITHOUT_AUTH+"\\"+window._ysp_top.certImageDirectory.directory+"\\";
		checkAndCreateFolder(recImageFolder);
		
		var CERT_IMAGE_ON_CLIENT_BASE_PATH = recImageFolder + window._ysp_top.certImageDirectory.timestamp;
		
		var picName = '';
		if ("serv" == kind) {
			picName = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newservcard.jpg";
			// 如果是登录时有手机号，则记录手机号 c00311908
			if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
			{
				picName = CERT_IMAGE_ON_CLIENT_BASE_PATH + "newservcard_"+window._ysp_top.serviceNumberForCardName+".jpg";
			}
			f.Copy(picName);
			window._ysp_top.EinvoiceIdCardInfo.besservcard = "serv";
			// 添加水印
			addWatermarkText(picName);
		}
		if ("delegate" == kind) {
			picName = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newdelegatecard.jpg";
			// 如果是登录时有手机号，则记录手机号 c00311908
			if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
			{
				picName = CERT_IMAGE_ON_CLIENT_BASE_PATH + "newdelegatecard_"+window._ysp_top.serviceNumberForCardName+".jpg";
			}
			
			f.Copy(picName);
			window._ysp_top.EinvoiceIdCardInfo.besdelegcard = "delegate";
			// 添加水印
			addWatermarkText(picName);
		}
		debugger;
}

/**
 * 只有集团组在使用的方法，计划要删除
 * @version 1.0
 * @date 2016/05/24
 * @author l00185610 用于实现页面 AdMap 对象，Key只能是String，对象随意  计划要删除
 *
 */
var AdMap = function() {
	this._MapEntrys = new Array();

	this.put = function(key, value) {
		if (key == null || key == undefined) {
			return;
		}
		var index = this.getIndex(key);
		if (index == -1) {
			var entry = new Object();
			entry.key = key;
			entry.value = value;
			this._MapEntrys[this._MapEntrys.length] = entry;
		} else {
			this._MapEntrys[index].value = value;
		}
	};
	this.get = function(key) {
		var index = this.getIndex(key);
		return (index != -1) ? this._MapEntrys[index].value : null;
	};
	this.remove = function(key) {
		var index = this.getIndex(key);
		if (index != -1) {
			this._MapEntrys.splice(index, 1);
		}
	};
	this.clear = function() {
		this._MapEntrys.length = 0;
	};
	this.contains = function(key) {
		var index = this.getIndex(key);
		return (index != -1) ? true : false;
	};
	this.getCount = function() {
		return this._MapEntrys.length;
	};
	this.getEntrys = function() {
		return this._MapEntrys;
	};
	this.getIndex = function(key) {
		if (key == null || key == undefined) {
			return -1;
		}
		var _length = this._MapEntrys.length;
		for ( var i = 0; i < _length; ++i) {
			var entry = this._MapEntrys[i];
			if (entry == null || entry == undefined) {
				continue;
			}
			if (entry.key === key) {// equal
				return i;
			}
		}
		return -1;
	};
};

/**
 * 只有集团组在使用的方法，计划要删除
 * @version 1.0
 * @date 2016/05/24
 * @author l00185610 ad paramters 根据参数id获取参数值   计划要删除
 */
var AdParameter = function() {
	this._ParameterEntrys = new AdMap();

	/**
	 * 读取系统参数的值 varId ：请传 < '$Page.xxx' > 的格式；或者传function类型；或者传''
	 */
	this.read = function(paramId, defaultValue, varIdOrFunc) {
		debugger;

		if (!paramId) {
			return;
		}

		var $scope = $(document).scope();
		var $Page = $scope.$Page;

		var cachedIndex = this._ParameterEntrys.getIndex(paramId);
		if (-1 < cachedIndex) {
			var val = this._ParameterEntrys.getEntrys()[cachedIndex].value;
			if(varIdOrFunc){
				if (typeof varIdOrFunc === 'function'){
					varIdOrFunc(val);
				}else if(typeof defaultValue === 'string'){
					eval(varIdOrFunc + "=\'" + val + "\'");
				}else{
					eval(varIdOrFunc + "=" + val + "");
				}
			}
			return;
		}

		if(varIdOrFunc){
			if (typeof varIdOrFunc === 'function'){
				varIdOrFunc(defaultValue);
			}else if(typeof defaultValue === 'string'){
				eval(varIdOrFunc + "=\'" + defaultValue + "\'");
			}else{
				eval(varIdOrFunc + "=" + defaultValue + "");
			}
		}

		var paraObj = this;
		$Page.varAdParameterParamvalue = null;

		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
		$scope.$Get("$Fire")(
				{
					service : 'ucec/v1/common/qrysystemparambykey',
					params : {
						"key" : paramId
					},
					target : "$Page.varAdParameterParamvalue",
					onafter : function() {
						debugger;

						if(varIdOrFunc){
							if (typeof varIdOrFunc === 'function'){
								varIdOrFunc($Page.varAdParameterParamvalue);
							}else if(typeof defaultValue === 'string'){
								eval(varIdOrFunc + "=\'" + $Page.varAdParameterParamvalue + "\'");
							}else{
								eval(varIdOrFunc + "=" + $Page.varAdParameterParamvalue + "");
							}
						}

						paraObj._ParameterEntrys.put(paramId,
								$Page.varAdParameterParamvalue);

						delete $Page.varAdParameterParamvalue;
					},
					onerror : function() {
						debugger;

						delete $Page.varAdParameterParamvalue;
					}
				}, $scope);
	};

	this.value = function(paramId) {
		return this._ParameterEntrys.get(paramId);
	};
};

/**
 * 只有集团组在使用的方法，计划要删除
 * @version 1.0
 * @date 2016/05/24
 * @author l00185610 ad Dictionary 根据字典id获取枚举值   计划要删除
 */
var AdDictionary = function() {

	this._DictionaryEntrys = new AdMap();

	// 读取单个字典项
	this.read = function(dictCode, dictFunc, finalFunc) {
		debugger;

		if (!dictCode) {
			return;
		}

		var dictCodeList = [];
		dictCodeList.push(dictCode);

		this.readn(dictCodeList, dictFunc, finalFunc);
	};

	// 读取数组中多个字典项
	this.readn = function(dictCodeList, dictFunc, finalFunc) {
		debugger;

		if (!dictCodeList) {
			return;
		}

		var $scope = $(document).scope();
		var $Page = $scope.$Page;

		var cachedIndex = 0;
		for ( var n = 0; n < dictCodeList.length; ++n) {
			var cachedIndex = this._DictionaryEntrys.getIndex(dictCodeList[n]);
			if (-1 < cachedIndex) {
				if (typeof dictFunc === 'function'){
					dictFunc(dictCodeList[n], this._DictionaryEntrys.getEntrys(cachedIndex));
				}
				dictCodeList.splice(n, 1);
				--n;
			}
		}

		if (0 == dictCodeList.length) {
			return;
		}

		var paraObj = this;
		$Page.varAdDictMap = null;

		$scope.$Get("$Fire")({
			service : "/common/dictkey",
			params : {
				"dictkeylist" : dictCodeList
			},
			target : "$Page.varAdDictMap",
			onafter : function() {
				debugger;
				for ( var n = 0; n < dictCodeList.length; ++n) {
					var dictCode = dictCodeList[n];
					var dictItems = $Page.varAdDictMap[dictCode];
					var list = [];

					$.each(dictItems, function(i, val) {
						var obj = {
							"key" : val.itemCode,
							"value" : val.itemName,
							"ext1" : val.extMap.ext1,
							"ext2" : val.extMap.ext2
						};

						list.push(obj);
					});

					if (typeof dictFunc === 'function'){
						dictFunc(dictCode, list);
					}
					paraObj._DictionaryEntrys.put(dictCode, list);
				}
				// 从后台装载完成所有字典后的处理
				if (typeof finalFunc === 'function'){
					finalFunc();
				}
				delete $Page.varAdDictMap;
			},
			onerror : function() {
				debugger;

				delete $Page.varAdDictMap;
			}
		}, $scope);
	};

	this.items = function(dictCode) {
		return this._DictionaryEntrys.get(dictCode);
	};

	this.item = function(dictCode, key) {
		var oneItem = null;
		var allItems = this._DictionaryEntrys.get(dictCode);
		for ( var n = 0; n < allItems.length; ++n) {
			var oneItem = allItems[n];
			if(oneItem.key == key){
				return oneItem;
			}
		}
		return null;
	};
};

/**
 * 只有集团组在使用的方法，计划要删除
 * @version 1.0
 * @date 2016/08/24
 * @author l00185610 ad AdGroupType 根据产品类别读取业务特性  计划要删除
 */
var AdGroupBusinessCharacter = function() {
	this._prodcode = null;
	this._offeringId = null;
	this._hasLoadCommon = false;

	/**
	 * 加载当前产品对应的js. $offeringId来源于pm_offering.offering_id
	 * $prodcode来源于pm_product.prod_code
	 */
	this.load = function($prodcode, $offeringId){
		debugger;

		var ruleDef = [];
		// Commmon对应的bes-ad-ctz-grp-Common.js和bes-ad-grp-Common.js本可不动态加载，为避免代码碎片化放在这
		if(!this._hasLoadCommon){
			ruleDef.push('Common');
			this._hasLoadCommon = true;
		}
		if(this._prodcode != $prodcode){
			this._prodcode = $prodcode;
			ruleDef.push(this._prodcode);
		}
		if(this._offeringId != $offeringId){
			this._offeringId = $offeringId;
			ruleDef.push(this._offeringId);
		}

		var i;
		var cmdStr;
		// 移除之前包含的文件
		for(i = 0; i < ruleDef.length; ++i){
			// 定制
			try{
				cmdStr = "$(\"script[src$='bes-ad-ctz-grp-"+ruleDef[i]+".js']\").remove()";
				eval(cmdStr);
			}catch(exception){
				debugger;
			}
			// 基线
			try{
				cmdStr = "$(\"script[src$='bes-ad-grp-"+ruleDef[i]+".js']\").remove()";
				eval(cmdStr);
			}catch(exception){
				debugger;
			}

			// 定制
			try{
				cmdStr = window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp
				+ "/bes/ad/ctz/gadget/group/install/groupopen/bes-ad-grp-attrgroup/bes-ad-ctz-grp-"+ruleDef[i]+".js";

				$("<script>").attr({
					type: "text/javascript",
					src: cmdStr
				}).appendTo("head");
			}catch(exception){
				debugger;
			}
			// 通用
			try{
				// 基线
				cmdStr = window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp
				+ "/bes/ad/gadget/group/install/groupopen/bes-ad-grp-attrgroup/bes-ad-grp-"+ruleDef[i]+".js";

				$("<script>").attr({
					type: "text/javascript",
					src: cmdStr
				}).appendTo("head");
			}catch(exception){
				debugger;
			}
		}
	};

	/**
	 * 执行指定的业务--$business来源于select t.item_code from sys_datadict_item t where
	 * t.dict_code='OM_BUSINESS_CODE' and t.item_code like 'Group%';或者自定义
	 * 这是一个多态的实现
	 */
	this.process = function($Page, $Gadget, $Fire, $business){
		debugger;

		// 如果入参不合法
		if(!$business){
			return;
		}

		var ruleDef = ['Common'];
		if(this._prodcode){
			ruleDef.push(this._prodcode);
		}
		if(this._offeringId){
			ruleDef.push(this._offeringId);
		}

		var i;
		var cmdStr;
		// 搜索顺序：通用->prodcode->offering
		for(i = 0; i < ruleDef.length; ++i){
			try{
				cmdStr = "$Controller.bes.ad.ctz.grp." + ruleDef[i] + "." + $business + "($Page, $Gadget, $Fire)";
				eval(cmdStr);
			}catch(exception){
				try{
					cmdStr = "$Controller.bes.ad.grp." + ruleDef[i] + "." + $business + "($Page, $Gadget, $Fire)";
					eval(cmdStr);
				}catch(exception){
					debugger;
				}
			}
		}
	};
};

var adutil = {

	/*
	 * 读取系统参数的服务(禁止做任何系统参数WEB端缓存的改造)
	 *
		由于 UEE的服务调用都是异步的，因此JS中不能通过类似如下的方式来直接获取系统参数值
		var item_value = call_getItemValue(item_id);
		必须通过异步的方式获取系统参数结果。

		使用方法1：传三个参数，适用于代码中获取到系统参数后，在回调函数中使用系统参数的返回结果

		// 其中ITEMID1,ITEMID2,ITEMID3,ITEMID4表示可以一次性同时查询多个系统参数，此处可以只传单个系统参数ID
		adutil.querySysParams("ITEMID1,ITEMID2,ITEMID3,ITEMID4", $Gadget, function(){

			// 系统参数 ITEMID1 的VALUE保存在$Gadget.sysparamResult["ITEMID1"]中
			alert($Gadget.sysparamResult["ITEMID1"]);
			alert($Gadget.sysparamResult["ITEMID2"]);
			alert($Gadget.sysparamResult["ITEMID3"]);
			alert($Gadget.sysparamResult["ITEMID4"]);
		});
					

		使用方法2： 传两个参数，适用于不需要立即使用系统参数的值，例如在后续的方法中使用、在HTML页面中使用，则可以不传回调函数

		adutil.querySysParams("ITEMID1", $Gadget); 


		// 系统参数ITEMID1的VALUE保存在$Gadget.sysparamResult["ITEMID1"]中，但是不是立即就能获取到，因此如果在当前JS方法中立即使用系统参数的返回结果，只能使用使用方法1

		说明，以下使用方式是不正确的

		adutil.querySysParams("ITEMID1", $Gadget); 

		// $Gadget.sysparamResult["ITEMID1"] 的结果不会立即获取到，以下的代码逻辑是错误的。
		if ($Gadget.sysparamResult["ITEMID1"] == xxx)
		{
		.....
		}

	 */
	querySysParams : function(KEYS, $ResultScope, callBackFunc)
	{
		debugger;

		var keyArray = KEYS.split(",");

		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');
 
		var callBackFunc = callBackFunc || function() {};

        $Fire({
            service: 'ucec/v1/common/qrysystemparamlistbykey',
            params: {
            	keylist : keyArray
            },
            target: 'sysParamList',
        }, $scope).onafter(function(sysParamList){
    		debugger;
			var KEYS = "";
			var resp = {};

			angular.forEach(sysParamList, function(val, index){
				resp[keyArray[index]] = val;
			});

			$ResultScope.sysparamResult = $ResultScope.sysparamResult || {};
			angular.extend($ResultScope.sysparamResult, resp);

			callBackFunc();
		});
	},

	/*
	 * 读取操作员权限的方法(禁止做任何操作权限WEB端缓存的改造)
	 *
		方法名称：adutil.checkLoginAuths 具体使用说明如下：

		由于 UEE的服务调用都是异步的，因此JS中不能通过类似如下的方式来直接获取操作员的权限值

		var auth_value = call_getItemValue(auth_id);

		必须通过异步的方式获取权限结果。


		使用方法1：传三个参数，适用于代码中获取到操作员权限后后立即在回调函数中根据操作员权限的结果进行逻辑判断，相关逻辑判断写在回调函数中
			
		adutil.checkLoginAuths("AUTHID1,AUTHID2", $Gadget, function(){
		
			// 操作员的权限AUTHID1的返回结果会放在$Gadget.operatorAuth["AUTHID1"]中，如果当前操作员具备该权限，则Gadget.operatorAuth["AUTHID1"]的值为"Y",没有权限返回结果是"N"
			alert($Gadget.operatorAuth["AUTHID1"]);
			alert($Gadget.operatorAuth["AUTHID2"]);
		});
		
		使用方法2： 传两个参数，适用于不需要立即使用操作员权限的值，例如在后续的方法中使用、在HTML页面中使用，则可以不传回调函数   
		adutil.checkLoginAuths("AUTHID1", $Gadget); 

		// 操作员令牌AUTHID1的结果保存在$Gadget.operatorAuth["AUTHID1"]中，但是不是立即就能获取到，因此如果在当前JS方法中立即使用权限的返回结果，只能使用使用方法1    
		
		说明，以下使用方式是不正确的
		adutil.checkLoginAuths("AUTHID1", $Gadget); 

		if ($Gadget.operatorAuth["AUTHID1"] == "Y")
		{
		...
		}
		// 操作员令牌AUTHID1的结果保存在$Gadget.operatorAuth["AUTHID1"]中，但是不是立即就能获取到，因此如果在当前JS方法中立即使用权限的返回结果，只能使用使用方法1    

	 *
	 */
	checkLoginAuths: function(AUTHS, $ResultScope, callBackFunc)
	{
		debugger;

		var authArray = AUTHS;

		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');

		var callBackFunc  = callBackFunc || function(){};

        $Fire({
            service: 'ocauthenticationboservice/checkauthbyloginidauth',
            params: {
            	req : authArray
            },
            target: 'authsList',
        }, $scope).onafter(function(authsList){
    		debugger

			if (authsList) {
				var auths = authsList.split(","); // 字符分割

				var resp = {};

				for ( var i = 0; i < auths.length; i++) {
					var auth = auths[i];
					var authID = auth.split("^")[0];
					var isExist = auth.split("^")[1];

					resp[authID] = isExist
				}

				$ResultScope.operatorAuth = $ResultScope.operatorAuth || {};
				angular.extend($ResultScope.operatorAuth, resp);
			}

			callBackFunc()}
        );
	},

	/*
	 * 获取数据字典的方法(禁止做任何数据字典WEB端缓存的改造)
	 *
		方法名称：adutil.queryDataDicts 方法使用说明如下：

		由于 UEE的服务调用都是异步的，因此JS中不能通过类似如下的方式来直接获取字典

		var dict = call_getDateDict(dictCode);

		必须通过异步的方式获取字典结果。



		使用方法1：传三个参数，适用于代码中获取到字典数据后后立即在回调函数中根据操作员权限的结果进行逻辑判断，相关逻辑判断写在回调函数中
		adutil.queryDataDicts("DICT_CODE1,DICT_CODE2", $Gadget, function(){

			// DICT_CODE1,DICT_CODE2这两个字典的返回结果会被存放在
			$Gadget.dictList["DICT_CODE1"]和$Gadget.dictList["DICT_CODE2"]中
		});

			// 其中$Gadget.dictList["DICT_CODE1"]的具体内容如下
			[{
			"key": "key1",
			"value": "value1"
			},
			{
			"key": "key2",
			"value": "value2"
			},
			{
			"key": "key3",
			"value": "value3"
			}]

			
		使用方法2：传两个参数，适用于不需要立即使用数据字典的值，例如在后续的方法中使用、在HTML页面中使用，则可以不传回调函数

		adutil.queryDataDicts("DICT_CODE1", $Gadget);


		// 返回结果存放在$Gadget.dictList["DICT_CODE1"] 中  

		以下的使用方式是不正确的

		adutil.queryDataDicts("DICT_CODE1", $Gadget);

		// 异步调用的服务，不会立即返回结果，此时立即使用返回结果将无法获取到对应的字典信息
		alert($Gadget.dictList["DICT_CODE1"]);
	 */
	queryDataDicts : function(DATADICTS, $ResultScope, callBackFunc)
	{
		debugger;

		var dataDictsArray = DATADICTS.split(",");

		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');

		$ResultScope = $ResultScope || $scope.$Page;
		var callBackFunc = callBackFunc || function(){};

        $Fire({
            service: '/common/dictkey2',
            params: {
            	'dictkeylist' : dataDictsArray
            },
            target: 'dataDictList'
        }, $scope).onafter(function(dataDictList){
    		debugger
			
			$ResultScope.dictList = $ResultScope.dictList || {};
			angular.extend($ResultScope.dictList, dataDictList);
    		callBackFunc();}
        );
	},

    /*
     * 截取URL中特定属性值的方法，此方法适用于通过URL传属性值的场景
     *
     * 例如：
     * 当前URL的地址是
     * https://10.171.48.187:19999/oc/bes/ad/html/ctz.bes-agentdesktop-openaccount.html?&offeringId=1000100301&quickPickRoutePath=undefined&isAgentCreateSubs=false&#/openaccount
     *
     * 在JS中调用方法：
     * adutil.getQueryStringByName("isAgentCreateSubs")  可以获得值是"false"
     * adutil.getQueryStringByName("quickPickRoutePath")  可以获得值是"undefined"
     * adutil.getQueryStringByName("noThisString")  可以获得值是 ""（不存在的属性）
     *
     * 如果URL中有两个相同名字的属性，会取第一个值返回
     *
     */
	getQueryStringByName : function(key) {
		var result = location.search.match(new RegExp("[\?\&]" + key
				+ "=([^\&]+)", "i"));
		if (result == null || result.length < 1) {
			return "";
		}

		return decodeURI(result[1]);
	},

	/*
	 * JS中全角字符转半角字符
	 *
	 * 使用方法：
	 * adutil.toSBC("Ｈｅｌｌｏ　你好　１２３　！＠＃")
	 * 输出结果："Hello 你好 123 !@#"
	 *
	 */
	toSBC : function(str) {
		var result = "";
		var len = str.length;
		for ( var i = 0; i < len; i++) {
			var cCode = str.charCodeAt(i);
			// 全角与半角相差（除空格外）：65248（十进制）
			cCode = (cCode >= 0xFF01 && cCode <= 0xFF5E) ? (cCode - 65248)
					: cCode;
			// 处理空格
			cCode = (cCode == 0x03000) ? 0x0020 : cCode;
			result += String.fromCharCode(cCode);
		}
		return result;
	},

	/*
	 * JS中半角字符转全角字符
	 *
	 * 使用方法：
	 * adutil.toDBC("Hello 你好 123 !@#")
	 * 输出结果："Ｈｅｌｌｏ　你好　１２３　！＠＃"
	 */
	toDBC : function(str) {
		var result = "";
		var len = str.length;
		for ( var i = 0; i < len; i++) {
			var cCode = str.charCodeAt(i);
			// 全角与半角相差（除空格外）：65248(十进制)
			cCode = (cCode >= 0x0021 && cCode <= 0x007E) ? (cCode + 65248)
					: cCode;
			// 处理空格
			cCode = (cCode == 0x0020) ? 0x03000 : cCode;
			result += String.fromCharCode(cCode);
		}
		return result;
	},

	/*
	 * 方法名称 ： adutil.getNextNumber()  JS中生成数字占位符的方法
		应用场景： AD拼订单报文的时候会需要在前台生成orderItemId字段，并且在子节点中可能会有relaItemId字段，需要同对应的orderItemId字段建立关联。生成的序列号不要求永远不重复，只要保证在一次调用的时候同报文内部不冲突就可以。
		本方法不适用于生成永远不重复的序列号。
		web端不建议生成序列号，如果代码中有生成序列号的需求，请在Java端生成。
	 */
	number : 100000000,

	getNextNumber : function() {
		return adutil.number++;
	},

	/*
	 * JS中清除属性值及其引用的方法
	 *
	   方法名称adutil.clearObj($Gadget.choosed);  ---其中$Gadget.choosed 为需要被清除属性的方法

	   说明：adutil.clearObj($Gadget.choosed); 同 $Gadget.choosed = {}; 的区别

	   $Gadget.choosed = {};
	   $Gadget.choosed.attrA = 1;
	   $Gadget.choosed.attrB = "ABC";

	   $Gadget.choosedCopy = $Gadget.choosed; ---将$Gadget.choosed的地址指向

	   $Gadget.choosedCopy = {};

	   执行 $Gadget.choosedCopy 命令，返回结果为 {}
	   执行 $Gadget.choosed 命令，返回结果为{attrA: 1, attrB: "ABC"}

	   $Gadget.choosedCopy = $Gadget.choosed; ---将$Gadget.choosed的地址指向

	   adutil.clearObj($Gadget.choosedCopy);

	   执行 $Gadget.choosedCopy 命令，返回结果为 {}
	   执行 $Gadget.choosed 命令，返回结果为 {}
	 *
	 */
	clearObj : function(obj) {
		if (obj) {
			for ( var i in obj) {
				delete obj[i];
			}
		}
	},

	/*
	 * 在下拉列表数组中，根据key获取value的方法
	 *
	 * 应用场景：在JS中选择了下拉列表中某个元素的key后，需要获取下拉列表中这个key对应的属性值
	 * 说明：
	 * 第一个参数 dropList 为数组对象，其中每个元素都是一个包含key、value属性的对象
	 * 例如：$Gadget.dictList["OC.AREA.TYPE"] 的内容为 [{"key":"99","value":"江苏"},{"key":"14","value":"南京"},{"key":"19","value":"无锡"}]
	 *
	 * 使用方法 adutil.getDropValueByKey($Gadget.dictList["OC.AREA.TYPE"], "99")
	 *
	 * 可以获得key "99"所对应的value"江苏"
	 *
	 *
	 * 第一个参数dropList数组对象的生成方法
	 * adutil.queryDataDicts("OC.AREA.TYPE", $Gadget);
	 *
	 */
	getDropValueByKey : function(dropList, key) {
		var value = "";
		$.each(dropList || [], function(i, vali) {
			if (key == vali.key) {
				value = vali.value;
				return false;
			}
		});
		return value;
	},

	/*
	 *  根据用户服务号码、用户ID、beid获取用户信息的方法
	 *
	 *  调用方法范例如下
	 *
	 *  var subsInfo = {
			serviceNum : "15153800273",
			idNo : "53899101000244013",
			beId : "538"
		}

		adutil.querysubscriber(subsInfo, function(subsuserInfo){

			debugger;

			if (subsuserInfo)
			{
				$Gadget.subsuserInfo = subsuserInfo;

				lert(JSON.stringify($Gadget.subsuserInfo));
			}
			else
			{
				// 未根据服务号码查询到数据
				$UI.msgbox.error($UEE.i18n("ad.person.message.information"),
				$UEE.i18n("ad.person.message.NoInformationForUser"));
			}
		});

		返回结果：
		{
		    "subsBaseInfo": {},
		    "realNameInfo": {},
		    "custBaseInfo": {},
		    "subsRelaInfo": {},
		    "subscriberInfo": {} ,
		    "extInfos": {}
		}

		说明：
		调用入参中，serviceNum、idNo 必传其一，否则返回结果为null
		传入serviceNum，可以不传beId，会在sys_servicenum_region 中查找（不会在上下文中获取操作员的beId），如果查询不到，直接返回null
		如果不传serviceNum,就必须同时传入idNo和beId

		服务中会调用
		SubscriberQueryFacadeService.querySubscriber  ---对应返回结果中的  "subscriberInfo": {}
		QueryCustSubsInfoBOService.qrySubsIntegrativeInfo   ---对应返回结果中的 "subsBaseInfo": {},"realNameInfo": {},"custBaseInfo": {},"subsRelaInfo": {},

		代码中预留了扩展点用户扩展局点个性返回信息

        Request extReq = ExtensionHelper.createRequest();
        extReq.setPointCode("querySubscriberEX");
        extReq.addParameter("request", request);
        extReq.addParameter("response", response);
        ExtensionHelper.getExtensionService().fire(extReq);

		扩展点信息的结果保留在 "extInfos": {} 中
	 */
	querysubscriber : function(subsInfo, callBackFunc)
	{
		debugger;

		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');
		var $UI = $scope.$UI;

    	$Fire(
		{
			'service' : 'querysubsinfoboservice/querysubscriber',
			'params' : {
				request : {
					serviceNum : subsInfo.serviceNum,
					idNo : subsInfo.idNo,
					beId : subsInfo.beId
				}
			},
			'target' : 'subsInfo.subscriberInfo',
			'onafter' : function(subsInfo) {

				debugger;

				if (subsInfo.subscriberInfo) {
					callBackFunc(subsInfo.subscriberInfo);
				}
				else
				{
					callBackFunc();
				}
			}
		}, $scope);
	},

	/*
	 * 国内用于记录敏感信息查询的方法
	 * 应该使用场景不是很多了
	 */
    log4QuerySensitiveInfo: function($Gadget, params, callBackStr) {
        //debugger;
        var basic = {
            "menuId": $BES.$Portal.tabpanel.getTabItem().key,
            "note": $BES.$Portal.tabpanel.getTabItem().title
        };
        var req = $.extend(basic, params);
        //ad.common.message.SecurityAuditRemind=该操作为信息安全敏感操作，若点击“是”将被记录操作日志，请保留操作依据以备审计，无须操作请点击“否”。
        var $UI = $Gadget.$Get("$UI");
        $UI.msgbox.confirm($UEE.i18n("ad.group.message.MSGBOXINFO"), $UEE.i18n("ad.common.message.SecurityAuditRemind"),
            function() {
                //记录操作日志
                $Fire({
                    "service": "/bes.agentdesktop.group.common.groupcommonservice/log4QuerySensitiveInfo",
                    "params": {
                        "req": req
                    },
                    "target": "$Gadget.log4QuerySensitiveInfoResult",
                    "onafter": function() {
                    	try {
                    		eval (callBackStr);
                    	} catch (e) {
                    		debugger;
                    	}
                    }
                },
                $Gadget);

            });
    },

	// 获取语言信息 init方法需要依赖$Page.contextInited
	getLocale: function(){
	    try {
	        return $(document).scope().$Global.$Lang() || "zh_CN";
	    } catch (e) {
	        return "zh_CN";
	    }
	},

	// 获取操作员BEID init方法需要依赖$Page.contextInited
	getBeId: function(){
		return $(document).scope().$Page.contextInfo.operBeId;
	},

	// 获取操作员的工号 init方法需要依赖$Page.contextInited
	getLoginId: function(){
		return $(document).scope().$Page.contextInfo.loginId;
	},

	// 获取操作员的账号 init方法需要依赖$Page.contextInited
	getOperId: function(){
		return $(document).scope().$Page.contextInfo.createOperId;
	},

	// 获取操作员BECODE init方法需要依赖$Page.contextInited
	getBeCode: function(){
		return $(document).scope().$Page.contextInfo.beCode;
	},

	// 获取操作员的渠道ID init方法需要依赖$Page.contextInited
	getChannelId: function(){
		return $(document).scope().$Page.contextInfo.channelId;
	},

	// 获取操作员的regionId init方法需要依赖$Page.contextInited
	getRegionId: function(){
		return $(document).scope().$Page.contextInfo.regionId;
	},

	// 获取操作员的regionId init方法需要依赖$Page.contextInited
	getDeptId: function(){
		return $(document).scope().$Page.contextInfo.createDeptId;
	},

	globalData : {},

    /**
     * 计算字符串长度的方法
     * 通过adutil.countCharacters(test1) 方法来获取文本长度，效果同test1.len()  不推荐使用。
     *
     * @param str
     * @returns {number}
     */
    countCharacters : function(str) {
        debugger;
        var totalCount = 0;
        for ( var i = 0; i < str.length; i++) {
            var c = str.charCodeAt(i);
            if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
                totalCount++;
            } else {
                totalCount += 2;
            }
        }

        return totalCount;
    },

    /**
     * 验证特殊字符的，可以包含·•
     */
    containSBCCaseChar : function(value) {
        var reg = /\￥|\…|\……|\（|\）|\—|\——|\、|\【|\】|\；|\：|\’|\‘|\“|\”|\，|\《|\》|\。|\？|\〖|\〗|\［|\］|\｛|\｝|\』|\『|\」|\「|\》|\《|\〉|\〕|\〈|\〔|\々|\～|\‖|\∶|\＂|\＇|\｀|\｜|\〃|\¨|\ˉ|\#|\~|\!|\@|\%|\^|\&|\*|\+|\=/;
        return reg.test(value);
    },

    /**
     * 验证特殊字符的，不可以包含·•
     */
    containSBCCaseCharAll : function(value) {
        var reg = /\·|\•|\￥|\…|\……|\（|\）|\—|\——|\、|\【|\】|\；|\：|\’|\‘|\“|\”|\，|\《|\》|\。|\？|\〖|\〗|\［|\］|\｛|\｝|\』|\『|\」|\「|\》|\《|\〉|\〕|\〈|\〔|\々|\～|\‖|\∶|\＂|\＇|\｀|\｜|\〃|\¨|\ˉ|\#|\~|\!|\@|\%|\^|\&|\*|\+|\=/;
        return reg.test(value);
    },
    
    /**
     * 验证汉字，输入的内容中不允许有汉字
     */
    validataChina : function(value){
    	var reg = /[^\x00-\xff]/;
    	return reg.test(value);
    },
    
    /**
     * 校验空格
     */
    validataTab :function(value){
    	var reg = /\s/;
    	return reg.test(value);
    },

    /**
     * 数字验证，验证输入的内容中只能包含数字
     */
    checkNumberChar : function(value) {
        debugger;
        var reg = /^[0-9]*$/;
        return reg.test(value);
    },
    
    /**
     * 只能输入空格和字母,不允许输入数字
     */
    checkNumberChar1 : function(value) {
        debugger;
        var reg = /^[ A-Za-z,]*$/;
        return reg.test(value);
    },
    /**
     * 只能输入汉字和字母,不允许输入数字
     */
    checkNumberChar2 : function(value) {
        debugger;
        var reg =/^([A-Za-z\u4E00-\u9FA5]|\•|\·)*$/;
        return reg.test(value);
    },
    
    /**
     * 校验包含几个汉字,其中汉语字符也算是一个汉字
     */

    countChineseCharacters: function(str) {
        var totalCount = 0;
        if (!str) {
            return totalCount;
        }
        for (var i = 0; i < str.length; i++) {
            if (str.charCodeAt(i) > 255) {
                totalCount++;
            }
        }
        return totalCount;
    },

    /**
     * 处理UCEC服务返回的方法，不推荐使用
     * @param response
     * @param $UI
     * @returns {boolean}
     */
    handleFireResponse : function(response,$UI)
    {
        if(!response)
        {
            $UI.msgbox.error("异常","服务调用异常");
            return false;
        }
        if(response.header.resultCode != '0')
        {
            $UI.msgbox.error("异常",response.header.resultMessage);
            return false;
        }
        return true;
    },
    // 打开推荐内容弹框   尝试优化一下
    openRecommendConten: function($Page, orderId) {
        debugger;
        var isCSP = $.cookie("bsacKF");
        if (null != isCSP && "NGCRM_CSP" == isCSP) {
            return;
        }

        if ($Page.businessCode && $Page.businessCode == 'CreateSubscriber') {
            return;
        }

        if (!orderId || orderId.length == 0) {
            return;
        }
        // $Gadget.PromotionInfo.orderId = orderId;
        var $rootScope = $(document).scope();
        var $Fire = $rootScope.$Get('$Fire');

        $Fire({
            service: '/agentdesktop/v1/person/queryRecommendContentInfo',
            params: {},
            target: "data"
        }).onafter(function(data) {
            debugger;
            data.body.servNumber=window._ysp_top.serviceNumber;
            if (!data || !data.body || !data.body.recommendList||!data.body.recommendList.length|| !data.body.servNumber||!window._ysp_top.serviceNumber) {
                return false;
            }
            $Page.recommendList = data.body.recommendList;

            //排序
            $Page.recommendList.sort(function(a,b) {
                if (!a.sortOrder) {
                    return 1;
                }
                return b.sortOrder - a.sortOrder;
            });

            // 只显示10条
            var recommendNum = $Page.recommendList.length;
            if (recommendNum > 10)
            {
                for (var index = 11; index <= recommendNum; index++)
                {
                    $Page.recommendList.pop();
                }
            }

            $Fire({
                "popup": {
                    "id": "offerSetPopup",
                    "title": $UEE.i18n('ad.person.lable.YWTJ'),
                    "width": "800px",
                    "height": "500px",
                    "src": "resource.root/bes/ad/popup/bes-ad-RecommendConten.html",
                    "resizable": "false"
                }
            });
        });
    },

    loadXML : function(xmlString) {
        var xmlDoc = null;
        // 判断浏览器的类型
        // 支持IE浏览器
        if (!window.DOMParser && window.ActiveXObject) { // window.DOMParser
            // 判断是否是非ie浏览器
            var xmlDomVersions = [ 'MSXML.2.DOMDocument.6.0',
                'MSXML.2.DOMDocument.3.0', 'Microsoft.XMLDOM' ];
            for ( var i = 0; i < xmlDomVersions.length; i++) {
                try {
                    xmlDoc = new ActiveXObject(xmlDomVersions[i]);
                    xmlDoc.async = false;
                    xmlDoc.loadXML(xmlString); // loadXML方法载入xml字符串
                    break;
                } catch (e) {
                }
            }
        }
        // 支持Mozilla浏览器
        else if (window.DOMParser && document.implementation
            && document.implementation.createDocument) {
            try {
                /*
                 * DOMParser 对象解析 XML 文本并返回一个 XML Document 对象。 要使用
                 * DOMParser，使用不带参数的构造函数来实例化它，然后调用其 parseFromString() 方法
                 * parseFromString(text, contentType) 参数text:要解析的 XML 标记
                 * 参数contentType文本的内容类型 可能是 "text/xml" 、"application/xml" 或
                 * "application/xhtml+xml" 中的一个。注意，不支持 "text/html"。
                 */
                domParser = new DOMParser();
                xmlDoc = domParser.parseFromString(xmlString, 'text/xml');
            } catch (e) {
            }
        } else {
            return null;
        }

        return xmlDoc;
    },

    // 取URL中参数的方法
    getParam : function(param) {
        var url = location.href;
        var paraString = url.substring(url.indexOf("?") + 1, url.length).split(
            "&");
        var paraObj = {};
        for ( var i = 0; i < paraString.length; i++) {
            var j = paraString[i];
            paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j
                .substring(j.indexOf("=") + 1, j.length);
        }

        var returnValue = paraObj[param.toLowerCase()];
        if (typeof (returnValue) == "undefined") {
            return "";
        } else {
            return returnValue;
        }
    },

    // 取URL参数的方法
    getParamInUrl : function(param, url) {
        var paraString = url.substring(url.indexOf("?") + 1, url.length).split(
            "&");
        var paraObj = {};
        for ( var i = 0; i < paraString.length; i++) {
            var j = paraString[i];
            paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j
                .substring(j.indexOf("=") + 1, j.length);
        }

        var returnValue = paraObj[param.toLowerCase()];
        if (typeof (returnValue) == "undefined") {
            return "";
        } else {
            return returnValue;
        }
    },

    // 解决得到参数为"null"/"undefined"问题
    // 也是取URL参数的方法
    getParam2 : function(param) {
        var url = location.href;
        var paraString = url.substring(url.indexOf("?") + 1, url.length).split(
            "&");
        var paraObj = {};
        for ( var i = 0; i < paraString.length; i++) {
            var j = paraString[i];
            paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j
                .substring(j.indexOf("=") + 1, j.length);
        }

        var returnValue = paraObj[param.toLowerCase()];
        if (typeof (returnValue) == "undefined") {
            return "";
        } else if(returnValue == "null" || returnValue == "undefined"){
            return "";
        } else {
            return returnValue;
        }
    },

    /**
     * 获取url参数值
     *
     * @param menuUrl
     * @param name
     * @returns
     */
    getUrlParam : function(menuUrl, name)
    {
        // debugger;
        var reg = new RegExp("(^|\\?|&)"+name+"=([^&#]*)([&#]|$)","i");
        var url = menuUrl || '';
        var r = url.match(reg);
        if (r!=null)
        {
            return unescape(r[2]);
        }
        else
        {
            return null;
        }
    },

    /**
     * @param menuUrl
     *            目标url
     * @param name
     *            需要替换的参数名称 若不包含改参数，则添加
     * @param val
     *            替换后的参数的值 若为null，表示删除该参数
     * @returns {String} 参数替换后的url 若替换出错返回空字符串
     */
    changeUrlParam : function(menuUrl, name, val){
        // debugger;
        var pattern='/('+ name.toLocaleLowerCase() + '=)([^&]*)/gi';
        var ret = '';

        if(!menuUrl||!name)
        {
            return ret;
        }

        // 删除参数
        if(!val)
        {
            ret = menuUrl.replace(eval(pattern),'');
            ret = ret.replace(/&&+/g,'&');
            ret = ret.replace(/\?&/,'?');
            ret = ret.replace(/&$/,'');
            ret = ret.replace(/\?$/, '');
            return ret;
        }

        // 修改参数值
        var replaceText = name.toLocaleLowerCase() + '=' + escape(val);
        // menuUrl已包含该参数
        if(menuUrl.match(eval(pattern)))
        {
            ret = menuUrl.replace(eval(pattern),replaceText);
        }
        // menuUrl未包含该参数
        else
        {
            if(menuUrl.match('[\?]'))
            {
                ret = menuUrl+'&'+replaceText;
            }
            else
            {
                ret = menuUrl+'?'+replaceText;
            }
        }
        return ret;
    },

    // 从浏览器获取参数值 不推荐用了
    request : function(param) {
        var url = location.href;

        var paraString = url.substring(url.lastIndexOf("?") + 1, url.length)
            .split("&");
        var paraObj = {};

        for ( var i = 0; i < paraString.length; i++) {
            var j = paraString[i];
            paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j
                .substring(j.indexOf("=") + 1, j.length);
        }

        var returnValue = paraObj[param.toLowerCase()];

        if (typeof (returnValue) == "undefined") {
            return "";
        } else {
            return returnValue;
        }
    },


    // 不知道啥错用，不推荐继续使用了
    bindCloseBtn : function() {
        /* 弹出框关闭 */
        $(document).on("click", ".windowBox .closeBox", function() {
            $(this).closest('.fullcover').hide();
        });
        /* 整合win_box样式 */
        $(document).on("click", ".win_box .closeBox", function() {
            $(this).closest('.fullcover').hide();
        });

        $(document).on("mousewheel", ".fullcover", function() {
            return false;
        });
    },

    // 设置控件长度限制
    limitInputLength : function(obj, length) {
        obj.bind('input propertychange', function() {
            if ($(this).val().length > length) {
                $(this).val($(this).val().substr(0, length));
            }
        });
    },

    inputKeypress : function(obj, jEvent, reg) {
        debugger;
        var value = "";
        value = obj.val();

        // 获取当前鼠标的位置
        var oTxt1 = obj[0];
        var startPosition = -1;
        var endPosition = -1;
        if (oTxt1.selectionStart || oTxt1.selectionStart == 0) {// 非IE浏览器
            startPosition = oTxt1.selectionStart;
            endPosition = oTxt1.selectionEnd;
        } else {// IE
            if (!document.selection) {
                startPosition = 0;
                endPosition = 0;
            } else {
                var range = document.selection.createRange();
                var len = range.text.length;
                range.moveStart("character", -oTxt1.value.length);
                endPosition = range.text.length;
                startPosition = endPosition - len;
            }
        }

        var preStr = value.substring(0, startPosition);
        var backStr = value.substr(endPosition);
        value = preStr + String.fromCharCode(jEvent.keyCode) + backStr;

        if (!reg.test(value)) {
            event.returnValue = false;
			// event.returnValue是IE的私有机制，从IE9开始已经废弃
			if (event.preventDefault) {
				event.preventDefault();
			}
            return;
        }
    },

    // 根据Gadget选择器获取该$Gadget对象，不存在则返回null.
    getGadgetObj : function($Selector) {
        try {
            return $Selector.scope().$$childTail.$Gadget;
        } catch (e) {
            return null;
        }
    },

    // 检查返回是否成功
    checkResponse : function(response, $UI) {
        if (response.respBase.resultCode == 0) {
            return true;
        } else {
            $UI.msgbox.error($UEE.i18n("ad.person.message.information"), response.respBase.resultReason);
            return false;
        }
    },

    // 检查ucec层接口返回结果是否成功
    checkUcecResp : function(respHeader, $UI) {
        if (!respHeader) {
            // "接口数据返回失败"
            $UI.msgbox.error($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.FailedReturnInterfaceData"));
            return false;
        } else if (respHeader.resultCode != 0) {
            // 接口数据返回失败
            $UI.msgbox.error($UEE.i18n("ad.person.message.information"), respHeader.resultMessage || $UEE.i18n("ad.person.message.FailedReturnInterfaceData"));
            return false;
        } else {
            return true;
        }
    },

    // 检查CreateOrder接口的返回信息
    checkCreateOrderRetInfo : function(orderResp, $UI, $Fire, $Page, reCreateorderCallBack) {
        /**
         * 流控提示标志
         */
        var FLOWCONTROLFLAG = "FlowControlFlag";
        if (orderResp && orderResp.body) {
            if (orderResp.body.retMessage == FLOWCONTROLFLAG) {
                $UI.msgbox.confirm($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.flowControl"), function() {
                    reCreateorderCallBack();
                }, function() {
                    $UI.msgbox.error($UEE.i18n("ad.person.message.error"), $UEE.i18n("ad.person.message.systemBusy"));
                });
                return false;
            }
        }

        return true;
    },

    // 通用订单校验返回是否成功,通用校验场景，出现的弹出框为error型和confirm型
    checkBusiValidResp : function($Gadget, $UI, busiValidResp,
                                  warningConfirmCb, warningCancelCb, errorCb, dialogTitle) {
        debugger;
        var wanConfirmCb = null // error级别校验成功，但是出现warning或者info级别的校验失败时，点击confirm弹出框的确定时的回调
        var wanCancelCb = null; // 出现warning级别校验失败时，点击confirm弹出框的cancel按钮或者点击右上角叉号时的回调
        var errCb = null; // error级别校验失败，关闭error弹出框的回调
        var fontList = [ "<font color='#333'>", "<font color='#333'>",
            "<font color='#333'>", "<font color='#EC4E5C'>" ];

        if ($Gadget) {
            if (warningConfirmCb) {
                wanConfirmCb = function() {
                    $Gadget.$safeApply($Gadget,warningConfirmCb);
                };
            }

            if (warningCancelCb) {
                wanCancelCb = function() {
                    $Gadget.$safeApply($Gadget,warningCancelCb);
                };
            }

            if (errorCb) {
                errCb = function() {
                    $Gadget.$safeApply($Gadget,errorCb);
                };
            }
        } else {
            wanConfirmCb = warningConfirmCb;
            wanCancelCb = warningCancelCb;
            errCb = errorCb;
        }

// if (!busiValidResp || !busiValidResp.returnMessage) {
// //"业务校验失败", "无响应报文。"
// $UI.msgbox.error($UEE.i18n("ad.person.message.FailedVerifyBusiness"),
// $UEE.i18n("ad.person.message.NoResponse"), errCb, errCb, errCb);
// return false;
// }
        // 修改bug单*DTS2016040509387
        if(!busiValidResp)
        {
            //
            $UI.msgbox.error($UEE.i18n("ad.person.message.FailedVerifyBusiness"), $UEE.i18n("ad.person.message.signInAgain"), errCb, errCb, errCb);
            return false;
        }
        else if(!busiValidResp.returnMessage)
        {
            $UI.msgbox.error($UEE.i18n("ad.person.message.FailedVerifyBusiness"), $UEE.i18n("ad.person.message.NoResponse"), errCb, errCb, errCb);
            return false;
        }else{

        }
        var returnMessage = busiValidResp.returnMessage;
        dialogTitle = dialogTitle || $UEE.i18n("ad.person.message.information");
        var messageCount = 0;
        var message = null;

        if (returnMessage.busiValidateResult) {
            for ( var i = 0; i < returnMessage.busiValidateResult.length; i++) {
                if (returnMessage.busiValidateResult[i].promptMessage) {
                    if (messageCount == 0) {
                        message = fontList[returnMessage.busiValidateResult[i].level]
                            + returnMessage.busiValidateResult[i].promptMessage
                            + "</font>";
                    } else {
                        message = message
                            + "<br>-----------------------------------------<br>"
                            + fontList[returnMessage.busiValidateResult[i].level]
                            + returnMessage.busiValidateResult[i].promptMessage
                            + "</font>";
                    }
                    messageCount++;
                }
// if(returnMessage.busiValidateResult[i].level == '2' &&
// !returnMessage.busiValidateResult[i].validateResult){
// returnMessage.retCode = "1";
// }
            }
        }

        if ("0" != returnMessage.retCode) { // 出现error级别错误时的弹出框
            if (!message) {
                // message = returnMessage.retMessage || "校验失败，无校验提示报文";
                message = $UEE.i18n('ad.person.message.SystemErrorLaterRetry');// "系统错误，请稍后重试";
            }

            $UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
            return false;
        } else if (messageCount > 0) { // 出现info跟warning错误时的弹出框
            $UI.msgbox.warning(dialogTitle, message, wanConfirmCb, wanCancelCb,
                wanCancelCb);
            return false;
        } else { // 不出现弹出框，返回true

            return true;
        }
    },
    //页面返回不友好，返回方式改为info
    checkBusiValidRespByInfo : function($Gadget, $UI, busiValidResp,
                                        warningConfirmCb, warningCancelCb, errorCb, dialogTitle) {
        debugger;
        var wanConfirmCb = null // error级别校验成功，但是出现warning或者info级别的校验失败时，点击confirm弹出框的确定时的回调
        var wanCancelCb = null; // 出现warning级别校验失败时，点击confirm弹出框的cancel按钮或者点击右上角叉号时的回调
        var errCb = null; // error级别校验失败，关闭error弹出框的回调
        var fontList = [ "<font color='#333'>", "<font color='#333'>",
            "<font color='#333'>", "<font color='#EC4E5C'>" ];

        if ($Gadget) {
            if (warningConfirmCb) {
                wanConfirmCb = function() {
                    $Gadget.$safeApply($Gadget,warningConfirmCb);
                };
            }

            if (warningCancelCb) {
                wanCancelCb = function() {
                    $Gadget.$safeApply($Gadget,warningCancelCb);
                };
            }

            if (errorCb) {
                errCb = function() {
                    $Gadget.$safeApply($Gadget,errorCb);
                };
            }
        } else {
            wanConfirmCb = warningConfirmCb;
            wanCancelCb = warningCancelCb;
            errCb = errorCb;
        }
        // 修改bug单*DTS2016040509387
        if(!busiValidResp)
        {
            //
            $UI.msgbox.error($UEE.i18n("ad.person.message.FailedVerifyBusiness"), $UEE.i18n("ad.person.message.signInAgain"), errCb, errCb, errCb);
            return false;
        }
        else if(!busiValidResp.returnMessage)
        {
            $UI.msgbox.error($UEE.i18n("ad.person.message.FailedVerifyBusiness"), $UEE.i18n("ad.person.message.NoResponse"), errCb, errCb, errCb);
            return false;
        }else{

        }
        var returnMessage = busiValidResp.returnMessage;
        dialogTitle = dialogTitle || $UEE.i18n("ad.person.message.information");
        var messageCount = 0;
        var message = null;

        if (returnMessage.busiValidateResult) {
            for ( var i = 0; i < returnMessage.busiValidateResult.length; i++) {
                if (returnMessage.busiValidateResult[i].promptMessage) {
                    if (messageCount == 0) {
                        message = fontList[returnMessage.busiValidateResult[i].level]
                            + returnMessage.busiValidateResult[i].promptMessage
                            + "</font>";
                    } else {
                        message = message
                            + "<br>-----------------------------------------<br>"
                            + fontList[returnMessage.busiValidateResult[i].level]
                            + returnMessage.busiValidateResult[i].promptMessage
                            + "</font>";
                    }
                    messageCount++;
                }
            }
        }

        if ("0" != returnMessage.retCode) { // 出现error级别错误时的弹出框
            if (!message) {
                // message = returnMessage.retMessage || "校验失败，无校验提示报文";
                message = $UEE.i18n('ad.person.message.SystemErrorLaterRetry');// "系统错误，请稍后重试";
            }
            $UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
            return false;
        } else if (messageCount > 0) { // 出现info跟warning错误时的弹出框
            $UI.msgbox.info(dialogTitle, message);
            return false;
        } else { // 不出现弹出框，返回true

            return true;
        }
    },
    // 针对只需要校验成功与否的中间性校验，比如校验手机号是否有效等,弹出框只有失败的error与成功且有提示的信息的info型两种
    checkBusiValidForNotify : function($Gadget, $UI, busiValidResp, successCb,
                                       errorCb, dialogTitle) {
        debugger;
        var sucCb = null;
        var errCb = null;
        var fontList = [ "<font color='#333'>", "<font color='#333'>",
            "<font color='#333'>", "<font color='#EC4E5C'>" ];

        if ($Gadget) {
            if (successCb) {
                sucCb = function() {
                    $Gadget.$apply(successCb);
                };
            }

            if (errorCb) {
                errCb = function() {
                    $Gadget.$apply(errorCb);
                };
            }
        } else {
            sucCb = successCb;
            errCb = errorCb;
        }

        var returnMessage = busiValidResp.returnMessage;
        dialogTitle = dialogTitle || $UEE.i18n("ad.person.message.information");
        var messageCount = 0;
        var message = null;

        if (returnMessage.busiValidateResult) {
            for ( var i = 0; i < returnMessage.busiValidateResult.length; i++) {
                if (returnMessage.busiValidateResult[i].promptMessage) {
                    if (messageCount == 0) {
                        message = fontList[returnMessage.busiValidateResult[i].level]
                            + returnMessage.busiValidateResult[i].promptMessage
                            + "</font>";
                    } else {
                        message = message
                            + "<br>-----------------------------------------<br>"
                            + fontList[returnMessage.busiValidateResult[i].level]
                            + returnMessage.busiValidateResult[i].promptMessage
                            + "</font>";
                    }
                    messageCount++;
                }
            }
        }

        if ("0" != returnMessage.retCode) { // 出现error级别错误时的弹出框
            if (!message) {
                // 校验失败，无校验提示报文
                message = returnMessage.retMessage || $UEE.i18n("ad.person.message.VerificationFailedNoInfo");
            }
            $UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
            return false;
        } else if (messageCount > 0) { // 出现info跟warning校验时的info弹出框
            $UI.msgbox.info(dialogTitle, message, sucCb, sucCb, sucCb);
            return false;
        } else { // 不出现弹出框，返回true
            return true;
        }

    },

    // JS注入校验
    checkInputdata : function(param) {
        var chechdata = param.toUpperCase();
        if (chechdata.indexOf("<") >= 0 || chechdata.indexOf(">") >= 0
            || chechdata.indexOf("/") >= 0
            || chechdata.indexOf("SCRIPT") >= 0) {
            return false;
        }
        return true;
    },

    /*
     * utc时间转换成BE时间 返回Date类型
     */
    convertToBeTime : function (utcTime) {
        var utc0 = "";

        if(typeof utcTime == 'number') {
            utc0 = utcTime;
        } else if(typeof utcTime == 'object' && utcTime instanceof Date) {
            utc0 = utcTime.getTime();
        } else {
            return "";
        }

        // 操作员所在BE对应的时区偏移量原来定义了一句 $Page.beRawOffset = 0 被我直接迁移下来了
        var beRawOffset = 0;
        var beTime = utc0 + beRawOffset;
        var beDate = new Date(beTime);
        return beDate;
    },
    /**
     * 字符转换为json对象
     *
     * @param str
     * @returns
     */
    parseJson : function(str) {
        try {
            return $.parseJSON(str);
        } catch (e) {
            return null;
        }
    },

    /**
     * 确保url以'/'开头
     */
    assureStratWithRoot: function(url) {
        if (url && url[0] != '/') {
            url = "/" + url;
        }

        return url;
    },


    /**
     * 打开顶级菜单
     *
     * @param key
     *            tab键值，全局唯一
     * @param key
     *            tab 名称
     * @param key
     *            tab url（不含上下文跟的绝对路径）
     *            如“http://10.135.37.98:19998/bes/bes/ordercapture/html/bes.oc.index.productorder.base.business.html?+'&'offeringid=1#/index”
     *            则url为“/bes/ordercapture/html/bes.oc.index.productorder.base.business.html?+'&'offeringid=1#/index”
     */
    openTopTab : function(key, name, url, contextPath) {

        debugger;
        name = decodeURI(decodeURI(name));
        window._ysp_top.productPopuFlag = '';
        var mainWorkSpace = null;
        if (!contextPath) {
            contextPath = $UEE.$Webapp;
        }
        var urlSM = contextPath + adutil.assureStratWithRoot(url);
        url = "/" + window.location.pathname.split("/", 2)[1] +"/" + url;

        var urlIcrm = _ysp_top.location.protocol + "//" + window.location.host+url;
        
        //如果是ICT平台嵌入的，则直接打开window
        if (!$Page.isIctFlag) {
			if ($.cookie("fromType") && $.cookie("fromType") == "ICT") {
				$Page.isIctFlag = true;
			}
		}
		if ($Page.isIctFlag) {
			//商品订购页面
			// modify by wwx554795 at 2018-09-10 for IR_REQ_2018预研0824001 关于家宽类有限业务支持ICT平台受理的需求 US-20180904095418-2031111201 DD-AR-D01895885 ICT统一视图改造购物车 start
			if (url.indexOf("ctz.bes.oc.index.productorder.base.business.html") != -1 && !($.cookie("ICTUseNewBusiCheckOut") && $.cookie("ICTUseNewBusiCheckOut") == "Y")) {
				var contextStr = "/"+ window.location.pathname.split("/", 2)[1];
				var targetUrl = contextStr + "/bes/ordercapture/html/bes.ad.productorder.newopen.business.html";
				url = targetUrl + getVersionUrlStr(1);
			}
			window.open(url, '_blank');
			return;
		}
		
        if (ocActionSource == "iCRM") {
            if (_ysp_top.publicObject) {
                mainWorkSpace = _ysp_top.publicObject["mainTab"];
            }

            if (mainWorkSpace) {
                try {

                    if (mainWorkSpace.hasTab(key)) {
                        mainWorkSpace.removeTabByCode(key);
                    }
                    mainWorkSpace.appendTab(key, name, urlIcrm);
                } catch (ex) {
                }
            } else {
                window.open(url, '_blank');
            }
        } else if (ocActionSource == "SM") {
            if (window.location.protocol == "http:") {
                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name,
                    urlSM, "");
            } else if (window.location.protocol == "https:") {
                window.$BES.$Portal.tabpanel.createTabItemByConf(key, name,
                    urlSM, "");
            }
        } else {
            window.open(url, '_blank');
        }
    },

    /**
     * 打开集团菜单页
     */
    openGroupUserTab : function(key, name, url) {
        debugger;
        adutil.openUserTab(key, name, url, $Page.GroupBusinessContextPath);
    },
    /**
     * 打开物联网菜单页
     */
    openIOTUserTab : function(key, name, url) {
    	debugger;
    	adutil.openUserTab(key, name, url, $Page.IoTContextPath);
    },

    openUserTab : function(key, name, url, contextPath) {

        debugger;
        name = decodeURI(decodeURI(name));

        //DTS2016102500899 ICRM获取不到mainWorkSpace会报错，初始化一下
        var mainWorkSpace = null;
        if (!contextPath) {
            contextPath = $UEE.$Webapp;
        }

        var urlSM = contextPath + adutil.assureStratWithRoot(url);
        url = "/" + window.location.pathname.split("/", 2)[1]  + "/" + url;
        
        var urlIcrm = _ysp_top.location.protocol + "//" + window.location.host+url;
        
        //如果从ICT平台嵌入的，则统一使用window打开
		if ($Page.isIctFlag) {
			//如果是从ICT平台嵌入的，并且调转页面是补卡菜单，则增加一个参数
			if (url.indexOf("ctz.bes.oc.index.supplycard.base.business.html") != -1 || url.indexOf("bes-agentdesktop-suspendorresume.html") != -1) {
				if (url.indexOf(getVersionUrlStr(0)) != -1) {
					url = url.replace(getVersionUrlStr(0), "");
					url += "&isIctFlag=";
					url += $Page.isIctFlag;
					url += getVersionUrlStr(0);
				}else {
					url += "&isIctFlag=";
					url += $Page.isIctFlag;
					url += getVersionUrlStr(0);
				}
			}
			window.open(url, '_blank');
			return;
		}
        if (ocActionSource == "iCRM") {
            /*
             * 原有逻辑，esop使用报BES菜单【key】不存在，改为下面的逻辑处理方法 DTS2016092202431,方法参考此js文件中的openTopTab
             var mainWorkSpace = null;
             if (_ysp_top.publicObject) {
             mainWorkSpace = _ysp_top.publicObject["openMenuForBES"];
             }
             if (mainWorkSpace) {
             _ysp_top.publicObject["openMenuForBES"](key, name, url);

             } else {
             window.open(url, '_blank');
             }*/

            if (_ysp_top.publicObject) {
                mainWorkSpace = _ysp_top.publicObject["mainTab"];
            }
            if (mainWorkSpace) {
                try {
                    if (mainWorkSpace.hasTab(key)) {
                        mainWorkSpace.removeTabByCode(key);
                    }
                    mainWorkSpace.appendTab(key, name, urlIcrm);
                } catch (ex) {
                }
            } else {
                window.open(url, '_blank');
            }
        } else if (ocActionSource == "SM") {
            if (window.location.protocol == "http:") {
                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name,
                    urlSM, "");
            } else if (window.location.protocol == "https:") {
                window.$BES.$Portal.tabpanel.createTabItemByConf(key, name,
                    urlSM, "");
            }
        } else {
            window.open(url, '_blank');
        }
    },

    openNGTab : function(key, name, url) {

        debugger;
        name = decodeURI(decodeURI(name));

        if ($Page.isIctFlag) {
			window.open(url, '_blank');
			return;
		}
        
        if (ocActionSource == "iCRM") {
            var mainWorkSpace = null;
            if (_ysp_top.publicObject) {
                mainWorkSpace = _ysp_top.publicObject["openMenuForBES"];
            }
            if (mainWorkSpace) {
                _ysp_top.publicObject["openMenuForBES"](key, name, url);

            } else {
                // alert(15240378255)
                window.open(url, '_blank');
            }
        } else if (ocActionSource == "SM") {
            if (window.location.protocol == "http:") {
                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name,
                    url, "");
            } else if (window.location.protocol == "https:") {
                window.$BES.$Portal.tabpanel.createTabItemByConf(key, name,
                    url, "");
            }
        } else {
            window.open(url, '_blank');
        }
    },

    /**
     * 计算两个日期之间相隔的天数
     */
    dateDiff : function(sDate1, sDate2) { // sDate1和sDate2是2006-12-18格式
        debugger;
        var aDate, oDate1, oDate2, iDays;
        aDate = sDate1.split("-");
        oDate1 = new Date(aDate[0] + '/' + aDate[1] + '/' + aDate[2]); // 转换为12-18-2006格式
        aDate = sDate2.split("-");
        oDate2 = new Date(aDate[0] + '/' + aDate[1] + '/' + aDate[2]);
        iDays = parseInt(Math.abs(oDate1 - oDate2) / 1000 / 60 / 60 / 24); // 把相差的毫秒数转换为天数
        return iDays + 1;
    },

    /**
     * 打开登录鉴权
     */
    openAuthTab : function(data, contextPath) { // sDate1和sDate2是2006-12-18格式
        debugger;
        var $scope = $(document).scope();
        $Page = $scope.$Page;
        if (!contextPath) {
            contextPath = $UEE.$Webapp;
        }

        var besUrl = adutil.getParamInUrl("besUrl", data);
        var besCheckUrl = besUrl.substring(besUrl.indexOf("/",1))
        var roaming = adutil.getParamInUrl("roamingCheck", data);
/*        //山东局点免漫游鉴权登陆(之前蒋飘jwx456845加的 现在要隐掉 cwx411021)
         
        if($Page.projectVersion == "SHANDONG"){
        	roaming = "true";
        }*/
        var tabId = adutil.getParamInUrl("tabId", data);
        var roamingRspMsge = adutil.getParamInUrl("roamingRspMsge", data);
     
        if ((!roaming || roaming == "false") && roaming != "") {
            var ismsg = adutil.ismsgbox();
            if (ismsg == 0) {
                $(document).scope().$Get("$UI").msgbox.info("提示", roamingRspMsge, function(){
                    debugger;
                    window.$BES.$Portal.tabpanel.closeTabItem();
                }, function(){
                }, function(){
                    debugger;
                    window.$BES.$Portal.tabpanel.closeTabItem();
                });
            }
            return;
        }

        if ("SM" == ocActionSource) {
            if (data.indexOf("?") != -1 ) {
                // 海外局点定制跳转界面为360查询界面
                if(data.indexOf("osbasicsearchcondition") != -1){
                    data = "/bes/ad/person/telecomm/osbasicsearchcondition/bes-ad-agent-osbasicsearchcondition.html"
                        + data.substring(data.indexOf("?"))+getVersionUrlStr(0);
                }else
                {
                    data = "/bes/ad/html/bes.ad.login.base.business.html"
                        + data.substring(data.indexOf("?"))+getVersionUrlStr(0);
                }
            }
            data = encodeURI(encodeURI(data));

            /*
             * window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo
             * ||{}; window._ysp_top.EinvoiceIdCardInfo.besdelegcard = '';
             */
            // 保存
            _ysp_top.window.tabtitleafterlogin = _ysp_top.TabSet.getTabItem().title;
            // 登录跳转
// if(data.indexOf("osbasicsearchcondition") != -1){
// _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf("60131_oclogintemp",
// "360-Degree Customer View", "resource.root" + data, "60131_oclogintemp");

            if(data.indexOf("osbasicsearchcondition") != -1){
                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf("60131_oclogintemp",
                    $UEE.i18n("ad.person.title.360DegreeCustomView"), "resource.root" + data, "60131_oclogintemp");

                // 为了保留基线60131_oclogintemp，关闭存在的60131201608191600
                window.$BES.$Portal.tabpanel.closeTabItem("60131201608191600");
                window.$BES.$Portal.tabpanel.closeTabItem();
            }else
            {
                window.$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp");
                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf("60131_oclogintemp",
                    $UEE.i18n("ad.person.title.SignInAndJumpTo"), "resource.root" + data, "60131_oclogintemp");
                window.$BES.$Portal.tabpanel.closeTabItem();
            }
        } else {
            window.open(data);
            window.opener = null;
            window.open('', '_self');
            window.close();
        }
    },

    /**
     * Fire查询后台数据
     */
    queryDatas : function(_$Gadget_, _$Fire_, service, params, target, callback){
        debugger;
        _$Fire_({
            service : service,
            params : params,
            target : target,
            onafter : function(){
                debugger;
                callback.call();
            }
        }, _$Gadget_);
    },

    /**
     * 判断$UI弹框的个数
     */
    ismsgbox : function() {
        debugger;
        var msgFlag = $(".popwin");
        return msgFlag.length;
    },


    /**
     * 获取当前UTC时间
     */
    getCurrentUTCDateLong : function()
    {
        var $scope = $(document).scope();
        var $Fire = $scope.$Get('$Fire');

        $Fire({
            service : '/timeutilservice/gettimes',
            target : '$Page.TimeUtil',
            onafter : function() {
                debugger;
            }
        }, $scope);

        return $Page.TimeUtil.nowDate;
    },

	 encryptWithMD5 :function (string) {
		  
		function RotateLeft(lValue, iShiftBits) {
			return (lValue<<iShiftBits) | (lValue>>>(32-iShiftBits));
		}
	  
		function AddUnsigned(lX,lY) {
			var lX4,lY4,lX8,lY8,lResult;
			lX8 = (lX & 0x80000000);
			lY8 = (lY & 0x80000000);
			lX4 = (lX & 0x40000000);
			lY4 = (lY & 0x40000000);
			lResult = (lX & 0x3FFFFFFF)+(lY & 0x3FFFFFFF);
			if (lX4 & lY4) {
				return (lResult ^ 0x80000000 ^ lX8 ^ lY8);
			}
			if (lX4 | lY4) {
				if (lResult & 0x40000000) {
					return (lResult ^ 0xC0000000 ^ lX8 ^ lY8);
				} else {
					return (lResult ^ 0x40000000 ^ lX8 ^ lY8);
				}
			} else {
				return (lResult ^ lX8 ^ lY8);
			}
		}
	  
		function F(x,y,z) { return (x & y) | ((~x) & z); }
		function G(x,y,z) { return (x & z) | (y & (~z)); }
		function H(x,y,z) { return (x ^ y ^ z); }
		function I(x,y,z) { return (y ^ (x | (~z))); }
	  
		function FF(a,b,c,d,x,s,ac) {
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(F(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		};
	  
		function GG(a,b,c,d,x,s,ac) {
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(G(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		};
	  
		function HH(a,b,c,d,x,s,ac) {
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(H(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		};
	  
		function II(a,b,c,d,x,s,ac) {
			a = AddUnsigned(a, AddUnsigned(AddUnsigned(I(b, c, d), x), ac));
			return AddUnsigned(RotateLeft(a, s), b);
		};
	  
		function ConvertToWordArray(string) {
			var lWordCount;
			var lMessageLength = string.length;
			var lNumberOfWords_temp1=lMessageLength + 8;
			var lNumberOfWords_temp2=(lNumberOfWords_temp1-(lNumberOfWords_temp1 % 64))/64;
			var lNumberOfWords = (lNumberOfWords_temp2+1)*16;
			var lWordArray=Array(lNumberOfWords-1);
			var lBytePosition = 0;
			var lByteCount = 0;
			while ( lByteCount < lMessageLength ) {
				lWordCount = (lByteCount-(lByteCount % 4))/4;
				lBytePosition = (lByteCount % 4)*8;
				lWordArray[lWordCount] = (lWordArray[lWordCount] | (string.charCodeAt(lByteCount)<<lBytePosition));
				lByteCount++;
			}
			lWordCount = (lByteCount-(lByteCount % 4))/4;
			lBytePosition = (lByteCount % 4)*8;
			lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80<<lBytePosition);
			lWordArray[lNumberOfWords-2] = lMessageLength<<3;
			lWordArray[lNumberOfWords-1] = lMessageLength>>>29;
			return lWordArray;
		};
	  
		function WordToHex(lValue) {
			var WordToHexValue="",WordToHexValue_temp="",lByte,lCount;
			for (lCount = 0;lCount<=3;lCount++) {
				lByte = (lValue>>>(lCount*8)) & 255;
				WordToHexValue_temp = "0" + lByte.toString(16);
				WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length-2,2);
			}
			return WordToHexValue;
		};
	  
		function Utf8Encode(string) {
			string = string.replace(/\r\n/g,"\n");
			var utftext = "";
	  
			for (var n = 0; n < string.length; n++) {
	  
				var c = string.charCodeAt(n);
	  
				if (c < 128) {
					utftext += String.fromCharCode(c);
				}
				else if((c > 127) && (c < 2048)) {
					utftext += String.fromCharCode((c >> 6) | 192);
					utftext += String.fromCharCode((c & 63) | 128);
				}
				else {
					utftext += String.fromCharCode((c >> 12) | 224);
					utftext += String.fromCharCode(((c >> 6) & 63) | 128);
					utftext += String.fromCharCode((c & 63) | 128);
				}
	  
			}
	  
			return utftext;
		};
	  
		var x=Array();
		var k,AA,BB,CC,DD,a,b,c,d;
		var S11=7, S12=12, S13=17, S14=22;
		var S21=5, S22=9 , S23=14, S24=20;
		var S31=4, S32=11, S33=16, S34=23;
		var S41=6, S42=10, S43=15, S44=21;
	  
		string = Utf8Encode(string);
	  
		x = ConvertToWordArray(string);
	  
		a = 0x67452301; b = 0xEFCDAB89; c = 0x98BADCFE; d = 0x10325476;
	  
		for (k=0;k<x.length;k+=16) {
			AA=a; BB=b; CC=c; DD=d;
			a=FF(a,b,c,d,x[k+0], S11,0xD76AA478);
			d=FF(d,a,b,c,x[k+1], S12,0xE8C7B756);
			c=FF(c,d,a,b,x[k+2], S13,0x242070DB);
			b=FF(b,c,d,a,x[k+3], S14,0xC1BDCEEE);
			a=FF(a,b,c,d,x[k+4], S11,0xF57C0FAF);
			d=FF(d,a,b,c,x[k+5], S12,0x4787C62A);
			c=FF(c,d,a,b,x[k+6], S13,0xA8304613);
			b=FF(b,c,d,a,x[k+7], S14,0xFD469501);
			a=FF(a,b,c,d,x[k+8], S11,0x698098D8);
			d=FF(d,a,b,c,x[k+9], S12,0x8B44F7AF);
			c=FF(c,d,a,b,x[k+10],S13,0xFFFF5BB1);
			b=FF(b,c,d,a,x[k+11],S14,0x895CD7BE);
			a=FF(a,b,c,d,x[k+12],S11,0x6B901122);
			d=FF(d,a,b,c,x[k+13],S12,0xFD987193);
			c=FF(c,d,a,b,x[k+14],S13,0xA679438E);
			b=FF(b,c,d,a,x[k+15],S14,0x49B40821);
			a=GG(a,b,c,d,x[k+1], S21,0xF61E2562);
			d=GG(d,a,b,c,x[k+6], S22,0xC040B340);
			c=GG(c,d,a,b,x[k+11],S23,0x265E5A51);
			b=GG(b,c,d,a,x[k+0], S24,0xE9B6C7AA);
			a=GG(a,b,c,d,x[k+5], S21,0xD62F105D);
			d=GG(d,a,b,c,x[k+10],S22,0x2441453);
			c=GG(c,d,a,b,x[k+15],S23,0xD8A1E681);
			b=GG(b,c,d,a,x[k+4], S24,0xE7D3FBC8);
			a=GG(a,b,c,d,x[k+9], S21,0x21E1CDE6);
			d=GG(d,a,b,c,x[k+14],S22,0xC33707D6);
			c=GG(c,d,a,b,x[k+3], S23,0xF4D50D87);
			b=GG(b,c,d,a,x[k+8], S24,0x455A14ED);
			a=GG(a,b,c,d,x[k+13],S21,0xA9E3E905);
			d=GG(d,a,b,c,x[k+2], S22,0xFCEFA3F8);
			c=GG(c,d,a,b,x[k+7], S23,0x676F02D9);
			b=GG(b,c,d,a,x[k+12],S24,0x8D2A4C8A);
			a=HH(a,b,c,d,x[k+5], S31,0xFFFA3942);
			d=HH(d,a,b,c,x[k+8], S32,0x8771F681);
			c=HH(c,d,a,b,x[k+11],S33,0x6D9D6122);
			b=HH(b,c,d,a,x[k+14],S34,0xFDE5380C);
			a=HH(a,b,c,d,x[k+1], S31,0xA4BEEA44);
			d=HH(d,a,b,c,x[k+4], S32,0x4BDECFA9);
			c=HH(c,d,a,b,x[k+7], S33,0xF6BB4B60);
			b=HH(b,c,d,a,x[k+10],S34,0xBEBFBC70);
			a=HH(a,b,c,d,x[k+13],S31,0x289B7EC6);
			d=HH(d,a,b,c,x[k+0], S32,0xEAA127FA);
			c=HH(c,d,a,b,x[k+3], S33,0xD4EF3085);
			b=HH(b,c,d,a,x[k+6], S34,0x4881D05);
			a=HH(a,b,c,d,x[k+9], S31,0xD9D4D039);
			d=HH(d,a,b,c,x[k+12],S32,0xE6DB99E5);
			c=HH(c,d,a,b,x[k+15],S33,0x1FA27CF8);
			b=HH(b,c,d,a,x[k+2], S34,0xC4AC5665);
			a=II(a,b,c,d,x[k+0], S41,0xF4292244);
			d=II(d,a,b,c,x[k+7], S42,0x432AFF97);
			c=II(c,d,a,b,x[k+14],S43,0xAB9423A7);
			b=II(b,c,d,a,x[k+5], S44,0xFC93A039);
			a=II(a,b,c,d,x[k+12],S41,0x655B59C3);
			d=II(d,a,b,c,x[k+3], S42,0x8F0CCC92);
			c=II(c,d,a,b,x[k+10],S43,0xFFEFF47D);
			b=II(b,c,d,a,x[k+1], S44,0x85845DD1);
			a=II(a,b,c,d,x[k+8], S41,0x6FA87E4F);
			d=II(d,a,b,c,x[k+15],S42,0xFE2CE6E0);
			c=II(c,d,a,b,x[k+6], S43,0xA3014314);
			b=II(b,c,d,a,x[k+13],S44,0x4E0811A1);
			a=II(a,b,c,d,x[k+4], S41,0xF7537E82);
			d=II(d,a,b,c,x[k+11],S42,0xBD3AF235);
			c=II(c,d,a,b,x[k+2], S43,0x2AD7D2BB);
			b=II(b,c,d,a,x[k+9], S44,0xEB86D391);
			a=AddUnsigned(a,AA);
			b=AddUnsigned(b,BB);
			c=AddUnsigned(c,CC);
			d=AddUnsigned(d,DD);
		}
	  
		var temp = WordToHex(a)+WordToHex(b)+WordToHex(c)+WordToHex(d);
	  
		//return temp.toLowerCase();
		return temp.toUpperCase();
	},
	
    /**
     * busivalidate入参加密 added by z00283015
     */
    encryptBusivReq : function(checkoutValidateReq){
        debugger;

        if (checkoutValidateReq && checkoutValidateReq.order){
            // 证件号码
            if (checkoutValidateReq.order.certInfo && checkoutValidateReq.order.certInfo.length > 0){
                checkoutValidateReq.order.certInfo[0].certId = encryptWithRSA(checkoutValidateReq.order.certInfo[0].certId);
            }
        }
        // 密码
        if (checkoutValidateReq && checkoutValidateReq.productOrderLine && checkoutValidateReq.productOrderLine.length > 0){
            // createOrderReq.productOrderLine[0].orderItem[0].orderItemInfo[0].orderItemPassword.newPassword
            // 证件号码
            if(checkoutValidateReq.productOrderLine[0].orderItem && checkoutValidateReq.productOrderLine[0].orderItem.length > 0){
                if(checkoutValidateReq.productOrderLine[0].orderItem[0].orderItemInfo && checkoutValidateReq.productOrderLine[0].orderItem[0].orderItemInfo.length > 0){
                    if(checkoutValidateReq.productOrderLine[0].orderItem[0].orderItemInfo[0].orderItemPassword){
                        checkoutValidateReq.productOrderLine[0].orderItem[0].orderItemInfo[0].orderItemPassword.newPassword =
                            encryptWithRSA(checkoutValidateReq.productOrderLine[0].orderItem[0].orderItemInfo[0].orderItemPassword.newPassword);
                    }
                }
            }
        }
        /*
         * //用户名称 if (checkoutValidateReq.extInfo){ if
         * (checkoutValidateReq.extInfo.registrant){ if
         * (checkoutValidateReq.extInfo.registrant.accountInfo){
         * checkoutValidateReq.extInfo.registrant.accountInfo.acctName =
         * encryptWithRSA(checkoutValidateReq.extInfo.registrant.accountInfo.acctName); } } }
         */
    },

    // -------------------------以上为正式收录到adutil中的方法---------------------



    // 证件号转换工具 15位转18位   要移除
    // 实名制整改计划
    certNum15To18 : function(certId, certType, allowType) {
        // certId——证件号; certType——证件类型; allowType——允许转换的证件类型 数组
        if (certId && certId.toString().length === 15 && needTrans()) {
            return doTrans();
        } else {
            return certId;
        }

        function needTrans() {
            var needTransType = ["IdCard", "TempId"];
            // 扩展值
            if (angular.isArray(allowType) && allowType.length > 0) {
                needTransType = allowType;
            }

            for (var i = needTransType.length - 1; i >= 0; i--) {
                if (certType === needTransType[i]) {
                    return true;
                }
            }

            return false;
        }

        function doTrans() {
            var newCertId = certId.substring(0, 6) + "19" + certId.substring(6);
            var total = 0;
            for (var i = 0; i < 17; i++) {
                var temp = Number(newCertId.substring(i, i + 1));
                total = total + temp * (Math.pow(2, 17 - i)) % 11;
            }
            return newCertId + getLastNum(Number(total % 11));
        }

        function getLastNum(lastNum) {
            if (lastNum === 0) {
                return 1;
            }
            if (lastNum === 1) {
                return 0;
            }
            if (lastNum === 2) {
                return "X";
            }
            return Number(12 - lastNum);
        }
    },

	// 360视图中专用的功能，计划要删除
	setLocationValueByName : function(key,value) {
		location.search=location.search.replace(new RegExp("[\?\&]" + key
				+ "=([^\&]+)", "i"),"&serviceNum="+value);
	},


	// 价格舍入方法  计划要删除  多货币整改计划
	approxPrice : function(storageValue) {
		if (null == storageValue) {
			return 0;
		}

		var displayPriceInfo = $(document).scope().$Page.displayPriceInfo;
		approxPrecision = Math.pow(10,
				parseInt(displayPriceInfo.approxPrecision || 0));

		storageValue = parseInt(storageValue, 10) / approxPrecision;
		storageValue = Math.floor(storageValue);
		return storageValue * approxPrecision;
	},

	/**
	 * 调用OCX插件的方法
	 *  读卡器整改计划
	 * 用fiddle验证无报错
	 */
	openOCX: function($Page,$Fire,callbackfun, $UI) {
	    debugger;
	    $Fire({
	    	service: 'ucec/v1/common/qrysystemparambykey',
	    	params: {
	            key: "OC_OCXCtrl"
	        },
	        target: "data",
	        onafter: function(data){
				if (data)
				{
					debugger;
					$Page.OCXInfoOut = {};
					adutil.telecomScope = adutil.telecomScope||{};
					var sysParame = data.split("#");
					if (!sysParame || sysParame.length != 4 || sysParame[0] == 0 || sysParame[0] != 1)
					{
						$Fire({
							service: 'ucec/v1/common/qrysystemparambykey',
							params: {
								key: "THRESHOLD"
							},
							target: "dataThreshold",
							onafter: function(dataThreshold){
								debugger;
                                $Page.OCXInfoIn.threshold = dataThreshold;
								// 流水号
								$Fire({
									service: '/OcxSNoAndRecService/getSerialNo',
									params: {
										"beId": $Page.OCXInfoIn.region,
									},
									target: "dataSerialNo",
									onafter: function(dataSerialNo) {
										// 调用插件接口
										debugger;
										if (!dataSerialNo || dataSerialNo == ''|| dataSerialNo == 'undefined')
										{
											// 从源头控制 PC比对时流水号为空的情况
											$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "获取流水号失败，请重新进行人证比对!");
											return;
										}
										$Page.OCXInfoIn.serialNo = dataSerialNo;
										$Page.OCXInfoOut.returnCode = 1;
										if (sysParame[0] == 2){
											$Page.OCXInfoOut.returnCode = 2;
										}
										$Page.OCXInfoOut.serialNo = $Page.OCXInfoIn.serialNo;
										if(callbackfun){
											callbackfun();
										}
										$Fire({
									        service: '/OcxSNoAndRecService/doRecord',
									        params: {
									           "ocxRecord": {
							                    "realNameId":$Page.OCXInfoIn.serialNo,
												"MSISDN": $Page.OCXInfoIn.MSISDN,
												"busiType": $Page.OCXInfoIn.busitype,
												"custName": $Page.OCXInfoIn.name,
												"custCertType": $Page.OCXInfoIn.cardtype,
												//DTS2017112905375 zwx392622 2017-11-30
        										//江苏移动BES-部分个人菜单请求报文中存在证件号码明文传输的安全风险
												"custCertNo": encryptWithRSA($Page.OCXInfoIn.cardno),
												"beId": $Page.OCXInfoIn.region,
												"picString": $Page.OCXInfoOut.image,
												"picrseult": $Page.OCXInfoOut.returnCode,
												"nation": $Page.OCXInfoIn.nation,
												"threshold": $Page.OCXInfoIn.threshold,
												"gender": $Page.OCXInfoIn.sex,
												"custCertAddr": $Page.OCXInfoIn.address,
												"certValidDate":$Page.OCXInfoIn.certValidDate,
												"certExpDate":$Page.OCXInfoIn.certExpDate
											   },
											   "ocxSerialNo":{}
									         },
									         onafter: function(){
												debugger;
												return;
									         }
									    });
									}
								});
							},
						});
					}
					else
					{
						adutil.telecomScope.sysParame = sysParame;
						var jsonInfo = "{\"serialNo\":\"\",\"threshold\":\"\",\"region\":\"\",\"regionName\":\"\",\"cardtype\":\"\",\"name\":\"\",\"cardno\":\"\",\"address\":\"\",\"sex\":\"\",\"nation\":\"\",\"born\":\"\",\"image\":\"\"}";
						var jsonObj = JSON.parse(jsonInfo);
						jsonObj.threshold = 0.5; // 比对阀值,换成从数据库抽的系统参数(范围：0.1-1)
						jsonObj.serialNo = "";
						var busitype = $Page.OCXInfoIn.busitype; // 业务类型
						var MSISDN = $Page.OCXInfoIn.MSISDN; // 客户手机号
						jsonObj.region = $Page.OCXInfoIn.region; // 地市编码
						jsonObj.regionName = $Page.OCXInfoIn.regionName; // 操作员工号
						jsonObj.cardtype = $Page.OCXInfoIn.cardtype == 'IdCard' || $Page.OCXInfoIn.cardtype == "IdCardGA" || $Page.OCXInfoIn.cardtype == "IdCardTW" ? 1:0; // 证件类型.1:身份证0:其他证件
						jsonObj.name = $Page.OCXInfoIn.name; // 证件姓名
						jsonObj.cardno = $Page.OCXInfoIn.cardno; // 证件号码
						jsonObj.address = $Page.OCXInfoIn.address || ""; // 证件地址
						jsonObj.sex = $Page.OCXInfoIn.sex == '1' ? "男":"女"; // 性别
						jsonObj.nation = $Page.OCXInfoIn.nation || ""; // 民族
						jsonObj.born = $Page.OCXInfoIn.born || ""; // 出生日志
						jsonObj.image = $Page.OCXInfoIn.image || ""; // 身份证芯片图像(通过二代证读卡器读取,只有二代身份证才有)
						if(jsonObj.cardtype!="1"){
							jsonObj.sex="";
							jsonObj.nation="";
							jsonObj.born="";
						}

						$Fire({
							service: 'ucec/v1/common/qrysystemparambykey',
							params: {
								key: "THRESHOLD"
							},
							target: "dataThreshold",
							onafter: function(dataThreshold){
								debugger;
                                $Page.OCXInfoIn.threshold = dataThreshold;
								jsonObj.threshold = dataThreshold;
								// 流水号
								$Fire({
									service: '/OcxSNoAndRecService/getSerialNo',
									params: {
										"beId": jsonObj.region,
									},
									target: "dataSerialNo",
									onafter: function(dataSerialNo) {
										// 调用插件接口
										debugger;
										if (!dataSerialNo || dataSerialNo == ''|| dataSerialNo == 'undefined')
										{
											// 从源头控制 PC比对时流水号为空的情况
											$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "获取流水号失败，请重新进行人证比对!");
											return;
										}
										
										$Page.OCXInfoIn.serialNo = dataSerialNo;
										jsonObj.serialNo = dataSerialNo;
										// 提交后调回调方法
										try{
											var ocxobj = document.getElementById('faceocx');
											var result = ocxobj.RegCompareJs(window, 'adutil.compareResult');
											adutil.telecomScope.$Page = $Page;
											adutil.telecomScope.$Fire = $Fire;
											adutil.telecomScope.$UI = $UI;
											adutil.telecomScope.callbackfun = callbackfun;
										}catch(e){
											$Page.OCXInfoOut.returnCode = "3";
											$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "调用插件前置条件失败!");
											return;
										}
										if(result == "0"){// 注册失败
											$Page.OCXInfoOut.returnCode = "3";
											$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "插件注册失败！");
											return;
										}
										var dataCardTypeDicts = ['CM_CERT_TYPE_JS'];
								        $Fire({
									        service: '/common/dictkey',
									        params: {
									        	'dictkeylist' : dataCardTypeDicts
									        },
									        target: "dataDictList",
									         onafter: function(dataDictList){
												debugger;
												if (dataDictList){
													var cardTypeList =  dataDictList['CM_CERT_TYPE_JS'];
													$.each(cardTypeList || [],function(i,val){
														if (val.itemCode == $Page.OCXInfoIn.cardtype 
																&& val.extMap && val.extMap.ext3 == 'IdCard'){
															jsonObj.cardtype = '1';
														}
													});
												}
												var cprInfo = JSON.stringify(jsonObj);
												try{
													ocxobj.ViewCompareInfo(cprInfo);
												}catch(e){
													$Page.OCXInfoOut.returnCode = "3";
													$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "调用插件失败!");
													return;
												}
									         }
									    });
									}
								});
							},
						});
					}
				}
	        }
	    });
	},

	// OCX回调方法  读卡器整改计划
	 compareResult : function(json){

	    debugger;
		var $Page = adutil.telecomScope.$Page;
		var $Fire =adutil.telecomScope.$Fire;
		var $UI =adutil.telecomScope.$UI;
	    var parame2 = adutil.telecomScope.sysParame[1];
		var param3 = adutil.telecomScope.sysParame[2];
	    $Page.OCXInfoOut.returnCode = json.returnCode;
	    if (parame2 == json.returnCode)
	    {
	    	$Page.OCXInfoOut.returnCode = 1;
	    }
		if(param3 == json.returnCode){
			$Page.OCXInfoOut.returnCode = 2;
		}
	    $Page.OCXInfoOut.image = json.image;
	    $Page.OCXInfoOut.serialNo = $Page.OCXInfoIn.serialNo;
		var callbackfun = adutil.telecomScope.callbackfun;
	    if(callbackfun){
			callbackfun();
		}
	    /*if ($Page.OCXInfoOut.returnCode == '3')
	    {
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "对比异常!");
		    return;
	    }
		if ($Page.OCXInfoOut.returnCode == '2')
	    {
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "对比不一致!");
	    }*/
		var parame4 = adutil.telecomScope.sysParame[3];
		if (parame4 == 1)
		{
			$Fire({
		        service: '/OcxSNoAndRecService/doRecord',
		        params: {
		           "ocxRecord": {
                    "realNameId":$Page.OCXInfoIn.serialNo,
					"MSISDN": $Page.OCXInfoIn.MSISDN,
					"busiType": $Page.OCXInfoIn.busitype,
					"custName": $Page.OCXInfoIn.name,
					"custCertType": $Page.OCXInfoIn.cardtype,
					//DTS2017112905375 zwx392622 2017-11-30
        			//江苏移动BES-部分个人菜单请求报文中存在证件号码明文传输的安全风险
					"custCertNo": encryptWithRSA($Page.OCXInfoIn.cardno),
					"beId": $Page.OCXInfoIn.region,
					"picString": $Page.OCXInfoOut.image,
					"picrseult": $Page.OCXInfoOut.returnCode,
					"nation": $Page.OCXInfoIn.nation,
					"threshold": $Page.OCXInfoIn.threshold,
					"gender": $Page.OCXInfoIn.sex,
					"custCertAddr": $Page.OCXInfoIn.address,
					"certValidDate":$Page.OCXInfoIn.certValidDate,
					"certExpDate":$Page.OCXInfoIn.certExpDate
				   },
				   "ocxSerialNo":{}
		         },
		         onafter: function(){
					debugger;
		         }
		    });
		}
	},

	isSheltered : function(busicode){
		var $scope = $(document).scope();
		$scope.$Page.shelters = $scope.$Page.shelters || [];
		return $.inArray(busicode,$scope.$Page.shelters) >= 0;
	},



    // 多货币相关需要整改 多货币整改计划
	getDisplayPrice : function(minValue, maxValue) {
		var displayPriceInfo = $(document).scope().$Page.displayPriceInfo;
		if (null == minValue) {
			return displayPriceInfo.currencySymbol + (new Number(0)).toFixed(2);
		}

		var precision = Math.pow(10, parseInt(displayPriceInfo.precision || 0));

		if (minValue == maxValue || null == maxValue) {
			return displayPriceInfo.currencySymbol
					+ (adutil.approxPrice(minValue) / precision).toFixed(2);
		} else {
			return displayPriceInfo.currencySymbol
					+ (adutil.approxPrice(minValue) / precision).toFixed(2)
					+ "-"
					+ (adutil.approxPrice(maxValue) / precision).toFixed(2);
		}
	},

    // 多货币相关需要整改  多货币整改计划
	getPriceByPrecision : function(storageValue) {
		// debugger;
		return (parseFloat(storageValue || 0) / Math.pow(10, parseInt($(
				document).scope().$Page.displayPriceInfo.precision || 0)));
	},

    // 多货币相关需要整改  多货币整改计划
    getStorageValueByPrecision: function(price) {

		debugger;
		var precision = parseInt($(document).scope().$Page.displayPriceInfo.precision || 0);

		price = price || 0;
		if (typeof price == "number") {
		//DTS2017031505969 归档的时候会产生位数很长，精确到两位小数
		//DTS2017072502120 ,修正16.1传过来得到16100.000000000002的结果 lwx414782
		//return  price * Math.pow(10, precision).toFixed(0);
		return  parseFloat((price * Math.pow(10, precision)).toFixed(0));
		} else if (typeof price != "string") {
		return 0;
		}

		var ponitIdx = price.indexOf('.');
		if (ponitIdx == -1) {
		return parseInt(price) * Math.pow(10, precision);
		}

		var priceInteger = price.substr(0, ponitIdx);
		var priceDecimal = price.substr(ponitIdx + 1);

		var decimalLen = priceDecimal.length;
		if (decimalLen <= precision) {
		var appendLen = precision - decimalLen;
		for ( var i = 0; i < appendLen; i++) {
		priceDecimal += '0';
		}
		} else {
		var newDecimalLen = decimalLen - precision;
		priceDecimal = priceDecimal.substr(0, precision) + '.' + priceDecimal.substr(precision, newDecimalLen);
		}

		//DTS2018022708847
		return parseFloat(parseFloat(priceInteger + priceDecimal).toFixed(0));
	},


	// 根据精度将存储的百分比转换为实际显示值 多货币相关需要整改  多货币整改计划
	getRealPercentByPrecision : function(storageValue) {
        return (parseFloat(storageValue || 0) / Math.pow(10, parseInt($(
                document).scope().$Page.percentPrecision || 0))).toFixed(2);
    },

    // 根据精度将实际的百分比转换为存储值  多货币相关需要整改 多货币整改计划
    getStoragePercentByPrecision : function(percent) {
        return (parseFloat(percent || 0)
                * Math.pow(10, parseInt($(document).scope().$Page.percentPrecision || 0))).toFixed(0);
    },

    // 多货币相关需要整改  多货币整改计划
	getToFixedPrice : function(price) {
		var precision = $(document).scope().$Page.displayPriceInfo.precision;
		if (precision && precision > 0) {
			return parseFloat((price || 0).toFixed(precision));
		} else {
			return parseFloat((price || 0).toFixed(0));
		}
	},

	/**
	 * 返回标准值对应的存储值，currencyid和beid如果为空则使用默认的，样例 :5000  多货币相关需要整改
	 *多货币整改计划
     *
	 * @param priceInfo
	 * @param callBack
	 * @returns
	 */
	getStorageValueFromDisplayPrice : function(priceInfo,callBack)
	{
		debugger;
		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');
		var beId = priceInfo.beId || $scope.$Page.displayPriceInfo.beId || adutil.getBeId();
		var currencyId = priceInfo.currencyId || $scope.$Page.displayPriceInfo.defaultCurrencyId;
		var displayPrice = priceInfo.displayPrice || 0;

		$Fire({
			service : 'gadget/sm/CurrencyAction/getStorageValFromStd',
			params : {
				'currencyid' : currencyId,
				'beid' : beId,
				'unitval' : displayPrice
			},
			target : "$Page.storageValue",
			onafter : function() {
				priceInfo.storageValue = $Page.storageValue;
				if (callBack){
					callBack.call(priceInfo);
				}
			}
		}, $scope);
	},

	/**
	 * 返回存储值的展示形式，样例 {5000: 'RMB ￥ 5.00 元', 1000 : 'RMB ￥ 1.00 元'}  多货币相关需要整改
     * 多货币整改计划
	 */
	getDisplayPricesFromStorageValues : function(priceInfo,callBack)
	{
		debugger;
		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');
		var beId = priceInfo.beId || $scope.$Page.displayPriceInfo.beId;
		var currencyId = priceInfo.currencyId || $scope.$Page.displayPriceInfo.defaultCurrencyId;
		var storageValues = priceInfo.storageValues;

			$Fire({
			service : 'bes.oc.ocpcofferfeeservice/getpricedisplaylist',
			params : {
				"pricelist" : storageValues,
				"currencyid" : currencyId
			},
			target : "$Page.displayPrices",
			onafter : function() {
				if ($scope.$Page.displayPrices){
					priceInfo.displayPrices = $scope.$Page.displayPrices;
					if (callBack){
						callBack.call(priceInfo);
					}
				}
			}
		}, $scope);
	},

	/**
	 * 返回存储值的展示值的map形式，样例：{currencyValue: "5.00", currencySymbol: "￥",  多货币相关需要整改
	 * currencyCode: "RMB", currencyUnit: "元"}
     * 多货币整改计划
	 */
	getDisplayPriceMapFromStorage : function(priceInfo,callBack)
	{
		debugger;
		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');
		var beId = priceInfo.beId || $scope.$Page.displayPriceInfo.beId;
		var currencyId = priceInfo.currencyId || $scope.$Page.displayPriceInfo.defaultCurrencyId;
		var storageValue = priceInfo.storageValue || 0;

			$Fire({
			service : 'com.huawei.bes.sm.base.common.smcurrencyboservice/querydisplaymap',
			params : {
				"beid" : beId,
				"currencyid" : currencyId,
				"value":storageValue,
				"displaytype":0
			},
			target : "$Page.displayPriceMap",
			onafter : function() {
				priceInfo.displayPriceMap = $scope.$Page.displayPriceMap;
				if (callBack){
					callBack.call(priceInfo);
				}
			}
		}, $scope);
	},

	/**
	 * 返回存储值的展示值  多货币相关需要整改
     * 多货币整改计划
	 */
	getDisplayPriceValueFromStorage : function(priceInfo,callBack)
	{
		debugger;
		var $scope = $(document).scope();
		var $Fire = $scope.$Get('$Fire');
		var beId = adutil.getBeId();
		var currencyId = priceInfo.currencyId || $scope.$Page.displayPriceInfo.defaultCurrencyId;
		var storageValue = priceInfo.storageValue || 0;

			$Fire({
			service : 'bes.oc.ocpcofferfeeservice/querystdvaluefromstorage',
			params : {
				"beid" : adutil.getBeId(),
				"currencyid" : currencyId,
				"storagevalue":storageValue
			},
			target : "$Page.displayPriceValue",
			onafter : function() {
				priceInfo.displayPriceValue = parseFloat($scope.$Page.displayPriceValue);
				if (callBack){
					callBack.call(priceInfo);
				}
			}
		}, $scope);
	},

	/**
	 * 排序US-20170906181553-2031034600商品展现顺序优化
	 * 排序函数，入参：排序商品数组，普通商品或营销档次
	 * noMemberOrderFlag 是否需要使用memberOrder进行排序不需要则传true
	 */
	sortsearchofferinglist: function(list,noMemberOrderFlag){
		debugger;
		if((list || []).length == 0)
			return null;
		//排序
		list.sort(function(a,b){
			if(a.memberOrder && b.memberOrder && a.memberOrder != b.memberOrder && !noMemberOrderFlag){
				//有memberOrder属性的，用memberOrder排序
				return a.memberOrder - b.memberOrder;
			}
			//名称排序，取名称的char数组 商品、商品子offer、营销活动档次
			var stringA = (a.offerName || a.offeringName || a.childOfferingName || (a.levelBaseInfo||{}).offeringName || '');
			var charListA = stringA.split('');
			var stringB = (b.offerName || b.offeringName || b.childOfferingName || (b.levelBaseInfo||{}).offeringName || '');
			var charListB = stringB.split('');
			var length = charListA.length > charListB.length ? charListB.length : charListA.length;//对比的长度取小的
			for ( var i = 0; i < length; i++) {
				if(/[0-9]/.test(charListA[i]) && /[0-9]/.test(charListB[i])){
					var numCompareResult = sortNumSubStrFromStr(stringA.substring(i,stringA.length),stringB.substring(i,stringB.length));
					if(numCompareResult != 0){
						return numCompareResult;
					}
				}else if(/[a-zA-Z]/.test(charListA[i]) && !/[0-9a-zA-Z]/.test(charListB[i])){
						return -1;//字母放中文前面
				}else if(!/[0-9a-zA-Z]/.test(charListA[i]) && /[a-zA-Z]/.test(charListB[i])){
						return 1;//字母放中文前面
				}else{
					//其他情况
					if(charListA[i].localeCompare(charListB[i]) != 0)
						return charListA[i].localeCompare(charListB[i]);
				}
			}
			return charListA.length - charListB.length;
		});
		//排序结束
		return list;
		//数字排序函数
		function sortNumSubStrFromStr(strA,strB){
			var numA = /\D/.test(strA) ? strA.substring(0,strA.replace(/\D/,'___').indexOf('___')) : strA;//获取数字字符串
			var numB = /\D/.test(strB) ? strB.substring(0,strB.replace(/\D/,'___').indexOf('___')) : strB;
			if(numA != numB)
				return numA - numB;//不相等，直接结束检查，排序完成
			if(numA == numB && strA.length != strB.length && (numA == strA.length || numB == strB.length))
				return strA.length - strB.length;//A是B的子字符串或相反，直接结束检查，排序完成
			return 0;
		}
	},
	
	/**
	 * 台胞证验证 按照实名制规则修改
     	 *  实名制整改计划
	 */
	checkTaiBaoZhengId : function(certificateNum, $UI) {
		debugger;
		if (!/^\d{7}$/.test(certificateNum)&&!/^\d{8}$/.test(certificateNum)
			&& !/^(\d{10})[a-zA-Z0-9]{1,2}$/.test(certificateNum)
			&& !/^(TW|LXZH)[A-Z0-9\(\)]+$/.test(certificateNum)) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
				"请输入正确的台胞证编号，格式为：11,12位时，前10位必须均为数字,最后1-2位为英文字母或阿拉伯数字；或8位时，均为数字；或前2位“TW”或 “LXZH”字符，后面是阿拉伯数字、英文大写字母与半角“（）”的组合");
			return false;
		}

		return true;
	},
	
	/**
	 * 台胞证验证 按照实名制规则修改
     	 *  实名制整改计划
	 */
	checkTaiBaoZhengIdjiangSu : function(certificateNum, $UI) {
		debugger;
		if (!/^\d{8}$/.test(certificateNum)
			&& !/^(\d{10})[a-zA-Z0-9]{1,2}$/.test(certificateNum)
			&& !/^(TW|LXZH)[A-Z0-9\(\)]+$/.test(certificateNum)) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
				"请输入正确的台胞证编号，格式为：11,12位时，前10位必须均为数字,最后1-2位为英文字母或阿拉伯数字；或8位时，均为数字；或前2位“TW”或 “LXZH”字符，后面是阿拉伯数字、英文大写字母与半角“（）”的组合");
			return false;
		}

		return true;
	},

    /**
     * 校验证件类型的非常吊的代码，实际上都是废代码
     *      实名制整改计划
     *
     * @param $UI
     * @param msgFunc
     * @param msg
     */
	checkCertMsgFunc : function($UI, msgFunc, msg) {
		if ($UI) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), msg);

		} else if (msgFunc) {
			msgFunc(msg);
		}
	},

    /**
     * 校验证件姓名的，一般用于过滤器中
     *      实名制整改计划
     *
     * @param userName
     * @param certType
     * @param param
     * @returns {*}
     */
	validateCertName : function(userName, certType, param) {
		return this.checkCertNameChar(certType, userName, null, function(msg){
			param[1] = msg;
		});
	},
	
	/**
	 * Add by wwx392692 at 2017/10/31 for DTS2017102803022
	 * 由于江苏完善资料当登陆鉴权为AuthCheckRND， 没有明文令牌并且没有进行金库鉴权去模糊化时，客户信息的证件姓名是模糊化的特殊性，仅以此方法校验完善
	 * 资料的客户信息中的客户姓名
	 * 
     * 校验证件姓名的，一般用于过滤器中
     *      实名制整改计划
     *
     * @param userName
     * @param certType
     * @param param
     * @returns {*}
     */
	validateCertNameForCompleteProfile : function(userName, certType, param) {
		return this.checkCertNameCharForCompleteProfile(certType, userName, null, function(msg){
			param[1] = msg;
		});
	},

    /**
     * 校验证件地址，一般用于过滤器中
     *      实名制整改计划
     *
     * @param custAddress
     * @param certType
     * @param addrName
     * @param param
     * @returns {*}
     */
	validateCustAddress : function(custAddress, certType, addrName, param) {
		return this.checkCustAddress(certType, custAddress, null, addrName, function(msg){
			param[1] = msg;
		});
	},
	
	/**
	 * US-20171009111409-2031039148
     * 校验开户、过户、改资料、补资料、批量开户（物联网、IMS）、批量改资料、批量补资料，界面上的联系地址（包括经办人、使用者的），一般用于过滤器中
     *      校验联系地址，输入长度不能超过128个字节
     *
     * @param contactAddr
     * @param addrName
     * @param param
     * @returns {*}
     */
	validateContactAddr : function(contactAddr, addrName, param) {
		return this.checkContactAddr(contactAddr, null, addrName, function(msg){
			param[1] = msg;
		});
	},

	/**
	 * US-20171009111409-2031039148
     * 校验改资料、补资料、批量开户（物联网、IMS）、批量改资料、批量补资料，界面上的证件地址、常用地址（包括经办人、使用者的），一般用于过滤器中
     *      校验证件地址或常用地址，输入长度不能超过128个字节
     *
     * @param custAddress
     * @param addrName
     * @param param
     * @returns {*}
     */
	validateCustAddress2 : function(custAddress, addrName, param) {
		return this.checkCustAddress2(custAddress, null, addrName, function(msg){
			param[1] = msg;
		});
	},
	
	/**
	 * US-20171009111409-2031039148
	 * 校验联系地址，输入长度不能超过128个字节
	 */
	checkContactAddr: function(contactAddr, $UI, addrName, msgFunc) {
		debugger;
		var length = this.countCharacters(contactAddr);
		var $scope = $(document).scope();
		$Page = $scope.$Page;
        if ($Page.projectVersion == "NINGXIA") {
    		if (length > 128) {
    			//联系地址不能超过128个字节
    			this.checkCertMsgFunc($UI, msgFunc, addrName + "不能超过128个字节");
    			return false;
    		}
    		return true;
        }
		return true;
	},
	
	/**
	 * US-20171009111409-2031039148
	 * 校验证件地址或常用地址，输入长度不能超过128个字节
	 */
	checkCustAddress2: function(custAddress, $UI, addrName, msgFunc) {
		debugger;
		var length = this.countCharacters(custAddress);
		var $scope = $(document).scope();
		$Page = $scope.$Page;
        if ($Page.projectVersion == "NINGXIA") {
    		if (length > 128) {
    			//证件地址（或常用地址）不能超过128个字节
    			this.checkCertMsgFunc($UI, msgFunc, addrName + "不能超过128个字节");
    			return false;
    		}
    		return true;
        }
		return true;
	},
	
	/**
	 * Add by wwx392692 at 2017/10/31 for DTS2017102803022
	 * 由于江苏完善资料当登陆鉴权为AuthCheckRND， 没有明文令牌并且没有进行金库鉴权去模糊化时，客户信息的证件姓名是模糊化的特殊性，仅以此方法校验完善
	 * 资料的客户信息中的客户姓名
	 * 
	 * 校验客户的证件姓名 按照实名制规则修改 不超过256位 身份证、军官证、警官证姓名规范： 1) 不能为空。 2) 长度2个汉字（4个字节）及以上。
	 * 3) 只包含简体汉字与“•”（包括半角全角的各类•）。 4) 身份证不能一个证件号码对应多个不同的姓名。 港澳证、台胞证姓名规范： 1)
	 * 不能为空。 2) 长度2个汉字（4个字节）及以上。 3) 只包含简体汉字与“•”（包括半角全角的各类•）。 护照姓名规范： 1)
	 * 名称须大于等于3个字节。 2) 不能全为阿拉伯数字。 3) 除“•”外 ，不能有汉字符号。
     *
     *      实名制整改计划
	 */
    checkCertNameCharForCompleteProfile: function(certType, userName, $UI, msgFunc) {
        debugger;
        var $scope = $(document).scope();
		$Page = $scope.$Page;
        if (!userName) {
            this.checkCertMsgFunc($UI, msgFunc, "请输入证件姓名。");
            return false;
        }
        var certTypeList1 = ["IdCard", "PLA", "PolicePaper", "HKMCPassport", "TaiBaoZheng","SoldierID","SoldierIdCard"];
        if ($Page.projectVersion == "JIANGSU"){
        	certTypeList1 = ["IdCard", "PLA", "PolicePaper", "HKMCPassport", "TaiBaoZheng","SoldierID","SoldierIdCard","HuKouBu","TempId"];
        }
        var certTypeList2 = ["CorpAggrCredential", "EnteAggrCredential", "OrgaCredential", "UnitsTestify", "BusinessLicence"];
        // 完善资料登陆鉴权为AuthCheckRND， 没有明文令牌并且没有进行金库鉴权去模糊化，则不进行客户姓名的校验
        if (!($Page.completeProfileRealAuthType == "AuthCheckRND" && $Page.isTreasury && !$Page.isHasDoUnFuzzyAuth)) {
        	if ($.inArray(certType, certTypeList1) > -1) {
                return this.checkIndividualCertName(userName, $UI, msgFunc);
            } else if (certType == 'Passport') {
                return this.checkPassportCertName(userName, $UI, msgFunc);
            } else if (certType == 'IdCardEx') {
            	return this.checkIdCardExName(userName, $UI, msgFunc);
            } else if ($.inArray(certType, certTypeList2) > -1) {
                return this.checkGroupCertName(userName, $UI, msgFunc);
            }
        }
        
        return true;
    },
	
	/**
	 * 校验客户的证件姓名 按照实名制规则修改 不超过256位 身份证、军官证、警官证姓名规范： 1) 不能为空。 2) 长度2个汉字（4个字节）及以上。
	 * 3) 只包含简体汉字与“•”（包括半角全角的各类•）。 4) 身份证不能一个证件号码对应多个不同的姓名。 港澳证、台胞证姓名规范： 1)
	 * 不能为空。 2) 长度2个汉字（4个字节）及以上。 3) 只包含简体汉字与“•”（包括半角全角的各类•）。 护照姓名规范： 1)
	 * 名称须大于等于3个字节。 2) 不能全为阿拉伯数字。 3) 除“•”外 ，不能有汉字符号。
     *
     *      实名制整改计划
	 */
    checkCertNameChar: function(certType, userName, $UI, msgFunc) {
        debugger;
        var $scope = $(document).scope();
		$Page = $scope.$Page;
        if (!userName) {
            this.checkCertMsgFunc($UI, msgFunc, "请输入证件姓名。");
            return false;
        }
        var certTypeList1 = ["IdCard", "PLA", "PolicePaper", "HKMCPassport", "TaiBaoZheng","SoldierID","SoldierIdCard"];
        if ($Page.projectVersion == "JIANGSU"){
        	certTypeList1 = ["IdCard", "PLA", "PolicePaper", "HKMCPassport", "TaiBaoZheng","SoldierID","SoldierIdCard","HuKouBu","TempId"];
        }
        var certTypeList2 = ["CorpAggrCredential", "EnteAggrCredential", "OrgaCredential", "UnitsTestify", "BusinessLicence"];
        if ($.inArray(certType, certTypeList1) > -1) {
            return this.checkIndividualCertName(userName, $UI, msgFunc);
        } else if (certType == 'Passport') {
            return this.checkPassportCertName(userName, $UI, msgFunc);
        } else if (certType == 'IdCardEx') {
        	return this.checkIdCardExName(userName, $UI, msgFunc);
        } else if ($.inArray(certType, certTypeList2) > -1) {
            return this.checkGroupCertName(userName, $UI, msgFunc);
        }
        
        return true;
    },

    /**
	 * 个人证件客户名校验
     *
     *      实名制整改计划
	 */
    checkIndividualCertName: function(userName, $UI, msgFunc) {
        var length = this.countCharacters(userName);
        //var reg = /^([\u4e00-\u9fa5]|\•|\·)*$/; // 有些汉字生僻字没有包含，会被校验住
        var reg = /^([\u2E80-\uFE4F]|\•|\·)*$/;
        var $scope = $(document).scope();
		$Page = $scope.$Page;
		var uiinfo = "身份证、军官证、警官证、士兵证、港澳证、台胞证、军人身份证的用户姓名只能包括汉字与•或·";
		if ($Page.projectVersion == "JIANGSU"){
			uiinfo = "身份证、港澳证、台胞证、军人身份证、武装警察身份证、户口簿、临时身份证只能包括汉字与•或·"
		}
        if (!reg.test(userName)) {
            this.checkCertMsgFunc($UI, msgFunc, uiinfo);
            return false;
        } else if (length < 4 || length > 256) {
            // 姓名至少2个汉字或4个字符，不超过256位
            this.checkCertMsgFunc($UI, msgFunc, $UEE.i18n('ad.person.message.IncorretUserNameLength'));
            return false;
        } else if (this.containSBCCaseChar(userName)) { //此处单独校验《》【】。等特殊字符
        	this.checkCertMsgFunc($UI, msgFunc, uiinfo);
            return false;
        }
        return true;
    },
    /**
	 * 护照客户名校验
     *
     *      实名制整改计划
	 */
    checkPassportCertName: function(userName, $UI, msgFunc) {
        var length = this.countCharacters(userName);
        if (length < 3 || length > 256) {
            this.checkCertMsgFunc($UI, msgFunc, "护照姓名至少3个字节，不超过256个字节.");
            return false;
        } else if (this.checkNumberChar(userName)) {
            this.checkCertMsgFunc($UI, msgFunc, '护照姓名不能全为阿拉伯数字');
            return false;
        } else if (this.containSBCCaseChar(userName)) {
            this.checkCertMsgFunc($UI, msgFunc, "护照姓名除“·•”外 ，不能包含汉字符号");
            return false;
        }
        return true;
    },
    /**
     * 外国人永久居留证客户名校验
     *
     *      实名制整改计划
     */
    checkIdCardExName: function(userName, $UI, msgFunc) {
    	var $scope = $(document).scope();
		$Page = $scope.$Page;
		var uiinfo = "外国人永久居留证姓名除“·•”外 ，不能包含汉字符号";
		if ($Page.projectVersion == "JIANGSU"){
			uiinfo = "仅有英文字母和空格组成，不得出现中文，支持有逗号的姓名，不能含有阿拉伯数字";
		}
    	var length = this.countCharacters(userName);
    	if (length < 3 || length > 256) {
    		this.checkCertMsgFunc($UI, msgFunc, "外国人永久居留证姓名至少3个字节，不超过256个字节.");
    		return false;
    	} else if (!(this.checkNumberChar2(userName))&& $Page.projectVersion == "NINGXIA") {
            this.checkCertMsgFunc($UI, msgFunc, '外国人永久居留证姓名不包括阿拉伯数字');
            return false;
        } else if (!(this.checkNumberChar1(userName)) && $Page.projectVersion == "JIANGSU") {
    		this.checkCertMsgFunc($UI, msgFunc, uiinfo);
    		return false;
    	}else if (this.validataChina(userName)&& $Page.projectVersion == "JIANGSU") {
    		this.checkCertMsgFunc($UI, msgFunc, uiinfo);
    		return false;
    	}
    	return true;
    },
    /**
	 * 集团证件客户名校验
     *
     *      实名制整改计划
	 */
    checkGroupCertName: function(userName, $UI, msgFunc) {
        var length = this.countCharacters(userName);
        var $scope = $(document).scope();
		$Page = $scope.$Page;
        if ($Page.projectVersion == "NINGXIA"){
			if($Page.selectedBatchDef && $Page.selectedBatchDef.id == "batchIMSInstall" && (userName.match(/[\u4E00-\u9FFF]/g).length<4 || length > 256)){
				this.checkCertMsgFunc($UI, msgFunc, "单位名称至少输入4个汉字，不超过256个字符");
				return false;
			}else if (length < 8 || length > 256) {
				this.checkCertMsgFunc($UI, msgFunc, "单位名称至少4个汉字或8个字符，不超过256位");
				return false;
			}
        }
        else if (length < 4) {
            this.checkCertMsgFunc($UI, msgFunc, "客户名称至少2个汉字或者4个字符");
            return false;
        }
        return true;
    },

	/**
	 * 校验客户的地址 按照实名制规则修改 不能为空  * 证件地址不能超过512位(或256个汉字)  * 证件地址至少16位字节  *
	 * 除了护照外的证件地址至少8个汉字
     *
     *      实名制整改计划
	 */
    checkCustAddress: function(certType, custAddress, $UI, addrName, msgFunc) {
        if (!custAddress) {
            this.checkCertMsgFunc($UI, msgFunc, "请输入" + addrName);
            return false;
        }

        var length = this.countCharacters(custAddress);
        
        var $scope = $(document).scope();
		$Page = $scope.$Page;
        if ($Page.projectVersion == "NINGXIA"){
        	//宁夏开户、过户、改资料、补资料、批量开户、批量改资料、批量补资料等，限制地址长度不能超过128个字节。
        	if (length > 128) {
    			//不能超过128个字节
    			this.checkCertMsgFunc($UI, msgFunc, addrName + "不能超过128个字节");
    			return false;
    		} else if (length < 12) {
    			//至少12个字节
    			this.checkCertMsgFunc($UI, msgFunc, addrName + "至少12个字节");
    			return false;
    		} else if (certType != 'Passport') {
    			if(!this.countChineseCharacters(custAddress)){
    				this.checkCertMsgFunc($UI, msgFunc, addrName + "不少于6个汉字。");
    				return false;
    			}
    		}
        }else{
        	if (length > 512) {
                // 不能超过512个字节
                this.checkCertMsgFunc($UI, msgFunc, addrName + "不能超过512个字节");
                return false;
            } else if (length < 16) {
                // 至少16个字节
                this.checkCertMsgFunc($UI, msgFunc, addrName + "至少16个字节");
                return false;
            } else if (certType != 'Passport') {
                if (this.countChineseCharacters(custAddress) < 8) {
                    this.checkCertMsgFunc($UI, msgFunc, addrName + "不少于8个汉字。");
                    return false;
                }
            }
        }
        return true;
    },

    /**
     * OFFER相关整改计划
     * @param offer
     */
	changeEffTypes : function(offer) {
		debugger;
		offer.showEffDateFlag = false;
		offer.showEffCycleFlag = false;
		offer.showEffFixStartDateFlag = false;
		offer.showPostPointFlag = false;// add by zWX270193 增加顺延节点

		if (offer.ocEffectiveMode.selectedMode == "C") { // 指定时间生效
			offer.showEffDateFlag = true;
		} else if (offer.ocEffectiveMode.selectedMode == "S") { // 特定周期
			offer.showEffCycleFlag = true;
		} else if (offer.ocEffectiveMode.selectedMode == "F") { // 固定时间
			offer.showEffFixStartDateFlag = true;
		} else if (offer.ocEffectiveMode.selectedMode == "P") {
			offer.showPostPointFlag = true;// add by zWX270193 增加顺延节点
		}
	},

    /**
     * OFFER相关整改计划
     * @param offer
     */
	changeExpTypes : function(offer) {
		debugger;
		offer.showExpDateFlag = false;
		offer.showExpCycleFlag = false;
		offer.showExpFixStartDateFlag = false;
		offer.showPostPointFlag = false;// add by zWX270193 增加顺延节点

		if (offer.ocExpireMode.selectedMode == "C") { // 指定时间生效
			offer.showExpDateFlag = true;
		} else if (offer.ocExpireMode.selectedMode == "S") { // 特定周期
			offer.showExpCycleFlag = true;
		} else if (offer.ocExpireMode.selectedMode == "F") { // 固定时间
			offer.showExpFixStartDateFlag = true;
		} else if (offer.ocExpireMode.selectedMode == "P") {
			offer.showPostPointFlag = true;// add by zWX270193 增加顺延节点
		}
	},

    /**
     * OFFER相关整改计划
     * @param offer
     * @param scene
     * @returns {boolean}
     */
	validateBundleOffer : function(offer, scene) {
		// 如果为空则不校验
		if (!offer.ocOfferingSelectRule){
			return true;
		}
		if (!offer.ocOfferInfoVA||(offer.ocOfferInfoVA || []).length==0){
			return true;
		}
		var selectedNum = 0;
		var selectedPrice = 0;
		for ( var i = 0; i < (offer.ocOfferInfoVA || []).length; i++) {
			if (offer.ocOfferingSelectRule.bundledType == "1"
					&& offer.ocOfferInfoVA[i].isBundleSelected != "Y") {
				// 请订购商品包：xx的所有子产品。
				$(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						$UEE.i18n("ad.person.message.SubscribeAllSubofferings",[offer.offerName]));
				return false;
			}
			if (offer.ocOfferInfoVA[i].isBundleSelected == "Y") {
				selectedNum++;
				selectedPrice += parseInt(offer.ocOfferInfoVA[i].memberValue || 0);
			}
		}

		var maxNumber = offer.ocOfferingSelectRule.maxNumber;
		var minNumber = offer.ocOfferingSelectRule.minNumber;
		if (offer.ocOfferingSelectRule.bundledType == "3") {
			// modify by wuyuxin/wwx175926 for DTS2015102400089
			// 客户觉得拗口,拆分为两个，提示更准确
			if (selectedNum < minNumber && scene != 'checkMax') {
				// 请最少订购商品包：xx的xx个子商品。
				$(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						$UEE.i18n("ad.person.message.SubscribeLeastSubofferings",[offer.offerName,""+minNumber]));
				return false;
			} else if (selectedNum > maxNumber && maxNumber > 0) {
				// 请最多订购商品包：xx的xx个子商品。
				$(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						$UEE.i18n("ad.person.message.SubscribeMostSubofferings",[offer.offerName,""+maxNumber]));
				return false;
			}
		} else if (offer.ocOfferingSelectRule.bundledType == "4") {
			if (selectedPrice > maxNumber || selectedPrice < minNumber) {
				// 选择商品包[xx]内子商品累计价值不在规定范围内[最大值：xx, 最小值：xx].
				$(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						$UEE.i18n("ad.person.message.AccumulatedValueOutOfRange",[offer.offerName,maxNumber+"",minNumber+""]));
				return false;
			}
		}

		return true;
	},

    /**
     * OFFER相关整改计划
     * @param offer
     * @param validateObj
     */
	validateAddiOffer : function(offer, validateObj) {
		if (offer.isbindOffer == "Y") {
			if (!adutil.validateBundleOffer(offer)) {
				validateObj.flag = false;
				return;
			}

			$.each(offer.ocOfferInfoVA || [], function(i, vali) {
				if (vali.isBundleSelected == "Y") {
					adutil.validateAddiOffer(vali, validateObj);
					if (!validateObj.flag) {
						return false;
					}
				}
			});
		} else {
			$.each(offer.ocOfferingAttrPOJO || [], function(i, vali) {
				if (vali.isNullable != 'Y' && (vali.attrKey == null || vali.attrKey == "")) {
					validateObj.flag = false;
					// "请先设置：xx的属性信息。
					$(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
							$UEE.i18n("ad.person.message.SetAttributesFirst",[offer.offerName]));
					return false;
				}
			});

			if (!validateObj.flag) {
				return;
			}

			// 校验有线业务是否设置
			if (offer.offerType == "OTWiredBand" && !offer.isPTWireSetted) {
				validateObj.flag = false;
				// 请先设置：xx。
				$(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						$UEE.i18n("ad.person.message.SetFirst",[offer.offerName]));
				return;
			}
		}
	},

    /**
     * OFFER相关整改计划
     * @param offers
     * @returns {boolean}
     */
	validateAddiOffers : function(offers) {
		var validateObj = {
			flag : true
		};

		$.each(offers || [], function(i, vali) {
			adutil.validateAddiOffer(vali, validateObj);
			if (!validateObj.flag) {
				return false;
			}
		});

		return validateObj.flag;
	},

    /**
     * OFFER相关整改计划
     * @param relaAddiProd
     * @returns {Array}
     */
	getSelectedRelaAddiProd : function(relaAddiProd) {
		var result = [];
		$.each(relaAddiProd || [], function(i, vali) {
			if (vali.selected || vali.relaType == "N") {
				result.push($.extend(true, {}, vali));
			}
		});
		return result;
	},

    /**
     * OFFER相关整改计划
     * @param offer
     * @param actionType
     * @param assembleProp
     * @returns {{}}
     */
	// 获取O类型订单项
	getOrderItemO : function(offer, actionType, assembleProp) {
		debugger;
		var destOrder = {};
		offer.relaOrderItemId = offer.relaOrderItemId || adutil.getNextNumber();
		offer.actionType = actionType;

		destOrder.relaOrderItemId = offer.relaOrderItemId;
		destOrder.itemId = offer.offerId;
		destOrder.itemType = "O";
		destOrder.itemName = offer.offerName;
		destOrder.actionType = offer.actionType;
		destOrder.bindMarketingId = offer.bindMarketingId;
		destOrder.orderItemInfo = [];

		offer.selectedEffExpDetail = offer.selectedEffExpDetail || {};
		// 生效方式
		if (offer.ocEffectiveMode && offer.ocEffectiveMode.selectedMode) {
			destOrder.orderItemTerm = destOrder.orderItemTerm || [];
			offer.ocEffectiveMode.durationUnit = offer.ocEffectiveMode.durationUnit || {};

			var selectedType = {};
			$.each(offer.ocEffectiveMode.effectiveTypes || [], function(i, vali) {
				if (vali.selected) {
					selectedType = vali;
				}
			});
			// 拼om报文时将次日转成特定周期
			var selectedMode = offer.ocEffectiveMode.selectedMode == "P" ? "C"
					: offer.ocEffectiveMode.selectedMode;
			if(selectedMode == "ND") {
				selectedMode = "S";
			}
			destOrder.orderItemTerm
					.push({
						actionType : actionType,
						termCode : "effectiveMode",
						termContent : JSON.stringify({
							mode : selectedMode,
							durationUnit : offer.ocEffectiveMode.durationUnit.key || "",
							durationValue : offer.ocEffectiveMode.durationValue || 0,
							fixStartDate : offer.ocEffectiveMode.fixStartDate || "",
							primaryOfferingId : selectedType.primaryOfferingId,
							businessCode : selectedType.businessCode,
							isDefault : "Y"
						})
					});

			if (offer.ocEffectiveMode.selectedMode == "C"
					|| offer.ocEffectiveMode.selectedMode == "P") {
				destOrder.effectiveDate = offer.ocEffectiveMode.effectiveDate;
				// 如果选择了失效时间，则组装失效时间，必须将失效模式同步为“C”
				if (offer.ocExpireMode && offer.ocExpireMode.expireDate) {
					// 同步失效模式和生效模式一致
					offer.ocExpireMode.selectedMode = "C";
				}
			}

			offer.selectedEffExpDetail.selectedEffMode = offer.ocEffectiveMode.selectedMode == "P" ? "C"
					: offer.ocEffectiveMode.selectedMode;
			offer.selectedEffExpDetail.effectiveDate = offer.ocEffectiveMode.effectiveDate;
		}

		// 失效方式
		if (offer.ocExpireMode && offer.ocExpireMode.selectedMode) {
			destOrder.orderItemTerm = destOrder.orderItemTerm || [];
			offer.ocExpireMode.durationUnit = offer.ocExpireMode.durationUnit || {};
			// 拼om报文时将次日转成特定周期
			var selectedMode = offer.ocExpireMode.selectedMode;
			if(selectedMode == "ND") {
				selectedMode = "S";
			}
			destOrder.orderItemTerm.push({
				actionType : actionType,
				termCode : "expireMode",
				termContent : JSON.stringify({
					mode : selectedMode,
					durationUnit : offer.ocExpireMode.durationUnit.key || "",
					durationValue : offer.ocExpireMode.durationValue || 0,
					fixEndDate : offer.ocExpireMode.fixEndDate || "",
					isDefault : "Y"
				})
			});

			if (offer.ocExpireMode.selectedMode == "C") {
				destOrder.expiryDate = offer.ocExpireMode.expireDate;
			}

			offer.selectedEffExpDetail.selectedExpMode = offer.ocExpireMode.selectedMode;
			offer.selectedEffExpDetail.expireDate = offer.ocExpireMode.expireDate;
		}

		destOrder.selectedEffExpDetail = offer.selectedEffExpDetail || {};

		if (offer.isbindOffer == "Y") {
			$.each(offer.ocOfferInfoVA || [], function(i, vali) {
				if (vali.isBundleSelected == "Y") {
					// add begin by y00227433 批量增值产品变更 设置子offer的action
					if (vali.selectedOperatorMode) {
						actionType = vali.selectedOperatorMode;
					}
					// add end by y00227433 批量增值产品变更 设置子offer的action
					
					// 宁夏批量业务增值商品子offer允许重复订购的,如果商品订购数量selectNum大于1，则组装多个该offer
					if ($Page.projectVersion == 'NINGXIA' && $Page.batchType && vali.selectNum && vali.selectNum > 1) {
						for (var i = 0; vali.selectNum - i > 0; i++) {
							//Add by wwx392692 at  2017/11/2  for DTS2017110111126 begin 
							// 组装增值商品重复订购的子offer，但要保证relaOrderItemId的唯一性
							if (i > 0) {
								vali.relaOrderItemId = vali.relaOrderItemId + 1000;
							}
							//Add by wwx392692 at  2017/11/2  for DTS2017110111126 end 
							destOrder.orderItemInfo.push(adutil.getOrderItemO(vali, actionType, assembleProp));
						}
					} else {
						destOrder.orderItemInfo.push(adutil.getOrderItemO(vali, actionType, assembleProp));
					}
				}
			});
		}

		$.each(offer.ocProductInfoVA || [], function(j, valj) {
			if (valj.isPrimary == "Y") {
				adutil.globalData.mainOfferingId = offer.offerId;
				adutil.globalData.mainProductId = valj.productId;
				adutil.globalData.mainProductIdentityTRSVO = valj.ocPcProductIdentityTRSVO || [];
			}

			destOrder.orderItemInfo.push(adutil.getOrderItemP(valj, actionType));
		});

		// 需要组装属性节点
		if (assembleProp) {
			destOrder.orderItemProp = destOrder.orderItemProp || [];
			$.each(offer.ocOfferingAttrPOJO || [], function(i, val) {
				// 如果包含复杂属性 ，则组装所有复杂属性子属性信息  add by wwx292225 17/09/13
				if(val.isComplex == "Y")
				{
					$.each(val.subAttr || [], function(j, valj) {
						var subExtProp = [];
						$.each(valj.subExtPropInfo || [], function(k, valk) {
								subExtProp.push({
									actionType : actionType,
									propId : valk.attributeId,
									propCode : valk.attributeCode,
									sValue : valk.attrKey,
									complexFlag : valk.isComplex || "N",
									entityRoute : valk.attibuteOwnerPath
								});
						});
						
						destOrder.orderItemProp.push({
							actionType : actionType,
							propId : val.attributeId,
							propCode : val.attributeCode,
							sValue : "22",
							complexFlag : val.isComplex || "N",
							entityType : "O",
							entityRoute : val.attibuteOwnerPath,
							encryptMethod : val.encryptMethod,
							isNeedEncrypt : val.isNeedEncrypt || "N",
							subExtPropInfo : subExtProp
						});
					});
				}
				// 17/09/13  end 
				
				if(adutil.validateEnableVA(val.ocPcOfferingAttributeEnableVA,"INS"))
				{
					return true;// 如果包含INS控制项，则不进行实例化。跳出本次循环，进入下一次属性设置循环。
				}
				if (val.attrKey) {
					destOrder.orderItemProp.push({
						actionType : actionType,
						propId : val.attributeId,
						propCode : val.attributeCode,
						sValue : val.attrKey,
						complexFlag : val.isComplex || "N",
						entityType : "O",
						entityRoute : val.attibuteOwnerPath,
						encryptMethod : val.encryptMethod,
						isNeedEncrypt : val.isNeedEncrypt || "N"
					});
				}
			});
		}
		// add by zWX270193 2015/09/08 增加
		if (offer.orderItemRelation) {
			destOrder.orderItemRelation = $.extend(true, [], offer.orderItemRelation);
		}
		// 2015/09/08 end
		// add by zWX270193 2015/09/21
		if (offer.orderItemTerm) {
			destOrder.orderItemTerm = destOrder.orderItemTerm || [];
			$.each(offer.orderItemTerm || [], function(j, valj) {
				destOrder.orderItemTerm.push(valj);
			});
		}
		// end
		// 合同管理
		if (offer.contract) {
			destOrder.orderItemTerm = destOrder.orderItemTerm || [];
			destOrder.orderItemTerm.push({
				actionType : actionType,
				termCode : "contractDuration",
				termContent : JSON.stringify(offer.contract)
			});
		}

		return destOrder;
	},

    /**
     * OFFER相关整改计划
     * @param prod
     * @param actionType
     * @returns {{}}
     */
	// 获取P类型订单项
	getOrderItemP : function(prod, actionType) {
		var destProd = {};
		prod.relaOrderItemId = adutil.getNextNumber();
		prod.actionType = actionType;

		destProd.relaOrderItemId = prod.relaOrderItemId;
		destProd.itemId = prod.productId;
		destProd.itemType = "P";
		destProd.actionType = prod.actionType;
		if (prod.complexFlag == "Y") {
			destProd.orderItemInfo = [];
			$.each(prod.ocProductInfoVA || [], function(i, vali) {
				destProd.orderItemInfo.push(adutil.getOrderItemP(vali,
						actionType));
			});
		}
		// 参与者信息
		if (prod.orderPartyRole) {
			destProd.orderPartyRole = $.extend(true, [], prod.orderPartyRole);
		}
		// 识别码信息
		if (prod.orderItemIdentity) {
			destProd.orderItemIdentity = $.extend(true, [],
					prod.orderItemIdentity);

			$.each(destProd.orderItemIdentity, function(i, vali) {
				vali.actionType = actionType;
			});
		}
		// 资源信息
		if (prod.orderItemResource) {
			destProd.orderItemResource = $.extend(true, [],
					prod.orderItemResource);

			$.each(destProd.orderItemResource, function(i, vali) {
				vali.actionType = actionType;
			});
		}
		// 地址信息
		if (prod.itemAddrInfo) {
			destProd.itemAddrInfo = $.extend(true, [], prod.itemAddrInfo);
		}
		// 施工信息
		if (prod.constructExInfo) {
			destProd.constructExInfo = $.extend(true, {}, prod.constructExInfo);
		}
		// 施工信息
		if (prod.newConstructExInfo) {
			destProd.newConstructExInfo = $.extend(true, {},
					prod.newConstructExInfo);
		}
		// 添加关联节点
		if (prod.orderItemRelation) {
			destProd.orderItemRelation = $.extend(true, [],
					prod.orderItemRelation);
		}
		if (adutil.globalData.mainProductId == prod.productId) {
			adutil.globalData.mainProd = destProd || {};
		}
		return destProd;
	},

    /**
     * OFFER相关整改计划
     * @param offers
     * @returns {*}
     */
	getOfferingList : function(offers) {
		return $.grep(offers, function(n, i) {
			if (n.isbindOffer == "Y") {
				n.ocOfferInfoVA = adutil.getOfferingList(n.ocOfferInfoVA);
			}

			return n.isBundleSelected == "Y";
		});
	},

    // 常量
    idenTypeCode : {
        BroadBandAccountId : "BroadBandAccountId", // 宽带帐号
        OUTER_SERVNUMBER : "OUTER_SERVNUMBER", // 政企通固话
        GRP_MEM_IMS_FSISDN : "GRP_MEM_IMS_FSISDN", // IMS固话开户
        FSIDN : "rsclT.ft.yx", // 有线固话
        MSISDN : "MSISDN", // 移动号码
        ICCID : "ICCID", // 集成电路卡识别码
        IMSI : "IMSI", // 国际移动用户识别码
        MSISDN12 : "MSISDN12" // 家庭融合IMS固话服务
    },

	// 客户常量信息
	customerParams : {
		OPER_TYPE : {
			ADD : "1",
			MODIFY : "2",
			DELETE : "3",
			NOCHANGE : "4"
		},
		PARTY_TYPE : {
			PERSON : "1", // 个人客户
			GROUP : "2" // 集团客户
		},
		CUST_ROLE_ID : {
			ENROLL : "31415" // 注册客户
		},
		CUST_TYPE : {
			PERSON : "1" // 个人
		},
		CUST_CLASS : {
			FORMAL : "1" // 正式客户
		},
		CUST_STATUS : {
			ACTIVE : "2" // 激活客户
		},
		ADDRREF_PURPOSEID : {
			RESIDENT_ADDR : "6010506001" // 常驻地址
		},
		CONTACT_PERSON_TYPE : {
			ACCOUNT_PERSON : "1", // 账单联系人
			SEND_ADDR_PERSON : "2", // 递送联系人
			BUSI_PERSON : "3", // 业务联系人
			ORDER_PERSON : "4", // 订单类型人
			PERSON_CONTACT : "5" // 客户联系人
		},
		CTREF_ENTITY_TYPE : {
			PARTY : "1", // 参与者
			CUST : "2", // 客户
			PARTNER : "3", // 合作伙伴
			TELE_OPERATOR : "4" // 运营商员工
		},
		CONTACT_TYPE_ID : {
			EMAIL_ADDR : "101", // Email地址
			CONNECT_ADDR : "104", // 联系地址
			CONNECT_PHONE : "105" // 联系电话
		},
		INDIVIDUAL_PROPERTY_ID : {
			STATIC_AREA : "10042", // 静态区域
			WORK_STATION : "10041", // 工作部门
			CUST_MAIN_PAGE : "10038", // 客户主页
			REMARK : "10039", // 备注
			HOME_PHONE : "10035", // 家庭电话
			WORK_PHONE : "10036", // 办公电话
			MOBILE_PHONE : "10037", // 移动电话
			POLITICAL_STATUS : "10045" // 政治面貌
		},
		ACCT_CLASS : {
			FORMAL : "1" // 1.正式账户
		},
		ACCT_STATUS : {
			VALID : "2" // 2.有效
		},
		PAYMENT_MODE : {
			PRE_ACCT : "0", // 预付费
			POST_ACCT : "1" // 后付费
		},
		DEFAULT_CUST_ITEM_CODE : {
			SEX : "1", // 性别
			NATIONALITY : "China" // 国家
		}
	},

	offeringProdType : {
		COMM : "COMM",
		YKSH : "YKSH",
		XQKD : "PTCellBroadband",
		XYKD : "PTCampusBroadband"
	},

	// 标准地址第三方出参
	gimsAddr : {},

	// 标准地址第三方出参属性与接口属性映射表
	gimsMapProp : {
		addrID : "addressId",
		districtName : "districtName",
		districtID : "districtId",
		addrName : "addressName",
		carrier : "supplyType",
		PM : "factoryType",
		radius : "radiusType",
		userType : "gimsUserType",
		areaType : "gimsAreaType",
		networkType : "networkType",
		schoolCode : "schoolCode",
		schAreaCode : "schoolAreaCode",
		ponType : "PonType",
		callFor : "callFor",
		isCurrentDayFinish : "isCurrentDayFinish"
	},

	// 宁夏 标准地址第三方出参属性与接口属性映射表 右侧是属性iD，左侧是第三方id和桩页面id
	gimsMapPropForNX : {
        addrID : "addrID",//标准地址ID
        districtName : "uptownName",//小区名称
        districtID : "uptownId",//小区ID
        addrName : "addrName",//地址全称
        workType : "workType",//合作模式
        accessType : "accessType",//接入方式
        cityCode : "cityCode",//地市编码
        areaCode : "areaCode",//区县编码
        freeCapacity : "freeCapacity",//可装容量
        businessType : "businessType",//业务类型
        //wwx386871
        /*
        addrInfoID : "addrInfoID",//标准地址ID
        cellName : "cellName",//小区名称
        cellId : "cellId",//小区ID
        addrInfo : "addrInfo",//地址全称
        countryInfo : "countryInfo",//区县名称
        countryID : "countryID",//区县ID
        cityInfo : "cityInfo",//地市名称
        cityID : "cityID",//地市ID
        */
        KDZH :"userAcct", //宽带账号

        //宽带地址回传需要的属性，共19个
        addressName: "addressName",//详细地址
        buildingId: "buildingId",//楼ID
        buildingName: "buildingName",//楼名称
        cityId: "cityId",//地市ID
        cityName: "cityName",//地市名称
        countyId: "countyId",//区县ID
        countyName: "countyName",//区县名称
        FlorName: "FlorName",//层名称
        Florid: "Florid",//层ID
        houseId: "houseId",//房号ID
        houseName: "houseName",//房号名称
        roadId: "roadId",//路巷ID
        roadName: "roadName",//路巷名称
        townId: "townId",//乡镇ID
        townName: "townName",//乡镇名称
        unitId: "unitId",//单元ID
        unitName: "unitName",//单元名
        zoneId: "zoneId",//小区ID
        zoneName: "zoneName"//小区名称
    },
	// 山东irms第三方属性对应map
	irmsMapPropSD : {
		cityId:"cityId",
		countyId:"countyId",
		townId:"townId",
		roadId:"roadId",
		zoneId:"zoneId",
		buildingId:"buildingId",
		unitId:"unitId",
		Florid:"floorId",
		houseId:"houseId",
		address:"address",
		equName:"equName",
		equId:"equId",
		equType:"equType",
		freePort:"portNum",
		ownership:"ownership",
		vendor:"vendor",
		cityName:"cityName",
		countyName:"countyName",
		townName:"townName",
		roadName:"roadName",
		houseName:"houseName",
		zoneName:"zoneName",
		buildingName:"buildingName",
		unitName:"unitName",
		floorName:"floorName"
	},
	// 校验11位手机号码
    //  实名制整改计划
	checkPhoneNum : function(phoneNum) {
		debugger;
		if (phoneNum.length != 11 && phoneNum.length != 13) {
			return false;
		}
		var reg11 = /^1[345789]\d{9}$/;
		var thingNetNumReg = $Page.thingNetNumReg || "/^1064\\d{9}$/";
		var reg13 = eval(thingNetNumReg);
		if (phoneNum.length == 11 && !reg11.test(phoneNum)) {
			return false;
		}
		if(phoneNum.length == 13 && !reg13.test(phoneNum))
			{
			return false;
			}
		return true;
	},

    //  实名制整改计划
	checkOperatorInfoPhoneNumber : function(phoneNumber) {
		var len = phoneNumber.len();

		// 1.检查安全性
		if (!adutil.checkInputdata(phoneNumber)) {
			return false;
		}
		// 2.检查长度
		if (len > 32) {
			return false;
		}

		var reg = /^((0\d{2,3}\d{7,8})|(0\d{2,3}-\d{7,8})|(1[345789]\d{9}))$/;
		if (phoneNumber != '' && !reg.test(phoneNumber)) {

			return false;
		}

		return true;
	},

    // OFFER相关整改计划
	filterOcPcOfferingAttributeEnable : function(data,type){
		if("add" == type)
		{
			if(!adutil.validateEnableVA(data,"SIV"))
			{
				return false;
			}
			return true;
		}
		else if ("modify" == type)
		{
			if(!adutil.validateEnableVA(data,"CIV"))
			{
				return false;
			}
			return true;
		}
		else if ("delete" == type)
		{
			if(!adutil.validateEnableVA(data,"UIV"))
			{
				return false;
			}
			return true;
		}
		else
		{
			return true;
		}
	},

    // OFFER相关整改计划
	validateEnableVA : function(data,type){
		var flag = true;
		$.each(data || [],function(j,valj){
			if(valj.enableType == type)
			{
				flag = false;
				return false;
			}
		});
		return flag;
	},

	// 2015/10/05 如果客户年龄小于16岁要求必须录入监护人 实名制整改计划
	validateJHRCertInfo : function(syzInfo, userInfo, $UI) {

		debugger;

		var $scope = $(document).scope();
		$Page = $scope.$Page;
		if (!userInfo) {
			// 客户信息不能为空 。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CustomerInfoCannotEmpty"));
			return "-1";
		}

		var custCertType = userInfo.reserverCertType;
		var custCertId = $.trim(userInfo.reserverCertId);

		if (!custCertType || custCertType == "") {
			// 客户证件类型为空。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CertificateTypeEmpty"));
			return "-1";
		}

		if (!custCertId || custCertId == "") {
			// 客户证件ID为空。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CertificateIDEmpty"));
			return "-1";
		}

		if (custCertType == "IdCard" || custCertType == "TempId" || custCertType == "HuKouBu") {

			// 客户年龄标志，true 大于16岁 ， false 小于16岁
			var custAge16Flag = true;
			// 客户年龄标志，true 大于10岁 ， false 小于10岁
			var custAge10Flag = true;

			var age = 0;

			//江苏局点需要判断老用户是否满足16岁
			if("JIANGSU" == $Page.projectVersion && OC.Callchain.getServNum() && OC.Callchain.getServNum().length>0){
				if(custCertId && custCertId.length>0){
					if (custCertId.length == 15) {
						age = Math.floor(adutil.getFullAge("19"+custCertId.substring(6,12),""));
						if(age == -1)
						{
							return "3";
						}
					} else if (custCertId.length == 18) {
						age = Math.floor(adutil.getFullAge(custCertId.substring(6,14),""));
						if(age == -1)
						{
							return "3";
						}
					}else{
						return "3";
					}
				}else{
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"),"获取用户证件信息失败!");
					return "-1";
				}
			}else{
				if (custCertId.length == 15) {
					age = Math.floor(adutil.getFullAge("19"+custCertId.substring(6,12),""));
					if(age == -1)
					{
						return "3";
					}
				} else if (custCertId.length == 18) {
					age = Math.floor(adutil.getFullAge(custCertId.substring(6,14),""));
					if(age == -1)
					{
						return "3";
					}
				}else{
					return "3";
				}
			}
			
			
			//江苏局点要求客户年龄在16周岁需要添加监护人，swx552311  US-20180802110124-2031107358
			if("JIANGSU" == $Page.projectVersion){
				$Page.ageNeedGuardian = 16;
			}else{
				$Page.ageNeedGuardian = $Page.ageNeedGuardian || 16 ;
			}
			custAge16Flag = (age >= $Page.ageNeedGuardian);
			custAge10Flag = (age >= 10);

			//江苏局点要求客户年龄在16周岁需要添加监护人， swx552311  US-20180802110124-2031107358
			//之前虽然注释写的是16岁(下一条注释)，但是取值都是10岁。if(custAge10Flag)
			var custAgeFlag = true;
			if("JIANGSU" == $Page.projectVersion){
				custAgeFlag = custAge16Flag;
				if(!custAgeFlag){
					$Page.needAttorneys = true;//江苏局点未满16周岁，结算页面需要填写代办人信息
				}else{
					$Page.needAttorneys = false;
				}
			}else{
				custAgeFlag = custAge10Flag;
			}

			// 如果客户年龄在16岁以下，要求必须输入监护人
			if (!custAgeFlag) {
				// 使用者信息不存在就报错
				if (!syzInfo) {
					// 客户年龄小于xx岁，请录入监护人 。
					var needGuardianAge = 10;
					if("JIANGSU" == $Page.projectVersion){
						needGuardianAge = 16;
					}
					//(江苏局点开户、过户、快捷开户、产品恢复菜单，16岁以下不需要强制走监护人流程)
					if(!(("JIANGSU" == $Page.projectVersion) && (("60131101" == $Page.menuId) || ("60131_register" == $Page.menuId) || ("601312110" == $Page.menuId) || ("60131_productrecover" == $Page.menuId)))){
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CustomerYoungerThan16",[needGuardianAge]));
						return "-1";
					}
				}
				
				if(("JIANGSU" == $Page.projectVersion) && (("60131101" == $Page.menuId) || ("60131_register" == $Page.menuId) || ("601312110" == $Page.menuId) || ("60131_productrecover" == $Page.menuId)) && !$Page.hasOpenAccountAuth){
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "您没有操作此证件权限");
					return "-1";
				}
				
				if(syzInfo){
					var consumerCertType = syzInfo.value.reserverCertType;
					var consumerCertId = syzInfo.value.reserverCertId;
					
					if (consumerCertType == "IdCard" || consumerCertType == "TempId" || consumerCertType == "HuKouBu") {
						var consumerAge = 0;
						
						if (consumerCertId.length == 15) {
							consumerAge = Math.floor(adutil.getFullAge("19" + consumerCertId.substr(6, 6),""));
							if(consumerAge == -1)
							{
								return "7";
							}
						} else if (consumerCertId.length == 18) {
							consumerAge = Math.floor(adutil.getFullAge(consumerCertId.substr(6, 8),""));
							if(consumerAge == -1)
							{
								return "7";
							}
						}
						else{
							// 监护人证件ID为："+consumerCertId +
							// "，长度不符合规范，必须为15位或者18位证件ID。
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.GuardianIdNumberLengthRule",[consumerCertId]));
							return "7";
						}
						
						if (consumerAge < $Page.ageNeedGuardian) {
							// 监护人的年龄不能小于xx岁。
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.GuardianYoungerThan16",[$Page.ageNeedGuardian]));
							return "-1";
						}
					}
					// "监护人"
					return "7";
				}
			}
		}
		// 使用者
		return "3";
	},

	// 2015/10/06 改资料、补资料 16岁以下户口簿、身份证增加监护人 实名制整改计划
	validateCertAgeLess16 : function(custCertType, custCertId) {
		debugger;
		var $scope = $(document).scope();
		$Page = $scope.$Page;
		$UI = $scope.$UI;
		if (!custCertType || custCertType == "") {
			// "客户证件类型为空。"
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CertificateTypeEmpty"));
			return false;
		}

		if (!custCertId || custCertId == "") {
			// "客户证件ID为空。"
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CertificateIDEmpty"));
			return false;
		}

		//测试用
		debugger;
		if (custCertType == "TempId" || custCertType == "IdCard" || custCertType == "HuKouBu") {
			// 客户年龄标志，flase 大于16岁 ， true 小于16岁
			var custAge16Flag = false;

			// 客户年龄标志，flase 大于10岁 ， true 小于10岁
			var custAge10Flag = false;

			var age = 0;

			try{
				if (custCertId.length == 15) {
					age = Math.floor(adutil.getFullAge("19" + custCertId.substr(6, 6),""));
				} else if (custCertId.length == 18) {
					age = Math.floor(adutil.getFullAge(custCertId.substr(6, 8),""));
				} else {
					// 客户证件ID为：" + custCertId + "，长度不符合规范，必须为15位或者18位证件ID。
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CustomerIdNumberLengthRule",[custCertId]));
					return custAge16Flag;
				}
			} catch (e){
				// 客户证件信息有误，请检查。
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectCustomerCardInfo"));
				return custAge16Flag;
			}

			// 2016/12/10  DTS2016120505812      江苏10岁以下户口簿、身份证增加监护人 add by ywx352261
			if ($Page.projectVersion =='JIANGSU') {
				$Page.ageNeedGuardian = $Page.ageNeedGuardian || 10;

				if (age >= 16) {
					custAge16Flag = false;
					$Page.needAttorneys = false;//江苏局点未满16周岁，结算页面需要填写代办人信息
				} else {
					$Page.needAttorneys = true;//江苏局点未满16周岁，结算页面需要填写代办人信息
					custAge16Flag = true;
				}
				return custAge16Flag;
			}

			$Page.ageNeedGuardian = $Page.ageNeedGuardian || 16;
			if (age >= $Page.ageNeedGuardian) {
				custAge16Flag = false;
			} else {
				custAge16Flag = true;
			}
			return custAge16Flag;
		}

		return false;
	},

	// 2015/08/01 客户、担保人、使用者不能是同一证件类型对应的证件号码  实名制整改计划
	validateDupCertInfo : function(extInfo) {
		debugger;
		if (!extInfo) {
			return true;
		}

		var certInfoList = [];
		var custIdList = [];

		extInfo.registrant = extInfo.registrant || {};
        // 尼日利亚定制代码不走校验
        if(extInfo.registrant.intfCustomerAndIndividualInfoExt){
            return true;
        }

		var regCust = extInfo.registrant.intfCustomerAndIndividualInfo || {};
		// 如果是老客户开户
		var regCustId = "";
		if (!extInfo.registrant.intfCustomerAndIndividualInfo
				&& extInfo.registrant.custId) {
			regCustId = extInfo.registrant.custId;
			custIdList.push(regCustId);
		} else { // 新客户开户
			var regCertInfo = (regCust.reserverCertType || "")
					+ (regCust.reserverCertId || "");
			if (regCertInfo) {
				certInfoList.push(regCertInfo);
			}
		}

		var $consumerGadget = adutil.getGadgetObj($(".bes-ad-custinfo"));
		var consumerCustId = "";
		if (!extInfo.consumer && $consumerGadget
				&& $consumerGadget.$Page
				&& $consumerGadget.$Page.syzInfo
				&& $consumerGadget.$Page.syzInfo.value
				&& $consumerGadget.$Page.syzInfo.value.custId) {
			consumerCustId = $consumerGadget.$Page.syzInfo.value.custId;
			custIdList.push(consumerCustId);
		} else {
			extInfo.consumer = extInfo.consumer || {};
			var consumerCust = extInfo.consumer.intfCustomerAndIndividualInfo
					|| {};
			var consumerCertInfo = (consumerCust.reserverCertType || "")
					+ (consumerCust.reserverCertId || "");
			if (consumerCertInfo) {
				certInfoList.push(consumerCertInfo);
			}
		}

		var gurantorCustId = "";
		if (!extInfo.guarantor &&$consumerGadget
				&& $consumerGadget.$Page
				&& $consumerGadget.$Page.dbrInfo
				&& $consumerGadget.$Page.dbrInfo.value
				&& $consumerGadget.$Page.dbrInfo.value.custId) {
			gurantorCustId = $consumerGadget.$Page.dbrInfo.value.custId;
			custIdList.push(gurantorCustId);
		} else {
			extInfo.guarantor = extInfo.guarantor || {};
			var guarantorCust = extInfo.guarantor.intfCustomerAndIndividualInfo
					|| {};
			var guarantorCertInfo = (guarantorCust.reserverCertType || "")
					+ (guarantorCust.reserverCertId || "");
			if (guarantorCertInfo) {
				certInfoList.push(guarantorCertInfo);
			}
		}
		var orgLen = certInfoList.length;
		var custIdLen = custIdList.length;

		return $.unique(certInfoList).length == orgLen
				&& $.unique(custIdList).length == custIdLen;
	},

	// 普通方式校验证件类型：32位字节（不包括身份证）  实名制整改计划
	checkCertificateNumLen : function(certificateNum, $UI) {
		debugger;
		if (!certificateNum || $.trim(certificateNum).len() == 0) {
			// 请输入证件号码。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCertificateNumber"));
			return false;
		}
		if ($.trim(certificateNum).len() > 32 || certificateNum == 0) {
			// 您输入的证件号码有误，请重新输入。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ReEnterIncorrectCertificateNumber"));
			return false;
		}
		return true;
	},

	// 校验当前选择的证件类型是否在特性参数中配置  实名制整改计划
	checkCerTypeInArr : function(certificateType, certificateTypeValidateArr) {
		for ( var i = 0; i < certificateTypeValidateArr.length; i++) {
			if (certificateTypeValidateArr[i].itemCode == certificateType) {
				return true;
			}
		}
		return false;
	},

	/**
     * 校验证件类型前台公共方法  实名制整改计划
     *
	 * @param certificateNum
	 *            证件号码号码，非空
	 * @param certificateType
	 *            证件类型，可以为空，为空仅做长度校验
	 * @param certificateTypeValidateArr
	 *            调用数据字典查询证件类型特性参数返回结果，可以为空，为空仅做长度校验
	 * @return boolean
	 */
	checkCertificateNum : function(certificateNum, certificateType,
			certificateTypeValidateArr, $UI, specialCheckFunc, certificateTypeList) {
		// 1、证件类型为空（场景：操作员未择具体的证件类型，先输入证件号码，此时仅对证件号码做32位长度校验
		// （在提交、结算等操作前，要对证件类型做非空校验，确保证件类型不为空后再调用此方法
		// 2、证件类型不为空，判断证件类型是否在严格校验项中进行配置，若未配置，则做普通校验

		// 1、32位长度校验
		// MODIFY 32位长度校验
		debugger;
		if (!adutil.checkCertificateNumLen(certificateNum, $UI)) {
			return false;
		}

		// 证件类型为空，则仅作32位长度校验
		if (!certificateType) {
			return true;
		}

		// 个性化校验
		if (specialCheckFunc && specialCheckFunc[certificateType]) {
			return specialCheckFunc[certificateType](certificateNum, $UI);
		}
		// 士兵证：证件号码须大于等于6位字符  DTS2016122611745
        if (certificateType == 'SoldierID') {
            return adutil.checkSoldierID(certificateNum, $UI);
        }
		// 2、证件类型为身份证，则身份证号码合法性校验
		// MODIFY 2015-05-20根据现网场景，户口簿、驾驶证、
		if ("IdCard" == certificateType || "HuKouBu" == certificateType
				|| "DriverIC" == certificateType || "TempId" == certificateType 
				|| "SoldierIdCard" == certificateType ) {
			// certificateNum = adutil.certNum15To18(certificateNum,
			// certificateType, ["IdCard", "TempId", "DriverIC", "TempId"]);
			if(certificateTypeList && certificateTypeList.length > 0){
				return adutil.checkIdCard(adutil.certNum15To18(certificateNum, certificateType, ["IdCard", "TempId", "DriverIC", "TempId","PolicePaper","PLA"]), $UI, certificateType, certificateTypeList);
			}else{
				return adutil.checkIdCard(adutil.certNum15To18(certificateNum, certificateType, ["IdCard", "TempId", "DriverIC", "TempId","PolicePaper","PLA"]), $UI);
			}
		}
		if (("PLA" == certificateType || "PolicePaper" == certificateType) && $Page.projectVersion =='JIANGSU'){
			if(certificateTypeList && certificateTypeList.length > 0){
				return adutil.checkIdCard(adutil.certNum15To18(certificateNum, certificateType, ["IdCard", "TempId", "DriverIC", "TempId","PolicePaper","PLA"]), $UI, certificateType, certificateTypeList);
			}else{
				return adutil.checkIdCard(adutil.certNum15To18(certificateNum, certificateType, ["IdCard", "TempId", "DriverIC", "TempId","PolicePaper","PLA"]), $UI);
			}
		}
		// 判断过期证件--江苏问题
		if ("Conflict" != certificateType &&"IdCard" != certificateType && "IdCardEx" != certificateType && "HuKouBu" != certificateType && "DriverIC" != certificateType && "TempId" != certificateType && certificateType != 'PLA'
				&& certificateType != 'BusinessLicence' && certificateType != 'OrgaCredential' && certificateType != 'EnteAggrCredential' &&
					certificateType != 'HKMCPassport' && certificateType != 'TaiBaoZheng' && certificateType != 'PolicePaper' && certificateType != 'Passport' && certificateType != 'MarryUnkown'
					&& "UnitsTestify" != certificateType && "CorpAggrCredential" != certificateType && "IdCardGA" != certificateType && "IdCardTW" != certificateType && $Page.projectVersion =='JIANGSU')
				{
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "您的证件类型已过期，请修改！.");
				return false;
				}
		// 3、查询出的特性参数为空，则普通校验
		// 4、当前选择的证件类型没有做特性参数配置，则普通校验
		//cwx222275
		//DTS2017051307380宁夏直接验证判断证件2017/5/16
		if (certificateType != null && 'NINGXIA' == $Page.projectVersion)
		{
			// 5、当前选择的证件类型，做了特性参数配置
			// 5.1 证件类型为军官证：证件号码须大于等于6位字符
			if (certificateType == 'PLA') {
				return adutil.checkPLA(certificateNum, $UI);
			}

			// 5.2 营业执照：长度必须为15或18位
			if (certificateType == 'BusinessLicence') {
				return adutil.checkBusinessLicence(certificateNum, $UI);
			}

			// 5.3组织机构代码证：证件号码长度需满足10位，其规则为“XXXXXXXX-X”
			if (certificateType == 'OrgaCredential') {
				return adutil.checkOrgaCredential(certificateNum, $UI);
			}

			// 5.4事业单位法人登记证：证件号码长度需满足12位
			if (certificateType == 'EnteAggrCredential') {
				return adutil.checkEnteAggrCredential(certificateNum, $UI);
			}

			// 港澳通行证：证件号码为9位或11位,首位为英文字母“H”或“M”；其余位均为阿拉伯数
			if (certificateType == 'HKMCPassport') {
				return adutil.checkHKMCPassport(certificateNum, $UI);
			}

			// 台胞证：证件号码为11位时，前10位为阿拉伯数字，最后一位为校验码，括号内为英文字母或阿拉伯数字；证件号码为8位时，均为阿拉伯数字
			if (certificateType == 'TaiBaoZheng') {
				return adutil.checkTaiBaoZhengId(certificateNum, $UI);
			}
			// 警官证：证件号码须大于等于6位字符
			if (certificateType == 'PolicePaper') {
				return adutil.checkPolicePaperForNx(certificateNum, $UI);
			}
			// 护照：证件号码须大于等于6位字符
			if (certificateType == 'Passport') {
				return adutil.checkPassport(certificateNum, $UI);
			}
			// 歪果仁永久居留证：证件号码须为15位，校验前3位为大写英文字母，是国家编号，后12位为阿拉伯数字
			if (certificateType == 'IdCardEx') {
				return adutil.checkIdCardEx(certificateNum, $UI);
			}
		}else if (certificateTypeValidateArr
				&& adutil.checkCerTypeInArr(certificateType,
						certificateTypeValidateArr)) 
		{
			// 5、当前选择的证件类型，做了特性参数配置
			// 5.1 证件类型为军官证：证件号码须大于等于6位字符
			if (certificateType == 'PLA') {
				return adutil.checkPLA(certificateNum, $UI);
			}

			// 5.2 营业执照：长度必须为15或18位
			if (certificateType == 'BusinessLicence') {
				return adutil.checkBusinessLicence(certificateNum, $UI);
			}

			// 5.3组织机构代码证：证件号码长度需满足10位，其规则为“XXXXXXXX-X”
			if (certificateType == 'OrgaCredential') {
				return adutil.checkOrgaCredential(certificateNum, $UI);
			}

			// 5.4事业单位法人登记证：证件号码长度需满足12位
			if (certificateType == 'EnteAggrCredential') {
				return adutil.checkEnteAggrCredential(certificateNum, $UI);
			}

			// 港澳通行证：证件号码为9位或11位,首位为英文字母“H”或“M”；其余位均为阿拉伯数
			if (certificateType == 'HKMCPassport') {
				return adutil.checkHKMCPassport(certificateNum, $UI);
			}

			// 台胞证：证件号码为11位时，前10位为阿拉伯数字，最后一位为校验码，括号内为英文字母或阿拉伯数字；证件号码为8位时，均为阿拉伯数字
			if (certificateType == 'TaiBaoZheng') {
				return adutil.checkTaiBaoZhengIdjiangSu(certificateNum, $UI);
			}
			// 警官证：证件号码须大于等于6位字符
			if (certificateType == 'PolicePaper') {
				return adutil.checkPolicePaper(certificateNum, $UI);
			}
			// 护照：证件号码须大于等于6位字符
			if (certificateType == 'Passport') {
				return adutil.checkPassport(certificateNum, $UI);
			}
			// 歪果仁永久居留证：证件号码须为15位，校验前3位为大写英文字母，是国家编号，后12位为阿拉伯数字
			if (certificateType == 'IdCardEx') {
				return adutil.checkIdCardEx(certificateNum, $UI);
			}
			// 港澳居民居住证 18位非汉字
			if (certificateType == 'IdCardGA') {
				return adutil.checkIdCardGA(certificateNum, $UI);
			}
			// 台湾居民居住证 18位非汉字
			if (certificateType == 'IdCardTW') {
				return adutil.checkIdCardTW(certificateNum, $UI);
			}
		}
		

		return true;
	},
	
    // 士兵证：证件号码须大于等于6位字符
    checkSoldierID : function(certificateNum, $UI) {
        debugger;
        if (certificateNum != "") {
            certificateNum = $.trim(certificateNum);
        }
        if(this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
            $UI.msgbox.info("提示", "士兵证不能包含任何汉字符号");
            return false;
        }
        if (certificateNum == 0 || certificateNum.len() < 6) {
            // 请输入正确的士兵证号码，长度大于等于6位字符。
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectSoldierNumber"));
            return false;
        }
        return true;
    },

	// 港澳通行证：证件号码为9位或11位,首位为英文字母“H”或“M”；其余位均为阿拉伯数  实名制整改计划
	checkHKMCPassport : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		var reg = /^(H|M)(\d{8}|\d{10})$/;
		if (certificateNum == 0 || !reg.test(certificateNum)) {
			// 请输入正确的港澳通行证编号，长度9位或11位字符，其中首字母为H或M，其余为数字。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectExitEntryPermit"));
			return false;
		}
		return true;
	},

	// 台胞证：证件号码为11位时，前10位为阿拉伯数字，最后一位为校验码，括号内为英文字母或阿拉伯数字；证件号码为8位时，均为阿拉伯数字  实名制整改计划
	checkTaiBaoZheng : function(certificateNum, $UI) {
		debugger;
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		if (certificateNum.len() != 13 && certificateNum.len() != 8) {
			// 请输入正确的台胞证编号，格式为：13位时，前10位必须均为数字，括号(英文)内为英文字母或数字；或8位时，均为数字。
			$UI.msgbox
					.info($UEE.i18n("ad.person.message.information"),
							$UEE.i18n("ad.person.message.EnterCorrectTaiwanCompatriotNumber"));
			return false;
		}
		var reg = "";
		if (certificateNum.len() == 13) {
			reg = /^(\d{10})\([a-zA-Z0-9]\)$/;
		} else if (certificateNum.len() == 8) {
			reg = /^(\d{8})$/;
		}
		if (certificateNum == 0 || !reg.test(certificateNum)) {
			// 请输入正确的台胞证编号，格式为：13位时，前10位必须均为数字，括号(英文)内为英文字母或数字；或8位时，均为数字。
			$UI.msgbox
					.info($UEE.i18n("ad.person.message.information"),
							$UEE.i18n("ad.person.message.EnterCorrectTaiwanCompatriotNumber"));
			return false;
		}
		return true;
	},
	// 警官证：证件号码须大于等于6位字符  实名制整改计划
	checkPolicePaper : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// DTS2016102300596 modify cwx390137
		if(this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
			$UI.msgbox.info("提示", "警官证不能包含任何汉字符号");
			return false;
		}
		if (certificateNum == 0 || certificateNum.len() < 6) {
			// 请输入正确的警官证号码，长度大于等于6位字符。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectPoliceNumber"));
			return false;
		}
		return true;
	},
    // 武装警察身份证件：证件号码须大于等于6位字符  实名制整改计划
    checkPolicePaperForNx : function(certificateNum, $UI) {
        if (certificateNum != "") {
            certificateNum = $.trim(certificateNum);
        }
        // DTS2016102300596 modify cwx390137
        if(this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
            $UI.msgbox.info("提示", "武装警察身份证件不能包含任何汉字符号");
            return false;
        }
        if (certificateNum == 0 || certificateNum.len() < 6) {
            // 请输入正确的警官证号码，长度大于等于6位字符。
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "请输入正确的武装警察身份证件号码，长度大于等于6位字符");
            return false;
        }
        return true;
    },
    
	// 护照：证件号码须大于等于6位字符  实名制整改计划
	checkPassport : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// DTS2016102300596 modify cwx390137
		if(this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
			$UI.msgbox.info("提示", "护照号码不能包含任何汉字符号");
			return false;
		}
		if(this.validataTab(certificateNum)){
			$UI.msgbox.info("提示", "护照号码不能包含空格，TAB，回车键");
			return false;
		}
		if (certificateNum == 0 || certificateNum.len() < 6) {
			// 请输入正确的护照号码，长度大于等于6位字符。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectPassportNumber"));
			return false;
		}
		return true;
	},
	// 歪果仁永久居留证：证件号码须为15位，校验前3位为大写英文字母，是国家编号，后12位为阿拉伯数字
	checkIdCardEx : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		var reg = /^([A-Z]{3})(\d{12})$/;
		if (certificateNum == 0 || !reg.test(certificateNum)) {
			// 请输入正确的外国人永久居留证编号，长度15位，其中前3位为大写英文字母，后12位为阿拉伯数字。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "请输入正确的外国人永久居留证编号，长度15位，其中前3位为大写英文字母，后12位为阿拉伯数字。");
			return false;
		}
		return true;
	},
	
	//港澳居民居住证、台湾居民居住证 前期要求不含汉字长度为18 
	checkIdCardTW : function(certificateNum, $UI){
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		if (this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
			$UI.msgbox.info("提示", "台湾居民居住证号码不能包含任何汉字符号");
			return false;
		}
		if (this.validataTab(certificateNum)){
			$UI.msgbox.info("提示", "台湾居民居住证号码不能包含空格，TAB，回车键");
			return false;
		}
		if (certificateNum.length != 18){
			$UI.msgbox.info("提示", "台湾居民居住证号码长度必须为18位");
			return false;
		}
		return true;
	},
	
	//港澳居民居住证、台湾居民居住证 前期要求不含汉字长度为18 
	checkIdCardGA : function(certificateNum, $UI){
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		if (this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
			$UI.msgbox.info("提示", "港澳居民居住证号码不能包含任何汉字符号");
			return false;
		}
		if (this.validataTab(certificateNum)){
			$UI.msgbox.info("提示", "港澳居民居住证号码不能包含空格，TAB，回车键");
			return false;
		}
		if (certificateNum.length != 18){
			$UI.msgbox.info("提示", "港澳居民居住证号码长度必须为18位");
			return false;
		}
		return true;
	},
	
	// 山东中华人民共和国解放军证：证件号码须大于6位字符
	checkPLAIDCard : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// DTS2017042901528 modify lwx472099
		if(this.containSBCCaseCharAll(certificateNum)){
			$UI.msgbox.info("提示", "解放军军人证不能包含任何汉字符号");
			return false;
		}
		if (certificateNum == 0 || certificateNum.len() < 6) {
			// 请输入正确的中国人民解放军军人证，长度大于等于6位字符。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ArmyOfficerCertificate"));
			return false;
		}
		return true;
	},
	// 中国人民武装警察身份证：中国人民武装警察身份证须大于等于6位字符 
	checkPoliceIDCard : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// DTS2017042901528 modify lwx472099
		if(this.containSBCCaseCharAll(certificateNum)){
			$UI.msgbox.info("提示", "武装警察身份证不能包含任何汉字符号");
			return false;
		}
		if (certificateNum == 0 || certificateNum.len() < 6) {
			// 请输入正确的中国人民武装警察身份证，长度大于等于6位字符。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ArmedPoliceIdentityCard"));
			return false;
		}
		return true;
	},
	
	
	// 事业单位法人登记证  实名制整改计划
	checkEnteAggrCredential : function(certificateNum, $UI) {
		debugger;
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		
		if ($Page.projectVersion == "NINGXIA") {
			if (certificateNum.len() != 12 && certificateNum.len() != 18) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "请输入正确的事业单位法人登记证号码，长度必须为12位或者18位字符。");
				return false;
			}
		}
		
		var enteAggrCredentialVal = $Page.certLengthDicts["EnteAggrCredential"];
		if(enteAggrCredentialVal){
			try{
				if(!new RegExp(enteAggrCredentialVal).test(certificateNum)){
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectRegistrationNumber"));
					return false;
				}
			}catch(e){
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectRegistrationNumber"));
				return false;
			}
		}else if (certificateNum.len() != 12 && certificateNum.len() != 18) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),"请输入正确的事业单位法人登记证号码，长度必须为12位或者18位字符。");
			return false;
		}

		return true;
	},
	// 组织机构代码证：证件号码长度需满足10位，其规则为“XXXXXXXX-X” 其他为数字 MODIFY 2015-06-11  实名制整改计划
	checkOrgaCredential : function(certificateNum, $UI) {
		debugger;
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}

        // 调整组织机构代码证件类型的校验规则
		// 1、长度为10；前8位为字符或数字，第9位为-，第十位为字符或数字
		// 2、或者长度为18位
		var reg = /^[a-zA-Z0-9]{8}-[a-zA-Z0-9]$/;
		if (certificateNum.len() != 18 && !reg.test(certificateNum)) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),"请输入正确的组织机构代码证编号，长度为10位，格式为'XXXXXXXX-X'；或者长度为18位。");
			return false;
		}

		return true;
	},
	// 营业执照：长度必须为15位  实名制整改计划
	checkBusinessLicence : function(certificateNum, $UI) {
		debugger;
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		
		var errMsg = "ad.person.message.EnterCorrectBusinessLicenseNumber";
        if ($Page.projectVersion == "NINGXIA") {
			errMsg = "ad.person.message.ctz.EnterCorrectBusinessLicenseNumber";
		}

		var businessLicenceVal = $Page.certLengthDicts["BusinessLicence"];
		if(businessLicenceVal){
			try{
				if(!new RegExp(businessLicenceVal).test(certificateNum)){
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n(errMsg));
					return false;
				}
			}catch(e){
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n(errMsg));
				return false;
			}
		}else if (certificateNum == 0 || (certificateNum.len() != 15 && certificateNum.len() != 18)) {
			// 请输入正确的营业执照编号，长度必须为15或18位字符。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n(errMsg));
			return false;
		}
         
         if (!/^[a-zA-Z0-9]*$/.test(certificateNum) ) {		
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "营业执照必须由字母和数字组成。");
			return false;
		}
		return true;
	},

	checkPLA : function(certificateNum, $UI) {
		debugger;
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// DTS2016102300596 modify cwx390137
		if(this.containSBCCaseCharAll(certificateNum) || this.validataChina(certificateNum)){
			$UI.msgbox.info("提示", "军官证不能包含任何汉字符号");
			return false;
		}

		/*
		 * var reg = /^([\u4E00-\u9FA5]{3}\d{6,10})$/; if (certificateNum == 0 ||
		 * !reg.test(certificateNum)) { $UI.msgbox.info("提示",
		 * "请输入正确的军官证号码，格式为三位中文汉字加6到10位数字。"); return false; }
		 */
		/*
		 * var reg = /^([a-zA-Z0-9]*)$/;
		 *
		 * if (certificateNum.len() <= 6 || !reg.test(certificateNum)) {
		 * $UI.msgbox.info("提示", "请输入正确的军官证号码。证件号码必须大于6位，且只允许包括数字、a到z、A到Z。");
		 * return false; }
		 */

		 // if (certificateNum != "") { certificateNum =
			// $.trim(certificateNum); }
		  if (certificateNum == 0 || certificateNum.len() < 6)
		  {
			  // 请输入正确的军官证号码，长度大于等于6位字符。
			  $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectPLANumber"));
			  return false;
		  }


		return true;
	},

	// add by zWX270193 增加15位身份证校验，提供公共方法  实名制整改计划
	check15IdCard : function(certificateNum, $UI,idCard,certificateValue) {
		debugger;

		// 15位证件号基本校验
		var check = /^[1-9]\d{7}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))\d{3}$/
				.test(certificateNum);
		if (!check) {				
			// 身份证号码出错：15位身份证号码必须为数字或证件编号不合法
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberInvalidNumber").replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		}

		// 校验地址的正确性
		var addressCode = certificateNum.substring(0, 6);
		check = adutil.check15IdAddr(addressCode, $UI);
		if (!check) {
			return false;
		}

		// 校验时间的正确性
		var timeCode = "19" + certificateNum.substring(6, 12);
		check = adutil.check15IdTime(timeCode, $UI);
		if (!check) {
			return false;
		}

		// 最后三位的校验正确性
		// var lastCode = certificateNum.substring(12,15);
		return true;
	},

	// add by zWX270193 增加15位身份证时间校验，提供公共方法  实名制整改计划
	check15IdTime : function(timeCode, $UI,idCard,certificateValue) {
		debugger;

		var check = /^[1-9]\d{3}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))$/
				.test(timeCode);
		if (!check) {
			// 身份证号码出错：日期编码非数字。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberInvalidDate").replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		}

		var year = parseInt(timeCode.substring(0, 4), 10);
		var month = parseInt(timeCode.substring(4, 6), 10);
		var day = parseInt(timeCode.substring(6, 8), 10);

		if (year < 1900) {
			// 身份证号码出错：" + "出生年（" + year + "）太小
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberSmallYear", [year]).replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		} else if (year > new Date().getFullYear()) {
			// 身份证号码出错：" + "出生年（" + year + "）太大（大于今年）
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLargeYear", [year]).replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		} else {
			if (month < 1) {
				// 身份证号码出错:" + "出生月（" + month + "）太小"
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberSmallMonth", [month]).replace(new RegExp(idCard, 'g'), certificateValue));
				return false;
			} else if (month > 12) {
				// 身份证号码出错:" + 出生月（" + month + "）太大
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLargeMonth", [month]).replace(new RegExp(idCard, 'g'), certificateValue));
				return false;
			} else {
				var dayMax = 31;
				if (month == 2) {
					if (year % 100 == 0) {
						if (year % 400 == 0) {
							dayMax = 29;
						} else {
							dayMax = 28;
						}
					} else {
						if (year % 4 == 0) {
							dayMax = 29;
						} else {
							dayMax = 28;
						}
					}
				}
				if (month == 4 || month == 6 || month == 9 || month == 11) {
					dayMax = 30;
				}
				if (day < 1) {
					// 身份证号码出错：" + "出生日（" + day + "）太小
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberSmallDay", [day]).replace(new RegExp(idCard, 'g'), certificateValue));
					return false;
				}
				if (day > dayMax) {
					// 身份证号码出错：" + "出生日（" + day + "）太大（大于"+ dayMax + "）"
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLargeDay", [day, dayMax]).replace(new RegExp(idCard, 'g'), certificateValue));
					return false;
				}

				// 校验出生日期应该小于当前时间
				var datenow = new Date();
				var dateborn = new Date(year, month - 1, day);
				if (dateborn > datenow) {
					// 身份证号码出错：出生日期大于当前时间
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLaterDate").replace(new RegExp(idCard, 'g'), certificateValue));
					return false;
				}
			}
		}
		return true;
	},

	// add by zWX270193 增加15位身份证地址校验，提供公共方法  实名制整改计划
	check15IdAddr : function(addressCode, $UI,idCard,certificateValue) {
		debugger;
		var check = /^[1-9]\d{5}$/.test(addressCode);
		if (!check) {
			// 身份证号码出错：地区编码非数字。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLaterAreaCode").replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		}
		// 增加全国地址信息数据数组
		var aCity = {
			11 : "北京",
			12 : "天津",
			13 : "河北",
			14 : "山西",
			15 : "内蒙古",
			21 : "辽宁",
			22 : "吉林",
			23 : "黑龙江",
			31 : "上海",
			32 : "江苏",
			33 : "浙江",
			34 : "安徽",
			35 : "福建",
			36 : "江西",
			37 : "山东",
			41 : "河南",
			42 : "湖北",
			43 : "湖南",
			44 : "广东",
			45 : "广西",
			46 : "海南",
			50 : "重庆",
			51 : "四川",
			52 : "贵州",
			53 : "云南",
			54 : "西藏",
			61 : "陕西",
			62 : "甘肃",
			63 : "青海",
			64 : "宁夏",
			65 : "新疆",
			71 : "台湾",
			81 : "香港",
			82 : "澳门",
			91 : "国外"
		};

		if (aCity[parseInt(addressCode.substring(0, 2))]) {
			return true;
		} else {
			// 非法地区代码编号：
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.InvalidAreaCode",[addressCode.substring(0, 2)]));
			return false;
		}
	},

	// 校验身份证号（18位）modify by zWX270193 增加支持15位  实名制整改计划
	checkIdCard : function(certificateNum, $UI, certificateType, certificateTypeList) {
		debugger;
		
		var idCard = $UEE.i18n("ad.sr.message.SFZ");
		var certificateValue="";
		if(certificateTypeList && certificateTypeList.length >0){
			$.each(certificateTypeList || [], function(i,val){
				if(val.key && val.value && val.value != "" && val.key == certificateType){
					certificateValue = val.value;
				}
			});
		}
		if(certificateValue==""){
			certificateValue=idCard;
		}
		if (!certificateNum || certificateNum == 0) {
			// 身份证号码长度需满足18位。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IDCardNumber15or18Digits").replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		}
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		} 

		// 如果长度满足15位，则进行15位校验，后18位校验下沉 add by zWX270193
		if (certificateNum.length == 15) {
			return adutil.check15IdCard(certificateNum, $UI,idCard,certificateValue);
		}

		if (certificateNum.length < 18) {
			// 修改提示语 modify by zWX270193
			// 身份证号码长度需满足15位或18位。
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IDCardNumber15or18Digits").replace(new RegExp(idCard, 'g'), certificateValue));		
			return false;
		}

		if (certificateNum.length == 18) {
			var check18 = certificateNum;
			var subCheck18 = check18.substring(0, 17);
			if (isNaN(subCheck18)) {
				// 18位身份证的前17位必须全部为数字。
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.18DigitIDNumber17mustdigits").replace(new RegExp(idCard, 'g'), certificateValue));
				return false;
			} else {
				var yearLength = 4, sexLocation = 17;
				var sexValue = (check18.charAt(sexLocation)) % 2;
				var year = check18.substring(6, 6 + yearLength);
				var month = check18.substring(6 + yearLength, 8 + yearLength);
				var day = check18.substring(8 + yearLength, 10 + yearLength);
				var aCity = {
					11 : "北京",
					12 : "天津",
					13 : "河北",
					14 : "山西",
					15 : "内蒙古",
					21 : "辽宁",
					22 : "吉林",
					23 : "黑龙江",
					31 : "上海",
					32 : "江苏",
					33 : "浙江",
					34 : "安徽",
					35 : "福建",
					36 : "江西",
					37 : "山东",
					41 : "河南",
					42 : "湖北",
					43 : "湖南",
					44 : "广东",
					45 : "广西",
					46 : "海南",
					50 : "重庆",
					51 : "四川",
					52 : "贵州",
					53 : "云南",
					54 : "西藏",
					61 : "陕西",
					62 : "甘肃",
					63 : "青海",
					64 : "宁夏",
					65 : "新疆",
					71 : "台湾",
					81 : "香港",
					82 : "澳门",
					91 : "国外"
				};
				var idNumber = certificateNum;
				if (aCity[parseInt(idNumber.substr(0, 2))] == null) {
					// 地区代码(" + idNumber.substr(0, 2)+ ")不匹配，该证件编号不合法"
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.InvalidAreaCode",[idNumber.substring(0, 2)]).replace(new RegExp(idCard, 'g'), certificateValue));
					return false;
				}
				if (year < 1800) {
					// 身份证号码出错：" + "出生年（" + year + "）太小
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberSmallYear", [year]).replace(new RegExp(idCard, 'g'), certificateValue));
					return false;
				} else if (year > new Date().getFullYear()) {
					// 身份证号码出错：" + "出生年（" + year + "）太大（大于今年）
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLargeYear", [year]).replace(new RegExp(idCard, 'g'), certificateValue));
					return false;
				} else {
					if (month < 1) {
						// 身份证号码出错:" + "出生月（" + month + "）太小"
						// $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						// $UEE.i18n("ad.person.message.IncorrectIDCardNumberSmallMonth",
						// [month]));
						// DTS2016080204688
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberDate").replace(new RegExp(idCard, 'g'), certificateValue));
						return false;
					} else if (month > 12) {
						// 身份证号码出错:" + 出生月（" + month + "）太大
						// $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
						// $UEE.i18n("ad.person.message.IncorrectIDCardNumberLargeMonth",
						// [month]));
						// DTS2016080204688
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberDate").replace(new RegExp(idCard, 'g'), certificateValue));
						return false;
					} else {
						var dayMax = 31;
						if (month == 2) {
							if (year % 100 == 0) {
								if (year % 400 == 0) {
									dayMax = 29;
								} else {
									dayMax = 28;
								}
							} else {
								if (year % 4 == 0) {
									dayMax = 29;
								} else {
									dayMax = 28;
								}
							}
						}
						if (month == 4 || month == 6 || month == 9
								|| month == 11) {
							dayMax = 30;
						}
						if (day < 1) {
							// 身份证号码出错：" + "出生日（" + day + "）太小
							// $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
							// $UEE.i18n("ad.person.message.IncorrectIDCardNumberSmallDay",
							// [day]));
							// DTS2016080204688
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberDate").replace(new RegExp(idCard, 'g'), certificateValue));
							return false;
						}
						if (day > dayMax) {
							// 身份证号码出错：" + "出生日（" + day + "）太大（大于"+ dayMax + "）"
							// $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
							// $UEE.i18n("ad.person.message.IncorrectIDCardNumberLargeDay",
							// [day, dayMax]));
							// DTS2016080204688
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberDate").replace(new RegExp(idCard, 'g'), certificateValue));
							return false;
						}

						// 校验出生日期应该小于当前时间
						var datenow = new Date();
						var dateborn = new Date(year, month - 1, day);
						if (dateborn > datenow) {
							// "身份证号码出错：出生日期大于当前时间"
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IncorrectIDCardNumberLaterDate").replace(new RegExp(idCard, 'g'), certificateValue));
							return false;
						}
						// 校验最后一位
						if (!adutil.isTrueValidateCodeBy18IdCard(
								certificateNum, $UI)) {
							return false;
						}
					}
				}
			}
		} else {
			// 修改提示信息，modify by zWX270193
			// "身份证必须为15位或18位。"
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.IDCardNumber15or18Digits").replace(new RegExp(idCard, 'g'), certificateValue));
			return false;
		}
		return true;
	},
	// 判断年是否在10到120岁之间，不在范围之内返回true  实名制整改计划
	isAgeLess10orMore120 : function(birthday,custCertType,custCertId,minAge){
        debugger;
		var $scope = $(document).scope();
        var age = undefined;
        $Page = $scope.$Page;
        $UI = $scope.$UI;
        if (!custCertType || custCertType == "") {
            // "客户证件类型为空。"
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CertificateTypeEmpty"));
            return true;
        }
        if (!custCertId || custCertId == "") {
            // "客户证件ID为空。"
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CertificateIDEmpty"));
            return true;
        }
        if (custCertType == "TempId" || custCertType == "IdCard" || custCertType == "HuKouBu"){

            if (custCertId.length == 15)
            {
                age = Math.floor(adutil.getFullAge("19" + custCertId.substr(6, 6), ""));
            }
            else if (custCertId.length == 18)
            {
                age = Math.floor(adutil.getFullAge(custCertId.substr(6, 8), ""));
            }else {
                // 客户证件ID为：" + custCertId + "，长度不符合规范，必须为15位或者18位证件ID。
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CustomerIdNumberLengthRule",[custCertId]));
                return true;
            }
        }
        if(birthday != null){
            var date = new Date(birthday).Format("yyyyMMdd");
            var birthage = Math.floor(adutil.getFullAge(date, ""))
            if(age != null && age!= birthage){
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("身份证年龄和客户生日不一致"));
				return true;
            }
            age = birthage;
            birthage = null;
        }
        
        if ($Page.projectVersion == "NINGXIA") {
            minAge = $Page.ageNeedGuardian || 16;
        } else {
            minAge = 10;
        }
        
        if (minAge > age || age > 120)
        {
             $UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "经办人或者使用者年龄不能小于" + minAge + "岁大于120岁");
             return true;
        }
        return false;
	},

	/**
	 * 判断身份证号码为18位时最后的验证位是否正确  实名制整改计划
	 *
	 * @param a_idCard
	 *            身份证号码数组
	 * @return
	 */
	isTrueValidateCodeBy18IdCard : function(certificateNum, $UI) {
		debugger;
		var $scope = $(document).scope();
		$Page = $scope.$Page;
		var Wi = [ 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1 ];// 加权因子
		var ValideCode = [ 1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2 ];// 身份证验证位值.10代表X
		var sum = 0;
		if ($Page.projectVersion == "NINGXIA"){
			var reg = /^\d{15}(\d{2}[0-9xX])?$/;
			if (!reg.test(certificateNum)) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "身份证最后一位只能为0-9或者x或者X");
				return false;
			}
		}else{
			var reg = /^\d{17}(\d|X)$/;
			if (!reg.test(certificateNum)) {
				// "身份证最后一位只能为0-9或者X"
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.LasDigitIDCardNumber"));
				return false;
			}
		}

		var certificateNum17 = certificateNum[17];
		
		if ($Page.projectVersion == "NINGXIA"){
			if (certificateNum[17] == "X" || certificateNum[17] == "x") {
				certificateNum17 = 10;
			}
		}else{
			if (certificateNum[17] == "X") {
				certificateNum17 = 10;
			}
		}
		for ( var n = 0; n < 17; n++) {
			sum += Wi[n] * certificateNum[n];
		}

		var valCodePosition = sum % 11;
		if (certificateNum17 == ValideCode[valCodePosition]) {
			return true;
		} else {
			// 您输入的的身份证号码有误，请重新输入
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ReEnterIncorrectIDNumber"));
			return false;
		}
	},

	/**
	 * 打开资料完善登录鉴权  江苏移动特有的
	 */
	openAuthTabProfile : function(data, contextPath) { // sDate1和sDate2是2006-12-18格式
		debugger;
		if (!contextPath) {
			contextPath = $UEE.$Webapp;
		}

		if ("SM" == ocActionSource) {
			data = "/bes/ad/html/bes.ad.login.base.clientbusiness.html"
					+ data.substring(data.indexOf("?"))+getVersionUrlStr(0);
			//完善资料鉴权
			_ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(
					"60131_ocloginforprofile", $UEE.i18n("ad.person.title.CompleteAuthInfo"), contextPath + adutil.assureStratWithRoot(data), "");
			window.$BES.$Portal.tabpanel.closeTabItem(adutil
					.getQueryStringByName("menuid"));
		} else {
			window.open(data);
			window.opener = null;
			window.open('', '_self');
			window.close();
		}
	},
	/**
	 * 根据出生日期 strBirthday 得到周岁年龄  实名制整改计划
	 *
	 * @param strBirthday
	 *            正确格式类似于 '1991.02.09', '1991-09-02', '19910902' 这样的字符串
	 * @param splitChar
	 *            日期分隔符，类似于 ./-
	 * @returns {Number}
	 */
	getFullAge : function(strBirthday, splitChar) {
		try
		{
			if (!strBirthday) {
				return 0;
			}

			var birth = strBirthday.split(splitChar).join(''); // 19910209

			// 年月日8位数字
			if (birth.length != 8 || !birth.match(new RegExp('^[0-9]*$'))) {
				return 0;
			}

			// 19910209
			var birthYear = birth.substr(0, 4); // 1991
			var birthMonth = birth.substr(4).substr(0, 2); // 02
			var birthDay = birth.substr(6); // 09

			var now = new Date();
			// 异常场景返回-1
			if(birthYear < 1900 || birthYear > now.getFullYear()
					|| birthMonth < 1 || birthMonth > 12
					|| birthDay < 1 || birthDay > 31)
			{
				return -1;
			}

			var dY = now.getFullYear() - birthYear;
			var dM = now.getMonth() - birthMonth + 1;
			var dD = now.getDate() - birthDay;

			var dX = dY * 365 + dM * 30 + dD;

			return dX / 365;
		}
		catch(e)
		{
			return -1;
		}
	},



	/**
	 * 打印日志
	 */
	printLog : function(msg,obj){
        try {
            if(msg){
                console.log(msg);
            }
            if(obj){
                console.log(obj);
            }
        } catch (e) {};
	},

	trimUpdate: function(value, element) {
		debugger;
        var newVal = value.trim().replace(/\s+/g, '');

		(newVal !== value) && element && element.val(newVal);

		return true;
	},

	trimFiled: function(filedContainer, filedName, elementName) {
		debugger;
		if (!filedContainer[filedName]) {
			return;
		}

        filedContainer[filedName] = filedContainer[filedName].trim().replace(/\s+/g, ' ');

		if (elementName) {
			$(elementName).val(filedContainer[filedName]);
		}
	},

	
	// add 2016-11-24 xwx391999 厄瓜多尔局点证件类型Id的证件号码校验
	checkId : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// 1、Id卡的长度为10
		if(certificateNum.length != 10){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectIdNumber"));
			return false;
		}
		/*
		 * 1. Id卡由10位纯数字构成，不含字母和特殊字符； 2. Id卡的第三位数字只能从下面的数字中取“0,1,2,3,4,5 “ 3. ID
		 * 卡的前两位组合起来不能小于1,或者大于22，应该是介于01到22之间，包括01和22；
		 */
		var reg = /^((0[1-9])|(1[0-9])|(2[0-2]))([0-5])\d{7}$/;
		if (!reg.test(certificateNum)) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectIdNumber"));
			return false;
		}
		return true;
	},
	// add 2016-11-24 xwx391999 厄瓜多尔局点证件类型RUC的证件号码校验
	checkRUC : function(certificateNum, $UI) {
		if (certificateNum != "") {
			certificateNum = $.trim(certificateNum);
		}
		// 1、RUC的长度为13
		if(certificateNum.length != 13){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectRUCNumber"));
			return false;
		}
		/*
		 * 1. RUC由13位纯数字构成，不含字母和特殊字符； 2. RUC的第三位数字只能从下面的数字中取“0,1,2,3,4,5,6,9“ 3.
		 * RUC的最后三位数字不能是000. 4. RUC的前两位组合起来不能小于1,或者大于22，应该是介于01到22之间，包括01和22；
		 */
		var reg = /^((0[1-9])|(1[0-9])|(2[0-2]))([0-5])\d{10}$/;
		if (!reg.test(certificateNum)) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectRUCNumber"));
			return false;
		}
		// RUC的最后三位数字不能是000
		if("000" == certificateNum.substr(10)) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectRUCNumber"));
			return false;
		}
		return true;
	},

	setTabsShareData: function(key, value) {
		if (!window._ysp_top) {
			return;
		}
		var container = window._ysp_top;

		if (!container.tabsShare) {
			container.tabsShare = {};
		};

		container.tabsShare[key] = JSON.stringify(value);
	},

	getTabsShareData: function (key, copyFunc) {
		if (!window._ysp_top) {
			return;
		}
		var container = window._ysp_top;

		if (!container.tabsShare) {
			return;
		};

		if (typeof copyFunc == "function") {
			var obj = null;
			if (container.tabsShare[key]) {
				try {
					obj = jQuery.parseJSON(container.tabsShare[key]);
				} catch (e) {}
			}
			copyFunc(obj);
			//delete container.tabsShare[key];
		}
	},

	callIntfPOJOInputService : function ($Fire, req, callBack, errCallBack) {
		this.callIntfEasyCommonInvoker($Fire, 'com.huawei.soaif.enabler.input.pojo.POJOInputBOService', 'accessPOJOInput', req, callBack, errCallBack);
	},

	callIntfCommonInvoker : function ($Fire, req, callBack, errCallBack) {
		this.callIntfEasyCommonInvoker($Fire, 'ebus4pojoService', 'PojoIn', req, callBack, errCallBack);
	},

	callIntfEasyCommonInvoker : function ($Fire, serviceName, operation, req, callBack, errCallBack) {
		this.callGeneralService($Fire, "/intfeasyservice/commoninvoker", {
			servicename : serviceName,
			operation : operation,
			req : JSON.stringify(req)
		}, callBack, errCallBack);
	},

	callGeneralEasyInvoker : function ($Fire, serviceName, operation, paramList, callBack, errCallBack) {
		var paramJsonList = null;
		if (paramList && paramList.length > 0) {
			paramJsonList = [];
			for (var i=0; i<paramList.length; i++) {
				paramJsonList.push(JSON.stringify(paramList[i]));
			}
		}

		this.callGeneralService($Fire, "/generaleasyservice/easyinvoker", {
			servicename : serviceName,
			operation : operation,
			paramlist : paramJsonList
		}, callBack, errCallBack);
	},

	callGeneralService : function ($Fire, restService, params, callBack, errCallBack) {
		$Fire({
			service : restService,
			params : params,
			target : "generalServiceResp",
			onafter : function (generalServiceResp) {
				if (generalServiceResp.body) {
					try {
						generalServiceResp.body = jQuery.parseJSON(generalServiceResp.body);
					} catch (e) {}
				}

				callBack(generalServiceResp);
			},
			onerror : function (generalServiceResp) {
				if (errCallBack) {
					errCallBack(generalServiceResp);
				}
			}
		});
	},

	isEmptyObject : function (obj) {
		if (!obj) {
			return true;
		}

		for (var key in obj) {
			return false
		}

		return true;
	},

	getPropertyByExpr : function(rootVar, expr) {
		debugger;
		if (typeof expr != 'string') {
			return;
		}

		var propList = expr.split('.');
		var preObj = rootVar;
		var arrIdx = -1;
		for(var i=0; i<propList.length; i++) {
			var prop = propList[i];
			var index1 = prop.indexOf('[');
			arrIdx = -1;
			if (index1 > -1) {
				var index2 = prop.indexOf(']', index1 + 1);
				if (index2 != prop.length - 1) {
					return null;
				}
				arrIdx = parseInt(prop.substr(index1 + 1, index2 - index1 - 1));
				if (isNaN(arrIdx)) {
					return null;
				}
				prop = prop.substr(0, index1);
			}

			preObj = preObj[prop];
			if (arrIdx >= 0) {
				preObj = preObj[arrIdx];
			}

			if (!preObj) {
				break;
			}
		}

		return preObj;
	},

    setPropertyByExpr : function(rootVar, expr, value) {
        debugger;
        if (typeof expr != 'string') {
            return;
        }

        var propList = expr.split('.');
        var preObj = rootVar;
        var ppreObj = rootVar;
        var arrIdx = -1;
        for(var i=0; i<propList.length; i++) {
            var prop = propList[i];
            var index1 = prop.indexOf('[');
            arrIdx = -1;
            if (index1 > -1) {
                var index2 = prop.indexOf(']', index1 + 1);
                if (index2 != prop.length - 1) {
                    return null;
                }
                arrIdx = parseInt(prop.substr(index1 + 1, index2 - index1 - 1));
                if (isNaN(arrIdx)) {
                    return null;
                }
                prop = prop.substr(0, index1);
            }

            var curObj = preObj[prop];
            if (!curObj) {
                if (arrIdx >= 0) {
                    preObj[prop] = [];
                }   else {
                    preObj[prop] = {};
                }
                ppreObj = preObj;
                prePropName = prop;
                preObj = preObj[prop];
            }
            
            if (arrIdx >= 0) {
                var curObj = preObj[arrIdx];
                if (!curObj) {
                    preObj[arrIdx] = {};
                    ppreObj = preObj;
                    prePropName = arrIdx;
                    preObj = preObj[arrIdx];
                }
            } else if (curObj) {
                preObj = curObj;
            }
        }

        ppreObj[prePropName] = value;
    },
	
    addEventListener : function(name, listener) {
        $Page.adEventListener = $Page.adEventListener || {};
        $Page.adEventListener[name] = $Page.adEventListener[name] || [];        
    	var funcList = $Page.adEventListener[name];
    	for (var i = 0; i < funcList.length; i++) {
    		var func = funcList[i];
    		if (func == listener) {
                return;
            }
    	}
        funcList.push(listener);
    },
	
    emitEvent: function (name) {
    	if (!$Page.adEventListener) {
    		return;
    	}
    	if (!$Page.adEventListener[name]) {
    		return;
    	}

        var args = [];
    	for (var i = 1; i < arguments.length; i++) {
            args.push(arguments[i]);
        }
        
    	var funcList = $Page.adEventListener[name];
    	for (var i = 0; i < funcList.length; i++) {
    		var func = funcList[i];
            func.apply(window, args);
    	}
    },
    
	/* 按照比例获取客户区宽度
	* percent 比例，100倍的整数形式，如90等
	*/
	getClientWidthByPercent : function(percent) {
		return Math.floor(document.documentElement.clientWidth * percent / 100) + 'px';
	},
	
	/* 按照比例获取客户区高度
	* percent 比例，100倍的整数形式，如90等
	*/
	getClientHeightByPercent : function(percent) {
		return Math.floor(document.documentElement.clientHeight * percent / 100) + 'px';
	},

	addFireSearchFunc : function(name, callBack) {
	    window.$UEE.$Fire.searchFuncMap = window.$UEE.$Fire.searchFuncMap || {};
        var searchFuncMap = window.$UEE.$Fire.searchFuncMap;
        searchFuncMap[name] = callBack;
        
        window.$UEE.$Fire.search = function($Page) {
            var param = {};
            for (var key in searchFuncMap) {
                var func = searchFuncMap[key];
                if (func) {                     
                    var paramCur = func.call(this, $Page);
                    $.extend(param, paramCur);
                }
            }
            
            return param;
        };
    },

    addFireGlobalAfterFunc : function(name, callBack) {
        window.$UEE.$Fire.globalAfterFuncMap = window.$UEE.$Fire.globalAfterFuncMap || {};
        var globalAfterFuncMap = window.$UEE.$Fire.globalAfterFuncMap;
        globalAfterFuncMap[name] = callBack;
        
        window.$UEE.$Fire.globalAfter = function(data, status, headers, config) {
            for (var key in globalAfterFuncMap) {
                var func = globalAfterFuncMap[key];
                func && func.call(this, data, status, headers, config);
            }
        };
    },
    
    /*增加初始化参数查询的注册项，
	param格式
	{
		dataDictCodeList: ['OM_CERT_COMP_BE'],
		authIdList: [],
		sysParamIdList: ['isBUG2017_087997'],
		callBack: callBackFunc
	} */
    addInitCfgParam : function(param) {
        this.initCfgParam = this.initCfgParam || [];
        this.initCfgParam.push(param);
    },

    //所有页面初始化用到的系统参数，字典组，令牌放在这里查询，查询后回调注册函数
    queryInitCfg : function() {
		debugger;
        var $scope = $(document).scope();
        var $Fire = $scope.$Get('$Fire');
		var req = {};
		var dataDictCodeList = [];
		var authIdList = [];
		var sysParamIdList = [];
		var callBackList = [];
		
		function concatArray(arrDest, arrSrc) {
			if (!arrDest || !arrSrc) {
				return;
			}
			
			for (var i = 0; i < arrSrc.length; i++) {
				arrDest.push(arrSrc[i]);
			}
		}
		
		for (var i = 0; i < this.initCfgParam.length; i++) {
			var param = this.initCfgParam[i];
			concatArray(dataDictCodeList, param.dataDictCodeList);
			concatArray(authIdList, param.authIdList);
			concatArray(sysParamIdList, param.sysParamIdList);
			callBackList.push(param.callBack);
		}
		
		if (dataDictCodeList.length > 0) {
			req.dataDictCodeList = dataDictCodeList;
		}
		if (authIdList.length > 0) {
			req.authIdList = authIdList;
		}
		if (sysParamIdList.length > 0) {
			req.sysParamIdList = sysParamIdList;
		}
        
		
		if ($.isEmptyObject(req)) {
			return;
		}
		
        $Fire({
            service: "/common/qrysyscfg",
            params: {
                req: req
            },
            target: "syscfgResp",
            onafter: function (syscfgResp) {
                if (!syscfgResp) {
                    return;
                }
                
				for (var i = 0; i < callBackList.length; i++) {
					callBackList[i].call(this, syscfgResp);
				}

                /*$Gadget.dataDictMap = syscfgResp.dataDictMap;
                $Gadget.custVideoAuthURL = syscfgResp.sysParamMap && syscfgResp.sysParamMap['AD.CUSTVIDEOAUTH.URL'];
                // test
                $Gadget.custVideoAuthURL = $Gadget.custVideoAuthURL || "/custvideoauth/mock";
                $Controller.bes.ad.cust.videoauth.checkShowCmpBtn($Gadget);*/
            }
        });
    },
        
	// 自定义集团业务特性对象
	adGroupBusinessCharacter : new AdGroupBusinessCharacter(),
	// 参数
	adParameter : new AdParameter(),
	// 字典
	adDictionary : new AdDictionary()
};

// 绑定弹出框关闭按钮事件
adutil.bindCloseBtn();
adutil.addInitCfgParam({
	sysParamIdList: ['isBUG2017_087997'],
	callBack: function (syscfgResp) {
		if (syscfgResp.sysParamMap) {
			$Page.recDeviceType = syscfgResp.sysParamMap["isBUG2017_087997"] || "N";
		}		
	}
});

$(function () {
    adutil.queryInitCfg();
});
		
$(document).on(
		"DOMMouseScroll mousewheel",
		"body",
		function(e) {
			var tar = e.target;
			if (!$(tar).closest(".DroplistOption")[0]
					&& !$(tar).hasClass("DroplistOption")) {
				$(".DroplistOption").hide();
			}
			$(".calendar").hide();
		});

angular.module('uee.ui').directive(
		'adCheckbox',
		function() {
			return {
				restrict : 'A',
				scope : {
					// checkboxHash: text, group, onChange, selected
					checkboxHash : '='
				},
				link : function(scope, elem, attrs) {
					scope.checkboxHash = scope.checkboxHash || {};

					var obj = new UCD.Checkbox($(elem),
							scope.checkboxHash.text, scope.checkboxHash.group,
							scope.checkboxHash.onChange);
					if (scope.checkboxHash.selected) {
						obj.check();
					}

					if (scope.checkboxHash.disabled) {
						obj.enable(false);
					}

					$(elem).data("obj", obj);
				}
			};
		});

angular.module('uee.ui').directive(
		'adRadio',
		function() {
			return {
				restrict : 'A',
				scope : {
					// radioHash: text, group, onChange, selected
					radioHash : '='
				},
				link : function(scope, elem, attrs) {
					scope.radioHash = scope.radioHash || {};

					var obj = new UCD.Radio($(elem), scope.radioHash.text,
							scope.radioHash.group, scope.radioHash.onChange);
					if (scope.radioHash.selected) {
						obj.check();
					}

					if (scope.radioHash.disabled) {
						obj.enable(false);
					}
					$(elem).data("obj", obj);
					// add $destroy function --2016/09/02 by z00278756
					scope.unbindDestroyEvent = scope.$on("$destroy", function(){
						debugger;
						var group;
						if(obj._settings){
							obj._settings.$container = null;
							obj._settings.$dom = null;
							obj._settings.$radio = null;
							obj._settings.container = null;
							group = obj._settings.group;
							delete obj._settings;
							obj = null;
						}
						// delete from UCD.Radio.group
						if(UCD.Radio && UCD.Radio.group && UCD.Radio.group[group] && UCD.Radio.group[group].checked){
							if(UCD.Radio.group[group].checked._settings){
								UCD.Radio.group[group].checked._settings.$container = null;
								UCD.Radio.group[group].checked._settings.$dom = null;
								UCD.Radio.group[group].checked._settings.$radio = null;
								UCD.Radio.group[group].checked._settings.container = null;
								delete UCD.Radio.group[group].checked._settings;
							}
							UCD.Radio.group[group].checked = null;
						}
						if(elem){
							elem.removeData();
							elem = null;
						}
						// 在解决内存泄露的问题时，避免在popin关闭弹窗的时候，错误的调用接绑事件
						scope.unbindDestroyEvent && scope.unbindDestroyEvent();
						scope.unbindDestroyEvent = null;
					});
				}
			};
		});

angular.module('uee.ui').directive(
		'adDroplist',
		function() {
			return {
				restrict : 'A',
				scope : {
					droplistHash : '='
				},
				link : function(scope, elem, attrs) {
					scope.droplistHash = scope.droplistHash || {};

					var obj = new UCD.Droplist($(elem),
							scope.droplistHash.data,
							scope.droplistHash.onCreateItem);
					obj.init();
					obj.setOnValueChange(scope.droplistHash.onValueChange);
					if (scope.droplistHash.selectedKey) {
						obj.selectItem(scope.droplistHash.selectedKey);
					}
					if (scope.droplistHash.disabled) {
						obj.setDisabled(scope.droplistHash.disabled);
					}
					obj.setOnValueChange(scope.droplistHash.onValueChange);
					$(elem).data("obj", obj);
				}
			};
		});
angular.module('uee.ui').directive(
		'adMultiDroplist',
		function() {
			return {
				restrict : 'A',
				scope : {
					droplistHash : '='
				},
				link : function(scope, elem, attrs) {
					scope.droplistHash = scope.droplistHash || {};

					var obj = new UCD.Droplist($(elem),
							scope.droplistHash.data,
							scope.droplistHash.onCreateItem);
					obj.enableSingle();
					obj.init();
					obj.setOnValueChange(scope.droplistHash.onValueChange);
					if (scope.droplistHash.selectedKey) {
						obj.selectItem(scope.droplistHash.selectedKey);
					}
					obj.setOnValueChange(scope.droplistHash.onValueChange);
					$(elem).data("obj", obj);
				}
			};
		});

angular.module('uee.ui').directive('adDate', function() {
	return {
		restrict : 'A',
		scope : {
			dateHash : '='
		},
		link : function(scope, elem, attrs) {
			debugger;
			scope.dateHash = scope.dateHash || {};

			var dateTime = new UCD.Date(scope.dateHash.options || {});
			dateTime.init();
			dateTime.setAnchor($(elem));
			if (scope.dateHash.onChanged) {
				dateTime.setOnChanged(scope.dateHash.onChanged);
			}

			// YYYY-MM-dd hh:mm:ss 格式的字符串
			if (scope.dateHash.defaultValue) {
				dateTime.setValue(scope.dateHash.defaultValue);
			} else {
				$(elem).find(".calendarInput").val('');
			}

			$(elem).find(".calendarInput").attr("readonly", "readonly");

			$(elem).data("obj", dateTime);
		}
	};
});


angular.module('uee.ui').directive(
		'adtDataSlider',
		function() {
			return {
				require : '?ngModel',
				restrict : 'A',
				link : function(scope, elem, attrs, ctrl) {
					debugger;
					var xMax = parseInt(attrs.max || 100);

					var xMin = parseInt(attrs.min || 0);

					var xStep = parseInt(attrs.step || 1);

					var $root = $(elem);
					var $input = $(".showdata input", $root);
					var $trackOC = $(".slider .trackOC", $root);
					var $slider = $(".slider", $root);

					// 创建横向滚动组件
					var slider = new UCD.RangeOC($slider, xMin);
					// 设置步长为1
					slider.setStep(parseInt(xStep));
					// 范围
					slider.setRange(parseInt(xMin), parseInt(xMax));
					// 绑定值变化事件
					slider.setOnChanged(function() {
						$trackOC.text(parseFloat(slider.getValue()).toFixed(0));
						$input.val(parseFloat(slider.getValue()).toFixed(0));

						var $scope = $(document).scope();
						$scope.$safeApply($scope, function() {
							if (ctrl) {
								ctrl.$setViewValue(parseFloat(slider.getValue()).toFixed(0));
							}
						});
					});

					$(elem).data("obj", slider);

					// 绑定+按钮，触发滚动组件值变化
					$(".add", $root).click(function() {
						var data = parseFloat($input.val());
						if (data < xMax) {
							data += parseInt(xStep);
						}
						$input.val(data);
						slider.setValue($input.val());
						$slider.trigger("change");
					});
					// 绑定-按钮，触发滚动组件值变化
					$(".minus", $root).click(function() {
						var data = parseFloat($input.val());
						if (data > xMin) {
							data -= parseInt(xStep);
						}
						$input.val(data);
						slider.setValue($input.val());
						$slider.trigger("change");
					});
					// 捕获输入框值变化，触发滚动组件
					$input.change(function() {
						var reg = new RegExp("^[0-9]*$");
						if (!reg.test($input.val())){
							$input.val(xMin);
						}
						slider.setValue(parseFloat($input.val()));
						$slider.trigger("change");
					});

					if (ctrl) {
						// model -> view
						ctrl.$render = function() {
							if (ctrl.$viewValue) {
								// 设置起始默认值
								slider.setValue(parseFloat(ctrl.$viewValue || ""));
							} else {
								// 设置起始默认值
								slider.setValue(parseFloat(xMin));
							}
						};
					}
				}
			};
		});


// (function($){
// var locale = $.cookie("u-locale");
// if(locale==undefined || locale == null){
// return;
// }
// locale = locale.replace("_","-");
// jQuery.datetimepicker.setDefaults(jQuery.datetimepicker.getRegional(locale));
// })(jQuery);
(function($){
	var locale = $.cookie("u-locale");
	if(locale==undefined || locale == null){
	return;
	}
	locale = locale.replace("_","-");
	jQuery.datetimepicker.setDefaults(jQuery.datetimepicker.getRegional(locale));
})(jQuery);


angular.module("uee").directive('ocDate', function ($templateCache, $filter, $compile, $UEE, $META, $Validate, $Date) {
    return {
        restrict: 'C',
        scope: true,
        compile : function(tElement, tAttr, linker){
            return function($scope, $element, $attrs, parentCtrls) {
                $scope.displayformat = $attrs.displayformat ? $attrs.displayformat : $scope.$Page.tzDate;
                var options = {
                    kind: 'date',
                    displaytime : false,
                   showOn: 'button',
                    buttonImageOnly: true,
                    dateFormat: $scope.displayformat,
                    idPrefix : $scope.$Id,
                    timepoint: ''
                };
                options.showWeeks = $attrs.showweeks == "true" ? true : false;
                options.clean = $attrs.clean == "true" ? true : false;
                $element.children('input').datetimepicker(options);
                $scope.$ConvertModelToView = function(newV,oldV){
                    var val;
                    if((typeof newV) == 'string'){
                        val = newV;
                    }else{
                    	if(!$UEE.$Tz.dstsupport){
							 val = $filter('tz')(newV, $scope.displayformat, $UEE.$Tz.serverTimezone);
						  }else{
							  val = $filter('tz')(newV, $scope.displayformat);
						 }
                    }
                    if(!val){
                        val = oldV;
                    }
                    return val;
                }

                $scope.$ConvertViewToModel = function(newV, oldV){
                    var val;
                    if((typeof oldV) == 'string'){
                        val = newV;
                    }else{
                    	if(!$UEE.$Tz.dstsupport){
							 val = $filter('tz')(newV, $scope.displayformat, $UEE.$Tz.serverTimezone);
						  }else{
							  val = $filter('tz')(newV, $scope.displayformat);
						 }
                    }
                    return val;
                }

                $scope.unbindDestroyEvent = $scope.$on("$destroy",function(){
                	$.datetimepicker._destroyDatepicker($element.children("input")[0]);
                    $element.removeData();
                    $element.remove();
                    $scope.unbindDestroyEvent();
                    $scope.unbindDestroyEvent = null;
                    if($scope.$ConvertViewToModel){
                        $scope.$ConvertViewToModel();
                        $scope.$ConvertViewToModel = null;
                    }
                    if($scope.$ConvertModelToView){
                        $scope.$ConvertModelToView();
                        $scope.$ConvertModelToView = null;
                    }
                    $scope.displayformat = null;
                });

            };
        }
    };
} ,true);

angular.module("uee").directive('ocDatetime', function ($templateCache, $filter, $compile, $UEE, $META, $Validate, $Date) {
	return {
			restrict: 'C',
			scope: true,
			compile : function(tElement, tAttr, linker){
			return function($scope, $element, $attrs, parentCtrls) {
					$scope.displayformat = $attrs.displayformat ? $attrs.displayformat : $scope.$Page.tzDateTime || "yyyy-MM-dd HH:mm:ss";
							var options = {
							kind: 'datetime',
							displaytime : true,
							showOn: 'button',
							buttonImageOnly: true,
							dateFormat: $scope.displayformat,
							idPrefix : $scope.$Id,
							timepoint: ''
					};
					options.showWeeks = $attrs.showweeks == "true" ? true : false;
					$element.children('input').datetimepicker(options);

					$scope.$ConvertModelToView = function(newV,oldV){
							var val;
							if((typeof newV) == 'string'){
									val = newV;
							}else{
								/*
								 * if($UEE.$Tz.dstsupport && $UEE.$Tz.dstdisplay &&
								 * angular.isNumber(val)){ var isDst =
								 * $Date.inDst(val); $scope.$Dstshow = ( isDst !=
								 * -1); }
								 */
								// sbegin
								if($UEE.$Tz.dstsupport && $UEE.$Tz.dstdisplay  && angular.isNumber(val)){
		                            var isDst = $Date.inDst(val);
		                            $scope.$Dstshow = ( isDst != -1);
		                        }else if($UEE.$Tz.dstsupport && $UEE.$Tz.dstdisplay){
		                        	if(!val){
		                        		$scope.$Dstshow = true;
		                        	}
		                        }
								// end

								 if(!$UEE.$Tz.dstsupport){
									 val = $filter('tz')(newV, $scope.displayformat, $UEE.$Tz.serverTimezone);
								  }else{
									 val = $filter('tz')(newV, $scope.displayformat);
								 }
							}
							if(!val){
									val = oldV;
							}
							return val;
					}

					$scope.$ConvertViewToModel = function(newV, oldV){
							var val;
							if((typeof oldV) == 'string'){
								val = newV;
							}else{
								 if(!$UEE.$Tz.dstsupport){
									 val = $filter('tz')(newV,  $scope.displayformat, $UEE.$Tz.serverTimezone);
								  }else{
									  val = $filter('tz')(newV, $scope.displayformat);
								 }
							}
							 if($UEE.$Tz.dstsupport && $UEE.$Tz.dstdisplay  && angular.isNumber(val)){
			                        var isDst = $Date.inDst(val);
			                        $scope.$Dstshow = ( isDst != -1);
			                    }
							return val;
					}

					$scope.unbindDestroyEvent = $scope.$on("$destroy",function(){
							$.datetimepicker._destroyDatepicker($element.children("input")[0]);
							$element.removeData();
							$element.remove();
							$scope.unbindDestroyEvent();
							$scope.unbindDestroyEvent = null;
							if($scope.$ConvertViewToModel){
								$scope.$ConvertViewToModel();
								$scope.$ConvertViewToModel = null;
							}
							if($scope.$ConvertModelToView){
								$scope.$ConvertModelToView();
								$scope.$ConvertModelToView = null;
							}
							$scope.displayformat = null;
					});
				};
			}
		};
	} ,true);

angular.module('uee.ui').directive(
		'adtDroplist',
		function($UEE) {
			return {
				require : '?ngModel',
				restrict : 'A',
				link : function(scope, elem, attrs, ctrl) {
					var xItems = $UEE.propertyValue(scope, $UEE
							.property(attrs.items || ""))
							|| [];
					var droplistHash = $UEE.propertyValue(scope,
							attrs.droplistHash)
							|| {};

					var $scope = $(document).scope();
					var obj = new UCD.Droplist($(elem), xItems,
							droplistHash.onCreateItem);
					obj.init();
					obj.$input.attr("u-validator", attrs.uValidator);

					scope.$Get('$compile')(obj.$header)(scope);

					var changeFn = function(self) {
						if (ctrl) {
							$scope.$safeApply($scope,
									function() {
										if (ctrl) {
											ctrl.$setViewValue(self.$input
													.attr("key"));
										}
									});
						}
						if (droplistHash.onValueChange) {
							droplistHash.onValueChange.apply(this, arguments);
						}
					};
					obj.setOnValueChange(changeFn);
					if (droplistHash.disabled) {
						obj.setDisabled(droplistHash.disabled);
					}
					$(elem).data("obj", obj);

					if (ctrl) {
						// model -> view
						ctrl.$render = function() {
							obj.selectItem(ctrl.$viewValue);
						};
						// load init value from DOM
						// ctrl.$setViewValue(obj.$input.attr("key"));
					}

                    // add --2016/10/11 by gWX300509 修复数据模型change事件无法同步更新DOM的情况
                    scope.$watchCollection(function() {
                        return $UEE.propertyValue(scope, $UEE.property(attrs.items || "")) || [];
                    }, function(newV, oldV) {
                        debugger;
                        if (angular.isArray(newV) && !angular.equals(newV, oldV)) {
                            // 更新jQuery数据
                            obj.setData(newV);
                            // 更新DOM
                           /*
							 * obj.$input.val(undefined);
							 * obj.$input.removeAttr("key"); //
							 * 更新angular中ng-model的数据
							 * ctrl.$setViewValue(undefined);
							 */
                        }
                    });

					// add $destroy function --2016/09/02 by z00278756
					scope.unbindDestroyEvent = scope.$on("$destroy", function(){
						debugger;
						if(obj){
							obj.$container = null;
							obj.$dom = null;
							obj.$header = null;
							obj.$input = null;
							obj.$optionUl = null;
							obj.$options = null;
							obj.$trigger = null;
							if(obj._settings){obj._settings.container = null;}
							obj = null;
						}
						if(elem){
							elem.removeData();
							elem = null;
						}
                        // 在解决内存泄露的问题时，避免在popin关闭弹窗的时候，错误的调用接绑事件
                        scope.unbindDestroyEvent && scope.unbindDestroyEvent();
						scope.unbindDestroyEvent = null;
					});
				}
			};
		});
angular.module('uee.ui').directive(
		'adtMultiDroplist',
		function($UEE) {
			return {
				require : '?ngModel',
				restrict : 'A',
				link : function(scope, elem, attrs, ctrl) {
					var xItems = $UEE.propertyValue(scope, $UEE
							.property(attrs.items || ""))
							|| [];
					var droplistHash = $UEE.propertyValue(scope,
							attrs.droplistHash)
							|| {};
					var obj = new UCD.Droplist($(elem), xItems,
							droplistHash.onCreateItem);
					obj.enableSingle();
					obj.init();
					obj.$input.attr("u-validator", attrs.uValidator);

					scope.$Get('$compile')(obj.$header)(scope);

					var changeFn = function(self) {
						var $scope = $(document).scope();
						$scope.$safeApply($scope, function() {
							if (ctrl) {
								ctrl.$setViewValue(self.$input.attr("key"));
							}
						});
						if (droplistHash.onValueChange) {
							droplistHash.onValueChange.apply(this, arguments);
						}
					};
					obj.setOnValueChange(changeFn);
					if (droplistHash.disabled) {
						obj.setDisabled(droplistHash.disabled);
					}
					$(elem).data("obj", obj);

					if (ctrl) {
						// model -> view
						ctrl.$render = function() {
							obj.selectAll(false); // 先清理
							obj.selectItem(ctrl.$viewValue);
						};
						ctrl.$setViewValue(obj.$input.attr("key"));
					}

					scope.$watch(xItems, function(newV) {
						obj.setData(newV);
					});
				}
			};
		});

angular
		.module('uee.ui')
		.directive(
				'adtDate',
				function() {
					return {
						require : '?ngModel',
						restrict : 'A',
						link : function(scope, elem, attrs, ctrl) {
							var dateHash = $UEE.propertyValue(scope,
									attrs.dateHash)
									|| {};

							var dateTime = new UCD.Date(dateHash.options || {});
							dateTime.init();
							dateTime.setAnchor($(elem));

							var changeFn = function() {
								var $scope = $(document).scope();
								var $this = this;
								$scope.$safeApply($scope, function() {
									if (ctrl && $this.getValue()) {
										ctrl.$setViewValue(new Date($this
												.getValue().replace(/-/g, "/"))
												.getTime());
									}
								});

								if (dateHash.onChanged) {
									dateHash.onChanged.apply(this, arguments);
								}
							};
							dateTime.setOnChanged(changeFn);

							$(elem).find(".calendarInput").attr("readonly",
									"readonly");
							$(elem).data("obj", dateTime);

							if (ctrl) {
								// model -> view
								ctrl.$render = function() {
									var dateFormat = dateTime._settings.dateFormat;
									if (ctrl.$viewValue) {
										dateTime.setValue(new Date(
												ctrl.$viewValue)
												.Format(dateFormat));
									} else {
										$(elem).find(".calendarInput").val('');
									}
								};
							}
						}
					};
				});

/**
 * 江苏移动充值卡和裸机价格显示的过滤器
 */
angular
.module('uee.ui')
.filter(
        'displayPriceForAD',
        function() {
            return function(input, symbol) {
                var out = "";
                var $page = $(document).scope().$Page;
                var reg = new RegExp("^[0-9]*$");
                input = input || "";
                if(input.length == 0 || !reg.test(input)){
                    return input;
                }

                $page.displayPriceInfo = $page.displayPriceInfo || {};
                out = ($page.displayPriceInfo.currencySymbol || "")
                        + (symbol || "")
                        + (adutil.approxPrice(input) / Math
                                .pow(
                                        10,
                                        parseInt($page.displayPriceInfo.precision || 0)))
                                .toFixed(2);

                return out;
            };
        });

angular
		.module('uee.ui')
		.filter(
				'displayPrice',
				function() {
					return function(input, symbol) {
						var out = "";
						var $page = $(document).scope().$Page;

						$page.displayPriceInfo = $page.displayPriceInfo || {};
						out = ($page.displayPriceInfo.currencySymbol || "")
								+ (symbol || "")
								+ (adutil.approxPrice(input) / Math
										.pow(
												10,
												parseInt($page.displayPriceInfo.precision || 0)))
										.toFixed(2);

						return out;
					};
				});

/**
 * 批量框架使用 时间filter
 */
  angular.module('uee.ui').filter(
            'hourMinute',
            function() {
                return function(input, datetime) {
					 debugger;
					 input = input || "";
                	 var hourMinute;
                     if(input.length > 0)
                     {
						hourMinute = input.substr(11,5);
						return hourMinute;
					 }

                };
            });

angular.module('uee.ui').filter('dateFormat', function() {
	return function(input, param) {

		var output = "";
		if(!input || !param) {
			return output;
		}

		if (typeof input == "string")
		{
			input = parseInt(input);

			if ( isNaN(input)){
				return output
			}
		}

		var dTime = adutil.convertToBeTime(input);
		if(dTime == "") {
			return output;
		}
		if("datetime" == param) {
			output = dTime.toLocaleString();
		} else if("date" == param) {
			output = dTime.Format("yyyy-MM-dd");
		} else if("time" == param) {
			output = dTime.toLocaleTimeString();
		}
		return output;
	};
});

/**
 * 对已经除1000的价格增加多货币国际化单位
 */
angular.module('uee.ui').filter('displayPriceForTransed',
		function() {
			return function(input, symbol) {
				var out = "";
				var $page = $(document).scope().$Page;

				$page.displayPriceInfo = $page.displayPriceInfo || {};
				out = ($page.displayPriceInfo.currencySymbol || "")
						+ (symbol || "")
						+ input.toFixed(2);

						return out;
					};
				});

/**
 *
 * 使用此valueChange函数后，当前Droplist下增加对象selectedObj，为当前选择的key和value
 * 如果在此Droplist下单独写了回调函数selectedCallback，则设置了selectedObj后，会去执行
 *
 * @param self
 * @returns {___anonymous35895_35896}
 *
 * @author w00233525
 */
function triggerOnValueChange(self) {
	debugger;
	if (!self.selectedObj) {
		self.selectedObj = {};
	}
	self.selectedObj.key = self.$input.attr('key');
	self.selectedObj.value = self.$input.val();
	//
	try {

		$Page = $(document).scope().$Page;
		if (!$Page.dropValue) {
			$Page.dropValue = {};
		}
		$Page.dropValue[self.$container.attr('id')] = self.selectedObj;
	} catch (e) {

	}
	// 如果自定义了回调函数则执行，执行完后清除
	if (self.selectedCallback) {
		try {
			if (self.selectedCallback) {
				self.selectedCallback();
			}
		} catch (e) {

		}
	}
}
/**
 * droplist 初始化后设置默认值到被选后的对象selectedObj中
 *
 * @param dropL
 */
function droplistAfterInitGetDefaultObj(dropL) {
	if (!dropL.selectedObj) {
		dropL.selectedObj = {};
	}
	dropL.selectedObj.key = dropL.$input.attr('key');
	dropL.selectedObj.value = dropL.$input.val();
}
/**
 * droplist 将初始化的值里面的选中项返回
 */
function selectedDefaultDictItem(DictItemList) {
	if (!DictItemList
			|| Object.prototype.toString.call(DictItemList) != "[object Array]") {
		return null;
	}
	for ( var i in DictItemList) {
		if (DictItemList[i].selected) {
			return [ DictItemList[i] ];
		}
	}
	return null;
}

/**
 * 加载过程，不允许修改页面数据
 */
function dontTouchDataOfWholePage() {
	var loadingCover = $('#loadingcover');
	if (loadingCover && loadingCover.length > 0) {
		loadingCover.show();
	} else {
		var a = "<div class=\"fullcover\" id=\"loadingcover\"><img class=\"loading\" src=\"resource.root/bes/ad/images/indicator_verybig.gif\" /></div>";
		$('body').append(a);
	}
	// modified by b00284253 新增超时处理，60秒以后弹框并去除转圈效果
	if(window.timeOutMonitor){
		clearTimeout(window.timeOutMonitor);
		window.timeOutMonitor=null;
	}
	window.timeOutMonitor = setTimeout(function(){
		debugger
		if($('#loadingcover').css("display")=="block"){
			$('#loadingcover').hide();
			$(document).scope().$Get("$UI").msgbox.error($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.TimeoutErrorMessage"));
		}
	},62000);
}

/**
 * 加载结束，放开限制，允许修改页面数据
 */
function youCanTouchDataOfWholePage() {

	if(window.timeOutMonitor){
		clearTimeout(window.timeOutMonitor);
		window.timeOutMonitor=null;
	}

	$('#loadingcover').hide();
}

function showLoadingWithHint(loadingHintMsg) {
    debugger
	var loadingHint = $('#loadingHint');
	if (loadingHint && loadingHint.length > 0) {
		loadingHint.show();
	} else {
		var a = "<div class=\"fullcover\" id=\"loadingHint\"><img class=\"loading\" src=\"resource.root/bes/ad/images/indicator_verybig.gif\" /> " +
                    "<div class='loading h1' id='loadingHintMsgId' style='margin-left: -15px;margin-_ysp_top: 0px;color: white;'></div>" +
                 "</div>";
		$('body').append(a);
	}

    var loadingHintMsgId = $("#loadingHintMsgId");
    loadingHintMsgId.text(loadingHintMsg);

	// modified by b00284253  新增超时处理，60秒以后弹框并去除转圈效果
	if(window.loadingHintMonitor){
		clearTimeout(window.loadingHintMonitor);
		window.loadingHintMonitor=null;
	}
	window.loadingHintMonitor = setTimeout(function(){
		debugger
		if($('#loadingHint').css("display")=="block"){
			$('#loadingHint').hide();
			$(document).scope().$Get("$UI").msgbox.error($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.TimeoutErrorMessage"));
		}
	},62000);
}

function refreshHintMsg(loadingHintMsg) {
    var loadingHintMsgId = $("#loadingHintMsgId");
    loadingHintMsgId.text(loadingHintMsg);
};

/**
 * 加载结束，放开限制，允许修改页面数据
 */
function hideLoadingWithHint() {

	if(window.loadingHintMonitor){
		clearTimeout(window.loadingHintMonitor);
		window.loadingHintMonitor=null;
	}

	$('#loadingHint').hide();
}

/**
 * 过滤器，格式化价格显示方式
 */
angular.module('uee.ui').filter(
		'price',
		function() {
			return function(input, param) {
				var $page = $(document).scope().$Page;
				var obj = $page.displayPriceInfo || {};

				var result = (param || obj.currencySymbol || "¥").trim()
						+ Number(
								input
										/ Math.pow(10,
												Number(obj.precision || 0)))
								.toFixed(2);

				return result;
			};
		});

angular.module('uee.ui').filter('overflow', function() {
	return function(input, param) {
		debugger;
		if (!input)
			return;
		if (input.length > 6) {
			return input.substr(0, 5) + "...";
		}
		return input;
	};
});

// 分页,currentPage从第一页开始
function getPageData(listData, currentPage, pageSize) {
	//
	var pageData = {};
	if (!listData) {
		return pageData;
	}
	// 总页数
	pageData.totalNums = parseInt(listData.length / pageSize);
	if (listData.length % pageSize > 0) {
		pageData.totalNums += 1;
	}
	// Dom分页按钮
	var tempSpan = null;
	// 是否已经添加省略号
	var hasSymbol = 0;
	debugger;
	for ( var i = 0; i < pageData.totalNums; i++) {
		tempSpan = null;
		// 如果是当前页
		if (i + 1 == currentPage) {
			tempSpan = {};
			tempSpan.className = "selected uPage";
			tempSpan.text = i + 1;
		}
		// 前三页 || 总页数超过四页，这是最后一页
		else if (i < 3 || i + 1 == pageData.totalNums) {
			tempSpan = {};
			tempSpan.className = "uPage";
			tempSpan.text = i + 1;
		} else if (i + 1 < currentPage) {
			if (0 == hasSymbol) {
				tempSpan = {};
				tempSpan.className = "pageThn thn";
				tempSpan.text = "...";
				hasSymbol = 1;
			}
		} else if (i + 1 > currentPage) {
			if (0 == hasSymbol || 1 == hasSymbol) {
				tempSpan = {};
				tempSpan.className = "pageThn thn";
				tempSpan.text = "...";
				hasSymbol = 2;
			}

		}

		if (i == 0) {
			pageData.spans = [];
		}
		if (tempSpan) {
			pageData.spans.push(tempSpan);
		}

	}
	// 当前页数据
	pageData.currentPageNum = currentPage;
	var currentData = null;
	// 当前页面请求在范围内
	if (listData.length > (currentPage - 1) * pageSize) {
		// 当前页的数据
		currentData = [];
		var endIndex = currentPage * pageSize;
		for ( var i = (currentPage - 1) * pageSize; i < endIndex
				&& i < listData.length; i++) {
			currentData.push(listData[i]);
		}

	}
	pageData.currentData = currentData
	return pageData;

}

// 免填单合并在服务器session增加打印项
function addMergePrintItem(orderId, bussinessType, bussinessDesc, $Fire) {
	debugger;
	var $scope = $(document).scope();
	$Page = $scope.$Page;
	//反馈用户是否成功退款(用于 ： 第三方支付)
	if($Page.ReturnSuccessPay){
		$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"), "退款成功");
	}
	if (!$Fire)
	{
		$Fire = $scope.$Get("$Fire");
	}
	$Fire({
		service : "/bes.oc.ocprintinfoserviceimpl/addmergeprintitem",
		params : {
			printItem : {
				orderId : orderId,
				bussinessType : bussinessType,
				bussinessDesc : bussinessDesc
			}
		},
		target : "$Page.addMergePrintItemResult",
		onafter : function() {
			debugger;
			// 刷新打印项列表
			$Page.addMergePrintItemResult;
		}
	}, $scope);

	// // 刷新打印项列表
	// flushPrintItems($Page);
	$Page.timer = setInterval(function() {
				flushPrintItems($Page);
			}, 5000);
}

// 刷新打印项列表
function flushPrintItems($Page) {
	if ($Page.addMergePrintItemResult == 1)
	{
		clearInterval($Page.timer);
		if (window._ysp_top.frames["besprintiframe"]) {
			window._ysp_top.frames["besprintiframe"].refreshMergePrintItems();
		}
	}
}

// 根据订单号或业务流水号从服务器session中去掉合并打印项，orderIds多个订单以','隔开
function delMergePrintItem(orderIds) {
	debugger;
	var $scope = $(document).scope();
	$scope.$Get("$Fire")({
		service : "/bes.oc.ocprintinfoserviceimpl/delmergeprintitem",
		params : {
			orderIds : orderIds
		},
		target : "$Gadget.addMergePrintItemResult",
		onafter : function() {
			debugger;
			// 刷新打印项列表
			if (window._ysp_top.frames["besprintiframe"]) {
				window._ysp_top.frames["besprintiframe"].refreshMergePrintItems();
			}
		}
	}, $scope);
}

function getRaceList() {
	return [
	                {
	                    "key": "1",
	                    "value": "汉族"
	                },
	                {
	                    "key": "2",
	                    "value": "蒙古族"
	                },
	                {
	                    "key": "3",
	                    "value": "回族"
	                },
	                {
	                    "key": "4",
	                    "value": "藏族"
	                },
	                {
	                    "key": "5",
	                    "value": "维吾尔族"
	                },
	                {
	                    "key": "6",
	                    "value": "苗族"
	                },
	                {
	                    "key": "7",
	                    "value": "彝族"
	                },
	                {
	                    "key": "8",
	                    "value": "壮族"
	                },
	                {
	                    "key": "9",
	                    "value": "布依族"
	                },
	                {
	                    "key": "10",
	                    "value": "朝鲜族"
	                },
	                {
	                    "key": "11",
	                    "value": "满族"
	                },
	                {
	                    "key": "12",
	                    "value": "侗族"
	                },
	                {
	                    "key": "13",
	                    "value": "瑶族"
	                },
	                {
	                    "key": "14",
	                    "value": "白族"
	                },
	                {
	                    "key": "15",
	                    "value": "土家族"
	                },
	                {
	                    "key": "16",
	                    "value": "哈尼族"
	                },
	                {
	                    "key": "17",
	                    "value": "哈萨克族"
	                },
	                {
	                    "key": "18",
	                    "value": "傣族"
	                },
	                {
	                    "key": "19",
	                    "value": "黎族"
	                },
	                {
	                    "key": "20",
	                    "value": "傈僳族"
	                },
	                {
	                    "key": "21",
	                    "value": "佤族"
	                },
	                {
	                    "key": "22",
	                    "value": "畲族"
	                },
	                {
	                    "key": "23",
	                    "value": "高山族"
	                },
	                {
	                    "key": "24",
	                    "value": "拉祜族"
	                },
	                {
	                    "key": "25",
	                    "value": "水族"
	                },
	                {
	                    "key": "26",
	                    "value": "东乡族"
	                },
	                {
	                    "key": "27",
	                    "value": "纳西族"
	                },
	                {
	                    "key": "28",
	                    "value": "景颇族"
	                },
	                {
	                    "key": "29",
	                    "value": "柯尔克孜族"
	                },
	                {
	                    "key": "30",
	                    "value": "土族"
	                },
	                {
	                    "key": "31",
	                    "value": "达斡尔族"
	                },
	                {
	                    "key": "32",
	                    "value": "仡佬族"
	                },
	                {
	                    "key": "33",
	                    "value": "羌族"
	                },
	                {
	                    "key": "34",
	                    "value": "布朗族"
	                },
	                {
	                    "key": "35",
	                    "value": "撒拉族"
	                },
	                {
	                    "key": "36",
	                    "value": "毛南族"
	                },
	                {
	                    "key": "37",
	                    "value": "仫佬族"
	                },
	                {
	                    "key": "38",
	                    "value": "锡伯族"
	                },
	                {
	                    "key": "39",
	                    "value": "阿昌族"
	                },
	                {
	                    "key": "40",
	                    "value": "普米族"
	                },
	                {
	                    "key": "41",
	                    "value": "塔吉克族"
	                },
	                {
	                    "key": "42",
	                    "value": "怒族"
	                },
	                {
	                    "key": "43",
	                    "value": "乌孜别克族"
	                },
	                {
	                    "key": "44",
	                    "value": "俄罗斯族"
	                },
	                {
	                    "key": "45",
	                    "value": "鄂温克族"
	                },
	                {
	                    "key": "46",
	                    "value": "德昂族"
	                },
	                {
	                    "key": "47",
	                    "value": "保安族"
	                },
	                {
	                    "key": "48",
	                    "value": "裕固族"
	                },
	                {
	                    "key": "49",
	                    "value": "京族"
	                },
	                {
	                    "key": "50",
	                    "value": "塔塔尔族"
	                },
	                {
	                    "key": "51",
	                    "value": "独龙族"
	                },
	                {
	                    "key": "52",
	                    "value": "鄂伦春族"
	                },
	                {
	                    "key": "53",
	                    "value": "赫哲族"
	                },
	                {
	                    "key": "54",
	                    "value": "门巴族"
	                },
	                {
	                    "key": "55",
	                    "value": "珞巴族"
	                },
	                {
	                    "key": "56",
	                    "value": "基诺族"
	                }
	            ];

}

/**
 * @description tips提示信息优化:鼠标移上去0.5秒后展示 直到鼠标移走再消失
 * @remark create wwx230437 2015-12-11 C30SPC001B200 DTS2015120501162
 */
var global_prodPurch_id = "";
var global_prodPurch_timer = null;
function showTips(tips,divshowid,flag)
{
	debugger;
	if(flag)
	{
       global_prodPurch_id = divshowid;
       global_prodPurch_timer = setTimeout(function(){startShowtips(tips,divshowid)},500);
    }
	else
    {
      if(divshowid == global_prodPurch_id)
      {
    	 global_prodPurch_id = "";
      	 if (global_prodPurch_timer)
	     {
	      	clearTimeout(global_prodPurch_timer);
	     }
	     var showTipsDivid = "tips" + divshowid;
		 var showTipsDiv = document.getElementById(showTipsDivid);
	     if (showTipsDiv)
	     {
	        showTipsDiv.style.display="none";
	     }
      }
   }
}

function startShowtips(tips,divshowid)
{
	debugger;
	if (divshowid == global_prodPurch_id)
	{
		if (!tips)
		{
			tips =  $("#"+divshowid).attr("tips");
		}
		if(!tips || "" == tips)
		{
			return;
		}
		var showTipsDivid = "tips" + divshowid;
		var showTipsDiv = document.getElementById(showTipsDivid);
		if (!showTipsDiv)
		{
			$("#"+divshowid).append("<div id="+ escapeHtml(showTipsDivid) +" style=\"display:none;z-index:999;position:absolute;bottom:33px;width:auto;max-width:280px;overflow: hidden;padding:0 10px;border:1px solid #8797ab;border-radius:5px;background:#fff;white-space: normal;word-break: normal;\"></div>");
		}
		showTipsDiv = document.getElementById(showTipsDivid);
	    showTipsDiv.innerHTML="<p style=\"line-height: 22px;\">"+tips+"</p>";
		showTipsDiv.style.display = "";
	}
}

function addBefore() {
	$(document).find('body').attr("style", "overflow:hidden");
}

function removeAfter() {
	$(document).find('body').removeAttr("style");
}

function escapeHtml(text) {
	text = text || '';
	var map = {
	'&': '&amp;',
	'<': '&lt;',
	'>': '&gt;',
	'"': '&quot;',
	"'": '&#039;',
	'/': '/',
	'(': '&#40;',
	')': '&#41;'
	};
	return text.replace(/[&<>"'()/]/g, function(m) { return map[m]; });
}

/**
 * 添加校验结果
 *
 * @param $Gadget
 * @param errNo
 * @param resId
 */
function addBusinessCharacterValidateResult($Gadget, errNo, resId){

	if(!$Gadget.businessCharacterValidateResult){
		$Gadget.businessCharacterValidateResult = [];
	}

	var resStr = $UEE.i18n(resId);
	$Gadget.businessCharacterValidateResult.push({retCode : errNo, retMessage : resStr});

	var $UI = $Gadget.$Get("$UI");
	$UI.msgbox.info($UEE.i18n("ad.group.message.MSGBOXINFO"), resStr);
	return;
}

$(function() {
	$("#popwin_close").on("click",function(){
		$(document).find('body').removeAttr("style");
	});
});

function getVersionUrlStr(param)
{
	if($UEE.version != null)
	{
		if(param == 1)
		{
			return "?build="+$UEE.version;
		}
		else
		{
			return "&build="+$UEE.version;
		}
	}
	else
	{
		if(param == 1)
		{
			// return "?build="+$UEE.version;
			return "?";
		}
		else
		{
			// return "&build="+$UEE.version;
			return "";
		}
	}
}
/**
 * 根据menu_id获取到menu_url
 */
function getMenuUrlStr(key,name,menuId)
{
	debugger;
	var $scope = $(document).scope();
	if(menuId==null)
	{
		return "";
	}
	$scope.$Get("$Fire")({
		service : '/ucec/v1/queryMenuByMenuId',
		params : {
			header : {},
			body : {
					menuId : menuId
			}
		},
		target : '$Page.menu',
		onafter : function() {
			debugger;
			var menuUrl= $Page.menu.menuUrl;
			if(menuUrl)
			{
				menuUrl = menuUrl.substring(menuUrl.indexOf("/",1));
				// 跳转页面
				adutil.openUserTab(key,name,menuUrl);
				// _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key,
				// name,menuUrl, "",false);
			}
		}
	}, $scope);
}
/**
 * 页面加载完执行 页面访问埋点统计 l00356902
 */
$(document).ready(function(){

    var head= document.getElementsByTagName('head')[0];
    var script= document.createElement('script');
    script.type= 'text/javascript';
    script.src= 'resource.root/bes/ad/js/BuriedPointStatistics.js';
    head.appendChild(script);
    
    var scriptParamDict= document.createElement('script');
    scriptParamDict.type= 'text/javascript';
    scriptParamDict.src= 'resource.root/bes/ad/common/paramdict/ad-param-dict.js';
    head.appendChild(scriptParamDict);
});


/**
 * 页面销毁动作
 */

$( window ).unload(function() {
// debugger;

	if ( window.jQuery ) {
		// IEMEMLEAK:4MB in IE8 render input
		window.jQuery.cache = {};

		// clean datetimepicker
		if(window.jQuery.datetimepicker){
			window.jQuery.datetimepicker = null;
		}
	}

	if(window.jBME){
		for(value in window.jBME){
			window.jBME = null;
		}
		window.jBME = null;
	}
	window.jBME = null;
	if(window.$UEE){
		window.$UEE.Timezone = null;
		if(window.$UEE.$Tz){
			window.$UEE.$Tz.serverTimezone = null;
		}
		window.$UEE.$Tz = null;
	}
	// clean I18n
	window.$UEE.$I18n = {};
	window.$UEE = null;

	// 清理iframe内window上挂的UCD相关的全局变量
	// 优雅的做法应该是UCD组件各自在$on $destroy发生时自己清理
	if(window.$.oc_droplists){
		for(val in window.$.oc_droplists){
			var temp = window.$.oc_droplists[val];
			temp.$container = null;
			temp.$dom = null;
			temp.$header = null;
			temp.$input = null;
			temp.$optionUl = null;
			temp.$options = null;
			temp.$trigger = null;
			if(temp._settings){temp._settings.container = null;}
			temp = null;
		}
		window.$.oc_droplists = null;
	}

	if(window.UCD){
		if(window.UCD.Pages){
			if(window.UCD.Pages.ins){
				for(value in window.UCD.Pages.ins){
					if(window.UCD.Pages.ins[value] && window.UCD.Pages.ins[value]._settings){
						window.UCD.Pages.ins[value]._settings.$container= null;
						window.UCD.Pages.ins[value]._settings.$ctrl= null;
						window.UCD.Pages.ins[value]._settings.$dom= null;
						window.UCD.Pages.ins[value]._settings.$goto= null;
						window.UCD.Pages.ins[value]._settings.$next= null;
						window.UCD.Pages.ins[value]._settings.$prev= null;
						window.UCD.Pages.ins[value]._settings.$showList= null;
						window.UCD.Pages.ins[value]._settings.$total= null;
						window.UCD.Pages.ins[value]._settings.container = null;
					window.UCD.Pages.ins[value] = null;
					}
				}
			}
			window.UCD.Pages.ins = null;
		}

		window.UCD.Pages = null;
		if(window.UCD.Radio){
			if(window.UCD.Radio.ins){
				for(value in window.UCD.Radio.ins){
					if(window.UCD.Radio.ins[value]._settings){
						window.UCD.Radio.ins[value]._settings.$container= null;
						window.UCD.Radio.ins[value]._settings.$radio= null;
						window.UCD.Radio.ins[value]._settings.$dom= null;
						window.UCD.Radio.ins[value]._settings.container = null;
					}
					window.UCD.Radio.ins[value] = null;
				}
			}
			window.UCD.Radio.ins = null;
		}

		window.UCD.Radio = null;
		window.UCD.Droplist = null;
		window.UCD.Dialog = null;
		window.UCD.Date = null;
		window.UCD.Core = null;
		window.UCD.Checkbox = null;
	}

	if(window.$ && window.$.popwin){
		var popObj = window.$.popwin.getPopwinObject();
		if(popObj){
			popObj.win["popwin"+popObj.inst]=undefined;
			if(window.$ && window.$.dialog && window.$.dialog[popObj.inst]){
				window.$.dialog[popObj.inst] = undefined;
			}
		}
		window.$.popwin.close();
		window.$.popwin = null;
		window.$.dialog = null;
		window.$.fn.extendtree = null;
		window.$.fn.popselect = null;
		window.$.fn.extendmenu = null;
	}

	window.$win = null;
	window.$doc = null;


	if(window.$ && window.$.validator)
	{
		window.$.validator = null;
		window.$ = null;
	}

	// clean $Page in window
	window.$Page = null;
	window.$Fire = null;
	window.AdDictionary=null;
	window.AdMap=null;
	window.AdParameter=null;
	window.OC_Droplist=null;
	window.Tabset=null;
	window.dealWithTreeEle=null;
	window.dealMsg=null;
	window.creatTree=null;
	window.tabSet=null;
	window.test=null;
	window.test1=null;
	window.adtips = null;
	window.closeAllDialogs=null;
	window.closePortalTab=null;
	window.setCardInfo=null;
	window.setPagesListHTML=null;
	window.showIDImg=null;
	window.showTips=null;
	window.startShowtips=null;
	window.transRaceStr=null;
	window.triggerOnValueChange=null;
	window.upLoadIDCardForPrint=null;
	window.youCanTouchDataOfWholePage=null;
	window.selectedDefaultDictItem=null;

	// DTS2016070903319 解决内存泄露问题
	if(window.onBesTabClose){
		window.onBesTabClose = null;
	}

	if(window.openTaskMenu){
		window.openTaskMenu = null;
	}

});


// 过滤器，格式化手机号空格分开 '18852223698' => '188 5222 3698'
angular.module('uee.ui').filter('mobilePhone', function($q, $Fire) {
    // input:输入
    return function(input, symbol) {
        if (!symbol) {
            symbol = ' ';
        }
        if (input.length === 11) {
            return input.substr(0, 3) + symbol + input.substr(3, 4) + symbol + input.substr(7, 4);
        }
        return input;
    };
});

/**
 * [$filter dictCodeToName，将数据字典code匹配至字典name]
 *
 * @auth {[gWX300509,2016/6/4]}
 * @example
 *       <td ng-bind="$item.region|dictCodeToName:'OC.DIFFNET.CITY'"></td>
 * @param {[service]}
 *            $q angular内置Promise服务
 * @param {[service]}
 *            $Fire UEE扩展$http服务
 * @return {[String]} 过滤后的结果 字典项匹配结果
 */
angular.module('uee.ui').filter('dictCodeToName', function($q, $Fire, $cacheFactory) {
    // 全局缓存
    var dictCaches = $cacheFactory.get('uee.ui.filter.dictCodeCaches') || $cacheFactory('uee.ui.filter.dictCodeCaches');
    var checkedDigestFlag = true;
    // 请求数字字典数据
    function getDictPromise(dictKey) {
        // 创建Promise对象
        var deferred = $q.defer();
        $Fire({
            service: '/meta/dictkey',
            params: {
                'dictkeylist': [dictKey],
            },
            target: 'data',
        }).onafter(function(data) {
            deferred.resolve(data);
        }).onerror(function() {
            // 设置deferred状态为拒绝
            deferred.reject();
        });
        // 返回Promise对象
        return deferred.promise;
    }
    /**
     * 默认从缓存中取值，如果缓存为空，值为input
     */
    function getValue(data, dictKey, input) {
        var value;
        angular.forEach(data[dictKey], function(item) {
            if (item.key == input)
                value = item.value;
        });
        return value || input;
    }
    // input:输入的字典值; dictKey:需要匹配的字典项
    return function(input, dictKey) {
        // 没有指定匹配的字典项则返回原始值
        if (!dictKey) {
            console.error('$filter:dictCodeToName can not find dictKey, please check ' + input);
            return input;
        }
        if (!dictCaches.get(dictKey)) {
            // 中转信号位，防止脏值检查时多次触发请求(必须要判断，否则会存在死循环)
            dictCaches.put(dictKey, checkedDigestFlag);
            return getDictPromise(dictKey).then(function successCallback(data) {
                // 查询完毕后异步返回结果,并缓存请求数据，替换信号位为具体数据
                dictCaches.put(dictKey, data);
                return getValue(data, dictKey, input);
            }, function errorCallback() {
                // 直接返回
                return input;
            });
        }
        return getValue(dictCaches.get(dictKey), dictKey, input);
    };
});
// 过滤器，根据当前货币精度过滤
angular.module('uee.ui').filter('displayprice', function() {
    return function(input) {
        return angular.isArray(input) ? adutil.getDisplayPrice(input[0], input[1]) : adutil.getDisplayPrice(input);
    };
});

/**
 * 获取图片编码
 *
 * @param imagePath
 *            证件图片绝对路径
 */
function getBase64OfImage(imagePath) {
	var hwUtil = document.getElementById("HWUtilOCX") || document.getElementById("HWUtilOCXS");
	if (hwUtil && imagePath) {
		return hwUtil.Base64EncodePath(imagePath);
	}
	return "";
};
/**
 * 去除水印，和watermark配套使用
 * by ywx440571 2017-01-21
 */
function removeWatermark(){
	debugger;
	var mask_divs = [];
	//ie8兼容
	try{
		mask_divs = document.body.getElementsByClassName('mask_div');
	}catch(e){
		for(var i = 0;i<document.body.childNodes.length;i++){
			if(document.body.childNodes[i].nodeType === 1){
				var name = document.body.childNodes[i].className;
				if(name.search(/mask_div/) != -1){
					mask_divs.push(document.body.childNodes[i]);
				}
			}
		}
	}
	//var mask_divs = document.body.getElementsByClassName('mask_div');
	var len = mask_divs.length;
	for(var i=len-1;i>=0;i--){
		document.body.removeChild(mask_divs[i]);
	}
};
/**
* 水印用法如watermark({ watermark_txt: new Date().toLocaleString() ,watermark_divid:'div1'});
* watermark_divid 必传，主要是将水印填充入此div
* by ywx440571 2017-01-21
*/
function watermark(settings) {
  debugger;
  //默认设置
  var defaultSettings={
	watermark_divid:'',//divId 必传，将水印填充入此div
	watermark_txt:"text",
	watermark_x:20,//水印起始位置x轴坐标
	watermark_y:20,//水印起始位置Y轴坐标
	watermark_rows:20,//水印行数
	watermark_cols:20,//水印列数
	watermark_x_space:100,//水印x轴间隔
	watermark_y_space:50,//水印y轴间隔
	watermark_color:'rgb(107, 61, 61)',//水印字体颜色
	watermark_alpha:0.3,//水印透明度
	watermark_fontsize:'14px',//水印字体大小
	watermark_font:'微软雅黑',//水印字体
	watermark_width:200,//水印宽度，可根据具体文字长度及大小调整
	watermark_height:80,//水印长度
	watermark_lineheight:25,
	watermark_zindex:'-1',
	watermark_textalign:'center',
	watermark_overflow:'hidden',
	watermark_display:'block',
	watermark_angle:15//水印倾斜度数
  };
  //采用配置项替换默认值，作用类似jquery.extend
  if(arguments.length===1&&typeof arguments[0] ==="object" )
  {
	var src=arguments[0]||{};
	for(key in src)
	{
	  if(src[key]&&defaultSettings[key]&&src[key]===defaultSettings[key])
		continue;
	  else if(src[key])
		defaultSettings[key]=src[key];
	}
  }

  var oTemp = document.createDocumentFragment();

  //获取页面最大宽度
  //var page_width = Math.max(document.body.scrollWidth,document.body.clientWidth);
  //获取页面最大长度
  //var page_height = Math.max(document.body.scrollHeight,document.body.clientHeight);
  debugger;

  //修改的div
  var modify_div = document.getElementById(defaultSettings.watermark_divid);
  var page_width = modify_div.clientWidth;
  var page_height = modify_div.clientHeight;

  //如果将水印列数设置为0，或水印列数设置过大，超过页面最大宽度，则重新计算水印列数和水印x轴间隔
  if (defaultSettings.watermark_cols == 0 || (parseInt(defaultSettings.watermark_x + defaultSettings.watermark_width *defaultSettings.watermark_cols + defaultSettings.watermark_x_space * (defaultSettings.watermark_cols - 1)) > page_width)) {
	defaultSettings.watermark_cols = parseInt((page_width-defaultSettings.watermark_x+defaultSettings.watermark_x_space) / (defaultSettings.watermark_width + defaultSettings.watermark_x_space));
	defaultSettings.watermark_x_space = parseInt((page_width - defaultSettings.watermark_x - defaultSettings.watermark_width * defaultSettings.watermark_cols) / (defaultSettings.watermark_cols - 1));
  }
  //如果将水印行数设置为0，或水印行数设置过大，超过页面最大长度，则重新计算水印行数和水印y轴间隔
  if (defaultSettings.watermark_rows == 0 || (parseInt(defaultSettings.watermark_y + defaultSettings.watermark_height * defaultSettings.watermark_rows + defaultSettings.watermark_y_space * (defaultSettings.watermark_rows - 1)) > page_height)) {
	defaultSettings.watermark_rows = parseInt((defaultSettings.watermark_y_space + page_height - defaultSettings.watermark_y) / (defaultSettings.watermark_height + defaultSettings.watermark_y_space));
	
	var divNum=defaultSettings.watermark_rows > 1?(defaultSettings.watermark_rows - 1):1;
	defaultSettings.watermark_y_space = parseInt(((page_height - defaultSettings.watermark_y) - defaultSettings.watermark_height * defaultSettings.watermark_rows) / divNum);
  }
  var x;
  var y;
  for (var i = 0; i < defaultSettings.watermark_rows; i++) {
	y = defaultSettings.watermark_y + (defaultSettings.watermark_y_space + defaultSettings.watermark_height) * i + modify_div.offsetTop;
	for (var j = 0; j < defaultSettings.watermark_cols; j++) {
	  x = defaultSettings.watermark_x + (defaultSettings.watermark_width + defaultSettings.watermark_x_space) * j + modify_div.offsetLeft;

	  var mask_div = document.createElement('div');
	  mask_div.id = 'mask_div' + i + j;
	  mask_div.className = 'mask_div';
	  mask_div.appendChild(document.createTextNode(defaultSettings.watermark_txt));
	  //设置水印div倾斜显示
	  //如果浏览器不支持下列样式，则走兼容样式
      if(mask_div.style.webkitTransform == '' || mask_div.style.MozTransform == '' || mask_div.style.msTransform == '' 
 	     || mask_div.style.OTransform == '' || mask_div.style.transform == ''){
		mask_div.style.webkitTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";//webkit代表谷歌内核识别码
	    mask_div.style.MozTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";//moz代表火狐内核识别码
	    mask_div.style.msTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";//ms代表ie内核识别码
	    mask_div.style.OTransform = "rotate(-" + defaultSettings.watermark_angle + "deg)";//o代表opera内核识别码
	    mask_div.style.transform = "rotate(-" + defaultSettings.watermark_angle + "deg)";//统一标识语句w3c标准
	  }else{//ie8+兼容
	    var cos = Math.cos(2*Math.PI/360* defaultSettings.watermark_angle);
		var sin = Math.sin(2*Math.PI/360* defaultSettings.watermark_angle);
		mask_div.style.filter="progid:DXImageTransform.Microsoft.Matrix(sizingMethod='auto expand',M11="+cos+",M12="+sin+",M21="+(0-sin)+",M22="+cos+")";
	  }
	  mask_div.style.visibility = "";
	  //定位
	  mask_div.style.position = "absolute";
	  mask_div.style.left = x + 'px';
	  mask_div.style._ysp_top = y  + 'px';

	  mask_div.style.overflow = defaultSettings.watermark_overflow;
	  mask_div.style.zIndex = defaultSettings.watermark_zindex;
	  //mask_div.style.border="solid #eee 1px";
	  //ie8兼容
	  if(mask_div.style.opacity==''){
		mask_div.style.opacity = defaultSettings.watermark_alpha;
	  }else{
		mask_div.style.filter += ' | progid:DXImageTransform.Microsoft.Alpha(opacity='+ defaultSettings.watermark_alpha * 100 +')';
	  }
	  mask_div.style.fontSize = defaultSettings.watermark_fontsize;
	  mask_div.style.fontFamily = defaultSettings.watermark_font;
	  mask_div.style.color = defaultSettings.watermark_color;
	  //文字居中显示
	  mask_div.style.textAlign = defaultSettings.watermark_textalign;
	  mask_div.style.lineHeight = defaultSettings.watermark_lineheight + 'px';

	  mask_div.style.width = defaultSettings.watermark_width + 'px';
	  mask_div.style.height = defaultSettings.watermark_height + 'px';
	  mask_div.style.display = defaultSettings.watermark_display;
	  oTemp.appendChild(mask_div);
	};
  };
  document.body.appendChild(oTemp);
};

/**
 * 山东定制水印的公共js
 */


//山东定制水印需求  cwx411021  根据系统参数进行局点判断
function SDWaterMark($Gadget,div_id){
	debugger;
	var $Fire = $Gadget.$Get('$Fire');
	$Fire({
    service: 'ucec/v1/common/qrysystemparambykey',
    params: {
        key: "6010000505"
    },
    target: "$Gadget.watermark",
    onafter: function() {
        debugger;
        if ($Gadget.watermark) {
			 $Fire({
			   service : 'bes.oc.operateinfoservice/getoperateinfo',
			   params : {},
			   target : '$Gadget.operinfo',
			   onafter : function() {
				   debugger;
	                var operId = $Gadget.operinfo.operatorId;
	                
	                var request = {
							header: null,
							body: {
								staffId: operId
							}
						}
	                $Fire({
						service : '/ucec/v1/order/operator_query',
						params : request,
						target : '$Gadget.operatorDetails',
						
						onafter : function($Gadget) {
							debugger;
						    //获取当前时间
							var time=CurentTime();
						    var name = $Gadget.operatorDetails.body.operators[0].name;
						    watermark({ watermark_txt: operId+ " "+time+ " "+name, watermark_divid:div_id});
						         
						}
					}, $Gadget);
	           }
	    }, $Gadget);
			document.body.oncontextmenu = function(){return  false;};
			document.body.oncopy=function(){return  false;};
			document.body.onselectstart=function(){return  false;};
        }
    }
}, $Gadget);
}

//山东定制水印需求    根据系统参数进行局点判断
function SDWaterBackMark($Gadget,div_id){
	debugger;
	var $Fire = $Gadget.$Get('$Fire');
	$Fire({
    service: 'ucec/v1/common/qrysystemparambykey',
    params: {
        key: "6010000505"
    },
    target: "$Gadget.watermark",
    onafter: function() {
        debugger;
        if ($Gadget.watermark) {
			 $Fire({
			   service : 'bes.oc.operateinfoservice/getoperateinfo',
			   params : {},
			   target : '$Gadget.operinfo',
			   onafter : function() {
				   debugger;
	                var operId = $Gadget.operinfo.operatorId;
	                
	                var request = {
							header: null,
							body: {
								staffId: operId
							}
						}
	                $Fire({
						service : '/ucec/v1/order/operator_query',
						params : request,
						target : '$Gadget.operatorDetails',
						
						onafter : function($Gadget) {
							debugger;
						    //获取当前时间
							var time=CurentTime();
						    var name = $Gadget.operatorDetails.body.operators[0].name;
						
						         
						}
					}, $Gadget);
	           }
	    }, $Gadget);
			document.body.oncontextmenu = function(){return  false;};
			document.body.oncopy=function(){return  false;};
			document.body.onselectstart=function(){return  false;};
        }
    }
}, $Gadget);
}
//山东定制水印需求    根据系统参数进行局点判断
function SDNotWaterMark($Gadget,div_id){
	debugger;
	var $Fire = $Gadget.$Get('$Fire');
	$Fire({
    service: 'ucec/v1/common/qrysystemparambykey',
    params: {
        key: "6010000505"
    },
    target: "$Gadget.watermark",
    onafter: function() {
        debugger;
        if ($Gadget.watermark) {
			 $Fire({
			   service : 'bes.oc.operateinfoservice/getoperateinfo',
			   params : {},
			   target : '$Gadget.operinfo',
			   onafter : function() {
				   debugger;
	                var operId = $Gadget.operinfo.operatorId;
	                
	                var request = {
							header: null,
							body: {
								staffId: operId
							}
						}
	                $Fire({
						service : '/ucec/v1/order/operator_query',
						params : request,
						target : '$Gadget.operatorDetails',
						
						onafter : function($Gadget) {
							debugger;
						    //获取当前时间
							var time=CurentTime();
						    var name = $Gadget.operatorDetails.body.operators[0].name;
						   
						         
						}
					}, $Gadget);
	           }
	    }, $Gadget);
			document.body.oncontextmenu = function(){return  true;};
			document.body.oncopy=function(){return  true;};
			document.body.onselectstart=function(){return  true;};
        }
    }
}, $Gadget);
}
function CurentTime()
{ 
    var now = new Date();
   
    var year = now.getFullYear();       //年
    var month = now.getMonth() + 1;     //月
    var day = now.getDate();            //日
   
    var hh = now.getHours();            //时
    var mm = now.getMinutes();          //分
   
    var clock = year + "-";
   
    if(month < 10)
        clock += "0";
   
    clock += month + "-";
   
    if(day < 10)
        clock += "0";
       
    clock += day + " ";
   
    if(hh < 10)
        clock += "0";
       
    clock += hh + ":";
    if (mm < 10) clock += '0'; 
    clock += mm; 
    return(clock); 
} 
//end

// add by l00380145  山东业务受理计时功能  US-20170518100906-2031000316 2017-06-17 begin

/**
 * 按照菜单ID注册计时开始-打开菜单时调用
 * @param  {String} menuID 菜单ID
 */
function regBusinessTimer(menuID) {
    debugger;
    try {

        // menuID为空，直接返回
        if (!menuID) {
            return;
        }

        // 受理时间 Map
        var timerMap = window._ysp_top.publicObject['businessTimerMap'];

        if(!timerMap) {
            timerMap = {};
            window._ysp_top.publicObject['businessTimerMap'] = timerMap;
        }

        if(timerMap) {
            var nowDate = new Date();
            timerMap[menuID]= nowDate.getTime();
        }

        // 启用定时
        setBusinessTimer(menuID);

    } catch (ex) {

    }

}

/**
 * 按menuID启用定制器
 * @param {String} menuID 菜单ID
 */
function setBusinessTimer(menuID) {
    debugger;

    // 受理时间div-business_timer 
    var businessTimerDiv = window._ysp_top.publicObject['businessTimerDiv'];

    try {
        var timerMap = window._ysp_top.publicObject['businessTimerMap'];

        if(timerMap[menuID]) {
            // 受理时间定时器变量
            var tmpTimerID = window._ysp_top.publicObject['businessTimerID'];
            if(tmpTimerID) {
                window.clearInterval(tmpTimerID);
            }

            window._ysp_top.publicObject['businessTimerID'] = window.setInterval(
                function() {
                    showBusinessTimer(menuID);
                }, 1000);

            if(businessTimerDiv && businessTimerDiv.style) {
                // 显示受理时间框
                businessTimerDiv.style.display = 'block';
            }

        } else {
            if(businessTimerDiv && businessTimerDiv.style) {
                businessTimerDiv.style.display = 'none';
            }
        }

    } catch (ex) {

        if(businessTimerDiv && businessTimerDiv.style) {
            businessTimerDiv.style.display = 'none';
        }
        
    }

}

/**
 * 受理时间显示
 * @param  {String} menuID 菜单ID
 * @return {Number}        受理时长
 */
function showBusinessTimer(menuID) {
    // debugger;
    // 受理时间 Map
    var timerMap = window._ysp_top.publicObject['businessTimerMap'];

    var businessTime = null;

    if(!timerMap) {
        return;      
    }
    businessTime = timerMap[menuID];

    // 该菜单没有初始时间，不用计时，直接返回
    if(!businessTime) {
        return;
    }

    var now = new Date().getTime();

    var secondSum = (now - businessTime) / 1000;
    var hour = parseInt(secondSum / 3600, 10);
    var minute = parseInt((secondSum % 3600) / 60, 10);
    var second = parseInt(secondSum % 60, 10);

    if(hour < 10) {
        hour = '0' + hour; 
    }

    if(minute < 10) {
        minute = '0' + minute;
    }

    if(second < 10) {
        second = '0' + second;
    }

    // 受理计时div-business_hour
    var businessHour = window._ysp_top.publicObject['businessHour'];
    if(businessHour) {
        businessHour.value = hour;
    }
    
    // 受理计时div-business_minute
    var businessMinute = window._ysp_top.publicObject['businessMinute'];
    if(businessMinute) {
        businessMinute.value = minute;
    }

    // 受理计时div-business_second
    var businessSecond = window._ysp_top.publicObject['businessSecond'];
    if(businessSecond) {
        businessSecond.value = second;
    }

    secondSum = parseInt(hour, 10) * 3600 + parseInt(minute, 10) * 60 + parseInt(second, 10);
    return secondSum;

}

/**
 * 暂停计数器并返回受理时长
 * @param  {String} menuId 菜单ID
 * @return {Number}        受理时长
 */
function pauseBusinessTimer(menuID) {
    debugger;
    try {
        // 定时器变量
        var tmpTimerID = window._ysp_top.publicObject['businessTimerID'];
        if(tmpTimerID) {
            window.clearInterval(tmpTimerID);
        }
        
        var secondSum = showBusinessTimer(menuID);

        return secondSum;

    } catch(ex) {


    }


}

/**
 * 清除menuID对应的受理时间-关闭菜单时调用
 * @param  {String} menuID 菜单ID
 */
function clearBusinessTimer(menuID) {
    debugger;

    try {

        // menuID为空，直接返回
        if(!menuID) {
            return;
        }

        // 受理时间 Map
        var timerMap = window._ysp_top.publicObject['businessTimerMap'];

        if(timerMap) {
            // 该菜单不在计时，直接返回
            if(!timerMap[menuID]) {
                return;
            }

            timerMap[menuID]= null;
            setBusinessTimer(menuID);
        }

        // 受理时间定时器变量
        var tmpTimerID = window._ysp_top.publicObject['businessTimerID'];
        if(tmpTimerID) {
            window.clearInterval(tmpTimerID);
        }
    } catch(ex) {


    }
    
}

/**
 * 设置business_timer DIV,SM框架调用
 * @param {[type]} menuID [description]
 */
function setBusinessTimerDiv(businessTimerAllDiv) {
    debugger;
    if(!businessTimerAllDiv) {
        return;
    }

    // business_timer DIV
    window._ysp_top.publicObject['businessTimerDiv'] = businessTimerAllDiv.BusinessTimerDiv;
    // biusiness_hour DIV
    window._ysp_top.publicObject['businessHour'] = businessTimerAllDiv.businessHour;
    // business_minute DIV
    window._ysp_top.publicObject['businessMinute'] = businessTimerAllDiv.businessMinute;
    // business_second DIV
    window._ysp_top.publicObject['businessSecond'] = businessTimerAllDiv.businessSecond;

}

// add by l00380145  山东业务受理计时功能  US-20170518100906-2031000316 2017-06-17 end

/**
 * @ngdoc directive
 * @name uee.ui.directive:ocPagination
 * @restrict E
 * @description Pagination.
 * @param {string} [pagesize] [Row count per page.]
 * @param {string} [totalrecord] [Total records.]
 */
angular.module("uee.ui").directive("ocPagination", function($http, $templateCache, $UEE, $timeout, $log, $UI) {
    function link(scope, element, attrs, ctrls, linker) {
        // 选择页 = 当前页
        var choosePage = currentPage = 1;
        // 总记录数
        var totalRecord = 0;
        // 每页大小
        var pageSize = 10;
        // 注册page事件
        var jPageEvent = $.Event("page");
        // clone外部指令
        linker(scope.$new(false), function(clone) {
            for (var i = 0; i < clone.length; i++) {
                if (clone[i].nodeName == "UEE:FIRE" || clone[i].nodeName === 'fire') {
                    element.append(clone[i]);
                }
            }
        });
        
        // 每页大小监听
        attrs.pagesize && scope.$watchCollection(attrs.pagesize, function(newV, oldV) {
            pageSize = newV || 10;
        });
        
        // 总记录数监听
        attrs.totalrecord && scope.$watchCollection(attrs.totalrecord, function(newV, oldV) {
            totalRecord = newV || 0;
            if (currentPage > getMaxPage()) {
                choosePage = currentPage = 1;
            }
            // 更新分页数据
            getTotalPageGroup();
        });
        
        scope.$toPage = function(value) {
            if (value == '...') return;
            choosePage = currentPage = value;
            triggerEvent();
        }

        scope.$nextPage = function($event) {
            $event.stopPropagation();
            if (currentPage + 1 <= getMaxPage()) {
                choosePage = ++currentPage;
                triggerEvent();
            }
        };

        scope.$prePage = function($event) {
            $event.stopPropagation();
            if (currentPage - 1 > 0) {
                choosePage = --currentPage;
                triggerEvent();
            }
        };

        // 事件触发器
        function triggerEvent(button) {
            jPageEvent.pagesize = pageSize;
            jPageEvent.startnum = currentPage > 1 ? (currentPage - 1) * pageSize : 0;
            // 触发分页事件
            element.trigger(jPageEvent);
            // 更新大小
            getTotalPageGroup();
        }
        // 获取最大分页数
        function getMaxPage() {
            return totalRecord != 0 ? Math.ceil(totalRecord / pageSize) : 0;
        }
        // 获取总共分页数据
        function getTotalPageGroup() {  	
            var pageData = [];
            var array = [];
            var maxpage = getMaxPage();
            if (maxpage <= 0) {
                scope.$pageData = [];
                return;
            }
            // 计算分页
            if (currentPage - 6 <= 0) {
                for (var i = 0; i < currentPage; i++) {
                    array.push(i + 1);
                }
            } else {
                array.push(1);
                array.push(2);
                array.push("...");
                for (var i = currentPage - 3; i <= currentPage; i++) {
                    array.push(i);
                }
            }

            if (currentPage + 4 >= maxpage) {
                for (var i = currentPage + 1; i <= maxpage; i++) {
                    array.push(i);
                }
            } else {
                array.push(currentPage + 1);
                array.push(currentPage + 2);
                array.push("...");
                for (var i = maxpage - 1; i <= maxpage; i++) {
                    array.push(i);
                }
            }
            // 更新对象
            angular.forEach(array, function(value) {
                pageData.push({
                    value: value,
                    selected: value == currentPage,
                    isItem: value == '...'
                });
            });

            scope.$pageData = pageData;
        }
    }

    return {
        template: '<div class="paging clearfix"> <div class="uPages"> <div class="ctrls"> <div class="prev" ng-click="$prePage($event)"></div> <div class="ctrl"> <span ng-repeat="$item in $pageData" id="page_{{$item.value}}" ng-class="{selected:$item.selected, uPage:!$item.isItem, thn:$item.isItem}" ng-bind="$item.value" ng-click="$toPage($item.value)"></span> </div> <div class="next" ng-click="$nextPage($event)"></div> </div> </div> </div>',
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: true,
        compile: function(tElement, tAttr, linker) {
            return link;
        }
    };
}, true);

/**
 * @ngdoc directive
 * @name uee.ui.directive:ocPagination
 * @restrict E
 * @description Pagination.
 * @param {string} [pagesize] [Row count per page.]
 * @param {string} [totalrecord] [Total records.]
 */
angular.module("uee.ui").directive("ocPaginationbefore", function($http, $templateCache, $UEE, $timeout, $log, $UI) {
    function link(scope, element, attrs, ctrls, linker) {
        // 选择页 = 当前页
        var choosePage = currentPage = 1;
        // 总记录数
        var totalRecord = 0;
        // 每页大小
        var pageSize = 10;
        // 注册page事件
        var jPageEvent = $.Event("page");
        
        var jBeforeEvent = $.Event("before");
        
        // clone外部指令
        linker(scope.$new(false), function(clone) {
            for (var i = 0; i < clone.length; i++) {
                if (clone[i].nodeName == "UEE:FIRE" || clone[i].nodeName === 'fire') {
                    element.append(clone[i]);
                }
            }
        });
        
        // 每页大小监听
        attrs.pagesize && scope.$watchCollection(attrs.pagesize, function(newV, oldV) {
            pageSize = newV || 10;
        });
        
        // 总记录数监听
        attrs.totalrecord && scope.$watchCollection(attrs.totalrecord, function(newV, oldV) {
            totalRecord = newV || 0;
            if (currentPage > getMaxPage()) {
                choosePage = currentPage = 1;
            }
            // 更新分页数据
            getTotalPageGroup();
        });
        
        scope.$toPage = function(value) {
            if (value == '...') return;

            element.trigger(jBeforeEvent);
            
            if ($(document).scope().needWait) {
            	var a = 30;
            	var b = window.setInterval(function() {
					a--;
					if (a < 0 || !$(document).scope().needWait) {
						clearInterval(b);
						
						choosePage = currentPage = value;
	                    triggerEvent();
					}
				}, 1000);

            } else {
            	if (!$(document).scope().notpaging) {
                	choosePage = currentPage = value;
                    triggerEvent();
                }
            }
        }

        scope.$nextPage = function($event) {        	
        	if (currentPage + 1 > getMaxPage()) return;
        	
        	element.trigger(jBeforeEvent);
            
            if ($(document).scope().needWait) {
            	var a = 30;
            	var b = window.setInterval(function() {
					a--;
					if (a < 0 || !$(document).scope().needWait) {
						clearInterval(b);
						
						if (!$(document).scope().notpaging) {
							$event.stopPropagation();
				            choosePage = ++currentPage;
				            triggerEvent();
						}
						
					}
				}, 1000);

            } else {
            	if (!$(document).scope().notpaging) {
            		$event.stopPropagation();
                    choosePage = ++currentPage;
                    triggerEvent();
                }
            }
            
        };

        scope.$prePage = function($event) {
        	if (currentPage - 1 <= 0) return;
        	
        	element.trigger(jBeforeEvent);
            
            if ($(document).scope().needWait) {
            	var a = 30;
            	var b = window.setInterval(function() {
					a--;
					if (a < 0 || !$(document).scope().needWait) {
						clearInterval(b);
						
						if (!$(document).scope().notpaging) {
							$event.stopPropagation();
				            choosePage = --currentPage;
				            triggerEvent();
						}
					}
				}, 1000);

            } else {
            	if (!$(document).scope().notpaging) {
            		$event.stopPropagation();
                    choosePage = --currentPage;
                    triggerEvent();
                }
            }
        };

        // 事件触发器
        function triggerEvent(button) {
        	jPageEvent = $.Event("page");
            jPageEvent.pagesize = pageSize;
            jPageEvent.startnum = currentPage > 1 ? (currentPage - 1) * pageSize : 0;
            // 触发分页事件
            element.trigger(jPageEvent);
            // 更新大小
            getTotalPageGroup();
        }
        // 获取最大分页数
        function getMaxPage() {
            return totalRecord != 0 ? Math.ceil(totalRecord / pageSize) : 0;
        }
        // 获取总共分页数据
        function getTotalPageGroup() {  	
            var pageData = [];
            var array = [];
            var maxpage = getMaxPage();
            if (maxpage <= 0) {
                scope.$pageData = [];
                return;
            }
            // 计算分页
            if (currentPage - 6 <= 0) {
                for (var i = 0; i < currentPage; i++) {
                    array.push(i + 1);
                }
            } else {
                array.push(1);
                array.push(2);
                array.push("...");
                for (var i = currentPage - 3; i <= currentPage; i++) {
                    array.push(i);
                }
            }

            if (currentPage + 4 >= maxpage) {
                for (var i = currentPage + 1; i <= maxpage; i++) {
                    array.push(i);
                }
            } else {
                array.push(currentPage + 1);
                array.push(currentPage + 2);
                array.push("...");
                for (var i = maxpage - 1; i <= maxpage; i++) {
                    array.push(i);
                }
            }
            // 更新对象
            angular.forEach(array, function(value) {
                pageData.push({
                    value: value,
                    selected: value == currentPage,
                    isItem: value == '...'
                });
            });

            scope.$pageData = pageData;
        }
    }

    return {
        template: '<div class="paging clearfix"> <div class="uPages"> <div class="ctrls"> <div class="prev" ng-click="$prePage($event)"></div> <div class="ctrl"> <span ng-repeat="$item in $pageData" id="page_{{$item.value}}" ng-class="{selected:$item.selected, uPage:!$item.isItem, thn:$item.isItem}" ng-bind="$item.value" ng-click="$toPage($item.value)"></span> </div> <div class="next" ng-click="$nextPage($event)"></div> </div> </div> </div>',
        restrict: 'E',
        replace: true,
        transclude: true,
        scope: true,
        compile: function(tElement, tAttr, linker) {
            return link;
        }
    };
}, true);

var frontLogUtil = {
	checkIsOpenLog: function (dictCfg) {
		debugger;
		for (var i = 0; i < dictCfg.length; i++) {
			var item = dictCfg[i];
			if (!item) {
				continue;
			}
			var extMap = item.extMap;
			if (!this.isMatchByExt(extMap)) {
				continue;
			}

            this.extMap = extMap;
			var logType = item.key.split(",")[0];
        
            if (extMap.ext5) {
                this.invokeMap = this.invokeMap || {};
                this.invokeMap[logType] = {
                    reg: new RegExp(extMap.ext5)
                };
            }
        
			if (logType == "0") {
				this.checkLogJSError();
			} else if (logType == "1") {
				this.checkLogCallStack();
			} else if (logType == "2") {
				this.checkLogRestService();
			}
		}
	},
    
    isMatchByExt: function (extMap, logType) {
    	if (!extMap) {
    		return false;
    	}

    	var servNumber = $.cookie("besServNum");
    	var matchServNumber = extMap.ext1;
    	if (matchServNumber && servNumber != matchServNumber) {
    		return false;
    	}
        this.servNumber = servNumber;
    	var menuId = $.cookie("com.huawei.boss.CURRENT_MENUID");
        //alert(menuId);
    	var matchMenu = extMap.ext2;
    	if (matchMenu && menuId != matchMenu) {
    		return false;
    	}
        this.menuId = menuId;
        return true;
    },

	checkLogJSError: function () {
        frontLogUtil.setErrorFunc();
	},

	setErrorFunc: function () {
        debugger;
        
        if (frontLogUtil.extMap.ext4 == '1') {
            $(document).scope().$applyBak = $(document).scope().$apply;
            $(document).scope().$apply = function (expr) {
                frontLogUtil.lastExpr = expr;
                var caller = this;
                var result = $(document).scope().$applyBak.apply(caller, arguments);
                return result;
            }            
        }
                
		// 基于$(document).scope().$Get('$log').error
        try {
        	var logObj = $(document).scope().$Get('$log');
        } catch (e) {}

        if (!logObj) {
        	return;
        }
        
        frontLogUtil.logObj = logObj;
        
        if (logObj.errorBak) {
            return;
        }
        
		logObj.errorBak = logObj.error;
		logObj.error = function (errorMsg, url, line) {
            if (!newErrorFunc(errorMsg, url, line) && logObj.errorBak) {
            	logObj.errorBak(errorMsg, url, line);
            }
        }
        
		function newErrorFunc(errorMsg, url, line) {
			debugger;
			var message = JSON.stringify({
					message: errorMsg.message,
                    lastFuncName: frontLogUtil.lastFuncName,
					stack: errorMsg.stack
				});
            var extMap = frontLogUtil.extMap;
            if (!extMap) {
				return false;
            }
            
            if (!frontLogUtil.checkInvokeCondition('0', message)) {
                return false;
            }
                
            var keyWords = extMap.ext3;
            if (keyWords) {
                var keyWordsReg = new RegExp(keyWords);
            }
			if (keyWordsReg && !keyWordsReg.test(message)) {
				return false;
			} 
			
            frontLogUtil.recordFrontLog('jsError', 'CatchError', message, frontLogUtil.lastExpr && frontLogUtil.lastExpr.toString());
            return true;
		}
	},
    
	recordFrontLog: function (bizCode, callMethod, req, resp) {
        debugger;
        var $scope = $(document).scope();
        var $Fire = $scope.$Get('$Fire');
 
        $Fire({
            service: '/frontlogservice/recordLog',
            params: {
            	req: {
            		bizCode: bizCode,
            		recId: this.recId++,
                    serviceNumber: $.cookie("besServNum"),
                    menuId: $.cookie("com.huawei.boss.CURRENT_MENUID"),
                    callMethod: callMethod,
                    operId: adutil.getOperId(),
            		req: req,
            		resp: resp
            	}
            },
            target: 'resp',
        }, $scope).onafter(function(resp){
		});
    },
    
	checkLogCallStack: function () {
        if (!this.extMap.ext2) {
            return;
        }
        var keyWordsReg = null;
        var keyWords = frontLogUtil.extMap.ext3;
        if (keyWords) {
            keyWordsReg = new RegExp(keyWords);
        }
        this.setNewController(keyWordsReg);
    },
    
	setNewController: function (keyWordsReg) {
        debugger;
        var $ControllerBak = window.$Controller;
		window.$Controller = function (name, controller) {
			if (arguments.length == 0) {
				return $Controller
			}
			var getter = parse(name),
			result = getter(),
			setter = getter.assign;
			if (arguments.length == 1) {
				return result
			}
			if (result && angular.isObject(controller)) {
				return angular.extend(result, controller)
			} else {
				if (angular.isObject(controller)) {
                    setMemberFunc(controller, '$Controller.' + name);
				} else if (angular.isFunction(controller)) {
                    var funcName = '$Controller.' + name;
                    
                    if (!keyWordsReg || keyWordsReg.test(funcName)) {
                    	controller = makeNewFunc(getter.last(), funcName, controller);
                    }
                }
				return setter(controller)
			}
		}

        if ($ControllerBak) {
            for (var key in $ControllerBak) {
                if ($ControllerBak.hasOwnProperty(key)) {
                    window.$Controller[key] = $ControllerBak[key];
                }
            }
        }
        
        setMemberFunc(window.$Controller, "$Controller");
        
        function setMemberFunc(obj, objName) {
            if (obj.setNewFunc) {
                return;
            }
            
            obj.setNewFunc = true;
            
        	for (var key in obj) {
        		if (!obj.hasOwnProperty(key)) {
        			continue;
        		}
                
                var member = obj[key];
                var memberName = objName + "." + key;
        		if (angular.isObject(member)) {
                    setMemberFunc(member, memberName);
        		} else if (angular.isFunction(member)) {
                    if (!keyWordsReg || keyWordsReg.test(memberName)) {
                        obj[key] = makeNewFunc(obj, memberName, member);
                    }
        		}
        	}
        }
                
        function makeNewFunc(caller, funcName, controllerFunc) {
        	return function () {
                frontLogUtil.lastFuncName = funcName;
        		try {
        			if (frontLogUtil.checkInvokeCondition('1', funcName)) {
                        frontLogUtil.recordFrontLog('callStack', funcName);
        			}
        			var result = controllerFunc.apply(caller, arguments);
        			return result;
        		} catch (e) {
                    frontLogUtil.logObj.error(e);
                }
        	}
        }
        
		function setNewFunc(name, controller, key, funcName) {
            controller[key] = makeNewFunc(controller, funcName, controller[key]);
		}

		function parse(name) {
            debugger;
			var result = $Controller,
			last = result;
			var keys = name.split("."),
			key;
			for (var i = 0, len = keys.length; i < len; ) {
				key = keys[i++];
				if (result) {
					result = (last = result)[key]
				}
				if (!result && i < len) {
					result = last[key] = {}
				}
			}
			function getter() {
				return result
			}
			getter.assign = function (object) {
				return last[key] = object
			};
			getter.last = function (object) {
				return last;
			};
			return getter
		}
	},
    
    checkLogRestService: function () {
        	debugger;
        if (!this.extMap.ext2) {
            return;
        }
        
        var keyWordsReg = null;
        var keyWords = frontLogUtil.extMap.ext3;
        if (keyWords) {
            keyWordsReg = new RegExp(keyWords);
        }
        
        var delNullKeyReg1 = /,\\?"[a-zA-Z0-9_]*\\?":null/g;
        var delNullKeyReg2 = /\\?"[a-zA-Z0-9_]*\\?":null,/g;
        
        var respProcess = frontLogUtil.extMap.ext4;
        
        var getRestService = function (url) {
        	var path = url;
        	try {
        		var lastIndex1 = url.lastIndexOf("u-route");
        		if (lastIndex1 != -1) {
        			var lastIndex2 = url.lastIndexOf("?");
        			if (lastIndex2 == -1) {
        				lastIndex2 = url.length;
        			}
        			lastIndex1 += "u-route".length;
        			path = url.substr(lastIndex1, lastIndex2 - lastIndex1);
        		}

        	} catch (e) {}
        	return path;
        }
        
        var globalAfterForFrontLogRest = function (data, status, headers, config) {
        	debugger;

        	var rest = getRestService(config.url);
            if (rest.indexOf("frontlogservice/recordLog") > -1) {
                return;
            }
            
            if (!frontLogUtil.checkInvokeCondition('2', rest)) {
                return;
            }
            
            if (keyWordsReg && !keyWordsReg.test(rest)) {
                return;
            }
            
        	var req = config.data && config.data.params || '';
        	var reqData = JSON.stringify(req);
            
            if (status != 200) {
                var respData = status + ";" + data;
            } else {
                var respData = data;
                // 0 删除null的key
                if (respProcess == 0) {
                    respData = respData.replace(delNullKeyReg1, "");
                    respData = respData.replace(delNullKeyReg2, "");
                }
            }
            
            frontLogUtil.recordFrontLog('rest', rest, reqData, respData);
        };
        
        adutil.addFireGlobalAfterFunc('frontLogRest', globalAfterForFrontLogRest);
    },
    
    checkInvokeCondition: function (type, checkPara) {
        var invokeMap = this.invokeMap;
        if (!invokeMap || !invokeMap[type] || !invokeMap[type].reg || invokeMap[type].match) {
        	return true;
        }
        var match = invokeMap[type].reg.test(checkPara);
        if (!match) {
            return false;
        }
        
        invokeMap[type].match = true;
        return true;
    },
    
    recId: 1
};

var timeChangeUtil = {
    addMonths: function(date, months) {
        if (typeof months != "number") {
            months = parseInt(months);            
        }
        
        var newDate = new Date(date);
        
        var month = newDate.getMonth();        
        var year = newDate.getYear();
        if (year < 1900) {
            year = year + 1900;
        }
        
        var newMonth = month + months;
        newDate.setMonth(Math.floor(newMonth % 12));
        newDate.setYear(year + Math.floor(newMonth / 12));
        
        return newDate;
    },
    
    addDaysForTs: function(date, days) {
        if (typeof days != "number") {
            days = parseInt(days);            
        }
        
        return date + days * 24 * 3600 * 1000;
    },
    
    isSameDay: function(date1, date2) {
        date1 = new Date(date1);
        date2 = new Date(date2);
        
        return (date1.getYear() == date2.getYear())
            && (date1.getMonth() == date2.getMonth())
            && (date1.getDay() == date2.getDay());
    }
};

function imgFileToBase64(filePath) {
    if (!$Page.base64UseActiveX) {
        return null;
    }
    
    var base64Str = null;
    var objStream = null;
    var objXMLDoc = null;
    try {
        var fs = new ActiveXObject("Scripting.FileSystemObject");
        if (!fs.FileExists(filePath)) {
            return base64Str;
        }
    
    	objStream = new ActiveXObject("ADODB.Stream");
    	objStream.Type = 1;
    	objStream.Open;
    	objStream.LoadFromFile(filePath);

    	objXMLDoc = new ActiveXObject("msxml2.FreeThreadedDOMDocument");
    	objXMLDoc.loadXML("<?xml version='1.0'?><Base64Data/>");
    	objXMLDoc.documentElement.dataType = "bin.base64";
    	objXMLDoc.documentElement.nodeTypedValue = objStream.Read();
                
    	if (objXMLDoc.readyState > 2) {
    		var root = objXMLDoc.getElementsByTagName("Base64Data");
    		base64Str = root[0].firstChild.nodeValue;
    	}
    
        if (base64Str && base64Str.indexOf("\n") > -1) {
            base64Str = base64Str.replace(/\n/g, "");
        }
    } catch (e) {
    } finally {
        try {
        	if (objStream) {
        		objStream.Close();
        	}            
            objStream = null;
            objXMLDoc = null;
        } catch (e) {}
    }
    
	return base64Str;
}
