$Controller(
	"bes.oc.appointmentinfo", {
		/**
		 * 预约信息弹窗初始化
		 */
		init : function($Gadget){
			debugger;
			$Gadget.qryAppointInfoCond = 0;
			$Gadget.appointQryCondValue = null;
			$Gadget.appointmentInfo = null;
			$Gadget.selectedAppointmentInfo = null;
			$Gadget.selectAppointmentIndex = null;
			
			$Gadget.appointInfoCondList = [{"value":$UEE.i18n("ad.marketplan.label.reservationsequencenumber"),"key":"0"},
			   						    {"value":$UEE.i18n("AD.FAMILY.LABEL.USERNUM"),"key":"1"}];
			
			//查询业务类型数据字典
			$Fire({
	            service : '/common/dictkey',
	            params : {
	                "dictkeylist" : ['OC.BUSINESS.CODE']
	            },
	            target : '$Gadget.businessCodeList',
	            onafter : function() {
	                debugger;
	            }
	        }, $Gadget);
		},
		isShowAppointmentBtn : function($Gadget, $Fire){
			debugger;
			$Fire({
			     service : 'ucec/v1/common/qrysystemparambykey',
			     params : {
			    	 key : "OC_SHOW_APPOINTMENT_INFO_BTN"
			     },
			     target : "$Gadget.ishowAppointmentBtn",
			     onafter : function() {
			    	 debugger;
			     }
			 }, $Gadget);
		},
	    showAppointmentInfo : function($Page, $Gadget, $Fire, $UI) {
	    	debugger;
			//1，查询操作员令牌，有权限则弹出预约信息查询选择界面。
	    	$Fire({
				service : "/authrightserviceboservice/hasright",
				params : {
				    authid : "60131001699",
				},
				target : "$Gadget.appointmentRight",
				onafter : function() {
					debugger;
					//$Gadget.appointmentRight = true;
					if($Gadget.appointmentRight){
						$Fire({
							"popup" : {
								'id' : 'appointmentInfoPop',
								'title' : $UEE.i18n("ad.person.title.appointmentinfo"),
								'width' : '800px',
								'height' : '480px',
								'src' : 'resource.root/bes/ad/ctz/gadget/bes-oc-productorder/bes-ad-ctz-appointmentinfo-pop.html',
								resizable : false
							}
					    }, $Gadget);
					}else{
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.marketplan.label.reservationnopermission"));
					}
				}
			}, $Gadget);
	    	
	    },
	    
	    //查询预约信息，
	    queryAppointmentInfo : function($Gadget, $Fire, $UI) {
	    	debugger;
			//弹出预约信息查询界面,点击查询按钮查询用户预约信息
	    	if(!$Gadget.appointQryCondValue || $Gadget.appointQryCondValue == ""){
	    		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.title.seqnumorservnumisnull"));
	    		return;
	    	}
	    	
	    	if($Gadget.qryAppointInfoCond == "1" && !OC.Comm.isMobile($Gadget.appointQryCondValue)){
	    		$UI.msgbox.info($UEE.i18n("ad.marketplan.message.tips"),$UEE.i18n("ad.marketplan.message.servnummustbemobilenum"));
				return false;
	    	}
	    	
	    	$Fire({
				service : "/ucec/v1/ctz/terminalappointment/queryAppointmentInfo",
				params : {
					header: {},
					body: {
						servNumber: $Gadget.qryAppointInfoCond == 1 ? $Gadget.appointQryCondValue : null,
						preContractSeq: $Gadget.qryAppointInfoCond == 0 ? $Gadget.appointQryCondValue : null,
					    custName: $Gadget.appointQryCondCustName
					}
				},
				target : "$Gadget.appointmentInfo",
				onafter : function() {
					debugger;
					
					//*****************************
			    	/*var precontractExtPropInfoList = [];
			    	precontractExtPropInfoList.push({"propCode":"","propName":"终端类型","propValue":"华为"});
			    	precontractExtPropInfoList.push({"propCode":"RESTYPE","propName":"资源编码","propValue":"10086"});
			    	precontractExtPropInfoList.push({"propCode":"RESTYPENAME","propName":"终端名称","propValue":"华为G7"});
			    	precontractExtPropInfoList.push({"propCode":"","propName":"终端颜色","propValue":"Red"});
			    	precontractExtPropInfoList.push({"propCode":"","propName":"终端数量","propValue":"2"});
			    	
			    	$Gadget.appointmentInfo= [];
			    	$Gadget.appointmentInfo.push({"businessCode":"GroupInstall","createTime":"2015-09-09",
			    		"beId":"18","preContractSeq":"100","source":"网厅","modifyTime":"2015-09-09","status":"1","valiDay":"3","servNum":"18888888888","precontractExtPropInfoList":precontractExtPropInfoList});
			    	$Gadget.appointmentInfo.push({"businessCode":"GroupInstall","createTime":"2015-09-09",
			    		"beId":"18","preContractSeq":"100","source":"网厅","modifyTime":"2015-09-09","status":"1","valiDay":"3","servNum":"18888888888","precontractExtPropInfoList":precontractExtPropInfoList});
			    	$Gadget.appointmentInfo.push({"businessCode":"DropSubs","createTime":"2015-09-09",
			    		"beId":"18","preContractSeq":"100","source":"网厅","modifyTime":"2015-09-09","status":"1","valiDay":"3","servNum":"18888888888","precontractExtPropInfoList":precontractExtPropInfoList});
			    	$Gadget.appointmentInfo.push({"businessCode":"DropSubs","createTime":"2015-09-09",
			    		"beId":"18","preContractSeq":"100","source":"网厅","modifyTime":"2015-09-09","status":"1","valiDay":"3","servNum":"18888888888","precontractExtPropInfoList":precontractExtPropInfoList});
			    	$Gadget.appointmentInfo.push({"businessCode":"CreateSubscriber","createTime":"2015-09-09",
			    		"beId":"18","preContractSeq":"100","source":"网厅","modifyTime":"2015-09-09","status":"1","valiDay":"3","servNum":"18888888888","precontractExtPropInfoList":precontractExtPropInfoList});
			    	$Gadget.appointmentInfo.push({"businessCode":"CreateSubscriber","createTime":"2015-09-09",
			    		"beId":"18","preContractSeq":"100","source":"网厅","modifyTime":"2015-09-09","status":"1","valiDay":"3","servNum":"18888888888","precontractExtPropInfoList":precontractExtPropInfoList});*/
			    	//*****************************
					
					if($Gadget.appointmentInfo){
						for(var i = 0; i < $Gadget.appointmentInfo.length; i++){
							
							//格式化展示时间
							$Gadget.appointmentInfo[i].createTime = $(document).scope().$Get('$filter')('tz')($Gadget.appointmentInfo[i].createTime, $Page.tzDate);
							$Gadget.appointmentInfo[i].modifyTime = $(document).scope().$Get('$filter')('tz')($Gadget.appointmentInfo[i].modifyTime, $Page.tzDate);
							
							//处理地区展示,$Gadget.data.roamRegionData为gadget初始化时查询出来的区域列表
							if($Gadget.appointmentInfo[i].beId && $Gadget.data.roamRegionData && $Gadget.data.roamRegionData.allRoamRegion){
								for(var j = 0; j < $Gadget.data.roamRegionData.allRoamRegion.length; j++){
									if($Gadget.data.roamRegionData.allRoamRegion[j].beId == $Gadget.appointmentInfo[i].beId){
										$Gadget.appointmentInfo[i].beId = $Gadget.data.roamRegionData.allRoamRegion[j].regionName;
										break;
									}
								}
							}
							
							//处理业务名称展示
							if($Gadget.appointmentInfo[i].businessCode && $Gadget.businessCodeList && $Gadget.businessCodeList["OC.BUSINESS.CODE"]){
								var businessTypeList = $Gadget.businessCodeList["OC.BUSINESS.CODE"];
								for(var j = 0; j < businessTypeList.length; j++){
									if(businessTypeList[j].itemCode == $Gadget.appointmentInfo[i].businessCode){
										$Gadget.appointmentInfo[i].businessCode = businessTypeList[j].itemName;
										break;
									}
								}
							}
							
							//处理状态展示
							var statuList = [{"key":"0","value":"未使用"},{"key":"1","value":"已使用"},{"key":"2","value":"已过期"}];
							if($Gadget.appointmentInfo[i].status){
								for(var j = 0; j < statuList.length; j++){
									if(statuList[j].key == $Gadget.appointmentInfo[i].status){
										$Gadget.appointmentInfo[i].status = statuList[j].value;
										break;
									}
								}
							}
						}
					}
					
				}
			}, $Gadget);
	    	
	    },
	    
	    showDetailInfo : function($Gadget,$Item,$Fire){
	    	debugger;
	    	$Gadget.selectedItem = $Item;
	    	$Fire({
				"popup" : {
					'id' : 'appointmentDetailInfoPop',
					'title' : $UEE.i18n("ad.person.label.DETAIL"),
					'width' : '800px',
					'height' : '400px',
					'src' : 'resource.root/bes/ad/ctz/gadget/bes-oc-productorder/bes-ad-ctz-appointmentdetail-pop.html',
					resizable : false
				}
		    }, $Gadget);
	    },
	    
	    confirm : function($Gadget,$Fire,$UI){
	    	debugger;
	    	if(!$Gadget.selectedAppointmentInfo){
	    		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.title.selectarecord"));
	    		return;
	    	}
	    	
	    	var propList = $Gadget.selectedAppointmentInfo.precontractExtPropInfoList || [];
	    	for(var i = 0; i < propList.length; i++){
	    		if(propList[i].propCode == "CUSTOMERNAME"){
	    			$Gadget.selectedAppointmentInfo.customerName = propList[i].propValue;
	    		}
	    		if(propList[i].propCode == "RESTYPENAME"){
	    			$Gadget.selectedAppointmentInfo.resTypeName = propList[i].propValue;
	    		}
	    		if(propList[i].propCode == "RESTYPE"){
	    			$Gadget.selectedAppointmentInfo.resType = propList[i].propValue;
	    		}
	    		if(propList[i].propCode == "RESColor"){
	    			$Gadget.selectedAppointmentInfo.resColor = propList[i].propValue;
	    		}
	    		if(propList[i].propCode == "RESNum"){
	    			$Gadget.selectedAppointmentInfo.resNum = propList[i].propValue;
	    		}
	    	}
	    	
	    	$Gadget.keyWord = $Gadget.selectedAppointmentInfo.resTypeName;
    		$Controller.bes.oc.productorder.clickSearch($Gadget,$Fire);
    		
	    	/*$Gadget.offerCondition = $Gadget.selectedAppointmentInfo.resType;
	    	if($Gadget.offerCondition && $Gadget.offerCondition != ""){
	    		$Controller.bes.oc.productorder.queryOfferByIMEI($Fire, $Gadget, $UI);
	    	}else{
	    		$Gadget.keyWord = $Gadget.selectedAppointmentInfo.resTypeName;
	    		$Controller.bes.oc.productorder.clickSearch($Gadget,$Fire);
	    	}*/
	    	//$(".grid_content .radio").removeClass("checked");
	    	$Fire({popin : ""});
	    }
	});