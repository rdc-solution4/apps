
 function authCheck(serverNum,recType,groupId)
 {
      var goldAuthData = getAuthChkResult(serverNum, recType, groupId);
      return goldAuthData.authChkResult;
 }
 
 function goldAuthCheck(serverNum,recType,groupId)
 {

      var goldAuthData = getAuthChkResult(serverNum, recType, groupId);
      return goldAuthData;    
 }
 
 function getAuthChkResult(serverNum, recType, groupId)
 {
         var goldAuthData = new Object;
         goldAuthData.authChkResult = false;
         goldAuthData.goldOid = "";

         if(!serverNum)
	     {
	         serverNum = "";
	     }
	     if(!recType)
	     {
	         recType = "";
	     }
	     if(!groupId)
	     {
	         groupId = "";
	     }
	     
	     var loginFrameType = "";
         if (_ysp_top && _ysp_top.publicObject && _ysp_top.publicObject["loginFrameType"])
         {
              loginFrameType = _ysp_top.publicObject["loginFrameType"];
         }
        
        var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/ifNeedCashboxAuthNew.action?goldStoreModeBean.recType="+recType+"&goldStoreModeBean.servnum="+serverNum +"&goldStoreModeBean.groupId="+groupId + "&goldStoreModeBean.loginFrameType=" + loginFrameType + "&ngcrm_reserved1=1";
        var info = execService(url,"");
        var authReturn = info.split("@_@");
        if(authReturn[0] == "success")
        {
             goldAuthData.authChkResult = true;
             if (authReturn.length > 2)
             {
                 goldAuthData.goldOid = authReturn[2];
             }
        }
        else if (authReturn[0] == "noPass")
        {
             alert(authReturn[1]);
        }
        else if (authReturn[0] == "haveNew")
        {
               var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/showGoldAuth.action?ngcrm_reserved1=1&ngcrm_rnd=" + Math.random();
	           var style = "dialogWidth:600px;dialogHeight:500px;center:yes;status:no;edge:sunken;help:no;status:no;menubar=no;scroll:no";
			   var rtn = window.showModalDialog(url, "", style);
			   var rtns = rtn.split(";");
			   if("success" == rtns[0])
			   {
			       goldAuthData.authChkResult = true;
		           if (rtns.length > 1)
		           {
		                goldAuthData.goldOid = rtns[1];
		           }
			   }
        }
        else if (authReturn[0] == "haveNewCQ")
        {
               var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/showGoldAuthCQ.action?ngcrm_reserved1=1&ngcrm_rnd=" + Math.random();
               var iWidth=700; 
               var iHeight=450;
               var iTop= (window.screen.height-iHeight-100)/2;
               var iLeft= (window.screen.width-iWidth)/2;
	           var style = "dialogHeight:"+iHeight+"px;dialogWidth:"+iWidth+"px; toolbar:no; menubar:no;titlebar:no;scrollbars:yes; resizable:no;location:no;status:no;left:"+iLeft+"px;_ysp_top:"+iTop+"px;"
			   var rtn = window.showModalDialog(url, "", style);
			   var code = "-1";
			   var formnumber = "";
			   var goldToken = "";
			   if (!rtn)
			   {
			       code = "-1";
			   }
			   else
			   {
			          var rtns = rtn.split("#");
					  code = rtns[0];
					  formnumber = rtns[1];
					  
					  if (rtns.length > 2)
					  {
					      goldToken = rtns[2];
					  }
			   }
			   
			   url = obtainWebContextPath("ngcustcare")+"/custsvc/common/logRecAuthInfoByCQ.action?goldStoreModeBean.authResult="+code+"&goldStoreModeBean.appFormNum="+formnumber;
               var goldOid = execService(url,"");
               
			   if (code == "1" || code == "2" || code == "5")
			   {
			   		//modify begin wWX301390 2015-10-16 R005C10LG1003 OR_JS_201509_405
			   		url = obtainWebContextPath("ngcustcare")+"/custsvc/common/jsGoldTokenCheck.action?goldAuthSN="+formnumber+"&goldAuthToken="+goldToken;
               		var jsons = eval( " ( " + execService(url) + " ) ");
			        if(jsons)
			        {
			        	if(jsons.result == "1")
			        	{
				        	//result:1,valid success
				        	goldAuthData.authChkResult = true;
				        	goldAuthData.goldOid = goldOid;
				        	setGoldAuthVal("goldAuthSN", formnumber)
				        	setGoldAuthVal("goldAuthToken", goldToken);
			        	}
				        else
				        {
				        	//result:0,valid failed
				        	alert(jsons.msg);
				        }
			        }
			        //modify end wWX301390 2015-10-16 R005C10LG1003 OR_JS_201509_405
			   }
        }
        else if(authReturn[0] == "haveAccountList")
        {
               var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/showAccountList.action?ngcrm_reserved1=1&ngcrm_rnd=" + Math.random();
	           var style = "dialogWidth:400px;dialogHeight:120px;center:yes;status:no;edge:sunken;help:no;status:no;menubar=no;scroll:no";
			   var rtn = window.showModalDialog(url, "", style);
			   var rtns = rtn.split(";");
			   if("success" == rtns[0])
			   {
			       goldAuthData.authChkResult = true;
			       if (rtns.length > 1)
			       {
			            goldAuthData.goldOid = rtns[1];
			       }
			   }
			   else if("next" == rtns[0])
			   {
			           var nexturl = obtainWebContextPath("ngcustcare")+"/custsvc/common/showGoldAuth.action?ngcrm_reserved1=1&ngcrm_rnd=" + Math.random();
			           var nextstyle = "dialogWidth:600px;dialogHeight:500px;center:yes;status:no;edge:sunken;help:no;status:no;menubar=no;scroll:no";
					   var nextrtn = window.showModalDialog(nexturl, "", nextstyle);
					   var nextrtns = nextrtn.split(";");
					   if("success" == nextrtns[0])
					   {
					       goldAuthData.authChkResult = true;
					       if (nextrtns.length > 1)
					       {
					            goldAuthData.goldOid = nextrtns[1];
					       }
					   }
			   }
        }
        else 
        {
             alert(authReturn[1]);
        }
        return goldAuthData;
 }
 
 function authCheckVoucher(recType) 
 {
        var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/voucherAuthInit.action?voucherAuthBean.recType=" + recType + "&ngcrm_reserved1=1";
        var info = execService(url,"");
        var authReturn = info.split("@_@");
        if(authReturn[0] == "success")
        {
             return "";
        }
        else if (authReturn[0] == "showVoucher")
        {
               var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/showVoucher.action?ngcrm_reserved1=1&ngcrm_rnd=" + Math.random();
	           var style = "dialogWidth:800px;dialogHeight:400px;center:yes;status:no;edge:sunken;help:no;status:no;menubar=no;";
			   var rtn = window.showModalDialog(url, "", style);
			   if (rtn)
			   {
			        return rtn;
			   }
			   else
			   {
			        return "";
			   }
        }
        else 
        {
             alert(authReturn[1]);
             return "";
        }
 }
 
 function isVoucherInput(recType) 
 {
        var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/voucherAuthInput.action?voucherAuthBean.recType=" + recType + "&ngcrm_reserved1=1";
        var info = execService(url,"");
        var authReturn = info.split("@_@");
        if(authReturn[0] == "success")
        {
             if(authReturn[1] == "1")
             {
                  return true;
             }
             else
             {
                  return false;
             }
        }
        else 
        {
             alert(authReturn[1]);
             return false;
        }
 }
 
 function setGoldAuthVal(name, val)
 {
      var authObj = document.getElementById(name);
      if (authObj)
      {
          authObj.value = val;
      }
      else
      {
          authObj = document.createElement("input"); 
		  authObj.setAttribute("type","hidden"); 
		  authObj.setAttribute("id", name); 
		  authObj.setAttribute("name", name); 
		  authObj.setAttribute("value", val); 
		  
		  if (document.forms[0])
		  {
		       document.forms[0].appendChild(authObj);
		  }
		  else
		  {
		      document.appendChild(authObj);
		  }
      }
 }
 
