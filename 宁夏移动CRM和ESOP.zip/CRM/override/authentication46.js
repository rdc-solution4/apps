"use strict";
var dropList1 = null;

var dropList2 = null;

//var checkBtn1 = null;

$Controller(
    "oc.authentication", {
        /**
         * 初始化页面数据.
         */
        init: function($Gadget, $Fire) {
            debugger;
            //清空店长鉴权
            $Gadget.authManager=null;
            if ($Gadget.$Page.isCsp) {
                //$Page.isCsp = $Controller.bes.ad.csp.common.isCsp();
            	_ysp_top.msgConfirm = $Gadget.$UI.msgbox.confirm;
            	_ysp_top.msgInfo = $Gadget.$UI.msgbox.info;
                Showbo = {
                	Msg: {}
                };
                Showbo.Msg.alert = $Gadget.$UI.msgbox.info;
            }
            
			//$Controller.oc.authentication.qryModifyInfoAuthCheckZ($Gadget, $Fire);
            $UEE.$Fire.onerrors[500] = function(data, fire, scope) {
//                debugger;
                $Gadget.$Get('$UI').msgbox.error('错误', data.message);
            }

            try {
                var params = $(document).scope().$Params || {};
                var $Page = $(document).scope().$Page;
                var trace = $Page.smTrace || {};
                if (params.traceId && params.traceId != "undefined") {
                    $Page.traceId = params.traceId;
                    $Page.traceFlag = params.traceFlag;
                    $Page.traceId = trace.traceId;
                    $Page.traceFlag = trace.traceFlag;
                } else {
                    $Page.traceId = trace.traceId;
                    $Page.traceFlag = trace.traceFlag;
                }
            } catch (e) {
//                debugger;
            }

            window._ysp_top.readCardStatus = "N";
            $Gadget.isIdCardAuthCheckAllowInput = "Y";
            $Gadget.authTypeBack = null;
            //获取店长鉴权特性参数
            $Gadget.recType = adutil.getQueryStringByName("recType");
            $Controller.oc.authentication.getCardGoldAuth($Gadget, $Fire);
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
//                debugger;
            }
            //默认按钮不换行
            $Gadget.buttonWrap = "false";
            
            try {
                if (_ysp_top.TabSet && _ysp_top.TabSet.portalName) {
                    //判断当前处于我的工作台
                    var loginValue = false;
                    $.each(_ysp_top.$(".wb_title") || [], function(i, val) {
                        //TODO：需要使用登录弹窗的国际化key值取用
                        if (val.innerText == $UEE.i18n("ad.authentication.message.custlogin") /*客户登录*/ ) {
                            loginValue = true;
                            return false;
                        }
                    });

                    if (_ysp_top.window.$BES.$Portal.tabpanel.getTabItem().key == "6010100090012" && !loginValue) {
                        $Gadget.buttonWrap = "true";
                    }
                    $Gadget.besMenuId = _ysp_top.window.$BES.$Portal.tabpanel.getTabItem().key;

                }
            } catch (e) {}
            
            $Gadget.besMenuId = $Gadget.besMenuId || '';
            $Gadget.logincertIdForQuery = $Gadget.logincertIdForQuery || '';
            
            if ($Gadget.$Attrs.servicenumber) {
                $Gadget.initServicenumber = $Gadget.$Attrs.servicenumber;
            	$("#serviceNumber" + $Gadget.besMenuId).val($Gadget.$Attrs.servicenumber);
            } else if (_ysp_top.serviceNumber) {
            	$("#serviceNumber" + $Gadget.besMenuId).val(_ysp_top.serviceNumber);
                $Gadget.initServicenumber = _ysp_top.serviceNumber;
            }

            // 获取系统参数，列表方式一次获取，避免多次请求
            var keylist = ["OM_ENABLE_AUTO_PWD_VALID", "OM_HIDDEN_READ_PWD_BUTTON", "OM_FIRST_CERT_OK_PROMPT", "MailboxCheck", "ForbidInputIDCard","OC_READBUTTON_HIDE","60101047"];
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
//                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparamlistbykey',
                params: {
                    keylist: keylist
                },
                target: "$Gadget.systemParamList",
                onafter: function($Gadget) {
                    debugger;
					//短信验证码发送等待时间
					$Gadget.waitingTime = parseInt($Gadget.systemParamList[6]);
					$Page.hideReadButton = $Gadget.systemParamList[5];
                    //操作员令牌信息(手动录入身份证的令牌)
                    $Gadget.forbidInputIDCard = $Gadget.systemParamList[4];
                    //                        if(!$Gadget.forbidInputIDCard){
                    //                            $Gadget.forbidInputIDCard = "IdCardAuthCheckAllowInput";
                    //                        }
                    $Gadget.operAuth = {};
                    $Gadget.operAuth[$Gadget.forbidInputIDCard] = "Y"; //是否具有输入身份证号的令牌

                    if ($Gadget.forbidInputIDCard == "IdCardAuthCheckAllowInput") {
                        $Fire({
                            'service': 'ocauthenticationboservice/checkauthbyloginidauth',
                            'target': '$Gadget.authInfos',
                            'params': {
                                "req": $Gadget.forbidInputIDCard
                            },
                            onafter: function($Gadget) {
                                debugger;
                                if ($Gadget.authInfos) {
                                    var auths = [];
                                    auths = $Gadget.authInfos.split(","); //字符分割
                                    for (var i = 0; i < auths.length; i++) {
                                        var auth = auths[i];
                                        var authID = auth.split("^")[0];
                                        var isExist = auth.split("^")[1];
                                        $Gadget.operAuth[authID] = isExist;
                                    }

                                    $Gadget.isIdCardAuthCheckAllowInput = $Gadget.operAuth[$Gadget.forbidInputIDCard];
                                }
                            }
                        }, $Gadget);
                    }

                    $Gadget.$safeApply($Gadget, function() {
                        $Gadget.isAuthDoLogin = $Gadget.systemParamList[0];
                        $Gadget.isHiddenReadPwd = $Gadget.systemParamList[1];
                        $Gadget.isCretOKPrompt = $Gadget.systemParamList[2];
                        $Gadget.ProvincialPoint = $Gadget.systemParamList[3];
                        if ($Gadget.ProvincialPoint == "N") {
                            $Gadget.phoneoremail = "手机号";
                        } else {
                            $Gadget.phoneoremail = "手机号/邮箱";
                        }
                    });
                }
            }, $Gadget);

            //                $Fire({
            //                    service : 'ucec/v1/common/qrysystemparambykey',
            //                    params : {
            //                        key : "OM_FORBID_KEYBOARD_PWD"
            //                    },
            //                    target : "$Gadget.isKeyboardPwd",
            //                    onafter : function($Gadget) {
            //                        debugger;
            //                    }
            //                }, $Gadget);

            //默认免填单不展示上传的图片，by bWX239558
            window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};
            window._ysp_top.EinvoiceIdCardInfo.showuploadservcard = false;
            window._ysp_top.EinvoiceIdCardInfo.showuploaddelegcard = false;
        },
        // 判断OC集成到的源系统，如果是iCRM系统则跳到OC鉴权页面；否则先判断是否用户已登陆，已登陆则直接在新系统中打开OC目标菜单，否则跳到OC鉴权页面。
        /*
         * checkLoged : function($Fire, $scope, $UI, data) { // 判断OC集成到的源系统
         * if ("iCRM" == adutil.getQueryStringByName("actionSource")) { //
         * 如果是iCRM系统则跳到OC鉴权页面
         * $Controller.oc.authentication.checkLoginUserInfo(); } else {
         *
         * var loged = false; // 调后台服务判断用户是否已经登陆 $Fire({ service :
         * 'bes.oc.XXXCheckLoged/XXXCheckLoged', params : { "xxx" :
         * xxx, "xxx" : "E", "xxx" : xxx }, target : loged, onafter :
         * function() { debugger; if (loged) {
         * this.$Emit('$bes.oc.openMenuInSM', {}); } else {
         * $Controller.oc.authentication .checkLoginUserInfo(); } } },
         * $scope); } },
         */
        // 根据url参数回填鉴权用户证件id和密码信息
        getAuthInfo: function($Gadget) {
            debugger;
            var certID = adutil.getQueryStringByName("certID") || "";
            var pswd = adutil.getQueryStringByName("pswd") || "";
            $Gadget.authInfo = certID + "|" + pswd;
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
//                debugger;
            }
        },
        // 根据url参数回填鉴权用户信息
        checkLoginUserInfo: function($Gadget) {
            // $(".bes-oc-authentication .changePayment_login").show();
            debugger;
            var authCheckType = adutil
                .getQueryStringByName("authCheckType");
            var certID = $Gadget.certype.cardId; //adutil.getQueryStringByName("certID");
            var certType = adutil.getQueryStringByName("certType");
            var pswd = $Gadget.certype.pswd; //adutil.getQueryStringByName("pswd");
            var rndPswd = adutil.getQueryStringByName("rndPswd");
            var servNumber = adutil.getQueryStringByName("servNumber");

            // TODO 枚举值要保持一致
            if (authCheckType && "" !== authCheckType) {
                dropList1.selectItem(authCheckType);
            }

            if (pswd && "" !== pswd) {
                $("#password").val(pswd);
            } else if (rndPswd && "" !== rndPswd) {
                $("#password").val(rndPswd);
            }

            if (certType && "" !== certType) {
                dropList2.selectItem(certType);
            }

            $("#cardId").val(certID);

            if (servNumber !== null && "" !== servNumber) {
                $("#serviceNumber" + $Gadget.besMenuId).val(servNumber);
            }

            if (servNumber) {
                $("#serviceNumber" + $Gadget.besMenuId).attr("readonly", "readonly");
            }
        },
        // US-20160411093216-2030866038 提取工单资料
    	queryOrderInfo : function($Gadget, $Page, $Fire, $UI) {
    		debugger;
    		if(!$Page.workOrderFormNum || !$Page.hasClickFlag){
    			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "未读取到工单流水号，请先点击生成下发工单按钮，生成工单流水号。");
    			return;
    		}
    		$Fire({
    			service:'bes.oc.occustomerservice/queryorderinfo',
    			params:{
    				realnameId: $Page.workOrderFormNum
    			},
    			target: '$Gadget.respDate',
    			onafter: function() {
    				if(($Gadget.respDate || {}).retCode == "0"){
    					// RealNameStatus状态 1：新建（未反馈）、2：已反馈、3：已使用 4:过期不能使用（不入库状态）
    					if(($Gadget.respDate || {}).realNameStatus == "1"){
    						// $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RealNameInfoNotReturned"));
    						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "实名制信息未反馈。");
    						return;
    					}
    					if(($Gadget.respDate || {}).realNameStatus == "3"){
    						// $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RealNameInfoBeenUsed"));
    						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "实名制信息已经被使用，请重新操作。");
    						$Page.workOrderFormNum = null;
    						$Page.hasClickFlag = false;
    						return;
    					}
    					if(($Gadget.respDate || {}).realNameStatus == "4"){
    						// $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RealNameInfoExpired"));
    						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "实名制信息过期不能使用，请重新操作。");
    						$Page.workOrderFormNum = null;
    						$Page.hasClickFlag = false;
    						return;
    					}
    					if(($Gadget.respDate || {}).realNameStatus == "2"){
    						//2016-10-11 将此标志提前，防止有js报错，导致后面此标志为设值，开户后成为未实名制登记的。
    						$Page.hasGetInfo = true;
    						// 获取客户信息
    						$Page.custInfo = ($Gadget.respDate || {}).groupAppRealNameFeedbackDetailViewVO;
    						
    						//$Gadget.userInfoData.reserverCertTypeValue = $Page.custInfo.custCertType;
    						$("#cardId").val($Page.custInfo.custCertNo);
    						// $Page.workOrderFormNum = null;
    					}
    				}
    				else if(($Gadget.respDate || {}).retCode == "1"){
    					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), ($Gadget.respDate || {}).retMessage);
    					return;
    				}
    			}
    		}, $Gadget);
    	},
     //生成下发工单
    	generateOrder : function($Gadget, $Page, $Fire, $UI) {
    		debugger;
    		// 防止重复点击
    		if($Page.workOrderFormNum && $Page.hasClickFlag){
    			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "已经生成工单流水号，不允许重复点击。");
    			return;
    		}
    		// busiType业务类型: 1、表示开户，2、表示信息补录'
    			$Fire({
    			service:'bes.oc.occustomerservice/generateorder',
    			params:{
    				busiType: "1",
    				msisdn: "",
    				custCertType: $Gadget.drop2
    			},
    			target: '$Gadget.resp',
    			onafter: function() {
    				debugger;
    				if(($Gadget.resp || {}).retCode == "0"){
    					$Page.workOrderFormNum = $Gadget.resp.realnameId;
    					$Page.hasClickFlag = true;
    					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "生成下发工单成功。");
    					//提取工单资料标示
    					$Page.hasGetInfo = false;
    					$("#cardId").val("");
    				}
    				else if(($Gadget.resp || {}).retCode == "1"){
    					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), ($Gadget.resp || {}).retMessage);
    					return;
    				}
    			}
    			
    		}, $Gadget);
    	},
        afterSmAuth: function($Gadget, $Fire) {
            debugger;
            $Gadget.isWithoutPwd = $Gadget.certype.isWithoutPwd || [];

            $Gadget.businessCode = adutil.getParam("businessCode");

            var doAfterInitAuth = function () {
                if (!$Gadget.businessCode || $Gadget.businessCode == "null") {
                    $Controller.oc.authentication.afterInitAuth($Gadget, $Fire);
                } else {
                    var req = {
                        busiType: $Gadget.businessCode
                    };

                    $Fire({
                        service: 'bes.oc.ocauthenticationservice/queryverifytype',
                        params: {
                            "req": req
                        },
                        target: "$Gadget.smauthlist",
                        onafter: function() {
                            debugger;
                            $Controller.oc.authentication.afterInitAuth($Gadget, $Fire);
                        }
                    }, $Gadget);
                }
            }
            
            $Controller.oc.authentication.qryModifyInfoAuthCheckZ($Gadget, $Fire, doAfterInitAuth);
        },

			afterInitAuth : function($Gadget, $Fire) {

				/*
				 * var dropListDemoData1 = [ { key : "AuthCheckF", value :
				 * "密码+证件认证", selected : true }, { key : "AuthCheckB", value :
				 * "服务密码认证", }, { key : "AuthCheckE", value : "本人身份证件认证", }, {
				 * key : "AuthCheckA", value : "随机短信密码认证", }, { key :
				 * "AuthCheckG", value : "二代身份证认证", }, { key : "AuthCheckI",
				 * value : "密码+二代证认证", }, { key : "AuthCheckZ", value : "不校验密码", } ]
				 */

            /*
             * if ($Gadget.authData != null) {
             *
             * for (var i = 0; i < $Gadget.authData.cardType.length; i++) {
             *
             * var cartType = $Gadget.authData.cardType[i]; var data = {};
             * data.key = cartType.itemCode; data.value = cartType.itemName;
             * dropListData0[i] = data; }; for (var i = 0; i <
             * $Gadget.authData.loginType.length; i++) { var logindata =
             * $Gadget.authData.loginType[i]; var data = {}; data.key =
             * logindata.itemCode; data.value = logindata.itemName;
             * dropListData1[i] = data; }; }
             */
            debugger;
            //获取实名制提醒校验方式
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getNextInitFireId());
            } catch (e) {
//                debugger;
            }
            $Gadget.$Get('$Fire')({
                service: "/common/dictkey2",
                params: {
                    'dictkeylist': ['RealNameRemindAuthType']
                },
                target: "$Gadget.RealNameRemindAuthType"
            }, $Gadget);

            // 是否将用户信息设置到session, 1表示设置
            $Gadget.sessionFlag = 1;
				$Gadget.needcheckWithoutPwd = true;
//				debugger;
				try {
					if ($Gadget.certype && $Gadget.certype.loginType != null) {                        
                        if ($Gadget.$Attrs.tabidforauthtype) {
                        	var menuId = $Gadget.$Attrs.tabidforauthtype;
                        } else {
                        	var menuId = adutil.getQueryStringByName("tabId");
                        	if (!menuId || menuId == "") {
                        		menuId = adutil.getQueryStringByName("menuid");
                        	}
                        }
                        
                        $Gadget.menuId = menuId;
                        
                        var querymenuauthtypes = function() {
                        	$Fire({
                        		service: '/ucec/v1/querymenuauthtypes',
                        		params: {
                        			"menuId": menuId
                        		},
                        		target: "$Gadget.authtyplist",
                        		onafter: function () {
                        			//鉴权方式过滤
//                        			debugger;
                        			$Controller.oc.authentication.initAuthTypes($Gadget, $Fire);
                        		}
                        	}, $Gadget);
                        };
                        
						if (menuId && menuId != "") {
							adutil.callGeneralEasyInvoker($Fire,
								'com.huawei.bes.sm.base.common.SMMenuBOService',
								'queryMenuExtAttrByAttrName',
								[menuId, "UseAuthCheckZ"],
								function (resp) {
                                    if (resp && resp.body == "1") {
                                        $Gadget.needcheckWithoutPwd = false;
                                    } else {
                                        $Gadget.needcheckWithoutPwd = true;
                                    }
                                    querymenuauthtypes();
                                },function () {
                                    querymenuauthtypes();
                                });

							
						} else {
//							debugger;
							$Controller.oc.authentication.initAuthTypes($Gadget, $Fire);
						}
						
					}
				} catch (e) {

				}
				

			},
			
			initAuthTypes : function($Gadget,$Fire){
//				debugger;
                
                if ($Gadget.initServicenumber) {
                    $("#serviceNumber" + $Gadget.besMenuId).val($Gadget.initServicenumber);
                }

				var dropListData = [];
				var dropListDemoData1 = [];
				dropListDemoData1 = $.parseJSON($Gadget.certype.loginType);
				if (dropListDemoData1.length == 0) {
					dropListDemoData1.push({
						key : '-1',
						value : $UEE.i18n("ad.authentication.option.pleasechoose")/*请选择*/,
						selected : true
					});
				}
				//过滤AuthCheckEM 本人身份证件+店长鉴权AuthCheckFM 密码+证件+店长鉴权AuthCheckJM本人身份证件+短信验证码+店长鉴权
				dropListDemoData1 = $.grep(dropListDemoData1 || [],function(val,i){
					return val&&val.extMap&&val.extMap.ext1 != "H";
				});
                if (window._ysp_top.loginReq && window._ysp_top.loginReq.authType) {
                	var dropListAll = dropListDemoData1;                            
                    var authType = window._ysp_top.loginReq.authType;                    
                    if (authType == "AuthCheckG") {
                        authType = "AuthCheckE";
                    } else if (authType == "AuthCheckI") {
                        authType = "AuthCheckF";
                    } 
                    
                	for (var i = 0; i < dropListAll.length; i++) {
                		if (authType == dropListAll[i].key) {
                			$Gadget.authTypeName = dropListAll[i].value;
                		}
                	}
                }
                
                if ($Gadget.$Attrs.authtypelistouter) {
                    $Gadget.authtyplist = $Gadget.$Attrs.authtypelistouter.split(",");
                }
                               
				if ($Gadget.authtyplist && $Gadget.authtyplist.length!=0 && dropListDemoData1.length != 0) {
					var dropListDemoData1temp=[];
					for (var i = 0; i < dropListDemoData1.length; i ++) {
						if ($.inArray(dropListDemoData1[i].key, $Gadget.authtyplist)!=-1) {
							dropListDemoData1temp.push(dropListDemoData1[i]);
						}
					}
					dropListDemoData1 = dropListDemoData1temp;
				}
                
				//两城一号
                if(adutil.getQueryStringByName("tabId")=="60131501"){
                    if($("#doublecitymaininner").length == 0){
                        dropListDemoData1 = [
                                             {
                                                 "key": "AuthCheckF",
                                                 "value": $UEE.i18n("ad.authentication.option.passwordcertauth")/*密码+证件认证*/,
                                                 "selected": true
                                             }
                                            ];
                        $Gadget.authType = 'AuthCheckF';
                        $Gadget.authTypeBack = $Gadget.authType;
                    }
                    
                }
				
				// 是否有权限不校验密码
//				debugger;
				$Gadget.isWithoutPwd = $Gadget.isWithoutPwd || [];
				//当前菜单id
				var curMenuId = adutil.getQueryStringByName("tabId");
				var modifyInfoMenu = '60131010';
				if(modifyInfoMenu == curMenuId){
					if ("N" == $Gadget.isWithoutPwd["60131002727"] && "N" == $Gadget.isWithoutPwd["60131002728"] && !$Gadget.modifyInfoAuthCheckZFlag) {
						for (var i = 0; i < dropListDemoData1.length; i ++) {
							if ("AuthCheckZ" == dropListDemoData1[i].key) {
								dropListDemoData1[i].key = "-1";
								dropListDemoData1[i].selected = true;
								dropListDemoData1[i].value = $UEE.i18n("ad.authentication.option.pleasechoose")/* 请选择 */;
								break;
							}
						}
					}
				} else if ($Gadget.$Attrs.busitype == "custinfoqryauth") {
					if ("N" == $Gadget.isWithoutPwd["60131002727"] && "N" == $Gadget.isWithoutPwd["60131002728"] && !$Gadget.noChekPwdForCustQryAuth) {
						for (var i = 0; i < dropListDemoData1.length; i++) {
							if ("AuthCheckZ" == dropListDemoData1[i].key) {
								dropListDemoData1[i].key = "-1";
								dropListDemoData1[i].selected = true;
								dropListDemoData1[i].value = $UEE.i18n("ad.authentication.option.pleasechoose")/* 请选择 */;
								break;
							}
						}
					}
				} else {
					if ($Gadget.needcheckWithoutPwd&&"N" == $Gadget.isWithoutPwd["60131002727"] && "N" == $Gadget.isWithoutPwd["60131002728"]) {
						for (var i = 0; i < dropListDemoData1.length; i ++) {
							if ("AuthCheckZ" == dropListDemoData1[i].key) {
								dropListDemoData1[i].key = "-1";
								dropListDemoData1[i].selected = true;
								dropListDemoData1[i].value = $UEE.i18n("ad.authentication.option.pleasechoose")/* 请选择 */;
								break;
							}
						}
					}
				}
				dropListDemoData1=$Controller.oc.authentication.operSmAuthList($Gadget,dropListDemoData1);

                var authtypecheckmsg = decodeURI(decodeURI(adutil.getParam("authtypecheckmsg")));
                var validAuthTypeNameList = "";
                for (var i = 0; i < dropListDemoData1.length; i ++) {
                    if (dropListDemoData1[i].key == "-1") {
                        continue;
                    }
                    
                    if ($Gadget.authtyplist && $Gadget.authtyplist.length && $.inArray(dropListDemoData1[i].key, $Gadget.authtyplist) == -1) {
                    	continue;
                    }
                    
                    if (authtypecheckmsg) {
                        validAuthTypeNameList += dropListDemoData1[i].value + '，';
                    }
                }
                    
                if (authtypecheckmsg && validAuthTypeNameList && location.pathname.indexOf('bes.ad.login.base.business.html') > -1) {
                    if (_ysp_top.serviceNumber) {
                        $("#serviceNumber" + $Gadget.besMenuId).val(_ysp_top.serviceNumber);
                    }
                    
                    this.showAuthTypeCheckMsg($Gadget, $Fire, $Gadget.$Get('$UI'), authtypecheckmsg, validAuthTypeNameList);
                }

				$Gadget.besMenuId = $Gadget.besMenuId || '';
				dropList1 = new UCD.Droplist($("#paperwork2" + $Gadget.besMenuId),
						dropListDemoData1);
				dropList1.init();
				dropList1.setOnValueChange(function() {
//					debugger;
					if($Gadget.authType != dropList1.$input.attr('key')){
						$("#password").val("");
						$("#cardId").val("");
						$("#verifyCodeInput").val("");
					}
					$Gadget.authType = dropList1.$input.attr('key');
					$Gadget.authTypeBack = $Gadget.authType;
					$Gadget.password = "";
					$Gadget.veryCode = null;
                    //清空下发工单流水
                    $Page.workOrderFormNum = null;
                    //清空店长鉴权
                    $Gadget.authManager=null;
					$Controller.oc.authentication
							.changeValue($Gadget.authType,$Gadget);
                    $Gadget.$Emit("$authTypeChange", $Gadget.authType);
				});
				
				//added by h00308289 sp综合业务方式
				if(adutil.getQueryStringByName("tabId")=="spContentCustomize_ZJ"){
					dropList1.selectItem("AuthCheckB");
					$Gadget.authTypeBack = "AuthCheckB";
				}
				else{
					dropList1.selectItem("AuthCheckB");
					$Gadget.authTypeBack = "AuthCheckB";
				}
				
				//两城一号
                if(adutil.getQueryStringByName("tabId")=="60131501"){
                    if($("#doublecitymaininner").length == 0){
                        $Gadget.authType = 'AuthCheckF';
                        $Gadget.authTypeBack = $Gadget.authType;
                    }
                }
                
				if ($Gadget.certype.cardType != null) {
					dropListData = $.parseJSON($Gadget.certype.cardType);
				} else {
					dropListData.push({
						key : '-1',
						value : $UEE.i18n("ad.authentication.option.pleasechoose")/*请选择*/,
						selected : true
					});
				}
				dropList2 = new UCD.Droplist($("#paperwork3"), dropListData);
				dropList2.init();
				dropList2.selectItem("IdCard");

            $Controller.oc.authentication.changeValue(dropList1.$input
                .attr('key'), $Gadget);
            //                var $checkDemo = $("#checkDemo");
            //
            //                checkBtn1 = new UCD.Checkbox($checkDemo, "邮箱账号", "myDemo");

            $Gadget.authdropList = dropList2.data;
            dropList2.setOnValueChange(function() {
//                debugger;
				$("#cardId").val("");
                $Gadget.drop2 = dropList2.$input.attr('key') || "";
                // 不是身份证 或者 身份证+有权限
                if (($Gadget.drop2 != "IdCard" && $Gadget.drop2 != "IdCardGA" && $Gadget.drop2 != "IdCardTW") || ($Gadget.isIdCardAuthCheckAllowInput == "Y" && $Gadget.cardRight == "false")) {
                    $("#cardId").removeAttr("readonly"); // 可以手动录入
                } else {
                    $("#cardId").attr("readonly", "readonly"); // 不可以手动录入
                }
                $Gadget.$safeApply($Gadget, function() {
                    var key = dropList2.$input.attr('key');
                    $Gadget.authSelectedKey = key;
                });
            });
            $Gadget.dropList2 = dropList2;
            //清空下发工单流水
            $Page.workOrderFormNum = null;
            $Controller.oc.authentication.checkLoginUserInfo($Gadget);

            /*
			 * try { OC.Callchain.setFireSearch($Gadget.$Page.pageId,
			 * OC.Callchain.getNextInitFireId()); } catch (e) { debugger; }
			 * 
			 * $Fire({ service : '/querycustlistboservice/queryauthbyauthids',
			 * params : { authids : "60131002727,60131002728" }, target :
			 * "$Gadget.isWithoutPwd", onafter : function($Gadget) { } },
			 * $Gadget);
			 */

        },        
        
        showAuthTypeCheckMsg: function ($Gadget, $Fire, $UI, authtypecheckmsg, validAuthTypeNameList) {
            function callBack(menuName) {                
                validAuthTypeNameList = validAuthTypeNameList.substr(0, validAuthTypeNameList.length - '，'.length);
                if (authtypecheckmsg == 'authTypeCheckMSG_default') {
                    authtypecheckmsg = "菜单%MENU_NAME%允许的鉴权方式为：%VALID_AUTHTYPE_NAMES%，当前的鉴权方式为%REAL_AUTHTYPE_NAME%，请修改鉴权方式。";
                }

                menuName = menuName || decodeURI(decodeURI(adutil.getQueryStringByName("tabName")));
                if (menuName == '个人销户(iCRM)') {
                    menuName = '销户';
                }
                
                var authTypeName = $Gadget.authTypeName || '';
                var regMenuName = new RegExp("%MENU_NAME%", "g");
                var regValidAuthTypeName = new RegExp("%VALID_AUTHTYPE_NAMES%", "g");
                var regRealAuthTypeName = new RegExp("%REAL_AUTHTYPE_NAME%", "g");
                var msg = authtypecheckmsg.replace(regMenuName, menuName);
                msg = msg.replace(regValidAuthTypeName, validAuthTypeNameList || '');
                msg = msg.replace(regRealAuthTypeName, authTypeName);
                $UI.msgbox.info('信息', msg);
            }
            
            $Fire({
            	service: '/gadget/common/operator/queryLoginOpenMenuByMenuId',
                params: {
                    'menuId' : $Gadget.menuId
                },
            	target: "menuInfoList",
            	onafter: function (menuInfoList) {
                    var menuName = "";
                    var menuInfo = menuInfoList && menuInfoList[0];
                    if (menuInfo) {
                        var SMMenuLangVO = menuInfo.SMMenuLangVO;
                        if (SMMenuLangVO && SMMenuLangVO.length > 0) {
                            for (var i=0; i<SMMenuLangVO.length; i++) {
                                if (SMMenuLangVO[i].locale == 'zh_CN') {
                                    menuName = SMMenuLangVO[i].menuName;
                                }
                            }
                        }
                        
                        if (!menuName && menuInfo.menuName) {
                            menuName = menuInfo.menuName;
                        }
                        
                        if (!menuName && menuInfo.menuDesc) {
                            menuName = menuInfo.menuDesc;
                        }
                    }
                    callBack(menuName);
            	},
            	onerror: function () {
                    callBack();
            	}
            });
            
        },
        
        //查询是否有改资料菜单不校验密码的令牌
        qryModifyInfoAuthCheckZ : function ($Gadget,$Fire, callBack){
        	debugger;
			$Gadget.modifyInfoAuthCheckZFlag = false;
            $Gadget.noChekPwdForCustQryAuth = false;
        	// 权限编码
        	$Gadget.modifyInfoAuthCheckZ = "601310070308";
        	$Fire({
        		service: "/ucec/v1/common/smHasAuth",
        		params: {
        			body: {
        				"authIds": [$Gadget.modifyInfoAuthCheckZ, "60131002721", "60131002722"]
        			}
        		},
        		target: "$Gadget.authResp",
        		onafter: function ($Gadget) {
        			debugger;
                    try {
                    	if ($Gadget.authResp && $Gadget.authResp.body && ($Gadget.authResp.body.authResults[0].result == "true")) {
                    		$Gadget.modifyInfoAuthCheckZFlag = true;
                    	}

                    	if ($Gadget.authResp && $Gadget.authResp.body && ($Gadget.authResp.body.authResults[1].result == "true" || $Gadget.authResp.body.authResults[2].result == "true")) {
                    		$Gadget.noChekPwdForCustQryAuth = true;
                    	}
                    } catch (e) {}
                    
                    callBack && callBack();
        		},
        		onerror: function () {
                    callBack && callBack();
        		}
        	}, $Gadget);
        },

        changeValue: function(key, $Gadget) {
//            debugger;
            $("#verifyCode").hide();
            if (key == "AuthCheckF") {

                $("#serverPassword").show();
                $("#cartType").show();
                $("#cartNumber").show();
                var drop2 = dropList2.$input.attr('key') || "";

                // 不是身份证 或者 身份证+有权限1
                if ((drop2 != "IdCard" && drop2 != "IdCardGA" && drop2 != "IdCardTW") || ($Gadget.isIdCardAuthCheckAllowInput == "Y" && $Gadget.cardRight == "false")) {
                    $("#cardId").removeAttr("readonly"); // 可以手动录入
                } else {
                    $("#cardId").attr("readonly", "readonly"); // 不可以手动录入
                }
                $("#verifyCode").hide();
                // 显示读取与上传
                $("#cardOperate").show();
            }
            if (key == "AuthCheckB" || key == "AuthCheckH") {
                // 小键盘读取按钮
                $("#keyBoardPasswordRead").hide();
                $("#serverPassword").show();
                $("#cartType").hide();
                $("#cartNumber").hide();
                $("#verifyCode").hide();;
                // 隐藏读取与上传
                $("#cardOperate").hide();
            }
            if (key == "AuthCheckA" || key == "AuthCheckAG" || key == "AuthCheckK") {
                // 小键盘读取按钮
                $("#keyBoardPasswordRead").hide();
                $("#serverPassword").hide();
                $("#cartType").hide();
                $("#cartNumber").hide();
                $("#verifyCode").show();
                // 隐藏读取与上传
                $("#cardOperate").hide();
            }
            
            if (key == "AuthCheckG") {
                $("#serverPassword").hide();
                $("#cartType").show();
                $("#cartNumber").show();
                var drop2 = dropList2.$input.attr('key') || "";
                // 不是身份证 或者 身份证+有权限
                if ((drop2 != "IdCard" && drop2 != "IdCardGA" && drop2 != "IdCardTW") || ($Gadget.isIdCardAuthCheckAllowInput == "Y" && $Gadget.cardRight == "false")) {
                    $("#cardId").removeAttr("readonly"); // 可以手动录入
                } else {
                    $("#cardId").attr("readonly", "readonly"); // 不可以手动录入
                }
                $("#verifyCode").hide();;
                // 显示读取与上传
                $("#cardOperate").show();
            }
            
            if (key == "AuthCheckI") {
                $("#serverPassword").show();
                $("#cartType").show();
                $("#cartNumber").show();
                var drop2 = dropList2.$input.attr('key') || "";
                // 不是身份证 或者 身份证+有权限
                if ((drop2 != "IdCard" && drop2 != "IdCardGA" && drop2 != "IdCardTW") || ($Gadget.isIdCardAuthCheckAllowInput == "Y" && $Gadget.cardRight == "false")) {
                    $("#cardId").removeAttr("readonly"); // 可以手动录入
                } else {
                    $("#cardId").attr("readonly", "readonly"); // 不可以手动录入
                }
                $("#verifyCode").hide();;
                // 显示读取与上传
                $("#cardOperate").show();
            }
            if (key == "AuthCheckZ") {

                $("#serverPassword").hide();
                $("#cartType").hide();
                $("#cartNumber").hide();
                $("#verifyCode").hide();;
                // 隐藏读取与上传
                $("#cardOperate").hide();
            }
            if (key == "AuthCheckE" || key == "AuthCheckJ") {
                 $("#serverPassword").hide();
                $("#cartType").show();
                $Gadget.$safeApply($Gadget, function() {
                    $Gadget.authSelectedKey = dropList2.$input.attr('key');
                });
                $("#cartNumber").show();
                var drop2 = dropList2.$input.attr('key') || "";
                // 不是身份证 或者 身份证+有权限
                if ((drop2 != "IdCard" && drop2 != "IdCardGA" && drop2 != "IdCardTW") || ($Gadget.isIdCardAuthCheckAllowInput == "Y" && $Gadget.cardRight == "false")) {
                    $("#cardId").removeAttr("readonly"); // 可以手动录入
                } else {
                    $("#cardId").attr("readonly", "readonly"); // 不可以手动录入
                }
                $("#verifyCode").hide();;
                // 显示读取与上传
                $("#cardOperate").show();
            }
                        
            if (key == "AuthCheckH") {
            	$("#serverPassword").show();
            	$("#verifyCode").show();
            } else if (key == "AuthCheckJ") {
            	$("#verifyCode").show();
            	$("#cartType").show();
            	$("#cartNumber").show();
            }
            
            //鉴权方式为 个人证件 或者 证件+密码  ，需要将证件类型自动回填
            if (key == "AuthCheckE" || key == "AuthCheckF" || key == "AuthCheckJ") {
                var servNumber = $("#serviceNumber" + $Gadget.besMenuId).val();
                if (servNumber) {
                    $Controller.oc.authentication.qryCustCertType(servNumber, $Gadget);
                }
            }

            try {
            	// 点击下拉框，调整父dom的高度
            	var inner = $('.changePayment_login');
            	var length = inner.height();
            	var outer1 = parent.$('.pl_content');
            	var outer2 = parent.$('.panel_login');
            	if (length < 280) {
            		length = 280;
            	}
            	outer1.height(length + 20);
            	outer2.height(length + 40);
            } catch (e) {}
        },

        qryCustCertType: function(servNumber, $Gadget) {

            $Gadget.$Get('$Fire')({
                service: "bes.oc.ocauthenticationservice/qryCustCertType",
                params: {
                    'servNumber': servNumber
                },
                target: "$Gadget.CustCertType",
                onafter: function() {
                    if ($Gadget.CustCertType) {
                        $Gadget.dropList2.selectItem($Gadget.CustCertType);
                    }
                }

            }, $Gadget);
        },

        autoDoLogin: function($Gadget, $UI, $Page, $Fire) {
//            debugger;
            if ("Y" == $Gadget.isAuthDoLogin && "AuthCheckB" == $Gadget.authType) {
                if (6 == $("#password").val().length) {
                    $Controller.oc.authentication.doLogin($Gadget, $UI, $Page, $Fire);
                }
            }
        },

        doLogin: function($Gadget, $UI, $Page, $Fire) {
            debugger;
            try {
                //OC.Callchain.initQueryTraceFlag($Page, $Gadget,$Fire);
                OC.Callchain.setFireSearch($(document).scope().$Params.pageId, "btnlogin");
            } catch (e) {
//                debugger;
            }
            //异地业务标识符，临时变量 z00316474 周绍华
            //$Page.diffLocated = window._ysp_top.difflocation;
            if (($Gadget.authType == "AuthCheckI" || $Gadget.authType == "AuthCheckG") && window._ysp_top.readCardStatus == "Y") {} else {
                $Gadget.authType = $Gadget.authTypeBack;
            }

            $("#loginbtn" + $Gadget.besMenuId).attr("disabled", "disabled");
            // modify 将证件类型特性参数结果保存到Page变量里
            $Page.CertificateTypeValidate = $Gadget.CertificateTypeValidate;

            $Gadget.accounts = [];
            var isEmail = false;
            var serviceNumber = $("#serviceNumber" + $Gadget.besMenuId).val();
            if ($Gadget.$Page.isCsp && !serviceNumber) {
                serviceNumber = $Gadget.$Attrs.servicenumber || _ysp_top.servicenumber;
            }
            //去掉空格
            serviceNumber = serviceNumber.replace(/\s+/g, "");
            if (serviceNumber.indexOf("@") != -1) {
                // 1为宁夏局点，0位江苏局点
                if ($Gadget.ProvincialPoint == "N") {
                    isEmail = false;
                } else {
                    isEmail = true;
                }
            }
            $Gadget.serviceNumber = serviceNumber;
			
	    if ($Gadget.authType == 'AuthCheckAG'){
		$Gadget.authTypeBack = $Gadget.authType;
		$Gadget.authType = "AuthCheckA"
            	$Gadget.serviceNumber = $Gadget.serviceNumberOfIms;
            }
			
            if (isEmail) {
                $Gadget.accounts.push({
                    'loginId': $Gadget.serviceNumber ,
                    'loginType': '1'
                });

                $Gadget.loginclass = "1";
            } else {
                $Gadget.loginclass = "2";
                $Gadget.accounts.push({
                    'loginId': $Gadget.serviceNumber ,
                    'loginType': '2'
                });
            }

            // $Gadget.password =$("").val();

            if (serviceNumber === null || serviceNumber.length === 0) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.servnumnotnull") /*服务号码不能为空*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                return;
            }

            // flag为true时，校验邮箱账号,否则校验电话号码
            if (isEmail) {
                var email_reg = /^[A-Za-z\d]+([-_\.\+]*[A-Za-z\d]+)*@(([A-Za-z\d]-?){0,62}[A-Za-z\d]\.)+[A-Za-z\d]{2,6}$/;
                if (!email_reg.test(serviceNumber)) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.wrongemailandrewrite") /*邮箱格式错误,请输入正确的邮箱!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                    return;
                }
            } else {
                if (!this.checkOperatorInfoServiceNumber(serviceNumber)) {
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                    return;
                }

            }

            var key = dropList1.$input.attr('key');
            $Gadget.nextflag = true;
			//一号多终端标识实名制标识
			window._ysp_top.isAddmultipleterminals = true;
			
            var next = true;

            $Controller.oc.authentication.isNext(key, $Gadget, $UI);

        },

        checkRealName: function($Gadget, $Page, $Fire, $UI) {
            debugger;
            var key = dropList1.$input.attr('key');
            var isEmail = false;
            var serviceNumber = $Gadget.serviceNumber;
            if (serviceNumber.indexOf("@") != -1) {
                // 1为宁夏局点，0位江苏局点
                if ($Gadget.ProvincialPoint == "N") {
                    isEmail = false;
                } else {
                    isEmail = true;
                }
            }
            var next = true;
            try {
                OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
//                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: "OM_REAL_NAME_CHECK"
                },
                target: "$Gadget.isCheckRealName",
                onafter: function($Gadget) {
                    debugger;
                    if (!isEmail && "Y" == $Gadget.isCheckRealName) {
//                        debugger;
                        $Gadget.RealNameRemindAuthType = $Gadget.RealNameRemindAuthType || [];
                        var RealNameRemindAuthType = $Gadget.RealNameRemindAuthType.RealNameRemindAuthType || [];
                        for (var int = 0; int < RealNameRemindAuthType.length; int++) {
                            if (key == RealNameRemindAuthType[int].key) {
                                next = false;
                                $Controller.oc.authentication.queryRealNameStatus($Gadget, $UI, serviceNumber, $Page, $Fire);
                            }
                        }
                        if (next) {
//                            debugger;
                            $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                        }
                    } else {
//                        debugger;
                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                    }
                }
            }, $Gadget);
        },

        isNext: function(key, $Gadget, $UI) {
            debugger;
            if (!this.validateBeforeLogin(key, $Gadget, $UI)) {
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                return;
            }
            // 随机短信验证
            //                if (key == "AuthCheckA") {
            //                    $Gadget.$Emit("$LoginByVerifyCode");
            //                    return;
            //                }// 不校验密码
            //                else if (key == "AuthCheckZ") {
            //                    $Gadget.$Emit("$LoginWithoutPsw");
            //                    return;
            //                }// 服务密码认证
            //                else if (key == "AuthCheckB") {
            //                    $Gadget.$Emit("$LoginByPsw");
            //                    return;
            //                } else {
            if (OC.Comm.checkNull($Gadget.idCardInfo) && OC.Comm.checkNull($Gadget.idCardInfo.tempiccardInfo)) {
                $Gadget.iccardkey = encryptWithRSA($Gadget.idCardInfo.tempiccardInfo.iccardkey);
                $Gadget.iccardname = encryptWithRSA($Gadget.idCardInfo.tempiccardInfo.name);
                $Gadget.iccardno = encryptWithRSA($Gadget.idCardInfo.tempiccardInfo.cardNo);
            } else {
                $Gadget.iccardkey = "";
                $Gadget.iccardname = "";
                $Gadget.iccardno = "";
            }

            // added by z00283015 for story 认证中心需求改造
            if ($Gadget.authType != 'AuthCheckZ') {
                // 首先调用om的接口，判断用户是否需要到认证中心鉴权，如果不需要走老流程，否则走新流程
                $Gadget.$Get("$Fire")({
                    service: 'bes.oc.ocauthenticationservice/needauthtocertcenter',
                    params: {
                        servicenumber: $Gadget.serviceNumber
                    },
                    target: "$Gadget.isNeedToCertCenter",
                    onafter: function($Gadget) {
                        debugger;
                        if ($Gadget.isNeedToCertCenter && $Gadget.isNeedToCertCenter == 1) {
                            // 走新流程
                            // 判断当前是否是修改密码/重置密码菜单,如果是直接调用sm接口到认证中心鉴权
                            var menuId = adutil.getQueryStringByName("menuId");
                            if (menuId == '60131416' || menuId == '60131417') { //'60131416'密码修改菜单  '60131417'密码重置菜单
                                //直接调用sm接口到认证中心鉴权
                                // sm自己封装了内部接口，不管是需要到认证中心鉴权，还是不需要，sm鉴权流程都不需要改代码
                                $Controller.oc.authentication.loginReqSendMsg($Gadget);
                                return;
                            } else {
                                //是否需要简单密码校验
                                $Gadget.isCheckSimple = true;

                                //直接调用sm接口到认证中心鉴权
                                // sm自己封装了内部接口，不管是需要到认证中心鉴权，还是不需要，sm鉴权流程都不需要改代码
                                $Controller.oc.authentication.loginReqSendMsg($Gadget);
                                return;
                            }

                        } else { // 如果不需要到认证中心鉴权，依然走老流程
                            $Controller.oc.authentication.loginReqSendMsg($Gadget);
                            return;
                        }
                    }
                }, $Gadget);
            } else {
                // 需要通过密码鉴权，依然走老流程
                $Controller.oc.authentication.loginReqSendMsg($Gadget);
                return;
            }
        },

        // 封装sm鉴权前台请求入参   loginbymultiinfo
        loginReqSendMsg: function($Gadget) {
            debugger;
			$Gadget.ext1 = null;
			if ($Gadget.authType == "AuthCheckK") {
				$Gadget.ext1 = "WIRED_BINDNUM";
			}
            $Gadget.sessionFlag = $Gadget.$Attrs.sessionflag ? $Gadget.$Attrs.sessionflag : $Gadget.sessionFlag;
            _ysp_top.loginReq = {
                accounts: $Gadget.accounts,
                diffLocatedBusiness: $Gadget.$Page.diffLocated,
                loginId: $Gadget.serviceNumber,
                password: $Gadget.password,
                verifyCode: $Gadget.veryCode,
                authId: $Gadget.$Attrs.authId,
                authType: $Gadget.authType,
                sessionFlag: $Gadget.sessionFlag,
                certId: $Gadget.logincertId,
                certType: $Gadget.logincertType,
                recType: $Gadget.recType,
                icCardKey: $Gadget.iccardkey,
                icCardName: $Gadget.iccardname,
                icCardNo: $Gadget.iccardno,
                readCardType: window._ysp_top.readCardType,
				ext1: $Gadget.ext1
            };
            //加密传输
            $Gadget.password = $("#password").val();
            $Gadget.passwordForICrm = $Gadget.password;
            if ($Gadget.password) {
                $Gadget.password = encryptWithRSA($Gadget.password);
            }

            $Gadget.logincertId = $("#cardId").val();
        
            //add by swx370484 DTS2016082909719 开户时输入15位身份证号码，校验成功会界面会显示为18位，且开户成功后使用15位身份证号码不能登录客户统一视图
            $Gadget.logincertId =  adutil.certNum15To18($Gadget.logincertId, $Gadget.authSelectedKey, ["IdCard", "TempId", "DriverIC", "TempId"]);
            if ($Gadget.logincertId) {
                $Gadget.logincertIdForQuery = $Gadget.logincertId;
                $Gadget.logincertId = encryptWithRSA($Gadget.logincertId);
            }

            window._ysp_top.newmenuid = $(document).scope().$Params.menuId || "";
            
            var checkKey = dropList1.$input.attr('key');
            if (checkKey == "AuthCheckB" && !$("#password").val()) {
                return;
            }
            $Gadget.$Emit("$LoginByAccounts");
        },
        loginSuccess: function($Gadget, $Page, $Fire, $UI) {
            debugger;
			
            // 如果是IMS固话登陆，再用不验证密码登陆一次
            if ($Gadget.authTypeBack == "AuthCheckAG" && !$Gadget.isLoginByZ) {
				$Gadget.serviceNumber = $("#serviceNumber" + $Gadget.besMenuId).val();
				$Gadget.accounts.loginId = $("#serviceNumber" + $Gadget.besMenuId).val();
				$Gadget.password = "";
				$Gadget.veryCode = null;
				$Gadget.authType = "AuthCheckZ";
                $Gadget.authTypeForSession = 'AuthCheckAG';
				$Gadget.$Emit("$LoginByAccounts");
				$Gadget.authType = "AuthCheckAG";
                if (_ysp_top.loginReq) {
                    _ysp_top.loginReq.authType = "AuthCheckAG";
                }
                
                $Gadget.authTypeForSession = null;
				$Gadget.isLoginByZ = true;
				return;
            }
			else if ($Gadget.authTypeBack == "AuthCheckAG") {
				$Gadget.authType = "AuthCheckAG"
				$Gadget.isLoginByZ = false;
			}
			
            //用户登录埋点 add by p00354016
            $BuriedPoinStat.loginstat($Gadget.serviceNumber);
            //用户登录埋点 end

            //登入成功后将密码、证件号码清空
            $("#password").val("");
            $("#cardId").val("");
            $("#verifyCodeInput").val("");

            // DD-AR-E01788661 业务推荐优化 2017_IT19 
            // add by wKF59141.
            if (window._ysp_top.hasRecommendPushed) {
                window._ysp_top.hasRecommendPushed = false;
            }

            var modifyKey = adutil.getQueryStringByName("tabId");

            if ("Y" == $Gadget.isCretOKPrompt && $Gadget.certype.cardId && 15 == $Gadget.certype.cardId.length) {
                _ysp_top.msgInfo($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idneedtobeupdated") /*当前客户在系统中登记的是15位身份证资料，需要更新该客户的证件资料*/ );
            }
            //登录成功以后发送一个事件
            $Gadget.$Emit("$LoginSuccessCell");
            //记录未校验密码方式登录的登录日志 ykf14608 [AD][电信公共][B层][宁夏]关于添加BES系统客户登录日志后台记录功能_电信公共
            if($Gadget.authType == "AuthCheckZ"){
                $Controller.oc.authentication.writeLoginBusiLog($Gadget, $Page, $Fire);
            }
                if ($Gadget.$Attrs.skipopenpage && "Y"==$Gadget.$Attrs.skipopenpage){
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                    $Gadget.$Emit("$LoginSuccess");                                    
                }
                else{
                	$Fire({
                        service: '/queryBroadbandInfoService/broadbandVerification',
                        params: {
                        	phoneNumber: $Gadget.serviceNumber
                        },
                        target: "$Gadget.verificationInfo",
                        onafter: function($Gadget) {
                            debugger;
                        	if ($Gadget.verificationInfo && $Gadget.verificationInfo.withinBlackList == 'true' && $Gadget.verificationInfo.amount){
                            	var amountInt = parseInt($Gadget.verificationInfo.amount)/100;
                            	var amount = amountInt.toFixed(2);
                            	if ($Page.showAmalgamation && $Page.businessCode == "ChangeProduct")
                            	{
    	                        	alert('该用户有一笔宽带设备欠费，金额'+amount+'元。');
                            	}
                            	else
                            	{
                            		Showbo.Msg.alert("提示" , "该用户有一笔宽带设备欠费，金额"+amount+"元。");
                            	}
                            }
                        	
                            var request = {
                                    header: {
                                        loginToken: "",
                                        loginId: "",
                                        locale: "",
                                        serialId: ""
                                    },
                                    body: {
                                        menuId: modifyKey
                                    }
                                };

                                $Fire({
                                    service: 'agentdesktop/v1/person/menu_check',
                                    params: request,
                                    target: '$Gadget.data',
                                    onafter: function($Gadget) {
                                        debugger;
                                        $Gadget.$Page.data = {};
                                        $Gadget.$Page.data.menucheckresult = $Gadget.data;
                                        //ocActionSource = "" == adutil.getQueryStringByName("actionSource")
                                        //    ? "iCRM" : adutil.getQueryStringByName("actionSource");
                                        if (null !== $Gadget.data.body && "0" != $Gadget.data.body.rspCode) {
                                            var fontList = ["<font color='blue'>", "<font color='blue'>",
                                                "<font color='blue'>", "<font color='red'>"
                                            ];
                                            var messageCount = 0;
                                            var message = "";
                                            if ($Gadget.data.body.list) {
                                                for (var i = 0; i < $Gadget.data.body.list.length; i++) {
                                                    if ($Gadget.data.body.list[i].promptMessage && !$Gadget.data.body.list[i].validateResult) {
                                                        if (messageCount === 0) {
                                                            message = fontList[$Gadget.data.body.list[i].level] + $Gadget.data.body.list[i].promptMessage + "</font>";
                                                        } else {
                                                            message = message + "<br>" + fontList[$Gadget.data.body.list[i].level] + $Gadget.data.body.list[i].promptMessage + "</font>";
                                                        }
                                                        messageCount++;
                                                    }
                                                }
                                                if (message !== null) {
                                                    _ysp_top.msgInfo($UEE.i18n("ad.authentication.message.checkfailed") /*校验失败*/ , message);
                                                }
                                            }
                                        } else {
                                            if ("SM" != ocActionSource) {
                                                $(".bes-oc-authentication .changePayment_login")
                                                    .hide();
                                            }
                                            var targetUrl = decodeURI(adutil.getQueryStringByName("besUrl"));
                                            var key = adutil.getQueryStringByName("tabId");
                                            var name = decodeURI(decodeURI(adutil
                                                    .getQueryStringByName("tabName")));
                                           
                                            var contextStr = "/" + window.location.pathname.split("/", 2)[1];

                                            // 如果集成到iCRM系统， url含contextstr
                                            if ("iCRM" == ocActionSource /* adutil.getQueryStringByName("actionSource") */ ) {
                                                debugger;
                                                // TODO 调用iCRM js方法打开鉴权用户号码Tab页面
                                                var needOpenSubsTab = true;
                                                var servNumber = adutil.getQueryStringByName("servNumber");
                                                if (!servNumber || servNumber === "") {
                                                    servNumber = $Gadget.serviceNumber;
                                                }
                                                try {
                                                    needOpenSubsTab = Container_newUser(servNumber, "P", "", "", "", "", "", "", "", "", servNumber);
                                                } catch (e) {
                                                    // alert(e);
                                                }

                                                // 调iCRM js方法打开用户统一视图
                                                var mainWorkSpace = null;
                                                if (_ysp_top.publicObject) {
                                                    mainWorkSpace = _ysp_top.publicObject.mainTab;
                                                }

                                                //20151113--icrm中打开个人统一视图有问题，暂时屏蔽,异地业务时不打开
                                                if (mainWorkSpace && ($Page.diffLocated != 'Y')) {
                                                    var openMenuArray = [];
                                                    if (needOpenSubsTab) { // 需要打开此号码的个人统一视图
                                                        var custViewMenu = [];
                                                        custViewMenu.push("60131006");
                                                        custViewMenu.push($UEE.i18n("ad.authentication.message.personalunifierview") /*个人统一视图[镇江]*/ );
                                                        custViewMenu.push(contextStr + "/bes/ad/html/ctz.bes.ad.personalunifiedview.html");
                                                        openMenuArray.push(custViewMenu);
                                                    }
                                                    if (targetUrl && "" !== targetUrl && targetUrl.indexOf("personalunifiedview") < 0) {
                                                        var custViewMenu = [];
                                                        custViewMenu.push(key);
                                                        custViewMenu.push(name);
                                                        custViewMenu.push(targetUrl + location.search);
                                                        openMenuArray.push(custViewMenu);
                                                    }
                                                    mainWorkSpace.appendSubTabs(servNumber, openMenuArray);
                                                    mainWorkSpace.removeTabByCode("valida");
                                                    mainWorkSpace.removeTabByCode("60131_oclogintemp");
                                                } else {
                                                    if (needOpenSubsTab) {
                                                        window.open("../../ad/html/ctz.bes.ad.personalunifiedview.html" + getVersionUrlStr(1));
                                                    }
                                                    if (targetUrl && "" !== targetUrl && targetUrl.indexOf("personalunifiedview") < 0) {
                                                        window.open(targetUrl + location.search, '_blank');
                                                    }
                                                }
                                            }
                                            // 如果集成到SM系统， url不含contextstr
                                            else if ("SM" == ocActionSource /* adutil.getQueryStringByName("actionSource") */ ) {

                                                // 调SM js方法打开用户统一视图

                                                // 配合商品订购修改是否操作菜单 DTS2015103008516
                                                //商品订购打开统一视图
                                                //20151113--异地业务不打开个人统一视图
                                                if (targetUrl && "" !== targetUrl && targetUrl.indexOf("personalunifiedview") < 0 && ($Page.diffLocated != 'Y')) {
                                                    
                                                    ///:huangyuyuan mod 2016-09-01 宁夏移动现场测试发现，对应iCrm菜单“/custcare/CUSTOMIZE/NX/receptionnew/servicequery/GlaNetAgePriAction.do?method=first”，
                                                    //普通打开时正常，当经过号码鉴权后跳转，就无法显示页面。经过分析是这段代码有问题，“/custcare”被改成了“/oc”，所以这里对它进行处理，由于这段代码被大量页面调用，目前无法每个场景都测试，
                                                    //为保险起见，最后面仍保留原代码（被注释），后续如果发现某种场景出现显示异常，就分析下新旧代码，看看场景是否考虑全，是否需要拉if/else分支，进行特殊处理
                                                    //临时获取，用来保存完整路径
                                                    var targetUrlTemp = targetUrl;
                                                    
                                                    targetUrl = targetUrl.substring(targetUrl.indexOf("/", 1));

                                                    var idx = targetUrlTemp.indexOf("/");
                                                    
                                                    try {
                                                        if (0 === idx) {
                                                            var context = targetUrlTemp.substring(0, targetUrl.indexOf("/", 1));
                                                            var secondContext = _ysp_top.getCrmWebContext(context.substring(1));
                                                            if (context == secondContext || (context=="" && secondContext == "/")) { 
                                                                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name, targetUrlTemp + location.search,
                                                                    key, false);
                                                            } else {
                                                                targetUrl = secondContext + targetUrlTemp.substring(context.length);

                                                                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name, targetUrl + location.search,
                                                                    key, false);
                                                            }
                                                        } else {

                                                            _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name, targetUrlTemp + location.search,
                                                                key, false);
                                                        }
                                                    } catch (e) {}
                                                    // 关闭鉴权页面
                                                    window.$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp");
                                                    
                                                    /*targetUrl = targetUrl.substring(targetUrl.indexOf("/", 1));
                                                    $Fire({
                                                        service: "bes.oc.ocauthenticationservice/checkbesurlinauthmap",
                                                        params: {
                                                            "besurl": targetUrl
                                                        },
                                                        target: "$Page.checkbesurl",
                                                        onafter: function() {
                                                            debugger;
                                                            if ($Page.checkbesurl) {
                                                                var idx = targetUrl.indexOf("/");
                                                                if (0 === idx) {
                                                                    var context = targetUrl.substring(0, targetUrl.indexOf("/", 1));
                                                                    var secondContext = _ysp_top.getCrmWebContext(context.substring(1));
                                                                    if (context == secondContext) {
                                                                        _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name, "resource.root" + targetUrl + location.search,
                                                                            key, false);
                                                                    } else {
                                                                        targetUrl = secondContext + targetUrl.substring(context.length);

                                                                        _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name, targetUrl + location.search,
                                                                            key, false);
                                                                    }
                                                                } else {

                                                                    _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name, "resource.root" + targetUrl + location.search,
                                                                        key, false);
                                                                }
                                                                // 关闭鉴权页面
                                                                window.$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp");
                                                            } else {
                                                                $(document).scope().$Get("$UI").msgbox.info($UEE.i18n("ad.checkout.label.information") , $UEE.i18n("ad.authentication.message.roamingfailed")  , function() {
                                                                    debugger;
                                                                    $Fire({
                                                                        'service': '/agentdesktop/v1/person/subscribersignout',
                                                                        'target': '$Gadget.result',
                                                                        'onafter': function() {
                                                                            debugger;
                                                                            window.$BES.$Portal.tabpanel.closeTabItem();
                                                                        },
                                                                        'onerror': function() {
                                                                            debugger;
                                                                        }
                                                                    }, $Gadget);
                                                                });
                                                            }
                                                        }
                                                    }, $Gadget);*/
                                                    ///:~
                                                } else if ($Page.diffLocated != 'Y') {
                                                    try {
                                                        window._ysp_top.setUserSessionFinish = false; //SM关闭所有tab页面，并且将用户信息塞到缓存中后通知OC继续操作
                                                        window._ysp_top.tmpLoginId = window._ysp_top.loginReq.loginId; //存放登陆的手机号码，SM用这个变量来指明具体要缓存的用户号码
                                                        // 如果当前打开的页面中，60131开头的菜单个数为0，则直接跳转个人统一视图
                                                        var ocMenuNumber = 0;
                                                        var lis = _ysp_top.window.tab.$dom.find("li");
                                                        for (var i = 0; i < lis.length; i++) {
                                                            var tmpli = lis.eq(i);
                                                            if (tmpli.attr('innerId').substring(0, 5) == "60131") {
                                                                ocMenuNumber = ocMenuNumber + 1;
                                                            }
                                                        }

                                                        if ("" === targetUrl && "1" != $Page.isOperatTab) {
                                                            // 关闭所有打开的标签
                                                            window.$BES.$Portal.tabpanel.closeAllTabItem();
                                                        }

                                                        var count = 0;
                                                        var timeout = function() {
                                                            count++;
                                                            if (window._ysp_top.setUserSessionFinish == true || count >= 20 || ocMenuNumber == 0) {
                                                                // 打开统一视图
                                                                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf("60131006", $Gadget.serviceNumber, "resource.root/bes/ad/html/ctz.bes.ad.personalunifiedview.html" + getVersionUrlStr(1), "60131006", false);
                                                                window._ysp_top.setUserSessionFinish = undefined;
                                                                window._ysp_top.tmpLoginId = undefined;
                                                                if ("" != targetUrl) {
                                                                    // 关闭鉴权页面
                                                                    try{window.$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp");
                                                                        }catch (e) {
                                                                            //console.error(e);
                                                                        }
                                                                }
                                                            } else {
                                                                setTimeout(timeout, 200);
                                                            }
                                                        };
                                                        setTimeout(timeout, 200);
                                                        
                                                    	//一站式融合家庭开户
                                                		if ($Gadget.adProductInfo && "FMC" == $Gadget.adProductInfo.prodType)
                                                        {	
                                                            //window.$BES.$Portal.tabpanel.closeAllTabItem();
                                                            adutil.openTopTab(
                                                                    "60131_orderningxiafamily",
                                                                    $UEE.i18n("AD.FAMILY.TITLE.ONE_STOP_FAMILY"),
                                                                    "/bes/ad/ctz/gadget/person/family/one-stop-familyopen/bes-ad-one-stop-familyorder-base.html"+getVersionUrlStr(1)+ "&offeringid=" + $Gadget.$Item.offeringId);				
                                                            $Page.isClickBtn = false;
                                                            window.$BES.$Portal.tabpanel.closeTabItem("60131004");
                                                            
                                                            if ($Page.showAmalgamation && $Page.businessCode == "ChangeProduct")
                                                            {
                                                            	window.$BES.$Portal.tabpanel.closeAllTabItemExceptSelf('60131_orderningxiafamily');	
//                                                            	setTimeout(function(){
//                                                            	},15000);                                                            		
                                                            }
                                                            return;
                                                        }
                                                        
                                                    } catch (e) {}
                                                }

                                                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                            }
                                            // 集成到其他系统
                                            else {
                                                window
                                                    .open("../../ad/html/ctz.bes.ad.personalunifiedview.html" + getVersionUrlStr(1));
                                                var targetUrl = adutil
                                                    .getQueryStringByName("targetUrl");
                                                if (targetUrl && "" != targetUrl) {
                                                    window.open(targetUrl + location.search);
                                                }
                                            }

                                            // $("#" + $Gadget.$Attrs.classname).show();
                                            $Gadget.$Emit("$LoginSuccess");

                                        }
                                    }
                                }, $Gadget);
                        }
                    }, $Gadget);
            // 登录成功以后跳转页面
                }
        },

        loginByReadCard: function($Gadget, $Page, $Fire, $UI) {
            // 设备读取身份证
            if (OC.Comm.checkNull($Gadget.idCardInfo)) {
                debugger;
                var effectDate = null;
                var expireDate = null;
                if ($Gadget.idCardInfo.tempiccardInfo.effectDate && "" != $Gadget.idCardInfo.tempiccardInfo.effectDate) {
                    effectDate = new Date(
                        $Gadget.idCardInfo.tempiccardInfo.effectDate).getTime();
                }
                if ($Gadget.idCardInfo.tempiccardInfo.endDate && "" != $Gadget.idCardInfo.tempiccardInfo.endDate) {
                    expireDate = new Date(
                        $Gadget.idCardInfo.tempiccardInfo.endDate).getTime();
                }

                request = {
                    header: {},
                    body: {
                        idName: $Gadget.idCardInfo.idName,
                        idAddress: $Gadget.idCardInfo.idAddr,
                        certAddress: $Gadget.idCardInfo.tempiccardInfo.address,
                        gender: $Gadget.idCardInfo.tempiccardInfo.sex,
                        serviceNum: $Gadget.serviceNumber,
                        race: $Gadget.idCardInfo.tempiccardInfo.nation,
                        effectDate: effectDate,
                        expireDate: expireDate,
                        authenticateType: $Gadget.authType
                    }
                };

                $Fire({
                    service: "ucec/v1/customer/realname_check",
                    params: request,
                    target: "$Gadget.data",
                    onafter: function($Gadget) {
                        debugger;
                        if (OC.Comm.checkNull($Gadget.data) && OC.Comm.checkNull($Gadget.data.body)) {
                            if ("0" == $Gadget.data.body.retCode) {
                                window._ysp_top.realNameDetail = null;
                                $Gadget.$Get('$Fire')({
                                    service: "queryrealnamestatusserviceboservice/queryrealnamestatus",
                                    params: {
                                        'header': null,
                                        'body': {
                                            "serviceNumber": $Gadget.serviceNumber
                                        }
                                    },
                                    target: "$Gadget.realNameDetail",
                                    onafter: function() {
                                        debugger;
                                        window._ysp_top.realNameDetail = $Gadget.realNameDetail && $Gadget.realNameDetail.body;
                                        if ("4" != $Gadget.realNameDetail.body.regStatus) {

                                            $Gadget.$Get('$Fire')({
                                                service: "queryrealnamestatusserviceboservice/realnamesystemcertification",
                                                params: {
                                                    "number": $Gadget.serviceNumber
                                                },
                                                target: "$Gadget.realNameCert",
                                                onafter: function() {
                                                }
                                            }, $Gadget);
                                        }
                                    }
                                }, $Gadget);
                                $Controller.oc.authentication.checkRealName($Gadget, $Page, $Fire, $UI);
                                //return true;
                            } else {
                                _ysp_top.msgInfo($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.docneedtobemodified") /*客户在系统中注册的证件资料与设备读取的证件资料不一致,请及时修改*/ ,
                                    function() {
                                        $Controller.oc.authentication.checkRealName($Gadget, $Page, $Fire, $UI);
                                    });
                            }
                        } else {
                            $Controller.oc.authentication.checkRealName($Gadget, $Page, $Fire, $UI);
                        }
                    }
                }, $Gadget);
            } else {
                $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
            }
        },

        // 记录受理日志
        writeBusiLog: function($Gadget, $Page, $Fire) {
            debugger;

            $Gadget.$Get("$Fire")({
                service: '/LogService/createOperLog',
                params: {
                    logParamIn: {
                        servNum: $Gadget.newserviceNumber,
                        authType: $Gadget.authType,
                        moduleId: "QRYCUSTINFO",
                        menuId: $Gadget.paramsmenuId,
                        operType: "Q",
                        bmocCompRecId: "",
                        complainNumber: "",
                        complainRecId: ""
                    }
                },
                target: '$Gadget.data.createOperLogResult',
                onafter: function($Gadget) {
                    debugger;
                    $Gadget.showCover = false;
                },
                onerror: function() {
                    $Gadget.showCover = false;
                }
            }, $Gadget);
        },
        
        //记录未校验密码方式登录的登录日志 ykf14608 [AD][电信公共][B层][宁夏]关于添加BES系统客户登录日志后台记录功能_电信公共
        writeLoginBusiLog: function($Gadget, $Page, $Fire) {
            debugger;
            $Gadget.bizCode = "LoginType";//入库用，不用国际化
            $Gadget.subBusiType = "UnAuthPwd";//入库用，不用国际化
            
            $Gadget.$Get("$Fire")({
                service: '/ctz.logservice/writeloginlog',
                params: {
                    req: {
                    	//受理类型
                        bizCode: $Gadget.bizCode,
                        //子业务类型
                        subBusiType: $Gadget.subBusiType,
                        currServNumber: $Gadget.serviceNumber
                    }
                },
                target: '$Gadget.data.createLoginLogResult',
                onafter: function($Gadget) {
                    debugger;
                    $Gadget.showCover = false;
                },
                onerror: function() {
                    $Gadget.showCover = false;
                }
            }, $Gadget); 
        },

        afterLoginNew: function($Gadget, $Page, $Fire, $UI) {
            debugger;
            //$Gadget.loginRes = 112;
            $Gadget.newserviceNumber = $("#serviceNumber" + $Gadget.besMenuId).val();
            $Gadget.paramsurl = $(document).scope().$Params.besUrl;
            $Gadget.paramsmenuId = $(document).scope().$Params.menuId;
            if ($Gadget.loginRes == 112 && $Gadget.paramsmenuId == "60131006") {
//                debugger;
                $UI.msgbox.confirm("提示", "你在尝试查询高价值用户信息，是否继续？", function() {
//                    debugger;
                    $Controller.oc.authentication.writeBusiLog($Gadget, $Page, $Fire);
                    adutil.openTopTab(
                        "judgeluckynumberold",
                        "吉祥号码客户资料",
                        "/bes/ad/html/bes-ad-ctz-luckynumprotection.html?&#/judgeluckynumber");
                });

            } else {
                $Controller.oc.authentication.afterLogin($Gadget, $Page, $Fire, $UI);
            }
        },

        afterLogin: function($Gadget, $Page, $Fire, $UI) {
            debugger;
            //20151010--重新登录时清空并刷新全局购物车

            //added by h00308289 只需要吧购物车清空就行 shoppingcart 下面会挂一下其他的变量的
            //window._ysp_top.shoppingcart = {};
            if (window._ysp_top.shoppingcart) {
//            	debugger;
                window._ysp_top.shoppingcart.carofferingList = [];
                (window._ysp_top.shoppingcart.$Pagea || {}).promInfoList = [];
                
                window._ysp_top.shoppingcart.projectVersion = "NINGXIA";
                //获取系统参数，是否开启购物车持久化操作,Y 开启、N 关闭
                $Fire({
					service : 'ucec/v1/common/qrysystemparambykey',
					params : {
						key : "ShoppingCartPersistence"
					},
					target : "$Gadget.ShoppingCarFlag",
					onafter : function($Gadget) {
						debugger;
						window._ysp_top.shoppingcart.ShoppingFlag = $Gadget.ShoppingCarFlag;
						//在登陆鉴权时预加载购物车
//		                debugger;
		                if (window._ysp_top.shoppingcart.ShoppingFlag == "Y")
		                {
			            	var req = {};
			            	req.serviceNumber = $Gadget.serviceNumber;
			            	req.beId = $Page.contextForBuriedPoints.beId;
			            	$Fire({
			                    service: '/ucec/v1/ctz/queryShoppingcarList',
			                    params : {
			                    	req : req
			                    },
			                    target: "$Gadget.shoppingcarinfolist",
			                    onafter: function($Gadget) {
			                        debugger;
                                    try {
			                        if ($Gadget.shoppingcarinfolist){
										//判断现在的数据是不是垃圾数据
										if($Gadget.shoppingcarinfolist.length == 1)
										{
											$Gadget.shoppingcarinfolist[0].itemData = JSON.parse($Gadget.shoppingcarinfolist[0].itemData);
											//看看是不是垃圾数据 DTS2017092200473
											if($Gadget.shoppingcarinfolist[0].itemData.promInfoList){
												var delshoppingcarinfo=[];
												var delshoppingcar={};
												delshoppingcar.beId=$Page.contextForBuriedPoints.beId;
												delshoppingcar.itemId=$Gadget.shoppingcarinfolist[0].itemId;
												delshoppingcarinfo.push(delshoppingcar);
												$Fire({
												service : "/ucec/ctz/delShoppingcar",
												params : {
													'request':delshoppingcarinfo ,
												},
												target : "flag",
												onafter : function(flag) {
													debugger;
													$Gadget.shoppingcarinfolist.splice(0,1);
												}
												});
											}else{
												//就一个普通商品的情况
												$Gadget.shoppingcarinfolist[0].itemData.itemTracId = $Gadget.shoppingcarinfolist[0].itemId;
												window._ysp_top.shoppingcart.carofferingList.push($Gadget.shoppingcarinfolist[0].itemData);
												var shoppingCar = $(".shoppingCar");
												 if (shoppingCar.length == 0) {
													 shoppingCar = _ysp_top.$(".shoppingCar");
												 }
												 shoppingCar.click();
											}
										}else{
											for ( var i = 0; i < $Gadget.shoppingcarinfolist.length; i++) 
											{
												$Gadget.shoppingcarinfolist[i].itemData = JSON.parse($Gadget.shoppingcarinfolist[i].itemData);
												$Gadget.shoppingcarinfolist[i].itemData.itemTracId = $Gadget.shoppingcarinfolist[i].itemId;
												if ($Gadget.shoppingcarinfolist[i].itemData.promInfoList)
												{
													window._ysp_top.shoppingcart.$Pagea.promInfoList = $Gadget.shoppingcarinfolist[i].itemData.promInfoList;
													window._ysp_top.shoppingcart.$Pagea.orderInvoice = $Gadget.shoppingcarinfolist[i].itemData.orderInvoice;
													window._ysp_top.shoppingcart.$Pagea.params = $Gadget.shoppingcarinfolist[i].itemData.params;
													window._ysp_top.shoppingcart.$Pagea.productFlag = $Gadget.shoppingcarinfolist[i].itemData.productFlag;
													window._ysp_top.shoppingcart.$Pagea.salesFlag = $Gadget.shoppingcarinfolist[i].itemData.salesFlag;
													window._ysp_top.shoppingcart.$Pagea.pageTracId = $Gadget.shoppingcarinfolist[i].itemData.itemTracId;
												}
												else
												{
													window._ysp_top.shoppingcart.carofferingList.push($Gadget.shoppingcarinfolist[i].itemData);
												}
											}
                                            
                                        	var shoppingCar = $(".shoppingCar");
                                        	if (shoppingCar.length == 0) {
                                        		shoppingCar = _ysp_top.$(".shoppingCar");
                                        	}
                                        	shoppingCar.click();
										}
			                        }
                                    } catch (e) {}
			                    },
			                }, $Gadget);
		                }
					},
				}, $Gadget);
            }
            
            try {
            	if (parent.$(".bes-ad-staticshoppingcar .order_title .order_close").length > 0) {
            		parent.$(".bes-ad-staticshoppingcar .order_title .order_close").click();
            	}
            } catch (e) {}


            if ($Gadget.loginRes == true || $Gadget.loginRes == 1) {
                //现场问题，Modify by lWX279860 for DTS2016041400924
                //是否需要简单密码校验
                if ($Gadget.isCheckSimple) {
                    //判断当前密码是否是简单密码
                    $Gadget.$Get("$Fire")({
                        service: 'bes.oc.ocauthenticationservice/chkpswdsimple',
                        params: {
                            "servicenumber": $Gadget.serviceNumber,
                            "password": $Gadget.password
                        },
                        target: "$Gadget.chkSimplePswd",
                        onafter: function($Gadget) {
                            debugger;
                            // 如果是简单密码，提示到修改密码页面修改密码，关闭登录鉴权页面
                            if ($Gadget.chkSimplePswd && $Gadget.chkSimplePswd.chkRetCode == 1) {
                                $Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.checkout.label.information") /*提示*/ , $Gadget.chkSimplePswd.chkRetMsg + $UEE.i18n("ad.authentication.message.modifypwdfirst") /*。请到修改密码菜单修改密码后再办理此业务。*/ , function() {
                                    // 关闭鉴权页面
                                    window.$BES.$Portal.tabpanel.closeTabItem("60131_oclogintemp");
                                    return;
                                });

                            } else {

                                $Controller.oc.authentication.weakPassWordVali($Gadget, $UI, $Page, $Fire);
                                //弱密码校验
                                /*if($Controller.oc.authentication.weakPassWordVali($Gadget, $UI, $Page, $Fire))
                                {
                                    //弱密码
                                    _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information")提示, $UEE.i18n("ad.authentication.message.pwdtoosimple")用户已有密码太简单，请修改密码后在办理此业务。, function(){
                                        $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                    }, function(){
                                        $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                                    });
                                }
                                else
                                {
                                        //非弱密码
                                        $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                                }*/
                            }

                        }
                    }, $Gadget);

                } else {
                    $Controller.oc.authentication.weakPassWordVali($Gadget, $UI, $Page, $Fire);
                    //弱密码校验
                    /*if($Controller.oc.authentication.weakPassWordVali($Gadget, $UI, $Page, $Fire))
                    {
                        //弱密码
                        _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information")提示, $UEE.i18n("ad.authentication.message.pwdtoosimple")用户已有密码太简单，请修改密码后在办理此业务。, function(){
                            $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                        }, function(){
                            $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                        });
                    }
                    else
                    {
                        //非弱密码
                        $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                    }*/
                }
                //现场问题，Modify by lWX279860 for DTS2016041400924

            }
            if ($Gadget.loginRes == false || $Gadget.loginRes == 0) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.servnumnopermission") /*服务号码没有对应的权限!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == -1) {
                var key = dropList1.$input.attr('key');
                // 密码+证件认证
                if (key == "AuthCheckF") {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numpwdcertwrong") /*服务号码或者服务密码或者证件号码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                }
                // 服务密码认证
                if (key == "AuthCheckB") {

                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numpwdwrong") /*服务号码或者服务密码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                }
                // 随机短信密码认证
                if (key == "AuthCheckA" || key == "AuthCheckK") {

                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numpwdwrong") /*服务号码或者服务密码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                }
                // 二代身份证认证
                if (key == "AuthCheckG") {

                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numcertwrong") /*服务号码或者证件号码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");

                }
                // 密码+二代证认证
                if (key == "AuthCheckI") {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numpwdcertwrong") /*服务号码或者服务密码或者证件号码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                }
                // 不校验密码
                if (key == "AuthCheckZ") {

                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numberwrong") /*服务号码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                }
                // 本人身份证件认证
                if (key == "AuthCheckE") {

                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.numcertwrong") /*服务号码或者证件号码有误!*/ );
                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                }

            }
            if ($Gadget.loginRes == 2) {

                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.userinfofailed") /*获取用户信息失败!请输入正确的服务号码或者邮箱!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == 12) {

                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.error.tips.account") /*该用户已销户，不能办理该业务。 */ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == 4) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.useroperthesame") /*用户归属地和操作员归属地相同，不允许在该菜单办理!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == 5) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.noremote") /*不允许办理异地业务!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == 6) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idtampered") /*身份证信息可能存在篡改，请重新读取!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            //                if ($Gadget.loginRes == 7) {
            //                    //_ysp_top.msgInfo("提示", "账号已经锁定!");
            //                    alert("账号已经锁定!");
            //                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            //                }
            //                if ($Gadget.loginRes == 8) {
            //                    //_ysp_top.msgInfo("提示", "账号已经锁定!");
            //                    alert( "账号已经锁定!");
            //                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            //                }
            if ($Gadget.loginRes == 9) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.opernorule") /*当前操作员没有不校验密码的权限!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == 10) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.useroperdiff") /*用户归属地和操作员归属地不同，不允许在该菜单办理!*/ );
                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
            }
            if ($Gadget.loginRes == 11) {
                //如果是预配号换卡菜单则不进行判断，否则会有流程矛盾
                if (adutil.getQueryStringByName("tabId") != "60131505") {
                    _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.dononebeforepwd") /*在用户修改初始密码前，不允许用户进行其他操作。*/ ,
                        function() {
//                            debugger;
                            adutil.openUserTab("60131416", $UEE.i18n("ad.authentication.message.modifypwdpersonal") /*个人密码修改*/ , "/bes/ordercapture/html/bes-oc-modifypwd.html" + getVersionUrlStr(1));
                        },
                        function() {
                            //清除session
                            $Fire({
                                'service': '/agentdesktop/v1/person/subscribersignout',
                                'target': '$Gadget.result',
                                'onafter': function() {
                                    debugger;
                                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                },
                                'onerror': function() {
                                    debugger;
                                }
                            }, $Gadget);
                        },
                        function() {
                            //清除session
                            $Fire({
                                'service': '/agentdesktop/v1/person/subscribersignout',
                                'target': '$Gadget.result',
                                'onafter': function() {
                                    debugger;
                                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                },
                                'onerror': function() {
                                    debugger;
                                }
                            }, $Gadget);
                        });
                }
            }

            //登录不管成功还是失败，把服务密码清空，防止失败的时候，又再次登录进去
            var checkKey = dropList1.$input.attr('key');
            if (checkKey == "AuthCheckB") {
                $("#password").val("");
            }
        },

        // 当输入字符为中文时，长度为3个字节
        len: function(str) {
//            debugger;
            if (!str) {
                return 0;
            }
            return str.replace(/[^\x00-\xff]/g, "xxx").length;
        },
        // JS注入校验
        checkInputdata: function(param) {
            debugger;
            var chechdata = param.toUpperCase();
            if (chechdata.indexOf("<") >= 0 || chechdata.indexOf(">") >= 0 || chechdata.indexOf("/") >= 0 || chechdata.indexOf("SCRIPT") >= 0) {
                return false;
            }
            return true;
        },

        validateBeforeLogin: function(key, $Gadget, $UI) {
            debugger;
            var cartType = dropList2.$input.attr('key');
            $Gadget.logincertType = cartType;
            $Gadget.logincertId = $("#cardId").val();
            if (key == null) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.option.pleasechooseauth") /*请选择鉴权方式!*/ );
                return false;
            }
            // 密码加证件认证/密码加二代证认证
            if (key == "AuthCheckI" || key == "AuthCheckF") {

                // 证件类型为身份证
                /*
                 * if (cartType == "IdCard") { //cartNumber, type, $Gadget,
                 * $UI if (!this.validateIdcard($("#cardId").val(),
                 * cartType, $Gadget.CertificateTypeValidate, $UI)) { return
                 * false; } ; $Gadget.accounts.push({ 'loginId' :
                 * $("#cardId").val(), 'loginType' : '3' }); }
                 */
                if (!this.validateIdcard($("#cardId").val(), cartType,
                        $Gadget.CertificateTypeValidate, $UI)) {
                    return false;
                };
                $Gadget.accounts.push({
                    'loginId': $("#cardId").val(),
                    'loginType': '3'
                });
                if ($("#password").val() == null || $("#password").val().length == 0) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );
                    return false;
                }
                $Gadget.password = $("#password").val();
                $("#serverPassword").show();
            }
            // 服务密码认证
            if (key == "AuthCheckB" || key == "AuthCheckH") {
                if ($("#password").val() == null || $("#password").val().length == 0) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );
                    return false;
                }
                $Gadget.password = $("#password").val();
                $("#serverPassword").show();

            }
            // 随机短信密码认证
            if (key == "AuthCheckA" || key == "AuthCheckAG" || key == "AuthCheckK"
                || key == "AuthCheckH" || key == "AuthCheckJ") {
                if ($("#verifyCodeInput").val() == null || $("#verifyCodeInput").val().length == 0) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );
                    return false;
                }
                $Gadget.veryCode = $("#verifyCodeInput").val();
                if (key != "AuthCheckH") {                    
                    $("#serverPassword").hide();
                }
                $("#verifyCode").show();
            }
            // 二代身份证认证
            if (key == "AuthCheckE") {
                // 证件类型为身份证
                /*
                 * if (cartType == "IdCard") { if
                 * (!this.validateIdcard($("#cardId").val(), cartType,
                 * $Gadget.CertificateTypeValidate, $UI)) { return false; } ;
                 * $Gadget.accounts.push({ 'loginId' : $("#cardId").val(),
                 * 'loginType' : '3' }); }
                 */
                if (!this.validateIdcard($("#cardId").val(), cartType,
                        $Gadget.CertificateTypeValidate, $UI)) {
                    return false;
                };
                $Gadget.accounts.push({
                    'loginId': $("#cardId").val(),
                    'loginType': '3'
                });

            }
            // 密码+二代证认证
            if (key == "AuthCheckI") {

                if ($("#password").val() == null || $("#password").val().length == 0) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );
                    return false;
                }
                $("#serverPassword").show();
                // 证件类型为身份证
                /*
                 * if (cartType == "IdCard") { if
                 * (!this.validateIdcard($("#cardId").val(), cartType,
                 * $Gadget.CertificateTypeValidate, $UI)) { return false; } ;
                 * $Gadget.accounts.push({ 'loginId' : $("#cardId").val(),
                 * 'loginType' : '3' }); }
                 */
                if (!this.validateIdcard($("#cardId").val(), cartType,
                        $Gadget.CertificateTypeValidate, $UI)) {
                    return false;
                };
                $Gadget.accounts.push({
                    'loginId': $("#cardId").val(),
                    'loginType': '3'
                });

            }
            // 本人身份证件认证
            if (key == "AuthCheckG") {
                // mody by wwx162658 【江苏移动】【C30产品实例化功能测试】【OC】【资料维护】【服务请求】身份证号最后一位不符合校验规则通过客户鉴权通过进入资料完善界面，登录成功。
                if (!this.validateIdcard($("#cardId").val(), cartType,
                        $Gadget.CertificateTypeValidate, $UI)) {
                    return false;
                };
                $Gadget.accounts.push({
                    'loginId': $("#cardId").val(),
                    'loginType': '3'
                });
            }

            return true;

        },

        checkOperatorInfoPhoneNumber: function(phoneNumber) {
            var len = this.len(phoneNumber);
            // 1.检查安全性
            if (!this.checkInputdata(phoneNumber)) {
                if (phoneNumber == $UEE.i18n("ad.authentication.message.phoneoremail") /*手机号/邮箱*/ ) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );
                } else {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.inputwrongcodes") /*输入包含非法字符，请重新输入!*/ );
                }
                return false;
            }
            // 2.检查长度
            if (len > 32) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.inputtoolong") /*输入字段的长度过长，请重新输入!*/ );
                return false;
            }
            var reg = /^((0\d{2,3}\d{7,8})|(1[34578]\d{9}))$/;
            if (phoneNumber != '' && !reg.test(phoneNumber)) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.phoneorfix") /*服务号码格式不正确，请输入手机号码或固话（含区号）!*/ );

                return false;
            }

            return true;
        },

        checkOperatorInfoServiceNumber: function(serviceNumber) {
            var len = this.len(serviceNumber);
            // 1.检查是否为空
            if (serviceNumber == '') {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );

                return false;
            }

            // 2.检查安全性
            if (!this.checkInputdata(serviceNumber)) {
                if (serviceNumber == $UEE.i18n("ad.authentication.message.phoneoremail") /*手机号/邮箱*/ ) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdnotnull") /*服务密码不能为空!*/ );
                } else {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.inputwrongcodes") /*输入包含非法字符，请重新输入!*/ );
                }
                return false;
            }

            //3.输入规则检查
            var regPhone = /^((0\d{2,3}\d{7,8})|(1[34578]\d{9}))$/;
            // mdy by wwx162658 DTS2015091908662 允许宽带号码有下划线
            //DTS2016112510893 割接老数据存在宽带账号为纯数字，增加允许纯数字类型的宽带账号鉴权，如 095308809666555
            var regBroad = /^(([a-z]+[0-9]+)|([0-9]+[a-z]+)|([a-z]+\_[0-9]+)|([0-9]+\_[a-z]+)|([0-9]+))[a-z0-9]*$/i;

            if (regPhone.test(serviceNumber)) {
                //4.电话号码长度检查
                if (len > 32) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.inputtoolong") /*输入字段的长度过长，请重新输入!*/ );
                    return false;
                }

            } else {
                if (regBroad.test(serviceNumber)) {
                    //5.宽带长度检查
                    if (len > 25) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.inputtoolong") /*输入字段的长度过长，请重新输入!*/ );
                        return false;
                    }
                } else {
                    // 物联网号码
                    if (!isNaN(serviceNumber) && (len == 13 || len == 10)) {
                        return true;
                    }
                    if ($Page.isCsp) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information"),$UEE.i18n("ad.authentication.message.bandnumorphoneorfix"));
                    } else {
                        Showbo.Msg.show({
                            'buttons': {
                                'yes': Showbo.BUTTON_OK
                            },
                            'title': $UEE.i18n("ad.checkout.label.information"),
                            'msg': $UEE.i18n("ad.authentication.message.bandnumorphoneorfix"),
                            'width': '505'
                        });
                    }
                    return false;
                }

            }
            return true;
        },

        validateIdcard: function(cartNumber, type, arr, $UI) {
            debugger;

            // return this.checkIdCard(cartNumber);
            var flag = adutil.checkCertificateNum(cartNumber, type, arr,
                $UI);
            return flag;
        },

        // add by zWX270193 增加15位身份证校验，提供公共方法
        check15IdCard: function(certificateNum) {
            debugger;

            // 15位证件号基本校验
            var check = /^[1-9]\d{7}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))\d{3}$/.test(certificateNum);
            if (!check) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.iddigitalerror") /*身份证号码出错：15位身份证号码必须为数字或证件编号不合法。*/ );
                return false;
            }

            // 校验地址的正确性
            var addressCode = certificateNum.substring(0, 6);
            check = $Controller.oc.authentication.check15IdAddr(addressCode);
            if (!check) {
                return false;
            }

            // 校验时间的正确性
            var timeCode = "19" + certificateNum.substring(6, 12);
            check = $Controller.oc.authentication.check15IdTime(timeCode);
            if (!check) {
                return false;
            }

            // 最后三位的校验正确性
            //var lastCode = certificateNum.substring(12,15);
            return true;
        },

        // add by zWX270193     增加15位身份证时间校验，提供公共方法
        check15IdTime: function(timeCode) {
            debugger;

            var check = /^[1-9]\d{3}((0[1-9])|(1[0-2]))((0[1-9])|([1-2][0-9])|(3[0-1]))$/.test(timeCode);
            if (!check) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.datedigitalerror") /*身份证号码出错：日期编码非数字。*/ );
                return false;
            }

            var year = parseInt(timeCode.substring(0, 4), 10);
            var month = parseInt(timeCode.substring(4, 6), 10);
            var day = parseInt(timeCode.substring(6, 8), 10);

            if (year < 1900) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.yearofbirth") /*出生年（*/ + year + $UEE.i18n("ad.authentication.message.tosmall") /*）太小*/ );
                return false;
            } else if (year > new Date().getFullYear()) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.yearofbirth") /*出生年（*/ + year + $UEE.i18n("ad.authentication.message.tolargethanthis") /*）太大（大于今年）*/ );
                return false;
            } else {
                if (month < 1) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.monthofbirth") /*出生月（*/ + month + $UEE.i18n("ad.authentication.message.tosmall") /*）太小*/ );
                    return false;
                } else if (month > 12) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.monthofbirth") /*出生月（*/ + month + $UEE.i18n("ad.authentication.message.tolarge") /*）太大*/ );
                    return false;
                } else {
                    var dayMax = 31;
                    if (month == 2) {
                        if (year % 100 == 0) {
                            if (year % 400 == 0) {
                                dayMax = 29;
                            } else {
                                dayMax = 28;
                            }
                        } else {
                            if (year % 4 == 0) {
                                dayMax = 29;
                            } else {
                                dayMax = 28;
                            }
                        }
                    }
                    if (month == 4 || month == 6 || month == 9 || month == 11) {
                        dayMax = 30;
                    }
                    if (day < 1) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.dayofbirth") /*出生日（*/ + day + $UEE.i18n("ad.authentication.message.tosmall") /*）太小*/ );
                        return false;
                    }
                    if (day > dayMax) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.dayofbirth") /*出生日（*/ + day + $UEE.i18n("ad.authentication.message.toolargethan") /*）太大（大于*/ + dayMax + "）");
                        return false;
                    }

                    // 校验出生日期应该小于当前时间
                    var datenow = new Date();
                    var dateborn = new Date(year, month - 1, day);
                    if (dateborn > datenow) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.birththancurr") /*身份证号码出错：出生日期大于当前时间*/ );
                        return false;
                    }
                }
            }
            return true;
        },

        // add by zWX270193 增加15位身份证地址校验，提供公共方法
        check15IdAddr: function(addressCode) {
            debugger;

            var check = /^[1-9]\d{5}$/.test(addressCode);
            if (!check) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.areadigitalerror") /*身份证号码出错：地区编码非数字。*/ );
                return false;
            }

            // 增加全国地址信息数据数组
            var aCity = {
                11: "北京",
                12: "天津",
                13: "河北",
                14: "山西",
                15: "内蒙古",
                21: "辽宁",
                22: "吉林",
                23: "黑龙江",
                31: "上海",
                32: "江苏",
                33: "浙江",
                34: "安徽",
                35: "福建",
                36: "江西",
                37: "山东",
                41: "河南",
                42: "湖北",
                43: "湖南",
                44: "广东",
                45: "广西",
                46: "海南",
                50: "重庆",
                51: "四川",
                52: "贵州",
                53: "云南",
                54: "西藏",
                61: "陕西",
                62: "甘肃",
                63: "青海",
                64: "宁夏",
                65: "新疆",
                71: "台湾",
                81: "香港",
                82: "澳门",
                91: "国外"
            };

            if (aCity[parseInt(addressCode.substring(0, 2))]) {
                return true;
            } else {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.illegalaeracode") /*非法地区代码编号：*/ + addressCode.substring(0, 2));
                return false;
            }
        },

        // 校验身份证号（18位）
        checkIdCard: function(certificateNum) {
            debugger;

            if (!certificateNum || certificateNum == 0) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idlengthcheck") /*身份证号码长度需满足18位。*/ );
                return false;
            }
            if (certificateNum != "") {
                certificateNum = $.trim(certificateNum);
            }

            // 如果长度满足15位，则进行15位校验，后18位校验下沉 add by zWX270193
            if (certificateNum.length == 15) {
                return $Controller.oc.authentication.check15IdCard(certificateNum);
            }

            if (certificateNum.length < 18) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idlengthscope") /*身份证号码长度需满足15位或18位。*/ );
                return false;
            }

            if (certificateNum.length == 18) {
                var check18 = certificateNum;
                var subCheck18 = check18.substring(0, 17);
                if (isNaN(subCheck18)) {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumbercheck") /*18位身份证的前17位必须全部为数字。*/ );
                    return false;
                } else {
                    var yearLength = 4,
                        sexLocation = 17;
                    var sexValue = (check18.charAt(sexLocation)) % 2;
                    var year = check18.substring(6, 6 + yearLength);
                    var month = check18.substring(6 + yearLength,
                        8 + yearLength);
                    var day = check18.substring(8 + yearLength,
                        10 + yearLength);
                    var aCity = {
                        11: "北京",
                        12: "天津",
                        13: "河北",
                        14: "山西",
                        15: "内蒙古",
                        21: "辽宁",
                        22: "吉林",
                        23: "黑龙江",
                        31: "上海",
                        32: "江苏",
                        33: "浙江",
                        34: "安徽",
                        35: "福建",
                        36: "江西",
                        37: "山东",
                        41: "河南",
                        42: "湖北",
                        43: "湖南",
                        44: "广东",
                        45: "广西",
                        46: "海南",
                        50: "重庆",
                        51: "四川",
                        52: "贵州",
                        53: "云南",
                        54: "西藏",
                        61: "陕西",
                        62: "甘肃",
                        63: "青海",
                        64: "宁夏",
                        65: "新疆",
                        71: "台湾",
                        81: "香港",
                        82: "澳门",
                        91: "国外"
                    };
                    var idNumber = certificateNum;
                    if (aCity[parseInt(idNumber.substr(0, 2))] == null) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.illegalaeranum") /*非法地区代码*/ + idNumber.substr(0, 2) + $UEE.i18n("ad.authentication.message.handlerwrongid") /*(该经办人证件编号不合法)*/ );
                        return false;
                    }
                    if (year < 1800) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.yearofbirth") /*出生年（*/ + year + $UEE.i18n("ad.authentication.message.tosmall") /*）太小*/ );
                        return false;
                    } else if (year > new Date().getFullYear()) {
                        Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.yearofbirth") /*出生年（*/ + year + $UEE.i18n("ad.authentication.message.tolargethanthis") /*）太大（大于今年）*/ );
                        return false;
                    } else {
                        if (month < 1) {
                            Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.monthofbirth") /*出生月（*/ + month + $UEE.i18n("ad.authentication.message.tosmall") /*）太小*/ );
                            return false;
                        } else if (month > 12) {
                            Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.monthofbirth") /*出生月（*/ + month + $UEE.i18n("ad.authentication.message.tolarge") /*）太大*/ );
                            return false;
                        } else {
                            var dayMax = 31;
                            if (month == 2) {
                                if (year % 100 == 0) {
                                    if (year % 400 == 0) {
                                        dayMax = 29;
                                    } else {
                                        dayMax = 28;
                                    }
                                } else {
                                    if (year % 4 == 0) {
                                        dayMax = 29;
                                    } else {
                                        dayMax = 28;
                                    }
                                }
                            }
                            if (month == 4 || month == 6 || month == 9 || month == 11) {
                                dayMax = 30;
                            }
                            if (day < 1) {
                                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.dayofbirth") /*出生日（*/ + day + $UEE.i18n("ad.authentication.message.tosmall") /*）太小*/ );
                                return false;
                            }
                            if (day > dayMax) {
                                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idnumerror") /*身份证号码出错：*/ + $UEE.i18n("ad.authentication.message.dayofbirth") /*出生日（*/ + day + $UEE.i18n("ad.authentication.message.toolargethan") /*）太大（大于*/ + dayMax + "）");
                                return false;
                            }

                            // 校验出生日期应该小于当前时间
                            var datenow = new Date();
                            var dateborn = new Date(year, month - 1, day);
                            if (dateborn > datenow) {
                                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.birththancurr") /*身份证号码出错：出生日期大于当前时间*/ );
                                return false;
                            }
                            // 校验最后一位
                            if (!this
                                .isTrueValidateCodeBy18IdCard(certificateNum)) {
                                return false;
                            }
                        }
                    }
                }
            } else {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idlengthscope") /*身份证号码长度需满足15位或18位。*/ );
                return false;
            }
            return true;
        },

        /**
         * 判断身份证号码为18位时最后的验证位是否正确
         *
         * @param a_idCard
         *            身份证号码数组
         * @return
         */
        isTrueValidateCodeBy18IdCard: function(certificateNum) {
            debugger;
            var Wi = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2,
                1
            ]; // 加权因子
            var ValideCode = [1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2]; // 身份证验证位值.10代表X
            var sum = 0;
            var reg = /^\d{17}(\d|X)$/;
            if (!reg.test(certificateNum)) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.lastidcheck") /*身份证最后一位只能为0-9或者X!*/ );
                return false;
            }

            if (certificateNum[17] == "X") {
                certificateNum[17] = 10;
            }
            for (var n = 0; n < 17; n++) {
                sum += Wi[n] * certificateNum[n];
            }

            var valCodePosition = sum % 11;
            if (certificateNum[17] == ValideCode[valCodePosition]) {
                return true;
            } else {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.wrongidreinput") /*您输入的的身份证号码有误，请重新输入!*/ );
                return false;
            }
        },
        beforeCreateCode: function($Gadget, $UI) {
            debugger;
            var serviceNumber = $("#serviceNumber" + $Gadget.besMenuId).val();

            if (serviceNumber == null || serviceNumber.length == 0) {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.servnumnotnull") /*服务号码不能为空*/ );
                return;
            }
			$Gadget.ext1 = null;
            
            var authCheckKey = dropList1.$input.attr('key');           
            if (authCheckKey && authCheckKey == $Gadget.authTypeBack && authCheckKey != $Gadget.authType) {
                $Gadget.authType = authCheckKey;
            }
            
			if ($Gadget.authType == "AuthCheckK") {
				$Gadget.ext1 = "WIRED_BINDNUM";
			}
			
			if ($Gadget.authType == "AuthCheckAG"){
            	// 判断是否为IMS固话号码，如果是IMS固话，则查询其对应的手机号
				$Gadget.$Get('$Fire')({
	                service: "/bes.oc.ocauthenticationservice/qryServiceNumberOfIMS",
	                params: {
	                	imsServiceNumber: serviceNumber,
	                	beId: $Page.contextForBuriedPoints.beId
	                },
	                target: "$Gadget.serviceNumberOfIms",
	                onafter: function() {
	                	if (!$Gadget.serviceNumberOfIms){
	                		Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information"), "其他错误");
							return;
	                	}
	                	else if ("1" == $Gadget.serviceNumberOfIms){
	                		Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information"), "非固话号码，不允许使用此鉴权方式");
							return;
	                	}
	                	else if ("2" == $Gadget.serviceNumberOfIms){
	                		Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information"), "此固话用户无关联手机，请选择其他鉴权方式");
							return;
	                	}
						
	                	$Gadget.createCode = $Gadget.serviceNumberOfIms;
						$Controller.oc.authentication.initauthenticationtype($Gadget, $UI);
						$Controller.oc.authentication.btnCountdown($Gadget);
						return;
	                }
	            }, $Gadget);
            }
			else {
				$Gadget.createCode = serviceNumber;
				$Controller.oc.authentication.initauthenticationtype($Gadget, $UI);
				$Controller.oc.authentication.btnCountdown($Gadget);
			}
        },
		
		initauthenticationtype : function($Gadget, $UI) {

			$Gadget.$Get('$Fire')({
	                service: "bes.oc.ocauthenticationservice/initauthenticationtype",
	                params: {
	                	req : {loginId : $Gadget.createCode,ext1:$Gadget.ext1}
	                },
	                target: "$Gadget.code",
	                onafter: function() {
	                	$Controller.oc.authentication.afterCreateCode($Gadget, $UI);
	                },
	                onerror: function() {
                        $Controller.oc.authentication.enableRandomPassword($Gadget);
	                }
	            }, $Gadget);
		},
		
        afterCreateCode: function($Gadget, $UI) {
            debugger;
            if ($Gadget.code == '1') {
                Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.randompwdfail") /*获取随机密码失败!*/ );
                this.enableRandomPassword($Gadget);
            }
            if ($Gadget.authType == "AuthCheckAG"){
                $Gadget.isLoginByZ = false;
            }
        },
        
        enableRandomPassword: function ($Gadget) {
        	try {
        		clearInterval($Gadget.randomNum);
        	} catch (e) {}
        	$("#randomPassword").attr({
        		"disabled": false
        	});
        	$("#randomPassword").val('获取验证码');
        },
		
		btnCountdown : function ($Gadget) {
			$("#randomPassword").attr({
                "disabled": false
            });
            var a = $Gadget.waitingTime || 300;
            $Gadget.randomNum = setInterval(function() {
                a--;
                if (a < 0) {
                    $("#randomPassword").attr({
                        "disabled": false
                    });
                    clearInterval($Gadget.randomNum);
                    $("#randomPassword").val('获取验证码');
                } else {
                    $("#randomPassword").val(a + $UEE.i18n("ad.authentication.message.second") /*秒*/ );
                    $("#randomPassword").attr({
                        "disabled": true
                    });

                }
            }, 1000);
		},
		
        readCard: function($Gadget) {
            debugger;
            if (!$Gadget.authSelectedKey) {
                $Gadget.authSelectedKey = dropList2.$input.attr('key');
            }

            $Gadget.$Emit("$Gadget.cardreadpop", {
                authSelectedKey: $Gadget.authSelectedKey,
                authdropList: $Gadget.authdropList,
            });
        },
        // 更新证件类型
        updatCardType: function($Event, $Gadget) {
            debugger;
            if ($Event && $Event.$Data) {
                $Gadget.dropList2.selectItem($Event.$Data.updateCardType);
            }
        },
        cardUpload: function($Gadget) {
            debugger;
            if (!$Gadget.authSelectedKey) {
                $Gadget.authSelectedKey = dropList2.$input.attr('key');
            }
            this.setLoginPageContextTag();

            if(!window._ysp_top.loginPageContextTag) {
                $Gadget.$Emit("$Gadget.carduploadpop", {
                    authSelectedKey: $Gadget.authSelectedKey,
                    authdropList: $Gadget.authdropList,
                });
                return;
            }
            try {
                var domCover = $(window._ysp_top.document).find('.win_cover');
            } catch(e) {
                return;
            }
            
            var coverDisplayOld = ("none" != domCover.css('display'));
            if (!coverDisplayOld) {
                domCover.eq(0).show();
            }

            window._ysp_top.carduploadpop = {
                authSelectedKey : $Gadget.authSelectedKey,
                authdropList : $Gadget.authdropList,
                coverDisplayOld : coverDisplayOld
            };

            var windowBoxwrapPop = $("<div class='windowBoxwrapPop' style='position: absolute; left: 20%; _ysp_top: 20%; z-index: 109;'></div>").appendTo(domCover);
            windowBoxwrapPop.load("resource.root/bes/ordercapture/themes/default/template/bes-oc-carduploadpop/bes-oc-carduploadframe.html"+getVersionUrlStr(1));
        },
		
        queryRealNameStatus: function($Gadget, $UI, serviceNumber, $Page, $Fire) {
            debugger;
            window._ysp_top.realNameDetail = null;
            $Gadget.$Get('$Fire')({
                service: "queryrealnamestatusserviceboservice/queryrealnamestatus",
                params: {
                    'header': null,
                    'body': {
                        "serviceNumber": serviceNumber
                    }
                },
                target: "$Gadget.realNameDetail",
                onafter: function() {
                    debugger;
                    window._ysp_top.realNameDetail = $Gadget.realNameDetail && $Gadget.realNameDetail.body;
                    //异地业务菜单时，icrm无top.msgConfirm对象，此处简化处理不做校验
                    if ($Gadget.realNameDetail && $Gadget.realNameDetail.header && "0" == $Gadget.realNameDetail.header.resultCode && ($Gadget.$Page.diffLocated != 'Y')) {
                        $Gadget.realNameDetail = $Gadget.realNameDetail.body || {};
                        if ("4" == $Gadget.realNameDetail.regStatus) {
                            $Gadget.nextflag = true;
							//一号多终端标识实名制标识
							 window._ysp_top.isAddmultipleterminals = true;                            
                        } else if ("1" == $Gadget.realNameDetail.regStatus) {
                            if ("BusinessLicence" == $Gadget.realNameDetail.custCertType) {
                                if ("IdCard" == $Gadget.realNameDetail.subsCertType) {
                                    $Gadget.nextflag = false;
                                    window._ysp_top.isAddmultipleterminals = false;
                                    _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.certsuggestion") /*用户目前为身份证实名未审核状态，建议通过证件鉴权方式登录。*/ ,
                                        function() {
                                            $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                            return false;
                                        },
                                        function(key, $Gadget, $UI) {
                                            debugger;
                                            $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                            $UI = $Gadget.$UI;
                                            var key = dropList1.$input.attr('key');
                                            $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                        },
                                        function() {
                                            debugger;
                                            $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                            $UI = $Gadget.$UI;
                                            var key = dropList1.$input.attr('key');
                                            $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                        }, $UEE.i18n("ad.authentication.button.ok") /*确定*/ , $UEE.i18n("ad.person.button.skip") /*跳过*/ );
                                } else {
                                    $Gadget.nextflag = true;
    								//一号多终端标识实名制标识
   								 	window._ysp_top.isAddmultipleterminals = true;                                    
                                }
                            } else if ("IdCard" == $Gadget.realNameDetail.custCertType) {
                                $Gadget.nextflag = false;
								window._ysp_top.isAddmultipleterminals = false;                               
                                _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.certsuggestion") /*用户目前为身份证实名未审核状态，建议通过证件鉴权方式登录。*/ ,
                                    function() {
                                        $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                        return false;
                                    },
                                    function() {
                                        debugger;
                                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                        $UI = $Gadget.$UI;
                                        var key = dropList1.$input.attr('key');
                                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                    },
                                    function() {
                                        debugger;
                                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                        $UI = $Gadget.$UI;
                                        var key = dropList1.$input.attr('key');										
                                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                    }, $UEE.i18n("ad.authentication.button.ok") /*确定*/ , $UEE.i18n("ad.person.button.skip") /*跳过*/ );
                            } else {
                                $Gadget.nextflag = true;
								//一号多终端标识实名制标识
								 window._ysp_top.isAddmultipleterminals = true;                                
                            }
                        } else {
                            if ("BusinessLicence" == $Gadget.realNameDetail.custCertType) {
                                if ("IdCard" == $Gadget.realNameDetail.subsCertType) {
                                    $Gadget.nextflag = false;
                                    window._ysp_top.isAddmultipleterminals = false;
                                    _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.certsuggestion") /*用户目前为身份证实名未审核状态，建议通过证件鉴权方式登录。*/ ,
                                        function() {
                                            $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                            return false;
                                        },
                                        function() {
                                            debugger;
                                            $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                            $UI = $Gadget.$UI;
                                            var key = dropList1.$input.attr('key');
                                            $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                        },
                                        function() {
                                            debugger;
                                            $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                            $UI = $Gadget.$UI;
                                            var key = dropList1.$input.attr('key');
                                            $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                        }, $UEE.i18n("ad.authentication.button.ok") /*确定*/ , $UEE.i18n("ad.person.button.skip") /*跳过*/ );
                                } else {
                                    $Gadget.nextflag = false;
                                    window._ysp_top.isAddmultipleterminals = false;
                                    _ysp_top.msgInfo($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idsuggestion") /*用户目前为非身份证实名未审核状态，建议使用身份证进行业务办理。*/ , function() {
                                        debugger;
                                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                        $UI = $Gadget.$UI;
                                        var key = dropList1.$input.attr('key');
                                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                    }, function() {
                                        debugger;
                                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                        $UI = $Gadget.$UI;
                                        var key = dropList1.$input.attr('key');
                                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                    });
                                }
                            } else if ("IdCard" == $Gadget.realNameDetail.custCertType) {
                                $Gadget.nextflag = false;
                                window._ysp_top.isAddmultipleterminals = false;
                                _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.certsuggestion") /*用户目前为身份证实名未审核状态，建议通过证件鉴权方式登录。*/ ,
                                    function() {
                                        $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                        return false;
                                    },
                                    function() {
                                        debugger;
                                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                        $UI = $Gadget.$UI;
                                        var key = dropList1.$input.attr('key');
                                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                    },
                                    function() {
                                        debugger;
                                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                        $UI = $Gadget.$UI;
                                        var key = dropList1.$input.attr('key');
                                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                    }, $UEE.i18n("ad.authentication.button.ok") /*确定*/ , $UEE.i18n("ad.person.button.cancel") /*取消*/ );
                            } else {
                                $Gadget.nextflag = false;
                                window._ysp_top.isAddmultipleterminals = false;
                                _ysp_top.msgInfo($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.idsuggestion") /*用户目前为非身份证实名未审核状态，建议使用身份证进行业务办理。*/ , function() {
                                    debugger;
                                    $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                    $UI = $Gadget.$UI;
                                    var key = dropList1.$input.attr('key');
                                    $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                }, function() {
                                    debugger;
                                    $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                                    $UI = $Gadget.$UI;
                                    var key = dropList1.$input.attr('key');
                                    $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                                });
                            }
                        }
                        if ($Gadget.nextflag) {
//                            debugger;
                            $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                            $UI = $Gadget.$UI;
                            var key = dropList1.$input.attr('key');
                            $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                        }
                    } else {
//                        debugger;
                        $Gadget = $(".bes-oc-authentication").scope().$$childTail.$Gadget;
                        $UI = $Gadget.$UI;
                        var key = dropList1.$input.attr('key');
                        $Controller.oc.authentication.loginSuccess($Gadget, $Page, $Fire, $UI);
                    }
                }
            }, $Gadget);
        },

        //店长鉴权
        authenticationManager: function($Gadget) {
            debugger;
            //将证件类型输入框变为可编辑
            $Gadget.cardRight = "false";
            //$("#cardId").attr('readonly', false);
            //document.getElementById("cardId").readOnly=false;
				
				//当金库验证用rest服务过滤时(参数开关60101154为1)，需求有一个rest服务，否则无法触发鉴权框。
				$Gadget.$Get("$Fire")({
					service : 'ucec/v1/common/qrysystemparambykey',
					params : {
						key : "60101154"
					},
					target : "$Gadget.isOpen",
					onafter : function($Gadget) {
						debugger;
						if('1'== $Gadget.isOpen){
							
							$Gadget.$Get("$Fire")({
					            service : '/ucec/v1/grp/telecomm/jinku/treasuryprove',
					            params : {
					                header : null
					            },
					            target : "$Gadget.treasuryProve",
					            onafter : function($Gadget) {
					                debugger;
					                $Gadget.authManager="1";
					                $("#cardId").removeAttr("disabled","");
					            }
					        }, $Gadget);
							
						}else{
							$("#cardId").removeAttr("disabled","");
							$Gadget.authManager="1";
						}
					}
				}, $Gadget);
        },

        //店长鉴权系统参数
        getCardGoldAuth: function($Gadget, $Fire) {
            var key = "OM_ID_CARD_GOLD_AUTH";
            debugger;
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.cardGoldAuth",
                onafter: function($Gadget) {
                    debugger;
                    $Gadget.cardRight = "false";
                    if ($Gadget.cardGoldAuth == 'On') {
                        //获取是否可以手动输入证件号码的令牌
                        $Fire({
                            service: "/authrightserviceboservice/hasright",
                            params: {
                                authid: "60131002726",
                            },
                            target: "$Gadget.rightResult",
                            onafter: function($Gadget) {
                                debugger;
                                if ($Gadget.rightResult) {
                                    //禁止手工输入
                                    $Gadget.cardRight = "true";
                                    //$("#cardId").attr('readonly', true);
                                    //document.getElementById("cardId").readOnly=true;
                                    $("#cardId").attr({
                                        "disabled": true
                                    });
                                } else {
                                    //手工输入
                                    $Gadget.cardRight = "false";
                                    //$("#cardId").attr('readonly', false);
                                    //document.getElementById("cardId").readOnly=false;
                                    $("#cardId").removeAttr("disabled", "");
                                }
                            }
                        }, $Gadget);
                    }
                }
            }, $Gadget);
        },

        /**
         * 是否加密证件号码（for iCRM）
         * @param $Gadget
         * @param $Fire
         */
        isIdCardEncrypt: function($Gadget, $Fire) {
            var key = "IdCardEncrypt";
            debugger;
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.isIdCardEncrypt",
                onafter: function($Gadget) {
                    $Gadget.isIdCardEncrypt = ($Gadget.isIdCardEncrypt == '1') ? true : false;
                    if ($Gadget.isIdCardEncrypt) {
                        $Controller.oc.authentication.encryptedCertId($Gadget, $Fire);
                    } else {
                        $Controller.oc.authentication.hasEncryptPassword($Gadget, $Fire);
                    }
                }
            }, $Gadget);
        },

        /**
         * 是否需要加密密码（for iCRM）
         * @param $Gadget
         * @param $Fire
         */
        hasEncryptPassword: function($Gadget, $Fire) {
            var key = "hasEncryptPassword";
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.hasEncryptPassword",
                onafter: function($Gadget) {
                    $Gadget.hasEncryptPassword = ($Gadget.hasEncryptPassword == '1') ? true : false;
                    if ($Gadget.hasEncryptPassword) {
                        pswd = $Controller.oc.authentication.encryptedPswd($Gadget, $Fire);
                    } else {
                        // 同步用户信息
                        $Controller.oc.authentication.sysCustInfo($Gadget, $Fire);
                    }
                }
            }, $Gadget);
        },

        getCustLoginRSAModForCertId: function($Gadget, $Fire) {
            var key = "BEScustLoginRSAMod";
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.custLoginRSAMod",
                onafter: function($Gadget) {
                    if ($Gadget.custLoginRSAMod && '' != $Gadget.custLoginRSAMod) {
                        $Controller.oc.authentication.getCustLoginRSAPubForCertId($Gadget, $Fire, $Gadget.certIDBeforeEncrypt);
                    } else {
                        $Controller.oc.authentication.hasEncryptPassword($Gadget, $Fire);
                    }
                }
            }, $Gadget);
        },

        getCustLoginRSAPubForCertId: function($Gadget, $Fire, source, dest) {
            var key = "hasEncryptPassword";
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.custLoginRSAPub",
                onafter: function($Gadget) {
                    if ($Gadget.custLoginRSAPub && '' != $Gadget.custLoginRSAPub) {
                        setMaxDigits(130);

                        var rSAKeyPair = new RSAKeyPair($Gadget.custLoginRSAPub, "", $Gadget.custLoginRSAMod);
                        var _source = encodeURIComponent(source);

                        // 加密后信息
                        $Gadget.certIDAfterEncrypt = encryptedString(rSAKeyPair, _source);
                    }

                    $Controller.oc.authentication.hasEncryptPassword($Gadget, $Fire);
                }
            }, $Gadget);
        },

        getCustLoginRSAModForPswd: function($Gadget, $Fire) {
            var key = "BEScustLoginRSAMod";
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
//                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.custLoginRSAMod",
                onafter: function($Gadget) {
                    if ($Gadget.custLoginRSAMod && '' != $Gadget.custLoginRSAMod) {
                        $Controller.oc.authentication.getCustLoginRSAPubForPswd($Gadget, $Fire, $Gadget.pswdBeforeEncrypt);
                    } else {
                        $Controller.oc.authentication.sysCustInfo($Gadget, $Fire);
                    }
                }
            }, $Gadget);
        },

        getCustLoginRSAPubForPswd: function($Gadget, $Fire, source, dest) {
            var key = "hasEncryptPassword";
            try {
                OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
//                debugger;
            }
            $Fire({
                service: 'ucec/v1/common/qrysystemparambykey',
                params: {
                    key: key
                },
                target: "$Gadget.custLoginRSAPub",
                onafter: function($Gadget) {
                    if ($Gadget.custLoginRSAPub && '' != $Gadget.custLoginRSAPub) {
                        setMaxDigits(130);

                        var rSAKeyPair = new RSAKeyPair($Gadget.custLoginRSAPub, "", $Gadget.custLoginRSAMod);
                        var _source = encodeURIComponent(source);

                        // 加密后信息
                        $Gadget.pswdAfterEncrypt = encryptedString(rSAKeyPair, _source);
                    }

                    // 同步用户信息
                    $Controller.oc.authentication.sysCustInfo($Gadget, $Fire);
                }
            }, $Gadget);
        },

        /**
         * 对密码 身份证信息进行加密
         * @param source
         * @returns
         */
        encryptedCertId: function($Gadget, $Fire) {

            debugger;

            if ($Gadget.certIDBeforeEncrypt && $Gadget.certIDBeforeEncrypt != "") {
                $Controller.oc.authentication.getCustLoginRSAModForCertId($Gadget, $Fire);
            } else {
                $Controller.oc.authentication.hasEncryptPassword($Gadget, $Fire);
            }
        },


        /**
         * 对密码 身份证信息进行加密
         * @param source
         * @returns
         */
        encryptedPswd: function($Gadget, $Fire) {

            debugger;

            if ($Gadget.pswdBeforeEncrypt && $Gadget.pswdBeforeEncrypt != "") {
                $Controller.oc.authentication.getCustLoginRSAModForPswd($Gadget, $Fire);
            } else {
                $Controller.oc.authentication.sysCustInfo($Gadget, $Fire);
            }
        },

        /**
         * 获取beID
         */
        getContextInfo: function($Gadget, $Fire) {
            $Fire({
                'service': '/bes.oc.ocquerysubscriptionbaseservice/querysubscriber',
                'params': {
                    'request': {
                        'serviceNumber': $Gadget.synData.servNumber
                    }
                },
                'target': '$Gadget.querysubscriberresp',
                onafter: function() {
                    debugger;
                    if ($Gadget.querysubscriberresp || $Gadget.querysubscriberresp.subscriberInfo) {
                        $Gadget.synData.beId = $Gadget.querysubscriberresp.subscriberInfo[0].beId;
                    }

                    $Controller.oc.authentication.sysCustInfoForNGJS($Gadget.synData.authCheckType, $Gadget.synData.pswd, $Gadget.synData.rndPswd, $Gadget.synData.certType, $Gadget.synData.certID, $Gadget.synData.beId, $Gadget.synData.servNumber, $Gadget.synData.beId);
                }
            }, $Gadget);
        },

        /**
         * 获取用户的登录信息（for iCRM）
         * @param $Gadget
         * @param $Fire
         */
        getLoginInfoForICrm: function($Gadget, $Fire) {
            $Gadget.synData = {};
            $Gadget.synData.isCert2G = OC.Comm.checkNull($Gadget.idCardInfo) ? 1 : 0;
            $Gadget.synData.servNumber = $("#serviceNumber" + $Gadget.besMenuId).val();
            $Gadget.synData.authCheckType = dropList1.$input.attr('key');
            $Gadget.synData.certID = $("#cardId").val();
            $Gadget.synData.certType = dropList2.$input.attr('key');
            $Gadget.synData.pswd = $Gadget.passwordForICrm; //$("#password")在登陆成功后，被清掉了，使用$Gadget.passwordForICrm
            $Gadget.synData.rndPswd = null;
            
            try {
                $Gadget.synData.beId = _ysp_top.$BES.$ContextAccessor.getBeId();
            } catch(e) {
                $Gadget.synData.beId = adutil.getBeId();
            }

            if ("AuthCheckA" == $Gadget.synData.authCheckType || "AuthCheckk" == $Gadget.synData.authCheckType) {
                $Gadget.synData.rndPswd = $("#password").val();
            }

            $Gadget.certIDBeforeEncrypt = $Gadget.synData.certID;
            $Gadget.certIDAfterEncrypt = $Gadget.synData.certID;

            $Gadget.pswdBeforeEncrypt = $Gadget.synData.pswd;
            $Gadget.pswdAfterEncrypt = $Gadget.synData.pswd;

            if ("AuthCheckZ" == $Gadget.synData.authCheckType) {
                $Controller.oc.authentication.sysCustInfo($Gadget, $Fire);
            } else {
                $Controller.oc.authentication.isIdCardEncrypt($Gadget, $Fire);
            }
        },

        /**
         * 同步用户信息
         */
        sysCustInfo: function($Gadget, $Fire) {

            //$Controller.oc.authentication.getContextInfo($Gadget, $Fire);
            //yubin add 20160825 随系统参数密码是否加密而变化
            $Controller.oc.authentication.sysCustInfoForNGJS($Gadget.synData.authCheckType, $Gadget.pswdAfterEncrypt, $Gadget.synData.rndPswd, $Gadget.synData.certType, $Gadget.synData.certID, $Gadget.synData.beId, $Gadget.synData.servNumber, $Gadget.synData.beId);

            $Controller.oc.authentication.sysCustInfoForWEBAR($Gadget.synData.authCheckType, $Gadget.pswdAfterEncrypt, $Gadget.synData.certType, $Gadget.certIDAfterEncrypt, $Gadget.synData.servNumber, null);

            $Controller.oc.authentication.sysCustInfoForWEBCC($Gadget.synData.authCheckType, $Gadget.pswdAfterEncrypt, $Gadget.synData.certType, $Gadget.certIDAfterEncrypt, $Gadget.synData.servNumber, null);

            $Controller.oc.authentication.sysCustInfoForICrm($Gadget.synData.isCert2G, $Gadget.synData.authCheckType, $Gadget.pswdAfterEncrypt, $Gadget.synData.rndPswd, $Gadget.synData.certType, $Gadget.certIDAfterEncrypt, null, $Gadget.synData.servNumber, $Gadget.hasEncryptPassword, null);

        },

        /**
         * 同步用户信息（for iCRM）
         * @param isCert2G: 是否通过设备读取二代证，1表示是，0表示否
         * @param authCheckType：鉴权方式，参考字典组：AuthCheck
         * @param pswd：密码，密码认证时传入，如果hasEncryptPassword为true，此需要加密
         * @param rndPswd：随机码，随机码认证时传入
         * @param certType：证件类型，参考字典组：IdType
         * @param certID：证件号码，确认下江苏有没有启用特性参数IdCardEncrypt，如果有的话需要加密。
         * @param custRegion：地市，宽带登录时可能会选择地市，只要明确指定地市的就传入
         * @param servNumber：服务号码
         * @param CustLoginTimeMillis：如果是先打开的菜单后鉴权，传开菜单的时间，System.currentTimeMillis()
         * @param hasEncryptPassword：是否加密密码，true是，false否
         */
        sysCustInfoForICrm : function(isCert2G, authCheckType, pswd, rndPswd, certType, certID, custRegion, servNumber, hasEncryptPassword, custLoginTimeMillis){			
            if (!_ysp_top.getCrmWebContext) {
                return;
            }
            
			var ngcustcare = _ysp_top.getCrmWebContext("ngcustcare");
        	
			var url = ngcustcare + "/servlet/custInfoForICrmServ?ONLYLOGIN=onlyLogin&noCrmSSO=1&isCert2G="+isCert2G;
			
			$.ajax({
				async : false,
				type: 'POST',
				url: url,
				dataType: "json",
				data: {authCheckType: authCheckType, pswd: pswd, rndPswd: rndPswd, certType: certType, certID: certID, custRegion: custRegion, servNumber:servNumber, hasEncryptPassword : hasEncryptPassword,CustLoginTimeMillis:custLoginTimeMillis},
				success: function () {
				},
				error: function(XMLHttpRequest, textStatus, errorThrown){
				}

			});
			
			
			
			var custcare = _ysp_top.getCrmWebContext("custcare");
        	
			var custcareUrl = custcare + "/ngCustcare.do?noCrmSSO=1&isCert2G="+isCert2G;
			
			$.ajax({
				async : false,
				type: 'POST',
				url: custcareUrl,
				dataType: "json",
				data: {authCheckType: authCheckType, pswd: pswd, rndPswd: rndPswd, certType: certType, certID: certID, custRegion: custRegion, servNumber:servNumber, hasEncryptPassword : hasEncryptPassword,CustLoginTimeMillis:custLoginTimeMillis},
				success: function () {
				},
				error: function(XMLHttpRequest, textStatus, errorThrown){
				}

			});

		},


        /**
         * 同步用户信息（for NGJS）
         * @param authCheckType：鉴权方式，参考字典组：AuthCheck
         * @param pswd：密码，密码认证时传入，
         * @param rndPswd：随机码，随机码认证时传入
         * @param certType：证件类型，参考字典组：IdType
         * @param certID：证件号码
         * @param custRegion：地市
         * @param servNumber：服务号码
         */
        sysCustInfoForNGJS: function(authCheckType, pswd, rndPswd, certType, certID, custRegion, servNumber, login_region) {
            if (!_ysp_top.getCrmWebContext) {
                return;
            }

            var url = _ysp_top.getCrmWebContext("ng_js") + "/custcdr/cdrquery/getReginByLogin.action?noCrmSSO=1";

            $.ajax({
                type: 'POST',
                url: url,
                dataType: "json",
                data: {
                    authCheckType: authCheckType,
                    pswd: pswd,
                    rndPswd: rndPswd,
                    certType: certType,
                    certID: certID,
                    custRegion: custRegion,
                    login_msisdn: servNumber,
                    login_region: login_region
                },
                success: function() {},
                error: function(XMLHttpRequest, textStatus, errorThrown) {}

            });

        },

        /**
         * 同步用户信息（for WEBAR）
         * @param authCheckType：鉴权方式，参考字典组：AuthCheck
         * @param pswd：密码，密码认证时传入，
         * @param certType：证件类型，参考字典组：IdType
         * @param certID：证件号码
         * @param region：地市
         * @param servNumber：服务号码
         */
        sysCustInfoForWEBAR: function(authCheckType, pswd, certType, certID, servNumber, region) {
            if (!_ysp_top.getCrmWebContext) {
                return;
            }

            var url = _ysp_top.getCrmWebContext("web_ar") + "/business.action?BMEBusiness=rec.syncAuthCheckData&noCrmSSO=1&authType=" + authCheckType + "&servNumber=" + servNumber + "&region=" + region + "&certType=" + certType + "&certID=" + certID + "&pwd=" + pswd;

            $.ajax({
                type: 'POST',
                url: url,
                error: function(XMLHttpRequest, textStatus, errorThrown) {}
            });

        },

        /**
         * 同步用户信息（for WEBCC）
         * @param authCheckType：鉴权方式，参考字典组：AuthCheck
         * @param pswd：密码，密码认证时传入，
         * @param certType：证件类型，参考字典组：IdType
         * @param certID：证件号码
         * @param region：地市
         * @param servNumber：服务号码
         */
        sysCustInfoForWEBCC: function(authCheckType, pswd, certType, certID, servNumber, region) {
            if (!_ysp_top.getCrmWebContext) {
                return;
            }
        
            var url = _ysp_top.getCrmWebContext("web_cc") + "/business.action?BMEBusiness=rec.syncAuthCheckData&noCrmSSO=1&authType=" + authCheckType + "&servNumber=" + servNumber + "&region=" + region + "&certType=" + certType + "&certID=" + certID + "&pwd=" + pswd;

            $.ajax({
                type: 'POST',
                url: url,
                error: function(XMLHttpRequest, textStatus, errorThrown) {}
            });

        },

        setLoginPageContextTag : function() {

            //SM里有三个登录的地方,在此加一个标识来区分 1-通过点击菜单进来的登录页面 2、SM集成的右边小登录页面
            window._ysp_top.loginPageContextTag = null;
            //通过点击菜单进来,besUrl不为空
            /**
            if(decodeURI(adutil.getQueryStringByName("besUrl")) != ""){
                window._ysp_top.loginPageContextTag = "1";
            }
            else if(decodeURI(adutil.getQueryStringByName("besUrl")) == ""){
                window._ysp_top.loginPageContextTag = "2";
            }
            */
            //判断是否是SM集成
            var pathNameUrl = document.location.pathname;
            //为除去上下文，从第一个位置搜索
            var index_2 = pathNameUrl.indexOf('/', 1);
            var currentUrl = pathNameUrl.substring(index_2);
            //因为OC菜单集成到Portal中，为了解决配置的url问题 根据 UEE的 resource.root 分割
            if (currentUrl.indexOf("resource.root") != -1) {
                currentUrl = currentUrl.split("resource.root")[1];
            }

            if (currentUrl == "/bes/sm/login/pages/oclogin-jsyd.html" || currentUrl == "/bes/sm/login/pages/oclogin.html" || currentUrl == "/bes/sm/login/pages/") {
                window._ysp_top.loginPageContextTag = "2";
            } else {
                window._ysp_top.loginPageContextTag = "1";
            }
        },
    
        readCardNew: function($Gadget) {
            debugger;
            if (!$Gadget.authSelectedKey) {
                $Gadget.authSelectedKey = dropList2.$input.attr('key');
            }
            if ("AuthCheckF" == $Gadget.authType) {
                $Gadget.authType = "AuthCheckI";
            } else {
                $Gadget.authType = "AuthCheckG";
            }

            this.setLoginPageContextTag();
            //UEE popup方式
            if ($Gadget.$Page.isCsp) {
                window._ysp_top.loginPageContextTag = null;
            }
            if (!window._ysp_top.loginPageContextTag || $Gadget.$Page.isCsp) {
                $Gadget.readCardParamData = {
                    authSelectedKey: $Gadget.authSelectedKey,
                    authdropList: $Gadget.authdropList,
                };
                if ($Gadget.$Page.isCsp) {
                    window._ysp_top.readCardParamData = {
                        authSelectedKey: $Gadget.authSelectedKey,
                        authdropList: $Gadget.authdropList,
                    };
                    
                    $Page.cspCustInfo = true;
                    $Gadget.$Get('$Fire')({
                        "popup": "{'title' : '" + $UEE.i18n("ad.authentication.label.secondgenerid") /*二代身份证*/ + "','width' : '660px','height' : '400px','modal' : true, 'src':'{{$Webapp}}/bes/ordercapture/themes/default/template/bes-oc-cardreadpop/bes-oc-cardread-popupcsp.html'}"
                    }, $Gadget);
                } else {
                    $Gadget.$Get('$Fire')({
                        "popup": "{'title' : '" + $UEE.i18n("ad.authentication.label.secondgenerid") /*二代身份证*/ + "','width' : '660px','height' : '400px','modal' : true, 'src':'{{$Webapp}}/bes/ordercapture/themes/default/template/bes-oc-cardreadpop/bes-oc-cardread-popup.html'}"
                    }, $Gadget);
                }
            }
            //SM popup方式
            else if (window._ysp_top.loginPageContextTag) {
                window._ysp_top.readCardParamData = {
                    authSelectedKey: $Gadget.authSelectedKey,
                    authdropList: $Gadget.authdropList,
                };
                var url = "resource.root/bes/ordercapture/themes/default/template/bes-oc-cardreadpop/bes-oc-cardread-toppop.html" + getVersionUrlStr(1);
                if (_ysp_top.loadPopup) {
                    _ysp_top.loadPopup(url);
                }
            }
        },

        checkPassWord: function($Gadget, $UI, $Page, $Fire) {
            //bes.oc.ocauthenticationservice/loginbymultiinfo
            debugger;
            if ("Y" == $Gadget.isAuthDoLogin && ("AuthCheckB" == $Gadget.authType || "AuthCheckF" == $Gadget.authType)) {
                if (6 == $("#password").val().length) {
                    $Gadget.password = $("#password").val();
                    $Gadget.password = encryptWithRSA($Gadget.password);
                    $Fire({
                        'service': '/bes.oc.ocauthenticationservice/checkpassword',
                        'params': {
                            'req': {
                                'password': $Gadget.password,
                                'loginId': $Gadget.serviceNumber,
                                'authType' : $Gadget.authType
                            }
                        },
                        'target': '$Gadget.checkPassWordFlag',
                        onafter: function() {
                            debugger;
                            if ($Gadget.checkPassWordFlag == 1 && $Gadget.authType == 'AuthCheckB') {
                                _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdtoosimple") /*用户已有密码太简单，请修改密码后在办理此业务。*/ , function() {
                                    $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                                    return;
                                }, function() {
                                    $Controller.oc.authentication.doLogin($Gadget, $UI, $Page, $Fire);
                                    return;
                                });
                            } else {
                                $Controller.oc.authentication.doLogin($Gadget, $UI, $Page, $Fire);
                            }

                        }
                    }, $Gadget);
                } else {
                    Showbo.Msg.alert($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.sixdigitpwd") /*密码请输入六位*/ );
                }
            } else {
                $Controller.oc.authentication.doLogin($Gadget, $UI, $Page, $Fire);
            }
        },

        weakPassWordVali: function($Gadget, $UI, $Page, $Fire) {
            //bes.oc.ocauthenticationservice/loginbymultiinfo
            debugger;
            var checkFlag = false;

            $Gadget.password = $("#password").val();
            if ($Gadget.password) {
                $Gadget.password = encryptWithRSA($Gadget.password);
                $Fire({
                    'service': '/bes.oc.ocauthenticationservice/checkpassword',
                    'params': {
                        'req': {
                            'password': $Gadget.password,
                            'loginId': $Gadget.serviceNumber,
                            'authType' : $Gadget.authType
                        }
                    },
                    'target': '$Gadget.checkPassWordFlag',
                    onafter: function() {
                        debugger;
                        if ($Gadget.checkPassWordFlag == 1 && $Gadget.authType == 'AuthCheckB') {
                            _ysp_top.msgConfirm($UEE.i18n("ad.checkout.label.information") /*提示*/ , $UEE.i18n("ad.authentication.message.pwdtoosimple") /*用户已有密码太简单，请修改密码后在办理此业务。*/ , function() {
                                $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
                            }, function() {
                                $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                            });
                        } else {
                            //checkFlag = false;
                            //return false;
                            $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                        }

                    }
                }, $Gadget);
            } else {
                $Controller.oc.authentication.loginSuccessBusi($Gadget, $UI, $Page, $Fire);
                //return false;
            }
        },

        //登入成功处理逻辑
        loginSuccessBusi: function($Gadget, $UI, $Page, $Fire) {
            $Gadget.$Emit("$breakRandomNum");
            // 登陆成功，同步信息到现网系统
            try {
                $Controller.oc.authentication.getLoginInfoForICrm($Gadget, $Fire);
            } catch (e) {

            }
            // add by zWX270193 2016/5/5 修改问题单，处理代办人证件信息、图片信息无法清空的问题，根据在读取代办人时的全局变量进行判断，如果为true则不清除
            if (window._ysp_top.clearDelegateFlag !== true) {
                window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};
                window._ysp_top.EinvoiceIdCardInfo.besdelegcard = '';
            } else {
                // 如果不清空，登录成功了，保存代办人信息，下一次登录时就为上一个代办人信息，需要将标志清空，为了实时清除代办人信息
                window._ysp_top.clearDelegateFlag = false;
            }
            // end by zWX270193 2016/5/5

            // 如果是证件认证或者密码+证件认证鉴权方式且读取身份证时，需要获取客户资料里的姓名及地址跟身份证上的信息进行比对
            var authCheckKey = dropList1.$input.attr('key');
            //var certType = dropList2.$input.attr('key');

            //如果是以身份证的方式登录，把经办人等信息清空，以防推送免填单时会把之前读到的经办人信息也推送过去;但户主（besservcard）的不清
            if (authCheckKey == "AuthCheckE" || authCheckKey == "AuthCheckF") {
                window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};
                window._ysp_top.EinvoiceIdCardInfo.besnewservcard = '';
                //window._ysp_top.EinvoiceIdCardInfo.besdelegcard = '';
                window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard = '';

            } else {
                //其它登录方式，全部清空~
                window._ysp_top.EinvoiceIdCardInfo = {};
            }

            if ($Gadget.authType == "AuthCheckE" || $Gadget.authType == "AuthCheckF" || $Gadget.authType == "AuthCheckB" || $Gadget.authType == "AuthCheckZ") {
                //省份证、或身份证+密码登入，清空本人经办人
                if (!window._ysp_top.EinvoiceIdCardInfo.showuploadservcard) {
                    window._ysp_top.EinvoiceIdCardInfo.besservcard = null;
                } else {
                    window._ysp_top.EinvoiceIdCardInfo.besservcard = "serv";
                }
                if (!window._ysp_top.EinvoiceIdCardInfo.showuploaddelegcard) {
                    window._ysp_top.EinvoiceIdCardInfo.besdelegcard = null;
                } else {
                    window._ysp_top.EinvoiceIdCardInfo.besdelegcard = "delegate";
                }
                window._ysp_top.EinvoiceIdCardInfo.showuploadservcard = false;
                window._ysp_top.EinvoiceIdCardInfo.showuploaddelegcard = false;
            }

            if (authCheckKey == "AuthCheckE" || authCheckKey == "AuthCheckF" || authCheckKey == "AuthCheckI" || authCheckKey == "AuthCheckG") {
                if ("HuKouBu" == $Gadget.logincertType || "IdCard" == $Gadget.logincertType) {
                	$Controller.oc.authentication.loginByReadCard($Gadget, $Page, $Fire, $UI);
                } else {
                    $Controller.oc.authentication.checkRealName($Gadget, $Page, $Fire, $UI);
                }
            } else {
                $Controller.oc.authentication.checkRealName($Gadget, $Page, $Fire, $UI);
            }
        },

        //商品快选，包含主产品营销包允许点击开户进入开户页面
        toOpenAccount: function($Gadget, $UI, $Page, $Fire) {
            debugger;
            var bundle = $Page.promotionBundle;
            if ((bundle.promotionBundle.mainOffer || []).length > 0) {
                //营销包里有主offer的情况
                $Controller.bes.oc.prodDispachUrl.closePortalTab("openvicecardaccount");
                //如果是营销工作台跳转，把recommendOid放在URL上面带到开户页面
                if (bundle.promotionBundle.recommendOid) {
                    adutil
                        .openTopTab(
                            "60131992",
                            $UEE.i18n("ad.authentication.label.openaccount") /*开户*/ ,
                            "/bes/ad/html/ctz.bes-agentdesktop-openaccount.html" + getVersionUrlStr(1) + "&offeringId=" + bundle.promotionBundle.mainOffer[0].offeringId + "&recommendOid=" + bundle.promotionBundle.recommendOid + "&#/openaccount");

                } else {
                    adutil
                        .openTopTab(
                            "60131992",
                            $UEE.i18n("ad.authentication.label.openaccount") /*开户*/ ,
                            "/bes/ad/html/ctz.bes-agentdesktop-openaccount.html" + getVersionUrlStr(1) + "&offeringId=" + bundle.promotionBundle.mainOffer[0].offeringId + "&#/openaccount");

                }


                setTimeout(function() {

                    bundle.promotionBundle.mainOffer = [];

                    if (navigator.userAgent.indexOf("MSIE") != -1) {
                        bundle = JSON.stringify(bundle);
                    }
                    
                    try {
                    	var curtabid = parent.tab.selectedItem().attr("innerid");
                    	parent.getPageById(curtabid).find("iframe")[0].contentWindow.postMessage(bundle, "*");
                    } catch (e) {}
                }, 2000);

            } else {

                //TO DO
            }

        },

        operSmAuthList: function($Gadget, olddata) {
            debugger;

            var newdata = [];

            /*$Gadget.smauthlist=[
            {
                verifyType : "AuthCheckE",
                verifyTypeName : "本人身份证件"
            },{
                verifyType : "AuthCheckB",
                verifyTypeName : "服务密码"
            }];*/

            if (($Gadget.smauthlist || []).length == 0) {
                return olddata;
            }

            $.each(olddata || [], function(i, vali) {
                $.each($Gadget.smauthlist || [], function(j, valj) {
                    if (valj.verifyType == vali.key) {
                        newdata.push(vali);
                    }
                });
            });

//            debugger;
            return newdata;

        },
        cardIdonclick: function() {
            window._ysp_top.readCardType = "0";
        },
        loginFalse: function($Gadget, $Page, $Fire, $UI) {
            debugger;
            var checkKey = dropList1.$input.attr('key');
            if (checkKey == "AuthCheckB") {
                $("#password").val("");
            }
            $("#loginbtn" + $Gadget.besMenuId).removeAttr("disabled");
        } 
    });
