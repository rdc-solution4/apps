var $doc = $(document);
var $win = $(window);
var browser = $.browser;
var isIE = browser.msie;
var browserVersion = browser.version;


/**
 * 执行一个回调
 * @param{Function} fn 目标函数
 * @param{Object} context 执行上下文
 * @param{args} args 执行参数
 */
function _callback(fn,context,args){
	if(typeof fn == "function"){
		if($.type(args) != "array"){
			return fn.call(context,args);
		}
		var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
		switch(aLen){
			case 1:
				return fn.call(context,a1);
				break;
			case 2:
				return fn.call(context,a1,a2);
				break;
			case 3:
				return fn.call(context,a1,a2,a3);
				break;
			default:
				return fn.apply(context,args);
				break;
		}
	}
}
/**
 * 比较两个数字的大小
 * @param{Number} no1 数字1
 * @param{Number} no2 数字2
 * @param{Boolean} isDesc 是否倒序（默认false）
 * @return isDesc=false时：no1>no2:+1; no1=no2:0; no1<no2:-1
 *         isDesc=true时：no1>no2:-1; no1=no2:0; no1<no2:+1
 */
function compareNumber(no1,no2,isDesc){
	isDesc = isDesc || false;
	no1 = parseFloat(no1),
	no2 = parseFloat(no2);
	return no1==no2?0:(isDesc?(no1>no2?-1:1):(no1>no2?1:-1));
}

/**
 * 比较两个时间的先后
 * @param{String} strDt1 日期1
 * @param{String} strDt2 日期2
 * @param{Boolean} isDesc 是否倒序（默认false）
 * @return isDesc=false时：dt1后于dt2:+1; dt1等于dt2:0; dt1先于dt2:-1;
 *         isDesc=true时：dt1后于dt2:-1; dt1等于dt2:0; dt1先于dt2:+1;
 */
function compareDate(strDt1,strDt2,isDesc){
	isDesc = isDesc || false;
	var d1 = new Date(""+strDt1).getTime(),
		d2 = new Date(""+strDt2).getTime();
	return d1==d2?0:(isDesc?(d1>d2?-1:1):(d1>d2?1:-1));
}

/**
 * 输入框的 Placeholder 效果
 * 使用input的placeholder属性(css3属性)来实现默认提示文字效果
 */
var _inputTemp = document.createElement("input");
var isSupportPlaceholder = ("placeholder" in _inputTemp);
var isIE9 = browser.msie && browser.version<=9;//IE9对于placeholder支持得不好，虽然也支持，它会默认不显示提示文字
if(!isSupportPlaceholder || isIE9){
	//绑定"聚焦/失焦"事件，以实现placeholder功能
	$("body").on("focus","input[placeholder]:not(.calendarInput)",function(){
		var $this = $(this);
		if($this.val()==$this.attr("placeholder")){
			$this.val("").removeClass("placeholder");
		}
	});
	$("body").on("blur","input[placeholder]:not(.calendarInput)",function(){
		var $this = $(this);
		if($this.val()==""){
			$this.val($this.attr("placeholder")).addClass("placeholder");
		}
	});
	//初始化让其显示默认提示值（placeholder属性对应的文本值）
	$("input[placeholder]:not(.calendarInput)").each(function(){
		var $this = $(this);
		if($this.val()==""){
			$this.val($this.attr("placeholder")).addClass("placeholder");
		}
	});
}
/**
 * 动态加载进来的input没办法初始化显示默认值，需要手动初始化
 * @param {Object} $range 范围
 * 说明：仅对"低端浏览器"以及"IE9"有效，因为其他高端浏览器不需要初始化，其自带这个功能
 */
function initInpPlaceholder($range){
	if(!isSupportPlaceholder || isIE9){//IE9的inout的placeholder会默认不显示
		var $outRange = $range || $("body");
		$outRange.find("input[placeholder]:not(.calendarInput)").each(function(){
			var $this = $(this);
			if($this.val()==""){
				$this.val($this.attr("placeholder")).addClass("placeholder");
			}
		});
	}else{
		return;
	}
}

/**
 * 加入收藏功能
 * @param{jQuery Object}  $fav  对应目标按钮（单个）
 * @param{Function}  fnAfterClick  点击之后处理
 */
function addFacourite($fav,fnAfterClick){
	if($fav.length!=1){
		console.log("参数错误。");
		return;
	}
	$fav.on("click",function(e){
		var $this = $(this);
		var isChecked = $this.hasClass("checked");
		$this[isChecked?"removeClass":"addClass"]("checked");
		fnAfterClick && fnAfterClick.call(this);
	});
}


/**
 *初始化建议tab页签 
 * @param {Object} $tab
 * @param {Function} fnClickHeader
 */
function initSimpleTab($tab, fnClickHeader) {
   if(!$tab.is(".tinyTabCon")){
		alert("参数错误");
		return;
	}
    var $header = $tab.children(".tinyTabHeaderCon");
    var $headerItems = $header.children(".tinyHeadItem");
    $headerItems.each(function(){
    	$(this).attr("title",$(this).text());
    });
    
    var evtType = evtType || "click";
    var $body = $tab.children(".tinyTabBodyCon");
    var $bodyItems = $body.children(".tinyTabBodyItem");
    if($bodyItems.length != $headerItems.length){
    	alert("头部个数和身体个数不一致，请检查。");
    }
    var select = function (index) {
        var $header = $headerItems.eq(index);
        var $body = $bodyItems.eq(index);
        $header.addClass("selected").siblings().removeClass("selected");
        $body.addClass("selected").siblings().removeClass("selected");
        $tab.attr("cur-sel", index);
        fnClickHeader && fnClickHeader.call($header,index,$body);
    };
    $headerItems.bind(evtType, function (e) {
        var index = $(this).index();
        select(index);
    });
    //默认选中第一个
    var defSel = $tab.attr("def-sel") || 0;
    select(defSel);
}

var needToFix = (isIE && browserVersion < 9);

//checkbox交互
function _syncChk($chk){
    var $c = $chk.parent();
    var action = $chk.is(":checked") ? "addClass" : "removeClass";
    $c[action]("checked");
}
function checkbox($label,fnAfter){
    $label.each(function () {
        var $this = $(this);
        var $checkbox = $this.children(":checkbox");
        _syncChk($checkbox);
        var $eventTatget = $checkbox;
        if (needToFix) {
            $eventTatget = $this;
        }
        $eventTatget.unbind("click").bind("click",function(e){
            var $self = $(this);
            var isLabel = $self.is("label");
            var isInput = $self.is("input");
            var isDisabled = (isLabel && $self.hasClass("disable")) || (isInput && $self.parent().hasClass("disable"));
            if(isDisabled){
            	return;
            }else{
            	needToFix && $checkbox.prop("checked", !$checkbox.prop("checked"));
	            _syncChk($checkbox);
	            fnAfter && _callback(fnAfter, this, $this);
            }
            e.stopPropagation();
        });    	
    });
}

//radio交互
function _syncRadio($radio){
	debugger;
    var $r = $radio.parent();
    var action = $radio.is(":checked") ? "addClass" : "removeClass";
    $r[action]("checked");
}
function radio($label,fnAfter){
	debugger;
    $label.each(function () {
        var $this = $(this);
        var $radio = $this.children(":radio");
        var $radios = $(document.getElementsByName($radio.attr("name")));
        _syncRadio($radio);
        var $eventTatget = $radio;
        if(needToFix) {
            $eventTatget = $this;
        }
        $eventTatget.unbind("click").bind("click", function(e){
        	var $self = $(this);
            var isLabel = $self.is("label");
            var isInput = $self.is("input");
            var isDisabled = (isLabel && $self.hasClass("disable")) || (isInput && $self.parent().hasClass("disable"));
            if(isDisabled){
            	return;
            }else{
                $radios.prop("checked", false);
	            $radio.prop("checked", true);
	            $radios.parent().removeClass("checked");
	            _syncRadio($radio);
	            fnAfter && _callback(fnAfter, this, $this);
	        }
	        e.stopPropagation();
        });
    });
}

//关闭弹窗
function closeAllDialogs(){
	$(".popWin").next(".popWinFilter").remove();
	$(".popWin").remove();
}
//此处不能加上e.stopPropagation();因为他可能还需要绑定其他事件。
$(document).on("click",".closeDialog",function(){
	closeAllDialogs();
});



//比较两个数字的大小
//isDesc=false时：no1>no2:+1; no1=no2:0; no1<no2:-1
//isDesc=true时：no1>no2:-1; no1=no2:0; no1<no2:+1
function compareNumber(no1,no2,isDesc){
	isDesc = isDesc || false;
	no1 = parseFloat(no1),
	no2 = parseFloat(no2);
	return no1==no2?0:(isDesc?(no1>no2?-1:1):(no1>no2?1:-1));
}
//compareNumber(1,2,false);

//比较两个时间的先后
//isDesc=false时：dt1后于dt2:+1; dt1等于dt2:0; dt1先于dt2:-1;
//isDesc=true时：dt1后于dt2:-1; dt1等于dt2:0; dt1先于dt2:+1;
function compareDate(strDt1,strDt2,isDesc){
	isDesc = isDesc || false;
	var d1 = new Date(""+strDt1).getTime(),
		d2 = new Date(""+strDt2).getTime();
	return d1==d2?0:(isDesc?(d1>d2?-1:1):(d1>d2?1:-1));
}
//console.log(compareDate("2014.5.6","2014.5.6",true));

/**
 * 给表排序（适用于table，ul>li）
 * @param {Object} $desListItems 被排序的jquery对象集合
 * @param {Boolean} isDesc 是否降序
 * @param {Function} fnCompare 用于进行值比较的自定义函数
 * @param {Function} fnGetSortValue 获取比较因子的方式
 * fnGetSortValue($it),参数$it是集合中的子项jquery对象,该函数一定要将“排序根据因子”作为返回值进行返回
 * 说明：本函数排序中其实只是“伪排序”，即改变的只是被排序元素显示的值以达到“视觉排序”效果，而非实质性的去改变位置
 */
function bubbleSortList($desListItems,isDesc,fnCompare,fnGetSortValue){
	if(typeof(fnCompare)!="function" || typeof(fnGetSortValue)!="function" || $desListItems.length<=1){
		console.log("无法排序(比较函数以及获取排序因子函数为空)，或者不需要排序(元素个数<=1)。");
		return;
	}
	isDesc = isDesc || false;
	console.log(isDesc?"降序∨排序:":"升序∧排序:");
	var cmp = (isDesc?"<":">");
	var arr = $desListItems.toArray();
	var count = $desListItems.length-1;
	for(var i=0;i<count;i++){
		for(var j=count;j>i;j--){
			var $it1 = $desListItems.eq(j-1),
				$it2 = $desListItems.eq(j);
			var c1 = fnGetSortValue.call(this,$it1),
				c2 = fnGetSortValue.call(this,$it2);
			//console.log("[i="+i+",j="+j+"] c1="+c1+",c2="+c2);
			if(fnCompare(c1,c2,isDesc)==1){
				//交换的仅仅是值内容，而非对象。
				//console.log("\t=> 'c1 "+cmp+" c2' =>交换。");
				var id1 = $it1.attr("id");
				var id2 = $it2.attr("id");
				var inner1 = $it1.html();
				var inner2 = $it2.html();
				//交换内容并且交换ID
				$it1.attr("id",id2).html(inner2);
				$it2.attr("id",id1).html(inner1);
			}
		}
	}
}

//对Date的扩展，将 Date 转化为指定格式的String
//月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
//年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
//例子： 
//(new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423 
//(new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18 
//修改为ad-util.js中的方法，2016/10/15 By:nwx371590
Date.prototype.Format = function(fmt) {
	var o = {
		"M+" : this.getMonth() + 1, // 月份
		"d+" : this.getDate(), // 日
		"D+" : this.getDate(), // 日
		"h+" : this.getHours(), // 小时
		"H+" : this.getHours(), // 小时
		"m+" : this.getMinutes(), // 分
		"s+" : this.getSeconds(), // 秒
		"q+" : Math.floor((this.getMonth() + 3) / 3), // 季度
		"S" : this.getMilliseconds()
	// 毫秒
	};
	if (/(y+)/.test(fmt) || /(Y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "")
				.substr(4 - RegExp.$1.length));
	for ( var k in o) {
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k])
					: (("00" + o[k]).substr(("" + o[k]).length)));
	}
	return fmt;
};

