$Controller(
		"besOcCheckoutrefundgoodlist",
		{
			init : function($Gadget, $Page, $Fire) {
				debugger;
				$Gadget.orderdetail = $Page.orderDetail || {};
				
				$Gadget.data = $Gadget.data || {};
				$Gadget.data.feeItemList = $Gadget.orderdetail.feeItemList
						|| [];
				// 角色类型
				$Gadget.data.invoiceRole = $Gadget.orderdetail.invoiceRole
						|| [];
				$Gadget.data.totalPrice = 0;
				//多货币修改
				var offerFeeResp = {};
				offerFeeResp.beId=($Page.contextForBuriedPoints || {}).beId || $Page.displayPriceInfo.beId;  
				if(($Gadget.data.feeItemList || []).length > 0)
				{
					offerFeeResp.currencyId=$Gadget.data.feeItemList[0].currencyId;
				}
				else
				{
					offerFeeResp.currencyId=null;
				}
				$Gadget.data.beId = offerFeeResp.beId;
				$Gadget.data.currencyId = offerFeeResp.currencyId;
				//设置变量，记录初始的currencyId，已经应收款
				$Gadget.data.initCurrencyId = $Gadget.data.currencyId;
				$Page.currencyType = $Gadget.data.currencyId;
				$Page.oldCurrencyType = $Page.currencyType;
				
				debugger;
				//多货币修改
				$Fire({
					service : 'gadget/sm/CurrencyAction/getCurrencies',
					params : {
						/*"beid" : _ysp_top.$BES.$ContextAccessor.getBeId()*/
						"beid" : $Page.displayPriceInfo.beId
					},
					target : "$Page.currencyTypes",
					onafter : function() {
						debugger;
						$Page.currencyTypeList=[];
						$Page.currencyTypes=$Page.currencyTypes||[];
						$.each($Page.currencyTypes,function(i,val){
							$Page.currencyTypeList.push({key:val.currencyId,value:val.currencyName});
						});
						if(!$Gadget.data.currencyId) {
							$Gadget.data.currencyId = $Page.currencyTypeList[0].key;
							//设置变量，记录初始的currencyId，已经应收款
							$Gadget.data.initCurrencyId = $Gadget.data.currencyId;
						}
						$Page.currencyType = $Gadget.data.currencyId;

						$Page.oldCurrencyType = $Page.currencyType;
					}
				},$Gadget);

				debugger;
				$Controller("besOcCheckoutrefundgoodlist").initBtnFlag($Gadget);
				$Controller("besOcCheckoutrefundgoodlist").setPrice($Gadget);
				
			},

			// 对于退费方式，如果PayMode为1：Payment On Spot和3：Cash On
			// Delivery，则显示退款，如果PayMode为2：Charge Account，则显示为充值。
			// btnFlag标志用于退费列后是否显示"取消","恢复"按钮。
			initBtnFlag : function($Gadget) {
				//debugger;
				$.each($Gadget.data.feeItemList || [], function(i, vali) {
					if (vali.payType == "1" || vali.payType == "3" || (vali.chargeItemId == "DeptPay" && vali.payType == "2" && 'JIANGSU' == $Page.projectVersion)) {
						vali.payTypeName = $UEE.i18n("ad.marketplan.label.refund");/*退款*/
						vali.enable = true;
						vali.btnFlag = true;
					} else {
						vali.payTypeName = $UEE.i18n("ad.marketplan.label.recharge");/*充值*/
						// modify by rwx203541 20151011 退款也包括退费方式为“充值”的费用
						vali.enable = true;
						vali.btnFlag = false;
					}
					if($Page.checkoutInfo.businessType == "refund") {
						vali.btnFlag = false;
					}
					if (vali.unitPrice != 0  && vali.unitPrice !=null)
					{						
						vali.unitPricePage = -vali.unitPrice;
					}
					else
					{
						vali.unitPricePage = vali.unitPrice;
					}
					if (vali.orderFee > 0  && vali.orderFee !=null)
					{
						vali.orderFeePage = -vali.orderFee;
					}
					else
					{						
						vali.orderFeePage = vali.orderFee;
					}
				});
			},

			// 点击费用列后的取消、恢复按钮
			clickbtn : function($Item, $Gadget) {
				$Item.enable = !$Item.enable;
				$Controller("besOcCheckoutrefundgoodlist").setPrice($Gadget);
			},

			// 设置显示应退款费用
			setPrice : function($Gadget) {
				debugger;
				$Gadget.data.totalPrice = 0;
				$Gadget.chargeAccountAmt = 0;
				// 冻结支付特殊处理 start
				$.each($Gadget.orderdetail.paymentInfos || [], function(i, val) {
					if("8400" == val.paymentMethod){
						$Gadget.data.freezePayAmt = val.amount;
						return;
					}
				});
				$.each($Gadget.orderdetail.custPaymentInfo || [], function(i, val) {
					if("9000" == val.paymentMethod){
						$Gadget.chargeAccountAmt = val.amount;
					}
				});
				$Gadget.data.feeItemList = $Gadget.data.feeItemList || [];
				for(var j=0;j< $Gadget.data.feeItemList.length;j++){
					if(("CreditPay" == $Gadget.data.feeItemList[j].chargeItemId || ("DeptPay" == $Gadget.data.feeItemList[j].chargeItemId && 'JIANGSU' == $Page.projectVersion)) && $Gadget.data.freezePayAmt == $Gadget.data.feeItemList[j].unitPrice){
						$Gadget.data.feeItemList.splice(j,1);
						break;
					}
				}
				// 冻结支付特殊处理 end
				$Page.judgeChargeAccount = false;
				//zwx392622 2017-11-27 DTS2017112901748
                //临时规避方案有问题
				//zwx392622 2017-12-5 DTS2017112901748
				//金额还是要全部展示在界面上，不能去掉押金不展示
				/*
				 * 临时规避方案，计算所有话费代付设备的金额
				 * 如果话费代付设备金额与账户支付金额一致，则不累计计算总额
				 */
				// var totalPhoneFee = 0;
				// $.each($Gadget.data.feeItemList || [],function (i,vali) {
				// 	if (("CreditPay" == vali.chargeItemId
				// 			 || "LuojiPrice" ==vali.chargeItemId)
				// 			 && "1" == vali.payType) {
				// 		totalPhoneFee += vali.unitPrice;
				// 	}
				// });
//				var isKDFlag = false;
//
//				$.each($Gadget.data.feeItemList || [], function(i, vali) {
//					debugger;
//					//上线前临时修改，只针对手机代付费宽带撤销场景DTS2017081105813 
//					if("3206" == vali.chargeItemId){
//						isKDFlag=true;
//					}
//				});
				$.each($Gadget.data.feeItemList || [], function(i, vali) {
					debugger;
					//上线前临时修改，只针对手机代付费宽带撤销场景DTS2017081105813 
					//zwx392622 2017-11-27 DTS2017112901748
                	//临时规避方案有问题，账户支付的信用金和裸机费不计回退费用
					//zwx392622 2017-12-5 DTS2017112901748
					//金额还是要全部展示在界面上，不能去掉押金不展示
					// if(!(("CreditPay" == vali.chargeItemId || "LuojiPrice" ==vali.chargeItemId) && "1" == vali.payType && "9000" == vali.paymentMethod)){
						
					// 	if (vali.enable) {
					// 		$Gadget.data.totalPrice += parseInt(vali.orderFee);
					// 	}
					// }
						
					if (vali.enable && ("1" == vali.payType || ("2" == vali.payType && "DeptPay" == vali.chargeItemId && 'JIANGSU' == $Page.projectVersion))) {
						$Gadget.data.totalPrice += parseInt(vali.orderFee);
					}
					
					if(("CreditPay" == vali.chargeItemId || "LuojiPrice" ==vali.chargeItemId || ("DeptPay" == vali.chargeItemId && 'JIANGSU' == $Page.projectVersion)) && "1" == vali.payType){
						$Page.judgeChargeAccount = true;
					}
				});
				
				//设置变量，记录初始的currencyId，已经应收款
				$Gadget.data.initTotalPrice = $Gadget.data.totalPrice;
				//add by rwx203541 2015101 存放在$page,支付方式gadget获取
				
				if ($Gadget.data.totalPrice > 0)
				{
					$Gadget.data.totalPricePage = -$Gadget.data.totalPrice;
				}
				else
				{
					$Gadget.data.totalPricePage = $Gadget.data.totalPrice;
				}
				//设置变量，记录初始的currencyId，已经应收款
				$Gadget.data.initTotalPricePage = $Gadget.data.totalPricePage;
				$Gadget.$Page.totalPriceDefault = -$Gadget.data.totalPrice;
				
				var priceList = [];
				priceList[0] = $Gadget.data.totalPricePage;
				$Fire({
					service : 'bes.oc.ocpcofferfeeservice/getpricedisplaylist',
					params : {
						"pricelist" : priceList,
						"currencyid" : $Page.currencyType
					},
					target : "$Gadget.priceDisplay",
					onafter : function() {
						$Gadget.data.totalPricePageDisplay = $Gadget.priceDisplay[$Gadget.data.totalPricePage];
					}
				}, $Gadget);
				// add by rwx203541 20151011 计算退费方式为充值的费用总和,自动填到退款支付方式的"充值"下（此时充值金额的最小值就是退费方式为"充值"的应退费总和）
				$Gadget.$Page.chargeTotalPrice = 0;
				$Gadget.$Page.autoChargeFillFlag = false;
				$.each($Gadget.data.feeItemList || [], function(i, vali) {
					if ('JIANGSU' == $Page.projectVersion){
						if (vali.payType == "2" && "DeptPay" != vali.chargeItemId) {
							$Gadget.$Page.autoChargeFillFlag = true;
							$Gadget.$Page.chargeTotalPrice += parseInt(vali.orderFee);
						}
					}else{
						if (vali.payType == "2") {
							$Gadget.$Page.autoChargeFillFlag = true;
							$Gadget.$Page.chargeTotalPrice += parseInt(vali.orderFee);
						}
					}
					
				});
			},

			// 同时根据退款信息生成InvoiceItem记录
			assembleInvoiceItem : function($Gadget, $Page) {
				debugger;
				$Page.serviceRequest = $Page.serviceRequest || {};
				$Page.serviceRequest.invoiceInfo = {};
				$Page.serviceRequest.invoiceInfo.invoiceItem = [];
				$.each($Gadget.data.feeItemList || [],
						function(key, val) {
							// val.orderFee就是接口返回来的数据。不需要转换成元单位
							// var amount = (adutil
							// .getStorageValueByPrecision(val.orderFee))
							// .toFixed(0);
							if (val.enable) {
								var item = {
									chargeCode : val.chargeItemId,
									payType : val.payType,
									unitPrice : val.unitPrice,
									quantity : val.quantity,
									//modify start:修复DTS2016062800084及DTS2016062902280 回退时保持原值传递即可。 modify by l00271327 20160702
							        discountAmount: val.discount,
							        waiveAmount: val.waiveAmount,
							        taxAmount: val.taxAmount,
									amount : val.orderFee,
									//modify end.
									payDirection : "RFN",
									currencyId : "1",
									feeType : val.feeType,
									refInvoiceItemId : val.invoiceItemId,
									detailInfo : $Controller("besOcCheckoutrefundgoodlist").detailInfobusi($Gadget, $Page, val.detailInfo),
									invoiceItemId : val.invoiceItemId,
									relaInvoiceItemId : val.relaInvoiceItemId
								};

								$Page.serviceRequest.invoiceInfo.invoiceItem
										.push(item);
							}
						});
				// 角色类型
				$Page.serviceRequest.invoiceInfo.invoiceRole = $Gadget.data.invoiceRole;
			},
			
			detailInfobusi : function($Gadget, $Page, data) {
				if (data && data.extInfo && data.extInfo && data.extInfo.extPropInfo && data.extInfo.extPropInfo.length > 0) {
					$.each(data.extInfo.extPropInfo || [],
							function(key, val) {
						val.paramName = val.attrId;
						val.paramValue = val.attrValue;
							});
				}
				return data;
			},
			/**
			 * 货币类型转换
			 */
			changeCurrencyType : function($Page,$Fire,$Gadget)
			{
				debugger;
				//发事件，通知支付方式组件货币类型进行相应转换
				if($Page.checkoutInfo && $Page.checkoutInfo.businessName == "业务回退") {
					$Gadget.$Emit("$bes.ad.changeCurrencyType",{fromCurrencyId : $Page.oldCurrencyType, toCurrencyId : $Page.currencyType, initCurrencyId : $Gadget.data.initCurrencyId});
				}
				//$Gadget.$Emit("$bes.ad.changeCurrencyType",{});
				if ($Gadget.data.initCurrencyId == $Page.currencyType) {
					$Page.oldCurrencyType = $Page.currencyType;
					var priceList = [];
					$Gadget.data.totalPricePage = $Gadget.data.initTotalPricePage;
					priceList[0] = $Gadget.data.totalPricePage;
					
					$Fire({
						service : 'bes.oc.ocpcofferfeeservice/getpricedisplaylist',
						params : {
							"pricelist" : priceList,
							"currencyid" : $Page.currencyType
						},
						target : "$Gadget.priceDisplay",
						onafter : function() {
							$Gadget.data.totalPricePageDisplay = $Gadget.priceDisplay[$Gadget.data.totalPricePage];
						}
					}, $Gadget);
				} else if($Page.oldCurrencyType != $Page.currencyType) {
					var priceList = [];
					priceList.push($Gadget.data.totalPricePage);
					
					$Fire({
						service : '/com.huawei.bes.sm.base.common.smcurrencyboservice/querydeststoragevalues',
						params : {
							'fromcurrencyid' : $Page.oldCurrencyType,
			          /*'beid' : _ysp_top.$BES.$ContextAccessor.getBeId(),*/
			          'beid' : $Page.displayPriceInfo.beId,
			          'tocurrencyid' : $Page.currencyType,
			          "fromstoragevalues":priceList
						},
						target : "$Gadget.priceList",
						onafter : function() {
							$Page.oldCurrencyType = $Page.currencyType;
							$Gadget.data.totalPricePage = $Gadget.priceList[0];
							
							var priceList = [];
							priceList[0] = $Gadget.data.totalPricePage;
							
							$Fire({
								service : 'bes.oc.ocpcofferfeeservice/getpricedisplaylist',
								params : {
									"pricelist" : priceList,
									"currencyid" : $Page.currencyType
								},
								target : "$Gadget.priceDisplay",
								onafter : function() {
									$Gadget.data.totalPricePageDisplay = $Gadget.priceDisplay[$Gadget.data.totalPricePage];
								}
							}, $Gadget);
						}
					},$Gadget);
				}				
			},
			
			//返回修改按钮
			btnReturnClick: function($Gadget, $Page) {
				debugger;
				if($Page.checkoutInfo && $Page.checkoutInfo.businessType == "refund") {
					$Controller.bes.ad.refund.btnReturnClick($Page);
				}
				else {
					$Controller.besAdRecrollback.btnReturnClick($Page);
				}
			}
		});
