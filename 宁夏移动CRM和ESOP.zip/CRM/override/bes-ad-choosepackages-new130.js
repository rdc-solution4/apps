$Controller("besOcChoosePackages", {
    init: function ($Gadget, $Fire, $Data) {
            debugger;
            $Page = $Gadget.$Page;
            $Gadget.recordnum = 1;
            
         // 判断是否是CSP系统调用
			if($Controller.bes.ad && $Controller.bes.ad.csp && $Controller.bes.ad.csp.common)
			{
				$Page.isCsp = $Controller.bes.ad.csp.common.isCsp();
			}
            
                //二维码业务分类信息获取
            $Gadget.qrcode = $Gadget.qrcode || {};
            $Gadget.qrcode.qrcodeInfo = $Gadget.qrcode.qrcodeInfo || {};
            // 初始化时显示全部页面
            $Gadget.tabIndex = 0;
            $Gadget.searchAttr = 'Y';
            // 构造初始化数据
            $Gadget.data = $Gadget.data || {};
            $Gadget.data.searchAllOfferingCond = true;
            $Gadget.data.childrenIDs=$Gadget.data.childrenIDs||[];
            $Gadget.choosePackage = {};
            $Gadget.choosePackage.selectItem = $.extend(true, {}, $Data);
            $Gadget.data.searchOfferingCond = {
                keyWord: '',
                extendCondition: []
            };
            $Gadget.data.pageInfo = {
                beginRowNumber: 0,
                recordPerPage: 14
            };
            /**
             * added by h00308289 默认是InstallMain
             */
            if (!$Gadget.$Attrs.scenariotype) {
                $Gadget.$Attrs.scenariotype = 'InstallMain';
            }
            
            $Controller.besOcChoosePackages.toGetHotSearchWords($Page,$Gadget);

            // 根据场景和渠道id 获取catagorylist 同时根据第一个查询对应的搜索属性
            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
            //获取省级BE
            $Fire({
                service : 'ucec/v1/common/qrysystemparambykey',
                params : {
                    key : "60101099"
                },
                target : "$Gadget.systemParaBeId",
                onafter : function($Gadget) {
                    debugger;
                    $Gadget.rootBeId = $Gadget.systemParaBeId;
                }
            }, $Gadget);
            $Fire({
                'service': 'bes.oc.occatalogqueryservice/querycategoriesbychannelandscenario',
                'params': {
                    scenariotype: $Gadget.$Attrs.scenariotype
                },
                'target': '$Gadget.data.categories',
                'onafter': function ($Gadget, $Fire) {
                    debugger;
                    $Gadget.data.rootcategories = [];
                    $.each($Gadget.data.categories || [], function (i, value) {
                        if (!value.parentId) {
                            $Gadget.data.rootcategories.push(value);
                        }
                    });

                    if ($Gadget.data.rootcategories.length > 0) {
                        //二维码销售目录信息获取
                        for (var i = 0; i < $Gadget.data.rootcategories.length; i++) {
                            if ($Gadget.data.rootcategories[i].categoryId == "6003") {
                                $Gadget.qrcode.qrcodeInfo.categoryId = $Gadget.data.rootcategories[i].categoryId;
                                $Gadget.qrcode.qrcodeInfo.categoryName = $Gadget.data.rootcategories[i].categoryName;

                                $Gadget.data.searchOfferingCond.categoryId = $Gadget.data.rootcategories[i].categoryId;
                                $Controller.besOcChoosePackages.querysearchattr($Gadget, $Fire, $Gadget.data.rootcategories[i].categoryId);
                            }
                        }
                    }
                    if(($Gadget.$Attrs.params||{}).hiddenflag){
                    	$Controller.besOcChoosePackages.clickSearch($Gadget, $Fire);
                    	return;
                    }
		    		//默认主推
                    $Gadget.initFlag = true;
                    //  US-20180131095359-2031068466 360视图中业务推荐的主套餐变更，需要跳转到变更主套餐，并要求模拟用户自动选择“主商品，商品包，包下子商品”
                    if ($Page.recommendMainOfferInfo && $Page.recommendMainOfferInfo.recommendMainOfferId) {
                    	debugger;
                    	$Gadget.initFlag = false;
                    	$Controller.besOcChoosePackages.clickAttr($Gadget,$("#dd_additionalProdrootcategoriesAll"), null,{},0);
                    }
                    $("#choosePackages #searchOfferingIcon").trigger("click");
                }
            }, $Gadget);

            $('#choosePackages .display_grid').bind('click', function () {
                if ($(this).hasClass('active')) {
                    return;
                } else {
                    $(this).addClass("active").css("background-position", "0px 0px");
                    $('#choosePackages .display_list').removeClass('active').css("background-position", "-22px -18px");
                    $('#choosePackages .item_grid').hide();
                    $('#choosePackages .item_list').show();
                }
            });

            $('#choosePackages .display_list').bind('click', function () {
                if ($(this).hasClass('active')) {
                    return;
                } else {
                    $(this).addClass("active").css("background-position", "0px -18px");
                    $('#choosePackages .display_grid').removeClass('active').css("background-position", "-22px 0px");

                    $('#choosePackages .item_list').hide();
                    $('#choosePackages .item_grid').show();
                }
            });

            // input输入框响应回车事件
            $(document).on("keydown", "#choosePackages #searchOfferingInput", function (e) {
                if (e.keyCode == 13) {
                    $("#choosePackages #searchOfferingIcon").trigger("click");
                }
            });

            $Gadget.$Emit("$bes.oc.choosepkgInited");
            //this.clickSearch($Gadget, $Fire);
        },

        choosePackageSetDefault: function ($Gadget, $Data) {
            $Gadget.choosePackage.selectItem = $.extend(true, {}, $Data);

            // 默认查询出所有的offering
            $("#choosePackages #searchOfferingIcon").trigger("click");
        },

        querysearchattr: function ($Gadget, $Fire, categoryId) {
            $Page = $Gadget.$Page
            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
            $Fire({
                'service': 'bes.oc.salescatalogqueryservice/querysearchattributebycategoryid',
                'params': {
                    categoryid: categoryId,
                    catalogid: ''
                },
                'target': '$Gadget.data.searchAttr',
                'onafter': function ($Gadget, $Fire) {
                    debugger;
                    $Gadget.tmpAttr = [];
                    $Gadget.data.searchAttrResult = $.extend(true, [], $Gadget.data.searchAttr) || [];
                    $Controller.besOcChoosePackages.pushSaleTagCon($Gadget, $Fire);
                    for (var i = 0; i < $Gadget.data.searchAttrResult.length; i++) {
                    	
                    	 try {
                    		 $Gadget.data.searchAttrResult[i].name = $.parseJSON($Gadget.data.searchAttrResult[i].name || "{}")[adutil.getLocale()];
                         } catch (e) {
                        	 $Gadget.data.searchAttrResult[i].name=$Gadget.data.searchAttrResult[i].name;

                         }
                         
                        $Gadget.data.searchAttrResult[i].options = $.parseJSON($Gadget.data.searchAttrResult[i].options);

                        if ($Gadget.data.searchAttrResult[i].code != "C_O_BRAND") {
                            $Gadget.tmpAttr.push($Gadget.data.searchAttrResult[i]);
                        }
                        if ($Gadget.data.searchAttrResult[i].code == "C_O_BRAND") {
                            //保存原始品牌属性，用于查询offer
                            $Gadget.data.topBrandAttr = $Gadget.data.searchAttrResult[i];
                            $Gadget.data.topBrandAttr.index = i;
                            //"品牌大类"
                            $Gadget.data.topBrandAttr.name = $UEE.i18n("ad.person.title.Brand");
                            $Gadget.data.topBrandAttr.options = [];
                            $Gadget.data.topBrandAttr.isTopBrand = true;
                            
                            $Controller.besOcChoosePackages.queryBrand($Gadget, $Fire);
                        }
                    }
                }
            }, $Gadget);
        },
        //查询大品牌及其小品牌
        queryBrand: function ($Gadget, $Fire) {
            debugger;

            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
            $Fire({
                'service': 'ucec/v1/pcBrandQuery/queryAllTopAndChildBrands',
                'target': '$Gadget.data.allTopAndChildBrandsRes',
                'onafter': function ($Gadget, $Fire) {
                    debugger;
                    if (!$Gadget.data.allTopAndChildBrandsRes || !$Gadget.data.allTopAndChildBrandsRes.body || !$Gadget.data.allTopAndChildBrandsRes.body.brandPOJOs) {
                        return;
                    }

                    $Gadget.allOptions = [];
                    $Gadget.data.allTopAndChildBrands = $Gadget.data.allTopAndChildBrandsRes.body.brandPOJOs;
                    for (var i = 0; i < $Gadget.data.allTopAndChildBrands.length; i++) {
                        var item = {};
                        item.childBrands = [];
                        try{
                        	item.LABEL  =  $.parseJSON($Gadget.data.allTopAndChildBrands[i].topBrand.brandName || "{}")[adutil.getLocale()];
                        }
                        catch(e){
                        	item.LABEL = $Gadget.data.allTopAndChildBrands[i].topBrand.brandName;
                        }
                        
                        item.VALUE = $Gadget.data.allTopAndChildBrands[i].topBrand.brandId;
                        item.isTopBrand = true;
                        $Gadget.data.topBrandAttr.options.push(item);
                        var childBrands = $Gadget.data.allTopAndChildBrands[i].childBrands;
                        if (childBrands && childBrands.length > 0) {
                            for (var j = 0; j < childBrands.length; j++) {
                                var chldItem = {};
                                try{
                                	chldItem.LABEL  =  $.parseJSON(childBrands[j].brandName || "{}")[adutil.getLocale()];
                                }
                                catch(e){
                                	chldItem.LABEL = childBrands[j].brandName;
                                }
                                
                                chldItem.brandId = childBrands[j].brandId;
                                chldItem.isTopBrand = false;
                                item.childBrands.push(chldItem);
                                $Gadget.allOptions.push(chldItem);
                            }
                        }

                    }

                    $Gadget.data.chldBrandAttr = $.extend(true, {}, $Gadget.data.topBrandAttr);
                    $Gadget.data.chldBrandAttr.$$hashKey = "000XX";//jquery拷贝出来对象hashKey相同，angularjs报错
                    $Gadget.data.chldBrandAttr.id = "chldBrandAttr";
                    //"品牌小类"
                    $Gadget.data.chldBrandAttr.name = $UEE.i18n("ad.person.label.SubBrand");
                    $Gadget.data.chldBrandAttr.isTopBrand = false;
                    $Gadget.data.chldBrandAttr.options = $Gadget.allOptions;
                    //$Gadget.data.searchAttrResult.splice($Gadget.data.topBrandAttr.index + 1, 0, $Gadget.data.chldBrandAttr);
                    $Gadget.data.searchAttrResult.push($Gadget.data.chldBrandAttr);
                    
                    $Gadget.tmpAttr.unshift($Gadget.data.chldBrandAttr);
                    $Gadget.tmpAttr.unshift($Gadget.data.topBrandAttr);

                    //$Gadget.data.searchAttrResult = $.extend(true, [], $Gadget.tmpAttr);
                    for (var k = 0;k < $Gadget.data.searchAttrResult.length; k++) {
                        if ($Gadget.data.searchAttrResult[k].$$hashKey == "000XX") {
                            $Gadget.data.chldBrandAttr.index = k;
                        }
                    }
                }
            }, $Gadget);


        },
        pushSaleTagCon: function ($Gadget, $Fire) {
            debugger;
            var isneedpush = true;
            for (var i = 0; i < $Gadget.data.searchAttrResult.length; i++) {
                if ("C_O_SALE_TAGS" == $Gadget.data.searchAttrResult[i].code) {
                    isneedpush = false;
                    break;
                }
            }
            if (isneedpush) {
                $Gadget.data.searchAttrResult.push({
                    id: "99999999",
                    code: "C_O_SALE_TAGS",
                    //销售标签
                    name: "{\"zh_CN\":\"" + $UEE.i18n("ad.person.title.SalesTag") + "\",\"en_US\":\"" + $UEE.i18n("ad.person.title.SalesTag") + "\"}",
                    order: $Gadget.data.searchAttrResult.length + 1,
                    inputType: "SINGLE_SEL",
                    isMulti: "N",
                    //主推  热销 最新
                    options: "[{\"LABEL\":\"" + $UEE.i18n("ad.person.title.Recommended") + "\",\"VALUE\":\"3\"},{\"LABEL\":\"" + $UEE.i18n("ad.person.title.Popular") + "\",\"VALUE\":\"1\"},{\"LABEL\":\"" + $UEE.i18n("ad.person.title.Latest") + "\",\"VALUE\":\"2\"}]"
                });
            }
        },

        queryOfferingList: function ($Gadget, $Fire, callback) {
            debugger;
            $Page = $Gadget.$Page;
            //$Page.mainOffer = $.extend(true, {}, $Gadget.data.mainOffering);
            //$Page.mainOffer.offeringId=$Page.mainOffer.offerId;
    		$Gadget.data.searchOfferingCond.queryType = "searchMainOffering";
    		$Gadget.data.searchOfferingCond.keyWord = $Gadget.hotKeyWords || $.trim($Gadget.data.searchInput || "");
    		if($Gadget.hotKeyWords)
    			$Gadget.hotKeyWords = null;
    		$Gadget.data.searchOfferingCond.recType = $Gadget.$Attrs.businesscode;
    		
    		// 主产品变更，只获取当前主产品允许变更的主产品list
    		if ($Page.mainOffer) {
    			$Gadget.data.searchOfferingCond.queryType = "changeMainOffering";
    			
    			if($Gadget.data && $Gadget.data.mainOffering){
    				$Page.mainOffer = $.extend(true, {}, $Gadget.data.mainOffering);
    				$Page.mainOffer.offeringId=$Page.mainOffer.offerId;
    			}
                
                if($Gadget.data.categories && $Gadget.data.categories.length > 0){
    			    $Gadget.data.searchOfferingCond.catalogId = $Gadget.data.categories[0].catalogId;
                }
                $Gadget.data.searchOfferingCond.mainOfferingId = $.trim($Page.mainOffer.offeringId || "");
    			if($Page.needPaymentMode != null && $Page.needPaymentMode != ""){
    				$Gadget.data.searchOfferingCond.paymentMode = $Page.needPaymentMode;
    			}
    		}

            //两城一号
            $Gadget.data.searchOfferingCond.beId = ($(document).scope().$Page.userInfo || {}).beID;
           
            // modify by wuyuxin/wx175926 for DTS2015102307309
            //批量主体产品变更 批量增值产品变更时$Page.mainOffer为undefine，也需要pc过滤
            var searchOfferingCondParam = $Gadget.data.searchOfferingCond;
            if($Gadget.$Attrs.productidlist && $Gadget.$Attrs.productidlist.length !=0){
            	//开户时 主体产品变更，此时未提交，需要将所有offer信息全部查询出来，无需pc过滤 
            	searchOfferingCondParam = $.extend(true, {
            		productList: $Gadget.$Attrs.productidlist ? $Gadget.$Attrs.productidlist : null
            	}, $Gadget.data.searchOfferingCond);
            }
	    	 if(($Gadget.data || {}).pageInfo){
	         	$Gadget.data.pageInfo.totalRecord = 0;
	         }
			 
			if ($Gadget.data.searchAllOfferingCond) {
				searchOfferingCondParam.categoryId = null;
			}
			 
            
            
            if (($Gadget.$Attrs.params||{}).groupType == "GrpPrdHome4GShare")
            {
            	//searchOfferingCondParam.extendCondition = searchOfferingCondParam.extendCondition || [];
            	//searchOfferingCondParam.extendCondition.push({"conditionId":"PM_HOMESHAREOFFER","conditionValue":["1"]});
            	searchOfferingCondParam.offeringIdList = ['1380000054','1380000052','1380000053']
            }
            
            if($Gadget.$Attrs.businesscode == 'M2MInstall'){
            	searchOfferingCondParam.catalogId = '7001';
            }
            $Controller.besOcChoosePackages.queryoffer4lastestonline($Gadget, $Fire,$Page);
            //清空二维码的设置
            searchOfferingCondParam.queryCodeContent = null;
            //  US-20180131095359-2031068466 360视图中业务推荐的主套餐变更，需要跳转到变更主套餐，并要求模拟用户自动选择“主商品，商品包，包下子商品”
            if ($Page.recommendMainOfferInfo && $Page.recommendMainOfferInfo.recommendMainOfferId) {
            	debugger;
            	$Gadget.data.pageInfo.recordPerPage = "1000";
            }
            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
            $Fire({
                'service': 'bes.oc.pcsearchex4telecomqueryservice/queryofferlist',
                'params': {
                    'searchofferingcond': searchOfferingCondParam,
                    'pageinfo': $Gadget.data.pageInfo
                },
                'target': '$Gadget.data.packageInfo',
                'onafter': function ($Gadget) {
                	debugger;
                	//清除查询条件
                	$Gadget.data.searchOfferingCond.saleTagList = [];
                	  //站内搜索埋点 add by p00354016
					var currentPage = $Gadget.data.pageInfo.beginRowNumber / $Gadget.data.pageInfo.recordPerPage + 1;
					var searchResult;
					
					if (!$Gadget.data.packageInfo || !$Gadget.data.packageInfo.offeringList
							|| $Gadget.data.packageInfo.offeringList.length<=0) {
						searchResult = 0;
						currentPage = 0;
					}
					else {
						searchResult = 1;
					}
					var keyWord = $Gadget.data.searchOfferingCond.keyWord;
					if (keyWord!=undefined && keyWord !=null && keyWord != ""){
						$BuriedPoinStat.searchstat(keyWord, "product", searchResult, currentPage);
					}
					//站内搜索埋点 end
                    $Gadget.data.packageInfo = $Gadget.data.packageInfo || {};
                    
                    //  US-20180131095359-2031068466 把其他主商品隐藏
                    if ($Page.recommendMainOfferInfo && $Page.recommendMainOfferInfo.recommendMainOfferId) {
                    	debugger;
                    	$Gadget.recommendMainOfferList = [];
                    	$.each($Gadget.data.packageInfo.offeringList || [],function(i,val){
                    		if (val.offeringId == $Page.recommendMainOfferInfo.recommendMainOfferId) {
                    			$Gadget.recommendMainOfferList.push(val);
                    		}
                    	});
                    	$Gadget.data.packageInfo.offeringList = $Gadget.recommendMainOfferList;
                    }
                    
                    //商品排序
                    if(($Gadget.data.packageInfo.offeringList || []).length > 0)
                    	$Gadget.data.packageInfo.offeringList = adutil.sortsearchofferinglist($Gadget.data.packageInfo.offeringList);
                    
                    $Gadget.data.packageInfoCopy = $Gadget.data.packageInfo;
                    
                    if ($Gadget.recommendMainOfferList && $Gadget.recommendMainOfferList.length > 0) {
                    	$Gadget.$Emit("$bes.oc.setRecommendMainOffer", $Gadget.recommendMainOfferList[0]);
                    }
                    callback.call(this);	 
                }
            }, $Gadget);
        },
        
        queryoffer4lastestonline: function($Gadget, $Fire,$Page){
        	debugger;
        	 OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
             $Fire({
                 'service': 'bes.oc.pcsearchex4telecomqueryservice/queryofferlist',
                 'params': {
                     'searchofferingcond': {
                    	 "keyWord":"",
                    	 "extendCondition":[],
                    	 "queryType":"searchMainOffering",
                    	 "categoryId":null,
                    	 "queryCodeContent":null,
                    	 saleTagList : ['2']
                     },
                     'pageinfo': {
                    	 "beginRowNumber":0,
                    	 "recordPerPage":20,
                    	 "totalRecord":0
                     }
                 },
                 'target': '$Gadget.data.lastestOnlineOffers',
                 'onafter': function ($Gadget) {
                 	debugger;
                 	
                 }
             },$Gadget);
        },

        clickSearch: function ($Gadget, $Fire) {
            if ($Gadget.tabIndex == 1) {
            	$Gadget.tabIndex = 0;//使用过后重新赋值为0；
                $Controller.besOcChoosePackages.queryFavoriteInfo($Gadget, $Fire, 0);
                return;
            }
            
            if($Gadget.initFlag){
            	$Gadget.initFlag = false;
            	//主推
				$Gadget.data.searchOfferingCond.saleTagList = ['3'];
            }

            $Gadget.data.pageInfo.beginRowNumber = 0;
            $Controller.besOcChoosePackages.queryOfferingList($Gadget, $Fire, function () {
                $("#choosePackagePages").empty();
                if ($Gadget.data.packageInfo.offeringList && $Gadget.data.packageInfo.offeringList.length > 0) {
                    $Gadget.data.pages = new UCD.Pages($("#choosePackagePages"),
                        $Gadget.data.packageInfo.pageInfo.totalRecord, $Gadget.data.pageInfo.recordPerPage, [14], 1);
                } else {
                    $Gadget.data.pages = null;
                }

                $Controller.besOcChoosePackages.setDisplayOfferingList($Gadget);
            });
        },

        setDisplayOfferingList: function ($Gadget) {
            $.each($Gadget.data.packageInfo.offeringList || [], function (i, val) {
                //hot
                if (val.salesTagList && val.salesTagList[0].salesTagId == '1') {
                    val.addedclass = 'tag_hot';
                    val.tagclass = 'tag_hot_list';
                }
                //new
                if (val.salesTagList && val.salesTagList[0].salesTagId == '2') {
                    val.addedclass = 'tag_new';
                    val.tagclass = 'tag_new_list';
                }
                //sale
                if (val.salesTagList && val.salesTagList[0].salesTagId == '3') {
                    val.addedclass = 'tag_sale';
                    val.tagclass = 'tag_sale_list';
                }
                // 设置radio信息
                var selected = false;
                if ($Gadget.choosePackage.selectItem && $Gadget.choosePackage.selectItem.offeringId == val.offeringId) {
                    selected = true;
                    $Gadget.choosePackage.selectItem = $.extend(true, {}, val);
                }

                $Gadget.data.packageInfo.offeringList[i].radioHash = {
                    text: "",
                    group: "packages",
                    selected: selected,
                    onChange: function (settings) {
                        $Gadget.$apply(function () {
                            $Gadget.choosePackage.selectItem = $.parseJSON(settings._settings.$container.attr("data-item"));
                        });
                        $("#packageListLi" + $Gadget.choosePackage.selectItem.offeringId).siblings().removeClass('active').end().addClass('active');
                    }
                };

                // 显示价格
                $Gadget.data.packageInfo.offeringList[i].displayPrice = adutil.getDisplayPrice(val.minPriceValue, val.maxPriceValue);
            });
        },

        clickcatalog: function ($Gadget, $Fire, $Target, $ItemRoot, level) {
            $Target.siblings().removeClass('active').end().addClass('active');

            $Gadget.data.searchOfferingCond.categoryId = $ItemRoot.categoryId;

            //二维码销售目录信息获取
            $Gadget.qrcode.qrcodeInfo.categoryId = $ItemRoot.categoryId;
            $Gadget.qrcode.qrcodeInfo.categoryName = $ItemRoot.categoryName;
            this.querysearchattr($Gadget, $Fire, $ItemRoot.categoryId);
        },

        //点击销售目录
        clickAttr: function ($Gadget, $Target, $Attr, $Item,level) {
            debugger;
            if ($Target.hasClass("active")) {
                return;
            }
            
            if($Item && $Item.key == 'recommend'){
            	//主推
				$Gadget.data.searchOfferingCond.saleTagList = ['3'];
            }
            
            if($Page.isCsp){
            	var mainBrandIdList = [];
                if ($Item.code == "C_O_BRAND") {
                    //品牌大类
                    if ($Item.isTopBrand) {
                        $("#dd_choosePackageAll" + $Gadget.data.chldBrandAttr.index).addClass('active');
                        //ALL
                        if (!$Attr) {
                            $Gadget.data.chldBrandAttr.options = $Gadget.allOptions;
                            for (var i = 0; i < $Item.options.length; i++) {
                            	mainBrandIdList.push($Item.options[i].VALUE);
                            }
                        } else {
                            //具体大品牌
                            $Gadget.data.chldBrandAttr.options = $Attr.childBrands;
                            mainBrandIdList.push($Attr.VALUE);
                        }
                        //设置搜索品牌为所有小品牌
                        for (var i = 0; i < $Gadget.data.chldBrandAttr.options.length; i++) {
                            mainBrandIdList.push($Gadget.data.chldBrandAttr.options[i].brandId);
                        }
                    } else {
                        //品牌小类
                        //ALL
                        if (!$Attr) {
                            //设置搜索品牌为所有小品牌
                            for (var i = 0; i < $Gadget.data.chldBrandAttr.options.length; i++) {
                                mainBrandIdList.push($Gadget.data.chldBrandAttr.options[i].brandId);
                            }
                        } else { //具体小品牌
                            //设置搜索品牌为具体小品牌
                            mainBrandIdList.push($Attr.brandId);
                        }
                    }
                    $Gadget.data.searchOfferingCond.mainBrandIdList = mainBrandIdList;
                }


                $Gadget.data.searchOfferingCond.extendCondition = [];
                //$Item.inputType="M";
                if ("SINGLE_SEL" == $Item.inputType) {
                    $Target.siblings().removeClass('active').end().addClass('active');

                    var extendCondition = $.extend(true, [], $Gadget.data.searchOfferingCond.extendCondition);
                    var isExist = false;
                    $.each(extendCondition, function (i, val) {

                        if ($Item.id == val.conditionId) {
                            isExist = true;
                            if (!$Attr) {
                                $Gadget.data.searchOfferingCond.extendCondition.splice(i, 1);
                            } else {
                                $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue = [$Attr.VALUE];
                            }
                            return;
                        }
                    });
                    //不通过品牌属性来查offer
                    if (!isExist && $Attr && "C_O_SALE_TAGS" != $Item.code && $Item.code != "C_O_BRAND") {
                        $Gadget.data.searchOfferingCond.extendCondition.push({
                            conditionId: $Item.id,
                            conditionValue: [$Attr.VALUE]
                        });
                    }
                    if ("C_O_SALE_TAGS" == $Item.code) {
                        $Gadget.data.searchOfferingCond.saleTagList = [];
                        $Gadget.data.searchOfferingCond.saleTagList.push($Attr.VALUE);
                    }
                } else {
                    var active = false;
                    if ($Target.hasClass('active')) {
                        $Target.siblings() && $Target.siblings()[0] && ($Target.siblings()[0].className = "");
                        $Target.removeClass('active');
                    } else {
                        active = true;
                        $Target.siblings() && $Target.siblings()[0] && ($Target.siblings()[0].className = "");
                        $Target.addClass('active');
                    }

                    var extendCondition = $.extend(true, [], $Gadget.data.searchOfferingCond.extendCondition);
                    var isExist = false;
                    $.each(extendCondition, function (i, val) {
                        if ($Item.id == val.conditionId) {
                            isExist = true;
                            if (!$Attr) {
                                $Target.siblings().removeClass('active');
                                $Gadget.data.searchOfferingCond.extendCondition.splice(i, 1);
                            } else {
                                $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue = $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue || [];
                                if (active) {
                                    $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue.push($Attr.VALUE);
                                } else {
                                    var index = -1;
                                    for (var j = 0; j < $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue.length; j++) {
                                        if ($Gadget.data.searchOfferingCond.extendCondition[i].conditionValue[j] == $Attr.VALUE) {
                                            index = j;
                                            break;
                                        }
                                    }

                                    $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue.splice(index, 1);
                                }
                            }
                            return;
                        }
                    });

                    if (!isExist && $Attr) {
                        $Gadget.data.searchOfferingCond.extendCondition.push({
                            conditionId: $Item.id,
                            conditionValue: [$Attr.VALUE]
                        });
                    }
                }
            }else{
            	$Target.siblings().removeClass('active');
                $Target.addClass('active');

                //
    			// 生成子层级
                $Gadget.data.levelCategoryName = [$UEE.i18n("ad.person.label.SecondCategory"),$UEE.i18n("ad.person.label.ThirdCategory"),$UEE.i18n("ad.person.label.ForthCategory"),
    			                                  $UEE.i18n("ad.person.label.FifthCategory"),$UEE.i18n("ad.person.label.SixthCategory"),$UEE.i18n("ad.person.label.SeventhCategory"),
    			                                  $UEE.i18n("ad.person.label.EighthCategory"),$UEE.i18n("ad.person.label.NinthCategory"),$UEE.i18n("ad.person.label.TenthCategory")];
    			var length = $Gadget.data.childrenIDs.length;
    			if (length > level) {
    				if (0 == level) {
    					$Gadget.data.childrenIDs = [];
    				} else {
    					$Gadget.data.childrenIDs.splice(level, length - level);
    				}
    			}
    			
    			var parentId = null;
    			if($Item){
    				parentId = $Item.categoryId;
    			}
    			
    			if(parentId){
    				$.each($Gadget.data.categories,function(i, value) {
    					if (value.parentId && (value.parentId == parentId )) {
    						$Gadget.data.childrenIDs[level] = $Gadget.data.childrenIDs[level] || [];
    						$Gadget.data.childrenIDs[level].index = level;
    						$Gadget.data.childrenIDs[level].push(value);
    						$Gadget.data.childrenIDs[level].levelCategoryName = $Gadget.data.levelCategoryName[level];
    					}
    				});
    			}/*else if(!$Item.id){
    				//点击全部的时候重新初始化
					$Gadget.data.searchAllOfferingCond = true;
    				$Gadget.$Emit('$bes.oc.choosePackagesInit');
    				return;
    			}*/
    			
    			$Gadget.data.searchAllOfferingCond = false;
				
    			if(level==0 || !$Attr || !$Attr.categoryId){
    				$Gadget.data.searchOfferingCond.categoryId = $Item.categoryId;
    			}else{
    				$Gadget.data.searchOfferingCond.categoryId = $Attr.categoryId;
    			}
            }
            $("#choosePackages #searchOfferingIcon").trigger("click");
        },

        clickPageNum : function($Gadget, $Fire, event) {
			debugger;
			if ($(event.target).hasClass("disabled")){
				return;
			}
            if ($Gadget.tabIndex == 0) {
                setTimeout(function () {
                    debugger;
                    if ($Gadget.data.pages) {
                        var selection = $Gadget.data.pages.getSelection() > 0 ? $Gadget.data.pages.getSelection() - 1 : 0;
                        $Gadget.data.pageInfo.beginRowNumber = selection * $Gadget.data.pageInfo.recordPerPage;

                        $Controller.besOcChoosePackages.queryOfferingList($Gadget, $Fire, function () {
                            if ($Gadget.data.packageInfo.pageInfo) {
                                $Gadget.data.pages.setTotal($Gadget.data.packageInfo.pageInfo.totalRecord);
                            } else {
                                $Gadget.data.pages.setTotal(0);
                            }

                            $Controller.besOcChoosePackages.setDisplayOfferingList($Gadget);
                        });
                    }
                }, 0);
            } else {
                setTimeout(function () {
                    debugger;
                    if ($Gadget.data.pages) {
                        var selection = $Gadget.data.pages.getSelection() > 0 ? $Gadget.data.pages.getSelection() - 1 : 0;

                        $Controller.besOcChoosePackages.queryFavoriteInfoByFire($Gadget, $Fire, selection);
                    }
                }, 0);
            }
        },

        selectPackage: function ($Gadget, $Target, $Item) {
            debugger;
            $Gadget.choosePackage.selectItem = $Item;
        },

        selectFavoritePackage: function ($Gadget, offeringId, promotionOfferId, $Fire, favoriteType,
            $UI, $index) {
            debugger;
            $Page = $Gadget.$Page
            $Gadget.params = {
                sceneCode: "SCENE_FAVORITE_PACKAGE_ORDER",
                offeringId: offeringId,
                // 如果收藏的为档次，则promotionOfferId为活动的offerID,如果不是档次，则与offeringid相同
                promotionOfferingId: promotionOfferId,
                maintainType: favoriteType
            };

            var realIndex = $index + $Gadget.favoriteSelectedPage * 6;
            if (favoriteType == 'UNFAVORITE') {
                $Gadget.params.relId = $Gadget.favoriteList.body.relIdList[realIndex];
            }
            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
            $Fire({
                'service': 'favoriteservice/maintainfavorite',
                'params': {
                    'body': $Gadget.params
                },
                'target': '$Gadget.favorite',
                'onafter': function ($Gadget) {
                    debugger;
                    if ($Gadget.favorite.body.retCode == 0) {
                        if (favoriteType == 'FAVORITE') {
                        	//收藏成功。
                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.AddedSuccessfully"));
                        } else {
                        	//取消收藏成功。
                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RemovedSuccessfully"));
                            $Gadget.data.packageInfo.offeringList.splice($index, 1);
                            $Gadget.favoriteList.body.relIdList.splice(realIndex, 1);

                        }
                    } else if ($Gadget.favorite.body.retCode == 1) {
                    	//该商品已被收藏
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.OfferingHasAdded"));
                    } else if ($Gadget.favorite.body.retCode == 2) {
                        if (favoriteType == 'FAVORITE') {
                        	//收藏失败。
                            $UI.msgbox.error($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.AddedFailed"));
                        } else {
                        	//取消收藏失败。
                            $UI.msgbox.error($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RemovedFailed"));
                        }
                    }
                }

            }, $Gadget);
        },

        confirmSelectPackage: function ($Gadget, $Target, $Item, $Fire) {
            debugger;
            $Page = $Gadget.$Page;
            if(($Page.choosedMainOffer||{}).offeringId == $Item.offeringId){
            	return;
            }
            //置空原来选择的主产品
            $Gadget.selectPackage=null;
            if(!$Page.addTo || $Page.addTo!="addMember"){
            	// modify by z00283015 for DTS2015100802168  on 2015/10/09
            	// 切换成小区宽带主销售品时应跳转到小区宽带开户页面
            	if (($Item.prodTypeList||[])[0] == 'PTCellBroadband' || ($Item.prodTypeList||[])[0] == 'PTCampusBroadband') {
            		var tabid = $BES.$Portal.tabpanel.getTabItem().key;
            		closePortalTab(tabid);
            		adutil
            		.openTopTab(
            				"60131_broadbandaccount",
            				$UEE.i18n("ad.person.title.BroadbandRegistration"),//"宽带开户"
            				"/bes/ad/html/bes-agentdesktop-broadbandopen.html"+getVersionUrlStr(1)+"&offeringId=" + $Item.offeringId + "&#/broadbandaccount");
            		return;
            	}
            }
            this.selectPackage($Gadget, $Target, $Item);


            /*----------- added by h00308289--------*/
            //因为前段offering模型开户和产品变更不一致 所以后续的offering详情都不需要
            if (!$Page.mainprodchangenew && (adutil.getGadgetObj($(".bes-agentdesktop-personalunifiedview")) || {}).isPersonalUnified) {
                $Gadget.$Emit('$bes.oc.packageSelected', {
                    offeringId: $Item.offeringId
                });
                $Fire({
                    "popin": ""
                });
                return;
            }
            if($Page.mainprodchangenew){
            	
            	$Controller.bes.ad.personalmainofferchange.offerChangeValidate($Page,$Item,$Gadget);
            }
            /*-------end-----*/

            /*----------- added by z00293500--------*/
            //因为前段offering模型开户和产品变更不一致 所以后续的offering详情都不需要，新已开业务
            if ((adutil.getGadgetObj($(".bes-ad-pc-newopenbusiness")) || {}).isnewopenbusiness) {
                $Gadget.$Emit('$bes.oc.packageSelected', {
                    offeringId: $Item.offeringId
                });
                $Fire({
                    "popin": ""
                });
                return;
            }
            /*-------end-----*/

            /*----------- added by c00318663--------*/
            //因为前段offering模型开户和产品变更不一致 所以后续的offering详情都不需要，商品订购
            if ((adutil.getGadgetObj($(".bes-oc-productorder")) || {}).isProdOrder) {
                $Gadget.$Emit('$bes.oc.packageSelected', {
                    offeringId: $Item.offeringId
                });
                $Fire({
                    "popin": ""
                });
                return;
            }
            
            if($Gadget.$Attrs.searchofferdetail == 'false'){
            	
            	$Gadget.$Emit('$bes.oc.packageSelected', {
                    offeringId: $Item.offeringId
                });
            	return;
            }
            /*-------end-----*/

            if($Page.isnewopenbusiness && $Page.changemainoffer)
            {
            	$Gadget.$Emit('$bes.oc.packageSelected', {
                    offeringId: $Item.offeringId
                });
            	return;
            }
            
            if($Page.isPreToPost)
            {
            	$Gadget.$Emit('$bes.oc.packageSelected', {
                    offeringId: $Item.offeringId
                });
            	return;
            }
            
            if ($Gadget.choosePackage.selectItem) {
                OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
                $Fire({
                    service: 'bes.oc.queryofferdetailservice/queryofferdetail',
                    params: {
                        "offerid": $Gadget.choosePackage.selectItem.offeringId,
                        "condition": {
                            "businessCode": $Gadget.$Attrs.businesscode,
                            "mainOfferingId": $Gadget.choosePackage.selectItem.offeringId
                        }
                    },
                    target: '$Gadget.data.offerInfoPOJO',
                    onafter: function () {
                        debugger;
                        if($Page.addTo=="addMember"){
                        	//跳转家庭融合IMS固话服务
                        	if($Gadget.data.offerInfoPOJO && $Gadget.data.offerInfoPOJO.ocProductInfoVA){
                        		var ocPcProductIdentityTRSVO = $Gadget.data.offerInfoPOJO.ocProductInfoVA[0].ocPcProductIdentityTRSVO;
                        		for(var i=0; i<(ocPcProductIdentityTRSVO || []).length; i++){
                        			if (ocPcProductIdentityTRSVO[i].isMain == "Y"){
                        					if (ocPcProductIdentityTRSVO[i].idenTypeCode == "MSISDN12") {
                        					debugger;
                        					$Page.offeringInfo = $Gadget.data.offerInfoPOJO;
                        					$Page.offeringInfo.ocProductInfoVA[0].constructExInfo = {};
                        					$Page.idenTypeCode = "MSISDN12";
                        					$Page.IMSofferingId=$Gadget.choosePackage.selectItem.offeringId;
                        					$Page.isClickBtn = false;
                        					$Controller.besOcChoosePackages.closePopup($Fire);
                        					$Gadget.$Emit('$bes.ad.family.openMSIAccountPop');
                        					return;
                        				}
										// 小区宽带开户或者校园宽带
										else if (ocPcProductIdentityTRSVO[i].idenTypeCode == "BroadBandAccountId") {
											debugger;
											$Page.idenTypeCode = "BroadBandAccountId";
											$Page.isClickBtn = false;
											$Controller.besOcChoosePackages.closePopup($Fire);
											$Gadget.$Emit('$bes.ad.family.openMSIAccountPop', $Gadget.data.offerInfoPOJO);
											return;
										}
                        			}
                        		}
                        	}
                        }
                        if ($Gadget.$Attrs.searchrelaaddiprod == "true") {
                            $Gadget.$Page.relaAddiProdList = [];
                            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
                            
                            var businesscode = $Gadget.$Attrs.businesscode;
                            if ($Gadget.$Page.rectype == "batchmainprodchange") {
                            	businesscode = "TRS";
                            	
                            	if($Page.polandDisEffectiveMode){
        							if($Gadget.data.offerInfoPOJO&&$Gadget.data.offerInfoPOJO.paymentMode=="0"){
        								
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effectiveTypes=[];
        								var iEffectiveType = {"key":"I","value":$UEE.i18n('ad.person.option.ImmediateEffect'),"selected":true,
        					            		"businessCode":"TRS","primaryOfferingId":"ALL","beId":null,
        					            		"chgAffectDate":"N","priority":null,"durationUnit":null,
        					            		"durationValue":null,"fixStartDate":null};
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effModeDisabled=true;
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effectiveTypes.push(iEffectiveType);
        								$Gadget.data.offerInfoPOJO.selectedMode = "I";
        								var nextEffectiveType = {"key":"N","value":$UEE.i18n('ad.group.label.NEXTMONTHEFFECTIVE'),"selected":false,
        					            		"businessCode":"ALL","primaryOfferingId":"ALL","beId":$Page.beId,
        					            		"chgAffectDate":"N","priority":null,"durationUnit":null,
        					            		"durationValue":null,"fixStartDate":null};
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effectiveTypes.push(nextEffectiveType);
        								
        							}
        							if($Gadget.data.offerInfoPOJO&&$Gadget.data.offerInfoPOJO.paymentMode=="1"){
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effectiveTypes=[];
        								
        								var iEffectiveType = {"key":"I","value":$UEE.i18n('ad.person.option.ImmediateEffect'),"selected":false,
        					            		"businessCode":"ALL","primaryOfferingId":"ALL","beId":null,
        					            		"chgAffectDate":"N","priority":null,"durationUnit":null,
        					            		"durationValue":null,"fixStartDate":null};
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effectiveTypes.push(iEffectiveType);
        								var nextEffectiveType = {"key":"N","value":$UEE.i18n('ad.group.label.NEXTMONTHEFFECTIVE'),"selected":true,
        					            		"businessCode":"ALL","primaryOfferingId":"ALL","beId":$Page.beId,
        					            		"chgAffectDate":"N","priority":null,"durationUnit":null,
        					            		"durationValue":null,"fixStartDate":null};
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effModeDisabled=false;
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.effectiveTypes.push(nextEffectiveType);
        								$Gadget.data.offerInfoPOJO.ocEffectiveMode.selectedMode = "N";
        								$("#sel_emainffTypeDroplist"+$Gadget.data.offerInfoPOJO.offerId +" .inputbox").val($UEE.i18n('ad.group.label.NEXTMONTHEFFECTIVE'));
        								$("#sel_emainffTypeDroplist"+$Gadget.data.offerInfoPOJO.offerId +" .inputbox").attr("key","N");
        							}
        								

        							
        						}
                            }
                            
                            // 产品恢复添加逻辑，过滤已经订购的增值offer信息
                            var conditionOfferIdList = [];
                            if ($Page.isrecover && $Page.isrecover == "true")
                            {
                            	$.each($Page.filterOfferIdList || [],function(i,val){
                            		conditionOfferIdList.push(val);
                            	});
                            }
                            
                            $Fire({
                                service: 'bes.oc.queryofferdetailservice/queryrelaofferdetaillist',
                                params: {
                                    "offerid": $Gadget.choosePackage.selectItem.offeringId,
                                    "condition": {
                                        "searchProd": "N",
                                        "businessCode": businesscode,
                                        "mainOfferingId": $Gadget.choosePackage.selectItem.offeringId,
                                        "conditionOfferIdList" : conditionOfferIdList
                                    }
                                },
                                target: '$Gadget.data.relaAddiProdList',
                                onafter: function () {
                                    debugger;
                                    if($Page.queryRelaAddiProdFlag != "false")
                                    {
                                    	$Gadget.$Page.relaAddiProdList = $Gadget.data.relaAddiProdList || [];
                                        $.each($Gadget.$Page.relaAddiProdList || [], function (i, vali) {
							
                                            $Gadget.rectype = $Gadget.$Page.rectype;
                                            if ($Gadget.rectype == "batchmainprodchange") {
                                                // DTS2016040300721 个人套餐（必选包）实例化没有返回N，前台处理加上
                                                var hasNextFlag = false;
                                                $.each(vali.ocEffectiveMode.effectiveTypes || [], function (j, valj) {
                                                	if(valj.key == "N"){
                                                		hasNextFlag = true;
                                                		return false;
                                                	}
                                                });
                                                if(!hasNextFlag){
                                                	var nextEffectiveType = {"key":"N","value":$UEE.i18n('ad.group.label.NEXTMONTHEFFECTIVE'),"selected":true,
                                                    		"businessCode":"TRS","primaryOfferingId":"ALL","beId":$Gadget.rootBeId,
                                                    		"chgAffectDate":"N","priority":null,"durationUnit":null,
                                                    		"durationValue":null,"fixStartDate":null};
                                                    vali.ocEffectiveMode.effectiveTypes.push(nextEffectiveType);
                                                }
                                                vali.ocEffectiveMode.selectedMode = "N";
                                                vali.ocEffectiveMode.effModeDisabled = true;
                                                if (vali.isbindOffer == "Y") {
                                                    $.each(vali.ocOfferInfoVA || [], function (i, valii) {
                                                        valii.ocEffectiveMode.selectedMode = "N";
                                                        valii.ocEffectiveMode.effModeDisabled = true;
                                                    });
                                                }
                                            }
                                            
                                            var familyProd = $(document).scope().fillFamilyProd(vali);
            								if(familyProd) {
            									vali.ocProductInfoVA = [familyProd];
            								}
            								if (vali.isbindOffer == "Y") {
            									$.each(vali.ocOfferInfoVA || [], function(i, valii){
            										var familyProdSub = $(document).scope().fillFamilyProd(valii);
            										if(familyProdSub) {
            											valii.ocProductInfoVA = [familyProdSub];
            										}
            									});
            								}
            								
            								// 关于增加社会渠道预开户功能的需求
                                            if ($Gadget.$Attrs.businesscode == "AgentGetCard") {
                                                 $.each(vali.ocOfferInfoVA || [], function(i, valii){
                                                    $.each(valii.ocOfferingAttrPOJO || [], function(n, valn){
                                                        if (valn.attributeCode == "AgentGetCard_MustSelect") {
                                                            // 默认选中
                                                            $Controller.besOcSelectpackageinfo.clickcatalog(vali,valii,$Gadget)
                                                            // 设置选中标识
                                                            vali.isSelected = true;

                                                        }
                                                    });
                                                });
                                            }
                                            
            								vali.selected = true;
                                                
            								
                                        });
                                        //add by zWX270193 提前生产relaOrderItemId
                                        $.each($Gadget.$Page.relaAddiProdList || [], function (i, valj) {
                                            valj.relaOrderItemId = adutil.getNextNumber();
                                        });
                                        //zWX270193 end
                                        
                                        //两城一号
                                        $Gadget.$Emit('$bes.oc.packageSelectedForDoubleCity', {offerInfo: $Gadget.data.offerInfoPOJO});
                                    }
                                }
                            }, $Gadget);
                        }

                        $Gadget.$Emit('$bes.oc.packageSelected', $Gadget.data.offerInfoPOJO);
                        // 一卡双号
                        $Gadget.$Emit('$Gadget.newnumchoose.updatePackageInfo', $Gadget.data.offerInfoPOJO);

                        $Controller.besOcChoosePackages.closePopup($Fire);
                    }
                }, $Gadget);
            } else {
                $Gadget.$Emit('$bes.oc.packageSelected', null);
                $Gadget.$Page.relaAddiProdList = [];
                $Controller.besOcChoosePackages.closePopup($Fire);
            }
            
        },

        closePopup: function ($Fire) {
            $Fire({
                "popin": ""
            });
        },

        // 收藏或全部
        changeTab: function ($Gadget, $Fire, clickTab) {
            debugger;
            if (clickTab == 1) {
                /*$("#li_choosePackageTabsAll").removeClass("active");
                $("#li_choosePackageTabsCollect").addClass("active");*/
            	$("#dd_additionalProdrootcategories_myfav").siblings().removeClass('active');
            	$("#dd_additionalProdrootcategories_myfav").addClass('active');
                $Gadget.searchAttr = 'Y';

            } else {
                $("#li_choosePackageTabsCollect").removeClass("active");
                $("#li_choosePackageTabsAll").addClass("active");
                $Gadget.searchAttr = 'Y';

            }
            if ($Gadget.tabIndex == clickTab) {
                return;
            }

            // 切换到收藏页面，直接保存全部页面的数据
            if ($Gadget.tabIndex == 0) {
                $Gadget.data.totalpackageInfo = $Gadget.data.packageInfo;
                $Gadget.data.totalpageInfo = $Gadget.data.pageInfo;
                $Controller.besOcChoosePackages.queryFavoriteInfo($Gadget, $Fire, 0);

            } else {
                $Gadget.favoriteList = {};
                $Gadget.data.packageInfo = $Gadget.data.packageInfoCopy;
                $Gadget.data.pageInfo = $Gadget.data.totalpageInfo;
                $("#choosePackagePages").empty();
                if ($Gadget.data.packageInfo.offeringList && $Gadget.data.packageInfo.offeringList.length > 0) {
                    $Gadget.data.pages = new UCD.Pages(
                        $("#choosePackagePages"),
                        $Gadget.data.packageInfo.pageInfo.totalRecord,
                        $Gadget.data.pageInfo.recordPerPage, [7, 14], 1);
                    if (!$Gadget.data.pageInfo.selection) {
                        $Gadget.data.pageInfo.selection = 0;
                    }
                    $Gadget.data.pages.setSelection($Gadget.data.pageInfo.selection + 1);
                }

            }
            //$Gadget.tabIndex = clickTab;

        },

        // 查询已收藏的活动
        queryFavoriteInfo: function ($Gadget, $Fire, selectedPage) {
            debugger;
            $Gadget.data.searchOfferingCond.keyWord = $.trim($Gadget.data.searchInput || "");
            $Gadget.favoriteSelectedPage = selectedPage;

            $Gadget.params = {
                sceneCode: "SCENE_FAVORITE_PACKAGE_ORDER",
                //添加功能：收藏支持按条件搜索
                searchOfferingCond: $.extend(true, {
                        productList: $Gadget.$Attrs.productidlist ? $Gadget.$Attrs.productidlist : null
                    }, $Gadget.data.searchOfferingCond)
                    // 分页改为前台分页，每次固定查询出1000条数据
                    // startNum : selectedPage * 6,
                    // pageSize : 6
            };
            if (true) {
                // 切换到收藏页面时进行查询
                $Controller.besOcChoosePackages.queryFavoriteInfoByFire($Gadget, $Fire, selectedPage);

            } else {

                $Gadget.data.packageInfo = {
                    offeringList: []
                };

                for (var i = selectedPage * 6; i < $Gadget.favoriteList.body.offerInfoList.length; i++) {

                    if (i >= selectedPage * 6 + 6) {
                        break;
                    }

                    $Gadget.data.packageInfo.offeringList.push($Gadget.favoriteList.body.offerInfoList[i]);
                }
                //站内搜索埋点 add by p00354016 
				var currentPage = selectedPage + 1;
				var searchResult;
				
				if (!$Gadget.data.productsearchoffering || !$Gadget.data.productsearchoffering.offeringList
						|| $Gadget.data.productsearchoffering.offeringList.length<=0) {
					searchResult = 0;
					currentPage = 0;
				}
				else {
					searchResult = 1;
				}
				var keyWord = $Gadget.params.searchOfferingCond.keyWord;
				if (keyWord!=undefined && keyWord !=null && keyWord != ""){
					$BuriedPoinStat.searchstat(keyWord, "product", searchResult, currentPage);
				}
				//站内搜索埋点 end
            }


            $Gadget.data.isclickFavoritePageNum = false;
        },

        queryFavoriteInfoByFire: function ($Gadget, $Fire, selectedPage) {
        	debugger;
            $Page = $Gadget.$Page
            dontTouchDataOfWholePage();
            OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
            $Fire({
                'service': 'favoriteservice/queryfavoritelist',
                'params': {
                    'body': $Gadget.params
                },
                'target': '$Gadget.favoriteList',
                'onafter': function ($Gadget) {
                    debugger;
					if($Gadget.favoriteList && $Gadget.favoriteList.body){
						
						$Gadget.data.packageInfo = {
								offeringList: []
						};
						
						var i = selectedPage * 6;
						
						if (i >= $Gadget.favoriteList.body.offerInfoList.length && selectedPage > 0) {
							i = i - 6;
							$Gadget.favoriteSelectedPage = selectedPage - 1;
						}
						
						for (; i < $Gadget.favoriteList.body.offerInfoList.length; i++) {
							
							if (i >= selectedPage * 6 + 6) {
								break;
							}
							$Gadget.data.packageInfo.offeringList.push($Gadget.favoriteList.body.offerInfoList[i]);
						}
						
						$Gadget.data.packageInfo.pageInfo = {
								totalRecord: $Gadget.favoriteList.body.totalSize
						};
						
						//站内搜索埋点 add by p00354016 
						var currentPage = selectedPage + 1;
						var searchResult;
						
						if (!$Gadget.data.packageInfo.offeringList || $Gadget.data.packageInfo.offeringList.length<=0) {
							searchResult = 0;
							currentPage = 0;
						}
						else {
							searchResult = 1;
						}
						var keyWord = $Gadget.params.searchOfferingCond.keyWord;
						if (keyWord!=undefined && keyWord !=null && keyWord != ""){
							$BuriedPoinStat.searchstat(keyWord, "product", searchResult, currentPage);
						}
						//站内搜索埋点 end
						
						$("#choosePackagePages").empty();
						if ($Gadget.data.packageInfo.offeringList && $Gadget.data.packageInfo.offeringList.length > 0) {
							$Gadget.data.pages = new UCD.Pages(
									$("#choosePackagePages"),
									$Gadget.data.packageInfo.pageInfo.totalRecord,
									$Gadget.data.pageInfo.recordPerPage, [7, 14], 1);
							$Gadget.data.pages.setSelection(selectedPage + 1);
							
						} else {
							$Gadget.data.pages = null;
						}
					}
                    youCanTouchDataOfWholePage();
                },
                'onerror' : function(){
                	youCanTouchDataOfWholePage();
                }

            }, $Gadget);

        },

        //根据二维码查询营销活动的结果
        queryQRCode: function ($Page, $Gadget, $Fire, data, $UI, $Target) {
            debugger;
            $Gadget.data.productsearchoffering = data;
            var searchoffer = $Gadget.data.productsearchoffering.offeringList[0];
            $Gadget.$Item = $Gadget.$Item || {};
            $Gadget.$Item.offeringId = searchoffer.offeringId;
            $Controller.besOcChoosePackages.confirmSelectPackage($Gadget, $Target, $Gadget.$Item, $Fire);
        },
        
        choosePackageAbroad: function($Gadget,$Item){
        	debugger;
        	$Gadget.refreshObj = {
        			refreshFlag: true
    		};
        	//modify by gwx300044
        	if($Item.offeringId == '1380100001'){
        	$Gadget.$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("AD.FAMILY.TIPS.PACNOSUBSCRIBED"));
        	return false;
        	}
        	//end modify
        	$(document).scope().$Page.validateFunction = [];
        	$Gadget.familyData = $Item;
		$Gadget.famParams = {
        			hiddenflag:($Gadget.$Attrs.params||{}).hiddenflag
        	}
        },
        
        cancelMainDetail: function($Gadget, $Fire){
    		debugger;
    		$Fire({
    			'popin' : ''
    		});
    	},
    	
    	clickHotWordSearch: function($Page, $Gadget, $item){
    		debugger;
    		$Gadget.hotKeyWords = $.trim($item);
    		$Controller.besOcChoosePackages.clickSearch($Gadget, $Gadget.$Get("$Fire"));
    	},
    	//初始化搜索热词
    	toGetHotSearchWords : function($Page, $Gadget){
			$Fire = $Gadget.$Get("$Fire");
			
			debugger;
			OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
			$Fire({
				  'service' : '/queryofferhotwordservice/queryofferhotword',
					'target' : '$Gadget.hotsearchwords',
					'onafter' : function($Gadget) {
								debugger;
								if(($Gadget.hotsearchwords||[]).length == 0){
									$Gadget.hotsearchwords = ["4G", "音乐","商旅"];
								}
					     }
				}, $Gadget);
		}
});