$Controller("bes.ad.familybase.mainofferinfo",{	
	/**
	 * 初始化操作
	 */
	init: function($Gadget){
		debugger;
		$Gadget.callback = {};
		$Gadget.isHouseHold =true;
		$Gadget.fmcchangemainoffer = false;
		//如果用户已经订购主offer,主offer只能做销户操作
		if($Gadget.$Attrs.family.offering.offeringInstId)
		{
			if('0' == $Gadget.$Attrs.family.subscriber.isHousehold)
			{
				$Gadget.isHouseHold =false;
			}
			
			if ('N' == $Gadget.$Attrs.family.offering.isCanceled && '1' == $Gadget.$Attrs.family.offering.isNextMonthExp)
			{
				$Gadget.changemainoffer = false;
				$Gadget.cancelfamily = false;
				$Gadget.fmcchangemainoffer = false;
			}
			else
			{
				$Gadget.changemainoffer = false;
				$Gadget.cancelfamily = true;
				
				// 次月生效的FMC、次月失效的FMC不能做变更
				if ($Gadget.$Attrs.family.offering.groupType == 'FMC' && $Gadget.$Attrs.family.offering.status == '2' && $Gadget.$Attrs.family.offering.expDate > $Page.TimeUtil.nextMonthFirstDay) {
					$Gadget.fmcchangemainoffer = true;
				}
				
			}
			$Gadget.$Attrs.mutioffer.showProductOrderBtn = true;
			$Gadget.$Attrs.mutioffer.newone = false;
		}
		else
		{
			$Gadget.changemainoffer = true;
			$Gadget.cancelfamily = false;
			$Gadget.$Attrs.mutioffer.showProductOrderBtn = false;
			$Gadget.$Attrs.mutioffer.newone = true;
			$Gadget.fmcchangemainoffer = false;
		}
						
		$Gadget.MainOfferDataIsReady = true;
		
		$Fire({
			service : 'ucec/v1/common/qrysystemparambykey',
			params :  {
				"key" : "FMY_OFFER_CHG_ROLL_ALLOW_FLAG"
			},
			target : '$Gadget.fmyChgRollFlag',
			onafter : function() {
				debugger;
			}
		}, $Gadget);
		
	},
	
	fmcChangeMainOffer : function($Gadget, $Fire, $UI) {
		debugger;
		
		var members = adutil.getGadgetObj($(".bes-ad-familybase-member")).members;
		var number = 0;
		$.each(members || [],function(i,val){
			if (val.serviceAccountType == '5') {
				number = number + 1;
			}
		});
		
		
		// modify begin by z00196689 US-20180820153518-2031109717 关于支持融合套餐FMC变更操作可回退的功能支持 
		var tips = "套餐变更不能回退，请谨慎操作。";
		if (number > 1) {
			if ("Y" == $Gadget.fmyChgRollFlag) {
				tips = "变更主套餐后，存在不可添加第二条宽带成员，请确定是否变更 ";
			} else {
				tips = "套餐变更不能回退，请谨慎操作。 变更主套餐后，存在不可添加第二条宽带成员，请确定是否变更 ";
			}
			
		}
		
		if ($Gadget.fmyChgRollFlag != 'Y' || number > 1) {
			$Gadget.$Get('$UI').msgbox.confirm("提示", tips, function(){
				$Fire({
					popup:{
						id: 'fmcChangeMainOffer',
						title : '套餐变更',
					    width : '940px',
					    height : '450px',
					    src :'{{$Webapp}}/bes/ad/ctz/gadget/person/family/familybase/bes-ad-familybase-fmcmainofferchoose/bes-ad-familybase-fmcchoosemainprod-pop.html'
					}
				},$Gadget);
			});
			
		} else {
			$Fire({
				popup:{
					id: 'fmcChangeMainOffer',
					title : '套餐变更',
				    width : '940px',
				    height : '450px',
				    src :'{{$Webapp}}/bes/ad/ctz/gadget/person/family/familybase/bes-ad-familybase-fmcmainofferchoose/bes-ad-familybase-fmcchoosemainprod-pop.html'
				}
			},$Gadget);
		}
		// modify end by z00196689 US-20180820153518-2031109717 关于支持融合套餐FMC变更操作可回退的功能支持 
	},
	
	cancelfamily : function($Gadget,Fire,$UI)
	{
		debugger;
		var members = adutil.getGadgetObj($(".bes-ad-familybase-member")).members;
		$.each(members || [],function(i,val){
			val.operationType = '';
			val.orderItem = [];
			//判断是否是第二条宽带
			val.isSecondBroadband = false;
		});
		//判断是否是第二条宽带
		if($Page.isOpenSecondBroaBandShow){
			var HouseholdNumber = null;
			//判断当前宽带账号是否是主号的宽带，如果是主号的宽带只能是第一条宽带
			$.each(members || [], function(i, vali){
				if (vali.isHousehold == "1") {
					HouseholdNumber = vali.serviceNumber;
				}
			});
			$.each(members || [], function(i, vali){
				if (vali.serviceNumber.indexOf(HouseholdNumber) < 0 && vali.isHousehold != "1") {
					vali.isSecondBroadband = true;
				}
			});
		}
		$Gadget.offering = $Gadget.$Attrs.family.offering;
		$Gadget.validateFunction=[];
		$Gadget.effexpmode={};
		$Gadget.effexpmode.showEffModeGadget = false;
		$Gadget.effexpmode.showExpModeGadget = true;
		$Gadget.effexpmode.dropSubs =true;
		$Gadget.callback = $Gadget.$Attrs.callback;
		
		if ($Gadget.offering.groupType == 'FMC') {

			
			$Fire({
				popup:{
					id: 'homesetpop',
					title : '',
				    width : '700px',
				    height : '450px',
				    src :'{{$Webapp}}/bes/ad/ctz/gadget/person/family/familybase/bes-ad-familybase-cancelaccount/bes-ad-familybase-cancelaccount-pop.html'
				}
			},$Gadget);
		} 
		else 
		{
			$Fire({
				popup:{
					id: 'homesetpop',
		            title : '注销',
				    width : '700px',
				    height : '360px',
				    src :'{{$Webapp}}/bes/ad/gadget/person/family/familybase/bes-ad-familybase-offerdetail/bes-ad-familybase-offerdetail-pop.html'
				}
			},$Gadget);
			//popup="{'id':'homesetpop','title' : '{{$Item.offeringName}}','width' : '700px','height' : '360px','src':'{{$Webapp}}/bes/ad/gadget/person/family/familybase/bes-ad-familybase-offerdetail/bes-ad-familybase-offerdetail-pop.html'}"
		}
	},

	cancelFMC : function($Gadget){
		debugger;
		var members = adutil.getGadgetObj($(".bes-ad-familybase-member")).members;
		$.each(members || [],function(i,val){
			val.actionType = '';
			val.orderItem = [];
		});
		$Page.CancelDeregisterFMCFlag = false;
		$Page.householdOfferChange = false;
		$Gadget.$Attrs.family.otherProductLines = [];
	},
	
	beforeChange : function($Page)
	{
		$Page.isNeedVpmnCode = false;
	}
});