$Controller("bes.ad.familyuserinfo", {
	
	/**
	 * 查询系统参数，获取四个按钮跳转url
	 */
	init : function($Gadget) {
		debugger;
		if ('FMC' == $Gadget.$Attrs.baseinfo.groupType && '1' == $Gadget.$Attrs.subscriber.isHousehold){
			// 获取系统参数，列表方式一次获取，避免多次请求
			var keylist = ["modifyInfoURL", "queryUseOfAmountUrl","acctQueryUrl","orderQueryUrl"];
			$Fire({
				service : 'ucec/v1/common/qrysystemparamlistbykey',
				params : {
					keylist : keylist
				},
				target : '$Page.systemParamList',
				onafter : function() {
					debugger;
					$Gadget.modifyInfoURL = $Page.systemParamList[0];
					$Gadget.queryUseOfAmountUrl = $Page.systemParamList[1];
					$Gadget.acctQueryUrl = $Page.systemParamList[2];
					$Gadget.orderQueryUrl = $Page.systemParamList[3];
				}
			}, $Gadget);
		}
	},

	/**
	 * 跳转到改资料页面
	 */
	goModifyInfo : function($Gadget) {
		debugger;
		_ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("MODIFYINFO");
		if ($Gadget.modifyInfoURL){
			var addURL = $Gadget.modifyInfoURL + '?&1=1'+getVersionUrlStr(0);
	        adutil.openUserTab("MODIFYINFO", $UEE.i18n("ad.person.title.ModifyInfo"), addURL); //改资料
		}
        
	},
	  
	/**
	 * 跳转到使用量查询页面
	 */
	 goQueryUseOfAmount : function($Gadget) {
		 debugger;
		 _ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("QUERYUSEOFAMOUNT");
		 if ($Gadget.queryUseOfAmountUrl){
			 var addURL = $Gadget.queryUseOfAmountUrl + '&1=1'+getVersionUrlStr(0);
		        adutil.openNGTab("QUERYUSEOFAMOUNT", $UEE.i18n("使用量查询"), addURL); //使用量查询
		 }
	},
	
	/**
	 * 跳转到账单查询页面
	 */
	goAcctQuery : function($Gadget) {
		debugger;
		_ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("ACCTQUERY");
		if ($Gadget.acctQueryUrl){
			var addURL = $Gadget.acctQueryUrl + '&1=1'+getVersionUrlStr(0);
	        adutil.openNGTab("ACCTQUERY", $UEE.i18n("账单查询"), addURL); //账单查询
		}
	},
	
	/**
	 * 跳转到订单查询页面
	 */
	goOrderQuery : function($Gadget) {
		debugger;
		_ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("ORDERQUERY");
		if ($Gadget.orderQueryUrl){
			var addURL = $Gadget.orderQueryUrl + '?&1=1'+getVersionUrlStr(0);
	        adutil.openUserTab("ORDERQUERY", $UEE.i18n("AD.MARKETPLAN.TITLE.ORDER_TRACKING"), addURL); //订单查询
		}
	}
});