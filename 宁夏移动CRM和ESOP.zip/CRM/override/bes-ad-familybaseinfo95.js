$Controller("bes.ad.familybaseinfo", {
	/**
	 * 初始化操作
	 * 海外家庭主offer开通 familyInstall 海外家庭主offer成员管理 familyMemberMgr
	 * 海外家庭主offer注销 familyDropSubs 添加和变更成员校验 familyMemberVali 海外家庭offer变更 familyChangeProduct
	 */
	init : function($Page, $Gadget, $Fire, $UI) {
		debugger;
		//定义回退事件
		
		//宁夏定制 修改DTS2016111602340 add by twx379737 start
		$Gadget.groupTypes = ['PTFamilyGroup', 'FMC', 'GrpPrdHome4GShare', 'KSJTW'];
		//修改DTS2016111602340 add by twx379737 end
		// 初始化数据:产品模型
		if($Page.homeCancelSubmitProcess && !$Page.needRecoverInitData) {
			$Gadget.family = $Page.family;
			//处理结算页面点击返回修改时不能展示多个主offering情况
			$Gadget.mutioffer = $Page.mutioffer;
			$Gadget.InitDataIsReady = true;
			$Page.homeCancelSubmitProcess = false;
			$Gadget.originalFamilyInfo = $Page.originalFamilyInfo;
			this.getShowTab($Gadget);
//			this.buildMuti($Page,$Gadget);
			return;
		}
		// 初始化个人虚拟网是否开通短号
		$Page.isHaveShorno = true;
		//初始化是否需要恢复初始化数据标识为false
		$Page.needRecoverInitData = false;
		//是否为多主产品模式
		$Gadget.mutioffer = {
			isMutiMainOffer : false,
			showProductOrderBtn : true,
			newone : false,
			offerings : [],
			offerIndex : 0
		};
		//初始家庭业务前台数据模型
		$Gadget.family = {
			baseinfo : {},
			otherProductLines:[], //成员增值产品变更订单行
			offerings:[], //主体产品变更的offer列表  java层组装订单报文
			subscriber : {},
			offering : {
				attachedOffers: []
			},
			callback : {
				canelFamilyOfferCB : function() {//注销
					debugger;
					$Controller.bes.ad.familybaseinfo.canelFamilyOffer($Page, $Gadget, $Fire, $UI);
					return true;
				},
				setMainNumMemberCB : function() {//设置主号
					debugger;
					$Controller.bes.ad.familybaseinfo.setMainNumMember($Page, $Gadget, $Fire, $UI);
					return true;
				}
			}
		};

		//初始化基本信息对象
		$Gadget.family.baseinfo = {
			showMemberOperBtn : true,
			showProductChgBtn : false,
			businessType : '',// 默认开户
			belongGroupIds : [],
			// 默认第一个
			groupType : $Gadget.groupTypes[0],
			// 户主名称定义对象
			houseNameMap : {
				"0" : $UEE.i18n("AD.FAMILY.LABEL.MEMBER"),
				"1" : $UEE.i18n("AD.FAMILY.LABEL.HOLDER")
			},
			//代付类型：0-不代付,1-全额代付
			payTypeMap : {
				"0" : $UEE.i18n("AD.FAMILY.LABEL.NOPAY"),
				"1" : $UEE.i18n("AD.FAMILY.LABEL.FULLPAY")
			},
			//初始化操作类型，用于判断对象是否变更
			actionTypeMap : $Controller.bes.ad.family.common.initActionTypeMap()
		};
		// 显示不允许修改界面
		dontTouchDataOfWholePage();
		// 初始化补资料数据字典
		OC.Callchain.setFireSearch($Page.pageId, "init0000");
		
		$Gadget.$Get('$Fire')({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				key : 'familyMemberRowNumber'
			},
			target : "$Page.memberRowNumber",
			onafter : function() {
				debugger;
				
				// 如果配置了familyMemberRowNumber系统参数并且大于0，则走新流程，否则走老流程
				if ($Page.memberRowNumber && Number($Page.memberRowNumber)>0 && $Page.phonenum && $Page.phonenum != '""') {
					
					$Controller.bes.ad.familybaseinfo.initfamilybaseinfonew($Page, $Gadget, $Fire, $UI);
					
				} 
				else {
					var service = "/ucec/v1/family/initfamilybaseinfo";

					var body = {
						menuId : _ysp_top.TabSet && _ysp_top.TabSet.getTabItem && _ysp_top.TabSet.getTabItem() && _ysp_top.TabSet.getTabItem().key,
						groupTypes : $Gadget.groupTypes
					};

					$Fire({
						service : service,
						params : {
							body : body
						},
						target : "$Gadget.familyInfoResponse",
						onafter : function() {
							debugger;
							// 隐藏不允许修改界面
							youCanTouchDataOfWholePage();
							
							//设置grouptype
							$Gadget.family.baseinfo.groupType = $Controller.bes.ad.familybaseinfo
									.getCustGroupTypeBySubs($Gadget,
											$Gadget.familyInfoResponse.body);
							
							if ('FMC' == $Gadget.family.baseinfo.groupType) {
								$Controller.bes.ad.familybaseinfo.buildFMCMuti($Page,$Gadget);
							}
							else if ('PTFamilyGroup' == $Gadget.family.baseinfo.groupType) {
								$Controller.bes.ad.familybaseinfo.buildMuti($Page,$Gadget);
							}
							
							$Controller.bes.ad.familybaseinfo.assembleRespParam($Gadget,
									$Gadget.familyInfoResponse.body,
									$Gadget.family.baseinfo.groupType);
							//如果用户已经订购主offer，展示附属offer信息
							if($Gadget.family.offering.offeringId)
							{
								$Gadget.family.baseinfo.showAddiOfferGadget = true;
							}	
							
							// 点击分页的时候，如果没有查询到成员信息，也需要展示成员的gadget
							if ($Gadget.family.offering && $Gadget.family.offering.members){
								$Gadget.showMemberInfo = true;
							}
							
							$Controller.bes.ad.familybaseinfo.getShowTab($Gadget);
							$Gadget.InitDataIsReady = true;
							//modify by swx505451 fmc防降档busi_id传subsid
							$Page.familyDropGradeBusinessId = (($Gadget.family || {}).offering || {}).subsId;
						},
						onerror : function() {
							// 隐藏不允许修改界面
							youCanTouchDataOfWholePage();
						}
					}, $Gadget);
				}
			}
		},$Gadget);
				
		//US-20180620162919-2031098905-家庭业务副号资费优化需求-预选成员商品在字典HoldNotNeedMemOffer中，不带入户主
		//US-20180719173008-2031104574-家庭业务副号资费优化需求-预选成员商品在字典OnlyHoldNeedMemOffer中，不带入成员
		$Gadget.$Get('$Fire')({											
			'service' : '/common/dictkey',
			'params' :  {
				"dictkeylist" : ['HoldNotNeedMemOffer', 'OnlyHoldNeedMemOffer']
			},
			'target' : '$Gadget.queryDict',
			'onafter': function(){
				debugger;
				$Page.HoldNotNeedMemOffer = $Gadget.queryDict['HoldNotNeedMemOffer'] || [];
				$Page.OnlyHoldNeedMemOffer = $Gadget.queryDict['OnlyHoldNeedMemOffer'] || [];
			}
		},$Gadget);
		//US-20180719193014-2031104602 FMC变更档次-降档问卷调查系统参数
		
		// 跨省家庭网主套餐offeringId
		$Gadget.$Get('$Fire')({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				key : 'TransProvFmyOfferId'
			},
			target : "$Page.ksjtwOfferingId",
			onafter : function() {
				debugger;
//				$Page.ksjtwOfferingId = "1610012282";
			}
		},$Gadget);
		
		$Gadget.$Get('$Fire')({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				key : 'QUESTIONNAIRE_FOR_LOWER'
			},
			target : "$Page.questionnaireForLower",
			onafter : function() {
				debugger;
			}
		},$Gadget);
		//US-20180810102257-2031108743
		$Gadget.$Get('$Fire')({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				key : 'isQueryMemberTypeByProductId'
			},
			target : "$Page.isQueryMemberTypeByProductId",
			onafter : function() {
				debugger;
				if($Page.isQueryMemberTypeByProductId == "true"){
					$Page.isQueryMemberTypeByProductId = true;
				}else if($Page.isQueryMemberTypeByProductId == "false"){
					$Page.isQueryMemberTypeByProductId = false;
				}
			}
		},$Gadget);
		
		$Fire({
			service : 'ucec/v1/common/qrysystemparambykey',
			params :  {
				"key" : "OC_ISOPEN_SECONDBROABOND"
			},
			target : '$Page.isOpenSecondBroaBandShow',
			onafter : function() {
				debugger;
				if($Page.isOpenSecondBroaBandShow == "true"){
					$Page.isOpenSecondBroaBandShow = true;
				}else if($Page.isOpenSecondBroaBandShow == "false"){
					$Page.isOpenSecondBroaBandShow = false;
				}
			}
		}, $Gadget);
	},	
	
	/**
	 * add by z00196689
	 */
	initfamilybaseinfonew : function($Page, $Gadget, $Fire, $UI) {
		debugger;

		$Fire({
			service : "/ucec/v1/ctz/initfamilybaseinfonew",
			params : {
				body : {
					menuId : _ysp_top.TabSet && _ysp_top.TabSet.getTabItem && _ysp_top.TabSet.getTabItem() && _ysp_top.TabSet.getTabItem().key,
					groupTypes : ['PTFamilyGroup'],
					serviceNumber : $Page.phonenum,
					needMembSubsInfo : '0',
					beginRowNum : '0',
					fetchRowNum : $Page.memberRowNumber,
					totalRowNum : '0'
				}
			},
			target : "$Gadget.familyInfoResponse1",
			onafter : function() {
				debugger;
				
				// 重新转圈，这样每个请求都有一分钟的时间
				// 隐藏不允许修改界面
				youCanTouchDataOfWholePage();
				// 显示不允许修改界面
				dontTouchDataOfWholePage();
				
				$Fire({
					service : "/ucec/v1/family/initfamilybaseinfo",
					params : {
						body : {
							menuId : _ysp_top.TabSet && _ysp_top.TabSet.getTabItem && _ysp_top.TabSet.getTabItem() && _ysp_top.TabSet.getTabItem().key,
							groupTypes : ['FMC', 'GrpPrdHome4GShare', 'KSJTW']
						}
					},
					target : "$Gadget.familyInfoResponse",
					onafter : function() {
						debugger;
						// 隐藏不允许修改界面
						youCanTouchDataOfWholePage();
						
						if ($Gadget.familyInfoResponse1.body.offering && $Gadget.familyInfoResponse.body.offering) {
							$Gadget.familyInfoResponse.body.offering['PTFamilyGroup'] = $.extend(true, [], $Gadget.familyInfoResponse1.body.offering['PTFamilyGroup']);
						}
						
						
						//设置grouptype
						$Gadget.family.baseinfo.groupType = $Controller.bes.ad.familybaseinfo
								.getCustGroupTypeBySubs($Gadget,
										$Gadget.familyInfoResponse.body);
						
						if ('FMC' == $Gadget.family.baseinfo.groupType) {
							$Controller.bes.ad.familybaseinfo.buildFMCMuti($Page,$Gadget);
						}
						else if ('PTFamilyGroup' == $Gadget.family.baseinfo.groupType) {
							$Controller.bes.ad.familybaseinfo.buildMuti($Page,$Gadget);
						}
						
						$Controller.bes.ad.familybaseinfo.assembleRespParam($Gadget,
								$Gadget.familyInfoResponse.body,
								$Gadget.family.baseinfo.groupType);
						//如果用户已经订购主offer，展示附属offer信息
						if($Gadget.family.offering.offeringId)
						{
							$Gadget.family.baseinfo.showAddiOfferGadget = true;
						}	
						
						// 点击分页的时候，如果没有查询到成员信息，也需要展示成员的gadget
						if ($Gadget.family.offering && $Gadget.family.offering.members){
							$Gadget.showMemberInfo = true;
						}
						
						$Controller.bes.ad.familybaseinfo.getShowTab($Gadget);
						$Gadget.InitDataIsReady = true;
						//modify by swx505451 fmc防降档busi_id传subsid
						$Page.familyDropGradeBusinessId = (($Gadget.family || {}).offering || {}).subsId;
					},
					onerror : function() {
						// 隐藏不允许修改界面
						youCanTouchDataOfWholePage();
					}
				}, $Gadget);

			},
			onerror : function() {
				// 隐藏不允许修改界面
				youCanTouchDataOfWholePage();
			}
		}, $Gadget);
		
	},
	
	buildFMCMuti : function($Page,$Gadget)
	{
		setTimeout(function(){
			$Gadget.$apply(function(){
		
				$Gadget.mutioffer = {
						isMutiMainOffer : false,
						showProductOrderBtn : true,
						newone : false,
						offerings : [],
						offerIndex : 0
					};
				
				if ($Gadget.familyInfoResponse && $Gadget.familyInfoResponse.body && $Gadget.familyInfoResponse.body.offering)
				{
					if ($Gadget.familyInfoResponse.body.offering.FMC && $Gadget.familyInfoResponse.body.offering.FMC.length > 1)
					{
						$Gadget.mutioffer.isMutiMainOffer = true;
		
						$Gadget.mutioffer.showProductOrderBtn = true;
						$Gadget.mutioffer.newone = false;
						
						//if ($Gadget.familyInfoResponse.body.offering.FMC[0].status != '1') {
						//	var tmp = $.extend(true, {}, $Gadget.familyInfoResponse.body.offering.FMC[0]);
						//	$Gadget.familyInfoResponse.body.offering.FMC[0] = $.extend(true, {}, $Gadget.familyInfoResponse.body.offering.FMC[1]);
						//	$Gadget.familyInfoResponse.body.offering.FMC[1] = $.extend(true, {}, tmp);
						//}
						
						for (var i=0;i<$Gadget.familyInfoResponse.body.offering.FMC.length;i++)
						{
							$Gadget.mutioffer.offerings.push($Gadget.familyInfoResponse.body.offering.FMC[i]);
						}
						
					}
				}
		
			},$Gadget);
		},0);
	},

	buildMuti : function($Page,$Gadget)
	{
		
		$Gadget.mutioffer = {
				isMutiMainOffer : false,
				showProductOrderBtn : true,
				newone : false,
				offerings : [],
				offerIndex : 0
			};
		
		if ($Page.originalFamilyInfo != null && $Page.originalFamilyInfo.offering != null)
		{
			if ($Page.originalFamilyInfo.offering['PTFamilyGroup'] && $Page.originalFamilyInfo.offering['PTFamilyGroup'].length > 1)
			{
				$Gadget.mutioffer.isMutiMainOffer = true;
				
				if ($Gadget.family.offering.offeringInstId != undefined && $Gadget.family.offering.offeringInstId != null && $Gadget.family.offering.offeringInstId != "")
				{
					$Gadget.mutioffer.showProductOrderBtn = true;
					$Gadget.mutioffer.newone = false;
				}
				else
				{
					$Gadget.mutioffer.showProductOrderBtn = false;
					$Gadget.mutioffer.newone = true;
				}
				
				for (var i=0;i<$Page.originalFamilyInfo.offering['PTFamilyGroup'].length;i++)
				{
					$Gadget.mutioffer.offerings.push($Page.originalFamilyInfo.offering['PTFamilyGroup'][i]);
				}
				
				if ($Gadget.mutioffer.newone == true)
				{
					$Gadget.mutioffer.offerIndex = $Page.originalFamilyInfo.offering['PTFamilyGroup'].length;
					
					$Gadget.mutioffer.offerings.push($Gadget.family.offering);
					
				}
			}
		}
	},
	
	initBefore : function($Page, $Gadget, $Fire, $UI) {
        debugger;
        // 是否csp登录
        $Page.isCsp = $Controller.bes.ad.csp.common.isCsp();
        if ($Page.isCsp) {
            $Page.servNumber = $Controller.bes.ad.csp.common.getServNumber();
            $Controller.bes.ad.csp.common.login($Page, $Fire, $Gadget,$UI, 
                    $Page.servNumber, 
                    function() {
                        $Controller.bes.ad.familybaseinfo.init($Page, $Gadget, $Fire, $UI);
                    },
                    function() {
                    }
            );
        } else {
            $Controller.bes.ad.familybaseinfo.init($Page, $Gadget, $Fire, $UI);
        }
    },
	
	/**
	 * 获取当前需要展示tab
	 */
	getShowTab: function($Gadget) {
		debugger;
		$Gadget.fmcShow = false;
		$.each($Gadget.groupTypeTabs || [], function(i, groupType) {
			if (groupType == 'FMC') {
				$Gadget.fmcShow = true;
			}
		});
	},
	/**
	 * 根据用户当前订购的家庭产品设置当前groupType 若均为加入家庭群网、融合家庭网，则默认办理家庭群网业务
	 * DTS2016101501694  增加家庭群网和融合家庭网可以全部展示
	 */
	getCustGroupTypeBySubs : function($Gadget, intfResp) {
		debugger;
		$Gadget.groupTypeTabs = [];
		if (!intfResp.offering) {
			$Gadget.groupTypeTabs.push($Gadget.groupTypes[0]);
			return $Gadget.groupTypes[0];
		}
		for ( var i = 0, max = $Gadget.groupTypes.length; i < max; i++) {
			if (!OC.Comm
					.isNullObj(intfResp.offering[$Gadget.groupTypes[i]]))
			{
				if(intfResp.offering[$Gadget.groupTypes[i]].length > 0)
				{	
					$Gadget.groupTypeTabs.push($Gadget.groupTypes[i]);
				}
			}
		}
		//菜单默认为家庭群网
		if(!$Gadget.groupTypeTabs || $Gadget.groupTypeTabs.length == 0){
			 $Gadget.groupTypeTabs[0] = $Gadget.groupTypes[0];
		}
		return $Gadget.groupTypeTabs[0];
	},
	/**
	 * 组装返回报文数据
	 */
	assembleRespParam : function($Gadget, intfResp, groupType) {
		debugger;
		$Gadget.originalFamilyInfo = $.extend(true, {}, intfResp) || {};
		$Gadget.family.subscriber = intfResp.subscriber;
		$Gadget.family.subscriber.isHousehold = "0";//默认普通用户
		this.reassembleOfferings($Gadget, intfResp.offering && intfResp.offering[groupType]);
	},
	/**
	 * 重新组装offerings信息 默认第一种offering情况
	 */
	reassembleOfferings : function($Gadget, offerings) {
		debugger;
		
		$Gadget.family.baseinfo.showOffersListName = "";
		
		var offerIndex = $Gadget.mutioffer.offerIndex;
		//$Gadget.mutioffer.isMutiMainOffer = false; //默认不支持多主产品场景
		if (!offerings || offerings.length == 0 || !offerings[offerIndex]) {
			$Gadget.family.offering = {attachedOffers: []};
			$Gadget.family.baseinfo.showAddiOfferGadget = false;
			return;
		}
		
		$Gadget.family.baseinfo.showAddiOfferGadget = true;
		$Gadget.family.baseinfo.showOffersListName = "offersList";

		$Gadget.family.baseinfo.belongGroupIds = [];
		for ( var i = 0; i < offerings.length; i++) {
			$Gadget.family.baseinfo.belongGroupIds.push({
				key : offerings[i]&&offerings[i].belongGroupId,
				value : offerings[i]&&offerings[i].belongGroupId
			});
		}
		
		//开启多主产品显示模式
		if($Gadget.family.baseinfo.groupType == $Gadget.groupTypes[0] && offerings.length > 1){
			$Gadget.mutioffer.isMutiMainOffer = true;
			$Gadget.mutioffer.offerings = offerings;
		}
				
		//if ($Gadget.mutioffer && $Gadget.mutioffer.offerings && $Gadget.mutioffer.offerings.length > 1) {
		//	this.reassembleOffering($Gadget, $Gadget.mutioffer.offerings[offerIndex]);
		//} else {
			this.reassembleOffering($Gadget, offerings[offerIndex]);
		//}
	},
	
	
	/**
	 * 重新组装offering信息
	 */
	reassembleOffering : function($Gadget, offering) {
		debugger;
		$Gadget.family.offering = offering;
		//设置当前登录用户是否户主信息
		if($Gadget.family.subscriber.serviceNumber == (offering.houseHold || {}).serviceNumber) {
			$Gadget.family.subscriber.isHousehold = "1";
			// 若为户主，则放开所有按钮权限
			$Gadget.family.baseinfo.showMemberOperBtn = true;
			$Gadget.family.baseinfo.showProductChgBtn = true;
		}else {
			$Gadget.family.subscriber.isHousehold = "0";
		}
	},
	
	/**
	 * 切换tap页
	 */
	clickTab : function($Page, $Gadget, $UI, groupType) {
		debugger;
		if ($Gadget.family.baseinfo.groupType == groupType){
			return;
		}
				
		if ($Gadget.family.baseinfo.groupType == "PTFamilyGroup" || $Gadget.family.baseinfo.groupType == "FMC" 
			|| $Gadget.family.baseinfo.groupType == "KSJTW")
		{
			$Controller.bes.ad.familybaseinfo.resetMutiOffer($Gadget);
		}
		
		if (groupType == "FMC")
		{
			$Controller.bes.ad.familybaseinfo.buildFMCMuti($Page,$Gadget);
		}
		
		// 展示成员信息
		$Gadget.showMemberInfo = false;
		
		if (!this.isHaveModifyFamilyData($Gadget)){
			$Controller.bes.ad.familybaseinfo.recoverFamilyBaseinfo($Gadget);
			$Gadget.family.baseinfo.groupType = groupType;
			$Gadget.originalFamilyInfo.offering = $Gadget.originalFamilyInfo.offering || {};
			$Controller.bes.ad.familybaseinfo.reassembleOfferings($Gadget, $Gadget.originalFamilyInfo.offering[groupType]);
			$Controller.bes.ad.familybaseinfo.refreshSubData($Gadget);
			
			// 点击分页的时候，如果没有查询到成员信息，也需要展示成员的gadget
			if ($Gadget.family.offering && $Gadget.family.offering.members){
				$Gadget.showMemberInfo = true;
			}
			
			return;
		}
		
		var hipMessage = $UEE.i18n("AD.FAMILY.TIPS.GIVEUP_CHANGE");
		$UI.msgbox.confirm($UEE.i18n("AD.FAMILY.LABEL.TIPS"), hipMessage,function() {
			var $Scope=$(document).scope();
			$Scope.$safeApply($Scope,function(){
				debugger;
				$Controller.bes.ad.familybaseinfo.recoverFamilyBaseinfo($Gadget);
				$Gadget.family.baseinfo.groupType = groupType;
				$Gadget.originalFamilyInfo.offering = $Gadget.originalFamilyInfo.offering || {};
				$Controller.bes.ad.familybaseinfo.reassembleOfferings($Gadget, $Gadget.originalFamilyInfo.offering[groupType]);
				$Controller.bes.ad.familybaseinfo.refreshSubData($Gadget);
				
				// 点击分页的时候，如果没有查询到成员信息，也需要展示成员的gadget
				if ($Gadget.family.offering && $Gadget.family.offering.members){
					$Gadget.showMemberInfo = true;
				}
				
			});
		});
	},
	
	refreshSubData : function($Gadget){
		$Gadget.$Emit("$bes.ad.syncmembers");
		$Gadget.$Emit("$bes.ad.syncmainoffer");
		$Gadget.$Emit("$bes.ad.familybase.addiofferinfo.refresh");
		$Gadget.$Emit("$bes.ad.familybase.memberofferpreset.refresh");
	},
	
	resetMutiOffer : function($Gadget)
	{
		debugger;
		$Gadget.mutioffer.isMutiMainOffer = false;
		$Gadget.mutioffer.showProductOrderBtn = true;
		$Gadget.mutioffer.newone = false;
		$Gadget.mutioffer.offerIndex = 0;
		//$Gadget.mutioffer.offerings = ($Gadget.originalFamilyInfo.offering || {})["PTFamilyGroup"];
	},
	
	/**
	 * 多主产品场景下切换群组主产品
	 */
	switchMutiOffering : function($Gadget) {
		debugger;
		 //当切换群组主产品时，恢复初始化值
		 $Controller.bes.ad.familybaseinfo.recoverFamilyBaseinfo($Gadget);
		 $Controller.bes.ad.familybaseinfo.reassembleOfferings($Gadget, ($Gadget.originalFamilyInfo.offering || {})[$Gadget.family.baseinfo.groupType]);
		 
		 //刷新指定页面
		 $Gadget.$Emit("$bes.ad.syncmainoffer");
		 $Gadget.$Emit("$bes.ad.familybase.member.refresh");
		 $Gadget.$Emit("$bes.ad.familybase.addiofferinfo.refresh");
		 $Gadget.$Emit("$bes.ad.familybase.memberofferpreset.refresh");
		 
	},
	
	submit : function($Page, $Gadget, $Fire, $UI) {
		if(($Page.selectMember || {}).serviceAccountType == '5' && $Page.mbanddevinfo && $Page.mbanddevinfo.MbandDevAttrInfoList && $Page.mbanddevinfo.MbandDevAttrInfoList.length>0){
			$UI.msgbox.confirm($UEE.i18n('ad.person.message.information'), "销户后，请到“宽带终端回收”菜单进行设备回收，否则该用户进入黑名单，限制办理宽带业务，若无法提供设备请到“宽带赔付”菜单进行赔付", function() {
				$Controller.bes.ad.familybaseinfo.fmcsubmit($Page, $Gadget, $Fire, $UI);
			});
		}else{
			$Controller.bes.ad.familybaseinfo.fmcsubmit($Page, $Gadget, $Fire, $UI);
		}
	},
	/**
	 * 提交
	 */
	fmcsubmit : function($Page, $Gadget, $Fire, $UI) {
		debugger;
		// 显示不允许修改界面
		dontTouchDataOfWholePage();		
		//对预选成员增加校验
		 var $memOfferList = adutil.getGadgetObj($(".bes-ad-familybase-memberofferpreset"));
			if($Page.memOfferingList == 0 && $memOfferList.data.orderProduct.length == 0){
				youCanTouchDataOfWholePage();
				$Gadget.$Get('$UI').msgbox.info("提示", "请先选择预选成员商品。");
				return;
		}
		if($Gadget.family.baseinfo.groupType=="FMC" && $Gadget.family.baseinfo.businessType == "familyChangeProduct"){
			$Controller.bes.ad.familybaseinfo.isDropGrade($Page, $Gadget, $Fire, $UI);
		}
        //FMC销户逻辑
		if($Gadget.family.baseinfo.groupType=="FMC" && $Page.CancelDeregisterFMCFlag){
			this.canelFamilyOffer($Page, $Gadget, $Fire, $UI) ;
		}
		// 校验
		if(!this.validate($Gadget, $UI)) {
			// 关闭进度条
			youCanTouchDataOfWholePage();
			return;
		}
		
		var valiBusinessTypeObj = $Controller.bes.ad.family.common.getValiBusinessTypeObj($Gadget.family.baseinfo.groupType, $Gadget.family.baseinfo.businessType);
		// 跨省家庭网成员主动退出的还不一样
		if ($Gadget.family.baseinfo.groupType=="KSJTW" 
				&& valiBusinessTypeObj.busiCode == "KSFmyMemberMgr" 
				&& $Gadget.family.subscriber.isHousehold != '1')
		{
			valiBusinessTypeObj.busiCode = "KSFmyMemberDel";
		}
		// 报文体
		var checkoutbody = {
			businessType : valiBusinessTypeObj.businessType,
			vaildateBaseInfo : this.assembleVaildateBaseInfo($Gadget),
			createOrderReq : this.assembleCreateOrderReq($Gadget)
		};
		//主体产品变更订单报文在java层组装
		if ($Gadget.family.offerings.length > 0) {
			checkoutbody.mixturePOJO = {
				offerings : $Gadget.family.offerings,
				packageFee: 'Y'
			};
		}
		OC.Callchain.setFireSearch($Page.pageId, "busivali");
		$Fire({
			service: 'bes.agentdesktop.checkoutboservice/busivalidate',
			params: {
				"header": {},
				"checkoutbody": checkoutbody
			},
			target: '$Page.checkoutValidateResult',
			onafter: function() {
				debugger;
				// 关闭进度条
				youCanTouchDataOfWholePage();
				if (adutil.checkUcecResp($Page.checkoutValidateResult.header, $UI)) {
					debugger;
					var checkOutResp = $Page.checkoutValidateResult.body.checkOutResp;
					
					var busiValidCheck = adutil.checkBusiValidResp(null, $UI, checkOutResp, function(){
						//对于提示类，比如 组建家庭网时成员进行了合户，提示用户“家庭网销户后请对成员做分户处理！”，仅提示点确定后，系统不做自动分户处理，订单继续提交。
						$Controller.bes.ad.familybaseinfo.validateNextStep($Page, $Gadget, $Fire);

					});
					
					// 成功
					if (busiValidCheck) {
						$Controller.bes.ad.familybaseinfo.validateNextStep($Page, $Gadget, $Fire);
						
					}
					else{
						if($Gadget.family && $Gadget.family.offering && $Gadget.family.offering.actionType=="D"){
							$Gadget.family.offering.actionType = "";
							for(var j=0; j<($Gadget.family.offering.members||[]).length; j++) {
								if($Gadget.family.offering.members[j].isHousehold == '1') {
									$Gadget.family.offering.members[j].actionType = '';
									$Gadget.family.offering.members[j].expDate = null;//将户主失效时间设置为空
								}
							}
							$Gadget.$Emit("$bes.ad.familybase.member.refresh");
							}
							
						}

				}
				else{
						if($Gadget.family && $Gadget.family.offering && $Gadget.family.offering.actionType=="D"){
						$Gadget.family.offering.actionType = "";
						for(var j=0; j<($Gadget.family.offering.members||[]).length; j++) {
							if($Gadget.family.offering.members[j].isHousehold == '1') {
								$Gadget.family.offering.members[j].actionType = '';
								$Gadget.family.offering.members[j].expDate = null;//将户主失效时间设置为空
							}
						}
						$Gadget.$Emit("$bes.ad.familybase.member.refresh");
						}
						
					}
			},
			onerror: function(){
				// 关闭进度条
				youCanTouchDataOfWholePage();
			}
		}, $Gadget);
	},
	//判断FMC是否降档
	isDropGrade : function($Page, $Gadget, $Fire, $UI){
		var offeringList = [];
		var offeringIdList = [];
		$.each($Gadget.family.offering.attachedOffers || [],function(i,vali){
			$.each(vali.subOffers || [],function(j,valj){
				//当月有多笔操作时，排除原有商品
				if(vali.subOffers.length > 2 && valj.isCanceled == "N"){
					return true;
				}
				var offerIdAndType = {
						offeringId : valj.offeringId,
						actionType : valj.actionType
				};
				offeringList.push(offerIdAndType);
				offeringIdList.push(valj.offeringId);
			});
		});
		$Gadget.$Get('$Fire')({
			service : "ucec/v1/offering/queryofferingdetail",
			params : {
				header : {},
				body : {
					offeringIdList : offeringIdList
				}
			},
			target : "$Page.offeringListResp",
			onafter : function() {
				debugger;
				var offerings = (($Page.offeringListResp || {}).body || {}).offerings;
				if(!offerings){
					return;
				}
				var beforePrice = '';
				var afterPrice = '';
				$.each(offerings || [],function(i,vali){
					$.each(offeringList || [],function(n,valn){
						if(vali.offeringId == valn.offeringId){
								var isBaseOffer = false;
								var price = {};
								$.each((vali.attributeGroups[0] || {}).attributes || [],function(j,valj){
									if(valj.attrCode == 'PM_BASE_OFFER' && valj.newValue == '1'){
										isBaseOffer = true;
									}
									if(valj.attrCode == 'PM_OFFER_PRICE'){
										price = valj.newValue;
									}
								});
								if(isBaseOffer && valn.actionType == 'D'){
									beforePrice = price;
								}else if(isBaseOffer && valn.actionType != 'D'){
									afterPrice = price;
								}
						}
					});
					
				});
				if(beforePrice && afterPrice && (beforePrice - afterPrice > 0)){
					$Page.isDropGrade = true;
				}
			}
		},$Gadget);
	},
	//跳转到结算页面
	validateNextStep : function($Page, $Gadget, $Fire){
		debugger;
		
		$Page.checkoutInfo = $Page.checkoutInfo || {};
		$Page.checkoutInfo.businessName = $UEE.i18n("AD.FAMILY.LABEL.HOMENET_BUSS_ACCP");
		$Page.checkoutInfo.serviceNumber = $Page.serviceNum = $Gadget.family.subscriber.serviceNumber;
		$Page.checkoutValidateBody = {};
		$Page.family = $Gadget.family;
		$Page.mutioffer = $Gadget.mutioffer;
		$Page.originalFamilyInfo = $Gadget.originalFamilyInfo;
		//用户返回修改按钮指定页面
		$Page.backStep = "index";
		$Page.ckeckoutFlag=true;
//		 标识跳转的结算页面
		$Page.backStepMethod='$bes.ad.familycheckout.back';
		$Page.homeCancelSubmitProcess = true;

		//解决无法跳转问题
		$Gadget.$Get('$Fire')({											
			'service' : '/common/dictkey',
			'params' :  {
				"dictkeylist" : ['OC.SUSPEND.RESUME.TYPE']
			},
			'target' : '$Gadget.stopOpenDict',
			'onafter': function(){
				debugger;
				$Page.ckeckoutFlag=true;
				
				}
			},$Gadget);
		

	},
	/**
	 * 封装VaildateBaseInfo对象
	 */
	assembleVaildateBaseInfo : function($Gadget) {
		debugger;
		var valiBusinessTypeObj = $Controller.bes.ad.family.common.getValiBusinessTypeObj($Gadget.family.baseinfo.groupType, $Gadget.family.baseinfo.businessType);
		// 跨省家庭网成员主动退出的还不一样
		if ($Gadget.family.baseinfo.groupType=="KSJTW" 
				&& valiBusinessTypeObj.busiCode == "KSFmyMemberMgr" 
				&& $Gadget.family.subscriber.isHousehold != '1')
		{
			valiBusinessTypeObj.busiCode = "KSFmyMemberDel";
		}
		var vaildateBaseInfo = {
			seniorId : valiBusinessTypeObj.seniorId,
			eventId : valiBusinessTypeObj.eventId,
			busiCode : valiBusinessTypeObj.busiCode
		};
		return vaildateBaseInfo;
	},
	/**
	 * 封装CreateOrderReq对象
	 */
	assembleCreateOrderReq : function($Gadget) {
		debugger; 
		//获取主offering报文
		var productOrderLines = this.assembleMainOfferOrderLineMsg($Gadget);
		//拼接成员订购的offering报文
		var memberOfferOrderLineMsg = this.assembleMemberOfferOrderLineMsg($Gadget);
		if(memberOfferOrderLineMsg) {
			Array.prototype.push.apply(productOrderLines, memberOfferOrderLineMsg);
		}
		//拼装成员合户报文  销户不需要组合户逻辑
		//if($Gadget.family.baseinfo.businessType !="familyDropSubs" && $Gadget.family.baseinfo.businessType !="familyMemberMgr"){
		//	var memberUniAcctOrderLineMsg = this.assembleMemberUniAcctOrderLineMsg($Gadget);
		//
		//	if(memberUniAcctOrderLineMsg) {
		//		Array.prototype.push.apply(productOrderLines, memberUniAcctOrderLineMsg);
		//	}
		//}

		
		//组装成员变更增值商品列表
		if(($Gadget.family.otherProductLines||[]).length > 0){
			
			Array.prototype.push.apply(productOrderLines, $Gadget.family.otherProductLines);
		}
		
		var createOrderReq = {
			order : this.assembleOrder($Gadget),
			productOrderLine : productOrderLines
		};
		return createOrderReq;
	},
	/**
	 * 封装订单信息
	 */
	assembleOrder : function($Gadget) {
		debugger;
		var businessCode = $Controller.bes.ad.family.common.getValiBusinessCode($Gadget.family.baseinfo.groupType, $Gadget.family.baseinfo.businessType);
		// 跨省家庭网成员主动退出的还不一样
		if ($Gadget.family.baseinfo.groupType=="KSJTW" 
				&& businessCode == "KSFmyMemberMgr" 
				&& $Gadget.family.subscriber.isHousehold != '1')
		{
			businessCode = "KSFmyMemberDel";
		}
		
		var order = {
			createOperId : $Gadget.family.subscriber.createProleId,
			orderType : "N",
			salesDepartId : null,
			accessChanelType : null,
			beId: this.getFamilyBeId($Gadget),
			partyRoleId : $Gadget.family.subscriber.custId,
			businessCode : businessCode,
			partyRoleType : "C",
			createDeptId : $Gadget.family.subscriber.createDeptId
		};
		//新增FMC销户设备回收扩展节点
		if($Page.mbanddevinfo && $Page.mbanddevinfo.retCode == "0000" && $Page.mbanddevinfo.MbandDevAttrInfoList){
			
			order.extInfo = order.extInfo || {
			  extNodeInfo : []
			};
		   //设置IdentityStatus为0，表示未回收
		   $.each($Page.mbanddevinfo.MbandDevAttrInfoList || [], function(i, vali) {
			   vali.identityStatus = 0;
		   });
			var extNodeInfo1 = {
						extNodeCode :"MBAND_DEV_INFO",
						extXmlString: JSON.stringify($Page.mbanddevinfobak)
				};
			order.extInfo.extNodeInfo.push(extNodeInfo1);
		}
		if(!$Controller.bes.ad.family.common.isHaveModifyMainOffer($Gadget.family.offering) && 
				$Controller.bes.ad.family.common.isHavaModifyOfferMember($Gadget.family.offering.members)) {
			order.busiFeeReqInfo = {
				itemName : $UEE.i18n('ad.sr.label.SFYYF')
			};
		}
		return order;
	},
	/**
	 * 封装主offering订单行报文
	 */
	assembleMainOfferOrderLineMsg : function($Gadget) {
		debugger;
		var valiBusinessTypeObj = $Controller.bes.ad.family.common.getValiBusinessTypeObj($Gadget.family.baseinfo.groupType, $Gadget.family.baseinfo.businessType);
		// 跨省家庭网成员主动退出的还不一样
		if ($Gadget.family.baseinfo.groupType=="KSJTW" 
				&& valiBusinessTypeObj.busiCode == "KSFmyMemberMgr" 
				&& $Gadget.family.subscriber.isHousehold != '1')
		{
			valiBusinessTypeObj.busiCode = "KSFmyMemberDel";
		}
		var productOrderLine = {};
		//0:非主offering场景 1：主offering场景
		if ($Gadget.family.baseinfo.groupType == 'KSJTW')
		{
			$Gadget.family.offering.isMainOfferScene = '1';
		}
		if("0" == $Gadget.family.offering.isMainOfferScene) {
			var relaOrderItemId = adutil.getNextNumber();
			//多终端流量共享产品退订
			if("1380000054" == $Gadget.family.offering.offeringId && $Gadget.family.offering){
				productOrderLine = this.getGroupOrderLineMsg($Gadget, $Gadget.family.offering);
			}else{
				productOrderLine = this.getUserOrderLineMsg($Gadget, $Gadget.family.subscriber);
			}			
			productOrderLine.orderItem.push(this.assembleMainOfferOrderItemMsg($Gadget, $Gadget.family.offering.attachedOffers[0], relaOrderItemId));
			productOrderLine.orderItem.concat(this.assembleAttachedOfferMsg($Gadget, $Gadget.family.offering.attachedOffers[0].subOffers, relaOrderItemId));
		}else {
			var relaOrderItemId = null;
			if($Gadget.family.baseinfo.actionTypeMap[$Gadget.family.offering.actionType]) {
				relaOrderItemId = adutil.getNextNumber();
			}
			productOrderLine = this.getGroupOrderLineMsg($Gadget, $Gadget.family.offering);
			var mainOfferOrderItemMsg = this.assembleMainOfferOrderItemMsg($Gadget, $Gadget.family.offering, relaOrderItemId);
			if(mainOfferOrderItemMsg) {
				Array.prototype.push.apply(productOrderLine.orderItem, mainOfferOrderItemMsg);
			}
			var attachedOfferMsg = this.assembleAttachedOfferMsg($Gadget, $Gadget.family.offering.attachedOffers, relaOrderItemId);
			if(attachedOfferMsg) {
				Array.prototype.push.apply(productOrderLine.orderItem, attachedOfferMsg);
			}
			
			//增加预选商品的报文组装
			debugger;
			if($Gadget.family.offering.isPresetOffersChange)
			{
				var memberOfferPresetMsg = this.assembleMemberOfferPresetMsg($Gadget, $Gadget.family.offering.presetOffers, relaOrderItemId,productOrderLine);
			}
			
			
		}
		//销户原因
		if(($Gadget.family.offering.terminateReason||[]).length>0){
			var terminateSubsExt = {
					terminateReason	: $Gadget.family.offering.terminateReason
				};
				var terminateSubsExtStr = JSON.stringify(terminateSubsExt);
				productOrderLine.extInfo.extNodeInfo[0] = {
					"extNodeCode" : "TERMINATE_EXT_INFO",
					"extXmlString" : terminateSubsExtStr
				};
		}
		//如果orderItem节点为空，则不封装订单行报文
		if(OC.Comm.isNullObj(productOrderLine.orderItem)) {
			return [];
		}
		return [productOrderLine];
	},
	/**
	 * 封装主offering订单项报文
	 */
	assembleMainOfferOrderItemMsg : function($Gadget, offering, relaOrderItemId) {
		debugger;
		offering = offering || {};
		//拼装主offering订单项
		if(!$Controller.bes.ad.family.common.isHaveModifyMainOffer(offering) && 
			$Controller.bes.ad.family.common.isHavaModifyOfferMember(offering.members)) {
			//只变更成员
			mianOfferOrderItem = this.getMemberMgrOrderItemMsg($Gadget, offering, relaOrderItemId);
		}else {
			if(!$Gadget.family.baseinfo.actionTypeMap[offering.actionType]) {
				return null;
			}
			mianOfferOrderItem = this.getOrderItemMsg($Gadget, offering, relaOrderItemId);
		}
		if(!mianOfferOrderItem.orderItemInfo){
			return mianOfferOrderItem;
		}
		//成员信息
		mianOfferOrderItem.orderItemInfo[0].orderItemMember = this.assembleMemberMsg($Gadget, mianOfferOrderItem.orderItemInfo[0].relaOrderItemId);
		//优化预选商品
		mianOfferOrderItem.orderItemInfo[0].orderItemMemberOffer = this.assemblePreSetOfferMsg($Gadget);
		//成员鉴权
		mianOfferOrderItem.orderItemInfo[0].extInfo = this.assembleMembersAuthMsg($Gadget);
		//成员支付关系
		var memberPayPlanMsg = this.assembleMembersPayPlanMsg($Gadget);
		mianOfferOrderItem.orderItemInfo[0].orderItemPayRelation = memberPayPlanMsg.orderItemPayRelations;
		mianOfferOrderItem.orderItemInfo[0].orderItemPaymentLimit = memberPayPlanMsg.orderItemPaymentLimits;
		return [mianOfferOrderItem];
	},
	/**
	 * 封装成员报文
	 * 将成员节点挂在主offering节点下
	 */
	assembleMemberMsg : function($Gadget, relaOrderItemId) {
		debugger;
		var members = $Gadget.family.offering.members;
		if(!members || members.length == 0) {
			return null;
		}
		var orderItemMembers = [];
		for(var i=0; i<members.length; i++) {
			if(!$Gadget.family.baseinfo.actionTypeMap[members[i].actionType]) {
				continue;
			}
			var memberEffModeTemp = (members[i].effMode && members[i].effMode.effectMode && members[i].effMode.effectMode[0] 
									 && members[i].effMode.effectMode[0].effectMode) || "";
			var useMemberBeId = $Gadget.family.baseinfo.groupType == "KSJTW" ? "Y" : members[i].useMemberBeId;
			var orderItemMember = {
				memberServiceNubmer : members[i].serviceNumber,
				memberId : members[i].memberId,
				memberBeId : members[i].memberBeId,
				actionType : members[i].actionType,
				subsId : members[i].subsId,
				memberName : members[i].memberName,
				memberType : members[i].memberType,
				shortNo : members[i].shortNo,
				isHousehold : members[i].isHousehold,
				groupOrderItemId : "10011002",//目前写死
				effDate : members[i].effDate,
				expDate : members[i].expDate,
				memberEffMode : members[i].isHousehold =="1"?null:memberEffModeTemp,
				confirmType : '1',// 二次确认方式，1代表短信方式
				groupSubsId : members[i].groupSubsId,
				doubleConfirm : members[i].doubleConfirm ? members[i].doubleConfirm : 0,
				orderItemMemberProp : this.assembleMemberPropMsg($Gadget, members[i]),
				useMemberBeId:useMemberBeId
			};
			orderItemMembers.push(orderItemMember);
		}
		if(orderItemMembers.length == 0) {
			return null;
		}
		return orderItemMembers;
	},
	/**
	 * 封装预选offer信息报文
	 */
	assemblePreSetOfferMsg : function($Gadget) {
		debugger;
		var presetOffers = $Gadget.family.offering.presetOffers;
		if(!presetOffers || presetOffers.length == 0) {
			return null;
		}
		var orderItemMemberOffers = [];
		for(var i=0, max=presetOffers.length; i<max; i++) {
			if(!$Gadget.family.baseinfo.actionTypeMap[presetOffers[i].actionType]) {
				continue;
			}
			var orderItemMemberOffer = {
				actionType : presetOffers[i].actionType,
				beId : this.getFamilyBeId($Gadget),
				bundleFlag : presetOffers[i].bundleFlag ? presetOffers[i].bundleFlag : presetOffers[i].bundledType,
				offeringId : presetOffers[i].offeringId,
				offeringCode : presetOffers[i].offeringCode,
				pOfferingId : presetOffers[i].pOfferingId,
				offeringInstId : presetOffers[i].offeringInstId
			};
			orderItemMemberOffers.push(orderItemMemberOffer);
		}
		if(orderItemMemberOffers.length == 0) {
			return null;
		}
		return orderItemMemberOffers;
	},

	/**
	 * 封装成员鉴权信息报文
	 */
	assembleMembersAuthMsg : function($Gadget) {
		var members = $Gadget.family.offering.members;
		if(!members || members.length == 0) {
			return null;
		}
		var memberAuthList = [];
		for(var i=0; i<members.length; i++) {
			if(!members[i].authInfo) {
				continue;
			}
			memberAuthList.push({
				serviceNumber : members[i].serviceNumber,
				subsId : members[i].subsId,
				authType : members[i].authInfo.authType,
				authTime : members[i].authInfo.authTime,
				actionType : members[i].actionType
			});
		}
		if(memberAuthList.length == 0) {
			return null;
		}
		var extInfo = {
			extNodeInfo : [{
				extNodeCode:"MEMBER_AUTH_INFO",
				extXmlString:JSON.stringify(memberAuthList)
			}]
		};
		return extInfo;
	},
	/**
	 * 封装成员代付关系
	 */
	assembleMembersPayPlanMsg : function($Gadget) {
		var members = $Gadget.family.offering.members;
		if(!members || members.length == 0) {
			return null;
		}
		var membersPayPlanMsg = {
			orderItemPayRelations : [],
			orderItemPaymentLimits : []
		};
		for(var i=0; i<members.length; i++) {
			if(!members[i].payPlans || members[i].payPlans.length==0) {
				continue;
			}
			for(var j=0; j<members.length; j++) {
				var payPlan = members[i].payPlans[j];
				if(!payPlan) {
					continue;
				}
				var relaPaymentLmtId =adutil.getNextNumber();
				membersPayPlanMsg.orderItemPayRelations.push({
					paymentRelId : payPlan.paymentRelId,//唯一编号
					relaPaymentLmtId : relaPaymentLmtId,//关联ID
					actionType : payPlan.actionType,//操作类型
					finalFlag : "N", //最终支付关系标志
					acctId : payPlan.acctId,//付费账户
					processMode : 'D',  //处理模式--> B/C/D
					chgCodeGroupId : payPlan.chgCodeGroupId,//费用代码
					priority : payPlan.priority,//支付顺序
					effDate : payPlan.effDate,//生效时间
					expDate : payPlan.expDate,//失效时间
	                subsId : payPlan.subsId,//成员subsId
	                payObjType : payPlan.payObjType,//支付类型
               		payObjId : payPlan.payObjId,//成员商品编号
               		beId : this.getFamilyBeId($Gadget)
				});
				membersPayPlanMsg.orderItemPaymentLimits.push({
					relaPaymentLmtId : relaPaymentLmtId,//关联ID
					actionType : payPlan.actionType,//操作类型
					limitType : "M", //代表money
					limitCtrlType : payPlan.paymentLmtContType ,//付费模式
					ctrlLifeCycleType : payPlan.ctrlLifeCycleType,//限额周期类型
					limitValue : payPlan.paymentLmtValue,//支付金额/比例
					acctId : payPlan.acctId,//付费账户
					effDate : payPlan.effDate,//生效时间
					expDate : payPlan.expDate,//失效时间
					subsId : payPlan.subsId//成员subsId
				});
			}
		}
		if(membersPayPlanMsg.orderItemPayRelations.length == 0) {
			return {};
		}
		return membersPayPlanMsg;
	},
	/**
	 * 封装成员属性报文
	 */
	assembleMemberPropMsg : function($Gadget, member) {
		debugger;
		if(!member.attributes || member.attributes.length == 0) {
			return null;
		}
		var orderItemMemberProps = [];
		for(var i=0; i<member.attributes.length; i++) {
			if(!$Gadget.family.baseinfo.actionTypeMap[member.attributes[i].actionType]) {
				continue;
			}
			var orderItemMemberProp = {
				propId : member.attributes[i].attrId,
				propCode : member.attributes[i].attrCode,
				propInstId : member.attributes[i].attrInstId,
				complexFlag : member.attributes[i].isComplex ? "Y" : "N",
				propValueOld : member.attributes[i].oldValue,
				propValueNew : member.attributes[i].newValue,
				actionType : member.attributes[i].actionType
			};
			orderItemMemberProps.push(orderItemMemberProp);
		}
		return orderItemMemberProps;
	},
	/**
	 * 封装成员订购商品报文
	 */
	assembleMemberOfferOrderLineMsg : function($Gadget) {
		debugger;
		var members = $Gadget.family.offering.members;
		if(!members || members.length == 0) {
			return null;
		}
		var productOrderLines = []; 
		for(var i=0; i<members.length; i++) {
			if(!members[i].offers || members[i].offers.length == 0) {
				continue;
			}
			var productOrderLine = this.getUserOrderLineMsg($Gadget, members[i]);
			for(var j=0; j<members[i].offers.length; j++) {
				if(!$Gadget.family.baseinfo.actionTypeMap[members[i].offers[j].actionType]) {
					continue;
				}
				//家庭网订购优化开户，订单需要组装applyObjType，增加标识
				$Gadget.getApplyObjType = "getApplyObjType";
				productOrderLine.orderItem.push(this.getOrderItemMsg($Gadget, members[i].offers[j]));
			}
			
			if (productOrderLine.orderItem.length == 0) {
				continue;
			}
			productOrderLines.push(productOrderLine);
		}
		if(productOrderLines.length == 0) {
			return null;
		}
		return productOrderLines;
	},
	/**
	 * 封装成员合户订单行报文
	 */
	assembleMemberUniAcctOrderLineMsg : function($Gadget) {
		debugger;
		//只针对FMC实现合户
		if('FMC' != $Gadget.family.baseinfo.groupType) {
			return null;
		}
		var members = $Gadget.family.offering.members;
		//判断offering的成员是否操作,如果没有，不用合户
		if(!$Controller.bes.ad.family.common.isHavaModifyOfferMember(members)) {
			return null;
		}
		//产品无需合户时，则不用合户
		if($Gadget.family.offering.needUniAccount != '1') {
			return null;
		}
		
		//当前户主为空时不考虑合户
		if(!$Gadget.family.offering.houseHold) {
			return null;
		}
		if(!members || members.length == 0) {
			return null;
		}
		var productOrderLines = []; 
		for(var i=0,max=members.length; i<max; i++) {
			//删除成员、与当前户主账号一致的，均无需创建合户订单行
			if(members[i].actionType == 'D' || members[i].acctId == $Gadget.family.offering.houseHold.acctId) {
				continue;
			}
			var productOrderLine = this.getUserOrderLineMsg($Gadget, members[i], "changeAccount");
			var orderItem = this.getOrderItemMsg($Gadget, members[i].mainOffer);
			orderItem.orderItemInfo[0].orderItemDftAcct = [{
				actionType : 'A',
				paymentMode : '1',
				postAcctId : $Gadget.family.offering.houseHold.acctId,
				dftAcctId : $Gadget.family.offering.houseHold.acctId
			}];
			productOrderLine.orderItem.push(orderItem);
			productOrderLines.push(productOrderLine);
		}
		if(productOrderLines.length == 0) {
			return null;
		}
		return productOrderLines;
	},
	/**
	 * 拼装主offering场景的附属offering报文
	 */
	assembleAttachedOfferMsg : function($Gadget, attachedOffers, mainOfferRelaOrderItemId) {
		debugger;
		if(!attachedOffers || attachedOffers.length == 0) {
			return null;
		}
		var orderItems = [];
		for(var i=0; i<attachedOffers.length; i++) {
			if(!$Gadget.family.baseinfo.actionTypeMap[attachedOffers[i].actionType]) {
				continue;
			}
			var orderItem = {
				itemId : attachedOffers[i].offeringId,
				itemName : attachedOffers[i].offeringName,
				quantity : "1",
				actionType : attachedOffers[i].actionType,
				itemType : "O",
				effectiveDate : attachedOffers[i].effDate,
				relaOrderItemId : adutil.getNextNumber(),
				itemInstanceId : attachedOffers[i].offeringInstId,
				// 增加$Gadget入参，以解决js报错，fix DTS2016062708774
				orderItemInfo : this.assembleSubsOfferMsg($Gadget,attachedOffers[i].subOffers)
			};
			//当主offering存在时才需要配置关联
			if(mainOfferRelaOrderItemId) {
				orderItem.orderItemRelation = [{
					relationType : "S",
					refRelaOrderItemId : mainOfferRelaOrderItemId
				}]
			}
			orderItems.push(orderItem);
		}
		if(orderItems.length == 0) {
			return null;
		}
		return orderItems;
	},
	/**
	 * 封装子offering信息
	 */
	assembleSubsOfferMsg : function($Gadget,offerings) {
		debugger;
		if(!offerings || offerings.length == 0) {
			return null;
		}
		var orderItemInfos = [];
		for(var i=0; i<offerings.length; i++) {
			if(!$Gadget.family.baseinfo.actionTypeMap[offerings[i].actionType]) {
				continue;
			}
			var orderItemInfo = {
				itemId : offerings[i].offeringId,
				itemName : offerings[i].offeringName,
				itemType : "O",
				actionType : offerings[i].actionType,
				effectiveDate : offerings[i].effDate,
				relaOrderItemId : adutil.getNextNumber(),
				itemInstanceId : offerings[i].offeringInstId
			};
			orderItemInfos.push(orderItemInfo);
		}
		if(orderItemInfos.length == 0) {
			return null;
		}
		return orderItemInfos;
	},
	/**
	 * 统一校验
	 */
	validate : function($Gadget, $UI) {
		debugger;
		
		//校验FMC注销是否进行主号变更
		if($Gadget.family.baseinfo.groupType=="FMC" && $Page.CancelDeregisterFMCFlag 
			&& $Gadget.family.offerings.length<=0 && $Gadget.family.offering.offeringId == "1380100001"){
			$UI.msgbox.info($UEE.i18n("AD.FAMILY.LABEL.TIPS"), "主号必须进行主体商品变更。");
			return false;


		}

		//DTS2016111503285 增加校验
		if($Gadget.family.baseinfo.businessType === 'familyInstall' && $Gadget.family.offering.belongGroupId) {
			$UI.msgbox.info($UEE.i18n("AD.FAMILY.LABEL.TIPS"), "页面操作有误，请清除浏览器缓存后重新操作。");
			return false;
		}

		//校验当前页面
		if(!$Gadget.family.baseinfo.businessType || !this.isHaveModifyFamilyData($Gadget)) {
			$UI.msgbox.info($UEE.i18n("AD.FAMILY.LABEL.TIPS"), $UEE.i18n("AD.FAMILY.TIPS.NOT_REPEAR_ORD"));//当前页面无修改，不需要重复订购
			return false;
		}



		
		//校验成员
		if(typeof $Gadget.family.callback.validateMemberCB === 'function') {
			return $Gadget.family.callback.validateMemberCB();
		}
	},
	/**
	 * 获取群用户订单行报文
	 * offering 主offering信息
	 * 
	 */
	getGroupOrderLineMsg : function($Gadget, offering) {
		debugger;
		var valiBusinessTypeObj = $Controller.bes.ad.family.common.getValiBusinessTypeObj($Gadget.family.baseinfo.groupType, $Gadget.family.baseinfo.businessType);
		// 跨省家庭网成员主动退出的还不一样
		if ($Gadget.family.baseinfo.groupType=="KSJTW" 
				&& valiBusinessTypeObj.busiCode == "KSFmyMemberMgr" 
				&& $Gadget.family.subscriber.isHousehold != '1')
		{
			valiBusinessTypeObj.busiCode = "KSFmyMemberDel";
		}
		
		var productOrderLine = {
			businessCode : valiBusinessTypeObj.busiCode,
			operationType : valiBusinessTypeObj.operationType,
			ownerType : "G",
			mainProductId : offering.product && offering.product[0] && offering.product[0].prodId,
			productInstId : offering.product && offering.product[0] && offering.product[0].prodInstId,
			ownerId : offering.belongGroupId,
			orderItem : [],
			extInfo: {
				extNodeInfo : []
			}
		};
		//拼接短号开通报文
//		if ($Page.isNeedVpmnCode) {
//			productOrderLine.extInfo = this.assembleShortNumExtendOrderLineMsg($Gadget);
//		}
		this.assembleShortNumExtendOrderLineMsg($Gadget, productOrderLine);
		return productOrderLine;
	},
	/**
	 * 获取个人用户订单行报文
	 * subscriber 个人用户信息
	 */
	getUserOrderLineMsg : function($Gadget, subscriber, businessType) {
		debugger;
		if(!businessType) {
			businessType = $Gadget.family.baseinfo.businessType;
		}
		var valiBusinessTypeObj = $Controller.bes.ad.family.common.getValiBusinessTypeObj($Gadget.family.baseinfo.groupType, businessType);
		// 跨省家庭网成员主动退出的还不一样
		if ($Gadget.family.baseinfo.groupType=="KSJTW" 
				&& valiBusinessTypeObj.busiCode == "KSFmyMemberMgr" 
				&& $Gadget.family.subscriber.isHousehold != '1')
		{
			valiBusinessTypeObj.busiCode = "KSFmyMemberDel";
		}
		
		if(subscriber.memberBeId != $Page.contextInfo.beId && $Page.isQueryMemberTypeByProductId){
			var productOrderLine = {
					businessCode : valiBusinessTypeObj.busiCode,
					operationType : valiBusinessTypeObj.operationType,
					ownerType : "S",
					mainProductId : subscriber.mainProdId,
					ownerId : subscriber.subsId,
					beId : subscriber.beId,
					ownerBeId : subscriber.memberBeId,
					serviceNumber : subscriber.serviceNumber,
					orderItem : []
				};
		}else{
			var productOrderLine = {
					businessCode : valiBusinessTypeObj.busiCode,
					operationType : valiBusinessTypeObj.operationType,
					ownerType : "S",
					mainProductId : subscriber.mainProdId,
					ownerId : subscriber.subsId,
					beId : subscriber.beId,
					orderItem : []
				};
		}
		return productOrderLine;
	},
	/**
	 * 获取订单信息报文
	 */
	getOrderItemMsg : function($Gadget, offering, relaOrderItemId) {
		debugger;
		if(!relaOrderItemId) {
			relaOrderItemId = adutil.getNextNumber();
		}
		
		// 如果生效时间早于当前时间，则不传
		var effectiveDate = offering.effDate;
		if (effectiveDate && (effectiveDate < $Gadget.$Page.TimeUtil.nowDateFirstSecond)) {
			effectiveDate = undefined;
		}
		
		var orderItem = {
				itemId : offering.offeringId,
				itemName : offering.offeringName,
				quantity : "1",
				actionType : offering.actionType,
				itemType : "O",
				effectiveDate : effectiveDate,
				expiryDate : offering.expDate || offering.expireDate,
				itemInstanceId : offering.offeringInstId,
				relaOrderItemId : relaOrderItemId,
				applyObjType: offering.belongGroupId ? "X" : null,      //预选成员商品需要此字段
				//applyObjType: "X",
				applyObjId : offering.belongGroupId,
				orderItemInfo : null
		};
		//家庭网订购优化，前台开户需要传入applyObjType，OM根据判断 
		if('FMC' != $Gadget.family.baseinfo.groupType && $Gadget.getApplyObjType == "getApplyObjType"){
			orderItem.applyObjType = "X";
			$Gadget.getApplyObjType = null;
		}
		if(offering.product) {
			orderItem.orderItemInfo = [{
				itemId : offering.product[0] && offering.product[0].prodId,
				itemType : "P",
				quantity : "1",
				actionType : offering.actionType,
				effectiveDate : offering.effDate,
				expiryDate : offering.expDate,
				itemInstanceId : offering.product[0] && offering.product[0].prodInstId,
				relaOrderItemId : adutil.getNextNumber(),
				orderItemRelation : [{
					relationType : "P_O",
					refRelaOrderItemId : relaOrderItemId
				}],
				orderItemMember : null,
				extInfo : null
			}];
		}
		return orderItem;
	},
	/**
	 * 只变更成员信息时 封装订单项报文
	 */
	getMemberMgrOrderItemMsg : function($Gadget, offering, relaOrderItemId) {
		debugger;
		if(!relaOrderItemId) {
			relaOrderItemId = adutil.getNextNumber();
		}
		var orderItem = {
			itemId : offering.offeringId,
			itemName : offering.offeringName,
			actionType : "M",
			itemType : "O",
			itemInstanceId : offering.offeringInstId,
			relaOrderItemId : relaOrderItemId,
			isBindOffer : offering.isBundled ? "Y" : "N",
			orderItemInfo : null
		};
		if(offering.product) {
			orderItem.orderItemInfo = [{
				itemId : offering.product[0] && offering.product[0].prodId,
				itemType : "P",
				actionType : "M",
				itemInstanceId : offering.product[0] && offering.product[0].prodInstId,
				relaOrderItemId : adutil.getNextNumber(),
				orderItemMember : null,
				extInfo : null
			}];
		}
		return orderItem;
	},
	/**
	 * 判断是否修改数据
	 * 根据offering、subOffers、attachedOffers、members下的acionType是否存在A/M/D情况
	 * 定义操作类型对象 用于判断是否存在新增、修改、删除三种操作类型
	 */
	isHaveModifyFamilyData : function($Gadget) {
		debugger;
		var offering = $Gadget.family.offering;
		//判断主offering是否操作
		if($Controller.bes.ad.family.common.isHaveModifyMainOffer(offering)) {
			return true;
		}
		//判断附属offering是否操作
		if($Controller.bes.ad.family.common.isHaveModifyAttachedOffer(offering.attachedOffers)) {
			return true;
		}
		//判断offering的成员是否操作
		if($Controller.bes.ad.family.common.isHavaModifyOfferMember(offering.members)) {
			return true;
		}
		//判断预选成员offering是否操作
		if($Gadget.family.offering.isPresetOffersChange && $Gadget.family.offering.presetOffers && $Gadget.family.offering.presetOffers.length > 0 )
		{
			return true;
		}	
		
		return false;
	},
	/**
	 * 注销家庭offering
	 */
	canelFamilyOffer : function($Page, $Gadget, $Fire, $UI) {
		debugger;

		
		//设置注销业务类型
		$Gadget.family.baseinfo.businessType = "familyDropSubs";
		//主offer置为删除
		$Gadget.family.offering.actionType = 'D';
		//将附属offering操作类型设置为空
		for(var i=0; i<($Gadget.family.offering.attachedOffers||[]).length; i++) {
			$Gadget.family.offering.attachedOffers[i].actionType = '';
		}
		//注销主offering时 户主操作类型位置为删除 其他为空
		for(var j=0; j<($Gadget.family.offering.members||[]).length; j++) {
			if($Gadget.family.offering.members[j].isHousehold == '1') {
				$Gadget.family.offering.members[j].actionType = 'D';
				$Gadget.family.offering.members[j].expDate = null;//将户主失效时间设置为空
			}else {
				$Gadget.family.offering.members[j].actionType = '';
			}
		}
		$Gadget.family.offering.expDate = null;//将主offering失效时间设置为空
		//需要恢复初始化数据
		$Page.needRecoverInitData = true;
		if($Gadget.family.baseinfo.groupType!="FMC"){
		this.submit($Page, $Gadget, $Fire, $UI);
	}
	},
	/**
	 * 设置户主操作
	 */
	setMainNumMember : function($Page, $Gadget, $Fire, $UI) {
		debugger;
		//主offer操作类型设置为空
		$Gadget.family.offering.actionType = '';
		//将附属offering操作类型设置为空
		for(var i=0; i<($Gadget.family.offering.attachedOffers||[]).length; i++) {
			$Gadget.family.offering.attachedOffers[i].actionType = '';
		}
		//需要恢复初始化数据
		$Page.needRecoverInitData = true;
		this.submit($Page, $Gadget, $Fire, $UI);
	},
	/**
	 * 封装短号发送
	 * 修改为如果有VPMN编码就封装对应报文，否则不封装对应报文
	 */
	assembleShortNumExtendOrderLineMsg: function($Gadget, productOrderLine) {
		debugger;
		if(!$Gadget.family.offering.vpmn || !$Gadget.family.offering.vpmn.body || !$Gadget.family.offering.vpmn.body.vpmn) {
			return false;
		} 
		var extNodeInfoList = {
			"vPMNCode": $Gadget.family.offering.vpmn && $Gadget.family.offering.vpmn.body.vpmn
		};
		productOrderLine.extInfo = productOrderLine.extInfo || {};
		productOrderLine.extInfo.extNodeInfo = productOrderLine.extInfo.extNodeInfo || [];
		productOrderLine.extInfo.extNodeInfo.push({
			extNodeCode: "EC_SUB_EX_INFO",
			extXmlString: JSON.stringify(extNodeInfoList)
		});
		
		/*productOrderLine.extInfo = {
			extNodeInfo: [{
				extNodeCode: "EC_SUB_EX_INFO",
				extXmlString: JSON.stringify(extNodeInfoList)
			}]
		};*/
		return true;
	},
	
	/**
	 * 先获取群用户beid，如果不存在，则获取当前登录用户beid
	 */
	getFamilyBeId : function($Gadget) {
		var beId = $Gadget.family.offering && $Gadget.family.offering.beId;
		if(!beId) {
			beId = $Gadget.family.subscriber.beId;
		}
		return beId;
	},
	
	/**
	 * 恢复baseinfo对象的初始化值
	 */
	recoverFamilyBaseinfo : function($Gadget) {
		//当切换群组主产品时，恢复初始化值
		$Gadget.family.baseinfo.showMemberOperBtn = true;
		$Gadget.family.baseinfo.showProductChgBtn = false;
		$Gadget.family.baseinfo.businessType = '';//业务类型默认为空
		$Gadget.family.baseinfo.belongGroupIds = [];
		$Page.isFMCChangeProduct = false; // FMC档次变更
	},
	
	/**
	 * 封装预选offer信息报文 add by ywx285882 20161130
	 */
	assembleMemberOfferPresetMsg : function($Gadget, memberOfferPreset, relaOrderItemId,productOrderLine)
	{
		debugger;
		if(!memberOfferPreset || memberOfferPreset.length == 0 || $Gadget.family.baseinfo.actionTypeMap[$Gadget.family.offering.actionType]) {
			return null;
		}
		if(!relaOrderItemId) {
			relaOrderItemId = adutil.getNextNumber();
		}
		var offering = $Gadget.family.offering;
		orderItem = {
			itemId : offering.offeringId,
			itemName : offering.offeringName,
			quantity : "1",
			actionType : "M",
			itemType : "O",
			itemInstanceId : offering.offeringInstId,
			relaOrderItemId : relaOrderItemId,
			orderItemInfo : null
		};
			
			if(offering.product) {
				orderItem.orderItemInfo = [{
					itemId : offering.product[0] && offering.product[0].prodId,
					itemType : "P",
					quantity : "1",
					actionType : "M",
					itemInstanceId : offering.product[0] && offering.product[0].prodInstId,
					relaOrderItemId : adutil.getNextNumber(),
					orderItemRelation : [{
						relationType : "P_O",
						refRelaOrderItemId : relaOrderItemId
					}],
					orderItemMember : null,
					extInfo : null
				}];
			}
			
		//优化预选商品
		orderItem.orderItemInfo[0].orderItemMemberOffer = this.assemblePreSetOfferMsg($Gadget);
		productOrderLine.orderItem = productOrderLine.orderItem || [];
		productOrderLine.orderItem.push(orderItem);
		return orderItem;
	},
	
	back :function ($Page, $Event){
		debugger;
		if(!$Page.ckeckoutFlag){
			$Fire({
				'targetstep':'index'
			},$Gadget);
		}else{
			$Page.ckeckoutFlag=false;
			$("#famlybaseinfomain_inner").show();
		}
		
	}
});