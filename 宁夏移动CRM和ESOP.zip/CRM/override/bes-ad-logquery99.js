$Controller("bes.ad.logquery",  {
	init: function($Gadget,$Fire, $Model){
		debugger;
		
		$('#BackQueryId').attr('disabled',null);
		$('#QueryId').attr('disabled',null);
		$Page.UserInfoTabId = 'queryBesLog'; //默认bes查询
		 // 判断是否是CSP系统调用
	    if($Controller.bes.ad && $Controller.bes.ad.csp && $Controller.bes.ad.csp.common)
		{
			$Page.isCsp = $Controller.bes.ad.csp.common.isCsp();
		}

		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		//请求全省beid
		$Fire({
			service : 'ucec/v1/common/qrysystemparambykey',
			params : {
				key : "60101099"
			},
			target : '$Gadget.provinceBeid',
			onafter : function($Gadget) {
				debugger;
				$Gadget.showHtml = true;
				
				$Fire({
					service: "/common/dictkey2",
					params: {"dictkeylist": ['OC.AREA.TYPE']},
					target: "$Gadget.areaId",
					onafter: function ($Gadget,$Fire,$UI) {
						debugger;
						
						var areaListTemp = [];
						
						for(var i = 0;i < $Gadget.areaId['OC.AREA.TYPE'].length;++i){
							if($Gadget.provinceBeid == $Gadget.areaId['OC.AREA.TYPE'][i].key){
								continue;
							}
							var oneArea = $Gadget.areaId['OC.AREA.TYPE'][i];
							oneArea.value = oneArea.key+oneArea.value;
							areaListTemp.push(oneArea);
						}
						$Gadget.areaList = areaListTemp;
						
						if(!$Gadget.$Page.contextForBuriedPoints){
							// 查询上下文登录id
					        $Fire({
					            service : "bes.oc.querycontextservice/querycontextinfo",
					            target : "$Gadget.$Page.contextForBuriedPoints",
					            onafter : function($Gadget) {
					                debugger;
					                $Gadget.areaBeId = $Gadget.$Page.contextForBuriedPoints.beId || $Gadget.areaList[0].key;
					            }
					        },$Gadget);
						}else{
							$Gadget.areaBeId = $Gadget.$Page.contextForBuriedPoints.beId || $Gadget.areaList[0].key;
						}
						
					}
				}, $Gadget);
			}
		}, $Gadget);
		
		//$Gadget.showHtml = true;
		$Gadget.isShowNodata = false; //是否显示无数据
		$Gadget.logQuery = {};
		
		// 初始化是否为客服内嵌系统，若是的话需要获取客服内嵌中相应地址的ip的端口号以获取详情
		$Gadget.isCsp = $Controller.bes.ad.csp.common.isCsp();
		$Gadget.crmUrlPort = null;

		if ($Gadget.isCsp)
		{
			$Gadget.crmUrlPort = $Controller.bes.ad.csp.common.getCrmUrlPort();
			// 获取号码
			$Gadget.logQuery.serviceNumber = $Controller.bes.ad.csp.common
                        				.getServNumber();
		}else{
			$Gadget.logQuery.serviceNumber = adutil.getParam("servNumber")||"";
		}

		$Model.selectionResult = [];
		var oneSelectResult={};
		oneSelectResult.employeeId = adutil.getParam("staffId")||"";
		oneSelectResult.employeeName = adutil.getParam("staffName")||"";
		$Model.selectionResult.push(oneSelectResult);
		$Gadget.data = {};
		$Gadget.pageRecNumPerPage = 20;// 日志列表显示行数
		$Gadget.acceptLogMainInfo = [];	
		// 支付方式
		$Gadget.data.PayTypeoptions = [];	
		// 其他条件数据
		$Gadget.data.OtherConditionDict = [];	
		$Gadget.data.acceptedMethodDropList = [];
		// 单据查询数据
		$Gadget.data.invoiceTypeDropList = [];
		$Gadget.data.invoiceTypeMapList = {};
		// 受理方式数据
		$Gadget.data.RecWayOptions = [];
		// 受理状态
		$Gadget.data.RecStatusOptions = [];
		$Gadget.data.RecStatusOptionsMapList = {};
		// 业务大类
		$Gadget.data.BusiClassOptions = [];
		// 支付方式
		$Gadget.data.PayTypeoptions = [];
		// 排序方式
		$Gadget.data.SortTypeOptions = [];
		// 导出功能
		$Gadget.doExport = {};
		// 查询返回结果
		$Gadget.queryResult = {};
		//DTS2015120501673 默认全部展示
		$Gadget.showMoreUserInfoFlag = false;
		this.initdate($Gadget);

		//操作员是否可以查看用户身份证照片
		$Gadget.viewPhotoAuth = false;

		//保存最原始的ucd方法，防止被SM的js影响
		UCD.newpages = UCD.Pages;
		
		// 访问查询接口参数
		$Gadget.params = {
				header : {},
				totalRowNum : 0,
				body : {
				}	
		};

		$Gadget.queryResult = {
			body : {
				totalRecFee : 0,
				totalDiscount : 0
			}
		};
	
		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		//this.queryBusiCode($Gadget, $Fire);
		// 查字典
    	$Fire({
			service: "/common/dictkey",
			params: {"dictkeylist": ['OC.BUSITYPE.TYPE','CM_CERT_TYPE_JS','OC.BSAC.TYPE','OC.STCM.TYPE','OC.RCTP.TYPE','OC.RECEIPT.TYPE','OC.ACCEPTLOGSORT.TYPE','OM_ORDER_PAYMENT_METHOD','OC.ACCEPTOTHERCONDITION.TYPE','OM_REC_SUBBUSICODE','PM_PAYMENT_MODE','PM_APPLY_ENTITY_TYPE','OC.ICRM_BUSITYPE_TYPE']},
			target: "$Gadget.data.DictList",
			onafter: function ($Gadget) {
				
				$Gadget.data.paymentTypeMap = {};
		    	$Gadget.data.custTypeMap={};
		    	// 支付类型
				var paymentTypeDictList = $Gadget.data.DictList["PM_PAYMENT_MODE"] || [];
				for(var i = 0 ; i< paymentTypeDictList.length ; ++i){
					$Gadget.data.paymentTypeMap[paymentTypeDictList[i].itemCode] = paymentTypeDictList[i].itemName;
				}
				
				//用户类型
				var custTypeList = $Gadget.data.DictList["PM_APPLY_ENTITY_TYPE"] || [];
				for(var i = 0 ; i< custTypeList.length ; ++i){
					$Gadget.data.custTypeMap[custTypeList[i].itemCode] = custTypeList[i].itemName;
				}
				
		    	// 单据打印类型
		    	var invoiceTypeDictList = $Gadget.data.DictList["OC.RECEIPT.TYPE"] || [];
		    	var invoiceTypeDropListTmp = [];
		    	invoiceTypeDropListTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< invoiceTypeDictList.length ; ++i){
		    
		    		if ('1' == invoiceTypeDictList[i].itemCode){
                		$Gadget.paperInvoiceType = invoiceTypeDictList[i].itemName;
                	}
		    		else if ('3' == invoiceTypeDictList[i].itemCode){ 
                        $Gadget.digitInvoiceType = invoiceTypeDictList[i].itemName;
                    }
		    		else if ('4' == invoiceTypeDictList[i].itemCode){
                    	$Gadget.paperAndigitInvoiceType = invoiceTypeDictList[i].itemName;
                    }
		    		
					invoiceTypeDropListTmp.push({"key":invoiceTypeDictList[i].itemCode ,"value":invoiceTypeDictList[i].itemName});
				}
				$Gadget.data.invoiceTypeDropList = invoiceTypeDropListTmp;
				
				// 受理类型
				var acceptedTypeDictList = $Gadget.data.DictList["OM_REC_SUBBUSICODE"] || [];
				//icrm侧 未割接到BES的业务类型，为了适配icrm日志查询
				if($Gadget.data.DictList["OC.ICRM_BUSITYPE_TYPE"] && $Gadget.data.DictList["OC.ICRM_BUSITYPE_TYPE"].length>0){
					acceptedTypeDictList = acceptedTypeDictList.concat($Gadget.data.DictList["OC.ICRM_BUSITYPE_TYPE"]);
				}
		    	var acceptedTypeTmp = [];
		    	//acceptedTypeTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< acceptedTypeDictList.length ; ++i){
					acceptedTypeTmp.push({"key":acceptedTypeDictList[i].itemCode ,"value":acceptedTypeDictList[i].itemName});
				}
				$Gadget.data.acceptedTypeDropList = acceptedTypeTmp;

				var isSort = false;
				
				try{
					$Fire({
						service: "/ucec/v1/qryBusiCodeList",
						params: {},
						target: "$Gadget.data.queryBusiCodeListResp",
						onafter : function($Gadget) {
							if($Gadget.data.queryBusiCodeListResp && $Gadget.data.queryBusiCodeListResp.busiCodeInfoList){
								$Gadget.data.acceptedTypeDropList = acceptedTypeTmp.concat($Gadget.data.queryBusiCodeListResp.busiCodeInfoList);
							}
							if($Gadget.data.acceptedTypeDropList){
								$Gadget.data.acceptedTypeDropList.sort(function(x,y){
									return x["value"].localeCompare(y["value"]);
								});
								isSort = true;
								$Gadget.data.acceptedTypeDropList.splice(0,0,{"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
							}
						}
					}, $Gadget);
				}catch(e){
				}
				
//				if($Gadget.data.acceptedTypeDropList  && isSort==false){
//					$Gadget.data.acceptedTypeDropList.sort(function(x,y){
//						return x["value"].localeCompare(y["value"]);
//					});
//					isSort = true;
//				}
				
				
				// 受理方式数据
				var acceptedMethodDictList = $Gadget.data.DictList["OC.BSAC.TYPE"] || [];
		    	var acceptedMethodTmp = [];
		    	acceptedMethodTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< acceptedMethodDictList.length ; ++i){
					acceptedMethodTmp.push({"key":acceptedMethodDictList[i].itemCode ,"value":acceptedMethodDictList[i].itemName});
				}
				$Gadget.data.acceptedMethodDropList = acceptedMethodTmp;
				
				// 受理状态
				var RecStatusDictList = $Gadget.data.DictList["OC.STCM.TYPE"] || [];
		    	var RecStatusOptionsTmp = [];
		    	RecStatusOptionsTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< RecStatusDictList.length ; ++i){
					RecStatusOptionsTmp.push({"key":RecStatusDictList[i].itemCode ,"value":RecStatusDictList[i].itemName});
					// $Gadget.data.RecStatusOptionsMapList[RecStatusDictList[i].itemCode]
					// = RecStatusDictList[i].itemName;
				}
				$Gadget.data.RecStatusOptions = RecStatusOptionsTmp;
				
				// 业务大类
				var BusiClassDictList = $Gadget.data.DictList["OC.RCTP.TYPE"] || [];
		    	var BusiClassOptionsTmp = [];
		    	BusiClassOptionsTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< BusiClassDictList.length ; ++i){
					BusiClassOptionsTmp.push({"key":BusiClassDictList[i].itemCode ,"value":BusiClassDictList[i].itemName});
				}
				$Gadget.data.BusiClassOptions = BusiClassOptionsTmp;
				
				// 排序方式
				var SortTypeDictList = $Gadget.data.DictList["OC.ACCEPTLOGSORT.TYPE"] || [];
		    	var SortTypeOptionsTmp = [];
		    	SortTypeOptionsTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< SortTypeDictList.length ; ++i){
					SortTypeOptionsTmp.push({"key":SortTypeDictList[i].itemCode ,"value":SortTypeDictList[i].itemName});
				}
				$Gadget.data.SortTypeOptions = SortTypeOptionsTmp;
				
				// 支付方式
				var paymentMethodDictList = $Gadget.data.DictList["OM_ORDER_PAYMENT_METHOD"] || [];
		    	var paymentMethodTmp = [];
		    	paymentMethodTmp.push({"key":"","value":$UEE.i18n('ad.sr.message.SY'),"selected":true}); //所有
		    	for(var i = 0 ; i< paymentMethodDictList.length ; ++i){
					paymentMethodTmp.push({"key":paymentMethodDictList[i].itemCode ,"value":paymentMethodDictList[i].itemName});
				}
				$Gadget.data.PayTypeoptions = paymentMethodTmp;
				
				
				// 其他条件 多选框
				var OtherConditionDictList = $Gadget.data.DictList["OC.ACCEPTOTHERCONDITION.TYPE"] || [];
		    	var OtherConditionDictTmp = [];
				for(var i = 0 ; i< OtherConditionDictList.length ; ++i){
					OtherConditionDictTmp.push({"key":OtherConditionDictList[i].itemCode ,"value":OtherConditionDictList[i].itemName});
				}
				$Gadget.data.OtherConditionDict = OtherConditionDictTmp;
				// $Gadget.data.OtherConditionDict =
				// [{'key':'incRollback','value':'不显示回退业务'},{'key':'incBackProcess','value':'包含后台业务'},{'key':'relaRequest','value':'查询相关受理'},{'key':'noPrintInvoice','value':'查询未打印发票业务'}];
				$Controller.bes.ad.logquery.paramControl($Gadget, $Fire);
				$Controller.bes.ad.logquery.buttonControl($Gadget, $Fire);
			}
		}, $Gadget);
    	
    	$Gadget.areaTreeMap = {};
    	
    	//校验当前操作员身份证照片查看令牌权限
    	this.validateOperAuth($Fire, $Gadget);
    	$Gadget.thlength = $('tbody th').length;
    	
    	this.queryCurrentOperator($Gadget,$Fire,$Model);//异步处理查询当前操作员
    	//this.paramControl($Gadget, $Fire);
    	//this.buttonControl($Gadget, $Fire);
	},
	validateOperAuth: function($Fire, $Gadget){
		$Fire({
			'service' : 'ocauthenticationboservice/checkauthbyloginidauth',
			'target' : '$Gadget.viewPhotoAuthInfo',
			'params' : {"req": '6013120180608113321'},
  
			onafter : function($Gadget) {
				debugger;
				var authInfo = (($Gadget.viewPhotoAuthInfo || '').split('^') || [])[1];
				if (authInfo === 'Y'){
					$Gadget.viewPhotoAuth = true;
				}
			}
		}, $Gadget);
	},
	getEmployee: function($Gadget,$Model){
		debugger;
		//操作员id列表，用于传给后台
		$Gadget.arrSelectEmployeeId = [];
		$Model.selectionResult.employeeCode_selfInput = '';
		if(!$Model.selectionResult || 0 == $Model.selectionResult.length){
			return false;
		}
		//操作员id列表，用于传给后台
		//$Model.selectionResult.employeeCode_selfInput = $Model.selectionResult[i].employeeCode;
		//$Gadget.arrSelectEmployeeId.push($Model.selectionResult[i].employeeId);
		for(var i = 0; i < $Model.selectionResult.length; ++i){
			if(0 != i){
				$Model.selectionResult.employeeCode_selfInput += ',';
			}
			$Model.selectionResult.employeeCode_selfInput += $Model.selectionResult[i].employeeCode;
			$Gadget.arrSelectEmployeeId.push($Model.selectionResult[i].employeeId);
		}
		//多选后前台展示的内容$Gadget.selectDisPlayEmployeeId
		$Gadget.selectDisPlayEmployeeId = $Model.selectionResult.employeeCode_selfInput;
	},
	paramControl: function($Gadget,$Fire){
		debugger;
		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		$Fire({
			service : 'ucec/v1/oclogspecialparacontrolboservice/specialparacontrol',
			params : {
				header : {}
			},
			target : '$Gadget.paramControlResult',
			onafter : function(){
				debugger;
				if(!$Gadget.paramControlResult || !$Gadget.paramControlResult.body){
					return false;
				}

				//是否展示单据类型
				if('Y' == $Gadget.paramControlResult.body.qryRecByRecipientType ||
				     '1' == $Gadget.paramControlResult.body.qryRecByRecipientType){
					$Gadget.disPlayRecipientType = true;
					//是否江苏单据
					if('Y' == $Gadget.paramControlResult.body.addInvoiceTypeForJS ||
					    '1' == $Gadget.paramControlResult.body.addInvoiceTypeForJS){
						//$Gadget.data.invoiceTypeDropList.splice(3);
						$Gadget.data.invoiceTypeDropListTemp=[];
						for(var i = 0;i<$Gadget.data.invoiceTypeDropList.length;++i){
							if('' == $Gadget.data.invoiceTypeDropList[i].key ||
								'1' == $Gadget.data.invoiceTypeDropList[i].key ||
									'3' == $Gadget.data.invoiceTypeDropList[i].key){
								$Gadget.data.invoiceTypeDropListTemp.push($Gadget.data.invoiceTypeDropList[i]);
							}
						}
						$Gadget.data.invoiceTypeDropList = $Gadget.data.invoiceTypeDropListTemp;
						//$Gadget.data.invoiceTypeDropList = [{key:"",value:$UEE.i18n('ad.sr.message.SY'),selected:true},{key:"1",value:"电子单据"},{key:"2",value:"纸质单据"}]; //所有
					}
				}
				//是否展示支付方式
				if('Y' == $Gadget.paramControlResult.body.qryRecByPayType || 
				    '1' == $Gadget.paramControlResult.body.qryRecByPayType ){
					$Gadget.disPayType = true;
				}
				//是否显示回退业务
				if('Y' != $Gadget.paramControlResult.body.isOnlyShowRolledLog && 
				     '1' != $Gadget.paramControlResult.body.isOnlyShowRolledLog){
					for(var i = 0 ; i < $Gadget.data.OtherConditionDict.length; ++i){
						if('incRollback' == $Gadget.data.OtherConditionDict[i].key){
							$Gadget.data.OtherConditionDict.splice(i,1);
							break;
						}
					}
				}
				//是否查询未打印发票业务
				if('Y' != $Gadget.paramControlResult.body.isShowPrintInvoice &&
				     '1' != $Gadget.paramControlResult.body.isShowPrintInvoice){
					for(var i = 0 ; i < $Gadget.data.OtherConditionDict.length; ++i){
						if('noPrintInvoice' == $Gadget.data.OtherConditionDict[i].key){
							$Gadget.data.OtherConditionDict.splice(i,1);
							break;
						}
					}
				}
				//是否包含后台业务
				if('Y' != $Gadget.paramControlResult.body.queryLogShowBack &&
				    '1' != $Gadget.paramControlResult.body.queryLogShowBack){
					for(var i = 0 ; i < $Gadget.data.OtherConditionDict.length; ++i){
						if('incBackProcess' == $Gadget.data.OtherConditionDict[i].key){
							$Gadget.data.OtherConditionDict.splice(i,1);
							break;
						}
					}
				}
				//能否进行单据下载，能否现在单据下拉框
				if('Y' == $Gadget.paramControlResult.body.qryRecByRecipientType ||
				    '1' == $Gadget.paramControlResult.body.qryRecByRecipientType){
					$Gadget.canDownLoadProto = true;
				}
				//能否隔月查询
				//if('Y' != $Gadget.paramControlResult.body.allowSpanMonth4LogQry){
				//	$Gadget.cannotSpanMonth = true;
				//	var toDate = new Date();
				//	toDate.setHours(23, 59, 59);
				//	var fromDate = $Controller.bes.ad.logquery.getPrevNMonth(toDate,null,1);
				//	fromDate.setHours(0, 0, 0);
				//	$Gadget.logQuery.fromDate = fromDate.getTime();
				//	$Gadget.initFromDate = $Gadget.logQuery.fromDate; 
				//	$("#beginTime>input").val(fromDate.Format("yyyy-MM-dd hh:mm:ss"));
				//}
				//江苏日志查询显示归属单位和归属地区
				if('Y' == $Gadget.paramControlResult.body.logShowOwnerOrg ||
				   '1' == $Gadget.paramControlResult.body.logShowOwnerOrg){
					$Gadget.showBeIdNotDepId = true;
				}
				
				//展现子业务类型
				if('Y' == $Gadget.paramControlResult.body.showSubRecType ||
				   '1' == $Gadget.paramControlResult.body.showSubRecType){
					$Gadget.showSubRecType = true;
				}
				
				//showOwnerRegion 开启时展示客户归属地，不开启展示是否异地
				if('Y' == $Gadget.paramControlResult.body.showOwnerRegion ||
				   '1' == $Gadget.paramControlResult.body.showOwnerRegion){
					$Gadget.showOwnerRegion = true;
				}
			}
		}, $Gadget);
	},
	buttonControl: function($Gadget,$Fire){
		debugger;

		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		$Fire({
			service : 'ucec/v1/oclogspecialparacontrolboservice/specialparaauthoritycontrol',
			params : {
				header : {}
			},
			target : '$Gadget.buttonControlResult',
			onafter : function(){
				debugger;
				if(!$Gadget.buttonControlResult || !$Gadget.buttonControlResult.body){
					return false;
				}
				
				//modiby by lwx207718 on 2015-11-21 for DTS2015112008259
				//1、是否有打印权限 没有这个权限时展示导出，反之不展示。
				if($Gadget.buttonControlResult.body.logQueryNoPrintRight)
				{
					$Gadget.disprintButton = false;
				}
				else
				{
					$Gadget.disprintButton = true;
				}
				
				//2、是否查询全省单位  以及能不查看费用信息
				$Gadget.qryProvinceOrg = false;
				if($Gadget.buttonControlResult.body.qryProvinceOrg){
					$Gadget.qryProvinceOrg = true;//详情里面显示费用信息
					//$Gadget.disprintButton = true;//显示打印按钮
                    $Gadget.showCityList = true;
				}
				
				//3、能否查看其他操作员
				if($Gadget.buttonControlResult.body.logQueryManager){
					$Gadget.canQueryOtherOperator = true;
				}//else{
				//	$Controller.bes.ad.logquery.queryCurrentOperator($Gadget,$Fire);
				//}
				
				$Gadget.selectMode = '1';
				if($Gadget.buttonControlResult.body.canMutualQueryLog){
					$Gadget.canQueryOtherOperator = true;
					$Gadget.selectMode = '2';
				}
				
				if ($Page.contextForBuriedPoints.operBeId == "999"){
					$Gadget.canQueryOtherOperator = true;
					$Gadget.showCityList = true;
				}
				
	
				
//				QueryLogDetail	包含下级单位的业务
//				LogQueryNoPrintRight	结果打印
//				CommitRecLogQueryTask	提交后台
//				LogExport	日志导出
				
				//是否显示“包含下级单位的业务”
				if($Gadget.buttonControlResult.body.queryLogDetail){
					$Gadget.data.OtherConditionDict.push({key:"queryLogDetail",value:$UEE.i18n('ad.sr.message.BHXJDWDYW')}); //包含下级单位的业务
				}
				
				//是否显示“提交后台”
				if($Gadget.buttonControlResult.body.commitRecLogQueryTask){
					$Gadget.disCommitRecLogQueryTask = true;
				}
				
				//modiby by lwx207718 on 2015-11-21 for DTS2015112008259
				//是否显示“日志导出” 没有这个权限时展示导出，反之不展示。
				if ($Gadget.buttonControlResult.body.logExport) {
					// 宁夏权限与现网一致，DTS2016100600143
					if ("NINGXIA" == $Page.projectVersion) {
						$Gadget.disLogExport = true;
					} else {
						$Gadget.disLogExport = false;
					}
				} else {
					if ("NINGXIA" == $Page.projectVersion) {
						$Gadget.disLogExport = false;
					} else {
						$Gadget.disLogExport = true;
					}
				}
				
			}
		}, $Gadget);
	},
	
	queryCurrentOperator: function($Gadget,$Fire,$Model){
		debugger;
		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		 $Fire({
			   service : 'bes.oc.operateinfoservice/getoperateinfo',
		     params : {},
			   target : '$Gadget.operinfo',
			   onafter : function() {
				   debugger;
				   
				   $Gadget.operatorId = $Gadget.operinfo && $Gadget.operinfo.operatorCode;
				   $Gadget.operatorCode = ($Gadget.operinfo && $Gadget.operinfo.operatorId) || $Gadget.operatorId;
				   $Gadget.orgId = $Gadget.operinfo && $Gadget.operinfo.orgId;
				   $Gadget.orgName = $Gadget.operinfo && $Gadget.operinfo.orgName;
				   
				   $Model.selectionResult = {
						   employeeId:$Gadget.operatorId,
						   employeeCode:$Gadget.operatorCode,
						   employeeCode_selfInput:$Gadget.operatorCode
				   };
                   $Gadget.selectDisPlayEmployeeId = $Model.selectionResult.employeeCode_selfInput;                   
                   $Gadget.arrSelectEmployeeId = [];
                   $Gadget.arrSelectEmployeeId.push($Gadget.operatorId);
				   $Model.unit = {
						   id:$Gadget.orgId,
						   text:$Gadget.orgName
				   };
				   
			   }
	    }, $Gadget);
	},
	clickcatalog : function($item, $Gadget) {
		debugger;
		
		$Gadget.data.OtherConditonSelect.toggle($item.key);
		if($item.isBundleSelected == "Y"){
			$item.isBundleSelected = "N";
		}else{
			if($Gadget.data.OtherConditonSelect.contain($item.key)){
				$item.isBundleSelected = "Y";
			}
		}
		
	},
	chooseTime: function($Gadget,$Fire,item){
		debugger;
		$Gadget.acceptneartimeKey = item.key;
		if($Gadget.acceptneartimeKey == '0'){
			var fromDate = new Date();
			fromDate.setMonth(fromDate.getMonth() - 3);
			fromDate.setDate(fromDate.getDate() + 1);
			fromDate.setHours(0, 0, 0);
			$Gadget.logQuery.fromDate = fromDate.getTime();
		}
		if($Gadget.acceptneartimeKey == '1'){
			var fromDate = new Date();
			fromDate.setMonth(fromDate.getMonth() - 2);
			fromDate.setDate(fromDate.getDate() + 1);
			fromDate.setHours(0, 0, 0);
			$Gadget.logQuery.fromDate = fromDate.getTime();
		}
		if($Gadget.acceptneartimeKey == '2'){
			var fromDate = new Date();
			fromDate.setMonth(fromDate.getMonth() - 1);
			fromDate.setDate(fromDate.getDate() + 1);
			fromDate.setHours(0, 0, 0);
			$Gadget.logQuery.fromDate = fromDate.getTime();
		}
		if($Gadget.acceptneartimeKey == '3'){
			this.initdate($Gadget);
		}
		 
		
	},
	chooseMonth : function($Gadget,$Fire,item){
		debugger;
		$Gadget.acceptneartimeKey = '3';
				
	},
	initdate: function($Gadget){
		debugger;
		var toDate = new Date();
		toDate.setHours(23, 59, 59);
		$Gadget.logQuery.toDate = toDate.getTime();

		
		//将开始和结束时间设为相差一天
		//var fromDate = this.getPrevNMonth(toDate,null,3);
		var fromDate = new Date();
		fromDate.setHours(0, 0, 0);
		//fromDate.setDate(fromDate.getDate()+1);
		$Gadget.logQuery.fromDate = fromDate.getTime();

		
		$Gadget.initFromDate = $Gadget.logQuery.fromDate;
		$Gadget.initToDate   = $Gadget.logQuery.toDate;
	},
	
	operator: function($Gadget){
		debugger;
	},
	
	department: function($Gadget){
		debugger;
	},
	
	do_query: function($Gadget,$Fire,$UI,$Model,asynchronize){
		debugger;
		
		$Gadget.isShowNodata = true; //是否显示无数据
		$Gadget.logQuery.serviceNumber = $("#ServiceNumberInputId").val().trim(); //服务号码不支持双向绑定
		// 1、校验查询参数
		if(!$Controller.bes.ad.logquery.validateQueryCondition($Gadget, $UI, $Model, asynchronize)){
			return false;
		}

		//组装查询数据
		$Gadget.params.body = {};			
		$Gadget.params.body.beginRowNumber = 0;
		$Gadget.params.body.curPage = 1;
		$Gadget.params.body.totalRowNum = 0;
		$Gadget.params.body.recordPerPage  = $Gadget.pageRecNumPerPage;
		$Gadget.params.body.incRollback = 'Y';
		
		if($Gadget.acceptObjectKey == '1'){
			$Gadget.params.body.beId = $Gadget.areaBeId;
		}
		//获取操作员Code
		if($Gadget.selectDisPlayEmployeeId) {
			$Gadget.params.body.selectDisPlayEmployeeCode = $Gadget.selectDisPlayEmployeeId;
		} else {
			$Gadget.params.body.selectDisPlayEmployeeCode = $Gadget.operatorCode;
		}
		// 操作员和单位
		if($Gadget.acceptObjectKey == '1' && $Gadget.canQueryOtherOperator){
			$Gadget.params.body.staffIdList = $Gadget.arrSelectEmployeeId;
		}else if($Gadget.acceptObjectKey == '1' && !$Gadget.canQueryOtherOperator){

			$Gadget.params.body.staffIdList = [$Gadget.operatorId];
		} else {
			$Gadget.params.body.depId =$Model.unit && $Model.unit.id;
		}

		// 其他条件
		//var otherConditionMap = ['incRollback','incBackProcess','relaRequest','noPrintInvoice'];
		$Gadget.params.body.queryLogDetail = 'N';
		for(var i=0;i<$Gadget.data.OtherConditonSelect.length;i++){
			if('incRollback'==$Gadget.data.OtherConditonSelect[i]){
				$Gadget.params.body[$Gadget.data.OtherConditonSelect[i]] = 'N';
			}else if('queryLogDetail'==$Gadget.data.OtherConditonSelect[i]){
				if($Gadget.acceptObjectKey=='1' || $Gadget.acceptObjectKey == '3'){
		    		$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.QXZDW')); //请选择单位 //提示
		    		return false;
				}else{
					$Gadget.params.body[$Gadget.data.OtherConditonSelect[i]] = 'Y';
				}
			}else{
				$Gadget.params.body[$Gadget.data.OtherConditonSelect[i]] = 'Y';
			}
		}
		if($Gadget.acceptObjectKey == '3' && !$Gadget.logQuery.queryCondition){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),'请输入查询条件。'); //受理对象选集团时，查询条件不能为空。 //提示
			return false;	
		}
		$.extend($Gadget.params.body, $Gadget.logQuery);
		
		// 是否提交后台
		$Gadget.params.body.asynchronize = asynchronize;
		
		//DTS2016090712388  修复错误的空list返回数据[null]修复为[] 
		if($Gadget.params.body.staffIdList && $Gadget.params.body.staffIdList.length == 1 && !$Gadget.params.body.staffIdList[0])
		{
		    $Gadget.params.body.staffIdList = [];
		}//DTS2016090712388 end

		if((!$Gadget.params.body.staffIdList || 0 == $Gadget.params.body.staffIdList.length) && !$Gadget.params.body.depId
				&& !$Gadget.logQuery.serviceNumber && !$Gadget.logQuery.recId){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.CZYDWFWHMLSHBXSXY')); //操作员、单位、服务号码、流水号必须四选一。 //提示
			return false;
		}
		if ($Page.UserInfoTabId == 'queryNgLog')
	    {
	       $Gadget.$Emit('$Gadget.queryNgLogEvent',
                    $Gadget.params);
	       return false;
	    }
	    if ($Page.UserInfoTabId == 'queryBesLog'&&$Page.do_query == '1') {
		    if (asynchronize == 'N') {
              $('#QueryId').attr('disabled', 'disabled');
            } else {
                 $('#BackQueryId').attr('disabled', 'disabled');
            }
	    }
		
		//var formatData = this.forMatData;
		$Gadget.acceptLogMainInfoTemp = {};
		
		if ($Gadget.acceptObjectKey == '3') {
			$Gadget.servicePath = 'logquerybygroup/LogQueryByGroup';
			if ($Gadget.queryDimensionKey == '1')
			{
				$Gadget.params.body.groupCode = $Gadget.logQuery.queryCondition;
				$Gadget.params.body.groupProdName = '';
				$Controller.bes.ad.logquery.executeQuery($Gadget,$Fire,$UI,$Model,asynchronize);
			}
			else
			{
				$Gadget.params.body.groupCode = '';
				$Gadget.params.body.groupProdName = $Gadget.logQuery.queryCondition;
				$Controller.bes.ad.logquery.executeQuery($Gadget,$Fire,$UI,$Model,asynchronize);
			}
		} else {
			$Gadget.servicePath = 'ucec/v1/Query_AcceptLogList';
			$Controller.bes.ad.logquery.executeQuery($Gadget,$Fire,$UI,$Model,asynchronize);
		}
	},
	
	executeQuery: function($Gadget,$Fire,$UI,$Model,asynchronize){
		debugger;
		
		try{
			$Gadget.waitForData = true;
			//服务链调用
    		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
	    	$Fire({
		    	service : $Gadget.servicePath,
		    	params : $Gadget.params,
		    	target : '$Gadget.acceptLogMainInfoTemp',
		    	onafter : function(){
		    		debugger;
		    		$Gadget.waitForData = false;
		     		$('#BackQueryId').attr('disabled',null);
		    		$('#QueryId').attr('disabled',null);
		    		// 对查询回来的列表进行整理
			    	if(!$Gadget.acceptLogMainInfoTemp.header || $Gadget.acceptLogMainInfoTemp.header.resultCode != "0"){
			    		$UI.msgbox.error($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.CXSB')+$Gadget.acceptLogMainInfoTemp.header.resultMessage); //查询失败： //提示
			    		return false;
			    	}
				
			    	if(asynchronize == 'N'){
				    	if(!$Gadget.acceptLogMainInfoTemp || !$Gadget.acceptLogMainInfoTemp.body || !$Gadget.acceptLogMainInfoTemp.body.acceptLogList){
				    		$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.CXSB29')); //查询失败! //提示
				    		return false;
				     	}
					
				    	//判断是否显示后台
				    	$Gadget.disQueryLogDetail = $Gadget.data.OtherConditonSelect.contain('queryLogDetail');
					
				    	$Gadget.queryResult = $Gadget.acceptLogMainInfoTemp;
				    	$Gadget.acceptLogMainInfo = $Gadget.acceptLogMainInfoTemp.body.acceptLogList;
				    	$Controller.bes.ad.logquery.forMatData($Gadget.acceptLogMainInfo);
				    	$Gadget.params.totalRowNum = $Gadget.acceptLogMainInfoTemp.body.totalRowNum;
				    	$("#logqueryPages").empty();
				    	$Gadget.canClick = false;
				    	$Gadget.pages = new UCD.newpages($("#logqueryPages"),$Gadget.params.totalRowNum, $Gadget.pageRecNumPerPage, [$Gadget.pageRecNumPerPage], 1, function() {
	                        debugger;
	                        if(!$Gadget.canClick){
	                        	$Gadget.canClick = true;
	                        	return ;
	                        }
	                        $Controller.bes.ad.logquery.clickPageNum($Gadget, $Fire);
				    	});
			    	}
			    	else{
			    		$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.YTJHTCL')); //已提交后台处理! //提示
			    		return false;
			    	}
			    	$Controller.bes.ad.logquery.transSubBusiTypeName($Gadget);
		    	}
	    	}, $Gadget);
		}catch(e){
			$Gadget.waitForData = false;
			$('#QueryId').attr('disabled',null);
			$('#BackQueryId').attr('disabled',null);
		}
	},
	
	transSubBusiTypeName : function($Gadget){
		debugger;
		$Gadget.subBusiTypeList = [{"key":"GrpMbrAdd","value":"集团成员新增"},{"key":"GrpMbrMod","value":"集团成员修改"},{"key":"GrpMbrDel","value":"集团成员删除"},{"key":"GrpMbrProdAdd","value":"集团成员附属商品新增"},{"key":"GrpMbrProdMod","value":"集团成员附属商品修改"},{"key":"GrpMbrProdDel","value":"集团成员附属商品删除"},{"key":"GrpMbrPropAdd","value":"集团成员属性新增"},{"key":"GrpMbrPropMod","value":"集团成员属性修改"},{"key":"GrpMbrPropDel","value":"集团成员属性删除"},{"key":"GrpMbrPayReationAdd","value":"集团成员代付关系新增"},{"key":"GrpMbrPayReationMod","value":"集团成员代付关系修改"},{"key":"GrpMbrPayReationDel","value":"集团成员代付关系删除"},{"key":"GrpChangeInfo","value":"集团用户变更"},{"key":"GrpChangeProduct","value":"集团产品变更"},{"key":"TransUserJoin","value":"合户"},{"key":"TransUserDisjoin","value":"分户"}]
		for ( var j = 0; j < $Gadget.acceptLogMainInfoTemp.body.acceptLogList.length; j++) {
			if (null == $Gadget.acceptLogMainInfoTemp.body.acceptLogList[j].subBusinessTypeName)
			{
				continue;
			}
			for ( var i = 0; i < $Gadget.subBusiTypeList.length; i++) {
				$Gadget.acceptLogMainInfoTemp.body.acceptLogList[j].subBusinessTypeName = $Gadget.acceptLogMainInfoTemp.body.acceptLogList[j].subBusinessTypeName
						.replace($Gadget.subBusiTypeList[i].key, $Gadget.subBusiTypeList[i].value);
				$Gadget.acceptLogMainInfoTemp.body.acceptLogList[j].subBusinessTypeName = $Gadget.acceptLogMainInfoTemp.body.acceptLogList[j].subBusinessTypeName
				.replace("|", ",");
			}

		}
	},
	
	query: function($Gadget,$Fire,$UI,$Model,asynchronize){
		debugger;	
		
		//如果工号是操作员手动输入的，则调接口查询
		if(!$Model.selectionResult.employeeCode_selfInput){
			//$Model.selectionResult.employeeId = null;
			$Gadget.arrSelectEmployeeId = [];
			$Controller.bes.ad.logquery.do_query($Gadget,$Fire,$UI,$Model,asynchronize);
			return true;
		}
		//如果前台选择操作员后，用户再手动输入操作员，则调接口返回操作员id
		if($Gadget.acceptObjectKey == '1' && $Model.selectionResult.employeeCode_selfInput != $Gadget.selectDisPlayEmployeeId){
			//服务链调用
    		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
			$Fire({
				   service : 'ucec/v1/sr/queryOperatorByLoginId',
				   params : {
					   header:{},
					   body:{
						   loginId:$Model.selectionResult.employeeCode_selfInput
					   }
				   },
				   target : '$Gadget.query_OperatorId',
				   onafter : function() {
					   debugger;
					   if($Gadget.query_OperatorId){
						   $Gadget.arrSelectEmployeeId = [];
						   $Gadget.arrSelectEmployeeId.push($Gadget.query_OperatorId);
						   //$Model.selectionResult.employeeId = $Gadget.query_OperatorId;
						   //$Model.selectionResult.employeeCode = $Model.selectionResult.employeeCode_selfInput;
						   $Controller.bes.ad.logquery.do_query($Gadget,$Fire,$UI,$Model,asynchronize);
					   }else{
						   $UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.WFHQCZYID')); //无法获取操作员id。 //提示
						   return false;
					   }
					   
					   
		           }
		    }, $Gadget);
			 return true;
		}else{
			$Controller.bes.ad.logquery.do_query($Gadget,$Fire,$UI,$Model,asynchronize);
			return true;
		}
		
		
	},
	validateQueryCondition: function($Gadget, $UI, $Model, asynchronize){
		debugger;
		
		//if(!$Model.selectionResult || !$Model.selectionResult.employeeId){
		//	$Model.selectionResult = {employeeId : "eid"};// 测试数据
		//}

		
		// 1、校验开始时间 （查询和提交后台都必选）
		if(!$Gadget.logQuery.fromDate){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.QXZKSSJ')); //请选择开始时间。 //提示
			return false;
		}
			
		// 2、校验结束时间 （查询和提交后台都必选）
		if(!$Gadget.logQuery.toDate){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.QXZJSSJ')); //请选择结束时间。 //提示
			return false;
		}

		if($Gadget.logQuery.fromDate >= $Gadget.logQuery.toDate){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.KSSJBXXYJSSJ')); //开始时间必须小于结束时间。 //提示
			return false;
		}
		
		if($Gadget.logQuery.orderId && isNaN($Gadget.logQuery.orderId)){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.label.DDBMBXSSZ')); //订单编码必须是数字。 //提示
			return false;
		}
		if($Gadget.logQuery.recId && isNaN($Gadget.logQuery.recId)){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.label.SLLSBXSSZ')); //受理流水必须是数字。 //提示
			return false;
		}
		if($Gadget.acceptObjectKey == '3' && $Gadget.queryDimensionKey == '1' 
			&& !(/^\w{10,20}$/g.test($Gadget.logQuery.queryCondition))){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),'集团编码须为10-20位字符.'); //查询维度为集团编码时，条件必须是10-20位字符。 //提示
			return false;
		}
		//现场要求相隔一天
		//能否跨月查询
		//if($Gadget.cannotSpanMonth){
		//	var selectEndDate = new Date($Gadget.logQuery.toDate);
		//	var selectFromDate = $Controller.bes.ad.logquery.getPrevNMonth(selectEndDate,null,1);
		//	var iSelectFromDate = selectFromDate.getTime();
		//	if(iSelectFromDate > $Gadget.logQuery.fromDate){
		//		$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),"当前用户不允许跨月查询。"); //提示
		//		return false;
		//	}
		//}
		
		//3。1、检查是否符合提交后台条件
		/*
		if(asynchronize == 'Y'){
			// 3.1.1如果是提交后台，操作员必选
			if($Gadget.acceptObjectKey != '1' || 
					!$Gadget.arrSelectEmployeeId || 0 == $Gadget.arrSelectEmployeeId.length){
				$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "提交后台必须选择操作员!"); //提示
				return false;
			}
			// 3.1.2 如果提交后台，服务号码必选
			if(!$Gadget.logQuery.serviceNumber){
				$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "提交后台必须选择服务号码。"); //提示
				return false;
			}		
		}*/
		
		//3.2、检查是否符合查询条件
		/*else{
			if (!$Gadget.qryProvinceOrg) {
				// 3.2.1、校验操作员或者单位
				if ($Gadget.acceptObjectKey == '1' && $Gadget.canQueryOtherOperator) {
					if (!$Gadget.arrSelectEmployeeId || 0 == $Gadget.arrSelectEmployeeId.length) {
						$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "请先选择操作员。"); //提示
						return false;
					}
				} else if ($Gadget.acceptObjectKey == '1' && !$Gadget.canQueryOtherOperator) {
					if (!$Gadget.operatorId) {
						$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "无法获取当前操作员。"); //提示
						return false;
					}
				}
			}
			else if($Gadget.selectMode != '2'){
				if(!$Model.unit || !$Model.unit.id){
					$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "请先选择单位。"); //提示
					return false;
				}
			}
			

			
			
		}*/
		
		//if($Gadget.logQuery.serviceNumber && !OC.Comm.isMobile($Gadget.logQuery.serviceNumber)){
		//	$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), "服务号码格式不正确，请重新输入。"); //提示
		//	return false;
		//}
		
		return true;
	},
	
	reset: function($Gadget,$Model){
		debugger;
		
		$("#ServiceNumberInputId").val('');
		$Gadget.acceptObjectKey = '2';
		
		$Model.selectionResult = {
			employeeId:$Gadget.operatorId,
			employeeCode:$Gadget.operatorCode,
			employeeCode_selfInput:$Gadget.operatorCode
		};
        
		$Gadget.selectDisPlayEmployeeId = $Model.selectionResult.employeeCode_selfInput;
		$Model.unit = {
			id:$Gadget.orgId,
			text:$Gadget.orgName
		};
		/*   
		if($Model.selectionResult){
			$Model.selectionResult.employeeId = null;
			$Model.selectionResult.employeeName=null;
		}
		if($Model.unit){
			$Model.unit.id=null;
			$Model.unit.text=null;
		}*/
		//$.extend($Gadget.logQuery, {});  //改用extend重置
		$Gadget.logQuery.busiCode = "";
		$Gadget.logQuery.acceptedMethod = "";
		$Gadget.logQuery.status = "";
		$Gadget.logQuery.invoiceType = "";
		$Gadget.logQuery.busiClass = "";
		$Gadget.logQuery.paymentMethod = "";
		$Gadget.logQuery.sortType = "";
		$Gadget.logQuery.recId = null;
		$Gadget.logQuery.serviceNumber = null;
		$Gadget.logQuery.groupCustCode = null;
		$Gadget.logQuery.orderId = null;
		
		$Gadget.logQuery.offeringId = null;
		$Gadget.data.offeringName = null;

		$Gadget.data.OtherConditonSelect=[];
		this.reSelect($Gadget);
		//重置时间
		$Gadget.logQuery.fromDate = $Gadget.initFromDate;
		$Gadget.logQuery.toDate   = $Gadget.initToDate;
		
		var tmpBegDate = new Date($Gadget.logQuery.fromDate);
		var tmpEndDate = new Date($Gadget.logQuery.toDate);

		$("#beginTime>input").val(tmpBegDate.Format("yyyy-MM-dd hh:mm:ss"));
		$("#date_endTime>input").val(tmpEndDate.Format("yyyy-MM-dd hh:mm:ss"));
	},
	reSelect :function($Gadget){
		debugger;
		for(var i = 0; i < $Gadget.data.OtherConditionDict.length; i++){
		   $Gadget.data.OtherConditionDict[i].isBundleSelected = 'N';
		}
	},
	printLog: function($Gadget){
		debugger;
		window.print();
	},
	commitToBackgroud: function($Gadget){
		debugger;
	},
	
	changeShowMoreFLag: function($Gadget){
		$Gadget.showMoreUserInfoFlag = !$Gadget.showMoreUserInfoFlag;
	},
	
	clickPageNum: function($Gadget, $Fire){
		debugger;
		var formatData = this.forMatData;
		setTimeout(function(){
			debugger;			
			if ($Gadget.pages) {				
				var selection = $Gadget.pages.getSelection() > 0 ? $Gadget.pages.getSelection() - 1 : 0;

				$Gadget.params.body.totalRowNum = $Gadget.params.totalRowNum;
				$Gadget.params.body.beginRowNumber = selection * $Gadget.pageRecNumPerPage;
				$Gadget.params.body.curPage        = selection + 1;
				
				$Gadget.acceptLogMainInfo = [];
				$Gadget.acceptLogMainInfoTemp = {};
				$Gadget.waitForData = true;
				//服务链调用
	    		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
				$Fire({
					service : $Gadget.servicePath,
					params : $Gadget.params,
					target : '$Gadget.acceptLogMainInfoTemp',
					onafter : function(){
						debugger;
						$Gadget.waitForData = false;
						// 对查询回来的列表进行整理
						$Gadget.acceptLogMainInfo = $Gadget.acceptLogMainInfoTemp.body.acceptLogList;
						formatData($Gadget.acceptLogMainInfo);
						$Controller.bes.ad.logquery.transSubBusiTypeName($Gadget);
					}
				}, $Gadget);
				
			}
		},0);
	},
	// 取上3个月所在日期对象
	// day未指定时，返回date对应上3月的日期，如 12.1 返回9.1,12.31则返回9.30
	getPrevNMonth: function (date,day,spanMonth){
		var year = date.getFullYear();
		var month = date.getMonth();
		var hour = date.getHours();
		var minute = date.getMinutes();
		var second = date.getSeconds();
		if( month < spanMonth ){
			month = month + 12 - spanMonth;
			year -= 1;
		} else {
			month -= spanMonth;
		}
		var days = this.getDaysOfMonth(year,month);
		if( day === undefined || day === null ){
			day = date.getDate();
		} else {
			day = parseInt(day,10);
		}
		if( day < 1 || isNaN(day) ){
			day = 1;
		} else if( day > days ){
			day = days;
		}
		return new Date(year,month,day,hour,minute,second);
	},
	
	getUnitInfo: function($Gadget,$Model,$Page){
		debugger;
		$Model.unit=$Page.popUnit;
	},
	
	// 某月有多少天
	getDaysOfMonth: function (year,month){
		var enddate = [31,28,31,30,31,30,31,31,30,31,30,31];
		if (year%4==0){
			enddate[1]=29;
		}
		return enddate[month];
	},
	
	popLogQueryDetail: function($Gadget,$Item){
		debugger;
		$Item.ProtocolType=$Item.prptocolType;
		var $sce = $Gadget.$Get("$sce");
		$Gadget.$Item = $Item;
		$Gadget.$Item.qryProvinceOrg = $Gadget.qryProvinceOrg;
		$Gadget.$Item.showBeIdNotDepId = $Gadget.showBeIdNotDepId;
		$Gadget.$Item.paymentMethod = $Gadget.logQuery.PayTypeSelectvalue;
		$Gadget.$Item.showSubRecType = $Gadget.showSubRecType;
		$Gadget.$Item.showOwnerRegion = $Gadget.showOwnerRegion;
		$Gadget.$Item.paymentTypeMap = $Gadget.data.paymentTypeMap;
		$Gadget.$Item.custTypeMap = $Gadget.data.custTypeMap;
		if($Item.crmUrl && $Gadget.isCsp){
			$Gadget.$Item.path = "http://"+window.location.hostname+$Gadget.crmUrlPort+$Item.crmUrl;
			$Gadget.$Item.path = $sce.trustAsResourceUrl($Gadget.$Item.path);
		}
		 
	},
	
	popNewDetail: function($Gadget,$Item){
		debugger;
		$Gadget.busiList = [];
		if(null == $Item.subBusinessType){
			$Gadget.busiList.push($Item.busiCode);
		}else{
			$Gadget.busiList = $Item.subBusinessType.split("|");
			$Gadget.busiList.push($Item.busiCode);
		}
	},
	selectOffering: function($Gadget,$UI,$Data){
		debugger;
		if($Data){
			$Gadget.logQuery.offeringId = $Data.offerId;
			$Gadget.data.offeringName = $Data.offerName;
		} else {
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.WFXQCPLX')); //无法选取产品类型 //提示
			return false;
		}
	},
	
	changeDepIdOrEmpId:function($Gadget,$Model,itemKey){
		debugger;
		if($Gadget.acceptObjectKey != itemKey){
			if('2' == itemKey){
				$Model.unit = {
						id:$Gadget.orgId,
						text:$Gadget.orgName
				};
			}else{
				$Model.selectionResult = {
						employeeId:$Gadget.operatorId,
						employeeName:$Gadget.operatorName
				};
			}
		}
		$Gadget.acceptObjectKey = itemKey;
	},
	
	ExportAll: function($Gadget,$UI,$Fire){
		debugger;
		if($Gadget.exAllValue0 == 'all'){
			return;
		}
		if($Gadget.params.totalRowNum == 0){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.MYKDCSJ')); //没有可导出数据。 //提示
			return false;
		}
		
		var paramsForExport = $Gadget.params;
		paramsForExport.body.beginRowNumber = 0;
		paramsForExport.body.curPage = 1;
		paramsForExport.body.recordPerPage = $Gadget.params.totalRowNum;
		paramsForExport.body.totalRowNum = 0;

		var exportAllMethod = this.ExportCur;
		$Gadget.acceptLogMainInfoTemp = {};
		var acceptLogMainInfo = {};
		var formatData = this.forMatData;
		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		$Fire({
			service : 'ucec/v1/Query_AcceptLogList',
			params : paramsForExport,
			target : '$Gadget.acceptLogMainInfoTemp',
			onafter : function(){
				debugger;
				// 对查询回来的列表进行整理
				acceptLogMainInfo = $Gadget.acceptLogMainInfoTemp.body.acceptLogList;
				formatData(acceptLogMainInfo);
				exportAllMethod($Gadget,$UI,$Fire,acceptLogMainInfo,$Gadget.exAllValue0);
			}
		}, $Gadget);
		
		
	},
	ExportCur: function($Gadget,$UI,$Fire,acceptLogMainInfo,exportType){
		debugger;
		if(exportType == 'all'){
			return;
		}		
					
		if(!$Gadget.acceptLogMainInfo || $Gadget.acceptLogMainInfo.length <= 0){
			$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'),$UEE.i18n('ad.sr.message.MYKDCSJ')); //没有可导出数据。 //提示
			return false;
		}
		
		var outPutList = [];
		if(acceptLogMainInfo){
			outPutList = acceptLogMainInfo;
		}
		else{
			outPutList = $Gadget.acceptLogMainInfo;
		}
		// 存储变量
		var ExportCurDataSeg = [];
		for( var i = 0 ; i < outPutList.length ; ++i){
			var item = {};
			if("xls" == exportType){
				item["recId"] = "\'" + (outPutList[i].recId || "");//加'，避免流水号转换成科学计算法
			}
			else{
				item["recId"] = outPutList[i].recId || "";
			}
			item["custName"] = outPutList[i].custName || "";
			item["serviceNumber"] = outPutList[i].serviceNumber || "";
			item["createOperId"] = outPutList[i].createOperName || "";
			item["acceptionNumber"] = outPutList[i].acceptionNumber || "";
			item["busiName"] = outPutList[i].busiName || "";
			item["subBusinessTypeName"] = outPutList[i].subBusinessTypeName || outPutList[i].busiName || "";
			item["createTime"] = outPutList[i].createTime || "";
			item["discount"] = adutil.getPriceByPrecision(outPutList[i].discount);
			item["recFee"] = adutil.getPriceByPrecision(outPutList[i].recFee);
			item["status"] = outPutList[i].status || "";
			item["protocolType"] = outPutList[i].prptocolType || "";
			if($Gadget.disQueryLogDetail){
				item["createDepId"] = outPutList[i].createDepName || "";//Id做了翻译，改成name
			}
			//新增四个字段
			if('1' == outPutList[i].recType){
				item["isBackTurn"] = $UEE.i18n('ad.sr.message.S'); //是
			}else{
				item["isBackTurn"] = $UEE.i18n('ad.sr.message.F'); //否
			}
			item["remark"] = outPutList[i].remark || "";
			item["authType"] = outPutList[i].authType || "";
			item["proName"] = outPutList[i].proName || "";
			
			ExportCurDataSeg.push(item);
		}
		if($Gadget.disQueryLogDetail){//判断是否显示“受理单位”
			exportItem = $UEE.i18n('ad.sr.message.SLLSKHMCFWHMCZYSLHMSLLXZYWLXSLDWSLSJYHSSSLZTDJLXSFHTBZJQFSCPMC'); //受理流水,客户名称,服务号码,操作员,受理号码,受理类型,子业务类型,受理单位,受理时间,优惠,实收,受理状态,单据类型,是否回退,备注,鉴权方式,产品名称
		}else{
			exportItem = $UEE.i18n('ad.sr.message.SLLSKHMCFWHMCZYSLHMSLLXZYWLXSLSJYHSSSLZTDJLXSFHTBZJQFSCPMC'); //受理流水,客户名称,服务号码,操作员,受理号码,受理类型,子业务类型,受理时间,优惠,实收,受理状态,单据类型,是否回退,备注,鉴权方式,产品名称
		}
		
		var req = {
				 "header" : exportItem,
			     "type" : exportType,
			     "fileName" : $UEE.i18n('ad.sr.message.RZCXDC'), //日志查询导出
			     "logQuery" : ExportCurDataSeg,
			     "serviceName" : "LogQuery"
			    };
				
		$Gadget.request=req;
		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		$Fire({
			'export' : '',
			'service' : '/export/exportfile',
			'params' : {'request':$Gadget.request}
		}, $Gadget);
	},
	
	forMatData: function(datalist){
		debugger;		
		if(!datalist){
			return;
		}
		for(var i = 0 ;i < datalist.length;++i){
			if(datalist[i].createTime && /^[0-9]+$/.test(datalist[i].createTime)){
				datalist[i].rawCreateTime = datalist[i].createTime;

				var date = new Date(parseInt(datalist[i].createTime));
							
				datalist[i].createTime = date.format("yyyy-MM-dd hh:mm:ss");
			}
		}
	},
	
	deleteoperidOrUnitId: function($Gadget,$Model){
		debugger;
		if('1' == $Gadget.acceptObjectKey && $Model.selectionResult){
			$Model.selectionResult.employeeId = null;
			$Model.selectionResult.employeeName=null;
			$Model.selectionResult.employeeCode_selfInput='';
			$Model.selectionResult.employeeCode='';
		}
		
		else if('2' == $Gadget.acceptObjectKey && $Model.unit){
			$Model.unit.id=null;
			$Model.unit.text=null;
		}
	},
	
	deleteProductType: function($Gadget){
		debugger;
		$Gadget.logQuery.offeringId = null;
		$Gadget.data.offeringName = null;
	},
	
	downLoadReceipt: function($Gadget,$Fire,$UI,$Item){
		debugger;
		$Gadget.downLoadparams = {
			printeinvoiceserialno : 0
		}

		
       //modify by lwx207718 on 2015-10-12 for DTS2015092310046 begin
		var eInvoiceNum = "";
		if (null != $Item.orderId 
				&& "" != $Item.orderId
				&& undefined != $Item.orderId)
		{
			eInvoiceNum = $Item.orderId;
		}
		else
		{
			eInvoiceNum = $Item.recId;
		}
		var index = document.location.pathname.substr(1).indexOf("/");
		var result = document.location.pathname.substr(0, index + 1);
		window.location.href = window.location.protocol+ "//"
		+ window.location.host
		+ result
		+ "/PrintEInvoicePDF.do?downloadFlag=1&printEInvoiceSerialNo="
		+ eInvoiceNum;
		//modify by lwx207718 on 2015-10-12 for DTS2015092310046 begin
	},
	viewPhotoInfo: function($Gadget,$Fire,$UI,$Item){
		debugger;
		if (null == $Item.realNameId 
				|| "" == $Item.realNameId
				|| undefined == $Item.realNameId)
		{
			return false;
		}
		$Gadget.certTypeList = [];
		$.each($Gadget.data.DictList.CM_CERT_TYPE_JS, function(index,val){
            var certType = {};
            certType.key = val.itemCode;
            certType.value = val.itemName;
            certType.ext = val.extMap.ext1;
            $Gadget.certTypeList.push(certType);

        });

		$Gadget.photoInfo = {};
		$Fire({
			service : 'certpicupload/querycertpiclss',
			params : {
				'beId' : $Item.beId,
				'recId' : $Item.realNameId
			},
			target : '$Gadget.photoInfo',
			onafter : function(){
				debugger;
				$Fire({
					popup : "{'title' : '身份证照片信息','width' : '660px','height' : '500px','modal' : true,'src':'{{$Webapp}}/bes/ad/ctz/gadget/bes-ad-logquery/bes-ad-viewphotofile.html'}"
				}, $Gadget);
				// $Gadget.photoInfo = {
				// 	"certType":"IdCard",
				// 	"certNo":"123456",
				// 	"picNameR":'/9j/4AAQSkZJRgABAgEASABIAAD/7Ql+UGhvdG9zaG9wIDMuMAA4QklNA+kAAAAAAHgAAHUAAEgASAAAAAAC9AJA/+7/7gMGAlIAAAUoA/wAAARmdQCrAAAUAAAAIAA/Y5QEZnVwAAAAAAAAF0AEZlSQBGZ1AKsAAA4AAAAwAECEXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGZ00AAAAAA4QklNA+0AAAAAABAASAAAAAEAAQBIAAAAAQABOEJJTQQNAAAAAAAEAAAAeDhCSU0D8wAAAAAACAAAAAAAAAAAOEJJTQQKAAAAAAABAAA4QklNJxAAAAAAAAoAAQAAAAAAAAACOEJJTQP1AAAAAABIAC9mZgABAGxmZgAGAAAAAAABAC9mZgABAKGZmgAGAAAAAAABADIAAAABAFoAAAAGAAAAAAABADUAAAABAC0AAAAGAAAAAAABOEJJTQP4AAAAAABwAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAADhCSU0ECAAAAAAAEAAAAAEAAAJAAAACQAAAAAA4QklNBBQAAAAAAAQAAAAFOEJJTQQMAAAAAAdqAAAAAQAAAHAAAAAfAAABUAAAKLAAAAdOABgAAf/Y/+AAEEpGSUYAAQIBAEgASAAA//4AJkZpbGUgd3JpdHRlbiBieSBBZG9iZSBQaG90b3Nob3CoIDUuMP/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAB8AcAMBIgACEQEDEQH/3QAEAAf/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APVUyRXn31wwv8ZOdnupwc6rD6cXH0W4nrMs2gn0jk310Pt9Z7X7bGUX/Zf0f+DSU97kZWPjV+rk2sormN9jgxs/1nkNTYuZiZlXrYl9eRTJHqVPa9sj6Td9Zc1fNf1g6Zb0jq+T066x1t+O7bdY9hZueQH2OY2wl76XOd+hvd/SKv0/+EQ+ldY6p0fKGX0zJsxbhy6swHAHdstYf0d1e7/B2t2JKfp2U68j+rv+MvrOc+y3qIaXdNbVdvpljbKbL8Xp+ZVk4270rn7MluVi3M9G3GyKPz8bIuoXrYSU0Mr6w9Awr3Y2Z1PExsiuN9Nt9bHtkB7d1dj2vbuY7cj4XUun9QqN2Bk05dLXbHWUWNtaHAB2wuqc5u/a5q4XrmTTd/jQx3bsjb0vp5Dzi49mQ9tl3q1+5uLXdaxv2fLZZ6m3/q0X6kM/aH1i6h9aMHZVhdXkHDqeHel6e39N1FlW2qvqOU9v2iun9N6deXlerd/pkp75Jcp1j619VqZ1R/ScOs09E/pmRnGyoWObWcq7Hwqa6i6x3o+lsyL7KKX+tT6Pr0212rZ6V1vGz+hUdasjGotxxkXB5kVDb6lodZDNzav9Jt/lpKdJZfX/AKx9M+r+GczqJtFUO2+nVZZLm8VGxjPQpfa52yn7TbQyxYWT9cOv31Mzuj9KqvwdzHFt+QK8h+O9jbGZnoNa6rEoc53s9W6/K9L9N9jZWg/4y7TndI6X0nFeXP6znUs9ISHPpANljtrtvsqt+zPfv+gkp7LGvGRj13hjq/VY1/pvgObuG7Y/aXN3s+i/3Iq5LE+tGZflDG6TiU29LZeKqeovte45LWFp6gcDDox3Pt9Bz7KG5jrv2f6//ahdY0yAeJEwUlP/0PVUydJJT5h/jV+pPUuo5lHWemNsynlnpZVTrW+wNj0Ps1Vpbta7db6tdX+E/S+l/PPXAYv1L+sV+SKLMR2KJh1uRLGD4aOfc7/g8eu67/g19GoTPsnq+z0/Vjtt3R/1SSnybov+LvqXTGv+1sN1ecaacl7f0bKseu+jPvO25v2nIysn7HXjYtVFHp/pbLMq2lesOuFGMbrmu9rS97K2uscPznNZVS19tv8A1piOmKSnzboedY361df631Ppme117qzg0Nwb3PsqpDqqNv6PbTc70sZ/6f0q/U/wq0vqD0vqON1XrXUsyttFvU8h1t+Ox4sZSQ+11eN9or/Q5GRuvs9b0v5jZX/h77qcfpyPq/ru+yc+6fT5/lK7V6PpN9Hb6UezZG2P5O32pKfHM/J6x1XovW7+r9Ly8nr1T3V73078bEqe/Eb6WHTfa6um30RZ+lxcW/N9/wBr+1fzl667rHTcjP8A8WN3T+m41/rtopDMS5gZeBjvodtfjssv2Xvx8f1fQ3+q/wD472Lr3t6d9rl/pfbCw/SLfU2fnRPv2KeKMQY7fsnp/Z/zPSI2R5bPakp5f6v/AFtZlY2HXj9NyKXWODOoW5Q9CqlzW7bK2XPa77dkucyuvExMev1PR/nvsuxZX1yx6PrB9bOkdPzMLM/ZGOMinIyxj3sYLrwaWBl762M2Uvopubkt9TE/4yj1F3DG9LGbuZ6P20gxq02R+ftE7/6yWQOl+v8ArPoetAj1Nu6Pzfp+5JTyX1FyOq9Jy7vqt1rEvNmHNeB1X03Oqtxmlz6KX5H6RlOz1P1bfb6f/aH9DkU1129wq1v7O9Wr1vR9WB6O/bujt6e73f5qtJKf/9k4QklNBAYAAAAAAAcAAgAAAAEBAP/iDFhJQ0NfUFJPRklMRQABAQAADEhMaW5vAhAAAG1udHJSR0IgWFlaIAfOAAIACQAGADEAAGFjc3BNU0ZUAAAAAElFQyBzUkdCAAAAAAAAAAAAAAAAAAD21gABAAAAANMtSFAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEWNwcnQAAAFQAAAAM2Rlc2MAAAGEAAAAbHd0cHQAAAHwAAAAFGJrcHQAAAIEAAAAFHJYWVoAAAIYAAAAFGdYWVoAAAIsAAAAFGJYWVoAAAJAAAAAFGRtbmQAAAJUAAAAcGRtZGQAAALEAAAAiHZ1ZWQAAANMAAAAhnZpZXcAAAPUAAAAJGx1bWkAAAP4AAAAFG1lYXMAAAQMAAAAJHRlY2gAAAQwAAAADHJUUkMAAAQ8AAAIDGdUUkMAAAQ8AAAIDGJUUkMAAAQ8AAAIDHRleHQAAAAAQ29weXJpZ2h0IChjKSAxOTk4IEhld2xldHQtUGFja2FyZCBDb21wYW55AABkZXNjAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA81EAAQAAAAEWzFhZWiAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPZGVzYwAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdmlldwAAAAAAE6T+ABRfLgAQzxQAA+3MAAQTCwADXJ4AAAABWFlaIAAAAAAATAlWAFAAAABXH+dtZWFzAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAACjwAAAAJzaWcgAAAAAENSVCBjdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23////+ACZGaWxlIHdyaXR0ZW4gYnkgQWRvYmUgUGhvdG9zaG9wqCA1LjD/7gAOQWRvYmUAZIAAAAAB/9sAhAAIBgYGBgYIBgYIDAgHCAwOCggICg4QDQ0ODQ0QEQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQkICAkKCQsJCQsOCw0LDhEODg4OEREMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAoAJIDASIAAhEBAxEB/90ABAAK/8QBogAAAAcBAQEBAQAAAAAAAAAABAUDAgYBAAcICQoLAQACAgMBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAIBAwMCBAIGBwMEAgYCcwECAxEEAAUhEjFBUQYTYSJxgRQykaEHFbFCI8FS0eEzFmLwJHKC8SVDNFOSorJjc8I1RCeTo7M2F1RkdMPS4ggmgwkKGBmElEVGpLRW01UoGvLj88TU5PRldYWVpbXF1eX1ZnaGlqa2xtbm9jdHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4KTlJWWl5iZmpucnZ6fkqOkpaanqKmqq6ytrq+hEAAgIBAgMFBQQFBgQIAwNtAQACEQMEIRIxQQVRE2EiBnGBkTKhsfAUwdHhI0IVUmJy8TMkNEOCFpJTJaJjssIHc9I14kSDF1STCAkKGBkmNkUaJ2R0VTfyo7PDKCnT4/OElKS0xNTk9GV1hZWltcXV5fVGVmZ2hpamtsbW5vZHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4OUlZaXmJmam5ydnp+So6SlpqeoqaqrrK2ur6/9oADAMBAAIRAxEAPwDv+bNkc83+d9A8k2KXuuTMvrFltreJecsrKKsEXYfDX4mdlXFWR1GbPN+vf85F61dO0PlrTIrKLos90TPMfcIvCJP9X99kMu/zk/Me7fkdaeH/ACYI4kH4Jir7DzZ5R8s/nt5z0adV1WVdasyfjiuAElA/4rnQV/4NZM7DpX55eTNYWG3gle01K5okNteq0cXqtsiSXMSzoiM3+7OOKvTc2Feg61Frdm1wsZguIZZLa8tWIZop4m4yJyGzr+3G4+3GyPhpirs2cE83jUF/Ni38v6fq+px2FzF9d1C3ivZlAZ+blYqN+4Q0T92n2f2MX1a+8weRfPXl7T9N1a8vLTVKPfaZfTtdhYuXBnEkoMifDyZWr+xir3TNicUqyxLIv2WFRhcvmfy62ojR11W0bUiaCzE0Zl5fy8OVeX+R9rFU1zZsLtU1/RNERZNX1C3sVf7H1iVIy3+qGILf7HFUxwC2s6St/FpZvoPr83L07QSKZTwUux9MHlRVGK2WoWOp2yXmnXMV3bSfYngdZENPBkJGcM0azsh+dWvXGkwx2lrpyCF/THFfUdU+sSHf4TzWbnir3zNhTB5n8t3NzHZW+sWU11KeEdvFcxPIzAVoqI7Nhtirs2bNir//0O/4Xaxouna5aGz1G3iuIq1VZo0kCnxUSBuJwxzYqwG9/LHShpF9Y6WyadcXELxw3MMSqUYj7VE4s3g2eQZV4SunLlxYjluK0NK77577zg35i/knc6rrt1ruiXKxrfN6kto0VER6AMUaPs/2v7v7WKvnrHKW5ArXlX4ada50m2/JXzK1yIruWJIq/E0Yd2I/yVZU/Fs6JpP5FabCIrhkZp46MjTuSOQ3BaNOHLf9nFWV/lzcTSajrvq9Xnt2fw9Q2kPq/iBnRci/lPy4+gxSpLIZ55ZXuLq4K8PUlkoPhSrcI0RVSNeTfCuGXmC+1nT7EzaJp6ald14+jLOtsigg/vGkcNyAbj8C/Firwu3tL3zb+a3mfULC+nsms5hZQz23pk0i/csB6ySrTlb88X0eS90H8z28s+aWXUp9RVZI9akH+lhCpeKJ2qyrD8DI0carjvy/0/zr5Tvb9p9Htr26vJmuGuXvkiQOw35cUmLLX4vhySaL5I1W/wDNc3m3zBPHdatcUH+jKy21tEAFEUJk+OQ8Bx9Q/wCX/rYqyT8z2sk8qfVrrX28vwySIGmiHKW4jUHnaRqpWSsoP2o/9n+7zj3m2W2u73ydp2laHJoyJdK1lcSxpBLJEjIKiIH6xxqObS3HFnfJv+cXlbzJfat5f8w6JEt7DpVFezdwoVw4kElGoCHpxb/UyPavovnfUPNeieY57WzlighKiNZH9OF2LVEsjD1ZpPj9TlHHx/YxV6v5u82t5U8l3XmKRBJcpGq28Z6NNKQkfL/JVm5N/krkW8s+R7DzBpK33mGCPU9Tv41l1DUbxfVlLyDl6UJP9xDDy4RpDwyR+e/K7+c/JNxots4huCsctszV4+rCeQVv8h/iXlkJ8q6x+ZdnpieWp9Ps7CW3X0jrU8hkIUfDyS0j/vpgv2PjSPl/eYq9G8r+XLXyfpj6faUj0+HlKqCppX4nZid2bPOegecZbC81O+K/VrnzRqMqLq9xH6ltBG7n1X47+tInrfY+x/NnoDzVdeZG8sSW2h2K3t5dwSW0tzcTx2oi5R8PXKEHmzcmPpJx/wBbOYeXPy7u9Y8jXvlTWbNLXULXlLpt2sqyBp+TyAniPgXf0n/mXFWf+S/IGl+XYUbT4kjXr9adENxKf53lpVeX8kfGPJ8ooAPAZzf8rbvzbYWK+W/NlqimxThaXqzLI7oDRYXRf99j/dvLOk4q7NmzYq//0e/5s8AZsVff+bPAGbFX37xXrQY7PAGbFX3/AJRAYUYVGeAc2Kvvr6vB/vpfuGKKqrsoAHtngHNir79dEkUq6hlPUHGfV4OIX014jcCgzwLmxV9/AACgFB4YmbaAvzMalv5qb54FzYq+/WVWHFgCPDGpDEhqqKD4gUzwJmxV9+CKMNzCAN/NTfH54AzYq+/82eAM2Kv/2Q==',
				// 	"picNameZ":'/9j/4AAQSkZJRgABAgEASABIAAD/7Ql+UGhvdG9zaG9wIDMuMAA4QklNA+kAAAAAAHgAAHUAAEgASAAAAAAC9AJA/+7/7gMGAlIAAAUoA/wAAARmdQCrAAAUAAAAIAA/Y5QEZnVwAAAAAAAAF0AEZlSQBGZ1AKsAAA4AAAAwAECEXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGZ00AAAAAA4QklNA+0AAAAAABAASAAAAAEAAQBIAAAAAQABOEJJTQQNAAAAAAAEAAAAeDhCSU0D8wAAAAAACAAAAAAAAAAAOEJJTQQKAAAAAAABAAA4QklNJxAAAAAAAAoAAQAAAAAAAAACOEJJTQP1AAAAAABIAC9mZgABAGxmZgAGAAAAAAABAC9mZgABAKGZmgAGAAAAAAABADIAAAABAFoAAAAGAAAAAAABADUAAAABAC0AAAAGAAAAAAABOEJJTQP4AAAAAABwAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAADhCSU0ECAAAAAAAEAAAAAEAAAJAAAACQAAAAAA4QklNBBQAAAAAAAQAAAAFOEJJTQQMAAAAAAdqAAAAAQAAAHAAAAAfAAABUAAAKLAAAAdOABgAAf/Y/+AAEEpGSUYAAQIBAEgASAAA//4AJkZpbGUgd3JpdHRlbiBieSBBZG9iZSBQaG90b3Nob3CoIDUuMP/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAB8AcAMBIgACEQEDEQH/3QAEAAf/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APVUyRXn31wwv8ZOdnupwc6rD6cXH0W4nrMs2gn0jk310Pt9Z7X7bGUX/Zf0f+DSU97kZWPjV+rk2sormN9jgxs/1nkNTYuZiZlXrYl9eRTJHqVPa9sj6Td9Zc1fNf1g6Zb0jq+T066x1t+O7bdY9hZueQH2OY2wl76XOd+hvd/SKv0/+EQ+ldY6p0fKGX0zJsxbhy6swHAHdstYf0d1e7/B2t2JKfp2U68j+rv+MvrOc+y3qIaXdNbVdvpljbKbL8Xp+ZVk4270rn7MluVi3M9G3GyKPz8bIuoXrYSU0Mr6w9Awr3Y2Z1PExsiuN9Nt9bHtkB7d1dj2vbuY7cj4XUun9QqN2Bk05dLXbHWUWNtaHAB2wuqc5u/a5q4XrmTTd/jQx3bsjb0vp5Dzi49mQ9tl3q1+5uLXdaxv2fLZZ6m3/q0X6kM/aH1i6h9aMHZVhdXkHDqeHel6e39N1FlW2qvqOU9v2iun9N6deXlerd/pkp75Jcp1j619VqZ1R/ScOs09E/pmRnGyoWObWcq7Hwqa6i6x3o+lsyL7KKX+tT6Pr0212rZ6V1vGz+hUdasjGotxxkXB5kVDb6lodZDNzav9Jt/lpKdJZfX/AKx9M+r+GczqJtFUO2+nVZZLm8VGxjPQpfa52yn7TbQyxYWT9cOv31Mzuj9KqvwdzHFt+QK8h+O9jbGZnoNa6rEoc53s9W6/K9L9N9jZWg/4y7TndI6X0nFeXP6znUs9ISHPpANljtrtvsqt+zPfv+gkp7LGvGRj13hjq/VY1/pvgObuG7Y/aXN3s+i/3Iq5LE+tGZflDG6TiU29LZeKqeovte45LWFp6gcDDox3Pt9Bz7KG5jrv2f6//ahdY0yAeJEwUlP/0PVUydJJT5h/jV+pPUuo5lHWemNsynlnpZVTrW+wNj0Ps1Vpbta7db6tdX+E/S+l/PPXAYv1L+sV+SKLMR2KJh1uRLGD4aOfc7/g8eu67/g19GoTPsnq+z0/Vjtt3R/1SSnybov+LvqXTGv+1sN1ecaacl7f0bKseu+jPvO25v2nIysn7HXjYtVFHp/pbLMq2lesOuFGMbrmu9rS97K2uscPznNZVS19tv8A1piOmKSnzboedY361df631Ppme117qzg0Nwb3PsqpDqqNv6PbTc70sZ/6f0q/U/wq0vqD0vqON1XrXUsyttFvU8h1t+Ox4sZSQ+11eN9or/Q5GRuvs9b0v5jZX/h77qcfpyPq/ru+yc+6fT5/lK7V6PpN9Hb6UezZG2P5O32pKfHM/J6x1XovW7+r9Ly8nr1T3V73078bEqe/Eb6WHTfa6um30RZ+lxcW/N9/wBr+1fzl667rHTcjP8A8WN3T+m41/rtopDMS5gZeBjvodtfjssv2Xvx8f1fQ3+q/wD472Lr3t6d9rl/pfbCw/SLfU2fnRPv2KeKMQY7fsnp/Z/zPSI2R5bPakp5f6v/AFtZlY2HXj9NyKXWODOoW5Q9CqlzW7bK2XPa77dkucyuvExMev1PR/nvsuxZX1yx6PrB9bOkdPzMLM/ZGOMinIyxj3sYLrwaWBl762M2Uvopubkt9TE/4yj1F3DG9LGbuZ6P20gxq02R+ftE7/6yWQOl+v8ArPoetAj1Nu6Pzfp+5JTyX1FyOq9Jy7vqt1rEvNmHNeB1X03Oqtxmlz6KX5H6RlOz1P1bfb6f/aH9DkU1129wq1v7O9Wr1vR9WB6O/bujt6e73f5qtJKf/9k4QklNBAYAAAAAAAcAAgAAAAEBAP/iDFhJQ0NfUFJPRklMRQABAQAADEhMaW5vAhAAAG1udHJSR0IgWFlaIAfOAAIACQAGADEAAGFjc3BNU0ZUAAAAAElFQyBzUkdCAAAAAAAAAAAAAAAAAAD21gABAAAAANMtSFAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEWNwcnQAAAFQAAAAM2Rlc2MAAAGEAAAAbHd0cHQAAAHwAAAAFGJrcHQAAAIEAAAAFHJYWVoAAAIYAAAAFGdYWVoAAAIsAAAAFGJYWVoAAAJAAAAAFGRtbmQAAAJUAAAAcGRtZGQAAALEAAAAiHZ1ZWQAAANMAAAAhnZpZXcAAAPUAAAAJGx1bWkAAAP4AAAAFG1lYXMAAAQMAAAAJHRlY2gAAAQwAAAADHJUUkMAAAQ8AAAIDGdUUkMAAAQ8AAAIDGJUUkMAAAQ8AAAIDHRleHQAAAAAQ29weXJpZ2h0IChjKSAxOTk4IEhld2xldHQtUGFja2FyZCBDb21wYW55AABkZXNjAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA81EAAQAAAAEWzFhZWiAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPZGVzYwAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdmlldwAAAAAAE6T+ABRfLgAQzxQAA+3MAAQTCwADXJ4AAAABWFlaIAAAAAAATAlWAFAAAABXH+dtZWFzAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAACjwAAAAJzaWcgAAAAAENSVCBjdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23////+ACZGaWxlIHdyaXR0ZW4gYnkgQWRvYmUgUGhvdG9zaG9wqCA1LjD/7gAOQWRvYmUAZIAAAAAB/9sAhAAIBgYGBgYIBgYIDAgHCAwOCggICg4QDQ0ODQ0QEQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQkICAkKCQsJCQsOCw0LDhEODg4OEREMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAoAJIDASIAAhEBAxEB/90ABAAK/8QBogAAAAcBAQEBAQAAAAAAAAAABAUDAgYBAAcICQoLAQACAgMBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAIBAwMCBAIGBwMEAgYCcwECAxEEAAUhEjFBUQYTYSJxgRQykaEHFbFCI8FS0eEzFmLwJHKC8SVDNFOSorJjc8I1RCeTo7M2F1RkdMPS4ggmgwkKGBmElEVGpLRW01UoGvLj88TU5PRldYWVpbXF1eX1ZnaGlqa2xtbm9jdHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4KTlJWWl5iZmpucnZ6fkqOkpaanqKmqq6ytrq+hEAAgIBAgMFBQQFBgQIAwNtAQACEQMEIRIxQQVRE2EiBnGBkTKhsfAUwdHhI0IVUmJy8TMkNEOCFpJTJaJjssIHc9I14kSDF1STCAkKGBkmNkUaJ2R0VTfyo7PDKCnT4/OElKS0xNTk9GV1hZWltcXV5fVGVmZ2hpamtsbW5vZHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4OUlZaXmJmam5ydnp+So6SlpqeoqaqrrK2ur6/9oADAMBAAIRAxEAPwDv+bNkc83+d9A8k2KXuuTMvrFltreJecsrKKsEXYfDX4mdlXFWR1GbPN+vf85F61dO0PlrTIrKLos90TPMfcIvCJP9X99kMu/zk/Me7fkdaeH/ACYI4kH4Jir7DzZ5R8s/nt5z0adV1WVdasyfjiuAElA/4rnQV/4NZM7DpX55eTNYWG3gle01K5okNteq0cXqtsiSXMSzoiM3+7OOKvTc2Feg61Frdm1wsZguIZZLa8tWIZop4m4yJyGzr+3G4+3GyPhpirs2cE83jUF/Ni38v6fq+px2FzF9d1C3ivZlAZ+blYqN+4Q0T92n2f2MX1a+8weRfPXl7T9N1a8vLTVKPfaZfTtdhYuXBnEkoMifDyZWr+xir3TNicUqyxLIv2WFRhcvmfy62ojR11W0bUiaCzE0Zl5fy8OVeX+R9rFU1zZsLtU1/RNERZNX1C3sVf7H1iVIy3+qGILf7HFUxwC2s6St/FpZvoPr83L07QSKZTwUux9MHlRVGK2WoWOp2yXmnXMV3bSfYngdZENPBkJGcM0azsh+dWvXGkwx2lrpyCF/THFfUdU+sSHf4TzWbnir3zNhTB5n8t3NzHZW+sWU11KeEdvFcxPIzAVoqI7Nhtirs2bNir//0O/4Xaxouna5aGz1G3iuIq1VZo0kCnxUSBuJwxzYqwG9/LHShpF9Y6WyadcXELxw3MMSqUYj7VE4s3g2eQZV4SunLlxYjluK0NK77577zg35i/knc6rrt1ruiXKxrfN6kto0VER6AMUaPs/2v7v7WKvnrHKW5ArXlX4ada50m2/JXzK1yIruWJIq/E0Yd2I/yVZU/Fs6JpP5FabCIrhkZp46MjTuSOQ3BaNOHLf9nFWV/lzcTSajrvq9Xnt2fw9Q2kPq/iBnRci/lPy4+gxSpLIZ55ZXuLq4K8PUlkoPhSrcI0RVSNeTfCuGXmC+1nT7EzaJp6ald14+jLOtsigg/vGkcNyAbj8C/Firwu3tL3zb+a3mfULC+nsms5hZQz23pk0i/csB6ySrTlb88X0eS90H8z28s+aWXUp9RVZI9akH+lhCpeKJ2qyrD8DI0carjvy/0/zr5Tvb9p9Htr26vJmuGuXvkiQOw35cUmLLX4vhySaL5I1W/wDNc3m3zBPHdatcUH+jKy21tEAFEUJk+OQ8Bx9Q/wCX/rYqyT8z2sk8qfVrrX28vwySIGmiHKW4jUHnaRqpWSsoP2o/9n+7zj3m2W2u73ydp2laHJoyJdK1lcSxpBLJEjIKiIH6xxqObS3HFnfJv+cXlbzJfat5f8w6JEt7DpVFezdwoVw4kElGoCHpxb/UyPavovnfUPNeieY57WzlighKiNZH9OF2LVEsjD1ZpPj9TlHHx/YxV6v5u82t5U8l3XmKRBJcpGq28Z6NNKQkfL/JVm5N/krkW8s+R7DzBpK33mGCPU9Tv41l1DUbxfVlLyDl6UJP9xDDy4RpDwyR+e/K7+c/JNxots4huCsctszV4+rCeQVv8h/iXlkJ8q6x+ZdnpieWp9Ps7CW3X0jrU8hkIUfDyS0j/vpgv2PjSPl/eYq9G8r+XLXyfpj6faUj0+HlKqCppX4nZid2bPOegecZbC81O+K/VrnzRqMqLq9xH6ltBG7n1X47+tInrfY+x/NnoDzVdeZG8sSW2h2K3t5dwSW0tzcTx2oi5R8PXKEHmzcmPpJx/wBbOYeXPy7u9Y8jXvlTWbNLXULXlLpt2sqyBp+TyAniPgXf0n/mXFWf+S/IGl+XYUbT4kjXr9adENxKf53lpVeX8kfGPJ8ooAPAZzf8rbvzbYWK+W/NlqimxThaXqzLI7oDRYXRf99j/dvLOk4q7NmzYq//0e/5s8AZsVff+bPAGbFX37xXrQY7PAGbFX3/AJRAYUYVGeAc2Kvvr6vB/vpfuGKKqrsoAHtngHNir79dEkUq6hlPUHGfV4OIX014jcCgzwLmxV9/AACgFB4YmbaAvzMalv5qb54FzYq+/WVWHFgCPDGpDEhqqKD4gUzwJmxV9+CKMNzCAN/NTfH54AzYq+/82eAM2Kv/2Q==',
				// 	"picNameF":'/9j/4AAQSkZJRgABAgEASABIAAD/7Ql+UGhvdG9zaG9wIDMuMAA4QklNA+kAAAAAAHgAAHUAAEgASAAAAAAC9AJA/+7/7gMGAlIAAAUoA/wAAARmdQCrAAAUAAAAIAA/Y5QEZnVwAAAAAAAAF0AEZlSQBGZ1AKsAAA4AAAAwAECEXAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGZ00AAAAAA4QklNA+0AAAAAABAASAAAAAEAAQBIAAAAAQABOEJJTQQNAAAAAAAEAAAAeDhCSU0D8wAAAAAACAAAAAAAAAAAOEJJTQQKAAAAAAABAAA4QklNJxAAAAAAAAoAAQAAAAAAAAACOEJJTQP1AAAAAABIAC9mZgABAGxmZgAGAAAAAAABAC9mZgABAKGZmgAGAAAAAAABADIAAAABAFoAAAAGAAAAAAABADUAAAABAC0AAAAGAAAAAAABOEJJTQP4AAAAAABwAAD/////////////////////////////A+gAAAAA/////////////////////////////wPoAAAAAP////////////////////////////8D6AAAAAD/////////////////////////////A+gAADhCSU0ECAAAAAAAEAAAAAEAAAJAAAACQAAAAAA4QklNBBQAAAAAAAQAAAAFOEJJTQQMAAAAAAdqAAAAAQAAAHAAAAAfAAABUAAAKLAAAAdOABgAAf/Y/+AAEEpGSUYAAQIBAEgASAAA//4AJkZpbGUgd3JpdHRlbiBieSBBZG9iZSBQaG90b3Nob3CoIDUuMP/uAA5BZG9iZQBkgAAAAAH/2wCEAAwICAgJCAwJCQwRCwoLERUPDAwPFRgTExUTExgRDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwBDQsLDQ4NEA4OEBQODg4UFA4ODg4UEQwMDAwMEREMDAwMDAwRDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDP/AABEIAB8AcAMBIgACEQEDEQH/3QAEAAf/xAE/AAABBQEBAQEBAQAAAAAAAAADAAECBAUGBwgJCgsBAAEFAQEBAQEBAAAAAAAAAAEAAgMEBQYHCAkKCxAAAQQBAwIEAgUHBggFAwwzAQACEQMEIRIxBUFRYRMicYEyBhSRobFCIyQVUsFiMzRygtFDByWSU/Dh8WNzNRaisoMmRJNUZEXCo3Q2F9JV4mXys4TD03Xj80YnlKSFtJXE1OT0pbXF1eX1VmZ2hpamtsbW5vY3R1dnd4eXp7fH1+f3EQACAgECBAQDBAUGBwcGBTUBAAIRAyExEgRBUWFxIhMFMoGRFKGxQiPBUtHwMyRi4XKCkkNTFWNzNPElBhaisoMHJjXC0kSTVKMXZEVVNnRl4vKzhMPTdePzRpSkhbSVxNTk9KW1xdXl9VZmdoaWprbG1ub2JzdHV2d3h5ent8f/2gAMAwEAAhEDEQA/APVUyRXn31wwv8ZOdnupwc6rD6cXH0W4nrMs2gn0jk310Pt9Z7X7bGUX/Zf0f+DSU97kZWPjV+rk2sormN9jgxs/1nkNTYuZiZlXrYl9eRTJHqVPa9sj6Td9Zc1fNf1g6Zb0jq+T066x1t+O7bdY9hZueQH2OY2wl76XOd+hvd/SKv0/+EQ+ldY6p0fKGX0zJsxbhy6swHAHdstYf0d1e7/B2t2JKfp2U68j+rv+MvrOc+y3qIaXdNbVdvpljbKbL8Xp+ZVk4270rn7MluVi3M9G3GyKPz8bIuoXrYSU0Mr6w9Awr3Y2Z1PExsiuN9Nt9bHtkB7d1dj2vbuY7cj4XUun9QqN2Bk05dLXbHWUWNtaHAB2wuqc5u/a5q4XrmTTd/jQx3bsjb0vp5Dzi49mQ9tl3q1+5uLXdaxv2fLZZ6m3/q0X6kM/aH1i6h9aMHZVhdXkHDqeHel6e39N1FlW2qvqOU9v2iun9N6deXlerd/pkp75Jcp1j619VqZ1R/ScOs09E/pmRnGyoWObWcq7Hwqa6i6x3o+lsyL7KKX+tT6Pr0212rZ6V1vGz+hUdasjGotxxkXB5kVDb6lodZDNzav9Jt/lpKdJZfX/AKx9M+r+GczqJtFUO2+nVZZLm8VGxjPQpfa52yn7TbQyxYWT9cOv31Mzuj9KqvwdzHFt+QK8h+O9jbGZnoNa6rEoc53s9W6/K9L9N9jZWg/4y7TndI6X0nFeXP6znUs9ISHPpANljtrtvsqt+zPfv+gkp7LGvGRj13hjq/VY1/pvgObuG7Y/aXN3s+i/3Iq5LE+tGZflDG6TiU29LZeKqeovte45LWFp6gcDDox3Pt9Bz7KG5jrv2f6//ahdY0yAeJEwUlP/0PVUydJJT5h/jV+pPUuo5lHWemNsynlnpZVTrW+wNj0Ps1Vpbta7db6tdX+E/S+l/PPXAYv1L+sV+SKLMR2KJh1uRLGD4aOfc7/g8eu67/g19GoTPsnq+z0/Vjtt3R/1SSnybov+LvqXTGv+1sN1ecaacl7f0bKseu+jPvO25v2nIysn7HXjYtVFHp/pbLMq2lesOuFGMbrmu9rS97K2uscPznNZVS19tv8A1piOmKSnzboedY361df631Ppme117qzg0Nwb3PsqpDqqNv6PbTc70sZ/6f0q/U/wq0vqD0vqON1XrXUsyttFvU8h1t+Ox4sZSQ+11eN9or/Q5GRuvs9b0v5jZX/h77qcfpyPq/ru+yc+6fT5/lK7V6PpN9Hb6UezZG2P5O32pKfHM/J6x1XovW7+r9Ly8nr1T3V73078bEqe/Eb6WHTfa6um30RZ+lxcW/N9/wBr+1fzl667rHTcjP8A8WN3T+m41/rtopDMS5gZeBjvodtfjssv2Xvx8f1fQ3+q/wD472Lr3t6d9rl/pfbCw/SLfU2fnRPv2KeKMQY7fsnp/Z/zPSI2R5bPakp5f6v/AFtZlY2HXj9NyKXWODOoW5Q9CqlzW7bK2XPa77dkucyuvExMev1PR/nvsuxZX1yx6PrB9bOkdPzMLM/ZGOMinIyxj3sYLrwaWBl762M2Uvopubkt9TE/4yj1F3DG9LGbuZ6P20gxq02R+ftE7/6yWQOl+v8ArPoetAj1Nu6Pzfp+5JTyX1FyOq9Jy7vqt1rEvNmHNeB1X03Oqtxmlz6KX5H6RlOz1P1bfb6f/aH9DkU1129wq1v7O9Wr1vR9WB6O/bujt6e73f5qtJKf/9k4QklNBAYAAAAAAAcAAgAAAAEBAP/iDFhJQ0NfUFJPRklMRQABAQAADEhMaW5vAhAAAG1udHJSR0IgWFlaIAfOAAIACQAGADEAAGFjc3BNU0ZUAAAAAElFQyBzUkdCAAAAAAAAAAAAAAAAAAD21gABAAAAANMtSFAgIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEWNwcnQAAAFQAAAAM2Rlc2MAAAGEAAAAbHd0cHQAAAHwAAAAFGJrcHQAAAIEAAAAFHJYWVoAAAIYAAAAFGdYWVoAAAIsAAAAFGJYWVoAAAJAAAAAFGRtbmQAAAJUAAAAcGRtZGQAAALEAAAAiHZ1ZWQAAANMAAAAhnZpZXcAAAPUAAAAJGx1bWkAAAP4AAAAFG1lYXMAAAQMAAAAJHRlY2gAAAQwAAAADHJUUkMAAAQ8AAAIDGdUUkMAAAQ8AAAIDGJUUkMAAAQ8AAAIDHRleHQAAAAAQ29weXJpZ2h0IChjKSAxOTk4IEhld2xldHQtUGFja2FyZCBDb21wYW55AABkZXNjAAAAAAAAABJzUkdCIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAEnNSR0IgSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYWVogAAAAAAAA81EAAQAAAAEWzFhZWiAAAAAAAAAAAAAAAAAAAAAAWFlaIAAAAAAAAG+iAAA49QAAA5BYWVogAAAAAAAAYpkAALeFAAAY2lhZWiAAAAAAAAAkoAAAD4QAALbPZGVzYwAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAWSUVDIGh0dHA6Ly93d3cuaWVjLmNoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGRlc2MAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAALklFQyA2MTk2Ni0yLjEgRGVmYXVsdCBSR0IgY29sb3VyIHNwYWNlIC0gc1JHQgAAAAAAAAAAAAAAAAAAAAAAAAAAAABkZXNjAAAAAAAAACxSZWZlcmVuY2UgVmlld2luZyBDb25kaXRpb24gaW4gSUVDNjE5NjYtMi4xAAAAAAAAAAAAAAAsUmVmZXJlbmNlIFZpZXdpbmcgQ29uZGl0aW9uIGluIElFQzYxOTY2LTIuMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAdmlldwAAAAAAE6T+ABRfLgAQzxQAA+3MAAQTCwADXJ4AAAABWFlaIAAAAAAATAlWAFAAAABXH+dtZWFzAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAACjwAAAAJzaWcgAAAAAENSVCBjdXJ2AAAAAAAABAAAAAAFAAoADwAUABkAHgAjACgALQAyADcAOwBAAEUASgBPAFQAWQBeAGMAaABtAHIAdwB8AIEAhgCLAJAAlQCaAJ8ApACpAK4AsgC3ALwAwQDGAMsA0ADVANsA4ADlAOsA8AD2APsBAQEHAQ0BEwEZAR8BJQErATIBOAE+AUUBTAFSAVkBYAFnAW4BdQF8AYMBiwGSAZoBoQGpAbEBuQHBAckB0QHZAeEB6QHyAfoCAwIMAhQCHQImAi8COAJBAksCVAJdAmcCcQJ6AoQCjgKYAqICrAK2AsECywLVAuAC6wL1AwADCwMWAyEDLQM4A0MDTwNaA2YDcgN+A4oDlgOiA64DugPHA9MD4APsA/kEBgQTBCAELQQ7BEgEVQRjBHEEfgSMBJoEqAS2BMQE0wThBPAE/gUNBRwFKwU6BUkFWAVnBXcFhgWWBaYFtQXFBdUF5QX2BgYGFgYnBjcGSAZZBmoGewaMBp0GrwbABtEG4wb1BwcHGQcrBz0HTwdhB3QHhgeZB6wHvwfSB+UH+AgLCB8IMghGCFoIbgiCCJYIqgi+CNII5wj7CRAJJQk6CU8JZAl5CY8JpAm6Cc8J5Qn7ChEKJwo9ClQKagqBCpgKrgrFCtwK8wsLCyILOQtRC2kLgAuYC7ALyAvhC/kMEgwqDEMMXAx1DI4MpwzADNkM8w0NDSYNQA1aDXQNjg2pDcMN3g34DhMOLg5JDmQOfw6bDrYO0g7uDwkPJQ9BD14Peg+WD7MPzw/sEAkQJhBDEGEQfhCbELkQ1xD1ERMRMRFPEW0RjBGqEckR6BIHEiYSRRJkEoQSoxLDEuMTAxMjE0MTYxODE6QTxRPlFAYUJxRJFGoUixStFM4U8BUSFTQVVhV4FZsVvRXgFgMWJhZJFmwWjxayFtYW+hcdF0EXZReJF64X0hf3GBsYQBhlGIoYrxjVGPoZIBlFGWsZkRm3Gd0aBBoqGlEadxqeGsUa7BsUGzsbYxuKG7Ib2hwCHCocUhx7HKMczBz1HR4dRx1wHZkdwx3sHhYeQB5qHpQevh7pHxMfPh9pH5Qfvx/qIBUgQSBsIJggxCDwIRwhSCF1IaEhziH7IiciVSKCIq8i3SMKIzgjZiOUI8Ij8CQfJE0kfCSrJNolCSU4JWgllyXHJfcmJyZXJocmtyboJxgnSSd6J6sn3CgNKD8ocSiiKNQpBik4KWspnSnQKgIqNSpoKpsqzysCKzYraSudK9EsBSw5LG4soizXLQwtQS12Last4S4WLkwugi63Lu4vJC9aL5Evxy/+MDUwbDCkMNsxEjFKMYIxujHyMioyYzKbMtQzDTNGM38zuDPxNCs0ZTSeNNg1EzVNNYc1wjX9Njc2cjauNuk3JDdgN5w31zgUOFA4jDjIOQU5Qjl/Obw5+To2OnQ6sjrvOy07azuqO+g8JzxlPKQ84z0iPWE9oT3gPiA+YD6gPuA/IT9hP6I/4kAjQGRApkDnQSlBakGsQe5CMEJyQrVC90M6Q31DwEQDREdEikTORRJFVUWaRd5GIkZnRqtG8Ec1R3tHwEgFSEtIkUjXSR1JY0mpSfBKN0p9SsRLDEtTS5pL4kwqTHJMuk0CTUpNk03cTiVObk63TwBPSU+TT91QJ1BxULtRBlFQUZtR5lIxUnxSx1MTU19TqlP2VEJUj1TbVShVdVXCVg9WXFapVvdXRFeSV+BYL1h9WMtZGllpWbhaB1pWWqZa9VtFW5Vb5Vw1XIZc1l0nXXhdyV4aXmxevV8PX2Ffs2AFYFdgqmD8YU9homH1YklinGLwY0Njl2PrZEBklGTpZT1lkmXnZj1mkmboZz1nk2fpaD9olmjsaUNpmmnxakhqn2r3a09rp2v/bFdsr20IbWBtuW4SbmtuxG8eb3hv0XArcIZw4HE6cZVx8HJLcqZzAXNdc7h0FHRwdMx1KHWFdeF2Pnabdvh3VnezeBF4bnjMeSp5iXnnekZ6pXsEe2N7wnwhfIF84X1BfaF+AX5ifsJ/I3+Ef+WAR4CogQqBa4HNgjCCkoL0g1eDuoQdhICE44VHhauGDoZyhteHO4efiASIaYjOiTOJmYn+imSKyoswi5aL/IxjjMqNMY2Yjf+OZo7OjzaPnpAGkG6Q1pE/kaiSEZJ6kuOTTZO2lCCUipT0lV+VyZY0lp+XCpd1l+CYTJi4mSSZkJn8mmia1ZtCm6+cHJyJnPedZJ3SnkCerp8dn4uf+qBpoNihR6G2oiailqMGo3aj5qRWpMelOKWpphqmi6b9p26n4KhSqMSpN6mpqhyqj6sCq3Wr6axcrNCtRK24ri2uoa8Wr4uwALB1sOqxYLHWskuywrM4s660JbSctRO1irYBtnm28Ldot+C4WbjRuUq5wro7urW7LrunvCG8m70VvY++Cr6Evv+/er/1wHDA7MFnwePCX8Lbw1jD1MRRxM7FS8XIxkbGw8dBx7/IPci8yTrJuco4yrfLNsu2zDXMtc01zbXONs62zzfPuNA50LrRPNG+0j/SwdNE08bUSdTL1U7V0dZV1tjXXNfg2GTY6Nls2fHadtr724DcBdyK3RDdlt4c3qLfKd+v4DbgveFE4cziU+Lb42Pj6+Rz5PzlhOYN5pbnH+ep6DLovOlG6dDqW+rl63Dr++yG7RHtnO4o7rTvQO/M8Fjw5fFy8f/yjPMZ86f0NPTC9VD13vZt9vv3ivgZ+Kj5OPnH+lf65/t3/Af8mP0p/br+S/7c/23////+ACZGaWxlIHdyaXR0ZW4gYnkgQWRvYmUgUGhvdG9zaG9wqCA1LjD/7gAOQWRvYmUAZIAAAAAB/9sAhAAIBgYGBgYIBgYIDAgHCAwOCggICg4QDQ0ODQ0QEQwMDAwMDBEMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMAQkICAkKCQsJCQsOCw0LDhEODg4OEREMDAwMDBERDAwMDAwMEQwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAwMDAz/wAARCAAoAJIDASIAAhEBAxEB/90ABAAK/8QBogAAAAcBAQEBAQAAAAAAAAAABAUDAgYBAAcICQoLAQACAgMBAQEBAQAAAAAAAAABAAIDBAUGBwgJCgsQAAIBAwMCBAIGBwMEAgYCcwECAxEEAAUhEjFBUQYTYSJxgRQykaEHFbFCI8FS0eEzFmLwJHKC8SVDNFOSorJjc8I1RCeTo7M2F1RkdMPS4ggmgwkKGBmElEVGpLRW01UoGvLj88TU5PRldYWVpbXF1eX1ZnaGlqa2xtbm9jdHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4KTlJWWl5iZmpucnZ6fkqOkpaanqKmqq6ytrq+hEAAgIBAgMFBQQFBgQIAwNtAQACEQMEIRIxQQVRE2EiBnGBkTKhsfAUwdHhI0IVUmJy8TMkNEOCFpJTJaJjssIHc9I14kSDF1STCAkKGBkmNkUaJ2R0VTfyo7PDKCnT4/OElKS0xNTk9GV1hZWltcXV5fVGVmZ2hpamtsbW5vZHV2d3h5ent8fX5/c4SFhoeIiYqLjI2Oj4OUlZaXmJmam5ydnp+So6SlpqeoqaqrrK2ur6/9oADAMBAAIRAxEAPwDv+bNkc83+d9A8k2KXuuTMvrFltreJecsrKKsEXYfDX4mdlXFWR1GbPN+vf85F61dO0PlrTIrKLos90TPMfcIvCJP9X99kMu/zk/Me7fkdaeH/ACYI4kH4Jir7DzZ5R8s/nt5z0adV1WVdasyfjiuAElA/4rnQV/4NZM7DpX55eTNYWG3gle01K5okNteq0cXqtsiSXMSzoiM3+7OOKvTc2Feg61Frdm1wsZguIZZLa8tWIZop4m4yJyGzr+3G4+3GyPhpirs2cE83jUF/Ni38v6fq+px2FzF9d1C3ivZlAZ+blYqN+4Q0T92n2f2MX1a+8weRfPXl7T9N1a8vLTVKPfaZfTtdhYuXBnEkoMifDyZWr+xir3TNicUqyxLIv2WFRhcvmfy62ojR11W0bUiaCzE0Zl5fy8OVeX+R9rFU1zZsLtU1/RNERZNX1C3sVf7H1iVIy3+qGILf7HFUxwC2s6St/FpZvoPr83L07QSKZTwUux9MHlRVGK2WoWOp2yXmnXMV3bSfYngdZENPBkJGcM0azsh+dWvXGkwx2lrpyCF/THFfUdU+sSHf4TzWbnir3zNhTB5n8t3NzHZW+sWU11KeEdvFcxPIzAVoqI7Nhtirs2bNir//0O/4Xaxouna5aGz1G3iuIq1VZo0kCnxUSBuJwxzYqwG9/LHShpF9Y6WyadcXELxw3MMSqUYj7VE4s3g2eQZV4SunLlxYjluK0NK77577zg35i/knc6rrt1ruiXKxrfN6kto0VER6AMUaPs/2v7v7WKvnrHKW5ArXlX4ada50m2/JXzK1yIruWJIq/E0Yd2I/yVZU/Fs6JpP5FabCIrhkZp46MjTuSOQ3BaNOHLf9nFWV/lzcTSajrvq9Xnt2fw9Q2kPq/iBnRci/lPy4+gxSpLIZ55ZXuLq4K8PUlkoPhSrcI0RVSNeTfCuGXmC+1nT7EzaJp6ald14+jLOtsigg/vGkcNyAbj8C/Firwu3tL3zb+a3mfULC+nsms5hZQz23pk0i/csB6ySrTlb88X0eS90H8z28s+aWXUp9RVZI9akH+lhCpeKJ2qyrD8DI0carjvy/0/zr5Tvb9p9Htr26vJmuGuXvkiQOw35cUmLLX4vhySaL5I1W/wDNc3m3zBPHdatcUH+jKy21tEAFEUJk+OQ8Bx9Q/wCX/rYqyT8z2sk8qfVrrX28vwySIGmiHKW4jUHnaRqpWSsoP2o/9n+7zj3m2W2u73ydp2laHJoyJdK1lcSxpBLJEjIKiIH6xxqObS3HFnfJv+cXlbzJfat5f8w6JEt7DpVFezdwoVw4kElGoCHpxb/UyPavovnfUPNeieY57WzlighKiNZH9OF2LVEsjD1ZpPj9TlHHx/YxV6v5u82t5U8l3XmKRBJcpGq28Z6NNKQkfL/JVm5N/krkW8s+R7DzBpK33mGCPU9Tv41l1DUbxfVlLyDl6UJP9xDDy4RpDwyR+e/K7+c/JNxots4huCsctszV4+rCeQVv8h/iXlkJ8q6x+ZdnpieWp9Ps7CW3X0jrU8hkIUfDyS0j/vpgv2PjSPl/eYq9G8r+XLXyfpj6faUj0+HlKqCppX4nZid2bPOegecZbC81O+K/VrnzRqMqLq9xH6ltBG7n1X47+tInrfY+x/NnoDzVdeZG8sSW2h2K3t5dwSW0tzcTx2oi5R8PXKEHmzcmPpJx/wBbOYeXPy7u9Y8jXvlTWbNLXULXlLpt2sqyBp+TyAniPgXf0n/mXFWf+S/IGl+XYUbT4kjXr9adENxKf53lpVeX8kfGPJ8ooAPAZzf8rbvzbYWK+W/NlqimxThaXqzLI7oDRYXRf99j/dvLOk4q7NmzYq//0e/5s8AZsVff+bPAGbFX37xXrQY7PAGbFX3/AJRAYUYVGeAc2Kvvr6vB/vpfuGKKqrsoAHtngHNir79dEkUq6hlPUHGfV4OIX014jcCgzwLmxV9/AACgFB4YmbaAvzMalv5qb54FzYq+/WVWHFgCPDGpDEhqqKD4gUzwJmxV9+CKMNzCAN/NTfH54AzYq+/82eAM2Kv/2Q=='
				// };
			}
		}, $Gadget);
		
	},
	
	setTabChange: function($Target, $Gadget,$UI,$Model) {
        debugger;
        var tabId = $Target.attr("id");


        if (null == tabId) {
            $Gadget.$Page.UserInfoTabId = "queryBesLog";
        }

        $Gadget.$Page.UserInfoTabId = tabId;
        $Gadget.$Page.do_query  = '2';

        if($Gadget.asynchronize == undefined)
        {
        	$Gadget.asynchronize = 'N';
        }
        
        $Controller.bes.ad.logquery.query($Gadget,$Fire,$UI,$Model,$Gadget.asynchronize);    
    }

});

$Controller("bes.group.choiceunit", function($Gadget,$Fire) {
	debugger;
	if($Gadget.qryProvinceOrg){//如果
		$Gadget.groupcontext={beId:$Gadget.areaBeId};
	}
	if(!$Gadget.groupcontext || !$Gadget.groupcontext.beId){
		// 获取beid
		//服务链调用
		OC.Callchain.setFireSearch($Page.pageId, $Page.qryFireId);
		$Fire({
			'service' : 'bes.agentdesktop.group.common.groupcommonservice/getgroupcontext',
			'target' : '$Gadget.groupcontext'
		}, $Gadget);
	}
});

$Controller("bes.group.addUnit", function($Gadget, $UI, $Model) {
	debugger;		
	var model = $Model.unit;
	if (!model) {
		$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.DQMYXZKYDDWQXZQTDW')); //当前没有选中可用的单位，请选择其他单位。 //提示
		return false;
	}
});

Array.prototype.contain = function(elt){
    var index;
    for(index in this){
        if(this[index] === elt)
            return true;
    }
    return false;
};

Array.prototype.toggle = function(elt)  {
    var index;
    for(index in this){
        if(this[index] === elt)  {
            this.splice(index,1);
            return;
        }
    }
    this.push(elt);
};

Date.prototype.format = function(format){
	var o = {
		"M+" : this.getMonth()+1, // month
		"d+" : this.getDate(), // day
		"h+" : this.getHours(), // hour
		"m+" : this.getMinutes(), // minute
		"s+" : this.getSeconds(), // second
		"q+" : Math.floor((this.getMonth()+3)/3), // quarter
		"S" : this.getMilliseconds() // millisecond
	}

	if(/(y+)/.test(format)) {
		format = format.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
	}

	for(var k in o) {
		if(new RegExp("("+ k +")").test(format)) {
			format = format.replace(RegExp.$1, RegExp.$1.length==1 ? o[k] : ("00"+ o[k]).substr((""+ o[k]).length));
		} 
	} 
	return format; 
};
