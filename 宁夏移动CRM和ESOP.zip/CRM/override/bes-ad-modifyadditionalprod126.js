$Controller("bes.ad.modifyadditionalprod",{
	init: function($Gadget, $Page, $UI){
		debugger;
		$Gadget.subscribedTietongOffer = false;
		$Gadget.displaySelectedAddiProd = [];
		$Gadget.displaySelectedAddiProd = $.extend(true, [],$Gadget.$Attrs.model) || [];
		$Gadget.deletedAddiProd = [];
		$Gadget.data = {};
		$Page.deviceNumExt = null;
		//字典组中的商品
		$Page.wlanOfferDictList = [];
		//调用OM查询结果商品
		$Gadget.standUptownResponseList = [];

		// add by wkf59141 4G自选（新）套餐展示标识位。
		//$Page.optional4G = false;
		$Page.canpost = [];

		//查询增值商品列表
		if(!$Gadget.displaySelectedAddiProd || $Gadget.displaySelectedAddiProd == ""){
			$Controller.bes.ad.modifyadditionalprod.queryInscrementOfferingNew($Gadget, $UI, $Page);
		}
		else{
			$Gadget.displaymodifyPanel = true;
			$Controller.bes.ad.modifyadditionalprod.selectedlistinit($Gadget,$Gadget.displaySelectedAddiProd,$UI);
		}
		//注入校验事件
		$Controller.bes.ad.modifyadditionalprod.validate($Gadget, $UI);

		$Gadget.isUniversaleNeedAuth = false;
		$Page.isUniversaleNeedAuth = false;
		$Gadget.dictList = $Gadget.dictList || [];
		var universaleCardOfferID = $Gadget.dictList['UNIVERSALE_CARD_OFFERID'] || [];
		if (universaleCardOfferID.length > 0){
			for ( var i = 0; i < universaleCardOfferID.length; i++) {
				if(($Page.data||{}).offeringId == universaleCardOfferID[i].key){
					$Gadget.isUniversaleNeedAuth = true;
					$Page.isUniversaleNeedAuth = true;
					break;
				}
			}
		} else {
			$Gadget.$Get('$Fire')({
				service: "/common/dictkey",
				params: {"dictkeylist": ['UNIVERSALE_CARD_OFFERID']},
				target: "$Gadget.universaleOfferDict",
				onafter: function($Gadget){
					var universaleCardOfferID = $Gadget.universaleOfferDict['UNIVERSALE_CARD_OFFERID'] || [];
			         for ( var i = 0; i < universaleCardOfferID.length; i++) {
			        	 if($Gadget.$Attrs.offeringid == universaleCardOfferID[i].itemCode){
			        		 $Gadget.isUniversaleNeedAuth = true;
			        		 break;
			        	 }
			         }
				}
			}, $Gadget);
		}
		
		// c00311908 初始化时 查询字典
		adutil.queryDataDicts("OM_pcrf_main_offerlist,OM_M2M_Gpcrf_offerlist,OM_M2M_Spcrf_offerlist,DATA_SERVICE_OFFERING,OC_REPEAT_SUBOFFERING,OC_REPEAT_SUBOFFERING", $Gadget);
		
		adutil.queryDataDicts("OC_APNNAME_LOWPOWERMODE,OC_NBIOT_SIXMINUTE,OC_NBIOT_TENMINUTE,OC_NBIOT_ONEHOUR,OC_NBIOT_TENHOURS,OC_CONTROL_ATTR,M2M_SAPN_PROD_ACCTYPE", $Page);
		
		// add for  US-20180605153723-2031094321  个人物联网产品调整   start
		// DD-AR-D01890693 [AD]个人智能网语音通信服务脚本控制（个人变更）
		adutil.queryDataDicts("userAreaFlagCanModify", $Page);
		adutil.querySysParams('UserAreaFlagCtrlOffer', $Page);
		// add for  US-20180605153723-2031094321  个人物联网产品调整   end
		
		$Fire({
            service: 'personalunifiedviewservice/qryofferinstinfo',
            target: '$Gadget.qryOfferInstInfoData',
            onafter: function($Gadget) {
                debugger;
                $Page.qryOfferInstInfoData = $Gadget.qryOfferInstInfoData;
            }
        }, $Gadget);
		
		$Fire({
			service : "/common/dictkey",
			params : {
				"dictkeylist" : ['OM_SET_PCRF_OFFERING','OM_DATASERVICE_APNNAME']
			},
			target : '$Gadget.pcrfdictList',
			onafter : function($Gadget) {
				debugger;
				if ($Gadget.pcrfdictList){
					angular.extend($Page.dictList, $Gadget.pcrfdictList);
				}
			},
		}, $Gadget);
		
	},

	selectedlistinit : function($Gadget,offeringinfolist,$UI){
		debugger;
        	$.each(offeringinfolist || [],function(i,vali){
        		vali.checked = vali.checked || false;
        		vali.showattr = vali.showattr || false;
        		vali.displayQuitReason = vali.displayQuitReason || false;
        		if(!vali.opCode && vali.offeringInstId && vali.exField4 !='N' && vali.exField4 !='C' && vali.status != 9)
        			{
        				vali.checked = true;
        			}
        		else if(vali.exField4 =='N' || vali.exField4 =='C' || vali.status == 9){
        			//********退订的offer以及失效的offer 变成普通未订购的offer处理
        			vali.status = null;
        			vali.exField4 = null;
        			vali.opCode = null;
        			vali.effDate = null;
        			vali.expDate = null;
        			vali.offeringInstId = null;

        		}
        		else if( (vali.opCode == "2"  || vali.opCode == "1"))
        			{
        				vali.checked = true;

        			}

        		if(vali.checked){
        			if($Page.changeNoLine){
        				vali.opCode = "1";
        			}
    				/*if((vali.attributeGroups || []).length > 0){
    					vali.showattr = true;
    				}*/
    				if (vali.hasAttrToShow) {
    					vali.showattr = true;
    				}

        			//增加铁通不能变更的逻辑
        			if(vali.offeringInstId){
        				$.each(vali.attributeGroups||[],function(j,valj){
        					$.each(valj.attributes||[],function(k,valk){
        						if(valk.attrCode == 'radiusType' && valk.newValue=='3'){
        							$Gadget.subscribedTietongOffer = true;
        						}
        					});
        				});
        			}
        		}
        	$.each(((vali.effectiveWay||{}).effectiveTypes||[]),function(j,valj){
        			if(valj.key == "C"){
						vali.effectiveWay.hasC = true;
					}
					if(valj.key == "P"){
						vali.effectiveWay.hasP = true;
					}
				});
        		if(vali.effectiveWay && vali.effectiveWay.hasC && !vali.effectiveWay.hasP){
					var postPone = {};
					postPone.key = "P";
					postPone.value = $UEE.i18n("ad.person.message.DelayTime");//"顺延时间";
					vali.effectiveWay.effectiveTypes.push(postPone);
					$Controller.bes.ad.modifyadditionalprod.postPoneOffers($Gadget, vali);
				}
        		if(vali.postPointOfferingId){
            		vali.postPoint.selectedKey = vali.postPointOfferingId;
            	}

        		//续订按钮判断
        		//1.continueSubscriberOffer true表示续订  默认为空
        		$.each(vali.attributeGroups||[],function(j,valj){
        			$.each(valj.attributes ||[] ,function(k,valk){
        					if(vali.offeringInstId && valk.attrCode  ==  'CanPostPone'  && valk.newValue == '1'){
        						vali.displayContinueSubscriberOffer = true;
        						return false;
        					}

        			});

        		});

        	});
        	if ($Gadget.isUniversaleNeedAuth){
        		$Controller.bes.ad.modifyadditionalprod.clickCheckbox1("",$Page, $UI, $Gadget);
        	}



	},

	continuePostPone:function($Item){
		debugger;
		$Item.continueSubscriberOffer = !$Item.continueSubscriberOffer;

	},

	passWordTest : function($Gadget,$UI,$Item){
		$Fire({
			"popup" : {
				"id" : "passWordTest",
				"title" : $UEE.i18n("密码验证"),//"添加设备",
				"width" : "370px",
				"height" : "260px",
				"src" : "resource.root/bes/ad/ctz/gadget/bes-ad-imsauthentication/bes-ad-imsauthentication.uslx",
				"resizable" : "false"
			}
		}, $Gadget);
	},

	clickRadio : function($Gadget,$UI,pageEvent){
		var $Item = pageEvent.$Scope().$Item;
		if ($Item.selectType=='M' || $Item.exField4 =='N' || $Item.status==9 || $Item.quickPick){
			return;
		} else {
			$UI.msgbox.info("提示", "万能副卡（标准版）和万能副卡（流量版），两个子商品只能开通一个，不支持切换，如需切换，请将万能副卡共享包退订后重新订购另外一个");
			return;
		}

	},

	clickCheckbox1 :function(pageEvent,$Page, $UI, $Gadget){
		debugger;
		$Page.universaleChooseOfferid = $Page.exFiled4;
		$Gadget.attributes = [];
		$.each($Gadget.displaySelectedAddiProd, function(i,val) {
			if (val.offeringId == $Page.exFiled4){
				val.checked = true;
				val.deleteOffer = null;
			}
			if (val.offeringId == $Page.deleteExFiled4){
				var opCode = val.opCode;//add for DTS2018041805678 
				val.checked = false;
				val.opCode = null;
				val.deleteOffer = true;
				val.isDisabled = true;
				//add for DTS2018041805678 start
				if(val.offeringId == '2400000433' || val.offeringId == '2400000432' || val.offeringId == '2400000436'){
					$.each($Page.attributes || [],function(j,vaj){
						if ($Page.deleteExFiled4 == vaj.exFiled4){
							val.checked = true;
							val.opCode = opCode;
							val.deleteOffer = false;
							val.isDisabled = true;
						}
					});
				}
				//add for DTS2018041805678 end
			}
			if (!val.deleteOffer && !$Page.oldExFiled4 && val.offeringId != $Page.exFiled4 && !$Page.initFalg && !$Page.deleteExFiled4){
				val.checked = false;
				val.opCode = null;
				if(val.offeringInstId 
						&& !val.checked 
						&& ((val.offeringId == "2400000434" && $Page.isOrderFK) || (val.offeringId == "2400000435" && $Page.isOrderFH))){
					val.opCode = 3;
					val.displaydate='立即';
					val.expirationWay.selectedKey='I';
					val.deleteOffer = true;
				}
			}
			else if ($Page.oldExFiled4 && val.offeringId == $Page.oldExFiled4 && !$Page.initFalg && !$Page.deleteExFiled4){
				val.checked = true;
				val.deleteOffer = null;
			}

			if(val.checked){
				val.opCode = "1";
			}
			if (!val.deleteOffer && ((val.offeringId == "2400000434" && $Page.isOrderFK == true) || (val.offeringId == "2400000435" && $Page.isOrderFH == true))) {
				val.opCode = null;
			}
			if(val.offeringId == $Page.deleteExFiled4 
					&& val.offeringInstId 
					&& !val.checked 
					&& ((val.offeringId == "2400000434" && $Page.isOrderFK) || (val.offeringId == "2400000435" && $Page.isOrderFH))){
				val.opCode = 3;
				val.displaydate='立即';
				val.expirationWay.selectedKey='I';
			}

			$Controller.bes.ad.modifyadditionalprod.postPoneOffersChg($Gadget);
		});
		$Page.deleteExFiled4 = null;


	},

	clickCheckbox : function($Gadget,$UI,pageEvent){
		debugger;
		if($Gadget.subscribedTietongOffer){
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.OnlySelfOwnedBroadbandNoTietongBus"));//("提示", "该套餐仅可以开发给自建宽带办理，铁通融合不应办理，请关注。");
			//return;
		}
		if($Page.checkbox){
			$Item = pageEvent;
			$Page.checkbox = false;
		}else{
			var $Item = pageEvent.$Scope().$Item;
		}
		
		// 【江苏】 万能副卡整合方案补充需求 - 功能3 US-20180329150458-2031081703
		if ($Gadget.isUniversaleNeedAuth && !this.clickCheckOffer($Item,$Page, $UI, $Gadget)) {
			return;
		}
		
		// 必选项直接返回
		if($Item.selectType=='M' || $Item.exField4 =='N' || $Item.status==9 || $Item.quickPick){
			return;
		}
		// 进入可选逻辑
		else{
			if($Item.offeringCode == "2101000304" && !$Page.TokenStatus){
				$Controller.bes.ad.modifyadditionalprod.passWordTest($Gadget,$UI,$Item);
				return;
			}
			$Item.checked = !$Item.checked;
			// 同步更新新增，删除或者修改模式
			if(!$Item.checked && $Item.offeringInstId){
				//	Modify by ywx372856 如果商品包下还有其他子商品(多层级), 在将该商品包置为删除状态的时候，同时将子商品也置为删除状态
				if($Item.subOfferings != null && $Item.subOfferings.length){
					$Item.subOfferings[0].opCode = '3';
				}
				//	Modify end
				$Item.opCode = '3';
			}else if(!$Item.checked && !$Item.offeringInstId){
				$Item.opCode = '';
			}else if($Item.checked && !$Item.offeringInstId){
				$Item.opCode = '1';
			}else if($Item.checked && $Item.offeringInstId){
				if($Item.opCode = '3'){
					$Item.opCode = '';
				}
				else{
					$Item.opCode = $Item.opCode;
				}

			}
		}

		if( $Item.checked && $Item.hasAttrToShow)
		{
			$Item.showattr = true;
		}else{
			$Item.showattr = false;
		}
		if($Item.opCode == '3' && $Item.offerType == "OTWiredBand" && $Item.offerSubType == "WBMobileBrand"){
			$Item.displayQuitReason = true;
		}
		$Controller.bes.ad.modifyadditionalprod.postPoneOffersChg($Gadget);
		//$.extend($Gadget.$Attrs.model,$Gadget.displaySelectedAddiProd);
		
		/**
    	 * US-20180521185335-2031091190  
    	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
    	 *  查询与商品A有BO关系（表示订购A时，自动把B带出来）的目标商品B，如果源商品退订，目标商品也要退订
    	 */
		if ($Item.checked) {
        	$Item.destEntryIdList = [];
        	$Controller.bes.ad.modifyadditionalprod.queryRelationOffer($Gadget, $Item, $UI);
        } else {
        	// modify for DTS2018060902310 退订自动带出
        	$Controller.bes.ad.modifyadditionalprod.delRelationOffer($Gadget, $Item, $UI);
        }
		
		// 选中和不选中 是两种判断逻辑
        if ($Item.checked)
        {
        	// 选中 判断该项是否为相应套餐，是则修改数据通信服务的属性 
        	$Controller.bes.ad.modifyadditionalprod.setPcrfCheck($Gadget,$Item);
        }
        else
        {
        	// 取消选中，判断所有选中的项中有没有相应套餐，没有则取消数据通信服务必填属性 否则不变
        	$Controller.bes.ad.modifyadditionalprod.cancelPcrfCheck($Gadget,$Item);
        }
	},
	
	// add for DTS2018060902310 退订自动带出
	delRelationOffer : function($Gadget, $Item, $UI){
		debugger;
		$Fire({
    		'service': 'com.huawei.bes.pc.base.common.PcRelationBOService/queryRelationByOriginForValidate',
    		'params': {
    			'searchVO': {
    				"oriEntityType": "O",
    				"oriEntityId": $Item.offeringId,
    				"relaType": "BO"
    			},
    			'beIds': null
    		},
    		'target': '$Gadget.delRelationList',
    		'onafter': function ($Gadget) {
    			debugger;
    			if ($Gadget.delRelationList && $Gadget.delRelationList.length > 0) {
    				
                    for (var i = 0; i < $Gadget.delRelationList.length; i++) {
                    	var delnotOrderdestEntryIdList = [];
                    	if ($Controller.bes.ad.modifyadditionalprod.delInOrderOfferList($Gadget, 
                    			$Gadget.delRelationList[i].destEntryId,$Item.offeringId)) {
                            continue;
                        }
                    	
                    	if ($Controller.bes.ad.modifyadditionalprod.checkDelOfferInShoppingcartList($Gadget, 
                    			$Gadget.delRelationList[i].destEntryId)) {
                             continue;
                		}
                    	
                    	if ($Controller.bes.ad.modifyadditionalprod.checkDelAndNotOrderOfferInShoppingcartList($Gadget, 
                    			$Gadget.delRelationList[i].destEntryId)) {
                    		delnotOrderdestEntryIdList.push($Gadget.delRelationList[i].destEntryId);
                    		var msg = {
                               		operation: "delDestEntryFollowOriEntity",
                               		scene: delnotOrderdestEntryIdList
                             };
                             msg = JSON.stringify(msg);

                             _ysp_top.postMessage(msg, "*");
                             continue;
                		}
                    	
                    	if ($Page.additionalOfferList && $Page.additionalOfferList.length > 0) {
                    		$.each($Page.additionalOfferList||[],function(j,valj){
                    			if (valj.offeringId == $Gadget.delRelationList[i].destEntryId) {
                    				valj.isnotDelOffering = true;
                    				$.each(valj.operType ||[],function(k,valk){
                            			if (valk.key == "2") {
                            				$Controller.bes.personalunifiedview.operatorOffer($Page,$Gadget,$UI,valj,valk,j);
                            			}
                            		});
                    			}
                    		});
                    	}
                    }
    			} 
    		}
    	}, $Gadget);
	},
	
	/**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  查询与商品A有BO关系（表示订购A时，自动把B带出来）的目标商品B，如果源商品退订，目标商品也要退订
	 */
	clickCheckboxCtz : function($Gadget,$UI,$Item){
		debugger;
		if($Gadget.subscribedTietongOffer){
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.OnlySelfOwnedBroadbandNoTietongBus"));//("提示", "该套餐仅可以开发给自建宽带办理，铁通融合不应办理，请关注。");
			//return;
		}
		
		// 【江苏】 万能副卡整合方案补充需求 - 功能3 US-20180329150458-2031081703
		if ($Gadget.isUniversaleNeedAuth && !this.clickCheckOffer($Item,$Page, $UI, $Gadget)) {
			return;
		}
		
		// 必选项直接返回
		if($Item.selectType=='M' || $Item.exField4 =='N' || $Item.status==9 || $Item.quickPick){
			return;
		}
		// 进入可选逻辑
		else{
			if($Item.offeringCode == "2101000304" && !$Page.TokenStatus){
				$Controller.bes.ad.modifyadditionalprod.passWordTest($Gadget,$UI,$Item);
				return;
			}
			$Item.checked = !$Item.checked;
			// 同步更新新增，删除或者修改模式
			if(!$Item.checked && $Item.offeringInstId){
				//	Modify by ywx372856 如果商品包下还有其他子商品(多层级), 在将该商品包置为删除状态的时候，同时将子商品也置为删除状态
				if($Item.subOfferings != null && $Item.subOfferings.length){
					$Item.subOfferings[0].opCode = '3';
				}
				//	Modify end
				$Item.opCode = '3';
			}else if(!$Item.checked && !$Item.offeringInstId){
				$Item.opCode = '';
			}else if($Item.checked && !$Item.offeringInstId){
				$Item.opCode = '1';
			}else if($Item.checked && $Item.offeringInstId){
				if($Item.opCode = '3'){
					$Item.opCode = '';
				}
				else{
					$Item.opCode = $Item.opCode;
				}

			}
		}

		if( $Item.checked && $Item.hasAttrToShow)
		{
			$Item.showattr = true;
		}else{
			$Item.showattr = false;
		}
		if($Item.opCode == '3' && $Item.offerType == "OTWiredBand" && $Item.offerSubType == "WBMobileBrand"){
			$Item.displayQuitReason = true;
		}
		$Controller.bes.ad.modifyadditionalprod.postPoneOffersChg($Gadget);
		//$.extend($Gadget.$Attrs.model,$Gadget.displaySelectedAddiProd);
		
		// 选中和不选中 是两种判断逻辑
        if ($Item.checked)
        {
        	// 选中 判断该项是否为相应套餐，是则修改数据通信服务的属性 
        	$Controller.bes.ad.modifyadditionalprod.setPcrfCheck($Gadget,$Item);
        }
        else
        {
        	// 取消选中，判断所有选中的项中有没有相应套餐，没有则取消数据通信服务必填属性 否则不变
        	$Controller.bes.ad.modifyadditionalprod.cancelPcrfCheck($Gadget,$Item);
        }
	},
	
	/**
     * c00311908 开通多专用APN，订购套餐需要订购pcrf策略
     */
	setPcrfCheck : function($Gadget,item)
	{
		debugger;
        // 从主商品判断是否需要进行校验
		if ($Gadget.dictList["OM_pcrf_main_offerlist"])
        {
        	var mainOfferingId = ($Page.mainOffer || {}).offeringId;
        	var mainOfferIdDict = $Gadget.dictList["OM_pcrf_main_offerlist"]; 
        	var isMainCheckPcrf = false;
        	for ( var i = 0; i < mainOfferIdDict.length; i++) 
        	{
        		if (mainOfferIdDict[i].key == mainOfferingId)
        		{
        			isMainCheckPcrf = true;
        			break;
        		}
        	}
        	if (!isMainCheckPcrf)
        	{
    			return;
        	}
        }
		else
		{
			return;
		}
		debugger;
		var gPcrfDict = $Gadget.dictList["OM_M2M_Gpcrf_offerlist"];
		var sPcrfDict = $Gadget.dictList["OM_M2M_Spcrf_offerlist"];
		var dataServiceDict = $Gadget.dictList['DATA_SERVICE_OFFERING'];
		
		// 所选offeringId 是否为套餐offeringId
		var isCheckPcrf = false;
		if (gPcrfDict)
		{
			for ( var i = 0; i < gPcrfDict.length; i++)
			{
				if (item.offeringId == gPcrfDict[i].key)
				{
					isCheckPcrf = true;
					break;
				}
			}
		}
		if (!isCheckPcrf && sPcrfDict)
		{
			for ( var i = 0; i < sPcrfDict.length; i++)
			{
				if (item.offeringId == sPcrfDict[i].key)
				{
					isCheckPcrf = true;
					break;
				}
			}
		}
		
		// 那么现场问题来了，如果已经知道了套餐需要做pcrf校验，如何判断子商品中哪个是数据通信服务 名字？
		// 按照SE的说法，数据通信服务和专用数据通信服务只有两个固定的offeringId，可以代码中写死
		// 由于环境中数据有多条，可能与实际现场数据不符，在此新加一个数据字典DATA_SERVICE_OFFERING 记录这两种通信服务的offeringid
		if (isCheckPcrf && dataServiceDict)
		{
			// 遍历所有订购的商品 
			debugger;
			$.each($Gadget.displaySelectedAddiProd || [], function(i, vali){
				// 找到数据通信服务
				var isDataServiceOffer = false;
				for ( var j = 0; j < dataServiceDict.length; j++) 
				{
					if (vali.checked && vali.offeringId == dataServiceDict[j].key)
					{
						isDataServiceOffer = true;
						break;
					}
				}
				
				if (isDataServiceOffer)
				{
					// 当前是数据通信服务子产品 循环属性，找到ServiceCode 设为必填
					$.each(vali.attributeGroups || [], function(g, group){
						$.each(group.attributes || [], function(t, attr){
							
							if (attr.attrCode == "ServiceCode")
							{
								debugger;
								attr.isNullable = false;
								return;
							}
						});
					});
				}
			});			
			
		}
	},
	
	delInOrderOfferList: function ($Gadget, destEntryId, oriEntityId) {
    	for (var i = 0; i < $Gadget.displaySelectedAddiProd.length; i++) {
    		if ($Gadget.displaySelectedAddiProd[i].offeringId == destEntryId) {
    			if ($Gadget.displaySelectedAddiProd[i].checked) {
    				$Controller.bes.ad.modifyadditionalprod.clickCheckboxCtz($Gadget,$UI,$Gadget.displaySelectedAddiProd[i]);
    			}
    			return $Gadget.displaySelectedAddiProd[i];
    		}
    	}
    	return null;
    },
	
	/**
     * c00311908 取消选中，判断所有选中的项中有没有相应套餐，没有则取消数据通信服务必填属性 否则不变
     */
	cancelPcrfCheck : function($Gadget,item)
	{
		debugger;
        // 从主商品判断是否需要进行校验
		if ($Gadget.dictList["OM_pcrf_main_offerlist"])
        {
        	var mainOfferingId = ($Page.mainOffer || {}).offeringId;
        	var mainOfferIdDict = $Gadget.dictList["OM_pcrf_main_offerlist"]; 
        	var isMainCheckPcrf = false;
        	for ( var i = 0; i < mainOfferIdDict.length; i++) 
        	{
        		if (mainOfferIdDict[i].key == mainOfferingId)
        		{
        			isMainCheckPcrf = true;
        			break;
        		}
        	}
        	if (!isMainCheckPcrf)
        	{
    			return;
        	}
        }
		else
		{
			return;
		}
		debugger;
		var gPcrfDict = $Gadget.dictList["OM_M2M_Gpcrf_offerlist"];
		var sPcrfDict = $Gadget.dictList["OM_M2M_Spcrf_offerlist"];
		var dataServiceDict = $Gadget.dictList['DATA_SERVICE_OFFERING'];
		
		// 遍历所有选中项，是否有相应套餐
		var isCheckPcrf = false;
		$.each($Gadget.displaySelectedAddiProd || [], function(i, vali){
			// 所选offeringId 是否为套餐offeringId
			if (gPcrfDict)
			{
				for ( var i = 0; i < gPcrfDict.length; i++)
				{
					if (vali.checked && vali.offeringId == gPcrfDict[i].key)
					{
						isCheckPcrf = true;
						break;
					}
				}
			}
			if (!isCheckPcrf && sPcrfDict)
			{
				for ( var i = 0; i < sPcrfDict.length; i++)
				{
					if (vali.checked && vali.offeringId == sPcrfDict[i].key)
					{
						isCheckPcrf = true;
						break;
					}
				}
			}
		});	
		
		// 如果isCheckPcrf==false，则说明没有套餐被选中了，则数据通信服务的属性要设置为非必填
		if (!isCheckPcrf && dataServiceDict)
		{
			// 遍历所有订购的商品 
			debugger;
			$.each($Gadget.displaySelectedAddiProd || [], function(i, vali){
				// 找到数据通信服务
				var isDataServiceOffer = false;
				for ( var j = 0; j < dataServiceDict.length; j++) 
				{
					if (vali.checked && vali.offeringId == dataServiceDict[j].key)
					{
						isDataServiceOffer = true;
						break;
					}
				}
				
				if (isDataServiceOffer)
				{
					// 当前是数据通信服务子产品 循环属性，找到ServiceCode 设为非必填
					$.each(vali.attributeGroups || [], function(g, group){
						$.each(group.attributes || [], function(t, attr){
							
							if (attr.attrCode == "ServiceCode")
							{
								debugger;
								attr.isNullable = true;
								return;
							}
						});
					});
				}
			});
			
			
		}
	},
	
	// 重复订购 点击+
	addItem: function($Gadget, $index, $Item)
	{
		debugger;
		if ($Item.offeringInstId)
		{
			// 有instId的情况，说明是变更页面，就不能直接复制该对象
			// 从offering列表中找到该offering，放进来
			if ($Gadget.data.addresponse && $Gadget.data.addresponse.body && $Gadget.data.addresponse.body.offerings)
			{
				$.each($Gadget.data.addresponse.body.offerings, function(i, vali){
					if ($Item.offeringId == vali.offeringId){
						var item2 = angular.copy(vali);
						item2.reoffer = true;
						item2.showdel = true;
						item2.opCode = '1';
						item2.checked = true;
						if (item2.hasAttrToShow)
						{
							item2.showattr = true;
						}
						$Gadget.displaySelectedAddiProd.splice($index+1, 0, item2);
						return;
					}
				});
			}
		}
		else
		{
			// 新订购场景
			var item2 = angular.copy($Item);
			item2.offeringInstId = null;
			item2.showdel = true;
			item2.opCode = '1';
			$Gadget.displaySelectedAddiProd.splice($index+1, 0, item2);
		}
		
	},
	
	// 重复订购 点击-
	delItem: function($Gadget, $index)
	{
		debugger;
		$Gadget.displaySelectedAddiProd.splice($index, 1);
	},
	
	/**
	 * 处理可重复订购的offering
	 */
	dealSubOfferingsForRepeat: function($Gadget, repeatSubOffers){
		debugger;
		if (!($Gadget.data.addresponse && $Gadget.data.addresponse.body && $Gadget.data.addresponse.body.offerings)){
			return;
		}
		for ( var t = 0; t < repeatSubOffers.length; t++) 
		{
			$.each($Gadget.data.addresponse.body.offerings||[],function(i,val){
				if (val.offeringId == repeatSubOffers[t].key)
				{
					// 只对可重复订购的商品处理
					if(val.selectType == 'M'){
						val.checked = true;
					}
					
					if(val.effectiveWay && (val.effectiveWay.effectiveTypes||[]).length > 0 ){
						if($Gadget.isHomeV) {
							// 如果是家庭v网产品，只保留下账期生效
							val.effectiveWay.effectiveTypes = $.grep(val.effectiveWay.effectiveTypes,function(effective,i){
								return effective.key == "N";
							});
						}
						if(val.effectiveWay.effectiveTypes[0]) {
							val.effectiveWay.selectedKey = val.effectiveWay.selectedKey|| val.effectiveWay.effectiveTypes[0].key;
						}
					}
					if(val.expirationWay && (val.expirationWay.expirationTypes||[]).length > 0 ){
						var selectedKey = "";
						$.each(val.expirationWay.expirationTypes ||[] ,function(l,vall){
							if(vall.selected){
								selectedKey = vall.key;
								return false;
							}
						});
						val.expirationWay.selectedKey = val.expirationWay.selectedKey|| selectedKey || val.expirationWay.expirationTypes[0].key;
					}
					// MODIFY 2015-11-30 by l00289267 start
					if (val.attributeGroups) {
						val.hasAttrToShow = false;
						$.each(val.attributeGroups ||[] ,function(k,valk){
							$.each(valk.attributes || [], function(m, valm){
								if (!adutil.filterOcPcOfferingAttributeEnable(valm.ocPcOfferingAttributeEnableVA, 'modify')) {
									valm.showType = 'HIDDEN';
								}
								if (valm.showType != 'HIDDEN') {
									val.hasAttrToShow = true;
								}
							});
						});
					}
					// MODIFY 2015-11-30 by l00289267 end
					
					$.each(((val.effectiveWay||{}).effectiveTypes||[]),function(j,valj){
	        			if(valj.key == "C"){
							val.effectiveWay.hasC = true;
						}
						if(valj.key == "P"){
							val.effectiveWay.hasP = true;
						}
					});
	        		if(val.effectiveWay && val.effectiveWay.hasC && !val.effectiveWay.hasP){
						var postPone = {};
						postPone.key = "P";
						postPone.value = $UEE.i18n("ad.person.message.DelayTime");//"顺延时间";
						val.effectiveWay.effectiveTypes.push(postPone);
						$Controller.bes.ad.modifyadditionalprod.postPoneOffers($Gadget, val);
					}
	        		if(val.postPointOfferingId){
	            		val.postPoint.selectedKey = val.postPointOfferingId;
	            	}
	        		//续订按钮判断
	        		//1.continueSubscriberOffer true表示续订  默认为空
	        		$.each(val.attributeGroups||[],function(j,valj){
	        			$.each(valj.attributes ||[] ,function(k,valk){
	        					if(val.offeringInstId && valk.attrCode  ==  'CanPostPone'  && valk.newValue == '1'){
	        						val.displayContinueSubscriberOffer = true;
	        						return false;
	        					}

	        			});

	        		});
				}
				
			});
			
		}
	},

	queryInscrementOfferingNew: function($Gadget, $UI, $Page){
		debugger;
		var body = {};
		body.offeringId = $Gadget.$Attrs.offeringid;
		if($Page.changeNoLine){
			$Gadget.$Attrs.offeringinstid = "";
		}
		body.offeringInstId = $Gadget.$Attrs.offeringinstid;
		body.businessCode = 'ChangeProduct';
		// MODIFY 2015-10-29 by l00289267 start
		// body.mainOfferingId = $(document).scope().$Page.selectedMainOfferingId;
		//body.mainOfferingId = ($Page.mainOffer || {}).offeringId;
		//获取主offerId
		body.mainOfferingId = $Gadget.$Attrs.mainofferingid;

		// MODIFY 2015-10-29 by l00289267 end
		$Fire = $Gadget.$Get("$Fire");


		//查询查询用户已订购商品
			$Fire(
					{
						'service' : 'ucec/v1/offeringinst/sub_offering_query',
						'params' :  {
							'body' : body,
						},
						'target' : '$Gadget.data.response',
						'onafter' : function($Gadget, $Fire) {
							debugger;
							//add by wwx292225  重新组装商品属性
							$Gadget.data.response = $Controller.bes.ad.modifyadditionalprod.reGroupSubsOffer($Gadget.data.response)
							// add by wwx 292225 end
							//返回所有子商品
							$Fire(
									{
										'service' : "ucec/v1/offering/sub_offering_query",
										'params' :  {
											header : {},
											body : {
												offeringId : $Gadget.$Attrs.offeringid,
												businessCode : 'ChangeProduct'
												}
											},
										'target' : '$Gadget.data.addresponse',
										'onafter' : function($Gadget) {
											debugger;
											$Fire({
													service: "/common/dictkey",
													params: {
														"dictkeylist": ['OfferingShow']
													},
													target: "$Gadget.promoDict",
													onafter: function($Gadget) {
														debugger;
														//快选页面进行如下处理
											if($Gadget.curItem && $Gadget.data.addresponse && $Gadget.data.addresponse.body
													&& $Gadget.data.addresponse.body.offerings) {
												if($Gadget.data.response && $Gadget.data.response.body) {
													$Gadget.data.response.body.offerings = $Gadget.data.response.body.offerings || [];
												}

												$.each($Gadget.data.addresponse.body.offerings || [], function(i, val) {
													var isExit = false;

													if ($Gadget.data.response && $Gadget.data.response.body){
														// 已经订购没有该子商品，进行插入
														$.each($Gadget.data.response.body.offerings || [], function(j, valOffer) {
															if(valOffer.offeringId == val.offeringId) {
																isExit = true;
																return false;
															}
														});
														if(!isExit) {
															$Gadget.data.response.body.offerings.push(val);
														}
													}

												});
											}

											if ($Gadget.data.response && $Gadget.data.response.body
													&& $Gadget.data.response.body.offerings){
												$Gadget.displaymodifyPanel = true;
												if ($Page.Corporation == 'NINGXIA') {
													$Gadget.data.response.body.offering = $Controller.bes.ad.modifyadditionalprod.setcanpost($Gadget.data.response.body.offerings);
												}
												$Gadget.displaySelectedAddiProd= $Controller.bes.ad.modifyadditionalprod.setSortedSubsOffer($Gadget.data.response.body.offerings);
												if ($Gadget.isUniversaleNeedAuth){
													$Page.isOldGXOffer = false;
													$.each($Gadget.displaySelectedAddiProd,function(k,valk) {
														if((valk.offeringId == "2400000432" || valk.offeringId == "2400000433") && valk.offeringInstId){
															valk.isOldGXOffer = true;
															$Page.isOldGXOffer = true;
															$Controller.bes.ad.modifyadditionalprod.clickCheckbox1("",$Page, $UI, $Gadget);
														}
													});
												}
												
												//add mac properties copy begin
												// 取出快选配置的子商品
												if($Gadget.curItem && $Gadget.curItem.parentOfferingId) {
													var displaySelectedAddiProdTmp = [];
													$.each($Gadget.displaySelectedAddiProd || [], function(i, val) {
														var isIndisplaySelected = false;
														$.each(($Gadget.curItem.parentOfferingId || "").split(","), function(j, valj) {
															if(valj == val.offeringId) {
																isIndisplaySelected = true;
																return;
															}
														});
														if(isIndisplaySelected || (val.offeringInstId && val.exField4 != 'N' && val.status != 9)) {
															// 单选框不可以点击标志
															val.quickPick = true;
															displaySelectedAddiProdTmp.push(val);
														}
													});
													$Gadget.displaySelectedAddiProd = displaySelectedAddiProdTmp;
												}

												var propsValueArr = ["MmacAddr","Road Num"];
												$Controller.bes.ad.modifyadditionalprod.getAndSetPropsValue($Gadget.data.response.body.offerings,propsValueArr);
												//add mac properties copy end
												
												// c00311908 将字典组中配置的可重复订购子offer标注出来 start
												var repeatSubOffers = $Gadget.dictList["OC_REPEAT_SUBOFFERING"];
												if (repeatSubOffers)
												{
													$.each($Gadget.displaySelectedAddiProd, function(t,valt){
														for ( var i = 0; i < repeatSubOffers.length; i++) 
														{
															if (repeatSubOffers[i].key == valt.offeringId)
															{
//																debugger;
																valt.reoffer = true;
																break;
															}
														}
													});
													
													// 处理$Gadget.data.response.body.offerings
													$Controller.bes.ad.modifyadditionalprod.dealSubOfferingsForRepeat($Gadget, repeatSubOffers);
												}
												// c00311908 将字典组中配置的可重复订购子offer标注出来 end
												
											}

											if ($Page.Corporation == "NINGXIA") {
												debugger;
												//判断用户是否宽带用户
												if ($Page.subsInfo && $Page.subsInfo.serviceAccountType) {
													if ($Page.subsInfo.serviceAccountType == '5'
														 || $Page.subsInfo.serviceAccountType == '6') {
														//小区id
														$Gadget.uptownId = "";
														//区县id
														$Gadget.countryID = "";
														//初始化用户信息;
												         $Fire({
														     'service' : 'bes.oc.doublenumberservice/getsubscriberinfo',
														     'target' : '$Page.subscribersinfo',
															 'onafter': function(){
															    debugger;
																if ($Page.subscribersinfo && $Page.subscribersinfo.subscriberInfoPOJO
																		&& $Page.mainOffer){
																	$Fire({
																		service : "shiftbroadbandserviceboservice/init",
																		params : {
																			"offeringid" : $Page.subscribersinfo.offeringId || "",
																			"offeringinstid" : $Page.mainOffer.offeringInstId || "",
																			"productinstid": $Page.subscribersinfo.subscriberInfoPOJO.prodInstId || ""
																		},
																		target : "$Page.relocationInfo",
																		onafter : function(){
																			debugger;
																			if ($Page.relocationInfo) {
																				//获取小区id和区县id
																				if ($Page.relocationInfo.attrInfos && $Page.relocationInfo.attrInfos.length > 0) {
																					$.each($Page.relocationInfo.attrInfos || [],function(i, val) {
																						if (val.propCode == "uptownId" || val.propCode == "zoneId") {
																							$Gadget.uptownId = val.propValue;
																						}
																            			if (val.propCode == "countryID" || val.propCode == "countyId") {
																            				$Gadget.countryID = val.propValue;
																            			};
																					});
																				}
																			}
																			//查询字典组中的商品，对OM返回的商品进行过滤字典组的
																			$Gadget.$Get('$Fire')({
																				service: "/common/dictkey",
																				params: {"dictkeylist": ['wlan_offer_4_uptown']},
																				target: "$Page.wlanOfferDict",
																				onafter: function($Gadget){
																					debugger;
																					$Page.wlanOfferDictList = $Page.wlanOfferDict['wlan_offer_4_uptown'] || [];
																					//查询OM接口
																					$Fire({
																		                service : '/queryStandUptownService/queryStandUptownInfo',
																		                params : {
																		                	countryID : $Gadget.countryID,
																		                	districtID : $Gadget.uptownId
																		                },
																		                target : '$Gadget.standUptownResponse',
																		                onafter : function() {
																		                    debugger;
																		                    if ($Gadget.standUptownResponse && $Gadget.standUptownResponse.length > 0
																		                    		&& $Page.wlanOfferDictList && $Page.wlanOfferDictList.length > 0) {
																		                    	//变更界面小区资费过滤,将字典组中的OM返回的商品过滤
																	    						for(var i = 0; i < $Page.wlanOfferDictList.length; i++) {
																	                        		$Gadget.isFlag = false;
																	                        		$.each($Gadget.standUptownResponse || [],function(n, valn){
																	                        			if($Page.wlanOfferDictList[i].itemCode == valn.offeringId){
																	                        				$Gadget.isFlag = true;
																	                        			}
																	                        		});
																	                        		if($Gadget.isFlag){
																	                        			$Page.wlanOfferDictList.splice(i, 1);
																	                        		}
																	                        	}
																		                    }
																		                  //变更界面小区资费过滤,将字典组中的商品过滤
																							if ($Gadget.displaySelectedAddiProd && $Page.wlanOfferDictList && $Page.wlanOfferDictList.length > 0) {
																								for(var i = 0; i < $Gadget.displaySelectedAddiProd.length; i++) {
															                                		$Gadget.isFlag = false;
															                                		$.each($Page.wlanOfferDictList || [],function(n, valn){
															                                			if($Gadget.displaySelectedAddiProd[i].offeringId == valn.itemCode){
															                                				$Gadget.isFlag = true;
															                                			}
															                                		});
															                                		if($Gadget.isFlag){
															                                			$Gadget.displaySelectedAddiProd.splice(i, 1);
															                                		}
															                                	}
																							}
																		                }
																		            }, $Gadget);
																				}
																			}, $Gadget);
																		}
																}, $Gadget);
															}
														}
													  }, $Gadget);
													}
												}
											}

											// 获取必选子offer
											var mSubOffering = null;
											var mSubOfferingId = "";
											$.each($Gadget.displaySelectedAddiProd||[],function(i,val){
												if(val.selectType == 'M'){
													mSubOffering = val;
													mSubOfferingId = val.offeringId;
													return false;
											    }
											});
											//保存原来的属性
											$Page.data.oldAddiProd = $.extend(true,[],$Gadget.displaySelectedAddiProd);

											$Gadget.isHomeV = false;
											if(mSubOfferingId == "") {
												$Controller.bes.ad.modifyadditionalprod.dealSubOffering($Gadget, $UI, $Page);
											} else {
												// 查询子offer的基本信息，判断是否家庭产品
												var req = {
													'searchofferingcond': {"offeringIdList":[mSubOfferingId]},
													'pageinfo': {"beginRowNumber":0,"recordPerPage":12,"curPage":1}
												};
												$Fire(
													   {
														    "service" : "bes.oc.pcsearchex4telecomqueryservice/queryofferlist",
															'params': req,
															'target' : "$Gadget.data.mSubOffer",
														    'onafter' : function($Gadget) {
														    	$Gadget.data.mSubOffer = $Gadget.data.mSubOffer || [];
														    	var familyProd = $(document).scope().fillFamilyProd($Gadget.data.mSubOffer.offeringList[0]);
														    	if(familyProd) {
														    		if (mSubOffering.offeringInstId){
														    			mSubOffering.opCodeTemp = "2";
														    		}
														    		else{
														    			mSubOffering.opCodeTemp = "1";
														    		}

														    		familyProd.refRelaItemId = adutil.getNextNumber();
														    		familyProd.relaItemId = adutil.getNextNumber();
																	familyProd.opCode = "2";
																	familyProd.prodId = familyProd.productId;
														    		mSubOffering.product = [familyProd];
														    		if("JTVW"==familyProd.prodType) {
															    		$Gadget.isHomeV = true;
															    	}
														    	}
														    	$Controller.bes.ad.modifyadditionalprod.dealSubOffering($Gadget, $UI, $Page);
														    }
													   }, $Gadget);
											}

											if($Gadget.curItem && $Gadget.curItem.parentOfferingId) {
												// 订购过的商品排在前面，进行倒序
												if($Gadget.displaySelectedAddiProd) {
													if($Gadget.displaySelectedAddiProd[0].offeringInstId) {
														$Gadget.displaySelectedAddiProd.reverse();
													}
												}
												// 快选配置的子商品和订购的完全相同,不做处理
												var isSame = true;
												$.each($Gadget.displaySelectedAddiProd || [], function(i, val) {
													if(!val.offeringInstId) {
														isSame = false;
														return false;
													}
												});

												if(!isSame) {
													$.each($Gadget.displaySelectedAddiProd || [], function(i ,val) {
														// 没有订购过的快选子商品
														if(!val.offeringInstId) {
															val.checked = !val.checked;
															// 新增子商品
															if(!val.checked) {
																val.opCode = '';
															}else if(val.checked) {
																val.opCode = '1';
															}
														} else {
															var isInQuick = false;
															// 已经订购过的不在快选配置的子商品中,删除子商品
															$.each(($Gadget.curItem.parentOfferingId || "").split(","), function(j, valj) {
																if(valj == val.offeringId) {
																	isInQuick = true;
																	return;
																}
															});
															if(!isInQuick) {
																val.checked = !val.checked;
																val.opCode = '3';
															}
														}

														if( val.checked && val.hasAttrToShow) {
															val.showattr = true;
														} else {
															val.showattr = false;
														}
														if(val.opCode == '3' && val.offerType == "OTWiredBand" && val.offerSubType == "WBMobileBrand") {
															$Item.displayQuitReason = true;
														}
													});

													$Controller.bes.ad.modifyadditionalprod.postPoneOffersChg($Gadget);
												}

											}
													}
												}, $Gadget);

										}
									}, $Gadget);
						}
					}, $Gadget);
	},
	/*
	 * 重组属性  add wwx292225  DTS2017081607186
	 */
	reGroupSubsOffer: function(willSubOffer)
	{
		debugger;
		if(willSubOffer.body)
		{
			$.each(willSubOffer.body.offerings||[], function(i,vali){
				if(vali.attributeGroups)
				{
					$.each(vali.attributeGroups||[], function(j,valj){
						if(valj.attributes)
						{
							// 组装复杂属性及其子属性
							// 简单属性组
							var  simpleAttr = [];
							// 复杂属性组
							var  complexSunAttr = [];
							$.each(valj.attributes||[], function(k,valk){
								if (null != valk.parentAttrId)
								{
									// 复杂属性 子属性
									complexSunAttr.push(valj.attributes[k]);
								}
								else
								{
									// 简单属性 和复杂属性
									simpleAttr.push(valj.attributes[k]);
								}
							});

							// 遍历简单属性 找出复杂属性父属性   重组复杂属性
							$.each(simpleAttr||[], function(p,valp){
								// 如果包含复杂属性，并且复杂属性子属性为空
								if (valp.isComplex && null == valp.subAttr)
								{
									// 取出父属性的 ID 与子属性匹配
									var complexAttrItem = [];
									$.each(complexSunAttr||[], function(m,valm){

										if(valp.attrId == valm.parentAttrId && valp.attrInstId == valm.parentAttrInstId)
										{
											complexAttrItem.push(complexSunAttr[m]);
										}
									});
									//complexAttrPojo.subExtPropInfo = complexAttrItem;
									//subExtPropAttr.push(complexAttrPojo);
									simpleAttr[p].subAttr = complexAttrItem;
									simpleAttr[p].newValue = "66666";
								}

							});
							valj.attributes = simpleAttr;
						}
					});
				}
			});
		}
		return willSubOffer;
	},
	//
	getAndSetPropsValue : function (offerings,props)
	{
		var value = [];
			value = $Controller.bes.ad.modifyadditionalprod.getOrSetMacPropValue("1",value,offerings,props);
			if (value != null)
			{
				$Controller.bes.ad.modifyadditionalprod.getOrSetMacPropValue("2",value,offerings,props);
			}
	},
	getOrSetMacPropValue : function (type , value, offerings,props)
	{
		if (offerings != null && offerings.length > 0)
		{
			for (var i = 0;i<offerings.length;i++)
			{
				var attributeGroupsObj = offerings[i].attributeGroups;
				if (attributeGroupsObj != null && attributeGroupsObj.length > 0)
				{
					for (var j = 0;j<attributeGroupsObj.length;j++)
					{
						var attributesObj = attributeGroupsObj[j].attributes;
						if ( attributesObj!= null && attributesObj.length >0)
						{
							if (props != null && props.length >0)
							{
								//var retObj = new Object;
								for (var kk = 0;kk<props.length;kk++)
								{
									for (var k = 0;k<attributesObj.length;k++)
									{
										if (type == "1" && attributesObj[k].attrCode == props[kk] && attributesObj[k].oldValue != null)
										{
											var tmpvalue = attributesObj[k].oldValue;
											value.push(tmpvalue);
											if (value.length == props.length)
											{
												return value;
											}
											else
											{
												break;
											}
										}
										if (type == "2" && attributesObj[k].attrCode == props[kk] && (attributesObj[k].newValue == null || attributesObj[k].newValue == ""))
										{
											attributesObj[k].newValue  = value[kk];
										}
									}
								}
							}

						}
					}
				}
			}
			return value;
		}
	},
	dealSubOffering : function($Gadget, $UI, $Page) {
		debugger;
		$.each($Gadget.displaySelectedAddiProd||[],function(i,val){
			if(val.selectType == 'M'){
		         val.checked = true;
		        }

			if(val.effectiveWay && (val.effectiveWay.effectiveTypes||[]).length > 0 ){
				if($Gadget.isHomeV) {
					// 如果是家庭v网产品，只保留下账期生效
					val.effectiveWay.effectiveTypes = $.grep(val.effectiveWay.effectiveTypes,function(effective,i){
						return effective.key == "N";
					});
				}
				if(val.effectiveWay.effectiveTypes[0]) {
					val.effectiveWay.selectedKey = val.effectiveWay.selectedKey|| val.effectiveWay.effectiveTypes[0].key;
				}
			}
			if(val.expirationWay && (val.expirationWay.expirationTypes||[]).length > 0 ){
				var selectedKey = "";
				$.each(val.expirationWay.expirationTypes ||[] ,function(l,vall){
					if(vall.selected){
						selectedKey = vall.key;
						return false;
					}
				});
				val.expirationWay.selectedKey = val.expirationWay.selectedKey|| selectedKey || val.expirationWay.expirationTypes[0].key;
			}
			// MODIFY 2015-11-30 by l00289267 start
			if (val.attributeGroups) {
				val.hasAttrToShow = false;
				$.each(val.attributeGroups ||[] ,function(k,valk){
					$.each(valk.attributes || [], function(m, valm){
		        		if (!adutil.filterOcPcOfferingAttributeEnable(valm.ocPcOfferingAttributeEnableVA, 'modify')) {
		        			valm.showType = 'HIDDEN';
		        		}
		        		if (valm.showType != 'HIDDEN') {
		        			val.hasAttrToShow = true;
		        		}
		        	});
				});
			}
			// MODIFY 2015-11-30 by l00289267 end

		});
		//遍历list，查找是否有密码属性start。
		$.each($Gadget.displaySelectedAddiProd||[],function(index,val){
			if(val.checked){
				$.each(val.attributeGroups||[],function(ind,attrg){
					$.each(attrg.attributes||[],function(i,attr){
						/*if(attr.attrCode=="password"&&(!attr.oldValue||!new RegExp("^[0-9]*$").test(attr.oldValue))&&!$Gadget.tipsFlag)
						{
							$Gadget.tipsFlag = true;
							$Gadget.$Get("$UI").msgbox.info("提示","已订购宽带商品密码为空或包含特殊字符，请设置。");
							return false;
						}*/
						if(attr.attrCode=="password"&&!attr.oldValue&&!$Gadget.tipsFlag && !$Page.changeNoLine)
						{
							$Gadget.tipsFlag = true;
							$Gadget.$Get("$UI").msgbox.info($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.PasswdEmptyorContiansSpecialChars"));//("提示","已订购宽带商品密码为空，请设置。");
							return false;
						}
					});
				});
			}
		});
		//遍历list，查找是否有密码属性end。
		$Controller.bes.ad.modifyadditionalprod.selectedlistinit($Gadget,$Gadget.displaySelectedAddiProd,$UI);
	},

	sortedArray : function(sortedOffers)
	{
		debugger;
		if(Array == sortedOffers.constructor)
		{
			if(sortedOffers && sortedOffers.length > 1)
			{
				var offerLength = sortedOffers.length;
				for(var i = 0 ; i < offerLength ; i++)
				{
					if(sortedOffers[i].memberOrder)
					{
						for(var j = i ; j<offerLength ; j++)
						{
							if(sortedOffers[j].memberOrder)
							{
								if(sortedOffers[j].memberOrder < sortedOffers[i].memberOrder)
								{
									var tempOffer = sortedOffers[i];
									sortedOffers[i] = sortedOffers[j];
									sortedOffers[j] = tempOffer;
								}
							}
						}
					}
					else
					{
						var tempOffer = sortedOffers[i];
						sortedOffers.splice(i, 1);
						sortedOffers.push(tempOffer);
						i=i-1;
						offerLength = offerLength -1;
					}
				}
			}
			else
			{
				return sortedOffers;
			}
		}

		return sortedOffers;
	},

	setcanpost: function(subOffers) {
        debugger;
        var h = 0;
        for (var i = 0; i < subOffers.length; i++) {
            for (var j = 0; j < subOffers[i].attributeGroups.length; j++) {
                for (var k = 0; k < subOffers[i].attributeGroups[j].attributes.length; k++) {
                    if (subOffers[i].attributeGroups[j].attributes[k].attrCode == 'CanPostPone') {
                        for (var m = 0; m < subOffers[i].effectiveWay.effectiveTypes.length; m++) {
                            debugger;
                            //console.log(subOffers[i].effectiveWay.effectiveTypes.length);
                            debugger;
                            if (subOffers[i].effectiveWay.effectiveTypes[m].key == 'C') {
                                subOffers[i].effectiveWay.effectiveTypes[m].key = 'P';
                                subOffers[i].effectiveWay.effectiveTypes[m].value = '顺延时间';
                                //subOffers[i].effectiveWay.effectiveTypes.splice(m,1);

                                // alert(subOffers[i].effectiveWay.effectiveTypes.length);
                            }
                        }
                    }
                }
            }
            $Page.canpost.push(subOffers[i]);
        }
        return $Page.canpost;
    },

	setSortedSubsOffer: function(subOffers)
	{
		debugger;
		//必选产品
		var mustOffers = [];
		//默认可选产品
		var defaultOffers = [];

		if(subOffers)
		{
			for(var i = 0 ; i < subOffers.length ; i++)
			{
				if(subOffers[i].selectType == 'M')
				{
					mustOffers.push(subOffers[i]);
				}
				else
				{
					defaultOffers.push(subOffers[i]);
				}
			}
		}

		//子商品排序
		var sortMustOffers = adutil.sortsearchofferinglist(mustOffers) || $Controller.bes.ad.modifyadditionalprod.sortedArray(mustOffers);
		var sortDefaultOffers = adutil.sortsearchofferinglist(defaultOffers) || $Controller.bes.ad.modifyadditionalprod.sortedArray(defaultOffers);

		return sortMustOffers.concat(sortDefaultOffers);
	},

		postPoneOffers : function($Gadget,offer){
		debugger;
			offer.postPoint = offer.postPoint || {};
			offer.postPoint.postPointList = [];
			$.each($Gadget.displaySelectedAddiProd, function(i,val) {

				if((val.opCode == '1' || val.offeringInstId) && (val.offeringId != offer.offeringId))	{
					debugger;
					var canPostPone = "1";
					//如果是宁夏局点，从产品中获取可续订商品标识的值，如果没有默认为0
					if ($Page.Corporation == 'NINGXIA')
					{
						canPostPone = "0";
						$.each(val.attributeGroups||[],function(j,valj){
        					$.each(valj.attributes||[],function(k,valk){
        						if(valk.attrCode == 'CanPostPone'){
        							canPostPone = valk.newValue;
        						}
        					});
        				});
					}

					if (canPostPone == "1")
					{
						var postPoint = {};
						postPoint.key = ""
							+ val.offeringId
							+ "";
						postPoint.value = val.offeringName;
						postPoint.offeringInstId = val.offeringInstId;
						offer.postPoint.postPointList.push(postPoint);
					}

				}

		});

	},

	postPoneOffersChg : function($Gadget){
		debugger;


			$.each($Gadget.displaySelectedAddiProd, function(i,val) {

				$.each((val.effectiveWay||{}).effectiveTypes||[],function(j,valj){

					if(valj.key == "P"){
						val.postPoint =  val.postPoint || {};
						val.postPoint.postPointList = [];
						val.postPoint.selectedClear = false;
						$.each($Gadget.displaySelectedAddiProd,function(k,valk){
							if((valk.opCode == '1' || valk.offeringInstId) && (valk.offeringId != val.offeringId))	{
								debugger;
								var canPostPone = "1";
								//如果是宁夏局点，从产品中获取可续订商品标识的值，如果没有默认为0
								if ($Page.Corporation == 'NINGXIA')
								{
									canPostPone = "0";
									$.each(valk.attributeGroups||[],function(j,valj){
			        					$.each(valj.attributes||[],function(k,valm){
			        						if(valm.attrCode == 'CanPostPone'){
			        							canPostPone = valm.newValue;
			        						}
			        					});
			        				});
								}

								if (canPostPone == "1")
								{
									var postPoint = {};
									postPoint.key = ""
										+ valk.offeringId
										+ "";
									postPoint.value = valk.offeringName;
									postPoint.offeringInstId = valk.offeringInstId;
									if(val.postPoint.selectedKey == valk.offeringId)
									{
										val.postPoint.selectedClear = true;
									}
									val.postPoint.postPointList.push(postPoint);
								}

							}

						});
						if(!val.postPoint.selectedClear){
							val.postPoint.selectedKey = "";
						}
					}

				});


		});
	},

	postPointChoose : function($Gadget, offerindex, key) {
		debugger;
		$Gadget.displaySelectedAddiProd[offerindex].postPoint.offeringId = null;
		$Gadget.displaySelectedAddiProd[offerindex].postPoint.offeringIntId = null;
		$.each($Gadget.displaySelectedAddiProd[offerindex].postPoint.postPointList || [], function(i,val) {
			if (val.key == key) {
				$Gadget.displaySelectedAddiProd[offerindex].postPoint.selectedKey = key;
				$Gadget.displaySelectedAddiProd[offerindex].postPoint.offeringId = val.key;
				$Gadget.displaySelectedAddiProd[offerindex].postPoint.offeringInstId = val.offeringInstId;
			}
		});

	},

	validate : function($Gadget, $UI){
		$Gadget.$Attrs.validate.push(function(){
			debugger;
			var result = true;

			var displaySelectedAddiProd = $.extend(true, [], $Gadget.displaySelectedAddiProd );
			var addAriffList = [];
			var cancelAriffList = [];
			$.each(displaySelectedAddiProd || [], function(i, val){
				//筛选新订购资费商品和新退订资费商品
				if(val.isAriff && val.addAriff){
					addAriffList.push(val);
				}
				if(val.isAriff && val.cancelAriff){
					cancelAriffList.push(val);
				}

				var subOfferings = val.subOfferings || [];

				//续订按钮逻辑
				if(val.continueSubscriberOffer){
					//1.取消offer实例   2.生效日期赋值为失效日期 ，失效日期空 3.opcode设置为1
					val.offeringInstId = null;
					val.opCode = '1';

					//DTS2017042710000  宁夏移动BES宽带商品的合同期计算有误.修改方案：失效时间设置为空，由后台根据合同模板计算.
                    /*var interDate = null;
                    if (val.effDate && val.expDate && val.expDate >= val.effDate) {
                        interDate = val.expDate - val.effDate;
                        val.effDate = val.expDate;
                        val.expDate = val.effDate + interDate;
                    } else {
                        val.effDate = val.expDate;
                        val.expDate = null;
                    }*/
                    val.effDate = val.expDate;
                    val.expDate = null;

					$.each(val.attributeGroups||[],function(j,valj){
	        			$.each(valj.attributes ||[] ,function(k,valk){
	        				valk.attrInstId = null;

	        			});

	        		});

					$.each(val.product ||[],function(j,valj){
						valj.prodInstId = null;
					});

				}

				if(val.opCode=="1" || val.opCode=="2"){

					if(!val.effDate && !val.effectiveWay.$EffectiveTypesTmp){
						$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectEffectiveModeForNewOffering"));//("提示", "新增的增值商品生效方式必选。");
						result = false;
						return false;
					}
					// modify begin wwx230437 C30LJS001TB100  DTS2015100805405
					if(val.effectiveWay.selectedKey == "C")
					{
						var datetime = $("#dateTime_effective_"+i+" input").val();
						if(!datetime){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectEffectiveTimeForOffering"));//("提示", "请选择增值商品的生效时间。");
							result = false;
							return false;
						}
						val.effectiveWay.effectiveDate = new Date(datetime.replace(/-/g, "/")).getTime();
						if(new Date(val.effectiveWay.effectiveDate).Format("yyMMdd") < new Date().Format("yyMMdd")){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectEffectiveTimeEarlierThanCurerntTime"));//("提示", "增值商品中请选择不小于当前时间的指定生效时间。");
							result = false;
							return false;
						}
						val.expirationWay = val.expirationWay || {};
						if(val.expirationWay.expirationDate){
							if(new Date(val.expirationWay.expirationDate).Format("yyMMdd") < new Date().Format("yyMMdd") ||
									new Date(val.expirationWay.expirationDate).Format("yyMMdd") <= new Date(val.effectiveWay.effectiveDate).Format("yyMMdd"))
								{
									$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.ExpirationTimeMustBeLaterThanCurrent"));//("提示", "增值商品中指定失效时间必须大于生效时间。");
									result = false;
									return false;
								}
							else{
								val.expirationWay.expirationTypes = val.expirationWay.expirationTypes || [];

								var expirationTypes = {};
								expirationTypes.key = "C";
								expirationTypes.value =  $UEE.i18n("ad.person.message.CustomerSpeciesExpirationTime");//"客户指定失效时间";
								expirationTypes.selected = true;
								val.expirationWay.expirationTypes[0] = expirationTypes;
								val.expirationWay.selectedKey = "C";
							}
						}
					}

					if(val.effectiveWay.selectedKey == "S"){
						if(!val.effectiveWay.durationValue){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.EnterPeriodForOffering"));//("提示", "请填写增值商品的特定周期值。");
							result = false;
							return false;
						}else if(!RegExp("^[0-9]*$").test(val.effectiveWay.durationValue) || val.effectiveWay.durationValue > 999){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.EnterPeriodValueFrom1to99forOffering"));//("提示", "增值商品的周期值请输入1-999范围内的数字。");
							result = false;
							return false;
						}

					}
					else if(val.effectiveWay && val.effectiveWay.selectedKey == "P"){
						if(!val.postPoint || !val.postPoint.offeringId){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.DelayNodeCannotBeEmpty"));//("提示", "顺延节点不能为空。");
							result = false;
							return false;
						}
					}


					//if(val.effectiveWay.effectiveTypes[0].key == "P"){
					//DTS2016092706542 原套餐没有到期时选择其他套餐顺延无法订购成功
					if(val.effectiveWay.selectedKey == "P"){
						if(val.postPoint && val.postPoint.offeringId){
							val.postPointOfferingId = val.postPoint.offeringId;
						}
						if(val.postPoint && val.postPoint.offeringInstId){
							val.postPointOfferingInstId = val.postPoint.offeringInstId;
						}

					}

				}
				else if(val.opCode=="3"){


					if(!val.expirationWay.$ExpirationTypesTmp){
						$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectEffectiveModeForOffering"));//("提示", "新增的增值商品生效方式必选。");
						result = false;
						return false;
					}

					if(val.expirationWay.selectedKey == "C"){
						var datetime = $("#dateTime_effective_"+i+" input").val();
						if(!datetime){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectEffectiveTimeForOffering"));//("提示", "请选择增值商品的生效时间。");
							result = false;
							return false;
						}
						val.expirationWay.expirationDate = new Date(datetime.replace(/-/g, "/")).getTime();
						if(new Date(val.expirationWay.expirationDate).Format("yyMMdd") < new Date().Format("yyMMdd")){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectEffectiveTimeEarlierThanCurrent"));//("提示", "增值商品中请选择不小于当前时间的指定生效时间。");
							result = false;
							return false;
						}

					}

					if(val.expirationWay.selectedKey == "S"){
						if(!val.expirationWay.durationValue){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.EnterPeriodForOffering"));//("提示", "请填写增值商品的特定周期值。");
							result = false;
							return false;
						}else if(!RegExp("^[0-9]*$").test(val.expirationWay.durationValue) || val.expirationWay.durationValue > 999){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.EnterPeriodValueFrom1to99forOffering"));//("提示", "增值商品的周期值请输入1-999范围内的数字。");
							result = false;
							return false;
						}

					}
					// modify end wwx230437 C30LJS001TB100  DTS2015100805405



				}

				if(val.continueSubscriberOffer){
					//1.取消offer实例   2.生效日期赋值为失效日期 ，失效日期空 3.opcode设置为1
					val.effectiveWay = null;
                    val.expirationWay = null;


				}

			});
			//江苏需求：判断当前订购的资费商品与退订的商品是否属于同一台互联网电视
			if(addAriffList&& addAriffList.length > 0 && cancelAriffList && cancelAriffList.length > 0){
				var flag = false;
				$.each(addAriffList|| [], function(i, vali){
					var hasSame = false;
					$.each(vali.ariffNumList|| [], function(j, valj){
						$.each(cancelAriffList|| [], function(k, valk){
							$.each(valk.ariffNumList|| [], function(r, valr){
								if(valj == valr){
									hasSame = true;
								}
							});
						});
					});
					if(!hasSame){
						flag = true;
					}
				});
				if(flag){
					$UI.msgbox.info($UEE.i18n("ad.person.label.information"), "你所订购的资费套餐与退订的资费套餐不属于同一台互联网电视,请重新确认！！");
					result = false;
					return false;
				}
			}
			if(result){
				$.extend($Gadget.$Attrs.model,displaySelectedAddiProd);
			}
			return result;
		});
	},

	dropListChoose : function(offerindex,key){
		  debugger;
		  var $GadgetTmp = $('.bes-ad-modifyadditionalprod').scope().$$childTail.$Gadget;

		  if($GadgetTmp.displaySelectedAddiProd[offerindex].opCode=="1" || $GadgetTmp.displaySelectedAddiProd[offerindex].opCode=="2"){
			  if(!$GadgetTmp.displaySelectedAddiProd[offerindex].effectiveWay.$EffectiveTypesTmp){
			  $GadgetTmp.displaySelectedAddiProd[offerindex].effectiveWay.$EffectiveTypesTmp = $GadgetTmp.displaySelectedAddiProd[offerindex].effectiveWay.effectiveTypes;

			  }
			  var effectiveType = {};
			  $.each($GadgetTmp.displaySelectedAddiProd[offerindex].effectiveWay.$EffectiveTypesTmp || [], function(i, val){
				  if(val.key == key){
					  effectiveType = val;
					  $GadgetTmp.displaySelectedAddiProd[offerindex].effectiveWay.selectedKey = key;
				  }
			  });

		  }
		  else if($GadgetTmp.displaySelectedAddiProd[offerindex].opCode=="3")
		  {
			  if(!$GadgetTmp.displaySelectedAddiProd[offerindex].expirationWay.$ExpirationTypesTmp){
				  $GadgetTmp.displaySelectedAddiProd[offerindex].expirationWay.$ExpirationTypesTmp = $GadgetTmp.displaySelectedAddiProd[offerindex].expirationWay.expirationTypes;
			  }
			  var expirationType = {};
			  $.each($GadgetTmp.displaySelectedAddiProd[offerindex].expirationWay.$ExpirationTypesTmp || [], function(i, val){
				  if(val.key == key){
					  expirationType = val;
					  $GadgetTmp.displaySelectedAddiProd[offerindex].expirationWay.selectedKey = key;
				  }
			  });

		  }

		  //指定时间生效和顺延时间的时候 调整下样式
		  if(key == "P" || key == "C")
		  {
			  $(".grid td").css("white-space","normal");
			  $(".grid td").css("overflow","visible");
		  }
	},


    attrpop: function($Page, $Gadget, $index, $UI) {
        debugger;
        var offer = $Gadget.displaySelectedAddiProd[$index];
        if (offer.attributeGroups && offer.attributeGroups.length > 0) {
            $Controller.bes.ad.personalsubofferattrpop.attrpop($Page, $Gadget, $index, $UI);
            return;
        }

        if (offer.offeringInstId && (!offer.attributeGroups || offer.attributeGroups.length == 0)) {
            $Fire({
                service: 'ucec/v1/offeringInst/offeringattributesinst_query',
                params: {
                    header: null,
                    body: {
                        offeringId: offer.offeringId,
                        offeringInstId: offer.offeringInstId
                    }
                },
                target: '$Gadget.offerInstAttrs',
                onafter: function($Gadget) {
                    debugger;
                    if (!$Gadget.offerInstAttrs || !$Gadget.offerInstAttrs.body) {
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "该商品没有可设置的属性。");
                        return;
                    }

                    offer.attributeGroups = $.extend(true, [], $Gadget.offerInstAttrs.body.attributeGroups || []);
                    var $UI = $Gadget.$Get("$UI");
                    if (!offer.attributeGroups || offer.attributeGroups.length == 0) {
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "该商品没有可设置的属性。");
                        return;
                    }

                    $Controller.bes.ad.personalsubofferattrpop.attrpop($Page, $Gadget, $index, $UI);
                }
            },
            $Gadget);
		} else if(!offer.offeringInstId && (!offer.attributeGroups || offer.attributeGroups.length == 0)){
			$Gadget.offerAttrs = {};
			$Fire({
				service : 'ucec/v1/offering/offeringattributes_query',
				params : {
					header : null,
					body : {
						offeringId : offer.offeringId,
					}
				},
				target : '$Gadget.offerAttrs',
				onafter : function($Gadget) {
					debugger;
					if (!$Gadget.offerAttrs || !$Gadget.offerAttrs.body)
					{
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "该商品没有可设置的属性。");
						return;
					}

					offer.attributeGroups = $.extend(true, [], $Gadget.offerAttrs.body.attributeGroups || []);
                    var $UI = $Gadget.$Get("$UI");
                    if (!offer.attributeGroups || offer.attributeGroups.length == 0) {
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "该商品没有可设置的属性。");
                        return;
                    }

					$Controller.bes.ad.personalsubofferattrpop.attrpop($Page, $Gadget, $index, $UI);
				}
			}, $Gadget);
        }

    },
    
    /*
     * 【江苏】 万能副卡整合方案补充需求 - 功能3 US-20180329150458-2031081703  
     *  主号订购多终端共享包（新）（2400000431）,子商品的选择改造为：
     *      程序自动选择，但可以被营业员取消（复选框不再置灰），勾选取消的同时，AD加入对子商品与属性的匹配性校验。
                        如果选择了副卡或副号类型，但子商品（副卡功能或多终端共享功能）没有对应的选择，提示报错给营业员。拒绝修改。
			如果匹配性校验通过，功能商品可以被取消
     */
	clickCheckOffer : function($Item,$Page, $UI, $Gadget){
		debugger;
		if ($Item.offeringId == "2400000432" || $Item.offeringId == "2400000433" || $Item.offeringId == "2400000436") {
			return false;
		}
		var productattrchangeGadget = adutil.getGadgetObj($(".bes-ad-productattrdisplay"));
		$Gadget.isChooseSecondCard = false;//是否选择了副卡
		$Gadget.isChooseSecondNum = false;//是否选择了副号
		$.each(productattrchangeGadget.commattr,function(i,val){
			$.each(val.attributes || [], function(j, valj){
				$.each($Gadget.dictList['UNIVERSALE_CARD_ATTRCODE'] || [], function(k, valk){
					if (valj.attrCode == valk.key) {
						if (valj.exFiled4 == "2400000434") {//副卡映射2400000434副卡共享功能
							$Gadget.isChooseSecondCard = true;
						}
						if (valj.exFiled4 == "2400000435") {//副号映射2400000435多终端共享功能
							$Gadget.isChooseSecondNum = true;
						}
					}
				});
			});
        });
		
		if ($Item.offeringId == "2400000434" && !$Gadget.isChooseSecondCard) {
			$UI.msgbox.info("提示", "没有副卡类型的副号，不能订购[副卡共享功能]，请重新选择。");
			return false;
		}
		if ($Item.offeringId == "2400000435" && !$Gadget.isChooseSecondNum) {
			$UI.msgbox.info("提示", "没有副号类型的副号，不能订购[多终端共享功能]，请重新选择。");
			return false;
		}
		
		if ($Item.offeringId == "2400000434" && $Gadget.isChooseSecondCard) {
			$UI.msgbox.info("提示", "套餐共享副号存在副卡类型，必须订购子商品[副卡共享功能]，不能取消订购。");
			return false;
		}
		if ($Item.offeringId == "2400000435" && $Gadget.isChooseSecondNum) {
			$UI.msgbox.info("提示", "套餐共享副号存在副号类型，必须订购子商品[多终端共享功能]，不能取消订购。");
			return false;
		}
		return true;
	},
    
	/**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  查询与商品A有BO关系（表示订购A时，自动把B带出来）的目标商品B
	 */
    queryRelationOffer: function ($Gadget, oriEntityInfo, $UI) {
    	debugger;
    	$Fire({
    		'service': 'com.huawei.bes.pc.base.common.PcRelationBOService/queryRelationByOriginForValidate',
    		'params': {
    			'searchVO': {
    				"oriEntityType": "O",
    				"oriEntityId": oriEntityInfo.offeringId,
    				"relaType": "BO"
    			},
    			'beIds': null
    		},
    		'target': '$Gadget.relationList',
    		'onafter': function ($Gadget) {
    			debugger;
    			if ($Gadget.relationList && $Gadget.relationList.length > 0) {
    				$Gadget.notOrderdestEntryIdList = [];
                    for (var i = 0; i < $Gadget.relationList.length; i++) {
                    	if ($Controller.bes.ad.modifyadditionalprod.findInOrderOfferList($Gadget, 
                            $Gadget.relationList[i].destEntryId,oriEntityInfo.offeringId)) {
                            continue;
                        }
    		    		$Gadget.notOrderdestEntryIdList.push($Gadget.relationList[i].destEntryId);
                    }
                    if ($Gadget.notOrderdestEntryIdList && $Gadget.notOrderdestEntryIdList.length > 0) {
                    	$Controller.bes.ad.modifyadditionalprod.orderOfferByDestEntryId($Gadget, $Fire, $Gadget.relationList, oriEntityInfo.offeringId);
                    }
    			} 
    		}
    	}, $Gadget);
    },
    
    /**
     * 判断源对象oriEntityId的目标对象destEntryId，是否在选择列表里，如果在，那么：
     * 1.设置源对象的目标对象
     * 2.设置目标对象的源对象并订购目标对象
     */
    findInOrderOfferList: function ($Gadget, destEntryId, oriEntityId, oriEntityIdIsCheck) {
    	debugger;
    	for (var i = 0; i < $Gadget.displaySelectedAddiProd.length; i++) {
    		//设置源对象的目标对象
    		if ($Gadget.displaySelectedAddiProd[i].offeringId == oriEntityId) {
    			$Gadget.displaySelectedAddiProd[i].destEntryIdList.push(destEntryId);
    		}
    	}
    	for (var i = 0; i < $Gadget.displaySelectedAddiProd.length; i++) {
    		//设置目标对象的源对象并订购目标对象
    		if ($Gadget.displaySelectedAddiProd[i].offeringId == destEntryId) {
    			$Gadget.displaySelectedAddiProd[i].oriEntityId = oriEntityId;
    			if (!$Gadget.displaySelectedAddiProd[i].checked) {
        			$Controller.bes.ad.modifyadditionalprod.clickCheckboxCtz($Gadget,$UI,$Gadget.displaySelectedAddiProd[i]);
    			}
    			return $Gadget.displaySelectedAddiProd[i];
    		}
    	}

    	return null;
    },
    
    /**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  查询目标商品的商品详情信息，并订购
	 */
    orderOfferByDestEntryId: function ($Gadget, $Fire, destEntryId, oriEntityId) {
    	debugger;
    	$Fire({
            'service' : 'bes.oc.queryofferdetailservice/queryofferdetailbyofferidlist',
            'params' : {
            	'offerids' : $Gadget.notOrderdestEntryIdList
             },
            'target' : '$Gadget.destEntryOfferdetailList',
            onafter : function() {
                debugger;
                if ($Gadget.destEntryOfferdetailList) {
                	for (var i = 0; i < $Gadget.destEntryOfferdetailList.length; i++) {
                		if ($Controller.bes.ad.modifyadditionalprod.checkOfferInShoppingcartList($Gadget, 
                				$Gadget.destEntryOfferdetailList[i].offerId)) {
                			continue;
                		}
                		var isOrderOld = false;
                		for (var j = 0; j < $Page.qryOfferInstInfoData.length; j++) {
                    		if ($Page.qryOfferInstInfoData[j].offeringId == $Gadget.destEntryOfferdetailList[i].offeringId) {
                    			isOrderOld = true;
                    		}
                    	}
                		if (!isOrderOld) {
                			if ($Controller.bes.ad.modifyadditionalprod.checkDelOfferInShoppingcartList($Gadget, 
                					$Gadget.destEntryOfferdetailList[i].offerId)) {
                				var destEntryIdInShopCarList = [];
                				destEntryIdInShopCarList.push($Gadget.destEntryOfferdetailList[i].offerId);
                				if (destEntryIdInShopCarList && destEntryIdInShopCarList.length > 0) {
                        			var msg = {
                                       		operation: "delDestEntryFollowOriEntity",
                                       		scene: destEntryIdInShopCarList
                                     };
                                     msg = JSON.stringify(msg);

                                     _ysp_top.postMessage(msg, "*");
                        		}
                    		} else {
                    			$Gadget.data.offeringinfo = $Gadget.destEntryOfferdetailList[i];
                				$Gadget.data.offeringinfo.oriEntityId = oriEntityId;
                				$Controller.bes.oc.prodDispachUrl.directAddtoShoppincar($Page, $Gadget);
                    		}
                			
                		}
                		
                	}
                }
            }
        },$Gadget);
    	
    },
    
    /**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  判断购物车订购列表中是否存在目标商品
	 */
    checkDelAndNotOrderOfferInShoppingcartList: function ($Gadget, destEntryId) {
    	for (var i = 0; i < window._ysp_top.shoppingcart.carofferingList.length; i++) {
			if (window._ysp_top.shoppingcart.carofferingList[i].offeringId == destEntryId) {
				return true;
			}
		}
    	return null;
    },
    
    checkOfferInShoppingcartList: function ($Gadget, destEntryId) {
    	for (var i = 0; i < window._ysp_top.shoppingcart.carofferingList.length; i++) {
			if (window._ysp_top.shoppingcart.carofferingList[i].offeringId == destEntryId && window._ysp_top.shoppingcart.carofferingList[i].opCode != "3") {
				return true;
			}
		}
    	return null;
    },
    
    checkDelOfferInShoppingcartList: function ($Gadget, destEntryId) {
    	for (var i = 0; i < window._ysp_top.shoppingcart.carofferingList.length; i++) {
			if (window._ysp_top.shoppingcart.carofferingList[i].offeringId == destEntryId && window._ysp_top.shoppingcart.carofferingList[i].opCode == "3") {
				return true;
			}
		}
    	return null;
    }

});
