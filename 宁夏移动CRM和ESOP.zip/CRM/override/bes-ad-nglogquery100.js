$Controller("bes.ad.nglogquery", {
    getNgLog: function($Gadget, $Fire, $UI, $Event) {
        debugger;
        $Page = $Gadget.$Page;
        //系统参数脚本暂时没提交
        $Fire({
            service: 'ucec/v1/common/qrysystemparambykey',
            params: { key: 'NG_LOG_ADDR_URL' },
            target: '$Gadget.gimsurl',
            onafter: function() {
                debugger;
                //$Gadget.gimsurl  ="http://localhost:9212/com.huawei.bes.oc.base.web/bes/ad/themes/default/template/bes-ad-standardaddrchoice/bes-ad-monitorgimspage.html?"
                if ($Gadget.gimsurl == "") {
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("请配置icrm日志查询地址")); 
                }
                if ($Event.$Data.body.depId) {
                    $Fire({
                        service: '/com.huawei.bes.sm.base.orgstaff.smorgintfboservice/queryorg',
                        params: { orgid: $Event.$Data.body.depId },
                        target: 'data'
                    }, $Gadget).onafter(function(data) {
                        if (data) {
                            $Event.$Data.body.depId = data.orgBizCode;
                        }
                        // var callGimsUrl = $Gadget.gimsurl + "&callFromBES=TRUE";

                        // if ($Page.do_query == '1') {
                        //     var model = $Controller("bes.ad.nglogquery").assembleparams($Gadget, $Fire, $UI, $Event);
                        //     callGimsUrl = callGimsUrl + model;
                        //     $("#showthirdaddr").html("<iframe id='ng-log-addr-url' src=" + callGimsUrl + " width='100%' height='85%' style='border-style: none;position: absolute;'></iframe>");
                        // }
                        // //初始化页面   
                        // if ($("#ng-log-addr-url").length == 0) {
                        //     $("#showthirdaddr").html("<iframe id='ng-log-addr-url' src=" + callGimsUrl + " width='100%' height='85%' style='border-style: none;position: absolute;'></iframe>");
                        // }
                        $Controller("bes.ad.nglogquery").getNgLogUrl($Page,$Gadget,$UI,$Event);
                    });
                }else{
                    $Controller("bes.ad.nglogquery").getNgLogUrl($Page,$Gadget,$UI,$Event);
                }

                // var ifr = $("#ng-log-addr-url");
                // if (window.attachEvent) {
                //     ifr.onreadystatechange = function() {
                //         if (iframe.readyState == "complete") {
                //             $('#BackQueryId').attr('disabled', null);
                //             $('#QueryId').attr('disabled', null);
                //         }
                //     };
                // } else {
                //     ifr.onload = function() {
                //         $('#BackQueryId').attr('disabled', null);
                //         $('#QueryId').attr('disabled', null);
                //     };
                // }
            }
        }, $Gadget);
    },
    getNgLogUrl: function($Page,$Gadget,$UI,$Event) {
        debugger;
        var callGimsUrl = $Gadget.gimsurl + "&callFromBES=TRUE";

        if ($Page.do_query == '1') {
            var model = $Controller("bes.ad.nglogquery").assembleparams($Gadget, $Fire, $UI, $Event);
            callGimsUrl = callGimsUrl + model;
            $("#showthirdaddr").html("<iframe id='ng-log-addr-url' src=" + callGimsUrl + " width='99%' height='80%' style='border-style: none;position: absolute;'></iframe>");
        }
        //初始化页面   
        if ($("#ng-log-addr-url").length == 0) {
            $("#showthirdaddr").html("<iframe id='ng-log-addr-url' src=" + callGimsUrl + " width='99%' height='80%' style='border-style: none;position: absolute;'></iframe>");
        }
    },

    assembleparams: function($Gadget, $Fire, $UI, $Event) {
        debugger;
        var url = "";
        $Gadget.icrm = this.translate($Event.$Data.body);
        if (!OC.Comm.isNullObj($Gadget.icrm)) {
            for (var name in $Gadget.icrm) {
                // if ($Gadget.icrm[name] instanceof Array) {
                //     var parmas;
                //     for (var i = 0; i < $Gadget.icrm[name].length; i++) {
                //         if (i == 0) {
                //             parmas = $Gadget.icrm[name][i];
                //             continue;
                //         }
                //         parmas = "," + $Gadget.icrm[name][i];
                //     }
                //     $Gadget.icrm[name] = parmas;
                // }
                if ($Gadget.icrm[name] == undefined) {
                    $Gadget.icrm[name] = "";
                }
                url += "&" + name + "=" + $Gadget.icrm[name];
            }
        }
        return url;
    },
    translate: function (data) {
        debugger;
        var obj = {};
        //获取EmployeeCode   
		if (data.selectDisPlayEmployeeCode) {
			obj.opid = data.selectDisPlayEmployeeCode;
		}
        if(data.depId){
            obj.orgname = data.depId;
            obj.recObj =  "orgname"; 
        }
        //受理类型 默认为ALL
        obj.rectype = 'ALL';
        if(data.busiCode){
        	obj.rectype = data.busiCode;
        }
        obj.formnum = data.recId;
        /**
        if(data.accessChannelTypeName){
            obj.accesstype = encodeURI(data.accessChannelTypeName,"utf-8");
        }
        else{
            obj.accesstype = data.accessChannelTypeName;
        }
        obj.accesstype = data.accessChannelTypeName;   
        **/
        
        //受理渠道，默认为‘ALL’
        obj.accesstype='ALL';
        //受理渠道需要转换,现网字典id与bes不一致，现网的id放到了字典项扩展字段1，因此查现网日志时，优先取扩展字段1的值
        if(data.accessChannelType){
        	obj.accesstype = data.accessChannelType;
        	if(data.accessChannelTypeExt1){
        		obj.accesstype = data.accessChannelTypeExt1;
        	}
        }
        
        
        //受理状态
        if(data.status == 'OS90'|| data.status =='OS20')
        {
        	//在网
            obj.status = 'stcmNml';
        }
        if(data.status =='OS50')
        {
        	//执行异常
            obj.status = 'stcmOrderExcp';
        }
        else
        {
             obj.status = 'ALL';
        }
        obj.srvnum = data.serviceNumber;
        obj.beginDate = new Date(data.fromDate).Format("yyyy-MM-dd");
        obj.endDate = new Date(data.toDate).Format("yyyy-MM-dd");
        obj.grpcode = data.groupCustCode;
        obj.rcTP = data.busiClass;
        obj.productName = data.offeringId;
        obj.querytype = data.sortType;
        obj.isBackYw = data.incBackProcess;
        if (data.incBackProcess == 'Y') {          
            obj.isShowBack = '0';
        } else {
             obj.isShowBack = '1';
        }
        if (data.incRollback == 'Y') {          
            obj.isBackYw = '0';
        } else {           
             obj.isBackYw = '1';
        }

        if (data.relaRequest == 'Y') {
            obj.isQryRelate = '1';
        } else {
            obj.isQryRelate = '0';
        }
        if (data.queryLogDetail =='Y') {
            obj.uniontype = '0';
        } else {
            obj.uniontype = '1';
        }
        if (data.beId){
        	obj.SelectRegion = data.beId;
        }
        
        
        return obj;
    }
});
