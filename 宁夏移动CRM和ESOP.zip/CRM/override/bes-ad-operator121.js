$Controller("bes.oc.operator", {
    // 点击“经办人信息”，展开或者收缩经办人信息输入框
    changeDispaly : function($Gadget, $Page)
    {
        debugger;
        $Gadget.operatorInfoShowFlag = !$Gadget.operatorInfoShowFlag;

        // 收缩展开结束后，发送事件，通知停开机组件刷新滚动条
        $Gadget.$Emit('$operatorInfo.changedisplay.finish', {});
    },

    hideOperatorInfo : function($Gadget)
    {
        $Gadget.operatorInfoShowFlag = false;
    },
    
    
    
    
    
    
    
    
    selectTemplateContent : function($Gadget, $Fire, $Page){
    	debugger;
    	if (!$Gadget.selectedTempContentId)
    	{
    		$Gadget.$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "请选择模板内容!");
    		return;
    	}
    	$.each($Gadget.tempContentList, function(index, tempContentItem){
    		if ($Gadget.selectedTempContentId == tempContentItem.key) {
    			$Page.operatorInfo.noFillRemark = tempContentItem.value; 
    			$Fire({"popin": ""});
			}
    	});
    	
    },
    
    queryCurrentCityTemplate : function($Gadget){
    	debugger;
    	// 取字典
    	if ($Gadget.currentCity)
    	{
    		$Gadget.selectedTempContentList = [];
    		$.each($Gadget.tempContentList, function(index, tempContentItem){ 
    			if (tempContentItem.key.indexOf($Gadget.currentCity) >= 0) {
    				$Gadget.selectedTempContentList.push(tempContentItem);
				}
    		});
    	}
    	$Fire(
			{
				"popup" :{
					"id" : "addDeviceRecv",
					"title" : "常用免填单备注",
					"width" : "500px",
					"height" : "330px",
					"src" : "resource.root/bes/ad/ctz/gadget/bes-ad-operator/bes-ad-templatecontent.html",
					"resizable" : "false"
				}
			}, $Gadget);
    },
    

          

    // 点击“经办人信息”，展开或者收缩经办人信息输入框
    initShowOrShowSuo : function($Page, $Gadget)
    {
    	if (window.navigator.appName == "Microsoft Internet Explorer")
    	{
    		$Gadget.inputIdOrName = "可根据工号或姓名查询";
    	}
    	
    	$Gadget.currentCity =   $Page.contextForBuriedPoints.beId;
    
        debugger;
        
        
        $Fire({
            service : "/common/dictkey2",
            params : {
                "dictkeylist" : ['AD.PRINTNOTE.TEMPLATE', 'AD.PRINTNOTE.TEMPLATE.CONTENT']
            },
            target : "$Gadget.modelDictionaryList",
            onafter : function($Gadget)    {
                if ($Gadget.modelDictionaryList){
             	   $Gadget.modelList = $Gadget.modelDictionaryList["AD.PRINTNOTE.TEMPLATE"];
             	   $Gadget.tempContentList = $Gadget.modelDictionaryList["AD.PRINTNOTE.TEMPLATE.CONTENT"];
                }
            } 
        }, $Gadget);
        

        // 改造 不同业务需要必填经办人信息不同 页面上不同的必填项使用不同的标志来控制 230437
        // 必填标志-姓名
        $Page.essentialOperatorName = false;
        // 必填标志-联系方式
        $Page.essentialOperatorphoneNumber = false;
        // 必填标志-证件类型
        $Page.essentialOperatorcertificateType = false;
        // 必填标志-证件地址
        $Page.essentialOperatoraddress = false;
        // 必填标志-证件号码
        $Page.essentialOperatorcertificateId = false;
        // 根据业务类型或者特殊标志来区别 00348602 zhaiyanfeng 添加 for zhangchen 公共组保证页面受理成功页面能获取到该值
        // $Page.businessCode = $Gadget.$Attrs.businesscode || '';
        if ($Page.openAccountGroupCretFlag)
        {
            $Page.essentialOperatorName = true;
            $Page.essentialOperatorcertificateType = true;
            $Page.essentialOperatoraddress = true;
            $Page.essentialOperatorcertificateId = true;
        }

        /*if ($Page.besOcForbiddenOperatorFlag)
        {
            $Page.essentialOperatorName = true;
            $Page.essentialOperatorcertificateType = true;
            $Page.essentialOperatorcertificateId = true;
			//$Page.essentialOperatoraddress = true;
        }*/

        $Gadget.$Attrs.approveemptyflag = $Gadget.$Attrs.approveemptyflag === undefined ? true
                : $Gadget.$Attrs.approveemptyflag;

        $Page.approveEmptyFlag = $Gadget.$Attrs.approveemptyflag;


        $Page.operatorInfo = {};
        $Page.operatorInfo.name = '';
        $Page.operatorInfo.enname = '';//英文名称
        $Page.operatorInfo.phoneNumber = '';
        $Page.operatorInfo.certificateType = $Page.operatorInfo.certificateType || 'IdCard';
        $Page.operatorInfo.certificateId = '';
        $Page.operatorInfo.address = '';
        $Page.operatorInfo.noFillRemark = '';
        $Page.operatorInfo.acceptanceRemark = '';
        $Page.operatorInfo.readNewPeopleFlagTemp = "0";
       
        
        if (!$Gadget.$Attrs.approveemptyflag || $Gadget.$Attrs.expandflag)
        {
            $Gadget.operatorInfoShowFlag = true;
        }

        debugger;
        if($Page.attnInfo && $Page.attnInfo.value){
            $Page.operatorInfo.name = $Page.attnInfo.value.custName;
            //添加判断
            $Page.operatorInfo.enname = $Page.attnInfo.value.custNameEN;
            $Page.operatorInfo.phoneNumber = $Page.attnInfo.value.linkPhone;

            //$Gadget.operatorInfo={};
            $Page.operatorInfo.certificateType = $Page.attnInfo.value.idType || 'notuse';
            //this.setDefaultValue($Gadget.operatorInfo.certificateType);

            $Page.operatorInfo.certificateId = $Page.attnInfo.value.idNumber;
            $Page.operatorInfo.address = $Page.attnInfo.value.permanentaddress;
            //$Page.operatorInfo.noFillRemark = $Page.attnInfo.value.name;
            $Page.operatorInfo.acceptanceRemark = $Page.attnInfo.value.note;

        }
        
        // 禁止业务经办人加载完，发送事件来 初始化已保存数据
        $Gadget.$Emit("$bes.oc.operator.inited");
    },
    // 读取证件号码
    readCard : function($Page, kind, multiCardReaderOCX, bossICCardOCX, $UI)
    {
        debugger;
        var certificateType = $Page.operatorInfo.certificateType;
        if ($Page.businessCode == "TransferOwner")
        {
            if ('serv' == kind)
            {
                kind = 'newserv';
            }
            if ('delegate' == kind)
            {
                kind = 'newdelegate';
            }
        }
        var tempiccardInfo = readCardFromOcx(certificateType, kind, multiCardReaderOCX, bossICCardOCX, $UI, $Page);

        // 如果读取出来，则把读取到的内容展示，并赋值给$Gadget.data
        if (tempiccardInfo)
        {
        	//证件未失效
        	//if(tempiccardInfo.endDate > $Page.TimeUtil.nowDate){
        		 $Page.operatorInfo.readNewPeopleFlagTemp = "1";
        		 $("#inputName").val(tempiccardInfo.name);
                 $("#inputCertificateId").val(tempiccardInfo.cardNo);
                 $("#inputAddress").val(tempiccardInfo.address);

                 $Page.operatorInfo.name = tempiccardInfo.name;
                 $Page.operatorInfo.certificateId = tempiccardInfo.cardNo;
                 $Page.operatorInfo.address = tempiccardInfo.address;
                 $Page.operatorInfo.certificateType = tempiccardInfo.certType;
        	//}
        	//else{
        	//	$UI.msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.CEDSFZJYGQSXJYSBQCSYXZJJXBL')); //此二代身份证件已过期失效，校验失败，请出示有效证件进行办理
        	//	return false;
        	//}

        }
    },

    // 若remarkShowFlag为true，则展示免填单备注
    showNoFillRemark : function($Gadget)
    {
        debugger;
        $("#noFillRemarkId").css("display", "block");
    },

    // 置空各个框的内容
    clearOperatorInfo : function($Page)
    {
        debugger;
        $("#inputName").val("");
        $("#inputPhoneNumber").val("");
        $("#stopContinueIDType").data("obj").selectItem('notuse');
        $("#inputCertificateId").val("");
        $("#inputAddress").val("");
        $("#inputNoFillRemark").val("");
        $("#inputAcceptanceRemark").val("");

        $Page.operatorInfo.name = "";
        $Page.operatorInfo.phoneNumber = "";
        $Page.operatorInfo.certificateType = "";
        $Page.operatorInfo.certificateId = "";
        $Page.operatorInfo.address = "";
        $Page.operatorInfo.noFillRemark = "";
        $Page.operatorInfo.acceptanceRemark = "";
    },

    setDefaultValue : function(operatorInfo)
    {
        debugger;
        var certificateType = operatorInfo.certificateType || "notuse";

        if ($("#stopContinueIDType").data("obj"))
        {
            $("#stopContinueIDType").data("obj").selectItem(certificateType);
        }
    },

    // 1、将经办人信息保存到PAGE变量里 2、结算页面点击修改，再次返回到结算页面的时候初始化经办人各个输入框的内容
    initOperatorInfo : function($Gadget, $Page)
    {
        debugger;
        // var dropListCertificateType = $.parseJSON($Gadget.data.CertificateType || "[]") || [];
        // var dropListCertificateType = $Gadget.data.CertificateType.body.dictItems || [];
        // $Page.operatorInfo = {};

        // 移除集团的证件类型
        var dropListCertificateType = [];
        var idTypes = $Gadget.data.CertificateType.body.dictItems || [];
        if (idTypes)
        {
            $.each(idTypes || [], function(i, val)
            {
                if (val.extMap && val.extMap.ext1 == 'person' && 
						"TempId" != val.key && "PLA" != val.key
						&& "PolicePaper" != val.key)
                {
                    dropListCertificateType.push(idTypes[i]);
                }
            });
        }

        var obj = {};
        obj.key = "notuse";
        obj.value = $UEE.i18n("ad.person.option.selectAnOption");
        obj.selected = true;
        dropListCertificateType.unshift(obj);
        // 禁止业务缓存已选的经办人信息
        var hasFlag = false;
        if ($Page.operatorInfo.certificateType)
        {
            $.each(dropListCertificateType || [], function(i, val)
            {
                if (val.key == $Page.operatorInfo.certificateType)
                {
                    val.selected = true;
                    hasFlag = true;
                }

            });
            if (!hasFlag)
            {
                dropListCertificateType[0].selected = true;
            }
        }
        // 若无已选的经办人信息，默认选择证件类型为身份证
        else
        {
            $.each(dropListCertificateType || [], function(i, val)
            {
                if (val.key == "IdCard")
                {
                    $Page.operatorInfo.certificateType = val.key;
                    val.selected = true;
                    hasFlag = true;
                }
            });
            if (!hasFlag)
            {
                dropListCertificateType[0].selected = true;
            }
        }

        $Gadget.certTypeDropList = {
            data : dropListCertificateType,
            onValueChange : function(self)
            {
                debugger;
                $Page.operatorInfo.certificateType = self.$input.attr('key');

                if ($Page.operatorInfo.certificateType == 'notuse')
                {
                    $Page.operatorInfo.certificateType = "";
                }
            },
            selectedKey : $Page.operatorInfo.certificateId
        };
    },
    //lwx473113 $Page值已经变换  但是没有立即生效
    changeIdType : function($Gadget,$UI) {
    	return true;
	},
    //zwx372009 添加  特殊字符校验
    checkSpecialChar : function(value) {
		var keyword = /\`|\~|\!|\@|\#|\$|\%|\^|\+|\&|\/|\||\:|\{|\}|\(|\)|\''|\;|\=|"/;
		if(keyword.test(value))
		{
		    return true;
		}else{
			return false;
		}
	},

	//zwx372009 添加   验证不能为纯数字
	checkNumberChar : function(value) {
		var keyword = /^[0-9]*$/;
		if(keyword.test(value))
		{
		    return true;
		}else{
			return false;
		}
	},

    // 校验经办人姓名的公共方法
    checkOperatorInfoName : function(name, $UI)
    {
        var len = name.len();
        // 1.检查安全性
        if (!adutil.checkInputdata(name))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRBHFFZFQZXSR'));//输入包含非法字符，请重新输入。
            return false;
        }
        
        var minByte = '4';
        /*// 2.检查长度

        if (len > 0)
        {
            // 2.1 太短校验
            if (len < minByte)
            {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTDZS') + parseInt(minByte / 2) + $UEE.i18n('ad.sr.message.GHZH') + minByte + $UEE.i18n('ad.sr.message.GZJ'));//经办人姓名太短。(至少    个汉字或   个字节)
                return false;
            }
            // 2.2太长校验
            if (len > 30)
            {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTCZD10GHZH30GZJ'));//经办人姓名太长。(最多15个汉字或30个字节)
                return false;
            }
        }*/
    	//alert($Page.operatorInfo.certificateType);
		debugger;
		if('Passport' == $Page.operatorInfo.certificateType){
			if (len > 0)
        {
            // 2.1 太短校验
            if (len < 3)
            {
				//alert('护照经办人姓名至少3个字节');
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMZSW3GZFZFCCDXYDY30'));//经办人姓名太短。(至少    个汉字或   个字节)
                return false;
            }
            // 2.2太长校验
            if (len > 30)
            {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTCZD10GHZH30GZJ'));//经办人姓名太长。(最多15个汉字或30个字节)
                return false;
            }
        }

		}else{
			debugger;
			if (len > 0)
        {
            // 2.1 太短校验
            if (len < minByte)
            {
				//alert('除护照外经办人姓名至少4个字节');
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTDZS') + parseInt(minByte / 2) + $UEE.i18n('ad.sr.message.GHZH') + minByte + $UEE.i18n('ad.sr.message.GZJ'));//经办人姓名太短。(至少    个汉字或   个字节)
                return false;
            }
            // 2.2太长校验
            if (len > 30)
            {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTCZD10GHZH30GZJ'));//经办人姓名太长。(最多15个汉字或30个字节)
                return false;
            }
        }
		}
        return true;
    },

    // 校验姓名：1.安全性 2.长度
    checkName : function($Gadget, $Page, $UI)
    {
        debugger;
        var flag = this.checkOperatorInfoName($.trim($("#inputName").val()), $UI);
        return flag;
        
    },

    // 校验经办人电话号码的公共方法
    checkOperatorInfoPhoneNumber : function(phoneNumber, $UI)
    {
        var len = phoneNumber.len();
        // 1.检查安全性
        if (!adutil.checkInputdata(phoneNumber))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRBHFFZFQZXSR'));//输入包含非法字符，请重新输入。
            return false;
        }
        // 2.检查长度
        if (len > 32)
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRZDDCDGCQZXSR'));//输入字段的长度过长，请重新输入。
            return false;
        }
        var reg = /^((0\d{2,3}\d{7,8})|(1[34578]\d{9}))$/;
        if (phoneNumber != '' && !reg.test(phoneNumber))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRLXDHGSBZQQSRSJHMHGHHQH'));//经办人联系电话格式不正确，请输入手机号码或固话（含区号）。

            return false;
        }

        return true;
    },
    // 校验联系方式：1.安全性 2.长度
    checkPhoneNumber : function($Gadget, $UI)
    {
        debugger;
        return this.checkOperatorInfoPhoneNumber($.trim($("#inputPhoneNumber").val()), $UI);

    },
    // 校验证件编号：1.安全性 2.长度
    checkCertificateId : function($Gadget, $Page, $UI)
    {
        debugger;
		if ($Page.operatorInfo.certificateType ==  "PLA" ){
			debugger;
			$UI.msgbox.info("提示", "用户不能新增军官证")
			return false;
		}
    	if ($Page.operatorInfo.certificateType ==  "PolicePaper" ){
			debugger;
			$UI.msgbox.info("提示", "用户不能新增武装警察身份证件")
			return false;
		
    	if ($Gadget.certTypeDropList && $Gadget.certTypeDropList.body && $Gadget.certTypeDropList.body.dictItems) {
			for (var i = 0; i < $Gadget.certificateTypeResp.body.dictItems.length; i++) {
				if ("person" == $Gadget.certificateTypeResp.body.dictItems[i].extMap["ext1"] && 
						"MarryUnkown" != $Gadget.certificateTypeResp.body.dictItems[i].key&& 
						"TempId" != $Gadget.certificateTypeResp.body.dictItems[i].key&& 
						"PLA" != $Gadget.certificateTypeResp.body.dictItems[i].key&& 
						"PolicePaper" != $Gadget.certificateTypeResp.body.dictItems[i].key
						) {
					var obj = {};
					obj.key = $Gadget.certificateTypeResp.body.dictItems[i].key;
					obj.value = $Gadget.certificateTypeResp.body.dictItems[i].value;
					droplist.push(obj);
				}
			}
		}
		$Gadget.attnSelectinfo.credential = droplist;
}
    	
        
        $Page.operatorInfo.certificateId = $.trim($("#inputCertificateId").val());
        var len = $Page.operatorInfo.certificateId.len();
        if (len == 0)
        {
            return true;
        }
        // 1.检查安全性
        if (!adutil.checkInputdata($Page.operatorInfo.certificateId))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRBHFFZFQZXSR'));//输入包含非法字符，请重新输入。
            return false;
        }
        // 2.检查长度
        if (len > 32)
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRZDDCDGCQZXSR'));//输入字段的长度过长，请重新输入。
            return false;
        }
    	if ($Page.operatorInfo.certificateType ==  "SoldierIdCard" && $Page.operatorInfo.certificateId.length != 18 && $Page.operatorInfo.certificateId.length != 15){
			debugger;
			$UI.msgbox.info("提示", "身份证号码必须为18位或15位")
			return false;
		}
    	if($Page.operatorInfo.certificateType ==  "SoldierIdCard"){
//			certificateNum = $Page.operatorInfo.certificateId;
//			return adutil.checkIdCard(certificateNum, $UI);
			if(adutil.checkIdCard($Page.operatorInfo.certificateId, $UI )){
            }else{
                return;
            }
		}
        var type = $Page.operatorInfo.certificateType || "";
        var arr = $Page.data.CertificateTypeValidate || [];
		//添加  by zWX372009
			var certificateNum = $Page.operatorInfo.certificateId;
			if($Page.operatorInfo.certificateType == 'BusinessLicence'){
					var keyword = /^[0-9]*$/;
					debugger;
					if (certificateNum != "") {
						certificateNum = $.trim(certificateNum);
					}
                    if(!keyword.test(certificateNum)){
						$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.person.message.EnterCorrectBusinessLicenseNeedForNumber'));
						//alert("营业执照编号必须为纯数字");
						return false;
					}
					if (certificateNum == 0 || (certificateNum.len() != 13 && certificateNum.len() != 15 && certificateNum.len() != 18
		&& certificateNum.len() != 20 && certificateNum.len() != 22 && certificateNum.len() != 24)) {
						//请输入正确的营业执照编号，长度必须为15或18位字符。
						//alert("请输入正确的营业执照编号，长度必须为13、15、18、20、22或24位字符");
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectBusinessLicenseNumber"));
						return false;
					}
				
					return true;
			}else if($Page.operatorInfo.certificateType ==  "TaiBaoZheng"){
				debugger;
				var certificateNum = $Page.operatorInfo.certificateId;
				if (certificateNum != "") {
					certificateNum = $.trim(certificateNum);
				}
				if (/^\d{7}$/.test(certificateNum)
					||/^\d{8}$/.test(certificateNum)
					|| /^(\d{10})[a-zA-Z0-9]{1,2}$/.test(certificateNum)
					|| /^(TW|LXZH)[A-Z0-9\(\)]+$/.test(certificateNum))
				{
					return true;
				}
				
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
					"请输入正确的台胞证编号，格式为：11,12位时，前10位必须均为数字,最后1-2位为英文字母或阿拉伯数字；或者7位或8位时，均为数字；或前2位“TW”或 “LXZH”字符，后面是阿拉伯数字、英文大写字母与半角“（）”的组合");
				return false;
				} else {
				var flag = adutil.checkCertificateNum($Page.operatorInfo.certificateId || "", type, arr, $UI);
			}
        if (!flag)
        {
            return false;
        }
        return true;
    },
    // 校验经办人地址信息
    checkOperatorInfoAddress : function(address, $UI)
    {
        var len = address.len();
        //空值在上层提交方法中校验，不在此处校验
        if (len == 0)
        {
            return true;
        }
        // 1.检查安全性
        if (!adutil.checkInputdata(address))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRBHFFZFQZXSR'));//输入包含非法字符，请重新输入。

            return false;
        }
        //服务请求校验
        return adutil.checkCustAddress($Page.operatorInfo.certificateType,address,$UI,$UEE.i18n("经办人地址"));
        // // 2.检查长度
        // if (len > 128)
        // {
        //     $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRZDDCDGCQZXSR'));//输入字段的长度过长，请重新输入。
        //     return false;
        // }
        //return true;
    },
    // 校验地址：1.安全性 2.长度
    checkAddress : function($Gadget, $UI)
    {
        debugger;
        $("#inputAddress").val($.trim($("#inputAddress").val()).replace(/\s/g, ""));
        var address = $("#inputAddress").val();
        if (address == undefined || address == "" || address == null)
        {
            return true;
        }
        return this.checkOperatorInfoAddress(address, $UI);

    },
    checkOperatorInfoNoFillRemark : function(noFillRemark, $UI)
    {
        var len = noFillRemark.len();

        // 1.检查安全性
//        if (!adutil.checkInputdata(noFillRemark))
//        {
//            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRBHFFZFQZXSR'));//输入包含非法字符，请重新输入。
//            return false;
//        }
        // 2.检查长度
        if (len > 1024)
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRZDDCDGCQZXSR'));//输入字段的长度过长，请重新输入。
            return false;
        }
        return true;
    },
    // 校验免填单备注：1.安全性 2.长度
    checkNoFillRemark : function($Gadget, $UI)
    {
        debugger;
        return this.checkOperatorInfoNoFillRemark($.trim($("#inputNoFillRemark").val()), $UI);

    },
    checkOperatorInfoAcceptanceRemark : function(acceptanceRemark, $UI)
    {
        var len = acceptanceRemark.len();

        // 1.检查安全性
//        if (!adutil.checkInputdata(acceptanceRemark))
//        {
//            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRBHFFZFQZXSR'));//输入包含非法字符，请重新输入。
//            return false;
//        }
        // 2.检查长度
        if (len > 1024)
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.SRZDDCDGCQZXSR'));//输入字段的长度过长，请重新输入。
            return false;
        }
        return true;
    },
    // 校验受理备注：1.安全性 2.长度
    checkAcceptanceRemark : function($Gadget, $UI)
    {
        debugger;
        return this.checkOperatorInfoAcceptanceRemark($.trim($("#inputAcceptanceRemark").val()), $UI);

    },
    openTabCustManager : function($Gadget, $Fire, $UI, $Page){
        debugger;
        $Fire({
                    "popup" : {
                        "title" : $UEE.i18n("客户经理选择"),
                        "width" : "800px",
                        "height" : "500px",
                        "src" : "resource.root/bes/ad/ctz/gadget/bes-ad-operator/bes-ad-operator-custmanager.html",
                        "resizable" : "false"
                    }
                }, $Gadget);
        this.initCustManager($Gadget, $Fire, $UI, $Page);
        this.queryCustManager($Gadget, $Fire, $UI, $Page);
    },
    initCustManager : function($Gadget, $Fire, $UI, $Page){
        debugger;
        $Gadget.qryEmp = {};
        $Gadget.qryEmp.status = "";
    },
    // 初始化环节列表分页
    initEmpListPageInfo : function($Gadget, $Fire) {
        debugger;
        $("#memberPagesId").text("");
        // 重新创建
        $Gadget.empListPages = new UCD.Pages($("#memberPagesId"),
                $Gadget.empPageInfo.totalRowNum,
                $Gadget.empPageInfo.fetchRowNum, 
                [ $Gadget.empPageInfo.fetchRowNum], 1);
        // 赋值总记录数
        $Gadget.empListPages.setTotal($Gadget.empPageInfo.totalRowNum);
    },
    selectCustManager : function($Gadget, $Fire, $Item, $Page){
        debugger;
            $Page.operatorInfo.CustManager = $Item.employeeCode;
            $Gadget.custManageName = $Item.employeeName;
            $Fire({"popin" : ""});
    },
    // 点击分页
    clickEmpInfoPage : function($Gadget, $Fire, $UI) {
        debugger;
        // 当前页
        setTimeout(function() {
            // 获取作用域
            var $Scope = $(document).scope();
            // 在作用域下使用(解决选中 .pages.getSelection() 下标乱跳)
            $Scope.$safeApply($Scope, function() {
                debugger;
                var curPage = $Gadget.empListPages.getSelection();
                $Gadget.empPageInfo={
                        // 开始行
                        beginRowNum : 10 * (curPage - 1),
                        // 当前选择页
                        curPage : curPage,
                        // 总行数
                        totalRowNum : $Gadget.empPageInfo.totalRowNum,
                        // 每页行数
                        fetchRowNum : 10
                };
                $Gadget.empListNum = $Gadget.empList.slice($Gadget.empPageInfo.beginRowNum, $Gadget.empPageInfo.beginRowNum+10);
            });
        });
    },
    queryCustManager: function($Gadget, $Fire, $UI, $Page){
		debugger;
        var employeePage = {};

		$Fire({
	          service: "com.huawei.bes.sm.base.orgstaff.SMEmployeeBServiceService/queryalluserbypagenation",
	          params: {"params" : $Gadget.qryEmp, 'page' : employeePage},
	          target: "$Gadget.empList",
	          onafter: function($Gadget) {
	        	  debugger;
                  $Gadget.empListBak = [];
	        	  if($Gadget.empList && ($Gadget.empList || []).length > 0){
                    $.each($Gadget.empList,function(index,vali){
                        if (vali.employeeName != null)
                        {
                            $Gadget.empListBak.push(vali);
                        }
                    });
                    $Gadget.empList = $Gadget.empListBak;
                    debugger;
                    $Gadget.empListNum = $Gadget.empList.slice(0,10);
                    $Gadget.empPageInfo = {
                            // 开始行
                            beginRowNum : 0,
                            // 总行数
                            totalRowNum : $Gadget.empList.length || 0,
                            // 每页行数
                            fetchRowNum : 10
                    };
                    $Controller.bes.oc.operator.initEmpListPageInfo($Gadget, $Fire);
                }else{
                    $Gadget.empListNum = 0;
                    $UI.msgbox.info("提示", "未查询到结果");
                }
 
	          }
		},$Gadget);
	},


//添加 by  zwx372009   添加了验证字符串中是否包含空白字符的验证
		checkSpacesChar : function(value) {
		var keyword = /\$|\^|\[|\]|\{|\}|\<|\>|\+|\\|\?|\||\、|\‘|\？|\！|\；|\×|\s|\//;
		if(keyword.test(value))
		{
		    return true;
		}else{
			return false;
		}
	},
	//添加 by  zwx372009
	countCharacters : function(str) {
		var totalCount = 0;
		for ( var i = 0; i < str.length; i++) {
			var c = str.charCodeAt(i);
			if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
				totalCount++;
			} else {
				totalCount += 2;
			}
		}

		return totalCount;
	},
    // 点击结算按钮时校验经办人信息
    checkOperatorInfoBeforeSubmit : function($Page, $UI)
    {
        debugger;
		$Page.operatorInfo = $Page.operatorInfo || {};
        var operatorInfo = $Page.operatorInfo;
        var name = operatorInfo.name || "";
        var phoneNumber = operatorInfo.phoneNumber || "";
        var certificateType = operatorInfo.certificateType || "";
        var certificateId = operatorInfo.certificateId || "";
        var address = operatorInfo.address || "";
        var noFillRemark = operatorInfo.noFillRemark || "";
        var acceptanceRemark = operatorInfo.acceptanceRemark || "";
        
        //添加 by zWX372009
        var isAllEmpty = name.len() || phoneNumber.len() || certificateId.len()
        || address.len();
        if($Page.judge10Or120Flag == undefined){

        } else if (!$Page.judge10Or120Flag)
           {
        	  /* if (!isAllEmpty)
               {
        	// 请输入经办人信息。
                 $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.QSRJBRAGELIMIT"));
                 return false;
               }*/
        	if(name.trim().len()==0 || certificateId.trim().len()==0 || address.trim().len()==0 || certificateType == "" ){
        		 $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.QSRJBRAGELIMIT"));
                 return false;

        	}
            }

		var accountGroup = $Page.cerAgeLess10orMore120 || $Page.openAccountGroupCretFlag;
		 //add by jiangyanqiao(00357255) 2016/08/02
         //如果填写就校验
		//$Page.suspensionFlag主动停机，需要校验经办人信息必填DTS2017113013983
        if ((!isAllEmpty && !accountGroup) && !$Page.suspensionFlag)
        {
        	return true;
        }

        if (!isAllEmpty)
        {
            if (!$Page.approveEmptyFlag)
            {
            	// 请输入经办人信息。
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.QSRJBRXX"));
                return false;
            }
            if ($Page.openAccountGroupCretFlag || $Page.besOcForbiddenOperatorFlag)
            {
            	// 请输入经办人信息。
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.QSRJBRXX"));
                return false;
            }
            $Page.operatorInfoIsEmpty = true;
            return true;
        }
        // modify 230437
        if ($Page.essentialOperatorName && ($Page.operatorInfo.name == null || $Page.operatorInfo.name.trim() == ''))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.KHXMBNWK"));//请输入客户姓名。
            return false;
        }
		//zWX372009
				if($Page.openAccountGroupCretFlag){
					var userName =(adutil.getGadgetObj($(".bes-ad-custinfo")).enrollUserInfoData||{}).userName;
					if($Page.operatorInfo.name == userName){
						//$UI.info('提示','单位地址和使用者姓名不能一致');
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.DWMCHJBRHSYRMCBNXT"));
						//alert('单位地址和经办人姓名不能一致');
                        return false;
					}
				}
        if ($Page.essentialOperatorphoneNumber
                && ($Page.operatorInfo.phoneNumber == null || $Page.operatorInfo.phoneNumber.trim() == ''))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.LXFSBNWK"));//请输入联系方式。
            return false;
        }
        if ($Page.essentialOperatorcertificateType
                && (null == $Page.operatorInfo.certificateType || $Page.operatorInfo.certificateType == ''))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"),  $UEE.i18n("ad.sr.message.QSRZJLX"));//请输入证件类型
            return false;
        }
        if ($Page.essentialOperatoraddress
                && ($Page.operatorInfo.address == null || $Page.operatorInfo.address.trim() == ''))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.LXDZBNWK"));//请输入联系地址
            return false;
        }
        if ($Page.essentialOperatorcertificateId
                && ($Page.operatorInfo.certificateId == null || $Page.operatorInfo.certificateId.trim() == ''))
        {
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.ZJHMBNWK169"));//请输入证件号码
            return false;
        }

    	//添加  by zWX372009
		debugger;
        if(this.checkSpacesChar($Page.operatorInfo.certificateId)){
	        //alert('证件号码中不能有空格');
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ReEnterCertificateNumberIncludeSpaces"));
			return false;
        }
    	//DTS2016101804448  实名制需求中要求军官证、警官证、台胞证、港澳证中姓名只能包含简体字，不能有繁体字，当前实现没有对繁体字进行校验，需要加校验
        if(!adutil.checkCertNameChar($Page.operatorInfo.certificateType,$Page.operatorInfo.name,$UI))
        {
        	return false;
        }
		/*
		//添加  by zWX372009
		debugger;
		var length = this.countCharacters($Page.operatorInfo.name.trim());
		if($Page.operatorInfo.certificateType == 'Passport'){

			if(length > 0){
				if(length< 3){
					//alert('护照经办人姓名至少3个字节');
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMZSW3GZFZFCCDXYDY30'));

					return false;
				}
				if (length > 30)
            {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTCZD10GHZH30GZJ'));//经办人姓名太长。(最多15个汉字或30个字节)
                return false;
            }
			}

		}else{
			if(length > 0){
				debugger;
				if(length< 4){
				if($Page.operatorInfo.name.length< 2){
					//alert('经办人姓名至少4个字节');
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMZSW2GHZH4GZFZFCCDXYDY30'));
					return false;
				}
				if (length > 30)
				{
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.sr.message.JBRXMTCZD10GHZH30GZJ'));//经办人姓名太长。(最多15个汉字或30个字节)
                return false;
            }
			}
		}
		}
        
		//添加  by  zWX372009
		debugger;
		if($Page.operatorInfo.certificateType == 'Passport'){
		     if(this.checkSpecialChar($Page.operatorInfo.name) || this.checkNumberChar($Page.operatorInfo.name)){
			  // alert('姓名不能含有特殊字符或为纯数字');
			   $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SpecialCharactersInUserNameOrcheckNumberChar"));
			   return false;
		     }
        }else if('IdCard'==$Page.operatorInfo.certificateType || 'PLA'==$Page.operatorInfo.certificateType ||
			'PolicePaper'==$Page.operatorInfo.certificateType || 'TaiBaoZheng'==$Page.operatorInfo.certificateType ||'HKMCPassport'==$Page.operatorInfo.certificateType){
			 debugger;
			 var reg = /^([\u4e00-\u9fa5]|\•|\·)*$/;
               if(!reg.test($Page.operatorInfo.name)){
				   $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.person.message.SJJGTZBKHZYD'));
			       //alert('身份证、军官证、警官证、港澳证、台胞证用户姓名只能为汉字与•');
                   return false;
			   }
			}
		//添加  by  zwx372009
		if(this.checkSpecialChar($Page.operatorInfo.name)){
			//alert('姓名不能含有特殊字符');
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SpecialCharactersInUserName"));
			return false;

		}
		*/

        $Page.operatorInfoIsEmpty = false;

        var flag = this.checkOperatorInfoName(name, $UI) && this.checkOperatorInfoPhoneNumber(phoneNumber, $UI)
                && this.checkOperatorInfoAddress(address, $UI);
        flag = flag && this.checkOperatorInfoNoFillRemark(noFillRemark, $UI)
                && this.checkOperatorInfoAcceptanceRemark(acceptanceRemark, $UI);
        if (flag)
        {
            var arr = $Page.data.CertificateTypeValidate || [];
            var flagCertificateId = true;
            if (certificateId)
            {
				if(certificateType == 'BusinessLicence'){
						var keyword = /^[0-9]*$/;
						debugger;
						if (certificateId != "") {
							certificateId = $.trim(certificateId);
						}
						if(!keyword.test(certificateId)){
							$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.person.message.EnterCorrectBusinessLicenseNeedForNumber'));
							//alert("营业执照编号必须为纯数字");
							return false;
						}
						if (certificateId == 0 || (certificateId.len() != 13 && certificateId.len() != 15 && certificateId.len() != 18
							&& certificateId.len() != 20 && certificateId.len() != 22 && certificateId.len() != 24)) {
							//请输入正确的营业执照编号，长度必须为15或18位字符。

							//alert("请输入正确的营业执照编号，长度必须为13、15、18、20、22或24位字符");
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterCorrectBusinessLicenseNumber"));
							return false;
						}

						return true;
				} else if(certificateType ==  "TaiBaoZheng"){
				debugger;
				var certificateNum = certificateId;
				if (certificateNum != "") {
					certificateNum = $.trim(certificateNum);
				}
				if (/^\d{7}$/.test(certificateNum)
					||/^\d{8}$/.test(certificateNum)
					|| /^(\d{10})[a-zA-Z0-9]{1,2}$/.test(certificateNum)
					|| /^(TW|LXZH)[A-Z0-9\(\)]+$/.test(certificateNum))
				{
					return true;
				}
				
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
					"请输入正确的台胞证编号，格式为：11,12位时，前10位必须均为数字,最后1-2位为英文字母或阿拉伯数字；或者7位或8位时，均为数字；或前2位“TW”或 “LXZH”字符，后面是阿拉伯数字、英文大写字母与半角“（）”的组合");
				return false;
				} else {
					flagCertificateId = adutil.checkCertificateNum(certificateId, certificateType, arr, $UI);
				}
            }

            flag = flag && flagCertificateId;
        }

        return flag;
    }
});
