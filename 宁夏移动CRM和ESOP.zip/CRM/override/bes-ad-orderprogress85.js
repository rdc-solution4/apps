$Controller("bes.ad.orderprogress", {
	/* 初始化页面数据 */
	init : function($Gadget, $Fire, $Event) {

		debugger;
		$Gadget.orderLineId = $Event.$Data.orderLineId;
		$Gadget.orderId = $Event.$Data.orderId;
		$Gadget.orderType= $Event.$Data.orderType;
		$Gadget.$Get("$Fire")({
			'service' : '/queryorderboservice/queryfulfillmentorder',
			'params' : {
				"orderid" : $Gadget.orderId,
				"orderLineId" : $Gadget.orderLineId
			},
			'target' : '$Gadget.queryfulfillment',
			onafter : function($Gadget) {

			}
		}, $Gadget);

	},

	processback : function() {
		$("#orderprogress").hide();
		$("#businessaccepted").show();

	},
	queryworkorderlistOpen : function($Gadget, item) {

		debugger;
		$Gadget.fulfillmentOderId = item.fulfillmentOrderId;

		$Gadget.$Emit("$bes.ad.orderprogress.queryworkorderlist", {
			fulfillmentOderId : $Gadget.fulfillmentOderId,
			orderId : $Gadget.orderId
		});

	}
});