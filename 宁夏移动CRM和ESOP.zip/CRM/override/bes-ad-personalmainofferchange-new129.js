$Controller("bes.ad.personalmainofferchange", {
	beforeInit:function($Gadget,$Fire){
		debugger;
		$Gadget.$Attrs.offeringlist = _ysp_top.mainOfferChangeOfferList;
		$Gadget.$Attrs.mainofferinglist = _ysp_top.mainOfferForMainOfferChange;
		$Page.personalInfo = $Page.personalInfo || _ysp_top.personalInfo || {};
		$Page.mainOffer = _ysp_top.mainOfferForMainOfferChange
//		delete _ysp_top.mainOfferChangeOfferList;
//		delete _ysp_top.mainOfferForMainOfferChange;
//		delete _ysp_top.personalInfo;
		$Page.serviceNumber = adutil.getParam2('servicenumber');
		//推荐主套餐信息
		$Page.recommendMainOfferInfo = {};
		$Page.recommendMainOfferInfo.recommendMainOfferId = adutil.getParam2('recommendMainOfferId');
		$Page.recommendMainOfferInfo.recommendMainPacketOfferId = adutil.getParam2('recommendMainPacketOfferId');
		$Page.recommendMainOfferInfo.recommendMainOfferMemberId = adutil.getParam2('recommendMainOfferMemberId');
		$Page.mainprodchangenew = true;
		$Page.haschoosedMainProdFlag = false;

		//预转后，账户组件对外暴露方法， 获取账户信息
		$Gadget.accountmodule = $.noop;
		$Gadget.accountInfo = {};
		$Gadget.validateFunction = [];
		// 将营销活动处理成平铺结构
		$Gadget.isSixOffer=false;
		$Gadget.judgeSixOffer=false;
		$Gadget.judgeOldSixOffer=false;
		var levelList = [];
		$.each($Gadget.$Attrs.offeringlist||[],function(i,val){
			if(val.levelBaseInfo  && val.levelBaseInfo.offeringId){
				val.levelBaseInfo.pOfferingInstId = val.offeringInstId;
				levelList.push(val.levelBaseInfo);
				val.levelBaseInfo = null;
			}
		});
		$Gadget.$Attrs.offeringlist = $Gadget.$Attrs.offeringlist || [];
		$Gadget.$Attrs.offeringlist = $Gadget.$Attrs.offeringlist.concat(levelList);
		$Fire({
			'service' : 'bes.agentdesktop.promotionservice/queryuserrewardactivitys',
			'target' : '$Gadget.RewardActivitys',
			onafter:function(){
				debugger;
				$.each($Gadget.$Attrs.offeringlist||[],function(i,val){
					var isExist = false;
					$.each($Gadget.RewardActivitys||[],function(j,valj){
						if(val.offeringId == valj.offeringId){
							isExist = true;
							return false;
						}
					});
					val.isPromotionOffer = isExist;
				});

				// 去除集团产品
				$Gadget.$Attrs.offeringlist = $.grep($Gadget.$Attrs.offeringlist,function(val,i){
				 // 过滤掉亲情组合 以及活动和档次,过滤
                    return ((val.applyObjType != "X") &&  (val.offeringInstId!=null));
				});

				//$Controller.bes.ad.personalmainofferchange.init($Gadget,$Fire);

				// 调用商品推荐接口.
				$Gadget.$Emit("$bes.recommendoffer");
			}
		},$Gadget);


		// 获取当前oc服务器时间
		$Fire(
				{
					service : "bes.oc.subscribeinfoservice/getadservercurtime",
					target : "$Gadget.ocServerCurTime",
					onafter : function() {
						debugger;
						if (null == $Gadget.ocServerCurTime) {
							$Gadget.ocServerCurTime = new Date();
						} else {
							$Gadget.ocServerCurTime = new Date(
									$Gadget.ocServerCurTime);
						}
						//获取用户信息DTS2016100805420 当天开户的用户做主体产品变更，生效时间是下月生效，应该是立即生效
						$Fire({
							'service': 'bes.oc.subscribeinfoservice/issubscribelogin',
							'params': {},
							'target': '$Gadget.subscriberStatusInfo',
							'onafter': function() {
								debugger;
								$Gadget.subscriberInfo = ($Gadget.subscriberStatusInfo||{}).subscriberInfo;
								var subsDate = new Date($Gadget.subscriberInfo.createTime);
					    		 var curDate = $Gadget.ocServerCurTime;
					    		 if(subsDate.getYear() == curDate.getYear() && subsDate.getMonth() == curDate.getMonth() && subsDate.getDate() == curDate.getDate()){
						    			//查询表数据
					    			 $Fire({
					    				 'service': '/interndistribute/distrbute',
											'params': {

												body: {
													beId : $Page.personalInfo.subsInfo.beId,
												    serviceNumber : $Page.serviceNumber,

												}

											},
											'target': '$Gadget.subInfo',
											'onafter': function() {
												debugger;
												if($Gadget.subInfo && $Gadget.subInfo.distribeList){
													//huangyuyuan add 2016-08-11 初始化数据，该数据用在生效类型上，如果不初始化，可能导致生效类型信息无法显示出来
								    				$Page.selectedMainOfferingIndex = 1;

												}
												else
												{
													 //立即生效
									    			 $Page.selectedMainOfferingIndex = 0;
									    			 $Gadget.immediatelyEffectiveOrExpire = true;
												}

											}
					    			 }, $Gadget);
					    		 }
					    		 else{
					    				//huangyuyuan add 2016-08-11 初始化数据，该数据用在生效类型上，如果不初始化，可能导致生效类型信息无法显示出来
					    				$Page.selectedMainOfferingIndex = 1;

					    		 }
					    			$Gadget.startLoadEff = true;
							}

						}, $Gadget);

					}
				}, $Gadget);

        adutil.querySysParams("QUESTIONNAIRE_FOR_LOWER", $Gadget, function(){
            $Page.questionnaireForLower = $Gadget.sysparamResult["QUESTIONNAIRE_FOR_LOWER"];
        });
	},

	/**
     * 筛选用于主体商品变更的营销商品
     * @param $Page
     */
    filterPromotionOfferForMainChg : function($Page)
    {
        debugger;
        for(var j=0;j<($Page.mainOfferChangeOfferList||[]).length;j++)
        {
            //营销赠送的增值商品
            if($Page.mainOfferChangeOfferList[j].offeringType == '5' &&
                    $Page.mainOfferChangeOfferList[j].offeringSubType &&
                    $Page.mainOfferChangeOfferList[j].offeringSubType.indexOf("RwdGift")>=0)
            {
                $Page.mainOfferChangeOfferList[j].isPromotionOffer = true;
            }
        }

        for(var i=0;i<($Page.PromotionList||[]).length;i++)
        {
            //过滤掉已失效的营销活动
            //var curTime = new Date().getTime();
            var curTime = $Page.TimeUtil.nowDate;
            if($Page.PromotionList[i].expTime != null && $Page.PromotionList[i].expTime < curTime)
            {
                continue;
            }
            var promotionInfo = $.extend(true,{},$Page.PromotionList[i]);
            promotionInfo.isPromotion = true;
            promotionInfo.classLevel = 1;
            $Page.mainOfferChangeOfferList.unshift(promotionInfo);
        }
    },
	offerChangeValidate:function($Page,$Item,$Gadget){
        debugger;
        var offeringId = $Item.offeringId;
        var $mainofferchangeGadget = adutil.getGadgetObj($('.bes-ad-personalmainofferchange-new')) || $Gadget;
        $Controller.bes.ad.personalmainofferchange.preCheck($Page, $mainofferchangeGadget, offeringId, function() {
        	$mainofferchangeGadget.isPersonalUnified = false;
            $Page.selectMainOfferingId = offeringId;
            $Page.choosedMainOffer = $Item;
            $mainofferchangeGadget.$Attrs.offeringid = offeringId;
            //筛选用于主商品变更的营销商品
            $Controller.bes.ad.personalmainofferchange.filterPromotionOfferForMainChg($Page);
            //$Gadget.$Get('$Fire')({targetstep:"personalmainofferchange"});
            $Controller.bes.ad.personalmainofferchange.init($mainofferchangeGadget,$Fire);
        });
    },
    preCheck : function($Page, $Gadget, offeringId, callBack) {
        // 如果商品是亲情组合商品，判断当前号码是否能订购亲情组合商品
        if (this.is4GMainOffer($Page, $Gadget, offeringId)) {
            $Page.personalInfo.subsInfo.usingCustId=$Page.personalInfo.subsInfo.custId;
            $Page.personalInfo.subsInfo.serviceNumber=$Page.personalInfo.subsInfo.servNumber;
            $Page.personalInfo.subsInfo.beId=$Page.personalInfo.subsInfo.city;
            var validateOfferReq = {
                'validationMode' : 'D',
                'scenarioType' : 'P',
                'validationContext' : {
                    'busiType' : 'ChangeProduct',
                    'customer' : {
                        'customerVO' : {
                            'custId' : $Page.personalInfo.subsInfo.custId
                        }
                    },
                    'beId' : _ysp_top.$BES.$ContextAccessor.getBeId()
                },
                'subscriptionInfo' : {
                    'offeringInfo' : [ {
                        'actionType' : 'A',
                        'offeringId' : offeringId
                    } ],
                    'subscriberInfo' : {
                        'beId' : $Page.personalInfo.subsInfo.city,
                        'subsId' : $Page.personalInfo.subsInfo.subsId,
                        'serviceNumber' : $Page.personalInfo.subsInfo.servNumber
                    }
                }
            };

            $Fire(
                {
                    service : "bes.agentdesktop.validateoffering.validateofferingservice/validateofferingsellable",
                    params : {
                        offeringrequest : validateOfferReq
                    },
                    target : "$Gadget.data.checkResp",
                    onafter : function() {
                        debugger;
                        if ($Gadget.data.checkResp
                            && $Gadget.data.checkResp.executeFlag) {
                            callBack();
                        } else {
                            $Gadget.$Get('$UI').msgbox.error($UEE.i18n("ad.person.label.information"),
                                $Gadget.data.checkResp.executeErrMsg);
                        }
                    }
                }, $Gadget);
        } else {
            callBack();
        }
    },
    is4GMainOffer : function($Page, $Gadget, offeringId) {
        var offerIdList = [ 1000100313 ];

        return $.inArray(offeringId, offerIdList) != -1;
    },

	querydict:function($Gadget){
		$Gadget.$Get("$Fire")({
			service : "/common/dictkey",
			params : {
				"dictkeylist" : ['NoPhoneBroadbandOffer']
			},
			target : "$Gadget.NoPhoneBroadbandOffer",
			onafter : function() {
			/*	$Gadget.isSixOffer=false;
				$.each($Gadget.NoPhoneBroadbandOffer.NoPhoneBroadbandOffer||[],function(i,value){
					$.each($Gadget.currentMainOfferingInfo.product||[],function(j,val){
						if(value.itemCode=="prodId"&&value.itemName==val.prodId){
							$Gadget.isSixOffer=true;
						}
					});
				});*/
				$Controller.bes.ad.personalmainofferchange.querysubscriberedoffer($Gadget);
			}
		},$Gadget);
	},
	querysubscriberedoffer:function($Gadget){
		$Gadget.usersubsed=false;
		$Gadget.$Get("$Fire")({
			service :  'personalunifiedviewservice/qryofferinstinfo',
			 params :
			{
				 "servicenumber":$.cookie("besServNum")
			},
			target : "$Gadget.userofferinfos",
			onafter : function () {
				debugger;
				var flag=false;
				$.each($Gadget.userofferinfos||[],function(i,value){
				   $.each($Gadget.NoPhoneBroadbandOffer.NoPhoneBroadbandOffer||[],function(l,v){
						if(v.itemCode=="offeringId"&&v.itemName==value.offeringId){
							$Gadget.usersubsed=true;
							$Gadget.mbofferingid=value.offeringId;
						}
						if(v.itemCode=="prodId"){
							$Gadget.mbprodid=v.itemName;
						}
						if(v.itemCode=="offeringId"){
							$Gadget.mbofferingid=v.itemName;
						}
						if(v.itemCode=="bundle"){
							$Gadget.mbbundleid=v.itemName;
						}
					});
					if(value.primaryFlag=="Y"&&value.status=="2"){
						$Gadget.mainoffersinfo=value;
						$.each(value.productInstInfo||[],function(k,vv){
							if(vv.prodId==$Gadget.mbprodid){
								$Gadget.oldmbprod=vv;
							}
						});
						$Gadget.oldmainofferid=value.offeringId;
						//查询老offer
						$Gadget.$Get("$Fire")(
								{
									service : 'bes.oc.queryofferdetailservice/queryofferdetail',
									params : {
										"offerid" : value.offeringId
									},
									target : '$Gadget.oldofferInfoPOJO',
									onafter : function($Gadget) {
										$Gadget.judgeOldSixOffer=true;
										$Gadget.oldisSixOffer=false;
										$.each($Gadget.oldofferInfoPOJO.ocOfferingAttrPOJO || [],function(i, val){
								            if ("NoPhoneBroadbandOffer" == val.attributeCode){
								            	$Gadget.oldisSixOffer=true;
								            }
								        });
										$Controller.bes.ad.personalmainofferchange.initfor4Gfly($Gadget);
									}
								}, $Gadget);
					}
				});
				$Controller.bes.ad.personalmainofferchange.queryofferdetail($Gadget,$Gadget.$Page);
			}
		},$Gadget);
	},

	initfor4Gfly:function($Gadget){
		debugger;
		//没有判断完成4G的转入转出，不进入逻辑
		if (!$Gadget.judgeOldSixOffer || !$Gadget.judgeSixOffer || !$Gadget.additionalListShowFlag){
			return ;
		}
		$Gadget.judgeOldSixOffer = false;
		$Gadget.judgeSixOffer = false;
		//如果是4G飞享家庭商品化的转出，则进行补充手机代付费宽带包
		if (!$Gadget.isSixOffer && $Gadget.oldisSixOffer){
								            	$Gadget.$Get("$Fire")(
												{
													'service' : 'bes.oc.queryofferdetailservice/queryofferdetail',
													'params' : {
														"offerid" : $Gadget.mbbundleid,
														"condition": {
															"businessCode": "ChangeProduct",
															"mainOfferingId": $Gadget.currentMainOfferingInfo.offeringId,
															"searchOfferTemp": "N",
															"searchProd": "Y"
														}
													},
													'target' : '$Gadget.data.offerInfoPOJO',
													'onafter' : function($Gadget) {
														if(null == $Gadget.data.offerInfoPOJO){
															return;
														}
														var data = [];
														data.push($Gadget.data.offerInfoPOJO);
														$Controller.bes.ad.personalmainofferchange.setAddiProd($Gadget, data);
													}
												},$Gadget);
								            }
		//如果是4G飞享家庭商品化的转入，原来的产品订购了手机代付费宽带包，则进行去除
		if ($Gadget.isSixOffer && !$Gadget.oldisSixOffer){
			$Gadget.hasWiredBrand = false;
			$.each($Gadget.holdOfferingList||[],function(i,vali){
				if(vali.offeringId == $Gadget.mbbundleid)
				{
					$Gadget.hasWiredBrand = true;
					//不再校验密码，界面已经屏蔽
					$.each($Gadget.currentMainOfferingInfo.attributeGroups||[],function(j,valj){
			    		$.each(valj.attributes||[],function(k,valk){
			    			if(valk.attrCode == "password"){
			    				valk.isNullable=true;
			    			}
			    		});
			    	});

					vali.opCode = '3';
					vali.nonheritableFlag = true;
					$.each(vali.subOfferings||[],function(j,valj){
						if(valj.offeringInstId)
						{
							valj.opCode = '3';
						}
					});
					$Gadget.deleteOfferingList.push(vali);
					$Gadget.holdOfferingList.splice(i,1);
					return false;
				}
			});
		}

		//AD_BoardBandComplete保存的是4G飞享家庭商品化套餐的宽带竣工套餐的offeringId
		var boardBandCompleteParamId = "AD_BoardBandComplete";
		$Fire({
		     service : 'ucec/v1/common/qrysystemparambykey',
		     params : {
		         key : boardBandCompleteParamId
		     },
		     target : "$Gadget.boardBandCompleteOfferingId",
		     onafter : function(){
		         debugger;
		         //从4G飞享家庭商品化套餐转成另一个4G飞享家庭商品化，不需要宽带竣工套餐
		         if($Gadget.isSixOffer && $Gadget.oldisSixOffer){
		             $.each($Gadget.additionalOfferingList||[],function(i,vali){
		                 if(vali.offeringId == $Gadget.boardBandCompleteOfferingId){
		                     $Gadget.additionalOfferingList.splice(i,1);
		                 }
		             });
		         }
		         //4G飞享家庭转入,对宽带已装的，需判断当前宽带是否已激活，如已激活，则不能生成竣工套餐
		         if ($Gadget.isSixOffer && !$Gadget.oldisSixOffer && $Gadget.usersubsed == true){
		             $Gadget.$Get("$Fire")({
		                 'service' : 'activewiredsubsboservice/queryinstofferingprod',
		                 'params': {
		                     serialnumber: $Page.serviceNumber
		                 },
		                 'target' : '$Gadget.queryinstofferingprodResp',
		                 'onafter':  function(){
		                     debugger;
		                     var respList = ($Gadget.queryinstofferingprodResp||{}).respList;
		                     if (undefined == respList || null == respList || "" == respList)
		                     {
		                         $.each($Gadget.additionalOfferingList||[],function(i,vali){
		                             if(vali.offeringId == $Gadget.boardBandCompleteOfferingId){
		                                 $Gadget.additionalOfferingList.splice(i,1);
		                             }
		                         });
		                     }
		                 }
		             }, $Gadget);
		         }
		     }
		 }, $Gadget);
	},
	queryofferdetail:function($Gadget,$Page){
		debugger;
		$Gadget.iswiredband="true";
		$Gadget.isSixOffer=false;
		$Gadget.$Get("$Fire")(
				{
					service : 'bes.oc.queryofferdetailservice/queryofferdetail',
					params : {
						"offerid" : $Gadget.$Attrs.offeringid
					},
					target : '$Gadget.offerInfoPOJO',
					onafter : function($Gadget) {
						$Gadget.offerInfoPOJOtemp=$.extend(true,{},$Gadget.offerInfoPOJO);
						$.each($Gadget.offerInfoPOJO.ocProductInfoVA||[],function(i,value){
							$Gadget.judgeSixOffer=true;
							if(value.prodType=='PTWire'){
								$Gadget.judgeSixOffer=false;
								$Gadget.offerInfoPOJO.ocProductInfoVA[0]=value;
								$Gadget.offerInfoPOJO.offerType="OTWiredBand";
								$Gadget.offerInfoPOJO.offerSubType="WBMobileBrand";
								$Gadget.offerInfoPOJO.offeringId=$Gadget.$Attrs.offeringid;
								if($Gadget.usersubsed){
									//查询宽带地址
									$Gadget.$Get("$Fire")({
										service : "/ucec/v1/common/queryCurrMobileBandProperties",
										params : {},
										target : "$Gadget.oldwireinfo",
										onafter : function() {
											debugger;
											$Gadget.hide=true;
											//$Gadget.offerInfoPOJO=$Gadget.oldwireinfo.body.relocationInfo.offeringInfo;
											$Gadget.offerInfoPOJO.wiredProdAttr=$Gadget.offerInfoPOJO.wiredProdAttr||{};
											$Gadget.offerInfoPOJO.wiredProdAttr.thirdAddressInfo={};
											$Gadget.offerInfoPOJO.wiredProdAttr.thirdAddressInfo.usAddr=$Gadget.oldwireinfo.body.relocationInfo.oldAddrInfo.addressName;//$Page.relocationInfo.oldAddrInfo.addressName
											$Gadget.offerInfoPOJO.wiredProdAttr.thirdAddressInfo.thirdDistrictName=$Gadget.oldwireinfo.body.relocationInfo.oldAddrInfo.districtName;//$Page.relocationInfo.oldAddrInfo.addressName
											//$Gadget.offerInfoPOJO.ocOfferingAttrPOJOTemp=$Gadget.oldwireinfo.body.relocationInfo.offeringInfo.ocOfferingAttrPOJO;
											$Gadget.offerInfoPOJO.wiredProdShowFlag={};
											$Gadget.offerInfoPOJO.offerType="OTWiredBand";
											$Gadget.offerInfoPOJO.hideattrs=true;
											$Gadget.offerInfoPOJO.offerSubType="WBMobileBrand";
											$Gadget.iswiredband="false";
											$.each($Gadget.offerInfoPOJO.ocOfferingAttrPOJO || [], function(j, valj){
												if (valj.inputType == 'PASSWORD'){
													$Gadget.offerInfoPOJO.ocOfferingAttrPOJO.splice(j,1);
													return false;
												}
											});
											$.each($Gadget.offerInfoPOJO.ocOfferingAttrPOJO || [], function(j, valj){
												valj.isCoverShow = true;
											});
											$Gadget.offerInfoPOJO.wiredProdShowFlag.newWireOffer=false;
											$Gadget.judgeSixOffer=true;
											$.each($Gadget.offerInfoPOJOtemp.ocOfferingAttrPOJO || [],function(i, val){
												if ("NoPhoneBroadbandOffer" == val.attributeCode){
													$Gadget.isSixOffer=true;
												}
											});
											$Controller.bes.ad.personalmainofferchange.initfor4Gfly($Gadget);
										}
									}, $Gadget);
								}else{
									$Gadget.judgeSixOffer=true;
									$.each($Gadget.offerInfoPOJO.ocOfferingAttrPOJO || [],function(i, val){
										if ("NoPhoneBroadbandOffer" == val.attributeCode){
											$Gadget.isSixOffer=true;
										}
									});
									$Controller.bes.ad.personalmainofferchange.initfor4Gfly($Gadget);
								}
								return false;
							}
						});
						$Controller.bes.ad.personalmainofferchange.initfor4Gfly($Gadget);
					}
				}, $Gadget);
	},
	/**
	 * 构造商品化信息
	 */
	packSpecInfo:function($Gadget,$Page){
		debugger;
		//$Gadget.startLoad = true;
		$Page.validateFunction=$Page.validateFunction||[];
		$Gadget.data=$Gadget.data||{};
		$Page.data=$Page.data||{};
		$Gadget.data.offeringInfo =$Page.data.offeringinfo1||{};//$Gadget.currentMainOfferingInfo;
		$Gadget.data.offeringInfo.offerId=$Gadget.$Attrs.offeringid;
		$Gadget.data.offeringInfo.offeringId=$Gadget.$Attrs.offeringid;
		$Page.data.phonenum=$.cookie("besServNum");


		/*

			$Page.familyisReady = true;
			$Page.familyOffering = $Page.familyOffering || {};
		    $Page.familyOffering.opCode = "1";
			 $Gadget.startLoad = true;
			 $Page.data=$Page.data||{};
                     $Page.data.members = [];
                     $Page.data.memberAuth = {};

                 $Page.data.params = {
                     getOffering: function () {
                             return $Page.familyOffering;
                         },
                         getSubsId: function () {
                             return "";
                         },
                         getServiceNumber: function () {
                             return $.cookie("besServNum");
                         },
                         getBeId: function () {
                             return "";
                         },
                         getProdId: function () {
                             return $Page.familyOffering.prodId;
                         },
                         isHousehold:true,
                         prodType : 'JTVW'
                 };*/



			$Gadget.$Get("$Fire")({
				service : "bes.oc.pcsearchex4telecomqueryservice/queryofferingsetlist",
				params : {
					offerid: $Gadget.$Attrs.offeringid
				},
				target : "$Gadget.queryOfferingSetListResp",
				onafter : function() {},
				onerror: function() {
					debugger;
					//$Gadget.mainOfferingInfoList=$Gadget.queryOfferingSetListResp;
					youCanTouchDataOfWholePage();
				}
			}, $Gadget);

	},
	init : function($Gadget,$Fire) {
		debugger;
		this.onMessageFromPortal();
		this.packSpecInfo($Gadget, $Gadget.$Page);
		// 生效方式显示为下月生效
		var $Page = $(document).scope().$Page;
		$Page.data = $Page.data || {};
		$Page.data.offeringinfo = $Page.data.offeringinfo || {};
		$Page.canModifyAddiOfferEffTime = 'N';
		$Page.haschoosedMainProdFlag = true;//已选择主商品

		$Page.haschoosedMainProdFlag2 = false;
		$Gadget.additionalListShowFlag = false;
		$Gadget.mainOfferList = [];//主套餐的档次为包，展示档次信息，不走变更按钮10.25
		$Gadget.currentMainOfferingInfo = {offeringId:$Gadget.$Attrs.offeringid};
		$Gadget.mainOfferingInfoList = [];
		$Gadget.additionalOfferingList = [];
		$Gadget.deleteOfferingList = [];
		$Gadget.holdOfferingList = [];
		dontTouchDataOfWholePage();
		/*
		 * if(($Gadget.$Attrs.mainofferinglist||[]).length == 1){
		 * $Gadget.srcMainOfferingId =
		 * $Gadget.$Attrs.mainofferinglist[0].offeringId; }
		 */
		$Gadget.srcMainOfferingId = ($Gadget.$Attrs.mainofferinglist||{}).offeringId;
		$Gadget.subscriberAddiOffers = [];
		// 失效的父offer
		var expOfferInstIdList = [];
		$.each($Gadget.$Attrs.offeringlist||[],function(j,valj){
			if(valj.status == '9' || valj.exField4 =='N' ){
				if('Y' == valj.bundleFlag){
					expOfferInstIdList.push(valj.offeringInstId);
				}
			}
		});
		$.each($Gadget.$Attrs.offeringlist||[],function(i,val){
			if(val.status != '9' && val.exField4 !='N'){
				// 针对新已开业务主产品变更数据模型跟统一视图不一致 父节点进行修改
				if(val.parentOfferingInstId){
					val.pOfferingInstId = val.parentOfferingInstId;
				}
				// 如果该Offer的父instId 不在 失效的父offerList中，才加入该offer
				if($.inArray(val.pOfferingInstId, expOfferInstIdList)==-1){
					$Gadget.subscriberAddiOffers.push(val);
				}
			}
		});
		// 删除additionalOfferingList里面新增的商品列表时会同时删除OfferingListForOpenAccount对应offer
		// 开户的前端模型
		$Gadget.OfferingListForOpenAccount = [];

		var offeringId = $Gadget.$Attrs.offeringid;
		// 查询主offer信息
		this.setMainOffer($Gadget, offeringId, $Fire);

		// 查询同组offer信息
		$Fire({
			service : "ucec/v1/offering/querygroupmainoffering",
			params : {
				header : {},
				body : {
					offeringId : offeringId
				}
			},
			target : "$Gadget.offergroupresp",
			onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getNextInitFireId())",
			onafter : function() {
				debugger;
				if(!(($Gadget.offergroupresp||{}).body || {}).offerings){
					// $Gadget.$Get('$UI').msgbox.error("提示", "未查询到此商品详细信息。");
					return false;
				}

				// 添加非空判断
				if($Gadget.offerdetailresp
						&&$Gadget.offerdetailresp.body
						&&$Gadget.offerdetailresp.body.offerings)
				{
					$Gadget.mainOfferingInfoList = $Gadget.offerdetailresp.body.offerings ||[];
				}

				$Gadget.mainOfferingInfoList=$Gadget.mainOfferingInfoList||[];
			}

		}, $Gadget);


		this.queryDefaultMustOfferingList($Gadget,$Fire);

	},

	initCustInfo : function($Page){
		$Page.custInfoModule = {};
		$Page.validateFunction = [];
		$Page.custDepend = {};
	},

	queryInheritOfferingList:function($Gadget,$Fire){
		// 查询pc是否可继承城接口
		$Fire({
			service : "ucec/v1/offering/queryinheritedoffering",
			params : {
				header : {},
				body : {
					srcMainOfferingId : $Gadget.srcMainOfferingId,
					destMainOfferingId: $Gadget.currentMainOfferingInfo.offeringId,
					srcAttachOfferingList: $Gadget.subscriberAddiOffers,
					businessCode : "ChangeProduct"
				}
			},
			target : "$Gadget.offerinheritresp",
			onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getNextInitFireId())",
			onafter : function() {
				debugger;
				youCanTouchDataOfWholePage();
				if(!($Gadget.offerinheritresp||{}).body ){
					$Gadget.deleteOfferingList = [];
					$Gadget.holdOfferingList = [];
				}
				else{
					$Gadget.deleteOfferingList = $Gadget.offerinheritresp.body.nonheritableOfferings ||[];
					$Gadget.holdOfferingList = $Gadget.offerinheritresp.body.inheritableOfferings ||[];

					$.each($Gadget.deleteOfferingList||[],function(i,val){
						val.opCode = '3';
						val.nonheritableFlag = true;
						// 组装删除商品的子商品
						if(val.isBundled)
						{
							$Controller.bes.ad.personalmainofferchange.getInstSubOffer(val,$Gadget);
							$Controller.bes.ad.personalmainofferchange.setOpCodeForSubOffer(val);
						}
					});

					// 新主套餐下必须和可选商品 直接将holdlist中的商品保留 必须列表里面去除此商品 -----  DTS2016101600868 保留已订购的商品
					$.each($Gadget.holdOfferingList||[],function(i,val){
						var delIndex = -1;
						$.each($Gadget.additionalOfferingList||[],function(j,valj){
							if(val.offeringId == valj.offeringId && valj.selectType == 'N'){
								delIndex = j;
								val.nonheritableFlag = true;
								val.isMust = true;
								return false;
							}
						});
						if(delIndex > -1){
							$Gadget.additionalOfferingList.splice(delIndex,1);
							/*if($Gadget.holdOfferingList[delIndex].isBundled)
							{
								$Gadget.holdOfferingList[delIndex].opCode='3';
								// 将已实例化的子offer塞进该offer包
								$Controller.bes.ad.personalmainofferchange.getInstSubOffer($Gadget.holdOfferingList[delIndex],$Gadget);
								$Controller.bes.ad.personalmainofferchange.setOpCodeForSubOffer($Gadget.holdOfferingList[delIndex]);
								// 将包offer塞进删除列表，同时保留增加列表里面的同名offer
								$Gadget.deleteOfferingList.push($Gadget.holdOfferingList[delIndex]);
								$Gadget.holdOfferingList.splice(delIndex,1);
							}*/
						}
					});

					$.each($Gadget.holdOfferingList||[],function(i,val){
						var delIndex = -1;
						var selecttype="T";
						$.each($Gadget.additionalOfferingList||[],function(j,valj){
							if(val.offeringId == valj.offeringId){
								delIndex = j;
								selecttype = valj.selectType;
								return false;
							}
						});

						if(delIndex > -1){
							$Gadget.additionalOfferingList.splice(delIndex,1);
							// 保留offer选中且不可退订
							if(selecttype==="N"){
								val.isMust = true;
							}
						}
						//子商品排序
						if((val.subOfferings || []).length > 0){
							val.subOfferings = adutil.sortsearchofferinglist(val.subOfferings);
						}
					});
				}
				$Gadget.choosedMainOfferHasSubsFlag = false;
				// 筛选营销活动
				$Controller.bes.ad.personalmainofferchange.filterPromotionOffer($Gadget);
				//$Gadget.additionalOfferingList展示在右边关联优惠中，去掉主套餐
				$Controller.bes.ad.personalmainofferchange.changeLineColor($Gadget);

				//初始化4g飞享子offer
				$Controller.bes.ad.personalmainofferchange.initfor4Gfly($Gadget);

				// MODIFY 2015-11-16 by l00289267 start
				$.each($Gadget.additionalOfferingList||[],function(i,val){
					if (val.attributeGroups) {
						//val.hasAttrToShow = false;
						$.each(val.attributeGroups ||[] ,function(k,valk){
							$.each(valk.attributes || [], function(m, valm){
				        		if (!adutil.filterOcPcOfferingAttributeEnable(valm.ocPcOfferingAttributeEnableVA, $Gadget.$Attrs.opertype)) {
				        			valm.showType = 'HIDDEN';
				        		}
				        		/*if (valm.showType != 'HIDDEN') {
				        			val.hasAttrToShow = true;
				        		}*/
				        	});
						});
					}
				});
				for ( var i = 0; i < ($Gadget.additionalOfferingList||[]).length; i++) {
					//档次包展示到左边
					if($Gadget.additionalOfferingList[i].selectType == 'N' || $Gadget.additionalOfferingList[i].isBundled){
						$Gadget.additionalOfferingList[i].checked = true;
						$Gadget.mainOfferList.push($Gadget.additionalOfferingList[i]);
						$Gadget.choosedMainOfferHasSubsFlag = true;
						$Gadget.additionalOfferingList.splice(i,1);
						i--;
					}
				}
				if(($Gadget.additionalOfferingList||[]).length > 0){
					$Gadget.additionalListShowFlag = true;
				}
				if(!$Gadget.choosedMainOfferHasSubsFlag){
					$Gadget.currentMainOfferingInfo.checked = true;
					$Gadget.currentMainOfferingInfo.selectType = 'N';
					$Gadget.mainOfferList = [$Gadget.currentMainOfferingInfo];
				}
                //  US-20180131095359-2031068466 360视图中业务推荐的主套餐变更，需要跳转到变更主套餐，并要求模拟用户自动选择“主商品，商品包，包下子商品”
                if ($Page.recommendMainOfferInfo && $Page.recommendMainOfferInfo.recommendMainOfferMemberId) {
                	debugger;
                	$.each($Gadget.mainOfferList||[],function(i,val){
                		$.each(val.subOfferings ||[],function(j,valj){
							if(valj.offeringId == $Page.recommendMainOfferInfo.recommendMainOfferMemberId){
								$Controller.bes.ad.personalmainofferchange.clickMainSubsCheckbox($Gadget,val,valj);
							}
						});
					});
                }
				// MODIFY 2015-11-16 by l00289267 end
				$Gadget.$RootScope.$apply();
			}

		}, $Gadget);
	},

	// 获取包offer里面已经实例化的子offer
	getInstSubOffer : function(offer,$Gadget)
	{
		debugger;
		$.each($Gadget.$Attrs.offeringlist||[],function(i,val){
			// 新已开父节点实例ID存放在parentOfferingInstId
			if(val.pOfferingInstId == offer.offeringInstId || val.parentOfferingInstId == offer.offeringInstId){
				var subOfferIndex = -1;
				// 判断该offer是否已经存在于子offer列表
				$.each(offer.subOfferings||[],function(j,valj){
					if(valj.offeringId == val.offeringId)
					{
						subOfferIndex = j;
					}
				});
				// 子offer列表没有该offer
				if(subOfferIndex == -1)
				{
					offer.subOfferings = offer.subOfferings || [];
					offer.subOfferings.push(val);
				}
			}
		});
	},

	/**
	 * 筛选营销的offer
	 *
	 * @param $Gadget
	 */
	filterPromotionOffer : function($Gadget)
	{
		// 筛选营销的offer
		var tempDate = new Date($Gadget.ocServerCurTime);
		tempDate.setDate(1);
		tempDate.setMonth(tempDate.getMonth() + 1);
		tempDate.setHours(0);
		tempDate.setMinutes(0);
		tempDate.setSeconds(0);
		tempDate.setMilliseconds(0);

		var effExpDateForCreateOrder;
		if( $Gadget.immediatelyEffectiveOrExpire ){
			effExpDateForCreateOrder= $Gadget.ocServerCurTime.getTime();
		}
		else{
			 effExpDateForCreateOrder = tempDate.getTime();
		}

		for(var i=0;i<($Gadget.deleteOfferingList||[]).length;i++)
		{
			var val = $Gadget.deleteOfferingList[i];
			var index = -1;
			$.each($Gadget.$Attrs.offeringlist||[],function(j,valj){
				if(valj.offeringId==val.offeringId && valj.isPromotion){
					//预付费转后付费业务，所有商品的生失效时间都为立即生效，存在不可继承的营销活动就不能进行业务
					if($Page.isPreToPost)
					{
						var str = $UEE.i18n("ad.person.message.XZSPBNYYXTSDG",[($Gadget.currentMainOfferingInfo||{}).offeringName,valj.offeringName]);
						$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'),str,function(){
							$Controller.bes.ad.personalmainofferchange.cancel($Gadget);
						},null,function(){
							$Controller.bes.ad.personalmainofferchange.cancel($Gadget);
						});
						return;
					}

					// 不可继承的营销活动，但在下月之前失效，可以进行变更
					if((valj.expDate != null && valj.expDate<= effExpDateForCreateOrder)
							|| (valj.expTime != null && valj.expTime <= effExpDateForCreateOrder)
							|| (val.expDate != null && val.expDate<= effExpDateForCreateOrder))
					{
						index = j;
						return false;
					}
					// 不可继承的营销活动，但在下月之后失效，不能进行变更
					else
					{
						// var str =
						// "已参加的"+valj.promotionName+"营销方案"+valj.offeringName+"档次在新主体产品"+($Gadget.currentMainOfferingInfo||{}).offeringName+"下没有发布关系";
						// var str =
						// "已参加的"+valj.offeringName+"营销方案在新主体产品"+($Gadget.currentMainOfferingInfo||{}).offeringName+"下没有发布关系";
						// var str =
						// "新主体产品【"+($Gadget.currentMainOfferingInfo||{}).offeringName+"】不能与已参加的"+valj.offeringName+"营销方案同时订购";
						var str = $UEE.i18n("ad.person.message.XZSPBNYYXTSDG",[($Gadget.currentMainOfferingInfo||{}).offeringName,valj.offeringName]);
						$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'),str,function(){
							$Controller.bes.ad.personalmainofferchange.cancel($Gadget);
						},null,function(){
							$Controller.bes.ad.personalmainofferchange.cancel($Gadget);
						});
					}

					// PM的返回结果中剔除“查询活动订购实例“新接口的订购实例
					if(valj.offeringSubType == 'RwdGift_Prod' || valj.offeringType=='3' || valj.offeringType=='4'){
						index = j;
						return false;
					}
				}

			});
			if(index > -1)
			{
				$Gadget.deleteOfferingList.splice(i,1);
				i--;
			}
		}

		// 走到这里说明即使有营销活动也是可继承或者是下月失效的
		// 此时需要将营销赠送的增值offer从删除列表移除
		for(var i=0;i<($Gadget.holdOfferingList||[]).length;i++)
		{
			var val = $Gadget.holdOfferingList[i];
			var index = -1;
			$.each($Gadget.$Attrs.offeringlist||[],function(j,valj){
				if(valj.offeringId==val.offeringId && (valj.isPromotion || valj.isPromotionOffer)){
					index = j;
					return false;
				}
			});
			if(index > -1)
			{
				/*
				 * $Gadget.holdOfferingList.splice(i,1); i--;
				 */
				$Gadget.holdOfferingList[i].isMust = true;
			}
		}
	},

	/**
	 * 递归设置suboffer的opcode
	 *
	 * @param offer
	 */
	setOpCodeForSubOffer:function(offer)
	{
		debugger;
		if((offer.subOfferings||[]).length>0)
		{
			var subLength = (offer.subOfferings||[]).length;
			for(var i=0;i<subLength;i++)
			{
				if(offer.subOfferings[i].offeringInstId)
				{
					offer.subOfferings[i].opCode = '3';
					$Controller.bes.ad.personalmainofferchange.setOpCodeForSubOffer(offer.subOfferings[i]);
				}
			}
		}
	},

	changeLineColor:function($Gadget)
	{
		debugger;
		$Gadget.linecolor="{even: ($index%2), odd: !($index%2)}";
		if($Gadget.additionalOfferingList.length%2 == 1){
			$Gadget.linecolor1="{even: !($index%2), odd: ($index%2)}";
		}else{
			$Gadget.linecolor1="{even: ($index%2), odd: !($index%2)}";
		}
		if(($Gadget.additionalOfferingList.length+$Gadget.deleteOfferingList.length)%2 == 1){
			$Gadget.linecolor2="{even: !($index%2), odd: ($index%2)}";
		}else{
			$Gadget.linecolor2="{even: ($index%2), odd: !($index%2)}";
		}
	},

	// 查询主体套餐下默认选择和必选套餐
	queryDefaultMustOfferingList:function($Gadget,$Fire){
		$Fire({
			service : "ucec/v1/offering/queryrelatedoffering",
			params : {
				header : {},
				body : {
					offeringId : $Gadget.currentMainOfferingInfo.offeringId,
					businessCode : "ChangeProduct"
				}
			},
			target : "$Gadget.offerDefAndMustresp",
			onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getNextFireId())",
			onafter : function() {
				debugger;
				if(!(($Gadget.offerDefAndMustresp||{}).body || {}).offerings){
					$Gadget.additionalOfferingList = [];
				}
				else{
					$Gadget.additionalOfferingList = $Gadget.additionalOfferingList.concat($Gadget.offerDefAndMustresp.body.offerings ||[]);
					$.each($Gadget.additionalOfferingList||[],function(i,value){
						$.each(value.product||[],function(j,val){
							if(val.prodType=='JTGX'){
								$Gadget.$Page.familyOffering=val;
							}
						});

					});
					$.each($Gadget.additionalOfferingList||[],function(i,val){
						val.opCode = '1';
						if(val.isBundled || val.selectType == 'N'){
							val.checked = true;
							val.hasAttrToShow = true;
							$.each(val.subOfferings ||[],function(j,valj){
								if(valj.selectType == 'M' || valj.selectType == 'D'){
									valj.opCode='1';
									valj.checked = true;
								}
							});
							//子商品排序
							val.subOfferings = adutil.sortsearchofferinglist(val.subOfferings) || val.subOfferings;
						}
					});
					//  US-20180131095359-2031068466 360视图中业务推荐的主套餐变更，需要跳转到变更主套餐，并要求模拟用户自动选择“主商品，商品包，包下子商品”
                    if ($Page.recommendMainOfferInfo && $Page.recommendMainOfferInfo.recommendMainPacketOfferId) {
                    	debugger;
                    	$.each($Gadget.additionalOfferingList||[],function(i,val){
    						if(val.offeringId == $Page.recommendMainOfferInfo.recommendMainPacketOfferId){
    							val.checked = true;
    							val.hasAttrToShow = true;
    						}
    					});
                    }
				}
				$Controller.bes.ad.personalmainofferchange.queryInheritOfferingList($Gadget,$Fire);

			}

		}, $Gadget);
	},

	clickGroupOffer:function($Gadget,$Fire,$Target,$Item,$index){
		debugger;
		if($Item.offeringId == $Gadget.currentMainOfferingInfo.offeringId){
			return;
		}
		$Gadget.mainOfferingInfoList = [];
		$Gadget.currentMainOfferingInfo = $Item;

		if ($Target.siblings().hasClass("selected")) {
			$Target.siblings().removeClass("selected");
		}
		$Target.addClass("selected");

		this.queryDefaultMustOfferingList($Gadget,$Fire,offeringId);
	},
	chooseAddtionalOffer:function($Gadget,$Fire){
		debugger;
		$Gadget.$Attrs.offeringid = $Gadget.currentMainOfferingInfo.offeringId;
		$Gadget.$Emit("$bes.ad.chooseAddtionalOffer",{});
	},
	addiProdInited:function($Gadget){
		debugger;
		$Gadget.$Emit('$bes.oc.addiProdSetDefault',{
			displaySelectedAddiProd: $Gadget.OfferingListForOpenAccount,
			offeringid: $Gadget.currentMainOfferingInfo.offeringId
		});
	},
	cancel:function($Gadget){
		debugger;
		$BES.$Portal.tabpanel.closeTabItem("mainprodchange-new");//关闭tab页
	},

	/**
	 * 过滤重复
	 *
	 * @param offeringList
	 */
	filterSamePkgOffer:function($Gadget)
	{
		for(var i=0;i<$Gadget.addOfferListForVal.length;i++)
		{
			for(var j=0;j<$Gadget.delOfferListForVal.length;j++)
			{
				if($Gadget.addOfferListForVal[i].offeringId == $Gadget.delOfferListForVal[j].offeringId)
				{
					$Gadget.addOfferListForVal[i].opCode = '2';
					$Gadget.addOfferListForVal[i].offeringInstId = $Gadget.delOfferListForVal[j].offeringInstId;
					if($Gadget.addOfferListForVal[i].product != null && $Gadget.addOfferListForVal[i].product[0] != null)
					{
						$Gadget.addOfferListForVal[i].product[0].opCode = '2';
						if($Gadget.addOfferListForVal[i].product[0].prodInstId == null)
						{
							$Gadget.addOfferListForVal[i].product[0].prodInstId = (($Gadget.addOfferListForVal[i].product||[])[0]||{}).prodInstId;
						}
					}

					if(($Gadget.addOfferListForVal[i].subOfferings||[]).length>0)
					{
						$Controller.bes.ad.personalmainofferchange.setSubOfferChange($Gadget.addOfferListForVal[i],$Gadget.delOfferListForVal[j]);
					}
					$Gadget.delOfferListForVal.splice(j,1);
					j--;
				}
			}
		}
	},

	/**
	 * 将增加和删除都有的offer包整合下
	 *
	 * @param addOffer
	 * @param delOffer
	 */
	setSubOfferChange:function(addOffer,delOffer)
	{
		debugger;
		for(var i=0;i<(addOffer.subOfferings||[]).length;i++)
		{
			if(!addOffer.subOfferings[i].checked)
			{
				addOffer.subOfferings.splice(i,1);
				i--;
			}
		}

		for(var i=0;i<(delOffer.subOfferings||[]).length;i++)
		{
			if(!delOffer.subOfferings[i].offeringInstId)
			{
				delOffer.subOfferings.splice(i,1);
				i--;
			}
		}

		for(var j=0;j<(delOffer.subOfferings||[]).length;j++)
		{
			var i = 0;
			for(;i<(addOffer.subOfferings||[]).length;i++)
			{
				if(addOffer.subOfferings[i].offeringId == delOffer.subOfferings[j].offeringId)
				{
					addOffer.subOfferings[i].opCode = '2';
					addOffer.subOfferings[i].offeringInstId = delOffer.subOfferings[j].offeringInstId;
					if(addOffer.subOfferings[i].product != null && addOffer.subOfferings[i].product[0] != null)
					{
						addOffer.subOfferings[i].product[0].opCode = '2';
						if(addOffer.subOfferings[i].product[0].prodInstId == null)
						{
							addOffer.subOfferings[i].product[0].prodInstId = ((delOffer.subOfferings[i].product||[])[0]||{}).prodInstId;
						}
					}
					break;
				}
			}
			if(i==(addOffer.subOfferings||[]).length)
			{
				addOffer.subOfferings.push(delOffer.subOfferings[j]);
			}
		}
	},


	subscribe : function($Gadget, $Page) {
		debugger;
        $Controller.bes.ad.personalmainofferchange.calculatePriceTotal($Gadget);
        window._ysp_top.$Page = window._ysp_top.$Page || {};
        $Page.gradePriceTotal = window._ysp_top.$Page.gradePriceTotal || 0;
        if (!$Gadget.questionnaireSubmitSuc) {
            if ($Page.gradePriceTotal > 0 && $Gadget.goalGradePriceTotal > 0) {
                if ($Page.gradePriceTotal > $Gadget.goalGradePriceTotal) {
                    $Gadget.$Get('$Fire')({
                        "popup" : {
                            'id': 'questionnairePop',
                            'title': "问卷调查",
                            'width': '1100px',
                            'height': '450px',
                            'src':'resource.root/bes/ad/ctz/usl/questionnairePop/questtionnairePop.uslx',
                            'resizable': false
                        }
                    }, $Gadget);
                    return;
                }
            }
        }

		//未选主套餐、主套餐为包时未选子套餐
		if(!$Page.haschoosedMainProdFlag || ($Gadget.choosedMainOfferHasSubsFlag && !$Page.haschoosedMainProdFlag))
			return;
		//循环调用校验函数
		for(var i=0; i<($Page.validateFunction || []).length; i++) {
	    	if(!$Page.validateFunction[i]())
	        {
	            return false;
	        }
	    }

		//预付费转后付费集成了客户的功能
		if($Page.isPreToPost && $Page.needCust){
			$Page.custReq = {};
			$Page.custInfoModule = $Page.custInfoModule || {};
			$Page.custInfoModule.assembleOrderReq = $Page.custInfoModule.assembleOrderReq || $.noop;
			$Page.custInfoModule.assembleOrderReq($Page.custReq);
		}

		var $Fire = $Gadget.$Get('$Fire');
		$Fire(
			{
				service : "bes.oc.subscribeinfoservice/getadservercurtime",
				target : "$Gadget.ocServerCurTime",
				onafter : function() {
					debugger;
					if (null == $Gadget.ocServerCurTime) {
						$Gadget.ocServerCurTime = new Date();
					} else {
						$Gadget.ocServerCurTime = new Date(
								$Gadget.ocServerCurTime);
					}
					$Controller.bes.ad.personalmainofferchange
							.businessProcess($Gadget, $Page);
				}
			}, $Gadget);

	},

	businessProcess:function($Gadget,$Page){
		debugger;

		var offeringList = [];
		$Page.notNeedBackStep = true;
		$Gadget.currentMainOfferingInfo.opCode='1';
		//对offer特殊处理,转入
		if(!$Gadget.oldisSixOffer && $Gadget.isSixOffer){
				$.each($Gadget.currentMainOfferingInfo.attributeGroups||[],function(j,valj){
		    		$.each(valj.attributes||[],function(k,valk){
		    			$.each($Gadget.offerInfoPOJO.ocOfferingAttrPOJO || [], function(m,valm){
		    				if(valm.attributeId == valk.attrId){
		    					valk.newValue = valm.attrKey;
		    				}
		    			});
		    		});
		    	});
				if(!$Gadget.hasWiredBrand){
					$.each($Gadget.currentMainOfferingInfo.product||[], function(i,vali){
						if(vali.isPrimary){
							$Gadget.currentMainOfferingInfo.product.splice(i,1);
							return false;
						}
					});
					$Gadget.currentMainOfferingInfo.wiredProdAttr = $.extend(true, {}, $Gadget.offerInfoPOJO.wiredProdAttr);
				}
				else{
					$Gadget.currentMainOfferingInfo.product = null;
				}
		}
		else{
			$Gadget.currentMainOfferingInfo.product = null;
		}

		// 结算逻辑
		offeringList = offeringList.concat($.extend(true,{},$Gadget.currentMainOfferingInfo));

		//主套餐档次
		var tempMainOffers = $.extend(true,[],$Gadget.mainOfferList);
		for ( var i = 0; i < tempMainOffers.length; i++) {
			tempMainOffers[i].opCode = '1';
			var tempindex = 0;
			if((tempMainOffers[i].subOfferings || []).length > 0 && tempMainOffers[i].choosedSubOffer){
				tempMainOffers[i].choosedSubOffer.opCode = '1';
				tempMainOffers[i].subOfferings = [tempMainOffers[i].choosedSubOffer];
				//DTS2017120802433
				offeringList.push(tempMainOffers[i]);
			}
		}

		// 将删除列表和增加列表里面的相同offer去掉一个，只保留子offer
		$Gadget.addOfferListForVal = $.extend(true,[],$Gadget.additionalOfferingList);
		$Gadget.delOfferListForVal = $.extend(true,[],$Gadget.deleteOfferingList);
		$Controller.bes.ad.personalmainofferchange.filterSamePkgOffer($Gadget);

		if(($Gadget.addOfferListForVal||[]).length > 0 ){
			//选择的关联优惠商品再添加
			for ( var i = 0; i < $Gadget.addOfferListForVal.length; i++) {
				if(($Gadget.addOfferListForVal[i].subOfferings||[]).length > 0){
					//去无效的子offer
					var list = [];
					$.each($Gadget.addOfferListForVal[i].subOfferings||[],function(j,valj){
						if(valj.opCode == '1' || valj.opCode == '2' || valj.opCode == '3'){
							list.push(valj);
						}
					});
					$Gadget.addOfferListForVal[i].subOfferings.length = 0;
					$.extend($Gadget.addOfferListForVal[i].subOfferings,list);
				}
				if($Gadget.addOfferListForVal[i].checked){
					offeringList.push($Gadget.addOfferListForVal[i]);
				}
			}
		}
		if(($Gadget.delOfferListForVal||[]).length > 0){
			offeringList = offeringList.concat($Gadget.delOfferListForVal);
		}

		// 20161201 DTS2016111201170 begin
		$Gadget.holdOfferListForVal = $.extend(true,[],$Gadget.holdOfferingList);
		$.each($Gadget.holdOfferListForVal||[],function(j,val){
			if (val.opCode && val.subOfferings){
				var isValid = false;
				for(var k=0; k <　(val.subOfferings||[]).length; k++){
					if (val.subOfferings[k].opCode){
						isValid = true;
						break;
					}
				}

				if(isValid){
					offeringList = offeringList.concat($.extend(true,{},val));
				}
			}
			if(val.add){
				offeringList.push(val);//添加新选择的增值offer
			}
		});
		// DTS2016111201170 end
		// 营销活动BEGIN
		$Gadget.$Page.promInfoList=$Gadget.$Page.promInfoList||[];


		//swx372006 	DTS2016071401236
		$Gadget.$Page.newPromInfoList = $.extend(true,[],$Gadget.$Page.promInfoList);



		var flagStatus=false;

		// 判断营销方案是否设置
		for(var i=0;i<offeringList.length;i++){

			// 如果是营销方案
			if (offeringList[i].offerClassCode && offeringList[i].offerClassCode.indexOf("PROM_")==0 && offeringList[i].opCode != null)
			{
				var settingStatus=false;

				for(var j=0;j<$Gadget.$Page.promInfoList.length;j++)
				{
					// 进行匹配
					if(offeringList[i].offeringId==$Gadget.$Page.promInfoList[j].offeringId){
						settingStatus=true;
						break;
					}
				}

				// 未设置
				if(!settingStatus)
				{
					flagStatus=true;
					break;
				}
			}


			// swx372006 去除opCode为空的营销活动数据
			for(var j=0;j<$Gadget.$Page.newPromInfoList.length;j++){

				// 进行匹配
				if(offeringList[i].offeringId==$Gadget.$Page.newPromInfoList[j].offeringId&&!$Gadget.$Page.newPromInfoList[j].opCode){
					$Gadget.$Page.newPromInfoList.splice(j,1);
				}
			}



		}

		// 未设置
		if(flagStatus)
		{
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.person.message.SZYXHD'));
			return;
		}

		dontTouchDataOfWholePage();

		// 添加营销活动
		var promotionList=[];
		$.each(offeringList || [], function(i, val){
			// 初始化状态
			var promStatus=false;

			// 循环营销活动列表
			for(var j=0;j<$Gadget.$Page.promInfoList.length;j++){

				// 进行匹配
				if(offeringList[i].offeringId==$Gadget.$Page.promInfoList[j].offeringId){
					promStatus=true;
					break;
				}
			}

			// 存在于列表中营销活动列表
			if(promStatus){
				return;
			}

			// 添加到数组
			promotionList.push(offeringList[i]);

		});

		// 去除营销方案
		offeringList = promotionList;

		// 营销活动END


		// MODIFY 2015-09-13 by l00289267 去掉opCode为空的。
		for (var ii = 0;ii < offeringList.length; ii++) {
			if (!offeringList[ii].opCode) {
				offeringList.splice(ii,1);
				ii--;
			}
		}
		var tempDate =new Date($Gadget.ocServerCurTime);
		tempDate.setDate(1);
		tempDate.setMonth(tempDate.getMonth() + 1);
		tempDate.setHours(0);
		tempDate.setMinutes(0);
		tempDate.setSeconds(0);
		tempDate.setMilliseconds(0);

		var effExpDateForCreateOrder;
		if( $Gadget.immediatelyEffectiveOrExpire ){
			effExpDateForCreateOrder= $Gadget.ocServerCurTime.getTime();
		}
		else{
			 effExpDateForCreateOrder = tempDate.getTime();
		}

		for(var i = 0 ; i < offeringList.length ; i++){
			if(offeringList[i].opCode=='1' || offeringList[i].opCode=='3' || offeringList[i].opCode=='2'){
				if(! $Controller.bes.ad.personalmainofferchange.offeringInfoValidate($Gadget, effExpDateForCreateOrder, offeringList[i])){
					return false;
				}
			}
		}

		// 查看增加列表里面是否有已经存在的营销赠送的增值商品，如果有并且opCode不为1，直接去除
		// 不然需要用户重新选择，防止用户选择了一个和营销赠送的增值商品一样的商品
		var canGoOn = true;
		var falseName = "";
		for(var i=0;i<(offeringList||[]).length;i++)
		{
			if(offeringList[i].isBundled)
			{
				for(var j=0;j<(offeringList[i].subOfferings||[]).length;j++)
				{
					var valj = offeringList[i].subOfferings[j];
					$.each($Gadget.$Attrs.offeringlist||[],function(k,valk){
						if(valk.isPromotionOffer && valk.offeringId == valj.offeringId)
						{
							/*
							 * if(valj.opCode == 3) {
							 * offeringList[i].subOfferings.splice(j,1); j--;
							 * return false; } else
							 */ if(valj.opCode == 1)
							{
								canGoOn = false;
								falseName = valj.offeringName;
							}
						}
					});
				}
			}
			var vali = offeringList[i];
			$.each($Gadget.$Attrs.offeringlist||[],function(k,valk){
				if(valk.isPromotionOffer && valk.offeringId == vali.offeringId)
				{
					/*
					 * if(vali.opCode == 3) { offeringList.splice(i,1); i--;
					 * return false; }else
					 */ if(vali.opCode == 1)
					{
						canGoOn = false;
						falseName = vali.offeringName;
					}
				}
			});
		}
		// 如果选择了和营销赠送的增值商品一样的商品，需要用户重新选择
		if(!canGoOn)
		{
			//
			// $Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'),"已经有营销活动赠送的商品"+falseName+"，请重新选择！");
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'),$UEE.i18n("ad.person.message.YDGYXHDQXZ",[falseName]));
			youCanTouchDataOfWholePage();
			return false;
		}
		if($Gadget.$Attrs.marketflag != "true"){
			// 普通产品变更逻辑
			$Controller.bes.ad.personalmainofferchange.gotocheckout($Page,$Gadget,$Gadget.$Get('$UI'),offeringList);
		}
		else{
			// 营销活动商品化逻辑，只组装，不走结算，发事件将offer列表回传
			$Gadget.$Emit("$bes.personalmainofferchange.assembleOfferListForMarketing",offeringList);
		}
	},

	gotocheckout : function($Page,$Gadget,$UI,offeringList)
	{
		if($Controller.bes.ad.csp.common.isCsp())
		{
			// 先判断操作员是否具有110911令牌 有就不需要进行ivr验证
			$Gadget.$Get('$Fire')({
				service : "/ucec/v1/offering/check_accountinfo_byname",
				params : {
					"header" : null,
					"body" : {
						"chargeInfoName" : "60131001527"
					}
				},
				target : "$Gadget.querypermission",
				onafter : function() {
					debugger;
					if($Gadget.querypermission && $Gadget.querypermission.body && $Gadget.querypermission.body.checkFlag ){
						$Controller.bes.ad.personalmainofferchange.realgotocheckout($Page,$Gadget,$UI,offeringList);
					}else{
						if($Controller.bes.ad.csp.common.ivrCheck($Controller.bes.ad.csp.common.getServNumber(), $Gadget.$Get('$UI')))
						{
							$Controller.bes.ad.personalmainofferchange.realgotocheckout($Page,$Gadget,$UI,offeringList);
						}else{
							return false;
						}
					}
				}
			}, $Gadget);
		}else{
			$Controller.bes.ad.personalmainofferchange.realgotocheckout($Page,$Gadget,$UI,offeringList);
		}
	},

	realgotocheckout : function($Page,$Gadget,$UI,offeringList)
	{
		debugger;

		var tempList = offeringList;

		$Controller.bes.ad.personalmainofferchange.gerateofferingList(tempList);//生产有问题，子offer下有product的没有考虑到，将购物车的逻辑复制过来了
		/*for ( var i = 0; i < offeringList.length; i++) {
			offeringList[i].relaItemId = adutil.getNextNumber();
			if(offeringList[i].subOfferings){
				for ( var j = 0; j < offeringList[i].subOfferings.length; j++) {
					offeringList[i].subOfferings[j].relaItemId = adutil.getNextNumber();
				}
			}
			if(offeringList[i].product){
				for ( var j = 0; j < offeringList[i].product.length; j++) {
					offeringList[i].product[j].opCode = offeringList[i].opCode;
					offeringList[i].product[j].relaItemId = adutil.getNextNumber();
				}
			}
		}*/
		// 家庭产品begin
		var isNeedAddHoldMember = false;
		var familyOfferList = [];
		for(var i=0; i<offeringList.length; i++) {
			var prod = $(document).scope().isFamilyProd(offeringList[i]);
			if(prod) {
				prod.opCode = offeringList[i].opCode;
				prod.refRelaItemId = adutil.getNextNumber();
				prod.relaItemId = adutil.getNextNumber();
				var offerTemp = offeringList[i];
				// var familyOffer =
				// $Controller.bes.ad.shoppingcart.filterOfferings(offerTemp);
				if(!offerTemp.members || offerTemp.members.length==0) {
					isNeedAddHoldMember = true;
				}
				familyOfferList.push(offerTemp);
			}
		}
		for(var i=0; i<familyOfferList.length; i++) {
			var offering = familyOfferList[i];
			offering.refRelaItemId = adutil.getNextNumber();
			offering.relaItemId = adutil.getNextNumber();
			if (offering.isBundled) {
				var subOfferings = offering.subOfferings || [];
				for(var j=0; j<subOfferings.length; j++) {
					subOfferings[j].refRelaItemId = adutil.getNextNumber();
					subOfferings[j].relaItemId = adutil.getNextNumber();
					var product = subOfferings[j].ocProductInfoVA || subOfferings[j].product;
                    product = product || [];
                    if (product && product.length > 0) {
					    product[0].opCode = offering.opCode;
                    }
				}
			}
		}
		tempList = $.grep(tempList,function(val,i){
			return !$(document).scope().isFamilyProd(val);
		});
		// 家庭产品end

		debugger;
		$Fire = $Gadget.$Get('$Fire');
		// var $Page = $(document).scope().$Page;

		// 营销活动begin
		$Page.promInfoList=$Page.promInfoList||[];
		// 保存营销方案列表
		for(var m=0;m<$Page.promInfoList.length;m++){
			for(var n=0; n<tempList.length; n++)
			{
				// 判断产品ID是否相同
				if($Page.promInfoList[m].offeringId==tempList[n].offeringId){
					// 删除营销方案
					tempList.splice(n,1);
					break;
				}
			}
		}
		// 营销活动end

		if(isNeedAddHoldMember)
		{
			// 是否需要增加家庭户主
			$Controller.bes.ad.personalmainofferchange.buildHoldMember($Fire, $Gadget, $Page, $UI, familyOfferList, tempList);
		}
		else
		{
			$Controller.bes.ad.personalmainofferchange.busiValidate($Page,$Fire,$Gadget,$UI,tempList,familyOfferList);
		}
	},
	logicbefore:function($Gadget){
		debugger;
		/**
		 * 老的主offer不是6类商品化商品，判断是否订购手机代付费宽带
		 * 		变更为普通商品 直接走；
		 * 		变更为6类主offer
		 * 				没有，直接订购
		 * 				有，删除
		 * 老的是6类主offer，判断新的是否是六类主offer
		 * 		是，直接订购
		 * 		不是，
		 */
		if(!$Gadget.oldisSixOffer){
			if($Gadget.isSixOffer){

			}
		}else{
			if(!$Gadget.isSixOffer){}
		}
	},
	busiValidate : function($Page,$Fire,$Gadget,$UI,tempList,familyOfferList) {
		debugger;
		//DTS2016052707391 家庭offer的成员信息如果没有生效时间和生效模式，则设置为Offer的生效时间模式
		$.each(familyOfferList||[],function(i,valuei){
		    $.each(valuei.members||[],function(j,valuej){
		        if(!valuej.effDate){
		            valuej.effDate = valuei.effDate;
		        }
		        if(!valuej.effMode && valuei.effectiveWay && valuei.effectiveWay.effectiveTypes && valuei.effectiveWay.effectiveTypes[0]){
		            valuej.effMode = valuei.effectiveWay.effectiveTypes[0].key;
		        }
	        });
        });

		$Page.agentFlag = $Page.agentFlag || "";
		// 成功后提交校验报文
		dontTouchDataOfWholePage();

		if($Page.isnewopenbusiness || $Page.isProdOrder){
			$Fire({
		        service : '/ucec/v1/order/currentorderlist_validate',
		        params:{
		        	header:{},
					body : {
						businessType : $Page.agentFlag,
						offerings : tempList,
						familyOfferings : familyOfferList,
						promotions : $Page.newPromInfoList,
						uniqueFeature : "PersonalMainOfferChange"
					}
		        },
		        target : '$Gadget.validateResult',
		        onbefore : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
		        onafter : function(){
		        	debugger;
		        	youCanTouchDataOfWholePage();
		        	var result = ($Gadget.validateResult||{}).body;
		        	OC.Comm.checkBusiValidResp($Gadget, $UI, result, null, function(){
		        		$Page.serialNo = result.serialNo;
		        		// 新已开不走结算,业务办理不走结算
		        		if($Page.isnewopenbusiness || $Page.isProdOrder)
		        		{
		        			$Controller.bes.ad.personalmainofferchange.mainOfferChangeValidate($Page,$Fire,$Gadget,$UI);
		        			return;
		        		}
		        		// 主体产品变更的时候不使用step方式
		        		$Controller.bes.ad.personalmainofferchange.validateSucess($Gadget,$Page);
		        		// 跳到结算页面引入样式
						 $("<link>").attr({
	 							rel: "stylesheet",
	       					type: "text/css",
	       					href: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/base.css"
	   				 	}).appendTo("head");
		            },
		            function(){
		            	// 按钮恢复
		            	$Controller.bes.ad.shoppingcart.enableBtn('#gotocheckoutfromcar');
		            });
		        }
			},$Gadget);
			return;
		}

		//对offer特殊处理,转入
		if(!$Gadget.oldisSixOffer){
			if($Gadget.isSixOffer){
				if($Gadget.usersubsed){
					var mainofferrelaitemid="";
					$.each(tempList||[],function(i,value){
						if(value.offeringId==$Gadget.$Attrs.offeringid){
							mainofferrelaitemid=value.relaItemId;
						}
					});

					$.each(tempList||[],function(i,value){
						$.each(value.subOfferings||[],function(j,val){
							if(val.offeringId==$Gadget.mbofferingid){
								val.shangpinghua="true";
								val.refRelaItemId=mainofferrelaitemid;
								val.product=null;
							}
						});
					});
				}
			}
		}else{
			//转出，新的offer不是商品化商品
			if(!$Gadget.isSixOffer){
				var subsofferrelaitemid="";
				$.each(tempList||[],function(i,value){
					$.each(value.subOfferings||[],function(j,val){
						if(val.offeringId==$Gadget.mbofferingid){
							subsofferrelaitemid=val.relaItemId;
							val.product=[];
						}
					});
				});
				if(subsofferrelaitemid){
					$Gadget.mainoffersinfo.relaItemId = adutil.getNextNumber();
					$Gadget.mainoffersinfo.product=[];
					$Gadget.mainoffersinfo.opCode="3";
					$.each(tempList||[],function(i,value){
						if(value.isPrimary){
							$Gadget.mainoffersinfo.expDate = value.effDate;
							if((((value.effectiveWay || {}).effectiveTypes || [])[0] || {}).key){
								$Gadget.mainoffersinfo.expirationWay = {
										"expirationTypes":[
										    {
										    	"key": value.effectiveWay.effectiveTypes[0].key
										    }
										]
								};
							}
						}
					});

					if($Gadget.oldmbprod){
						$Gadget.oldmbprod.opCode="T";
						$Gadget.oldmbprod.relaItemId=adutil.getNextNumber();
						$Gadget.oldmbprod.shangpinghua=subsofferrelaitemid;
						$Gadget.oldmbprod.expiryDate = null;
						$Gadget.mainoffersinfo.product.push($Gadget.oldmbprod);
					}
					tempList.push($Gadget.mainoffersinfo);
				}
			}
		}


		$Page.checkoutInfo = {
				businessName: "",
				serviceNumber: $Page.serviceNumber
		};

		$Page.checkoutValidateBody = {
				businessType: "ChangeProduct",
				createOrderReq:{
					order:{
						orderPayment:[]
					}
				},
				mixturePOJO:{
					offerings:tempList,familyOfferings:familyOfferList,promInfoList:$Page.newPromInfoList,
					businessType:$Page.agentFlag
				},
				uniqueFeature: "PersonalMainOfferChange"  // 主产品变更
		};
		//营销工作台跳转营销包，将recommendOid传入后台
		if((($Page.promotionBundle || {}).promotionBundle||{}).recommendOid){
			$Page.checkoutValidateBody.mixturePOJO.recommendOid=$Page.promotionBundle.promotionBundle.recommendOid;
		}

		//预付费转后付费业务
		if($Page.isPreToPost){
			// 客户信息
			if($Page.needCust){
				$Page.checkoutValidateBody.createOrderReq.order.certInfo = (($Page.custReq||{}).order||{}).certInfo;
			}

			$Page.custReq = $Page.custReq || {};
			$Page.custReq.extInfo = $Page.custReq.extInfo || {};
			$Page.custReq.extInfo.registrant = $Page.custReq.extInfo.registrant || {};

			// 账户信息
			var acctInfo = {};
			if ($Gadget.accountInfo.isNewAccount == "Y") {
				// 新账户
				acctInfo = $Gadget.accountmodule.getAccountInfoData();
				//新建账户的账户ID后台随机生成
				//acctInfo.acctId = acctInfo.accountId;
				acctInfo.acctCode = acctInfo.accountCode;
				$Page.custReq.extInfo.registrant.accountInfo = acctInfo;
			} else {
				// 老账户
				acctInfo = $Gadget.accountInfo;
				$Page.custReq.extInfo.accountInfo = acctInfo;
			}

			//如果是新建客户，则将老客户ID传入
			if($Page.custReq.extInfo.registrant.intfCustomerAndIndividualInfo != null || $Page.custReq.extInfo.registrant.accountInfo != null){
				$Page.custReq.extInfo.registrant.custId = (($Page.personalInfo||{}).subsInfo||{}).custId;
				$Page.custReq.extInfo.registrant.isNewCust = "N";
			}

			$Page.checkoutValidateBody.extInfoJson = JSON.stringify(($Page.custReq||{}).extInfo);
		}


		$Fire({
	        service : 'bes.agentdesktop.checkoutboservice/busivalidate',
	        params:{
	        	header:{},
	        	"checkoutbody": $Page.checkoutValidateBody
	        },
	        target : '$Page.checkoutValidateResult',
	        onafter : function(){
	        	debugger;
	        	youCanTouchDataOfWholePage();

	        	if (adutil.checkUcecResp($Page.checkoutValidateResult.header, $UI)) {
					var busiValidCheck = adutil.checkBusiValidResp(null,$UI,$Page.checkoutValidateResult.body.checkOutResp, function(){
						// 点击确认按钮表示继续执行，到结算页面
						debugger;
						// 主体产品变更的时候不使用step方式
		        		$Gadget.$safeApply($Gadget,$Controller.bes.ad.personalmainofferchange.validateSucess($Gadget,$Page));
					});
					if(busiValidCheck){
						debugger;
						// 主体产品变更的时候不使用step方式
		        		$Gadget.$safeApply($Gadget,$Controller.bes.ad.personalmainofferchange.validateSucess($Gadget,$Page));
					}
				}
	        }
		},$Gadget);

	},

	// modify by lwx207718 on 2015-12-22 for DTS2015121802054 begin
	buildHoldMember : function($Fire, $Gadget, $Page, $UI, familyOfferList, tempList) {
		$Fire({
			service : "bes.oc.occustomerservice/queryindividualcustomer",
			target : "$Gadget.customerInfo",
			onafter : function() {
				debugger;
				$Gadget.customerInfo = $Gadget.customerInfo || {};
				var subscribeInfo = $Gadget.customerInfo.subscribeInfo;
				if(!subscribeInfo) {
					$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n("ad.person.message.NoUserInfo"));
					return false;
				}

					$Gadget.payTypeDict = {
						"0" : $UEE.i18n("ad.sr.message.BDF"),
						"1" : $UEE.i18n("ad.sr.message.QEDF"),
						"2" : $UEE.i18n("ad.sr.message.BFDF")
					};
					$Gadget.householdDict = {
						"0" : $UEE.i18n("ad.sr.message.CY"),
						"1" : $UEE.i18n("AD.FAMILY.LABEL.HOLDER")
					};
					$Gadget.memberCodeDict = {
						"JTW" : "4",
						"JTVW" : "0",
						"QQZH" : "4"
					};
					$Gadget.addiMemberDict = {
						"2" : $UEE.i18n("ad.sr.label.FJCY"),
						"1" : $UEE.i18n("ad.sr.message.PTCY")
					};

				$Gadget.$prodNum = 0;
				for(var i=0; i<familyOfferList.length; i++)
				{
					var familyOffer = familyOfferList[i];
					if(!familyOffer.members || familyOffer.members.length==0)
					{
						var prod = $(document).scope().isFamilyProd(familyOffer);
						var subsId = subscribeInfo.subsId;
						$Gadget.$familyOfferIndex = i;
						if (subsId)
						{
							$Controller.bes.ad.personalmainofferchange.queryHomeMember($Gadget,$Fire,prod,subscribeInfo, function (memberTemp, prodIndex)
							{
								  debugger;
								  $Gadget.$prodNum = $Gadget.$prodNum + 1;
								  familyOfferList[prodIndex].members = memberTemp;

								  if (familyOfferList.length == $Gadget.$prodNum)
								  {
										$Controller.bes.ad.personalmainofferchange.busiValidate($Page,$Fire,$Gadget,$UI,tempList,familyOfferList);
								  }
							});
						}
					}
				}


				/*
				 * var member = { "shortNo" : "", "memberType" : {value : "1"},
				 * "groupSubsId" : null, "memberBeId" : subscribeInfo.beId,
				 * "actionType" : "A", "subsId" : subscribeInfo.subsId,
				 * "groupOrderItemId" : "10011002", "serviceNumber" :
				 * subscribeInfo.serviceNumber, "isHousehold" : "1", "beId" :
				 * subscribeInfo.beId };
				 */
				/*
				 * if ($Gadget.$isExecuted) { //succAction(familyOfferList);
				 * $Controller.bes.ad.personalmainofferchange.busiValidate($Page,$Fire,$Gadget,$UI,tempList,familyOfferList); }
				 */
			}
		}, $Gadget);
	},

	queryHomeMember : function ($Gadget,$Fire,prod,subscribeInfo, successAction)
	{
		debugger;

		// 查询此用户已存在生效的家庭产品成员信息
		var groupType = prod.prodType;
		var prodIndex = $Gadget.$familyOfferIndex;
		OC.Callchain.setFireSearch($(document).scope().$Page.pageId, OC.Callchain.getNextInitFireId());
		$Fire({
		    service : "/ucec/v1/family/queryHomeMember",
			params : {
				body : {
					groupType: groupType,
					prodId: prod.prodId,
					memberCode: $Gadget.memberCodeDict[groupType],
					subsId: subscribeInfo.subsId
				}
			},
		    target : '$Gadget.familyMember',
		    onafter : function($Gadget, $Fire) {
		    	debugger;
		    	var body = $Gadget.familyMember.body || {};
		    	var members = body.members || [];
		    	var familyGroup = body.familyGroupInfo||{};
		    	$Gadget.$subscribeInfo = subscribeInfo;
		    	if(members.length > 0) {
		    		$.each(members, function(i, member){
		    			member.additionalMember = member.additionalMember || 1;
		    			member.additionalMemberValue = $Gadget.addiMemberDict[member.additionalMember];
		    			member.isHouseholdValue = $Gadget.householdDict[member.isHousehold];
		    			member.statusDetail = member.status.value;
		    			member.memberServiceNumberAnonymous = $Controller.bes.ad.family.common.anonymousStr(member.serviceNumber,"mobile");
		    			var attributes = member.attributes || [];
		    			$.each(attributes, function(j, attribute){
			    			if(attribute.attrCode == "fmyPayType") {
			    				member.payTypeValue = $Gadget.payTypeDict[attribute.newValue];
			    				return false;
			    			}
			    		});
		    		});

		    		var memberTemp = $.extend(true, [], members);

			    	if (typeof successAction === 'function')
					{
						successAction(memberTemp, prodIndex);
					}
		    	}
		    	else
		    	{
		    		// 添加户主信息
		    		$Controller.bes.ad.personalmainofferchange.queryHouseholdmember($Gadget, $Fire, groupType, familyGroup, prodIndex, successAction);
		    	}
		    }
		},$Gadget);
	},

	// 添加户主信息
	queryHouseholdmember : function ($Gadget, $Fire, groupType, familyGroup, prodIndex, successAction)
	{
		debugger;
		var subscribeInfoTemp = $Gadget.$subscribeInfo;
		OC.Callchain.setFireSearch($(document).scope().$Page.pageId, OC.Callchain.getNextInitFireId());
		$Fire({
			service : "bes.oc.homebusinessmemberservice/addmember",
			params : {productid:null,servnumber: subscribeInfoTemp.serviceNumber},
			target : "$Gadget.houseHoldInfo",
			onafter : function (){
				debugger;
				var firstName = $Gadget.houseHoldInfo.custInfo.IndividualExVO.firstName || "";
				var middleName = $Gadget.houseHoldInfo.custInfo.IndividualExVO.middleName || "";
				var lastName = $Gadget.houseHoldInfo.custInfo.IndividualExVO.lastName || "";
				var name = firstName + middleName + lastName;
				var member = {
					"serviceNumber" : subscribeInfoTemp.serviceNumber,
					"memberServiceNumberAnonymous" : subscribeInfoTemp.serviceNumber,
					"effDate" : null,
					"expDate" : null,
					"isHousehold" : "1",   // 户主
					"isHouseholdValue" : "户主",
					"status":null,
					"statusDetail" : null,
					"region" : null,
					"memberName" : name,
					"memberType": {"value":"1"},   // 户主
					"memberBeId":null,
					"groupOrderItemId": "10011002",    // 目前写死
					"payType":null,    // 页面取到
					"payTypeValue": null,
					"actionType":"A",
					"subsId" :null,
					"doubleConfirm":false,
					"additionalMember" : 1,
					"additionalMemberValue" : $UEE.i18n("ad.sr.message.PTCY")
				};
				member.region = $Gadget.houseHoldInfo.custInfo.IndividualExVO.regionCode;
				member.memberBeId = subscribeInfoTemp.beId;
				member.effDate = familyGroup.expDate;
				member.subsId = subscribeInfoTemp.subsId;
				if(groupType == "JTVW") {
					member.shortNo = "760";
				}
				var memberTemp = [member];
		    	if (typeof successAction === 'function')
				{
					successAction(memberTemp, prodIndex);
				}
			}
		},$Gadget);
	},
	// modify by lwx207718 on 2015-12-22 for DTS2015121802054 end

	/**
	 * 不走结算页面时直接调用算费
	 */
	mainOfferChangeValidate : function($Page,$Fire,$Gadget,$UI)
	{
		debugger;
		dontTouchDataOfWholePage();
		$Fire({
			service : '/ucec/v1/order/order_calcfee',
			params : {
				header : null,
				body : {
					serialNo : $Page.serialNo
				}
			},
			target : '$Gadget.calcFeeResult',
			onbefore : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
			onafter : function($Page,$Gadget) {
				debugger;
				youCanTouchDataOfWholePage();
				if($Gadget.calcFeeResult.body.totalAmount > 0)
				{
					$UI.msgbox.error($UEE.i18n('ad.person.message.information'), $UEE.i18n("ad.person.message.NotUnavailable"));
					// 按钮恢复
	            	$Controller.bes.ad.shoppingcart.enableBtn('#personalmainofferchangesubscribe');
				}else
				{
					$Controller.bes.ad.personalmainofferchange.mainOfferChangeOrderCreate($Page,$Fire,$Gadget,$UI);
				}
			}
		}, $Gadget);
	},

	/**
	 * 不走结算页面直接调用创建订单
	 */
	mainOfferChangeOrderCreate : function($Page,$Fire,$Gadget,$UI)
	{
		debugger;
		dontTouchDataOfWholePage();
    	$Fire({
    		service : '/ucec/v1/order/order_submit',
    		params : {
			      "header" : {},
		      "body" : {
				  "serialNo" : $Page.serialNo
		      }
    		},
    		target : '$Page.order_resp',
    		onbefore : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
    		onafter : function($Page){
    			debugger;
    			youCanTouchDataOfWholePage();

    			if($Page.isProdOrder)
    			{
    				$Fire({targetstep:'index'});
	    			$("#productOrderForNewOpen").hide();
					// 删除旧的base.css
					$("link[href$='ordercapture/css/base.css']").remove();
					$("link[href$='ordercapture/css/style.css']").remove();
    			}
    			else if($Page.isnewopenbusiness)
    			{
    				$Fire({targetstep:'service'});
    			}

    			$Page.paymentFinishStepFlag = true;

    			$("<link>").attr({
		            rel : "stylesheet",
		            type : "text/css",
		            href : window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/checkoutFinish.css"
		        }).appendTo("head");
    		}
    	},$Gadget);
	},

	offeringInfoValidate:function($Gadget, effExpDateForCreateOrder, offeringinfo){
		// 子offer附加属性设置
	    var validateSucess = true;
	    if(offeringinfo.opCode == '1' || offeringinfo.opCode == '2') {
	    	if(offeringinfo.isBundled) {
				// MODIFY 2015-10-05 by l00289267 DTS2015092808976 start
				// 校验子offer数量。
				if (offeringinfo.bundledType && offeringinfo.bundledType == "3") {
					var num = 0;
					var minus = 0;
					$.each(offeringinfo.subOfferings||[],function(i,val){
						if(val.checked && (val.opCode == '1' || val.opCode == '2')){
							num = num + 1;
						}

						// 此种场景是不点击已选，并且只添加一个的情况
						if(val.checked && !val.opCode && val.offeringInstId){
							num = num + 1;
						}

						if(val.opCode == '3' && val.offeringInstId){
							minus = minus + 1;
						}
					});

					var maxNum = offeringinfo.maxNumber;
				    var minNum = offeringinfo.minNumber;
				    if(null != maxNum && minNum!=null){
				    	// modify by wuyuxin/wwx175926 for DTS2015102400089
				    	if(num < minNum || (num == 0 && minus > 1)){
							// $Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'),
							// "请最少订购商品包：" + offeringinfo.offeringName + "的" +
							// minNum + "个商品。");
							$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"),
			                        $UEE.i18n("ad.person.message.SubscribeLeastSubofferings",[offeringinfo.offeringName,""+minNum]));
							youCanTouchDataOfWholePage();
							return false;
						}
				    	else if(num>maxNum){
							// $Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'),
							// "请最多订购商品包：" + offeringinfo.offeringName + "的" +
							// maxNum + "个商品。");
							$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"),
			                        $UEE.i18n("ad.person.message.SubscribeMostSubofferings",[offeringinfo.offeringName,""+maxNum]));
							youCanTouchDataOfWholePage();
							return false;
						}
					}
				}
				// MODIFY 2015-10-05 by l00289267 DTS2015092808976 end
				// 价值校验
			    if(offeringinfo.bundledType && offeringinfo.bundledType == "4") {
			    	var value = 0;
				    $.each(offeringinfo.subOfferings || [], function(i, val) {
					    if(val.checked && (val.opCode == '1' || val.opCode == '2')) {
					    	value = value + val.memberValue;
					    }
				    });

				    var maxNum = offeringinfo.maxNumber;
				    var minNum = offeringinfo.minNumber;
				    if(null != maxNum && minNum != null) {
					    if(value > maxNum || value < minNum) {
						    // $Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'),
							// "选择商品包" + "[" + offeringinfo.offeringName +"]"
						    // + "内子商品累计价值不在规定范围内[最大值：" + maxNum + ", 最小值：" +
							// minNum + "]。");
					        $Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"),
			                        $UEE.i18n("ad.person.message.AccumulatedValueOutOfRange",[offeringinfo.offeringName,maxNum+"",minNum+""]));
						    youCanTouchDataOfWholePage();
						    return false;
					    }
				    }
			    }
			}
	    	// 没有使用生效模板就设定为下月生效
	    	offeringinfo.expDate = null;
	    	if(!offeringinfo.effectiveWay)
	    	{
	    		// MODIFY 2015-11-21 by l00289267 modify reason:
				// 主体产品变更前后的必选包，包的生效时间不变
	    		// 如果opCode为2 且为商品包，则生效时间保持不变。
	    		if (offeringinfo.opCode == '1' || !offeringinfo.isBundled) {
	    			//预付费转后付费业务，所有商品都是立即生效和立即失效
	    			if($Page.isPreToPost){
	    				offeringinfo.effectiveWay = offeringinfo.effectiveWay || {};
	    				offeringinfo.effectiveWay.effectiveTypes = offeringinfo.effectiveWay.effectiveTypes || [];
	    				offeringinfo.effectiveWay.effectiveTypes.push({"key":"I","selected":true});
	    				offeringinfo.effectiveWay.selectedMode = "I";
	    			}else{
	    				offeringinfo.effDate = effExpDateForCreateOrder;
	    			}
	    		}
	    	}

	    	$.each(offeringinfo.attributeGroups||[],function(j,valj){
	    		$.each(valj.attributes||[],function(k,valk){
	    			if(!valk.isNullable && (valk.newValue=='' || null == valk.newValue)){
	    				validateSucess = false;
	    				// $Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'),
						// "请先设置"+offeringinfo.offeringName);
	    				$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"),
	                            $UEE.i18n("ad.person.message.SetFirst",[offeringinfo.offeringName]));
	    				youCanTouchDataOfWholePage();
	    				return false;
	    			}
	    		});
	    	});

	    	// 子offer
	    	 $.each(offeringinfo.subOfferings || [], function(i, val) {
				    if(val.checked && val.opCode == '1') {
				    	var subOfferExpDate = val.expDate;
				    	val.expDate = null;
				    	if(!val.effectiveWay)
				    	{
				    		//预付费转后付费业务，所有商品都是立即生效和立即失效
				    		if($Page.isPreToPost){
				    			val.effectiveWay = val.effectiveWay || {};
				    			val.effectiveWay.effectiveTypes = val.effectiveWay.effectiveTypes || [];
				    			val.effectiveWay.effectiveTypes.push({"key":"I","selected":true});
				    			val.effectiveWay.selectedMode = "I";
			    			}else{
			    				val.effDate = effExpDateForCreateOrder;
			    			}
				    	}
				    	$.each(val.attributeGroups||[],function(j,valj){
				    		$.each(valj.attributes||[],function(k,valk){
				    			if(!valk.isNullable && (valk.newValue=='' || null == valk.newValue)){
				    				validateSucess = false;
				    				// $Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'),
									// "请先设置"+val.offeringName);
				    				$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"),
			                                $UEE.i18n("ad.person.message.SetFirst",[val.offeringName]));
				    				youCanTouchDataOfWholePage();
				    				return false;
				    			}
				    		});
				    	});
				    }else if(val.opCode == '3'){
				    	//预付费转后付费业务，所有商品都是立即生效和立即失效
				    	if($Page.isPreToPost){
			    			val.expirationWay = val.expirationWay || {};
			    			val.expirationWay.expirationTypes = val.expirationWay.expirationTypes || [];
			    			val.expirationWay.expirationTypes.push({"key":"I","selected":true});
			    			val.expirationWay.selectedMode = "I";
		    			}else{
		    				if (subOfferExpDate != undefined && subOfferExpDate != null && subOfferExpDate != "" && subOfferExpDate <= effExpDateForCreateOrder){
		    					val.expDate = subOfferExpDate;
		    				}
		    				else {
		    					val.expDate = effExpDateForCreateOrder;
		    				}
		    			}
				    }
			    });


	    }else if(offeringinfo.opCode == '3'){
	    	offeringinfo.effDate = null;
	    	var offerExpDate = offeringinfo.expDate;
	    	//预付费转后付费业务，所有商品都是立即生效和立即失效
	    	if($Page.isPreToPost){
	    		offeringinfo.expirationWay = offeringinfo.expirationWay || {};
	    		offeringinfo.expirationWay.expirationTypes = offeringinfo.expirationWay.expirationTypes || [];
	    		offeringinfo.expirationWay.expirationTypes.push({"key":"I","selected":true});
	    		offeringinfo.expirationWay.selectedMode = "I";
			}else{
				if (offerExpDate != undefined && offerExpDate != null && offerExpDate != "" && offerExpDate <= effExpDateForCreateOrder){
					offeringinfo.expDate = offerExpDate;
				}
				else {
					offeringinfo.expDate = effExpDateForCreateOrder;
				}
			}
	    }

	    // 生效方式设置校验
	    $Controller.bes.ad.personalmainofferchange.effectiveWayValidate(offeringinfo,$Gadget.$Get('$UI'));
	    if(offeringinfo.isBundled)
	    {
	    	$.each(offeringinfo.subOfferings || [], function(i, val) {
	    		if(val.opCode == "1")
	    		{
	    			$Controller.bes.ad.personalmainofferchange.effectiveWayValidate(val,$Gadget.$Get('$UI'));
	    		}
	    	});
	    }

	    if(!validateSucess){
	    	return false;
	    }
		return true;
	},

	effectiveWayValidate : function(offeringinfo,$UI){

		if(offeringinfo.effectiveWay)
		{
			for(var j=0;j<offeringinfo.effectiveWay.effectiveTypes.length;j++)
			{
				if(offeringinfo.effectiveWay.effectiveTypes[j].key != offeringinfo.effectiveWay.selectedMode)
				{
					offeringinfo.effectiveWay.effectiveTypes.splice(j,1);
					j--;
				}
			}

			offeringinfo.effectiveWay.selectedKey = offeringinfo.effectiveWay.selectedMode;

			if(!offeringinfo.effectiveWay.effectiveTypes[0] || !offeringinfo.effectiveWay.effectiveTypes[0].key)
			{
				$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.sr.message.QXZSXFS'));
				return false;
			}
			else if(offeringinfo.effectiveWay.effectiveTypes[0].key == "S")
			{
				if(!offeringinfo.effectiveWay.durationValue){
					$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.sr.message.QSRZQZ'));
					return false;
				}
				else if(!RegExp("^[0-9]*$").test(offeringinfo.effectiveWay.durationValue)
						|| offeringinfo.effectiveWay.durationValue > 999
						|| offeringinfo.effectiveWay.durationValue < 1){
					$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.group.message.enterPeriodValueOf1-999'));
					return false;
				}
			}
			else if(offeringinfo.effectiveWay.effectiveTypes[0].key == "C")
			{
				if(!offeringinfo.effectiveWay.effectiveDate || (new Date(offeringinfo.effectiveWay.effectiveDate).Format("yyMMddhhmmss") < new Date().Format("yyMMddhhmmss"))){
					$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.shoppingcart.message.selectcurrentnotlesseffect'));
					return false;
				}
			}
		}
		return true;
	},

	setattrpop:function($Gadget,offer,subOfferFlag){
		debugger;
		$Gadget.data = $Gadget.data||{};
		// $Gadget.data.offeringinfo
		$Gadget.data.offeringId = offer.offeringId;

		if(subOfferFlag =='N'){
			$.each($Gadget.additionalOfferingList||[],function(i,val){
				if(val.offeringId == offer.offeringId){
					$Gadget.data.offeringinfo =  val;
					return false;
				}
			});
		}

		else{

			$.each($Gadget.additionalOfferingList||[],function(i,val){
				if(val.isBundled){
					$.each(val.subOfferings||[],function(j,valj){
						if(valj.offeringId == offer.offeringId){
							$Gadget.data.offeringinfo =  val;
							return false;
						}
					});
				}
			});
		}


		if($Page.isnewopenbusiness)
		{
			$Gadget.attrPopPath = 'resource.root/bes/ad/popup/bes-ad-mainofferattrprop.html';
		}
		else
		{
			$Gadget.attrPopPath = 'resource.root/bes/ad/popup/bes-ad-mainofferattrprop.html';
		}
		$Gadget.$Get('$Fire')({popup:"{'id': 'attrpop', 'title': $UEE.i18n('ad.person.message.ChangeOfferingAttr'), 'width': '1100px', 'height': '450px'," +
		    "'src':'{{$Gadget.attrPopPath}}', 'resizable': false}"}, $Gadget);
	},

	setSubOffer:function($Gadget,$index){
		debugger;
		$Gadget.data = $Gadget.data||{};
		$Gadget.data.offeringinfo = $Gadget.additionalOfferingList[$index];
		$Gadget.data.offeringId = $Gadget.data.offeringinfo.offeringId;
		$Gadget.is4GFamilyTransOut = false;
		if (!$Gadget.isSixOffer && $Gadget.oldisSixOffer && $Gadget.data.offeringId == $Gadget.mbbundleid){
		    $Gadget.is4GFamilyTransOut = true;
		}
		/*if($Page.mainprodchangenew )
			return;*/
		if($Page.isnewopenbusiness)
		{
			$Gadget.subOfferPath = 'resource.root/bes/ad/popup/bes-ad-mainoffersubofferchange.html';
		}
		else
		{
			$Gadget.subOfferPath = 'resource.root/bes/ad/popup/bes-ad-mainoffersubofferchange.html';
		}
		$Gadget.$Get('$Fire')({popup:"{'id': 'subofferpop', 'title': $UEE.i18n('AD.FAMILY.LABEL.CHG_PROD_PAK'), 'width': '1100px', 'height': '450px'," +
		    "'src':'{{$Gadget.subOfferPath}}', 'resizable': false}"}, $Gadget);
	},

	setHoldSubOffer : function($Gadget,$Offer){
		debugger;
		// 20161201 将需要做变更的保持offer设置标志 DTS2016111201170 begin
		$.each($Gadget.holdOfferingList||[],function(j,val){
			if (val.offeringId == $Offer.offeringId){
				val.opCode = "2";
			}
		});
		$Gadget.selectonlyone = true;
		// DTS2016111201170 end

		$Gadget.data = $Gadget.data||{};
		$Gadget.data.offeringinfo = $Offer;
		$Gadget.data.offeringId = $Gadget.data.offeringinfo.offeringId;
		$Gadget.is4GFamilyTransOut = false;
		if (!$Gadget.isSixOffer && $Gadget.oldisSixOffer && $Gadget.data.offeringId == $Gadget.mbbundleid){
		    $Gadget.is4GFamilyTransOut = true;
		}
		if($Page.isnewopenbusiness)
		{
			$Gadget.subOfferPath = 'resource.root/bes/ad/popup/bes-ad-mainoffersubofferchange.html';
		}
		else
		{
			$Gadget.subOfferPath = 'resource.root/bes/ad/popup/bes-ad-mainoffersubofferchange.html';
		}
		$Gadget.$Get('$Fire')({popup:"{'id': 'subofferpop', 'title': $UEE.i18n('AD.FAMILY.LABEL.CHG_PROD_PAK'), 'width': '1100px', 'height': '450px'," +
		    "'src':'{{$Gadget.subOfferPath}}', 'resizable': false}"}, $Gadget);
	},

	setAddiProd:function($Gadget, $Data){
		debugger;
		$Gadget.OfferingListForOpenAccount = $Data;
		$Gadget.OfferingListForSetOfferName = [];
		var tempList = [];

		// 将取消的offer删除
		for(var i=0;i<($Gadget.holdOfferingList||[]).length;i++)
		{
			if($Gadget.holdOfferingList[i].add)
			{
				for(var j=0;j<($Gadget.OfferingListForOpenAccount||[]).length;j++)
				{
					if($Gadget.holdOfferingList[i].offeringId == $Gadget.OfferingListForOpenAccount[j].offerId)
					{
						break;
					}
				}
				if(j==($Gadget.OfferingListForOpenAccount||[]).length)
				{
					$Gadget.holdOfferingList.splice(i,1);
					i--;
				}
			}
		}

		// 定义下标
		var index=null;

		// 查询新增
		$.each($Gadget.OfferingListForOpenAccount||[],function(i,val){

			if(!val.offeringId){
				val.offeringId = val.offerId;
			}
			// 获取下标
			index=i;

			var exist = false;
			$.each($Gadget.additionalOfferingList||[],function(j,valj){
				if(val.offeringId == valj.offeringId){
					exist = true;
					return false;
				}

				// 添加营销活动变更
				if (val.offerClassCode && val.offerClassCode.indexOf("PROM_")==0) {
					if(val.offeringId == valj.offeringId){
						exist = true;
						return false;
					}
				}
			});
			$.each($Gadget.holdOfferingList||[],function(j,valj){
				if(val.offeringId == valj.offeringId){
					exist = true;
					return false;
				}

				// 添加营销活动变更
				if (val.offerClassCode && val.offerClassCode.indexOf("PROM_")==0) {
					if(val.offeringId == valj.offeringId){
						exist = true;
						return false;
					}
				}
			});

			if(!exist){

				// 添加营销活动变更
				if (val.offerClassCode && val.offerClassCode.indexOf("PROM_")==0) {

					// 非空赋值
					$Gadget.holdOfferingList = $Gadget.holdOfferingList || [];
//					$Gadget.additionalOfferingList=$Gadget.additionalOfferingList||[];

					// 添加选中
					$Gadget.OfferingListForOpenAccount[index].checked = true;
					$Gadget.OfferingListForOpenAccount[index].add = true;

					// 添加到数组
					$Gadget.holdOfferingList.push($Gadget.OfferingListForOpenAccount[index]);
//					$Gadget.additionalOfferingList.push($Gadget.OfferingListForOpenAccount[index]);

					return;

				}else{
					tempList.push(val.offeringId);
					$Gadget.OfferingListForSetOfferName.push(val);
				}
			}
		});

		$Gadget.$Get('$Fire')({
			service : "ucec/v1/offering/queryofferingdetail",
			params : {
				header : {},
				body : {
					offeringIdList : tempList,
					mainOfferingId : $Gadget.currentMainOfferingInfo.offeringId,
					businessCode: "ChangeProduct"
				}
			},
			target : "$Gadget.offeringListResp",
			onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getNextFireId())",
			onafter : function() {
				debugger;
				if(!(($Gadget.offeringListResp||{}).body || {}).offerings){
					return false;
				}
				$.each($Gadget.offeringListResp.body.offerings||[],function(i,val){
					val.opCode = '1';
					val.checked = true;
					val.add = true;
					// 新选择的增值offer是没有offeringInstId，因此如果用户之前订购过此offer，退订，重新订购时，应能够走offer属性订购页面(productattrdisplay.html)
					// 而不是走offer属性变更页面(productattrchange.html)
					// modified by z00283015 for DTS2015101608968 on 2015/10/17
					val.offeringInstId = null;

					// MODIFY 2015-11-16 by l00289267 start
					if (val.attributeGroups) {
						val.hasAttrToShow = false;
						$.each(val.attributeGroups ||[] ,function(attrk,valattrk){
							$.each(valattrk.attributes || [], function(attrm, valattrm){
				        		if (!adutil.filterOcPcOfferingAttributeEnable(valattrm.ocPcOfferingAttributeEnableVA, $Gadget.$Attrs.opertype)) {
				        			valattrm.showType = 'HIDDEN';
				        		}
				        		if (valattrm.showType != 'HIDDEN') {
				        			val.hasAttrToShow = true;
				        		}
				        	});
						});
					}
					// MODIFY 2015-11-16 by l00289267 end

					$.each($Gadget.OfferingListForSetOfferName||[],function(k,valm){
						if(valm.offerId == val.offeringId)
						{
							// 判断是否需要设置生效方式，当前只有有线业务需要
							var isNeedEffectiveWay = $Controller.bes.ad.personalmainofferchange.checkIsNeedEffectiveMode(val);
							if(isNeedEffectiveWay)
							{
								val.effectiveWay = $.extend(true,{},valm.ocEffectiveMode);
							}

							if(val.isBundled && val.subOfferings && val.subOfferings.length > 0){
								$Controller.bes.ad.personalmainofferchange.setSubOfferDetail(val.subOfferings,valm.ocOfferInfoVA,isNeedEffectiveWay);
							}

							val.members = valm.members;
						}

						//营销包传过来的offer是queryofferlist的offer结构 需要重新查出offer 的生失效方式
						else if(valm.offeringId == val.offeringId){
							var isNeedEffectiveWay = $Controller.bes.ad.personalmainofferchange.checkIsNeedEffectiveMode(val);
							if(isNeedEffectiveWay)
							{
								 var queryReq = {
							                'offerid': val.offeringId,
							                'condition': {
							                    'searchBundleOffer': 'Y',
							                    businessCode: 'ChangeProduct'
							                }
							            };
								$Fire(
								{
									'service' : 'bes.oc.queryofferdetailservice/queryofferdetail',
									'params' : queryReq,
									'target' : '$Gadget.WBMobileBrandOfferingInfo['+val.offeringId+']',
									'onafter' : function() {
										debugger;
										var offeringInfo = $Gadget.WBMobileBrandOfferingInfo[val.offeringId];
										if(null == offeringInfo){
											return;
										}
										val.effectiveWay = $.extend(true,{},offeringInfo.ocEffectiveMode);
										if(val.isBundled){
											$Controller.bes.ad.personalmainofferchange.setSubOfferDetail(val.subOfferings,offeringInfo.ocOfferInfoVA,true);
										}
									}
								}, $Gadget);

							}

						}
					});
				});



				///:huangyuyuan mod 2016-08-08 DTS2016080409373 这段代码处理逻辑有问题，导致增加商品后再增加商品不生效，所以把代码修改一下
				/*
				if(($Gadget.additionalOfferingList||[]).length == 0)
				{
					$Gadget.additionalOfferingList = $Gadget.additionalOfferingList.concat($Gadget.offeringListResp.body.offerings);
				}

				for(var i=0;i<($Gadget.additionalOfferingList||[]).length;i++)
				{
					if(!$Gadget.additionalOfferingList[i].add)
					{
						for(var j=0;j<($Gadget.offeringListResp.body.offerings||[]).length;j++)
						{
							$Gadget.additionalOfferingList.splice(i+j,0,$Gadget.offeringListResp.body.offerings[j]);
						}
						return;
					}
				}*/
				for(var i=0;i<($Gadget.holdOfferingList||[]).length;i++)
				{
					if(!$Gadget.holdOfferingList[i].add)
					{
						for(var j=0;j<($Gadget.offeringListResp.body.offerings||[]).length;j++)
						{
							$Gadget.holdOfferingList.splice(i+j,0,$Gadget.offeringListResp.body.offerings[j]);
						}

						return;
					}
				}


				//在这里增加处理，避免原先已经选择商品(additionalOfferingList.length > 0)，再选择商品不生效的情况
				$Gadget.holdOfferingList = $Gadget.holdOfferingList.concat($Gadget.offeringListResp.body.offerings);
				///:~
			}

		}, $Gadget);
	},

	setSubOfferDetail : function(newOfferList,oldOfferList,isNeedEffectiveWay)
	{
		debugger;
		$.each(newOfferList,function(i,val){
			// MODIFY 2015-10-24 by l00289267 DTS2015102309556 start
			// modify reason: 包下子商品默认和必选的标示分别为 D和M
			// if(val.selectType == 'N' || val.selectType == 'T'){
			if(val.selectType == 'M' || val.selectType == 'D'){
				val.opCode='1';
				val.checked = true;
				// 新选择的增值offer是没有offeringInstId，因此如果用户之前订购过此offer，退订，重新订购时，应能够走offer属性订购页面(productattrdisplay.html)
				// 而不是走offer属性变更页面(productattrchange.html)
				// modified by z00283015 for DTS2015101608968 on 2015/10/17
				// val.offeringInstId = null;
			}
			// modify reason:给子商品的实例ID置空
			val.offeringInstId = null;
			// MODIFY 2015-10-24 by l00289267 DTS2015102309556 end
			$.each(oldOfferList,function(j,valj){
				if(val.offeringId == valj.offerId)
				{
					val.offeringName = valj.offerName;
					if(isNeedEffectiveWay)
					{
						val.effectiveWay = $.extend(true,{},valj.ocEffectiveMode);
					}
				}
			});
		});
	},

	// 检查是否需要生效方式，暂时只有符合以下提交的需要将生效方式展示并组装报文
	checkIsNeedEffectiveMode : function(offering)
	{
		if(offering.offerSubType=="WBNetTV"||offering.offerSubType == "WBMobileBrand")
		{
			return true;
		}

		if(offering.isBundled)
		{
			for(var i=0;i<(offering.subOfferings||[]).length;i++)
			{
				if(offering.subOfferings[i].offerSubType == "WBNetTV"
					|| offering.subOfferings[i].offerSubType == "WBMobileBrand")
				{
					return true;
				}
			}
		}
		return false;
	},

	/**
	 * 设置营销方案
	 */
	setBusinessLevel: function($Gadget,$Fire,$Item){

		debugger;

		// 添加批次ID、档次ID、开户MODE、活动类型
		$Gadget.params={
				"offeringId":$Item.offeringId,
				"levelId":$Item.levelBaseInfo.offeringId,
				"promotionType":($Item.attributeMap||{})["PM_PROM_SUB_TYPE"]||"",
				"mode":"CreateSubscriber"
		};

		$Gadget.$Emit("$bes.oc.additionalChangeOfferLevelPop");
	},

	togglePrize : function($Target) {
		debugger;
		$Target.find('.s_icon').toggleClass("open");
		debugger;
		var $s_content = $Target.parent().siblings();

		if ($s_content.length > 0 && $s_content.is(':visible')) {
			$s_content.hide();

		} else {
			$s_content.show();

		}
	},
	clickAddCheckbox:function($Gadget,$index){
		debugger;
		if($Gadget.additionalOfferingList[$index].selectType == 'N'){
			return;
		}
		$Gadget.additionalOfferingList[$index].checked = !$Gadget.additionalOfferingList[$index].checked;
		if(!$Gadget.additionalOfferingList[$index].checked){
			$Gadget.additionalOfferingList[$index].hasAttrToShow = false;//选择后，展示属性设置按钮
		}else{
			$Gadget.additionalOfferingList[$index].hasAttrToShow = true;
		}
		var delIndex = -1;
		$.each($Gadget.OfferingListForOpenAccount,function(i,val){
			if(val.offerId == $Gadget.additionalOfferingList[$index].offeringId){
				delIndex = i;
				return false;
			}

			// 添加营销活动变更
			if (val.offerClassCode && val.offerClassCode.indexOf("PROM_")==0) {
				if(val.offeringId == $Gadget.additionalOfferingList[$index].offeringId){
					delIndex = i;
					return false;
				}
			}
		});
		if(delIndex > -1){
			if(!$Gadget.additionalOfferingList[$index].checked){
				$Gadget.OfferingListForOpenAccount[delIndex].opCode = null;
			}else{
				$Gadget.OfferingListForOpenAccount[delIndex].opCode = '1';
			}
		}

		debugger;

		// 为空赋值空数组
		$Gadget.$Page.promInfoList=$Gadget.$Page.promInfoList||[];

		// 循环营销方案
		for(var i=0;i<$Gadget.$Page.promInfoList.length;i++){

			// 判断对象
			if($Gadget.additionalOfferingList[$index].offeringId==$Gadget.$Page.promInfoList[i].offeringId){
				if(!$Gadget.additionalOfferingList[$index].checked){
					$Gadget.$Page.promInfoList[i].opCode = null;
				}else{
					$Gadget.$Page.promInfoList[i].opCode = '1';
				}
				break;
			}
		}

		if(!$Gadget.additionalOfferingList[$index].checked){
			$Gadget.additionalOfferingList[$index].opCode = null;
		}else{
			$Gadget.additionalOfferingList[$index].opCode = '1';
		}
        $Gadget.questionnaireSubmitSuc = false;
	},
	clickDelCheckbox:function($Gadget,$index){
		debugger;
		if($Gadget.deleteOfferingList[$index].nonheritableFlag){
			return false;
		}
		$Gadget.holdOfferingList.push($Gadget.deleteOfferingList[$index]);
		$Gadget.deleteOfferingList.splice($index,1);
	},
	clickHoldCheckbox:function($Gadget,$index){
		debugger;
		if($Gadget.holdOfferingList[$index].isMust){
			return;
		}
        $Gadget.questionnaireSubmitSuc = false;
		if($Gadget.holdOfferingList[$index].add){
			//更多增值商品展示逻辑
			if($("#AdditionalCbx_" + $Gadget.holdOfferingList[$index].offeringId).hasClass('checked')){
				$("#AdditionalCbx_" + $Gadget.holdOfferingList[$index].offeringId).removeClass('checked');
				$Gadget.holdOfferingList[$index].opCode = null;
			}else{
				$("#AdditionalCbx_" + $Gadget.holdOfferingList[$index].offeringId).addClass('checked');
				$Gadget.holdOfferingList[$index].opCode = '1';
			}
			return;
		}
		$Gadget.holdOfferingList[$index].opCode = '3';
		$.each($Gadget.holdOfferingList[$index].subOfferings||[],function(i,vali){
			if(vali.offeringInstId)
			{
				vali.opCode = '3';
			}
		});
		$Gadget.deleteOfferingList.push($Gadget.holdOfferingList[$index]);
		$Gadget.holdOfferingList.splice($index,1);
	},
	validateSucess:function($Gadget,$Page){
		debugger;
		$Page.backStep = null;
		$Page.notNeedBackStep = false;
		$Gadget.gocheckout = true;
		// 用于订单创建成功页面判断是否是主体商品变更（仅个人统一视图有用）
		$Page.isMainOfferChange = true;
		$("#personalMainOfferChange").hide();
		$("#ochasRecommendMainOfferChange").hide();
	},
	showBackStep:function($Gadget, $Page){
		debugger;
		$Gadget.gocheckout = false;
		// 用于订单创建成功页面判断是否是主体商品变更（仅个人统一视图有用）
		$Page.isMainOfferChange = false;
		$("#personalMainOfferChange").show();
		$("#ochasRecommendMainOfferChange").show();
	},

	OnMessage : function(e) {
		debugger;
		e = e || window.event;
		var data;
		if (navigator.userAgent.indexOf("MSIE") != -1) {
			data = JSON.parse(e.data);
		} else {
			data = e.data;
		}

		var operation = data.operation;
		if (undefined == operation) {
			return;
		}

		if ("promotionBundle" == operation)  // 营销虚包消息
		{
			// 增值产品
			$Controller.bes.ad.personalmainofferchange.processPromotionBundle(data.promotionBundle);
		}
	},

	onMessageFromPortal: function()
	{
	    //先移除原来的事件DTS2016040400233
        if (window.detachEvent)
        { // IE before version 9
            window.detachEvent("onmessage", this.OnMessage);
        }

		if (window.addEventListener) {  // all browsers except IE before version
										// 9
			window.addEventListener ("message", this.OnMessage, false);
	    }
	    else {
	        if (window.attachEvent) {   // IE before version 9
	            window.attachEvent("onmessage", this.OnMessage);
	        }
	    }
	},

	processPromotionBundle : function(promotionBundle) {
		if (promotionBundle.mainOffer
				&& promotionBundle.mainOffer.length > 0) {
			// 查询主offer信息
			$(document).scope().$Emit('$bes.oc.setMainOffer',
					promotionBundle.mainOffer[0].offeringId);
		}

		var promotionBundleOffer = $.extend(true, [], promotionBundle.offer);
		var promotionoffers = promotionBundle.promotionOffer;
		if (promotionoffers) {
			for (var i = 0; i < promotionoffers.length; i++) {
				var $Item = promotionoffers[i];
				var $levelInfo = $Item.parentOffering;

				var $Promotion = {};
				$Promotion.offerId = $Item.offeringId
						+ ""
						+ $levelInfo.offeringId;

				$Promotion.offerName = $levelInfo.offeringName
						+ "(" + $Item.offeringName + ")";

				$Promotion.offerClassCode = 'PROM_TYPE';
				// 档次所属活动名称
				$Promotion.offeringName = $Item.offeringName;
				// 档次所属活动ID
				$Promotion.offeringId = $Item.offeringId;
				$Promotion.includeLevel = true;
				$Promotion.attributeMap = $Item.attributeMap;

				$Promotion.levelBaseInfo = $levelInfo;
				promotionBundleOffer.push($Promotion);
			}
		}
		$(document).scope().$Emit('$bes.oc.addiProdSelected',
				promotionBundleOffer);
	},

	setMainOffer: function($Gadget, offeringId, $Fire) {
		$Fire({
			service : "ucec/v1/offering/offeringdetail_query",
			params : {
				header : {},
				body : {
					offeringId : offeringId,
					needOfferAttr : "Y"
				}
			},
			target : "$Gadget.offerdetailresp",
			onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId())",
			onafter : function() {
				debugger;
				if(!(($Gadget.offerdetailresp||{}).body || {}).offeringInfo){
					$Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.person.message.FoundOfferDetail'));
					return false;
				}

				$Gadget.currentMainOfferingInfo = $Gadget.offerdetailresp.body.offeringInfo ||{};
				$Controller.bes.ad.personalmainofferchange.querydict($Gadget);

				$.each($Gadget.currentMainOfferingInfo.attributeGroups || [] ,function(i,val){
					var groupIndex = i;
					$.each(val.attributes || [],function(j,valj){
						if (valj.attrCode == "C_O_DIY_FLAG" && valj.newValue == "Y")
						{
							$Gadget.isPoland = true;
						}
						valj.attrName =  $.parseJSON(valj.attrName  || "{}")[adutil.getLocale()];
						$Controller.bes.ad.personalmainofferchange.assembleDIYAttr($Gadget, valj,groupIndex)
					});

				});
			}

		}, $Gadget);
	},

	// date 初始化
	initDate : function($Page,target,$Item){
		debugger;
		var date = new UCD.Date({dateFormat: "YYYY-MM-dd hh:mm:ss"});
		date.init();
		date.setAnchor($(".date").last());

		date.setValue("");
		date.setOnChanged(function()
		{
			debugger;
			$Item.effectiveWay.effectiveDate = new Date($Controller.bes.ad.personalmainofferchange.getValue().replace(/-/g, "/")).getTime();
		});
	},

	// 订购推荐商品
	ordeRecommendOffer : function($Gadget, $Page, $Data){
		debugger;
		$Gadget.recommendOfferId = $Data.offeringId;
		var existFlag = false;
		$.each( $Gadget.additionalOfferingList ||[], function(i, val){
			if(val.offeringId == $Gadget.recommendOfferId){
				var flag = true;
			}
		});
		if(existFlag){
			// 商品已在列表中，请选择其他商品
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.OfferingAlreadyInList"));
			return false;
		}

		// 先查offer信息，再查询属性
		dontTouchDataOfWholePage();
		$Fire({
			service : "ucec/v1/offering/offeringdetail_query",
			params : {
				header : {},
				body : {
					offeringId : $Gadget.recommendOfferId
				}
			},
			target : "$Gadget.recommendOfferDetailResp",
			onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId())",
			onafter : function() {
				youCanTouchDataOfWholePage();
				debugger;
				if(!(($Gadget.recommendOfferDetailResp||{}).body || {}).offeringInfo){
					$Gadget.$Get('$UI').msgbox.error($UEE.i18n('ad.person.message.information'),
							$UEE.i18n("ad.person.message.OfferingDetailNotFound")); // "未查询到此商品详细信息。"
					return false;
				}
				$Gadget.recommendOfferingInfo = $.extend(true, {}, $Gadget.recommendOfferDetailResp.body.offeringInfo);

				dontTouchDataOfWholePage();
				// 查询属性
				$Fire({
					service : "ucec/v1/offering/offeringattributes_query",
					params : {
						header : {},
						body : {
							offeringId : $Gadget.recommendOfferId
						}
					},
					target : "$Gadget.recommendproductAttrs",
					onbefore : "OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId())",
					onafter : function() {
						youCanTouchDataOfWholePage();
						debugger;
						if ( !($Gadget.recommendproductAttrs||{}).body) {
							var commattr = $Gadget.recommendproductAttrs.body.attributeGroups || [];
							$Gadget.recommendOfferingInfo.attributeGroups = $.extend(true, [], commattr);
							$Gadget.recommendOfferingInfo.hasAttrToShow = true;
						}

						$Gadget.recommendOfferingInfo.selectType = "T";
						$Gadget.recommendOfferingInfo.checked = true;
						$Gadget.recommendOfferingInfo.opCode = "1";
						$Gadget.recommendOfferingInfo.feedbackRecommend = $.extend(true, {}, $Data.feedbackRecommend);
						// 添加到展示列表
						$Gadget.additionalOfferingList = $Gadget.additionalOfferingList ||[];
						$Gadget.additionalOfferingList.push($Gadget.recommendOfferingInfo);
					}

				}, $Gadget);
			}

		}, $Gadget);
	},
	// 组装DIY属性
	assembleDIYAttr: function($Gadget, attr,groupIndex){
		// 保底消费租费
		if (attr.attrCode == "PM_Attr_MonthlyFee_Min"){
			$Gadget.currentMainOfferingInfo.monthlyFeeMin = attr.newValue;
			adutil.getDisplayPricesFromStorageValues({storageValues: [attr.newValue]}, function(){
				$Gadget.currentMainOfferingInfo.monthlyFeeMinDisplay = this.displayPrices[attr.newValue];
			});
		}

		// 租费计算公式
		if (attr.attrCode == "PM_Attr_MonthlyFee_RankPrice"){
			$Gadget.currentMainOfferingInfo.monthlyFeeRankPrice = attr.newValue;
		}

		// 流量套餐
		if (attr.attrCode == "PM_Attr_DataFlow"){
			attr.DIYInfo = {
				value: attr.newValue
			};
			$.each($Gadget.currentMainOfferingInfo.attributeGroups[groupIndex].attributes||[], function(i,vali){
				// 最大数量
				if (vali.attrCode == "PM_Attr_DataFlow_Max"){
					attr.DIYInfo.max = vali.newValue;
				}
				// 最小数量
				if (vali.attrCode == "PM_Attr_DataFlow_Min"){
					attr.DIYInfo.min = vali.newValue;
				}
				// 步进值
				if (vali.attrCode == "PM_Attr_DataFlow_Step"){
					attr.DIYInfo.step = vali.newValue;
				}
				// 租费计算公式
				if (vali.attrCode == "PM_Attr_DataFlow_RankPrice"){
					attr.DIYInfo.rankPrice = vali.newValue;
				}
				// 单价
				if (vali.attrCode == "PM_Attr_DataFlow_Price"){
					attr.DIYInfo.unitStorageValue = vali.newValue;
					adutil.getDisplayPricesFromStorageValues({storageValues: [vali.newValue]}, function(){
						attr.DIYInfo.unitPrice = this.displayPrices[vali.newValue] + "/" + attr.attrUnit;
					});
				}
			});
		}
		// 语音套餐
		if (attr.attrCode == "PM_Attr_Voice"){
			attr.DIYInfo = {
				value: attr.newValue
			};
			$.each($Gadget.currentMainOfferingInfo.attributeGroups[groupIndex].attributes||[], function(i,vali){
				// 最大数量
				if (vali.attrCode == "PM_Attr_Voice_Max"){
					attr.DIYInfo.max = vali.newValue;
				}
				// 最小数量
				if (vali.attrCode == "PM_Attr_Voice_Min"){
					attr.DIYInfo.min = vali.newValue;
				}
				// 步进值
				if (vali.attrCode == "PM_Attr_Voice_Step"){
					attr.DIYInfo.step = vali.newValue;
				}
				// 租费计算公式
				if (vali.attrCode == "PM_Attr_Voice_RankPrice"){
					attr.DIYInfo.rankPrice = vali.newValue;
				}
				// 单价
				if (vali.attrCode == "PM_Attr_Voice_Price"){
					attr.DIYInfo.unitStorageValue = vali.newValue;
					adutil.getDisplayPricesFromStorageValues({storageValues: [vali.newValue]}, function(){
						attr.DIYInfo.unitPrice = this.displayPrices[vali.newValue] + "/" + attr.attrUnit;
					});
				}
			});
		}
		// 短信套餐
		if (attr.attrCode == "PM_Attr_SMS"){
			attr.DIYInfo = {
				value: attr.newValue
			};
			$.each($Gadget.currentMainOfferingInfo.attributeGroups[groupIndex].attributes||[], function(i,vali){
				// 最大数量
				if (vali.attrCode == "PM_Attr_SMS_Max"){
					attr.DIYInfo.max = vali.newValue;
				}
				// 最小数量
				if (vali.attrCode == "PM_Attr_SMS_Min"){
					attr.DIYInfo.min = vali.newValue;
				}
				// 步进值
				if (vali.attrCode == "PM_Attr_SMS_Step"){
					attr.DIYInfo.step = vali.newValue;
				}
				// 租费计算公式
				if (vali.attrCode == "PM_Attr_SMS_RankPrice"){
					attr.DIYInfo.rankPrice = vali.newValue;
				}
				// 单价
				if (vali.attrCode == "PM_Attr_SMS_Price"){
					attr.DIYInfo.unitStorageValue = vali.newValue;
					adutil.getDisplayPricesFromStorageValues({storageValues: [vali.newValue]}, function(){
						attr.DIYInfo.unitPrice = this.displayPrices[vali.newValue] + "/" + attr.attrUnit;
					});
				}
			});
		}
		if (attr.DIYInfo){
			$Controller.bes.ad.personalmainofferchange.changeDIYValue($Gadget, attr);
		}
	},
	changeDIYValue: function($Gadget,$Item){
		debugger;
		$Item.newValue = $Item.DIYInfo.value;

		var storageValue = $Item.newValue * $Item.DIYInfo.unitStorageValue;
		// 计算费用 0~100$0.15#100~500$0.1#500~2048$0.05
		if ($Item.DIYInfo.rankPrice){
			storageValue = $Controller.bes.ad.personalmainofferchange.calcStorageValue($Item.DIYInfo.rankPrice,
					$Item.newValue, $Item.DIYInfo.unitStorageValue);
		}

		$Item.DIYInfo.storageValue = storageValue;

		var totalStorageValue = 0;
		$.each($Gadget.currentMainOfferingInfo.attributeGroups||[],function(i,val){
			$.each(val.attributes||[],function(j,valj){
				if (valj.DIYInfo){
					totalStorageValue += parseFloat(valj.DIYInfo.storageValue);
				}
			});
		});

		var monthlyFee = totalStorageValue;
		if ($Gadget.currentMainOfferingInfo.monthlyFeeRankPrice){
			monthlyFee = $Controller.bes.ad.personalmainofferchange.calcStorageValue($Gadget.currentMainOfferingInfo.monthlyFeeRankPrice, totalStorageValue, 1);
		}

		if (monthlyFee < $Gadget.currentMainOfferingInfo.monthlyFeeMin){
			monthlyFee = $Gadget.currentMainOfferingInfo.monthlyFeeMin;
		}

		$.each($Gadget.currentMainOfferingInfo.attributeGroups||[],function(i,val){
			$.each(val.attributes||[],function(j,valj){
				if (valj.attrCode == "C_O_MONTHLY_FEE"){
					valj.newValue = monthlyFee;
					adutil.getDisplayPriceValueFromStorage({storageValue: parseInt(monthlyFee)}, function(){
						valj.attrDisplayPriceValue = this.displayPriceValue;
					});
				}
			});
		});

		adutil.getDisplayPricesFromStorageValues({storageValues: [parseInt(monthlyFee)]}, function(){
			$Gadget.currentMainOfferingInfo.monthlyFeeDisplay = this.displayPrices[parseInt(monthlyFee)];
		});
	},

	// 根据公式计算费用存储值
	calcStorageValue: function(rankPrice, newValue, unitStorageValue){
		var storageValue = 0;
		var gradeArr = rankPrice.split("#");
		$.each(gradeArr || [], function(i, vali){
			var splitArr = [];
			var splitGrade = [];
			var unitValue = 0;

			// 价格
			if (vali.indexOf("$") != -1){
				splitArr = vali.split("$");
				splitGrade = splitArr[0].split("~");
				unitValue = parseFloat(splitArr[1]);
			}

			// 百分比
			if (vali.indexOf("%") != -1){
				splitArr = vali.split("%");
				splitGrade = splitArr[0].split("~");
				unitValue = parseFloat(splitArr[1] * unitStorageValue);
			}

			if (splitGrade.length == 1){
				if (parseFloat(newValue) > parseFloat(splitGrade[0])){
					storageValue += (newValue - splitGrade[0]) * unitValue;
				}
			}
			if (splitGrade.length == 2){
				if (parseFloat(newValue) > parseFloat(splitGrade[0])
						&& parseFloat(newValue) <= parseFloat(splitGrade[1])){
					storageValue += (newValue - splitGrade[0]) * unitValue;
				}
				else if (parseFloat(newValue) > parseFloat(splitGrade[1])){
					storageValue += (splitGrade[1] - splitGrade[0]) * unitValue;
				}
			}
		});
		return storageValue;
	},
	//主商品选择点击ok
	choosemainofferok: function($Gadget,$Page){
		debugger;
		if(!$Page.haschoosedMainProdFlag)
			return;
		$Gadget.displayChoosedMainOfferInfo = [];//已选主商品展示信息
		if(($Gadget.mainOfferList||[]).length > 0){
			for ( var i = 0; i < ($Gadget.mainOfferList||[]).length; i++) {
				if(($Gadget.mainOfferList[i].subOfferings||[]).length > 0){
					//包
					for ( var j = 0; j < ($Gadget.mainOfferList[i].subOfferings||[]).length; j++) {
						if($Gadget.mainOfferList[i].subOfferings[j].checked){
							$Gadget.displayChoosedMainOfferInfo.push({
								offerName: $Gadget.mainOfferList[i].offeringName,
								subOfferName: $Gadget.mainOfferList[i].subOfferings[j].offeringName,
								subOfferDesc: $Gadget.mainOfferList[i].subOfferings[j].offeringDesc
							});
							break;
						}
					}
				}else{
					//非包
					$Gadget.displayChoosedMainOfferInfo.push({
						offerName: $Gadget.mainOfferList[i].offeringName,
						subOfferName: $Gadget.mainOfferList[i].offeringName,
						subOfferDesc: $Gadget.mainOfferList[i].offeringDesc
					});
				}
			}
		}
		if($Gadget.displayChoosedMainOfferInfo.length == 0)//选择了主商品，还要选择选择主商品的子套餐
			return;
		$Page.haschoosedMainProdFlag2 = true;//选择主商品，点击确定
	},
	//主商品取消按钮，清除相关数据
	choosemainoffercancel: function($Gadget){
		debugger;
		$Page = $Gadget.$Page;
		$Page.haschoosedMainProdFlag = false;
		$Page.haschoosedMainProdFlag2 = false;
		$Gadget.displayChoosedMainOfferInfo = null;
		$Gadget.mainOfferList = null;
		$Gadget.currentMainOfferingInfo = null;
		$Gadget.additionalOfferingList = null;
		$Gadget.deleteOfferingList = null;
		$Gadget.holdOfferingList = null;
	},

	/**
	 * 主套餐子offer复选框
	 */
	clickMainSubsCheckbox: function($Gadget,$Offer,$subOffer){
		debugger;
		for ( var i = 0; i < ($Offer.subOfferings||[]).length; i++) {
			if($Offer.subOfferings[i].checked && $Offer.subOfferings[i].offeringId != $subOffer.offeringId){
				$Offer.subOfferings[i].checked = !$Offer.subOfferings[i].checked;
				break;
			}
		}
		$subOffer.checked = !$subOffer.checked;
		if($subOffer.checked){
			$Offer.choosedSubOffer = $subOffer;
		}else{
			$Offer.choosedSubOffer = null;
		}
        $Gadget.questionnaireSubmitSuc = false;
	},
	/**
	 * 组装报文时，给relaItemId和opCode赋值，从购物车js中复制来的代码
	 */
	setDeviceRecvOfferingList:function(deviceRecvOfferingList){
		$.each(deviceRecvOfferingList||[],function(j,valj){
			valj.relaItemId = adutil.getNextNumber();
			valj.opCode = '1';
			$.each(valj.product||[],function(k,valk){
				valk.relaItemId = adutil.getNextNumber();
				valk.opCode = '1';
			});
		});
	},

	gerateofferingList:function(offeringList){
		debugger;

		$.each(offeringList||[],function(i,val){
			//转套餐 升降级 时候需要展示一个删除的offering 这个只是为了展示
			//组装保温的时候老offer是放在心offer下面传给后端
			if(val.justForDisplay){
				offeringList.splice(i,1);
				return true;
			}
			if(val.relatedTransOldOffering){
				val.relatedTransOldOffering.relaItemId = adutil.getNextNumber();
			}
			// 设备领取
			$Controller.bes.ad.personalmainofferchange.setDeviceRecvOfferingList(val.deviceRecvOfferingList);

			val.relaItemId = adutil.getNextNumber();
			if(val.product && val.product.length > 0){

				$.each(val.product ,function(p,pro){
					pro.relaItemId = adutil.getNextNumber();
					pro.opCode = val.opCode;
				});

				//去除掉无用的产品
				if(!val.product[0].prodId){
					val.product = null;
				}
			}
			//去除无用的有线业务信息
			if(val.wiredProdAttr && val.wiredProdAttr.newCardInfo && (!val.wiredProdAttr.newCardInfo.skuId)){
				val.wiredProdAttr.newCardInfo = null;
			}

			if(val.isBundled && val.subOfferings){
				$Controller.bes.ad.personalmainofferchange.genereateSubOffer(val.subOfferings);
			}

		});
	},

	genereateSubOffer:function(subOfferings){

		//去除无效的子offer
		var list = [];
		$.each(subOfferings||[],function(j,valj){
			if(valj.opCode == '1' || valj.opCode == '2' || valj.opCode == '3'){
				list.push(valj);
			}
		});
		subOfferings.length = 0;
		$.extend(subOfferings,list);

		//处理子offer生失效方式
		$.each(subOfferings||[],function(k,valk){

			if(valk.isBundled && valk.subOfferings){
				//O-O-O结构 底层offering直接使用父级opCode
				var selectNum = 0;
				// 去除包上所挂无效产品   DTS2017060614714 选择了子商品经busivalidate接口校验之后说没有选子商品 Author:cwx430960
				valk.product = null;
				$.each(valk.subOfferings||[],function(i,vali){
					if(valk.opCode == 1 && vali.selectType == 'M'){
						vali.opCode = 1;
					}else if(valk.opCode == 3){
						vali.opCode = vali.offeringInstId ? 3:null;
					}
					if(vali.opCode){
						selectNum++;
					}
				});
				if(selectNum == 0 && (valk.subOfferings||[]).length > 0 && valk.opCode ==1){
						valk.subOfferings[0].opCode  = valk.opCode;
				}
				$Controller.bes.ad.personalmainofferchange.genereateSubOffer(valk.subOfferings);
			}

			valk.relaItemId = adutil.getNextNumber();
			if(valk.product && valk.product.length > 0){
				$.each(valk.product ,function(p,pro){
					pro.relaItemId = adutil.getNextNumber();
					pro.opCode = valk.opCode;
				});
			}

			// 设备领取
			$Controller.bes.ad.personalmainofferchange.setDeviceRecvOfferingList(valk.deviceRecvOfferingList);

			//去除无用的有线业务信息
			if(valk.wiredProdAttr && valk.wiredProdAttr.newCardInfo && (!valk.wiredProdAttr.newCardInfo.skuId)){
				valk.wiredProdAttr.newCardInfo = null;
			}

			if(valk.effectiveWay){

				var effectiveTypes = [];
				$.each(valk.effectiveWay.effectiveTypes||[],function(l,vall){
					if(vall.key == valk.effectiveWay.selectedKey){
						vall.selected = true;
						effectiveTypes.push(vall);
						return false;
					}

				});
				valk.effectiveWay.effectiveTypes = 	effectiveTypes;
			}

			if(valk.expirationWay){
					var expirationTypes = [];
					$.each(valk.expirationWay.expirationTypes||[],function(l,vall){
						if(vall.key == valk.expirationWay.selectedKey){
							vall.selected = true;
							expirationTypes.push(vall);
							return false;
						}

					});
					valk.expirationWay.expirationTypes = 	expirationTypes;
				}
		});
	},

    /*
     * 用于调查问卷的提交成功事件的处理
     */
     clickconfirm:function($Gadget){
        $Gadget.questionnaireSubmitSuc = true;
        $Gadget.$Get("$Fire")({
            "popin":""
        }, $Gadget);
     },
     /*
     * 用于调查问卷的取消事件的处理
     */
     clickcancel:function($Gadget){
        $Gadget.$Get("$Fire")({
            "popin":""
        }, $Gadget);
     },
     /*
      * 计算变更后的主商品下的价格总和,用于判断变更后的主商品是否降档了,降档需要记录原因(问卷调查)
      */
     calculatePriceTotal: function($Gadget){
        debugger;
        $Gadget.goalGradePriceTotal = 0;
        var isPmBaseOffer = false;
        var isPmOfferPrice = 0;
        var choosedSubOffer = {};
        // 主商品下的包
        $.each($Gadget.mainOfferList || [], function(i, vali){
            if (vali.checked) {
                isPmBaseOffer = false;
                isPmOfferPrice = 0;
                choosedSubOffer = vali.choosedSubOffer || {};
                $.each(choosedSubOffer.attributeGroups || [], function(j, valj){
                    $.each(valj.attributes || [],function(k, valk){
                        if (valk.attrCode == "PM_BASE_OFFER" && valk.newValue == "1") { // PM_BASE_OFFER=1表示需要计算档次费用
                            isPmBaseOffer = true;
                        }
                        if (valk.attrCode == "PM_OFFER_PRICE" && valk.newValue) { // PM_OFFER_PRICE表示档次价格
                            if (adutil.checkNumberChar(valk.newValue)) { // 数字验证
                                isPmOfferPrice = parseInt(valk.newValue);
                            }else{
                                isPmOfferPrice = 0;
                            }
                        }
                    });
                });
                if (isPmBaseOffer) {
                    $Gadget.goalGradePriceTotal = $Gadget.goalGradePriceTotal + isPmOfferPrice;
                }
            }
        });
        // 增值商品
        $.each($Gadget.additionalOfferingList || [], function(i, vali){
            if (vali.checked) {
                isPmBaseOffer = false;
                isPmOfferPrice = 0;
                $.each(vali.attributeGroups || [], function(j, valj){
                    $.each(valj.attributes || [],function(k, valk){
                        if (valk.attrCode == "PM_BASE_OFFER" && valk.newValue == "1") { // PM_BASE_OFFER=1表示需要计算档次费用
                            isPmBaseOffer = true;
                        }
                        if (valk.attrCode == "PM_OFFER_PRICE" && valk.newValue) { // PM_OFFER_PRICE表示档次价格
                            if (adutil.checkNumberChar(valk.newValue)) { // 数字验证
                                isPmOfferPrice = parseInt(valk.newValue);
                            }else{
                                isPmOfferPrice = 0;
                            }
                        }
                    });
                });
                if (isPmBaseOffer) {
                    $Gadget.goalGradePriceTotal = $Gadget.goalGradePriceTotal + isPmOfferPrice;
                }
            }
        });
        // 删除的商品
        $.each($Gadget.holdOfferingList || [], function(i, vali){
            if (vali.isBundled) {
                $.each(vali.subOfferings || [], function(m, valm){
                    if (!valm.offeringInstId) {
                        return;
                    }
                    isPmBaseOffer = false;
                    isPmOfferPrice = 0;
                    $.each(valm.attributeGroups || [], function(j, valj){
                        $.each(valj.attributes || [],function(k, valk){
                            if (valk.attrCode == "PM_BASE_OFFER" && valk.newValue == "1") { // PM_BASE_OFFER=1表示需要计算档次费用
                                isPmBaseOffer = true;
                            }
                            if (valk.attrCode == "PM_OFFER_PRICE" && valk.newValue) { // PM_OFFER_PRICE表示档次价格
                                if (adutil.checkNumberChar(valk.newValue)) { // 数字验证
                                    isPmOfferPrice = parseInt(valk.newValue);
                                }else{
                                    isPmOfferPrice = 0;
                                }
                            }
                        });
                    });
                    if (isPmBaseOffer) {
                        $Gadget.goalGradePriceTotal = $Gadget.goalGradePriceTotal + isPmOfferPrice;
                    }
                });
            }else{
                isPmBaseOffer = false;
                isPmOfferPrice = 0;
                $.each(vali.attributeGroups || [], function(j, valj){
                    $.each(valj.attributes || [],function(k, valk){
                        if (valk.attrCode == "PM_BASE_OFFER" && valk.newValue == "1") { // PM_BASE_OFFER=1表示需要计算档次费用
                            isPmBaseOffer = true;
                        }
                        if (valk.attrCode == "PM_OFFER_PRICE" && valk.newValue) { // PM_OFFER_PRICE表示档次价格
                            if (adutil.checkNumberChar(valk.newValue)) { // 数字验证
                                isPmOfferPrice = parseInt(valk.newValue);
                            }else{
                                isPmOfferPrice = 0;
                            }
                        }
                    });
                });
                if (isPmBaseOffer) {
                    $Gadget.goalGradePriceTotal = $Gadget.goalGradePriceTotal + isPmOfferPrice;
                }
            }
        });
     }
});
