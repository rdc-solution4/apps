$Controller("bes.ad.personalofferinginfo", {
	init : function($Page,$Gadget, $Fire) {
		debugger;
		//初始化为校验成功，校验失败时系统为显示温馨提示，这个功能目前只有江苏移动定制才有，基线没做提示，默认都是不显示
		$Gadget.validateSuccess = true;

		$Gadget.newWireOffer = false;
		$Gadget.offeringInfo = $Gadget.$Attrs.model;
		$Gadget.$Attrs.refresh = $Gadget.$Attrs.refresh || {};
		
		//0.2元/10M pmUnitValue对应10。对于不存在pmUnitValue的商品，也不需要判断pmUnitValue是否为空
		$Gadget.data = $Gadget.data || {};
		$Gadget.data.pmUnitValue = 1;
		
		dontTouchDataOfWholePage();
		try {
        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextInitFireId());
        } catch (e) {
        	debugger;
        }
        $Controller.bes.ad.personalofferinginfo.getPromRemainAmount($Gadget,$Page,$Fire);
		$Fire({
			service : "bes.oc.pcsearchex4telecomqueryservice/queryofferingsetlist",
			params : {
				offerid: $Gadget.$Attrs.offeringid
			},
			target : "$Gadget.queryOfferingSetListResp",
			onafter : function() {
				debugger;
				
				//主Offer升降级 by w0316510
				if ($Page.isOfferSJJ == 1) {
					if ($Gadget.queryOfferingSetListResp &&
				        $Gadget.queryOfferingSetListResp.header && $Gadget.queryOfferingSetListResp.header.resultCode == 0 &&
				        $Gadget.queryOfferingSetListResp.body && $Gadget.queryOfferingSetListResp.body.pcOfferingBasicInfoTRSDTOs) {
						  $Gadget.pcOfferingBasicInfoTRSDTOs = $Gadget.queryOfferingSetListResp.body.pcOfferingBasicInfoTRSDTOs;
					} else {
						$UI = $Gadget.$Get('$UI');
						//此商品未查到其他套餐规格，不可以进行升降级操作。
						$UI.msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n('ad.person.message.noOtherSpecificationCannotUpgrade'), function(){
							$Gadget.$Get('$Fire')({
								targetstep: 'index'
							});
						});
						youCanTouchDataOfWholePage();
						return;
					}
					
					//原来订购的Offer
					$Gadget.oldQueryOffering = {};
					//展示的套餐规格
					$Gadget.displayQueryOfferingSetLists = [];
					var offers = $Gadget.pcOfferingBasicInfoTRSDTOs;
					for ( var i = 0; i < offers.length; i++) {
						var item = offers[i];
						if (item.offeringId == $Gadget.$Attrs.offeringid) {
							$Gadget.oldQueryOffering = item;
						}
						
						$Gadget.displayQueryOfferingSetLists.push(item);
					}
					
					//默认选中原来的Offer
					$Page.oldQueryOffering = $Gadget.oldQueryOffering;
				} else {
					$Gadget.queryOfferingSetListResp = (($Gadget.queryOfferingSetListResp).body||{}).pcOfferingBasicInfoTRSDTOs;
					
					//获取原套餐规格名称
					$.each($Gadget.queryOfferingSetListResp||[],function(i,val){
						if (val.offeringId == $Gadget.$Attrs.offeringid){
							$Gadget.oldofferingInfo = val;
						}
					});
				}
				youCanTouchDataOfWholePage();
			},
			onerror: function() {
				debugger;
				youCanTouchDataOfWholePage();
			}
		}, $Gadget);
		
		try {
        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextInitFireId());
        } catch (e) {
        	debugger;
        }
		$Fire({
			service : "ucec/v1/offering/offeringdetail_query",
			params : {
				header : {},
				body : {
					offeringId : $Gadget.$Attrs.offeringid,
					needOfferAttr : "Y"
				}
			},
			target : "$Gadget.offerdetailresp",
			onafter : function() {
				debugger;
				$Gadget.offeringInfo = (($Gadget.offerdetailresp||{}).body || {}).offeringInfo;
				if($Gadget.offeringInfo){
					var priceValue = adutil.getDisplayPrice($Gadget.offeringInfo.lowPrice,$Gadget.offeringInfo.highPrice);
					var monthlyFee = adutil.getDisplayPrice($Gadget.offeringInfo.monthlyFee);
					if (priceValue == "￥0.00" || priceValue == "￥0.00-0.00")
					{
						priceValue = "";
					}
					$Gadget.offeringInfo.priceValue = priceValue;
					if (monthlyFee == "￥0.00" || monthlyFee == "￥0.00-0.00")
					{
						monthlyFee = "";
					}
					$Gadget.offeringInfo.monthlyFee = monthlyFee;
					
					debugger;
					if ($Gadget.$Attrs.params)
					{
						if ($.parseJSON($Gadget.$Attrs.params) &&　$.parseJSON($Gadget.$Attrs.params).iscug)
						{
							$Gadget.cugflag = true;
						}
						if ($Gadget.cugflag)
						{
							$Gadget.offeringInfo.netType = $Controller.bes.ad.personalofferinginfo.getOfferingAttrValue($Gadget,"C_O_NETWORK_TYPE");
							$Gadget.offeringInfo.paymentFlag = $Controller.bes.ad.personalofferinginfo.getOfferingAttrValue($Gadget,"C_O_PAYMENT_MODE");
						}
					}
				}
				
				//商品详情埋点 by00356902
				$BuriedPoinStat.setEcommerceView($Gadget.offeringInfo);
				
				// 如果是包月宽带商品,查询同组的商品
				if ($Gadget.offeringInfo.classificationId =='5215'){
					$Gadget.newWireOffer = true;
						$Gadget.offeringSetSelectedId = $Gadget.$Attrs.offeringid;
						try {
				        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextInitFireId());
				        } catch (e) {
				        	debugger;
				        }
						$Fire({
							service : 'ucec/v1/offering/offeringattributes_query',
							params : {
								header : null,
								body : {
									offeringId : $Gadget.$Attrs.offeringid
								}
							},
							target : '$Gadget.productAttrs',
							onafter : function() {
								debugger;
								if ($Gadget.productAttrs && $Gadget.productAttrs.body) {
									
								} else {
									return;
								}
								var commattr = $Gadget.productAttrs.body.attributeGroups
								|| [];
								$Gadget.offeringInfo.attributeGroups = $.extend(true,[],commattr);
								$.each(commattr||[],function(i,val){
									$.each(val.attributes||[],function(j,valj){
										if (valj.attrCode == "bandSpeed"){
											$Gadget.offeringInfo.bandSpeed = 
												$Controller.bes.ad.personalofferinginfo.getDictValueBykey(valj.options, valj.newValue);
										}
									});
								});
							}
						}, $Gadget);
						
						
						
						
						
				}
				
				
				if ($Gadget.offeringInfo.classificationId == "5214"){
                    			//$Gadget.data.displayTotalPrice = true;
					$("#quantityGood").show();
					$("#totalPrice").show();
                    			$Gadget.data.displayPurchaseNumber = true;
                    			$Gadget.offeringInfo = $Gadget.offeringInfo || {};
                    			$Gadget.offeringInfo.quantity = ($Gadget.$Attrs.model || {}).quantity  || 1;

                    			$Controller.bes.ad.personalofferinginfo.queryChargeOfferingAttributes($Gadget, $Gadget.$Attrs.offeringid);  
                    			
                    			$Controller.bes.ad.personalofferinginfo.updatePurchaseNumber($Gadget);
                    			$Controller.bes.ad.personalofferinginfo.updateTotalPrice($Gadget);
				}
			}
		}, $Gadget);
		try {
        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextInitFireId());
        } catch (e) {
        	debugger;
        }
		$Fire({
			service : "/bes.agentdesktop.promotionservice/querypromotionlistbyofferingid",
			params : {
				offeringid : $Gadget.$Attrs.offeringid
				},
			target : "$Gadget.promotionList",
			
		}, $Gadget);
		
		//新已开业务判断
		if($Page.data&&$Page.data.isNewopenbusiness){
			$("#showproductinfo").removeClass("main");
			$("#showproductinfo").addClass("newopenbusiness_main");
		}else{
			$("#showproductinfo").removeClass("newopenbusiness_main");
			$("#showproductinfo").addClass("main");
		}
		debugger;
		$Gadget.spOffingInfo={};
		$Gadget.request=[];
		$Gadget.request.push({
			"offeringId":$Gadget.$Attrs.offeringid,
		    "offeringName":"",		
		    "spCode":"",
		    "spBizCode":""});
			    
		
		$Fire({
			service: "/bes.agentdesktop.spqueryservice/queryofferingrelation",
			params:{
           	 req:$Gadget.request
            },
			target: "$Gadget.spOffingInfo",
			onafter: function($Gadget) {
				debugger;
			}
		}, $Gadget);
	},

	getPromRemainAmount: function($Gadget, $Page,$Fire) {
		debugger;
		if ($Page.projectVersion == "NINGXIA" && $Page.promOfferingInfoForRemainAmount && 
			$Page.promOfferingInfoForRemainAmount.offerClassCode.indexOf("PROM_") == 0){
			$Fire({
				service: "/pmofferinglicenselimitexboservice/queryentityusagebalancebycond",
				params:{
	           		cond : {actionName: $Page.promOfferingInfoForRemainAmount.offerName},
	           		page : {recordPerPage: 15, beginRowNumber: 0},
	            },
				target: "$Gadget.promRemainAmountInfo",
				onafter: function($Gadget) {
					debugger;
					$Gadget.displayPromRemainAmountInfo = {};
					if ($Gadget.promRemainAmountInfo && $Gadget.promRemainAmountInfo.balanceVOList && $Gadget.promRemainAmountInfo.balanceVOList.length > 0){
						$.each($Gadget.promRemainAmountInfo.balanceVOList, function(i, vali){
							if (vali.beId == $Page.roamRegion && vali.actionOfferingName == $Page.promOfferingInfoForRemainAmount.offerName){
								$Gadget.displayPromRemainAmountInfo.limitAmount = vali.cycleTimes/100;
								$Gadget.displayPromRemainAmountInfo.banlance = vali.banlance/100;
							}
							if (!$Gadget.displayPromRemainAmountInfo.limitAmount && vali.beId == "999" && vali.actionOfferingName == $Page.promOfferingInfoForRemainAmount.offerName){
								$Gadget.displayPromRemainAmountInfo.limitAmount = vali.cycleTimes/100;
								$Gadget.displayPromRemainAmountInfo.banlance = vali.banlance/100;
							}
						});
					}
				}
			}, $Gadget);
		}
	},
	
	getOfferingAttrValue: function($Gadget, attrCode) {
		var key = "";
		var label = "";

		if ($Gadget.offerdetailresp.body.offeringInfo.attributeGroups && $Gadget.offerdetailresp.body.offeringInfo.attributeGroups.length > 0) {
			var len = $Gadget.offerdetailresp.body.offeringInfo.attributeGroups.length;
			var groups = $Gadget.offerdetailresp.body.offeringInfo.attributeGroups;
			for (var i = 0; i < len; i++) {
				if (groups[i].showGroup && groups[i].attributes && groups[i].attributes.length > 0) {
					var attrs = groups[i].attributes;
					for (var j = 0; j < attrs.length; j++) {
						if (attrs[j].attrCode == attrCode) {
							key = attrs[j].newValue;
							var optionItems = $.parseJSON(attrs[j].optionItems);

							if (key == "" || key == null || key == undefined) {
								key = attrs[j].defaultValue;
							}

							if (key == "" || key == null || key == undefined) {
								for (var k = 0; k < attrs[j].options.length; k++) {
									if (attrs[j].options[k].selected == true) {
										key = attrs[j].options[k].key;
										break;
									}
								}
							}

							if (key && key != "" && optionItems && optionItems.length > 0) {
								for (var a = 0; a < optionItems.length; a++) {
									if (optionItems[a].VALUE == key) {
										label = optionItems[a].LABEL;
										break;
									}
								}
							}

							break;
						}
					}
					if (key != "" && label != "") {
						break;
					}
				}
			}
		}

		return label;
	},
	
	getDictValueBykey: function(options, key){
		var result = "";
		$.each(options || [], function(i, vali){
			if (vali.key == key){
				result = vali.value;
			}
		});
		return result;
	},
	
	//商品化宽带业务与飞享套餐业务商品详情页点击营销活动类目
    clickPromotionOfferItem : function($Page, $Gadget, $Fire, $Item){
    	debugger;
    	$UI = $Gadget.$Get("$UI");
    	$Fire({
				service: 'bes.agentdesktop.promotionservice/querylevelbaseinfobyofferingid',
				params: {
					"offeringid": $Item.offeringId
				},
				target: '$Gadget.detailData.PromotionList',
				onafter: function($Page, $Gadget, $UI) {
					debugger;
					if (null == $Gadget.detailData.PromotionList) {
						$UI.msgbox.warning("提示", "该活动没有档次信息。");
						return;
					}
					$Promotion = $Gadget.detailData.PromotionList[0];
					$Item.offerClassCode ="PROM_TYPE";
					$Controller.bes.oc.productorder.checkLevelDetail($Page,$Item, $Promotion,$Gadget,$Fire,$UI);
				}
			}, $Gadget);
    },
	clickOfferingSetItem: function($Page, $Gadget, $Fire, $Item){
        debugger;
        
        if ($Page.isOfferSJJ == 1) {			
        	$Page.offeringSetSelected = $Item;
        	//$Page.data = $Page.data || {};
        	//$Page.data.offeringId = $Item.offeringId;
        }
		if ($Gadget.offeringSetSelectedId == $Item.offeringId || ($Gadget.$Attrs.displayoldname == 'Y' && $Item.offeringId == $Gadget.$Attrs.offeringid)){
			return;
		}
        
		dontTouchDataOfWholePage();
		$Gadget.offeringSetSelectedId = $Item.offeringId;
		try {
        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
        } catch (e) {
        	debugger;
        }
		$Fire({
			service : "ucec/v1/offering/offeringdetail_query",
			params : {
				header : {},
				body : {
					offeringId : $Item.offeringId
				}
			},
			target : "$Gadget.offerdetailresp",
			onafter : function() {
				debugger;
				$Gadget.offeringInfo = (($Gadget.offerdetailresp||{}).body || {}).offeringInfo;
				if($Gadget.offeringInfo){
					var priceValue = adutil.getDisplayPrice($Gadget.offeringInfo.lowPrice,$Gadget.offeringInfo.highPrice);
					var monthlyFee = adutil.getDisplayPrice($Gadget.offeringInfo.monthlyFee);
					if (priceValue == "￥0.00" || priceValue == "￥0.00-0.00")
					{
						priceValue = "";
					}
					$Gadget.offeringInfo.priceValue = priceValue;
					if (monthlyFee == "￥0.00" || monthlyFee == "￥0.00-0.00")
					{
						monthlyFee = "";
					}
					$Gadget.offeringInfo.monthlyFee = monthlyFee;
				}
				//商品详情页切换套餐规格时刷新归属的活动
				$Fire({
					service : "/bes.agentdesktop.promotionservice/querypromotionlistbyofferingid",
					params : {
					offeringid : $Item.offeringId
						},
					target : "$Gadget.promotionList",
				}, $Gadget);
				// 如果是开户组使用该组件,则调用queryofferdetail接口
				if ($Gadget.$Attrs.usesource == "fromOpenAcct"){
					try {
			        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
			        } catch (e) {
			        	debugger;
			        }
					$Fire(
							{
								service : 'bes.oc.queryofferdetailservice/queryofferdetail',
								params : {
									"offerid" : $Item.offeringId
								},
								target : '$Gadget.offerInfoPOJO',
								onafter : function() {
									// 清空offer信息
									$Gadget.$Attrs.refresh.refreshFlag = false;
									adutil.clearObj($Gadget.$Attrs.model);
									$Gadget.$Attrs.validate.length = 0; // 清空校验器
									$.extend(true, $Gadget.$Attrs.model, $Gadget.offerInfoPOJO);
									$Gadget.$Get('$timeout')(function(){
										$Gadget.$Attrs.refresh.refreshFlag = true;
										youCanTouchDataOfWholePage();
								    },1);
								}
							}, $Gadget);
					
				} else {
					// 清空offer信息
					$Gadget.$Attrs.refresh.refreshFlag = false;
					adutil.clearObj($Gadget.$Attrs.model);
					$Gadget.$Attrs.validate.length = 0; // 清空校验器
					
					$.each($Gadget.$Attrs.model, function(i, val){  delete xx[i]; });
					$.extend(true, $Gadget.$Attrs.model, $Gadget.offeringInfo);
					$Gadget.$Attrs.model.attributeGroups = $Gadget.$Attrs.model.attributeGroups ||[];
					$Gadget.$Attrs.model.wiredProdAttr = $Gadget.$Attrs.model.wiredProdAttr || {};
					$Gadget.$Attrs.model.effectiveWay = $Gadget.$Attrs.model.effectiveWay||{};
					$Gadget.$Attrs.model.expirationWay = $Gadget.$Attrs.model.expirationWay ||{};
					$Gadget.$Attrs.model.subOfferings  = $Gadget.$Attrs.model.subOfferings||[];
					$Gadget.$Attrs.model.deviceRecvOfferingList = $Gadget.$Attrs.model.deviceRecvOfferingList||[];
					$Gadget.$Attrs.model.relationOfferings = $Gadget.$Attrs.model.relationOfferings ||[];
					$Gadget.$Attrs.model.resource = $Gadget.$Attrs.model.resource ||[];
					$Gadget.$Attrs.model.productIdentitys = $Gadget.$Attrs.model.productIdentitys ||[];
					
					$Gadget.$Get('$timeout')(function(){
						$Gadget.$Attrs.refresh.refreshFlag = true;
						youCanTouchDataOfWholePage();
				    },1);
				}
				try {
		        	OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId());
		        } catch (e) {
		        	debugger;
		        }
				$Fire({
					service : 'ucec/v1/offering/offeringattributes_query',
					params : {
						header : null,
						body : {
							offeringId : $Item.offeringId
						}
					},
					target : '$Gadget.productAttrs',
					onafter : function() {
						debugger;
						if ($Gadget.productAttrs && $Gadget.productAttrs.body) {

						} else {
							return;
						}
						var commattr = $Gadget.productAttrs.body.attributeGroups
								|| [];
						//$Gadget.offeringInfo.attributeGroups = $.extend(true,[],commattr);
						//$.extend(true, $Gadget.$Attrs.model, $Gadget.offeringInfo);
						$Gadget.$Attrs.model.attributeGroups = $.extend(true,[],commattr);
						
						$.each(commattr||[],function(i,val){
							$.each(val.attributes||[],function(j,valj){
								if (valj.attrCode == "bandSpeed"){
									$Gadget.offeringInfo.bandSpeed = 
										$Controller.bes.ad.personalofferinginfo.getDictValueBykey(valj.options, valj.newValue);
								}
							});
						});
					}
				}, $Gadget);
				
				if ($Gadget.offeringInfo.classificationId == "5214"){
					 $Gadget.offeringInfo.quantity = 1;
                    
					 $Gadget.data.totalPrice =  $Gadget.offeringInfo.priceValue;
					 $Controller.bes.ad.personalofferinginfo.queryChargeOfferingAttributes($Gadget, $Gadget.$Attrs.offeringid); 
                    
					 $Controller.bes.ad.personalofferinginfo.updatePurchaseNumber($Gadget);
				}
			},
			onerror: function() {
				debugger;
				youCanTouchDataOfWholePage();
			}
		}, $Gadget);
	},
	 
	queryChargeOfferingAttributes : function($Gadget, offeringId)
	{
           debugger;
           $Gadget.data.displayPurchaseNumber = true;
           try {
           	OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getNextFireId());
           } catch (e) {
           	debugger;
           }
           $Fire = $Gadget.$Get('$Fire');
           $Fire({
               service:"ucec/v1/offering/qryuninstantiableattributes",
               params:{
                   header : null,
                   body : {
                       offeringId : offeringId,
                       attributesCodes :[
                           "PM_UNIT",
                           "PM_UNIT_VALUE"
                       ]
                   }
               },
               target:'$Gadget.chargeOfferingAttrs',
               onafter:function(){
                   debugger;
                   var attributeList = (($Gadget.chargeOfferingAttrs||{}).body||{}).attributes;
                   
                   $.each(attributeList||[],function(i,val){
                       if(val.attrCode == "PM_UNIT"){
                           $Gadget.data.pmUnit = val.defaultValue;                           
                       }
                       if(val.attrCode == "PM_UNIT_VALUE"){
                           $Gadget.data.pmUnitValue = val.defaultValue;                           
                       }                       
                   });               
               }                         
           },$Gadget);
        
    },
   
    updatePurchaseNumber : function( $Gadget)
    {
        debugger;
        
        var num = Number($Gadget.offeringInfo.quantity)
                * Number($Gadget.data.pmUnitValue);

        $('#orderNum').val("" + num.toString());
    },
    
    updateTotalPrice : function( $Gadget)
    {
        debugger;
      
        var minValue = $Gadget.offeringInfo.lowPrice;
      
        var totalPrice = minValue * $Gadget.offeringInfo.quantity;
      
        $Gadget.data.totalPrice = adutil.getDisplayPrice(totalPrice);
    },

    minusbtnClick : function($Gadget)
    {
        var num = $.trim($('#orderNum').val());

        num = Number(num) - Number($Gadget.data.pmUnitValue);

        if (num > 0)
        {
            $('#orderNum').val("" + num.toString());             
             
            $Gadget.offeringInfo.quantity = num/$Gadget.data.pmUnitValue;    
            $.extend($Gadget.$Attrs.model, $Gadget.offeringInfo);
            $Gadget.$Attrs.model = $Gadget.offeringInfo;
        }

        this.updateTotalPrice( $Gadget);
    },

    inputnum : function( $Gadget,$UI)
    {
        debugger;

        var num = $.trim($('#orderNum').val());

        if (this.verifyNumber($Gadget,num))
        {              
            $Gadget.offeringInfo.quantity = num/$Gadget.data.pmUnitValue; 
            
            this.updateTotalPrice($Gadget);
        }
        else 
        {
            $('#orderNum').val("" + $Gadget.offeringInfo.quantity * $Gadget.data.pmUnitValue);
        }
    },

    addbtnClick : function( $Gadget)
    {
        debugger;

        var num = $.trim($('#orderNum').val());

        num = Number(num) + Number($Gadget.data.pmUnitValue);

        $('#orderNum').val("" + num.toString());

        $Gadget.offeringInfo.quantity = num/$Gadget.data.pmUnitValue;       
        $.extend($Gadget.$Attrs.model, $Gadget.offeringInfo);
        this.updateTotalPrice( $Gadget);
    },

    // 数字验证
    verifyNumber : function($Gadget,number)
    {
        if (number.length == 0)
        {
            return false;
        }
        var verify = new RegExp("^[0-9]*$").test(number);

        if(verify) {
            verify = ((number % $Gadget.data.pmUnitValue) == 0);
        }

        return verify;
    } 
    
});