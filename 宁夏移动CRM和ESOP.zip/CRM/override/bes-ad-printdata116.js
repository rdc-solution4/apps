$Controller("bes.oc.printdata", {
	init : function($Page, $Gadget) {
		debugger;
		var printCell = document.getElementById('CellWeb');
		printCell.Login("华为技术有限公司", "", "13100104539",
				"6140-1517-0123-3005");

		if (!$Gadget.data.besOcPrintData) {
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.person.message.NoACKSlipData'));  //提示   //没有免填单数据
			return false;
		}//获取系统参数值
        $Gadget.$Get("$Fire")({
            'service' : 'ucec/v1/common/qrysystemparambykey',
            'params' : {
				key : "PrintCount"
            },
            'target' : '$Gadget.PrintCount',
            onafter : function() {
				debugger;

				// 如果值为空或者值为0则默认给1
				if (!$Gadget.PrintCount || $Gadget.PrintCount == "" || $Gadget.PrintCount == null|| $Gadget.PrintCount == 0) {
					$Gadget.PrintCount = 1;
				}
				for(var i=0;i<$Gadget.PrintCount;i++){
					$Controller.bes.oc.printdata.pagePrint($Page, $Gadget, printCell);
				}
            },
			onerror: function() {
				$Controller.bes.oc.printdata.pagePrint($Page, $Gadget, printCell);
			}
        }, $Gadget);
	},
	
	jasperReportPrint : function($Page, $Gadget) {
		debugger;
		if (!$Gadget.data.besOcPrintData) {
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.person.message.NoACKSlipData'));  //提示   //没有免填单数据
			return false;
		}
	
		debugger;
		$Fire({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				"key" : "JASPERREPORT_DEST_URL"
			},
			target : "$Page.jasperReportDestUrl",
			onafter : function() {
				debugger;
				if($Page.jasperReportDestUrl){
					document.getElementById("printData").value = JSON.stringify($Gadget.data.besOcPrintData);
					var forms = document.getElementById("printDataForm");
					forms.action = $Page.jasperReportDestUrl;
					forms.submit();
				}
				else{
					var pathName = document.location.pathname;
					var index = pathName.substr(1).indexOf("/");
					var result = pathName.substr(0, index + 1);
					$Page.jasperReportDestUrl = window.location.protocol + "//"
							+ window.location.host + result + "/JasperReportPrint"

					document.getElementById("printData").value = JSON.stringify($Gadget.data.besOcPrintData);
					var forms = document.getElementById("printDataForm");
					forms.action = $Page.jasperReportDestUrl;
					forms.submit();
				}
			}
		}, $Gadget);	
		
	},

	// 
	jasperReportAgreementPrint : function($Page, $Gadget) {
		debugger;
		
		var protocolType = "A";
		
		if (!$Gadget.data.besOcPrintData) {
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.person.message.NoACKSlipData'));  //提示   //没有免填单数据
			return false;
		}
		
		if(true)
		{
			debugger;
			$Gadget.data.besOcPrintData[1].cellFileName = $Gadget.data.besOcPrintData[0].cellFileName.split(".")[0]+"_Agree.jasper";
		}
		
		
		var printDataList = [];
		
		for (var i=0;i<$Gadget.data.besOcPrintData.length;i++)
		{
			if($Gadget.data.besOcPrintData[i].protocolType == protocolType)
			{
				debugger;
				printDataList.push($Gadget.data.besOcPrintData[i]);
			}
		}
	
		debugger;
		$Fire({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				"key" : "JASPERREPORT_DEST_URL"
			},
			target : "$Page.jasperReportDestUrl",
			onafter : function() {
				debugger;
				if($Page.jasperReportDestUrl){
					document.getElementById("printData").value = JSON.stringify(printDataList);
					var forms = document.getElementById("printDataForm");
					forms.action = $Page.jasperReportDestUrl;
					forms.submit();
				}
				else{
					var pathName = document.location.pathname;
					var index = pathName.substr(1).indexOf("/");
					var result = pathName.substr(0, index + 1);
					$Page.jasperReportDestUrl = window.location.protocol + "//"
							+ window.location.host + result + "/JasperReportPrint"

					document.getElementById("printData").value = JSON.stringify(printDataList);
					var forms = document.getElementById("printDataForm");
					forms.action = $Page.jasperReportDestUrl;
					forms.submit();
				}
			}
		}, $Gadget);	
	},
	
	// 发票打印
	printInvoice : function($Page, $Gadget) {
		debugger;
		$Gadget.$Get("$Fire")({
			service : "ucec/v1/common/qrysystemparambykey",
			params : {
				key: "OH4TELECOM_SUBID_FLAG"
			},
			target : "$Gadget.NingXia",
			onafter: function() {
				debugger;
				var printCell = document.getElementById('CellWeb');
				//yubin add 20160705 增加异常保护
				try
				{		
			  	printCell.Login("华为技术有限公司", "", "13100104539",
						"6140-1517-0123-3005");
				}
				catch(e){
					$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.PrintedFailed"));//"提示","调用控件失败");
					return false;
				}					

				if (!$Gadget.data.besOcPrintData) {
					$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.PrintedDataFailed"));//"提示","没有发票打印数据或发票出库失败，请核对后台数据，并在发票补打页面补打发票。");
					return false;
				}

				var printDataArr = $Gadget.data.besOcPrintData;
				if($Gadget.NingXia == "NXYD_SUBID" && $Page.projectVersion == 'NINGXIA'){
					for ( var i = 0; i < printDataArr.length; i++) {
						if (i > 0) {
							$Controller.bes.oc.printdata.clearInvoice(printCell);
						}
						if(printDataArr[i].invoiceType == "R" || printDataArr[i].invoiceType =='2'){
							var cellFileName = printDataArr[i].cellFileName;
							printCell.openfile("c:\\" + cellFileName, '');
							var printData = printDataArr[i];
							if (printData.invoiceType == '2') {
								$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.TietongUser"),//"提示","用户是铁通用户，请更换铁通发票。",
										function() {
											$Controller.bes.oc.printdata.printSheetData(
													printCell, printData);
										});
							} else {
								$Controller.bes.oc.printdata.printSheetData(printCell,
										printData);
							}
						}
						if($Page.curResCondition == "invoicePageRes" && printDataArr[i].invoiceType == "1"){
							var cellFileName = printDataArr[i].cellFileName;
							printCell.openfile("c:\\" + cellFileName, '');
							var printData = printDataArr[i];
							if (printData.invoiceType == '2') {
								$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.TietongUser"),//"提示","用户是铁通用户，请更换铁通发票。",
										function() {
											$Controller.bes.oc.printdata.printSheetData(
													printCell, printData);
										});
							} else {
								$Controller.bes.oc.printdata.printSheetData(printCell,
										printData);
							}
						}
					}
					//yubin add 20160705 增加打印成功提示
				  $Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n("ad.person.message.printsuccess"));		
				}
				else
				{
					for ( var i = 0; i < printDataArr.length; i++) {
						var cellFileName = printDataArr[i].cellFileName;
						if (i > 0) {
							 $Controller.bes.oc.printdata.clearInvoice(printCell);
						}
						printCell.openfile("c:\\" + cellFileName, '');
						var printData = printDataArr[i];
						if (printData.invoiceType == '2') {
							$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.TietongUser"),//"提示","用户是铁通用户，请更换铁通发票。",
									function() {
										$Controller.bes.oc.printdata.printSheetData(
												printCell, printData);
									});
						} else {
							$Controller.bes.oc.printdata.printSheetData(printCell,
									printData);
						}
					}
					//yubin add 20160705 增加打印成功提示
					$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.person.message.information'), $UEE.i18n("ad.person.message.printsuccess"));		
				}
				
			}
		}, $Gadget);
	},

	printSheetData : function(printCell, printData) {
		debugger;
		var printCellInfoArr = printData.printCellInfoList;

		for ( var j = 0; j < printCellInfoArr.length; j++) {
			// 设置每个单元格打印信息
			var cellarr = printCellInfoArr[j];
			this.setCellInfo(cellarr, 0, printCell);
		}
		printCell.PrintSheet(0, 0);
	},

	pagePrintReview : function($Page, $Gadget, printCell) {
		debugger;
		$Controller.bes.oc.printdata.setDefaultDataForPreview($Page, $Gadget,
				printCell);
	},

	printPreview : function($Page, $Gadget, printCell) {
		debugger;
		//var printCell = document.all['CellWeb'];
		var printCell = document.getElementById('CellWeb');
		printCell.Login("华为技术有限公司", "", "13100104539",
				"6140-1517-0123-3005");

		if (!$Gadget.data.besOcPrintData) {
			$Gadget.$Get('$UI').msgbox.info($UEE.i18n('ad.sr.message.TS'), $UEE.i18n('ad.sr.message.MYMTDSJ'));  //没有免填单数据。 //提示
			return false;
		}
		$Controller.bes.oc.printdata.setDefaultDataForPreview($Page, $Gadget,
				printCell);
	},

	setDefaultDataForPreview : function($Page, $Gadget, printCell) {
		var printDataArr = $Gadget.data.besOcPrintData;
		var cellFileName = printDataArr[0].cellFileName;
		printCell.openfile("c:\\" + cellFileName, '');
		// printCell.InsertSheet(0,2);
		for ( var i = 0; i < printDataArr.length; i++) {
			if (i > 0) {
				this.clearInvoice(printCell);
			}
			var printCellInfoArr = printDataArr[i].printCellInfoList;

			for ( var j = 0; j < printCellInfoArr.length; j++) {
				// 是否打印标识
				// 设置每个单元格打印信息
				var cellarr = printCellInfoArr[j];
				this.setCellInfo(cellarr, 0, printCell);
			}
			printCell.PrintPreview(1, 0);
		}
	},

	setDefaultDataForPrint : function($Page, $Gadget, printCell) {
		var printDataArr = $Gadget.data.besOcPrintData;
		for ( var i = 0; i < printDataArr.length; i++) {
			var cellFileName = printDataArr[i].cellFileName;
			if (i > 0) {
				this.clearInvoice(printCell);
			}
			printCell.openfile("c:\\" + cellFileName, '');
			var printCellInfoArr = printDataArr[i].printCellInfoList;

			for ( var j = 0; j < printCellInfoArr.length; j++) {
				// 设置每个单元格打印信息
				var cellarr = printCellInfoArr[j];
				this.setCellInfo(cellarr, 0, printCell);
			}
			printCell.PrintSheet(0, 0);
		}
	},

	setCellInfo : function(printCellInfo, sheet, printCell) {
		if (!printCellInfo.protocolContent) {
			return;
		}
		var posx = printCellInfo.posx;
		var posy = printCellInfo.posy;

		// 10.String protocolContent;
		printCell.SetCellString(parseInt(posy), parseInt(posx), sheet,
				printCellInfo.protocolContent);

		// 1.align 排列
		if (printCellInfo.align && printCellInfo.align != 0) {
			printCell.SetCellAlign(parseInt(posy), parseInt(posx), sheet,
					parseInt(printCellInfo.align));
		}

		// 2.字体格式 fontModel TODO

		// 3.字体大小
		if (undefined != printCellInfo.fontSize
				&& null != printCellInfo.fontSize) {
			printCell.SetCellFontSize(parseInt(posy), parseInt(posx),
					sheet, parseInt(printCellInfo.fontSize));
		}

		// 4.字体 fontType 为字体数组的索引号 可用函数FindFontIndex()得到，-1为缺省字体，>=0为字体序号 TODO
		if (printCellInfo.fontType) {
			var para = printCell.FindFontIndex(printCellInfo.fontType, 1);
			printCell.SetCellFont(parseInt(posy), parseInt(posx), sheet,
					parseInt(para));
		}

		/*
		 * // 5.BigDecimal height; TODO if (printCellInfo.height) {
		 * printCell.SetRowHeight(0, parseInt(printCellInfo.height),
		 * parseInt(posx), sheet); } // 6.BigDecimal width; TODO if
		 * (printCellInfo.width) { printCell.SetColWidth(0,
		 * parseInt(printCellInfo.width), parseInt(posy), sheet); }
		 */

		// 7.字体颜色 String fontColor TODO;
		if (printCellInfo.fontColor) {
			// printCell.SetCellTextColor(parseInt(posy), parseInt(posx), sheet, parseInt(printCellInfo.fontColor));
			printCell.SetCellTextColor(parseInt(posy), parseInt(posx), sheet, printCell.FindColorIndex(this.jsRGB(printCellInfo.fontColor), 1));
		}

		// 8.字体属性 BigDecimal fontStyle TODO BOLD 加粗 0或者空为普通
		if (printCellInfo.fontStyle) {
			printCell.SetCellFontStyle(parseInt(posy), parseInt(posx),
					sheet, parseInt(printCellInfo.fontStyle));
		}

		// 9.是否排重 BigDecimal isUnion 不需要关注

		/*
		 * // 打印区域String printArea; PrintRangeEx (col1 As Long, row1 As Long,
		 * col2 As Long, row2 As Long,sheet As Long)
		 * printCell.PrintRangeEx(parseInt(posy), parseInt(posx), 0, 0,
		 * sheet);
		 */
	},

	pagePrint : function($Page, $Gadget, printCell) {
		debugger;
		$Controller.bes.oc.printdata.setDefaultDataForPrint($Page, $Gadget,
				printCell);
	},

	clearInvoice : function(printCell) {
		for ( var i = 1; i < 100; i++) {
			for ( var j = 1; j < 6; j++) {
				printCell.SetCellString(j, i, 0, "");
			}
		}
	},
	
	/**
	 * 计算RGB值
	 */
	jsRGB: function(rgb) {
		var colors = rgb.split(",");
		if (colors.length != 3 || rgb == "0")
		{
			// 配置不对 默认为1 黑色
			return 1;
		}
		var r = trimStr(colors[0]);
		var g = trimStr(colors[1]);
		var b = trimStr(colors[2]);
		return b*65536 + g*256 + r;
		
		function trimStr(str){
			return str.replace(/(^\s*)|(\s*$)/g,"");
		}
	}
});
