$Controller("bes.ad.productattrchange", {
	init : function($Page, $Gadget, $Fire) {
        debugger;

        // c00311908 数据初始化 start
		if ($Page.dictList["OC_NBIOT_SIXMINUTE"])
		{
			$Page.SIXMINUTE = angular.copy($Page.dictList["OC_NBIOT_SIXMINUTE"]);
			$.each($Page.SIXMINUTE || [], function(t,valt){
				valt.selected = false;
			});
		}
		if ($Page.dictList["OC_NBIOT_TENMINUTE"])
		{
			$Page.TENMINUTE = angular.copy($Page.dictList["OC_NBIOT_TENMINUTE"]);
			$.each($Page.TENMINUTE || [], function(t,valt){
				valt.selected = false;
			});
		}
		if ($Page.dictList["OC_NBIOT_ONEHOUR"])
		{
			$Page.ONEHOUR = angular.copy($Page.dictList["OC_NBIOT_ONEHOUR"]);
			$.each($Page.ONEHOUR || [], function(t,valt){
				valt.selected = false;
			});
		}
		if ($Page.dictList["OC_NBIOT_TENHOURS"])
		{
			$Page.TENHOUR = angular.copy($Page.dictList["OC_NBIOT_TENHOURS"]);
			$.each($Page.TENHOUR || [], function(t,valt){
				valt.selected = false;
			});
		}
		// c00311908 数据初始化 end

        $Gadget.hasAttrToShow = false;
        $Gadget.effectShowFlag = [];

        $Gadget.attrpasswordShowFlag = {};
        $Gadget.attrpasswordGadget = {};

        $Gadget.effectCondition = [ {
            key : "I",
            value : $UEE.i18n("ad.person.message.TakeEffectThisMonth"),//本月生效
            selected : true
        }, {
            key : "N",
            value :  $UEE.i18n("ad.person.message.TakeEffectNextMonth")//次月生效
        } ];
		if($Page.projectVersion == "NINGXIA"){
			$Gadget.$Get('$Fire')({
				service : "/common/dictkey",
				params : {
					"dictkeylist" : ['CheckPOCDiscount']
				},
				target : '$Gadget.hdjDictList',
				onafter : function($Gadget) {
					debugger;
					$Gadget.CheckPOCDiscountList = $Gadget.hdjDictList["CheckPOCDiscount"];
				},
			}, $Gadget);
		}
        $Controller.bes.ad.productattrchange.initCommAttr($Page, $Gadget, $Fire);
        $Gadget.$Attrs.validate.push(function() {
            debugger;
            return $Controller.bes.ad.productattrchange.productattrCheckValidate($Gadget);
        });

        if($Gadget.attrpasswordShowFlag.password){
        	$Gadget.$Attrs.validate.push(function() {
                debugger;
                return $Controller.bes.ad.productattrchange.attrpasswordValidate($Gadget,$Gadget.$Get('$UI'));
            });

        }

        // 添加关联上网伴侣校验
        try {
            if ($Page.data.offeringinfo.product[0].prodType == 'PTSWBL') {
                $Gadget.$Attrs.validate.push(function() {
                    debugger;
                    return $Controller.bes.ad.productattrchange.swblValidate($Gadget);
                });
            }
        } catch (error) {
            return;
        }

        // 国际漫游校验
        try {
            if ($Page.data.offeringinfo.product[0].prodType == 'InternetRoaming') {
                $Gadget.$Attrs.validate.push(function() {
                    debugger;
                    return $Controller.bes.ad.productattrchange.interRomCheckValidate($Gadget);
                });
            }
        } catch (error) {
            return;
        }

        // 健体助手置灰
        try {
            if ($Page.data.offeringinfo.product[0].prodType == 'PTJKZS') {
                $Gadget.$Attrs.validate.push(function() {
                    debugger;
                    setTimeout(function(){
           			 $("#group_commAttrs_conts_productattrdisplay input").attr("readonly","readonly");
           			 $("#group_commAttrs_conts_productattrdisplay input").css('background','#f8f8f8');
           		 },10);
                });
            }
        } catch (error) {
            return;
        }

    },
	// 初始化属性信息
	initCommAttr : function($Page, $Gadget, $Fire) {
		debugger;
		// $Gadget.commattr = $Gadget.$Attrs.model;
		$Gadget.commattr = $.extend(true, [], $Gadget.$Attrs.model) || [];

		if ($Gadget.commattr.length > 0) {
			debugger;
			if($Page.projectVersion == "NINGXIA"){
				$Controller.bes.ad.productattrchange.initUserWhiteNum($Gadget, $Fire, $Page);
			}
			// 已经从外面获取了属性数据，不需要再调用UCEC了
			$.each($Gadget.commattr || [], function(i, val) {
				val.hasAttributesToShow = false;
				$.each(val.attributes || [], function(j, valj) {

					if (!adutil.filterOcPcOfferingAttributeEnable(valj.ocPcOfferingAttributeEnableVA,$Gadget.$Attrs.opertype)){
	        			valj.showType = 'HIDDEN';
	        		}

					if (valj.showType != 'HIDDEN') {
						val.hasAttributesToShow = true;
	        			$Gadget.hasAttrToShow = true;
	        		}

					if (valj.showType == 'MULTI_SEL') {
						if (valj.newValue) {
							valj.newValue = valj.newValue.split(",");
						}
					}
					if(valj.effectMode == 'N'){
                        $Gadget.effectShowFlag[j] = 'I';
                    }

					//宁夏国长与国漫商品
					if ($Page.projectVersion== "NINGXIA" && (valj.attrCode == 'GuoJiHuJiaoTianShu' || valj.attrCode == 'ManYouTianShu')){
                        valj.isModify = true;
						valj.isModify = false;
                        valj.options=[{'key':'30', 'value':'30'},{'key':'180', 'value':'180'},{'key':'360', 'value':'长期(360)'}];
                    }

					// 是否实名制校验
					if (valj.attrCode == 'PM_IS_REALUSER') {
						$Gadget.attrPhoneRealuserFlag = true;
					}

					//车联网特殊日期处理   实例的值是 yyyyMMddHHmmss
					if ((valj.attrCode == 'ServiceStartDateTime' || valj.attrCode == 'ServiceEndDateTime')
							&& (valj.showType == 'TIME' || valj.showType == 'DATE')) {
						var newValue =  valj.newValue;
						try{
							if(null !=  valj.newValue && valj.newValue.length == 14){
								var year = newValue.substring(0,4);
								var month = newValue.substring(4,6) - 1;
								var day = newValue.substring(6,8);
								var hour = newValue.substring(8,10);
								var min = newValue.substring(10,12);
								var second = newValue.substring(12,14);
								valj.newValue = new Date(year,month,day,hour,min,second).getTime();
								valj.oldValue = valj.newValue;
							}
						}
						catch(e){

						}
					}
					// 是否需要鉴权
					if (valj.attrCode == 'PM_IS_AUTHOR') {
						$Page.attrPhoneAuthorFlag = true;
					}

					if (valj.attrCode == 'ANXINGKA_IS_INTERNET') {
                        $Controller.bes.ad.productattrchange.inputdisabled($Gadget, valj);
                    }

					if (valj.showType == 'PASSWORD'){
						$Gadget.attrpasswordShowFlag.password = true;

						$Gadget.attrpasswordGadget = {};
						$Gadget.attrpasswordGadget.password = valj.newValue;
						$Gadget.attrpasswordGadget.passwordRep = valj.newValue;
						//MODIFY 2015-11-03 by l0028967 DTS2015110203299
						$Gadget.attrpasswordGadget.passwordForCompare = valj.oldValue;
						$Gadget.attrpasswordShowFlag.passwordHideStar = !!valj.isNullable;
						$Gadget.attrpasswordShowFlag.validaterule = valj.verificationRule;

						// 监控密码属性值的变化
						$Gadget.$watch(function(){
							return $Gadget.attrpasswordGadget;
						}, function(newValue,oldValue,scope){
							if (newValue){
								$.each($Gadget.commattr||[],function(i,val){
									$.each(val.attributes||[],function(j,valj){
										if (valj.showType == "PASSWORD"){
											valj.newValue = newValue.password;
										}
									});
								});
							}
						}, true);
					}
					//yubin add 20160722 增加金额处理，需要做展示数据转换
					if(valj.showType == 'CURRENCY'){
					       valj.newValue = parseFloat(adutil.getPriceByPrecision(adutil.approxPrice(valj.newValue)));
					 }
					// 实现了对属性的 APNPackageFlag 判断
                    if(valj.attrCode == "APNPackageFlag" || valj.attrCode == "APNPackageFlag4XS" ){
                        // 否存在“车联网APN1流量套餐产品包（I00010100150）”或者“车联网APN2流量套餐产品包（I00010100160）”两个商品包中
                        if($Controller.bes.ad.productattrchange.isBelogTelematicsOffering($Gadget,$Page)){
                            // APNPackageFlag
                            // 展示四个附加属性(APNNAME、Discount、ApprovalNum、CanShare)
                            // APNPackageFlag4XS
                            // 展示3个附加属性(APNNAME、Discount、ApprovalNum)
                            $.each($Gadget.commattr||[],function(i,val){
                                $.each(val.attributes||[],function(k,valk){
                                 if("APNNAME" != valk.attrCode && "Discount" != valk.attrCode && "ApprovalNum" != valk.attrCode){
                                    if(valj.attrCode == "APNPackageFlag" && "CanShare" != valk.attrCode){
                                        valk.showType = "HIDDEN";
                                    }else if(valj.attrCode == "APNPackageFlag4XS"){
                                        valk.showType = "HIDDEN";
                                    }
                                 }
                             });
                            });

                        }else{
                            $.each($Gadget.commattr||[],function(i,val){
                                    $.each(val.attributes || [], function(k, valk) {
									if ("Discount" != valk.attrCode) {
										valk.showType = "HIDDEN";
									}
								});
                            });
                        }
                    }

                    //IsOrderBusiStrategy”，如果是，则根据“是否配置业务策略”（IsOrderBusiStrategy的值展示页面元素。如果值为“否”，则只展示“APNNAME”商品附加属性。如果值为“是”, 则显示所属性
                    if(valj.attrCode == "IsOrderBusiStrategy" && (valj.newValue == "0")){
                    // 商品编码是否是 数据通信产品I00010100085 判空
	                    if($Page.isDataOffering){
	                    	$Page.isDataOffering = null;
	                        $.each($Gadget.commattr || [], function(i, val) {
								$.each(val.attributes || [], function(k, valk) {
									if ("APNNAME" != valk.attrCode) {
										valk.showType = "HIDDEN";
									}
								});
							});
	                    }
                    }

                    // c00311908 NB-IOT节点属性优化 start
                    // 没有实例化时才可以变更，否则不可变更
                    if (valj.attrCode == "APNNAME" && valj.attrInstId)
                    {
                    	valj.isModify = false;
                    }

                    if (valj.attrCode == "APNNAME" && !valj.attrInstId)
        			{
                    	debugger;
        				// apnname
        				valj.onValueChange = function($Gadget, jEvent){
        					debugger;
        					var $Item = $(jEvent.$Target).scope().$ChildItem;
        					var apnname_lowpowermode = $Page.dictList["OC_APNNAME_LOWPOWERMODE"];
        					if (!apnname_lowpowermode)
        					{
        						return;
        					}

        					var apnName = $Item.newValue;
        					var lowPowerMode = '-1';
        					$.each(apnname_lowpowermode, function(t,valt){
        						if (valt.key == apnName)
        						{
        							lowPowerMode = valt.value;
        						}
        					});

        					$.each($Gadget.commattr||[], function(m,valm){
        						$.each(valm.attributes||[], function(n,valn){
	        						// 找到低功耗模式
	        						if (valn.attrCode == "LOWPOWERMODE")
	        						{
	        							// 如果为-1，则直接将低功耗模式改为可选，其值不变
	        							if (lowPowerMode == '-1')
	        							{
	        								valn.isModify = true;
	        								return;
	        							}

	        							$Gadget.isChange = false;
	        							if (valn.newValue && lowPowerMode == '-1'){
	        								// 如果原来就是-1了 标记出来 因为不会再触发记为null的操作了
	        								// 原来是正常值，变为非正常值时，要依靠自动触发
	        								$Gadget.isChange = true;
	        							}
	        							valn.isNullable = false;
	        							valn.isModify = false;
	        							valn.newValue = lowPowerMode;
	        							if (valn.newValue == '-1')
	        							{
	        								valn.isModify = true;
	        								// 不应该出现这种情况 当且仅当新配置的APNNAME没有配置对应的字典OC_APNNAME_LOWPOWERMODE
//	        								$Gadget.$Get('$UI').msgbox.error('错误','未找到该APNNAME对应的低功耗模式！');
	        								if (!$Gadget.isChange)
	        								{
	        									// 假change 要手动触发
	        									$Controller.bes.ad.productattrchange.onValueChange_LOWPOWERMODE($Gadget, null, valn);
	        								}
	        							}
	        							return;
	        						}
        						});
        					});
        				};
        			}

                    if (valj.attrCode == "IfSetPCRF")
        			{
                    	debugger;
        				valj.onValueChange = function($Gadget, jEvent){
        					debugger;
        					var $Item = $(jEvent.$Target).scope().$ChildItem;
        					var ifsetpcrf_controlattr = $Page.dictList["OC_CONTROL_ATTR"];
        					if (!ifsetpcrf_controlattr)
        					{
        						return;
        					}

        					var ifsetpcrf_offering = $Page.dictList["OM_SET_PCRF_OFFERING"];
        					if (!ifsetpcrf_offering)
        					{
        						return;
        					}
        					var offerflag = false;
        					var mainofferflag = false;
        					$.each(ifsetpcrf_offering||[],function(p,vap){
        						if (vap.description == $Gadget.$Attrs.offeringid || (vap.extMap ||{}).ext1 == $Gadget.$Attrs.offeringid){
        							offerflag = true;
        						}
        						if (vap.itemCode == $Page.selectedMainOfferingId 
        								|| (vap.itemCode == $Page.selectMainOfferingId && $Page.pcrfChangeFlag == "mainofferchange")
        								|| (vap.itemCode == ($Page.mainOffer || {}).offeringId && $Page.pcrfChangeFlag == "personofferchange")){
        							mainofferflag = true;
        						}
        					});
        					if (!offerflag || !mainofferflag){
        						return;
        					}

        					if($Item.newValue == "0"){
        						$.each($Gadget.commattr||[], function(m,valm){
            						$.each(valm.attributes||[], function(n,valn){
            							$.each(ifsetpcrf_controlattr||[],function(k,valk){
            								if(valn.attrCode == valk.key){
            									valn.newValue = null;
            									valn.defaultIsNullable = valn.defaultIsNullable || valn.isNullable;
                				        		valn.isNullable = true;
                				        		valn.defaultVerificationRule = valn.defaultVerificationRule || valn.verificationRule;
            									valn.verificationRule = "";
                								valn.isModify = false;
                								if (valn.showType == "SINGLE_SEL" || valn.showType == "TIME"){
                				        			valn.defaultShowType = valn.defaultShowType || valn.showType;
                				        			valn.showType='TEXT';
            					        			$.each(valn.optionArr || [], function(t,valt){
            						        			valt.selected = false;
            						        		})
            					        		}
            								}
            							});
            						});
        						});
        					}else{
        						$.each($Gadget.commattr||[], function(m,valm){
            						$.each(valm.attributes||[], function(n,valn){
            							$.each(ifsetpcrf_controlattr||[],function(k,valk){
            								if(valn.attrCode == valk.key){
            									valn.isModify = true;
            									if (!valn.defaultIsNullable || (valn.defaultVerificationRule || "").indexOf("required") >=0){
            										valn.isNullable = false;
                    								valn.verificationRule = valn.defaultVerificationRule;
            									}
            									if (valn.defaultShowType == "SINGLE_SEL"){
            										valn.showType = "SINGLE_SEL";
            					        		}
            					        		if (valn.defaultShowType == "TIME"){
            					        			valn.showType = "TIME";
            					        		}
            								}
            							});
            						});
        						});
        					}
        				};
        			}

        			if (valj.attrCode == "LOWPOWERMODE")
        			{
        				debugger;
        				// 低功耗模式 不可编辑
        				valj.isModify = false;
        				valj.options = valj.options || [];
        				valj.options.push({"key":'-1',"value":"请选择",selected:false});
        				valj.onValueChange = function($Gadget, jEvent){
        					debugger;
        					var $Item = $(jEvent.$Target).scope().$ChildItem;
        					if ($Item.newValue == "-1")
        					{
        						// 为空
        						$Item.newValue = null;
        					}

        					if($Item.newValue == "PSM" || $Item.newValue == "BOTH"){
        						$.each($Gadget.commattr||[], function(m,valm){
            						$.each(valm.attributes||[], function(n,valn){
            							if(valn.attrCode == "RAUTAUTIMER"){
            								valn.isModify = true;
            								valn.showType = 'SINGLE_SEL';
            								valn.isNullable = false;
            				        	}
            				        	if(valn.attrCode == "ACCURACY"){
            				        		valn.isModify = true;
            				        		valn.showType = 'SINGLE_SEL';
            				        		valn.isNullable = false;
            				        	}
            						});
        						});
        					}
        					else
        					{
        						$.each($Gadget.commattr||[], function(m,valm){
            						$.each(valm.attributes||[], function(n,valn){
            							if(valn.attrCode == "RAUTAUTIMER")
            				        	{
            								valn.newValue = null;
            								valn.isNullable = true;
            								valn.showType = "TEXT";
            								valn.isModify = false;
            				        	}
            				        	if(valn.attrCode == "ACCURACY")
            				        	{
            				        		valn.newValue = null;
            				        		valn.isNullable = true;
            				        		valn.showType = "TEXT";
            				        		valn.isModify = false;
            				        		$.each(valn.options || [], function(t,valt){
            				        			// 由于这里改了类型，不会再触发onChange事件，需要手动把数据改掉
            				        			valt.selected = false;
            				        		})
            				        	}
            						});
        						});
        					}
        				};
        			}
        			if (valj.attrCode == "ACCURACY")
        			{
        				debugger;
        				// 精度 不可编辑
        				if (!valj.newValue){
        					// 有值的情况下
        					valj.showType="TEXT";
        					valj.isNullable = true;
        					valj.isModify = false;
        				}
        				else
        				{
        					valj.showType="SINGLE_SEL";
        					// 精度值有值时，更新TAU的数据源
            				$.each($Gadget.commattr||[], function(m,valm){
        						$.each(valm.attributes||[], function(n,valn){
        							if(valn.attrCode == "RAUTAUTIMER")
            				    	{
            				    		if(valj.newValue == "0")
            				    		{
            				    			valn.options = $Page.SIXMINUTE;
            				    		}
            				    		else if(valj.newValue == "1")
            				    		{
            				    			valn.options = $Page.TENMINUTE;
            				    		}
            				    		else if(valj.newValue == "2")
            				    		{
            				    			valn.options = $Page.ONEHOUR;
            				    		}
            				    		else if(valj.newValue == "3")
            				    		{
            				    			valn.options = $Page.TENHOUR;
            				    		}

            				    	}
        						});
            				});
        				}
        				valj.onValueChange = function($Gadget, jEvent){
        					debugger;

        					var $Item = $(jEvent.$Target).scope().$ChildItem;
        					$.each($Gadget.commattr||[], function(m,valm){
        						$.each(valm.attributes||[], function(n,valn){
        							if(valn.attrCode == "RAUTAUTIMER")
            				    	{
        								// 先判断数据源是否相同，如果相同，则不处理了
        								if($Item.newValue == "0" && valn.options && (valn.options[0] || {}).key == $Page.SIXMINUTE[0].key)
        								{
        									return;
        								}
        								else if($Item.newValue == "1" && valn.options && (valn.options[0] || {}).key == $Page.TENMINUTE[0].key)
        								{
        									return;
        								}
        								else if($Item.newValue == "2" && valn.options && (valn.options[0] || {}).key == $Page.ONEHOUR[0].key)
        								{
        									return;
        								}
        								else if($Item.newValue == "3" && valn.options && (valn.options[0] || {}).key == $Page.TENHOUR[0].key)
        								{
        									return;
        								}
            				    		// 先清空原来的值
        								valn.newValue = null;
        								if($Item.newValue == "0")
            				    		{
            				    			valn.options = $Page.SIXMINUTE;
            				    		}
            				    		else if($Item.newValue == "1")
            				    		{
            				    			valn.options = $Page.TENMINUTE;
            				    		}
            				    		else if($Item.newValue == "2")
            				    		{
            				    			valn.options = $Page.ONEHOUR;
            				    		}
            				    		else
            				    		{
            				    			valn.options = $Page.TENHOUR;
            				    		}
            				    	}
        						});
        					});
        				};
        			}
        			if (valj.attrCode == "RAUTAUTIMER" && !valj.newValue)
        			{
        				// TAU值 不可编辑
        				valj.isNullable = true;
        				valj.isModify = false;
        				valj.showType = "TEXT";
        			}
                    // c00311908 NB-IOT节点属性优化 end

        			// add for US-20180605153723-2031094321  DD-AR-D01890693 start
        			if (valj.attrCode == "userAreaFlag" && $Page.projectVersion == "NINGXIA") {
        				$Controller.bes.ad.productattrchange.checkUserAreaFlagControlAttr($Gadget, valj);
        			}
        			// add for US-20180605153723-2031094321  DD-AR-D01890693 end

				});
			});
			return;
		}

		// 调用UCEC接口获取数据
		$Fire({
			service : 'ucec/v1/offeringInst/offeringattributesinst_query',
			params : {
				header : null,// 目前传空后续方案确定好要再传
				body : {
					offeringId : $Gadget.$Attrs.offeringid,
					offeringInstId : $Gadget.$Attrs.offeringinstid
				}
			},
			target : '$Gadget.productAttrs',
			onafter : function() {
				debugger;
				if ($Gadget.productAttrs && $Gadget.productAttrs.body) {

				} else {
					return;
				}
				$Gadget.commattr = $Gadget.productAttrs.body.attributeGroups
						|| [];
				$Page.tempattributeGroups= $.extend(true, [], $Gadget.productAttrs.body.attributeGroups
						|| []);

				$.each($Gadget.commattr || [], function(i, val) {
					// MODIFY 2015-10-31 by l00289267 start
					val.hasAttributesToShow = false;

					$.each(val.attributes || [], function(j, valj) {
						// add by wkf59141 新4G自选
						if (valj.attrCode == "PM_DICT_CONTROL"
								&& valj.newValue == "Y"){
							$Page.optional4G = true;
						}

		        		if (!adutil.filterOcPcOfferingAttributeEnable(valj.ocPcOfferingAttributeEnableVA,$Gadget.$Attrs.opertype)) {
		        			valj.showType = 'HIDDEN';
		        		}

		        		if (valj.showType != 'HIDDEN') {
		        			val.hasAttributesToShow = true;
		        			$Gadget.hasAttrToShow = true;
		        		}
		        		// MODIFY 2015-10-31 by l00289267 end
						if (valj.showType == 'MULTI_SEL') {
							if (valj.newValue) {
								valj.newValue = valj.newValue.split(",");
							}
						}
						if(valj.effectMode == 'N'){
	                        $Gadget.effectShowFlag[j] = 'I';
	                    }

						// 是否实名制校验
						if (valj.attrCode == 'PM_IS_REALUSER') {
							$Gadget.attrPhoneRealuserFlag = true;
						}

						//车联网特殊日期处理   实例的值是 yyyyMMddHHmmss
						if ((valj.attrCode == 'ServiceStartDateTime' || valj.attrCode == 'ServiceEndDateTime')
								&& (valj.showType == 'TIME' || valj.showType == 'DATE')) {
							var newValue =  valj.newValue;
							try{
								if(null !=  valj.newValue && valj.newValue.length == 14){
									var year = newValue.substring(0,4);
									var month = newValue.substring(4,6) - 1;
									var day = newValue.substring(6,8);
									var hour = newValue.substring(8,10);
									var min = newValue.substring(10,12);
									var second = newValue.substring(12,14);
									valj.newValue = new Date(year,month,day,hour,min,second).getTime();
									valj.oldValue = valj.newValue;
								}
							}
							catch(e){

							}
						}
						// 是否需要鉴权
						if (valj.attrCode == 'PM_IS_AUTHOR') {
							$Page.attrPhoneAuthorFlag = true;
						}

						if (valj.attrCode == 'ANXINGKA_IS_INTERNET') {
	                        $Controller.bes.ad.productattrchange.inputdisabled($Gadget, valj);
	                    }
						if (valj.showType == 'PASSWORD'){
							$Gadget.attrpasswordShowFlag.password = true;

							$Gadget.attrpasswordGadget = {};
							$Gadget.attrpasswordGadget.password = valj.newValue;
							$Gadget.attrpasswordGadget.passwordRep = valj.newValue;
							//MODIFY 2015-11-03 by l0028967 DTS2015110203299
							$Gadget.attrpasswordGadget.passwordForCompare = valj.oldValue;
							$Gadget.attrpasswordShowFlag.passwordHideStar = !!valj.isNullable;
							$Gadget.attrpasswordShowFlag.validaterule = valj.verificationRule;

							// 监控密码属性值的变化
							$Gadget.$watch(function(){
								return $Gadget.attrpasswordGadget;
							}, function(newValue,oldValue,scope){
								if (newValue){
									$.each($Gadget.commattr||[],function(i,val){
										$.each(val.attributes||[],function(j,valj){
											if (valj.showType == "PASSWORD"){
												valj.newValue = newValue.password;
											}
										});
									});
								}
							}, true);
						}

						if(valj.showType == 'CURRENCY'){
						       valj.newValue = parseFloat(adutil.getPriceByPrecision(adutil.approxPrice(valj.newValue)));
						 }
						// 实现了对属性的 APNPackageFlag 判断
	                    if(valj.attrCode == "APNPackageFlag" || valj.attrCode == "APNPackageFlag4XS" ){
	                        // 否存在“车联网APN1流量套餐产品包（I00010100150）”或者“车联网APN2流量套餐产品包（I00010100160）”两个商品包中
	                        if($Controller.bes.ad.productattr.isBelogTelematicsOffering($Gadget,$Page)){
	                            // APNPackageFlag
	                            // 展示四个附加属性(APNNAME、Discount、ApprovalNum、CanShare)
	                            // APNPackageFlag4XS
	                            // 展示3个附加属性(APNNAME、Discount、ApprovalNum)
	                            $.each($Gadget.commattr||[],function(i,val){
	                                $.each(val.attributes||[],function(k,valk){
	                                 if("APNNAME" != valk.attrCode && "Discount" != valk.attrCode && "ApprovalNum" != valk.attrCode){
	                                    if(valj.attrCode == "APNPackageFlag" && "CanShare" != valk.attrCode){
	                                        valk.showType = "HIDDEN";
	                                    }else if(valj.attrCode == "APNPackageFlag4XS"){
	                                        valk.showType = "HIDDEN";
	                                    }
	                                 }
	                             });
	                            });

	                        }else{
	                            $.each($Gadget.commattr||[],function(i,val){
	                                    $.each(val.attributes || [], function(k, valk) {
										if ("Discount" != valk.attrCode) {
											valk.showType = "HIDDEN";
										}
									});
	                            });
	                        }
	                    }

	                    //IsOrderBusiStrategy”，如果是，则根据“是否配置业务策略”（IsOrderBusiStrategy的值展示页面元素。如果值为“否”，则只展示“APNNAME”商品附加属性。如果值为“是”, 则显示所属性
	                    if(valj.attrCode == "IsOrderBusiStrategy" && (valj.newValue == "0")){
	                    // 商品编码是否是 数据通信产品I00010100085 判空
	                    if($Page.isDataOffering){
	                    	$Page.isDataOffering = null;
	                        $.each($Gadget.commattr || [], function(i, val) {
								$.each(val.attributes || [], function(k, valk) {
									if ("APNNAME" != valk.attrCode) {
										valk.showType = "HIDDEN";
									}
								});
							});
	                      }
	                    }
					});
				});

			}
		}, $Gadget);

		/*
		 * $Gadget.$Attrs.validate.push(function() { debugger; return
		 * $Controller.bes.ad.productattrchange
		 * .productattrCheckValidate($Gadget); });
		 */
	},


initUserWhiteNum : function($Gadget, $Fire, $Page) {
	debugger;
	//个人智能网语音通信服务--- 移动到其他位置
	if(($Gadget.$Attrs || {}).offeringid == '1310007904' && $Page.contextInfo && $Page.serviceNumber){
		// 电话号码
		$Fire({
			service: "bes.oc.ocquerysubscriptionbaseservice/querysubscriber",
			params: {
				request: {serviceNumber: $Page.serviceNumber}
			},
			target: "$Gadget.userdata",
			onafter: function() {
			debugger;
			if($Gadget.userdata && $Gadget.userdata.subscriberInfo && $Gadget.userdata.subscriberInfo.length > 0)
			{
				$Controller.bes.ad.productattrchange.queryGroupMems($Gadget, $Fire, $Page);
			   }
			}
		}, $Gadget);
		// 查询号码所属的集团
	}
	},


	queryGroupMems : function($Gadget, $Fire, $Page) {
		debugger;
		$Fire(
				{
					service : "ocquerygroupsubsboservice/querygroupsubsbymember",
					params : {
						header : {},
						body : {
							beId : $Gadget.userdata.subscriberInfo[0].beId,
							memberServiceNumber : $Gadget.userdata.subscriberInfo[0].serviceNumber,
							subscriberId : $Gadget.userdata.subscriberInfo[0].subsId,
						}
					},
					target : "$Gadget.groupResp",
					onafter : function($Gadget) {
						debugger;
						if ($Gadget.groupResp && $Gadget.groupResp.body) {
							debugger;
							$.each($Gadget.groupResp.body.groupSubscribers || [],
									function(
											i,
											vai) {
										debugger;
								if(vai.prodId == '1420000160' || vai.prodId == '1610002161'  ){
									$Gadget.groupId = vai.groupId;
									$Controller.bes.ad.productattrchange.getGroupType($Gadget);
								}
							});

						}
					}
				}, $Gadget);
	},

	getGroupType : function($Gadget) {
		debugger;
		$Fire({service : 'ucec/v1/productchange/queryOfferingInstEx',
			params : {
				header : {},
				body : {
					subscriberId : $Gadget.groupId
				}
			},
			target : '$Gadget.exOfferingInstInfoResp',
			onafter : function() {
				debugger;
				var offerInstInfoList = (($Gadget.exOfferingInstInfoResp || {}).body || {}).offeringInstInfo;
				if(offerInstInfoList == null){
					return;
				}
				// 找到GroupType的属性
				$.each(offerInstInfoList || [],
					function(
							nn,
							vann) {
						debugger;
						//集团智能网语音通信服务
						if(vann.offeringId == "1310007802" || vann.offeringId == "2000006440"){
						$.each(vann.attributeGroups
								|| [],
						function(i, vai) {
							debugger;
							var attribueList = vai;
							$.each(attribueList.attributes
									|| [],
							function(n, van) {
								debugger;
								if (van.attrCode == 'GroupType' && '2' == van.newValue  ) {
									// 个人的产品属性
									debugger;
									$Controller.bes.ad.productattrchange
											.setUserWhiteNum(
													$Gadget);
								}
							});
						});
						}
					});
                $Controller.bes.ad.productattrchange.groupTypeMajor($Gadget, $Page)

			},
		}, $Gadget);
	},

	setUserWhiteNum : function($Gadget) {
		debugger;
		// 回填anpname的属性
		$.each($Gadget.commattr || [], function(z,
				vaz) {
			$.each(vaz.attributes || [], function(j, valj) {
				if (valj.attrCode == 'AutoForwardFlag') {
					valj.allowChange = false;
					valj.isModify = false;
					var newOptions =  []
					$.each(valj.options || [], function(p, vap) {
						if (vap.key == '0') {
							vap.selected = true;
							 valj.newValue = vap.key;
							 valj.oldValue = vap.key;
							newOptions.push(vap);
						}
					});
					valj.options = newOptions;
				}
				if (valj.attrCode == "userWhiteNum") {
					valj.showType = "HIDDEN";
				}
				if (valj.attrCode == "userWhiteNumOperType") {
					valj.showType = "HIDDEN";
				}
				if (valj.attrCode == "userWhiteNumFlag") {
					valj.showType = "HIDDEN";
				}
			});
		});
	},



	/*
     * 关于更新PBOSS物联网及车联网产品模型的通知  US-20180605153723-2031094321
     * DD-AR-D01890693 个人智能网语音通信服务脚本控制（个人变更）
     * 当个人用户/企业客户成员区域限制标识（userAreaFlag）不为1（多省漫游）时，则userAreaOperType和userArea（属性值设置为空且不可编辑）
     */
    checkUserAreaFlagControlAttr: function ($Gadget, attrItem) {
        debugger;
		var offerMatch = false;
		var userAreaFlagCtrlOffer = null;
		if ($Page.sysparamResult && $Page.sysparamResult['UserAreaFlagCtrlOffer']) {
			userAreaFlagCtrlOffer = $Page.sysparamResult && $Page.sysparamResult['UserAreaFlagCtrlOffer'];
		}
		if (!userAreaFlagCtrlOffer) {
			return;
		}

		var offerList = userAreaFlagCtrlOffer.split(',');
		for (var i = 0; i < offerList.length; i++) {
			if (offerList[i] == ($Gadget.$Attrs || {}).offeringid) {
				offerMatch = true;
				break;
			}
		}
		if (!offerMatch) {
			return;
		}

		var userAreaFlagCtrlAttrs = $Page.dictList && $Page.dictList['userAreaFlagCanModify'] || [];
		var findInCtrlAttrs = function (attrCode) {
			for (var i = 0; i < userAreaFlagCtrlAttrs.length; i++) {
				if (attrCode == userAreaFlagCtrlAttrs[i].key) {
					return true;
				}
			}

			return false;
		};

		 var ctrlAttrs = function (newValue) {
			debugger;
			$.each($Gadget.commattr || [], function(i, val) {
                $.each(val.attributes || [], function(j, valj) {
                	if (findInCtrlAttrs(valj.attrCode)) {
    					if (newValue == '1') {
    						valj.isCoverShow = false;
    						valj.isModify = true;
    					} else {
    						valj.isCoverShow = true;
    						valj.isModify = false;
    						valj.newValue = null;
    						if (valj.showType == 'TEXT') {
    							$('#TEXT_' + valj.attrCode + '_' + valj.attrId).trigger('blur');
    						} else if (valj.showType == 'SINGLE_SEL') {
    							$('#SINGLE_SEL_' + valj.attrCode + '_' + valj.attrId).find('input').val('');
    						}
    					}
    				}
                });
			});
		};

		ctrlAttrs(attrItem.newValue);

		attrItem.onValueChange = function ($Gadget, jEvent) {
			debugger;
			var attrItem = null;
			var commattrItem = $(jEvent.$Target).scope().$Item;
			$.each(commattrItem.attributes || [], function(j, valj) {
            	if (valj.attrCode == "userAreaFlag") {
            		attrItem = valj;
				}
            });
            ctrlAttrs(attrItem.newValue);
		};

    },

	// c00311908 低功耗模式
    onValueChange_LOWPOWERMODE : function($Gadget,jEvent,$Item)
    {
    	debugger;
    	if (!$Item)
    	{
    		$Item = $(jEvent.$Target).scope().$ChildItem;
    	}
    	if ($Item.newValue == "-1")
    	{
    		// 为空
    		$Item.newValue = null;
    	}

    	if($Item.newValue == "PSM" || $Item.newValue == "BOTH"){

    		$.each($Gadget.commattr||[], function(m,valm){
				$.each(valm.attributes||[], function(n,valn){
	            	if(valn.attrCode == "RAUTAUTIMER"){
	            		valn.isModify = true;
	            		valn.showType='SINGLE_SEL';
	            		valn.isNullable = false;
	            	}
	            	if(valn.attrCode == "ACCURACY"){
	            		valn.isModify = true;
	            		valn.showType='SINGLE_SEL';
	            		valn.isNullable = false;
	            	}
				});
            });
    	}
    	else
    	{
    		$.each($Gadget.commattr||[], function(m,valm){
				$.each(valm.attributes||[], function(n,valn){
	            	if(valj.attrCode == "RAUTAUTIMER")
	            	{
	            		valj.newValue = null;
	            		valj.isNullable = true;
	            		valj.showType='TEXT';
	            		valj.isModify = false;
	            	}
	            	if(valj.attrCode == "ACCURACY")
	            	{
	            		valj.newValue = null;
	            		valj.isNullable = true;
	            		valj.showType='TEXT';
	            		valj.isModify = false;
	            	}
				});
            });
    	}
    },

	// 判断商品是否在“车联网APN1流量套餐产品包（I00010100150）”或者“车联网APN2流量套餐产品包（I00010100160）”两个商品包中??
    isBelogTelematicsOffering : function($Gadget, $Page){
        if("I00010100150" ==$Page.data.offeringinfo.offeringCode ||"I00010100160"==$Page.data.offeringinfo.offeringCode)
        {
            return true;
        }
        return false;
    },
	inputdisabled: function($Gadget, obj) {
        debugger;

        $Fire({
            service: '/authrightserviceboservice/hasright',
            params: {
                authid: 'ANXINKA_INTERNET_AUTH' //安心卡上网设置令牌
            },
            target: '$Gadget.openavailable',
            onafter: function($Gadget) {
                debugger;
                obj.isModify = obj.isModify?($Gadget.openavailable || false):obj.isModify;
            }
        }, $Gadget);
    },
	productattrCheckValidate : function($Gadget) {
		debugger;
		if($Page.projectVersion == "NINGXIA" && $Gadget.displaySelectedAddiProd && $Gadget.displaySelectedAddiProd.length > 0 && $Gadget.attrindex >= 0){
			if($Gadget.displaySelectedAddiProd[$Gadget.attrindex].offeringCode == "M2M.I00010900011"){
				var attributeGroups = $Gadget.commattr;
				var validateDiscount = null;
				if($Gadget.CheckPOCDiscountList && $Gadget.CheckPOCDiscountList.length>0){
					validateDiscount = $Gadget.CheckPOCDiscountList[0].itemCode || "100";
				}
				var discountFlag = false;
				$.each(attributeGroups || [], function(i, vali){
					$.each(vali.attributes || [], function(j, valj){
						if("Discount" == valj.attrCode && valj.newValue != validateDiscount){
							discountFlag = true;
						}
					   });
				   });
				   if(discountFlag){
					   $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "固费折扣率必须为："+validateDiscount);
	   					return false;
				   }
			}
		}
		$.each($Gadget.commattr || [], function(i, val) {
			$.each(val.attributes || [], function(j, valj) {
				if (valj.showType == 'MULTI_SEL') {
					valj.newValue = (valj.newValue || []).join(",");
				}
			});
		});
		$.extend($Gadget.$Attrs.model, $Gadget.commattr);
		return true;
	},

	// 选择号码按钮
	chooseNumberBtn : function($Gadget, $Page){
		debugger;
		$Page.testUserAuth = true;
		$("#bes-oc-userauth-fullcover").show();
	},

	// 鉴权事件
	handleAuthProcessEmit : function($Gadget,$Page, $Fire, $Event, $UI){
		debugger;
		$Gadget.authProcess = $Event.$Data.authProcess;
		if($Gadget.authProcess != "AuthSuccess"){
			try{
				var len = $Gadget.commattr[0].attributes.length;
				for(var i=0; i<len; i++){
					var val = $Gadget.commattr[0].attributes[i];
					if(val.attrCode == "RelNumber"){
						val.newValue = "";
					}else if(val.attrCode == "RelSubsID" ){
						val.newValue = "";
					}
				}
			}catch(error){
				return false;
			}
			return ;
		}

		var userAuthGadget = adutil.getGadgetObj($(".bes-oc-userauth"));
		var serviceNumberVal = userAuthGadget.serviceNumber;

		var req = {
			serviceNumber : serviceNumberVal
		};
		debugger;
		// 获取subsId
		$Fire({
			service:'/bes.oc.ocquerysubscriptionbaseservice/querysubscriber',
			params:{
				"request": req
			},
			target: '$Gadget.response',
			onafter: function() {
				debugger;
				if(($Gadget.response == null) || ($Gadget.response.subscriberInfo == null)){
					debugger;
// $UI.msgbox.info('提示',"【关联号码】和手机上网伴侣用户不归属同一地区!");
					$UI.msgbox.info($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.FailedObtainnumberInforNosubscribe"));//('提示',"获取关联号码信息失败，不能订购 。");
					return;
				}
				var targetNumBeId = $Gadget.response.subscriberInfo[0].beId;

				// 获取当前登录号码的信息， 比较BeId是否相同，不归属同一地区不允许订购
				debugger;
				$Fire({
					'service' : '/ucec/v1/context/contextandsession_query',
					'params' : {},
					'target' : '$Gadget.loginedInfo',
					'onafter' : function($Gadget) {
						debugger;
						if(($Gadget.loginedInfo==null) || ($Gadget.loginedInfo.body==null)){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.NotTheSameAreaasMobileInternet"));//('提示',"【关联号码】和手机上网伴侣用户不归属同一地区!");
							return;
						}

						var sourceNum = $Gadget.loginedInfo.body.subSrvSubscriberInfo.serviceNumber;
						var sourceNumBeId = $Gadget.loginedInfo.body.subSrvSubscriberInfo.beId;

						if(sourceNum == serviceNumberVal){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.AssociatedNumberCannotBeUsersOwm"));//('提示',"关联号码不能是自己的号码 。");
							return;
						}else if(targetNumBeId != sourceNumBeId){
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.NotSameAreaasMobileInternetPartner"));//('提示',"【关联号码】和手机上网伴侣用户不归属同一地区!");
							return;
						}

// var len = $Gadget.$Attrs.commattr.commattr[0].attributes.length;
						var len = $Gadget.commattr[0].attributes.length;
						for(var i=0; i<len; i++){
// var val = $Gadget.$Attrs.commattr.commattr[0].attributes[i];
							var val = $Gadget.commattr[0].attributes[i];
							if(val.attrCode == "RelNumber"){
								val.newValue = serviceNumberVal;
							}else if(val.attrCode == "RelSubsID" ){
								var temp = $Gadget.response.subscriberInfo[0].subsId;
								val.newValue = String(temp);
							}
						}
					}
				}, $Gadget);
			}
		},$Gadget);
	},

	// 关联上网伴侣校验
	swblValidate : function($Gadget){
		debugger;
		$UI = $Gadget.$Get('$UI');

		var len = $Gadget.commattr[0].attributes.length;
		for(var i=0; i<len; i++){
			var val = $Gadget.commattr[0].attributes[i];
			if((val.newValue=="") || (val.newValue == null)){
				debugger;
				$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.SelectANumber"));//("提示", "请选择号码!");
				return false;
			}
		}

		return true;
	},

	// 国际漫游校验
	interRomCheckValidate : function($Gadget)
	{
		debugger;
		$UI = $Gadget.$Get('$UI');
		if($Gadget.healthchangemark==null)
		{
			$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.CompleteRoamingVerificationFirst"));//("提示", "请先完成漫游校验");
			return false;
		}

		if($Gadget.healthchangemark==false)
		{
			$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.RoamingVerificationFailed"));//("提示", "漫游校验失败");
			return false;
		}

		if($Gadget.healthchangemark==true)
		{
			return true;
		}
	},

	// 国际漫游校验服务
	romCheck : function($Gadget,$Page)
	{
		debugger;
		$UI = $Gadget.$Get('$UI');
		$Fire = $Gadget.$Get("$Fire");
		$Gadget.healthchangemark==null;

		var req={};

		/*
		 * if($Gadget.commattr) { $.each($Gadget.commattr,function(i,val){
		 * debugger; $.each(val.attributes||[],function(i,child){ debugger;
		 * if(child.attrCode=="CANROAMDAYS") { req.roamDays=child.newValue; }
		 *
		 * if(child.attrCode=="p100008") { req.voucherName=child.newValue; } });
		 * }); }
		 */


		var len1=$Gadget.commattr.length;
		for(var i=0;i<len1;i++)
		{
		    var attributtdata=$Gadget.commattr[i].attributes;
		    var len2=attributtdata.length;
		    for(var j=0;j<len2;j++)
	    	{
		    	if(attributtdata[j].attrCode=="CANROAMDAYS")
		    	{
			    	req.roamDays=attributtdata[j].newValue;
		    	}

				if(attributtdata[j].attrCode=="p100008")
		    	{
			    	req.voucherName=attributtdata[j].newValue;
		    	}
	    	}
		}

		debugger;

		$Fire({
			service : "/agentdesktop/v1/person/validateinterroam",
			params : {
				"body": req
			},
			target : '$Gadget.valdiaterespose',
			onafter : function()
			{
				debugger;
				if(!$Gadget.valdiaterespose.body)
				{
					$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.RomingVerificationInforEmpty"));//("提示", "漫游校验信息为空");
					$Gadget.healthchangemark=false;
					return false;
				}
				if($Gadget.valdiaterespose.body&&$Gadget.valdiaterespose.body.retCode)
				{
					var valiErrorMsg = $Gadget.valdiaterespose.body.retMessage;
						if($Gadget.valdiaterespose.body.retCode!="0")
						{
							$UI.msgbox.info($UEE.i18n("ad.person.label.information"), valiErrorMsg);
							$Gadget.healthchangemark=false;
							return false;
						}
				}
			  $UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.RoamingVerficationSucceed"));//("提示", "漫游校验成功");
			  $Gadget.healthchangemark=true;
			  return true;
			}
		},$Gadget);
	},

	attrpasswordValidate: function($Gadget, $UI){
		debugger;

		if(!$Gadget.attrpasswordGadget.password || !$Gadget.attrpasswordGadget.passwordRep){
			$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.PasswdCannotBeEmpty"));//("提示", "密码不能为空");
			return false;
		}

		//MODIFY 2015-11-03 by l0028967 DTS2015110203299
		if ($Gadget.attrpasswordGadget.password != $Gadget.attrpasswordGadget.passwordForCompare) {
			if(!new RegExp("^[0-9]*$").test($Gadget.attrpasswordGadget.password)){
				$Gadget.$Get("$UI").msgbox.info($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.BroadbandOfferingPasswdContainsSpecialChars"));//("提示","宽带商品密码包含特殊字符，请重新设置");
				return false;
			}
		}

		if($Gadget.attrpasswordGadget.password != $Gadget.attrpasswordGadget.passwordRep){
			$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.TwoIputsMustBeSame"));//("提示", "密码重复输入要一致");
			return false;
		}

		return true;
	},

	inputValidate:function($Gadget, $Item, jEvent) {
		debugger;
		// 副号鉴权
		if ($Page.attrPhoneAuthorFlag && $Item.newValue.length == 11
				&& $Item.verificationRule == "phone;") {

			//$Page.testUserAuth = true;
			$Page.serviceNumberAuth=$Item.newValue;
			//$('#serviceNumberAuth').val($Item.newValue);
			$Gadget.$Emit("$cometoshow",$Item.newValue);
			$Page.testUserAuth = true;

		}
		// 副号实名制校验 add by zwx365526
		if ($Gadget.attrPhoneRealuserFlag
				&& $Item.newValue.length == 11
				&& $Item.verificationRule == "phone;") {
			$Controller.bes.ad.productattrchange.queryRealNameInfo($Gadget, $Item);
		}
	},
	// 查询实名认证信息
	queryRealNameInfo : function($Gadget, $Item) {
		debugger;

		var request = {
			header : {},
			body : {
				serviceNumber : $Item.newValue
			}
		};
		// 查询返回实名认证信息
		$Fire = $Gadget.$Get("$Fire");
		$UI = $Gadget.$Get("$UI");
		$Fire({
			service : "/ucec/v1/customer/realnamereg_query_new",
			params : request,
			target : "$Gadget.data",
			onafter : function($Gadget) {
				debugger;
				if ($Gadget.data.body && $Gadget.data.body.isRealName == '1') {
					//实名制不做处理
				}else{
					$UI.msgbox.info("提示", "非实名制副号,不可添加");
					//实名制校验失败时，将副号置空
					$Item.newValue = null;
					return false;
				}
			}
		}, $Gadget);

	},
	dataSubmitAfterAuth :function ($Gadget){
		debugger;
		 $Gadget.$Get('$Fire')({
	            'popin' : ''
	        });
	},

	/*
     * “固费折扣率”的属性的属性值低于系统参数 OM_NX_LL_LOWEST_Discount的值时，将“审批文号”修改为必填。由AD开发
     * 成员属性？  omNxLllowestDiscount
     */
	omNxLllowestDiscount: function($Gadget,$Fire,$ChildItem){
        debugger;

        if (!$Gadget.omNxLllowestDiscount || !$Gadget.OCApprovalNumOfferingList)
        {
        	// 没有获取到系统参数或字典 就重新查询一遍获取
        	$Gadget.$Get("$Fire")({
        		service : 'ucec/v1/common/qrysystemparambykey',
        		params : {
        			key : "OM_NX_LL_LOWEST_Discount"
        		},
        		target : '$Gadget.omNxLllowestDiscount',
        		 onafter : function($Gadget) {
                     debugger;
                     $Gadget.omNxLllowestDiscount = $Gadget.omNxLllowestDiscount || 60;

                     $Fire({
                         service : "/common/dictkey2",
                         params : {
                             "dictkeylist" : ['OC_ApprovalNum_VALIDATE_NX']
                         },
                         target : "$Gadget.OCApprovalNumOfferingList",
                         onafter : function($Gadget)
                         {
                             debugger;
                             var isValidate = false;
                             $.each($Gadget.OCApprovalNumOfferingList["OC_ApprovalNum_VALIDATE_NX"] || [], function(i, vali){
                            	 if (vali.key == $Gadget.$Attrs.offeringid){
                            		 isValidate  = true;
                            		 return;
                            	 }
                             });
                             if (isValidate)
                             {
                            	 $Controller.bes.ad.productattr.validateApprovalNum($Gadget, $ChildItem);
                             }
                         }
                     }, $Gadget);
                }
        	}, $Gadget);
        }
        else
        {
        	var isValidate = false;
        	$.each($Gadget.OCApprovalNumOfferingList["OC_ApprovalNum_VALIDATE_NX"] || [], function(i, vali){
	           	 if (vali.key == $Gadget.$Attrs.offeringid){
	           		 isValidate  = true;
	           		 return;
	           	 }
            });
            if (isValidate)
            {
           	 	$Controller.bes.ad.productattrchange.validateApprovalNum($Gadget, $ChildItem);
            }
        }

    },

    validateApprovalNum: function($Gadget, $ChildItem){
    	debugger;
    	if ($ChildItem.newValue && Number($ChildItem.newValue) < Number($Gadget.omNxLllowestDiscount)) {
 	    	for ( var j = 0; j < $Gadget.commattr.length; j++) {
 	    		for(var i = 0; i < $Gadget.commattr[j].attributes.length; i++){
 	    			if ("ApprovalNum" == $Gadget.commattr[j].attributes[i].attrCode)
 	    			{
 	    				$Gadget.commattr[j].attributes[i].isNullable = false;
 	    				$Gadget.commattr[j].attributes[i].verificationRule  = "required;";
					}
 	    		}

 			}
	    }
    	else
    	{
        	//ApprovalNum
  	    	for ( var j = 0; j < $Gadget.commattr.length; j++) {
  	    		for(var i = 0; i < $Gadget.commattr[j].attributes.length; i++){
  	    			if ("ApprovalNum" == $Gadget.commattr[j].attributes[i].attrCode)
  	    			{
  	    				$Gadget.commattr[j].attributes[i].isNullable = true;
  	    				$Gadget.commattr[j].attributes[i].verificationRule  = "";
					}
  	    		}

  			}
        }
    },
    groupTypeMajor: function($Gadget, $Page){
        debugger;
        if ($Page.groupType == "2") { //集群类企业
            $.each($Gadget.commattr || [],function(j, valj){
                $.each(valj.attributes || [], function(k, valk){
                    if (valk.attrCode == "AutoForwardFlag") { // 企业客户成员分钟数使用完毕后是否支持自动前转
                        valk.newValue = "0"; //值为0且不可修改
                        valk.isModify = false;
                        return;
                    }
                    if (valk.attrCode == "LockFlag") { // 被叫闭锁功能标识
                        valk.newValue = ""; //值为空且不可修改
                        valk.isModify = false;
                        return;
                    }
                    if (valk.attrCode == "userWhiteNumFlag") { // 白名单功能状态
                        valk.newValue = ""; //值为空且不可修改
                        valk.isModify = false;
                        return;
                    }
                });
            });
        }else if ($Page.groupType == "1") { //普通企业
            $.each($Gadget.commattr || [],function(j, valj){
                $.each(valj.attributes || [], function(k, valk){
                    if (valk.attrCode == "userShutFlag") { // 集群类企业客户成员闭锁功能
                        valk.newValue = ""; //值为空且不可修改
                        valk.isModify = false;
                        return false;
                    }
                });
            });
        }
    }

});
