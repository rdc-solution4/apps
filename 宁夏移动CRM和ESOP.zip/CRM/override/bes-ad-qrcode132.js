$Controller("besOcQRcode", {
	// 初始化数据
	init : function($Gadget, $Fire, $Page) {
		debugger;
		//$Page.qrcode.qrcodeInfo = $Page.qrcode.qrcodeInfo || {};
		$Gadget.qrcode = $Gadget.qrcode || {};
		if($Gadget.$Attrs && $Gadget.$Attrs.model){			
			$Gadget.qrcode.qrcodeInfo = $.parseJSON($Gadget.$Attrs.model);
		}
	},
	
	// 单击二维码按钮
	qrCodeBtn: function($Gadget)
	{
		debugger;
		// 弹出第三方地址选择页面
		$Gadget.$Emit("$bes.oc.qrCodePop");
	}
})
