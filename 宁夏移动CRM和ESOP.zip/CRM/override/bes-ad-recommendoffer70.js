$Controller(
		"bes.ad.recommendoffer",
		{
			/**
			 * 初始化推荐页面.
			 */
			init : function($Gadget,$Page) {
				debugger;
				$Page.data.showMonthFlow=true;
				$Page.data.showRecommend=true;
				this.getRecommendList($Gadget,$Page);
				$Controller.bes.ad.recommendoffer.queryprivilegeleft($Page,$Gadget);
				this.createData($Gadget, {});
				if ($Gadget.$Page.data.offeringinfo.offeringId == $Gadget.$Page.data.feedbackRecommend.offeringId) {
					$Gadget.$Page.data.offeringinfo.feedbackRecommend = $Gadget.$Page.data.feedbackRecommend;
				}
			},
			/**
			 * 获取推荐商品列表.
			 */
			getRecommendList : function($Gadget,$Page) {
				debugger;
				$Fire = $Gadget.$Get("$Fire");
				var parmas = {
					"header" : null,
					"body" : {
						"serviceNumber" : $Gadget.$Page.personalInfo.subsInfo.servNumber,
						"displayCount" : 3
					}
				};
				OC.Callchain.setFireSearch($Page.pageId, "recomIni");
				$Fire({
					'service' : '/ucec/v1/recommend/offerlist_query',
					'params' : parmas,
					'target' : '$Gadget.data.recommendlist',
					'onafter' : function($Gadget) {
						// Fixed: DTS2016080805817 调试用代码，实际环境中不需要，注释掉。 modify by wkf59141. 
						/*debugger;
						//调试使用 
						if(!$Gadget.data.recommendlist && $Gadget.$Attrs.scenetype=="mainofferchange" ){
							var temp = {
									recommended: "aaaaaaaaa",
									actionId : "bbbbbbb",
									userSeq : "55555555",
									eventType : "4",
									offeringId : "18001",
									offeringName : "蜗牛幻想",
									offeringDesc : "",
									url: null,
									isPrimaryFlag: "N",
								};
							$Gadget.data  = $Gadget.data ||{};
							$Gadget.data.recommendlist  = {
									body: {
										recommendOffers : []
									}
							};
							$Gadget.data.recommendlist.body.recommendOffers.push($.extend(true, {}, temp));
						}*/
					}
				}, $Gadget);
			},
			/**
			 * 商品反馈.
			 */
			feedback : function($Page,$Gadget, item, $target, type) {
				debugger;
				$Fire = $Gadget.$Get("$Fire");
				var parmas = {
					"header" : null,
					"body" : {
						"feedbackResult" : {
							"serviceNumber" : $Gadget.$Page.personalInfo.subsInfo.servNumber,
							"userSeq" : item.userSeq,
							"actionId" : item.actionId,
							"eventType" : item.eventType,
							"status" : type
						}
					}
				};
				OC.Callchain.setFireSearch($Page.pageId, "feedback");
				$Fire({
					'service' : '/ucec/v1/recommend/feedbackresult',
					'params' : parmas,
					'target' : '$Gadget.data.feedback',
					'onafter' : function() {
						var tgt = $target.parent().parent().parent();
						tgt.siblings().last().addClass("last");
						tgt.remove();
					}
				}, $Gadget);
			},
			/**
			 * 短信内容校验.
			 */
			smsValidate : function($Gadget) {
				var msg = $("#msgcontent").val();
				$UI = $Gadget.$Get("$UI");
				if (!msg) {
					$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.recommendoffer.message.input'));//请输入内容。
					return false;
				}
				if (msg.length > 150) {
					$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.recommendoffer.message.contentnotexceedyibaiwu'));//内容不能超过150字。
					return false;
				}
				return true;
			},
			/**
			 * 短信回馈.
			 */
			sendSMS : function($Page,$Gadget) {
				debugger;
				if (!this.smsValidate($Gadget)) {
					return;
				}
				OC.Callchain.setFireSearch($Page.pageId, "sendSMS0");
				$Fire = $Gadget.$Get("$Fire");
				var parmas = {
					"header" : null,
					"body" : {
						"callContent" : $.trim($("#msgcontent").val()),
						"receiverNumber" : $Gadget.$Page.personalInfo.subsInfo.servNumber
					}
				};
				$Fire({
					'service' : '/ucec/v1/customer/message_send',
					'params' : parmas,
					'target' : '$Gadget.data.msgresult',
					'onafter' : function($Gadget) {
						$UI = $Gadget.$Get("$UI");
						if ($Gadget.data.msgresult
								&& $Gadget.data.msgresult.body) {
							$UI.msgbox.success($UEE.i18n('ad.recommendoffer.message.success'), $UEE.i18n('ad.recommendoffer.message.smssuccess'));//短信发送成功。
							$Controller.bes.ad.recommendoffer.hideDialog($Gadget);
						} else {
							$UI.msgbox.error($UEE.i18n('ad.recommendoffer.message.fail'), $UEE.i18n('ad.recommendoffer.message.smssendfail'));//短信发送失败。
							//$UI.msgbox.success("成功", "短信发送成功。");
							//$Controller.bes.ad.recommendoffer.hideDialog($Gadget);
						}
					}
				}, $Gadget);
			},
			
			//点击购买
			packdata : function($Gadget, item) {
				debugger;
				if (item.isPrimaryFlag && "Y" == item.isPrimaryFlag) {
					$Gadget.$Get("$UI").msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.recommendoffer.message.productiscommodity'));//该商品是主商品，暂不支持主商品变更。
					return;
				}
				
				//主产品变更的场景
				if($Gadget.$Attrs.scenetype=="mainofferchange"){
					//组装节点
					item.status = "4";
					item.serviceNumber = $Gadget.$Page.personalInfo.subsInfo.servNumber;
					var emitData = {
							offeringId:item.offeringId,
							feedbackRecommend: item
					};
					$Gadget.$Emit('$OrdeRecommendOffer',emitData);
					return;
				}
				
				this.createData($Gadget, item);
				item.status = "4";
				item.serviceNumber = $Gadget.$Page.personalInfo.subsInfo.servNumber;
				$Gadget.$Page.data.feedbackRecommend = item;
				/*$Gadget.$Get("$Fire")({
					targetstep : "displayofferingdetail"
				});*/
				
				
				window._ysp_top.unifiedProductPopupFlag='1';
				//parent.$Controller.bes.ad.staticshoppingcar.showPartShade($("#"+obj),"../../ad/usl/bes-ad-goofferingdetail.uslx");
				$Controller.bes.personalunifiedview.showPartShade($("#personalunifiedmaininner"));
			},
			/**
			 * 构建报文节点。
			 */
			createData : function($Gadget, item) {
				debugger;
				$Gadget.$Page.data = $Gadget.$Page.data || {};
				$Gadget.$Page.data.offeringinfo = $Gadget.$Page.data.offeringinfo
						|| {};
				$Gadget.$Page.data.offeringId = item.offeringId;
				$Gadget.$Page.data.feedbackRecommend = $Gadget.$Page.data.feedbackRecommend
						|| {};
				if (item.offeringId) {
					$Gadget.$Page.data.feedbackRecommend.offeringId = item.offeringId;
				}
			},
			/**
			 * 弹出窗口.
			 */
			showDialog : function($Gadget, content) {
				debugger;
				$("#recommendmsgbox").show();
				$Gadget.msgcontents = content||"";
				$("#msgcontent").val(content);
			},
			/**
			 * 隐藏窗口.
			 */
			hideDialog : function($Gadget) {
				debugger;
				$("#recommendmsgbox").hide();
			},
			gotosaleworkbench:function($Gadget, $Page){
			    var urlStr = window.location.protocol + "//" + window.location.host + "/ngrecmaster/custsvc/business.action?BMEBusiness=rec.salesconsole" ;
				window.open(urlStr);
				//window.open("http://10.163.232.62:8000/custsvc/business.action?BMECID=17747&BMETimestamp="+(new Date()).getTime());
			},
			queryprivilegeleft:function($Page,$Gadget) {
				debugger;
				OC.Callchain.setFireSearch($Page.pageId, "recomIni");
				$Gadget.$Get("$Fire")({
					'service' : 'personalunifiedviewservice/queryprivilegeleft',
					'params' : {
						"servnumber":$Gadget.$Page.personalInfo.subsInfo.servNumber,
						"cycle":""
					},
					'target' : '$Gadget.privilegeLeftInfo',
					'onafter' : function($Gadget) {
						debugger;
						/*$Gadget.privilegeLeftInfo = $Gadget.privilegeLeftInfo||[];
						var obj = $(".process_bar").eq(0);
						var width = obj.width();
						width = 212;
						var creatProcessBar = function(con, val, v) {
							var proce = new UCD.ProcessBar(con, 0, v);
							proce.setOnChanged(function(process) {
							});

							proce.setValue(val);
							proce.enableAnimation(true);
							return proce;
						};

						var lenth = $Gadget.privilegeLeftInfo.length;
						for(var i=0;i<lenth;i++) {
							var $Item=$Gadget.privilegeLeftInfo[i];
							var bar1 = creatProcessBar($("#process_bar"+i), ($Item.leftData/$Item.totalData), false);
							bar1.setWidth(width);
						}
						*/

						/* var bar2 = creatProcessBar($("#process_bar2"), 70, false);
						bar2.setWidth(width);

						var bar3 = creatProcessBar($("#process_bar3"), 50, false);
						bar3.setWidth(width); */

					}
				}, $Gadget);
			}
		});