$Controller(
        "besAdRecrollback",
        {
            // 初始化
            initData : function($UI, $Emit, $Gadget, $Page, $Fire) {
                debugger;
                $Gadget.isRollBackFlag = true;
                $Gadget.pageShow = '1';// 是否显示分页
                $Gadget.isCheck = false;// 是否选中订单行
                $Gadget.expandButton = true;// 展开按钮显示
              //  $Gadget.isShowButton = false; //是否显示展示按钮
                $Gadget.isSelectOrder = false;
                $Gadget.recrollbackReason = "";// 退回原因
                $Page.showCover = false;
                $Gadget.pageSize = 10;
                $Gadget.curPage = 1;
                $Gadget.beginRowNum = 0;
                $Gadget.queryParam = {};
                $Gadget.queryType = '1';
                // $('#orderId').focus();
                $Page.goToCheckoutFlag = false;
                // 获取系统参数OM_IS_ROLLBACK_FLAG
                $Controller.besAdRecrollback.isRollBack($UI, $Gadget, $Fire);
                // 获取系统参数OM_SHOW_ROLLBACK_DETAIL_INFO
                $Controller.besAdRecrollback.showRollBackDetail($UI, $Gadget,
                        $Fire);
                // 获取系统参数bes上线时间戳（毫秒级）OC_BES_ONLINE_TIME
                $Controller.besAdRecrollback.besOnLineTime($UI, $Gadget, $Fire);
                // 获取系统参数OC_BES_ONLINE_TIME
                $Controller.besAdRecrollback.besRollBackBusiType($UI, $Gadget, $Fire);
                $Controller.besAdRecrollback.getAuthInfo($Gadget);
                //DTS2016081400475
                //DTS2016082907756,y00290641,2016.08.30
                // 获取系统参数REC_TIMES_TO_PROMOTIN(查询充值卡状态的最大次数)
                $Controller.besAdRecrollback.getCardStatusQueryTimes($UI, $Gadget, $Fire);
                // 获取系统参数REC_TIME_TO_PROMOTIN(查询充值卡状态时单次查询时长)
                $Controller.besAdRecrollback.getCardStatusQueryIntervalTime($UI, $Gadget, $Fire);

                // 业务回退没提及这个值要怎么传，先写死
                $Gadget.reasonCode = "testrollBackCode";

                $(document).keydown(function(){
                    if(event.keyCode =="13"){
                        $Controller.besAdRecrollback.btnQueryClick($UI,$Emit,$Gadget,$Page,$Fire);
                    }
                });

                $Gadget.data = $Gadget.data || {};
                this.initDataTimeCtrl($Gadget);
                
                //从宽带查询与处理传过来的订单编号，bes-ad-broadbandorder.js如果有值，则通过订单编号进行查询 dwx476196
                $Gadget.choosedOrder = adutil.getParam("choosedOrder");
                if ($Gadget.choosedOrder && $Gadget.choosedOrder != "") {
                	$Gadget.queryType = '2';
                	$Gadget.orderId = $Gadget.choosedOrder;
                	$Controller.besAdRecrollback.query($UI, $Emit, $Gadget, $Page,
                            $Fire);
                }
            },

            initDataTimeCtrl : function($Gadget){
                //如果是csp系统自动填充服务号码
                debugger;
                if ($Controller.bes.ad.csp.common.isCsp()) {
                    $("#serviceNumber").val($Controller.bes.ad.csp.common.getServNumber());
                }
                // 初始化时间控件
                $Gadget.endTime = $Page.TimeUtil.localNowDateLastSecond;
                // 起止时间默认间隔一周
                var intervalTime = 7 * 24 * 3600 * 1000 -1000;
                $Gadget.beginTime = $Gadget.endTime - intervalTime;
                $Page.$initFree=false;
            },

            initFree : function() {
                debugger;
                $Page.$initFree = true;
            },

            isRollBack : function($UI, $Gadget, $Fire) {
                var key = "OM_IS_ROLLBACK_FLAG";
                debugger;
                $Fire(
                        {
                            service : 'ucec/v1/common/qrysystemparambykey',
                            params : {
                                key : key
                            },
                            target : "$Gadget.isRollBack",
                            onafter : function($Gadget) {
                                debugger;
                                if ($Gadget.isRollBack
                                        && $Gadget.isRollBack == "true") {
                                    $Gadget.isRollBack = true;
                                } else {
                                    $Gadget.isRollBack = false;
                                }
                            }
                        }, $Gadget);
            },

            showRollBackDetail : function($UI, $Gadget, $Fire) {
                var key = "OM_SHOW_ROLLBACK_DETAIL_INFO";
                debugger;
                $Fire({
                    service : 'ucec/v1/common/qrysystemparambykey',
                    params : {
                        key : key
                    },
                    target : "$Gadget.showRollBackDetail",
                    onafter : function($Gadget) {
                        debugger;
                        if ($Gadget.showRollBackDetail
                                && $Gadget.showRollBackDetail == "true") {
                            $Gadget.showRollBackDetail = true;
                        } else {
                            $Gadget.showRollBackDetail = false;
                        }
                    }
                }, $Gadget);
            },

            //查询bes的上线时间戳（毫秒级）
            besOnLineTime : function($UI, $Gadget, $Fire) {
                var key = "OC_BES_ONLINE_TIME";
                debugger;
                $Fire({
                    service : 'ucec/v1/common/qrysystemparambykey',
                    params : {
                        key : key
                    },
                    target : "$Gadget.besOnLineTime",
                    onafter : function($Gadget) {
                        debugger;
                        if(!$Gadget.besOnLineTime){
                            //$Gadget.besOnLineTime=$Page.TimeUtil.localNowDateLastSecond;
                        }
                    }
                }, $Gadget);
            },
            //查询bes上线前老用户已受理业务 可以做业务回退的业务类型OC_CANROLLBACK_BUSITYPE
            besRollBackBusiType : function($UI, $Gadget, $Fire) {
                debugger;
                $Fire({
                    'service' : '/common/dictkey',
                    'params' :  {
                        "dictkeylist" : ['OC_CANROLLBACK_BUSITYPE']
                    },
                    'target' : '$Gadget.besRollBackBusiType',
                    'onafter': function(){
                        debugger;
                        $Gadget.besRollBackBusiTypeList = $Gadget.besRollBackBusiType["OC_CANROLLBACK_BUSITYPE"]||[];
//                        $.each(promStarDict, function(i, val) {
//                            var obj = {
//                                "key" : val.itemCode,
//                                "value" : val.itemName
//                            };
//                            $Gadget.data.starCategorys.push(obj);
//                        });
                        }
                    },$Gadget);
            },

            // 获取系统参数 REC_TIMES_TO_PROMOTIN(查询充值卡状态的最大次数)
            getCardStatusQueryTimes : function($UI, $Gadget, $Fire) {
                var key = "REC_TIMES_TO_PROMOTIN";
                debugger;
                $Fire({
                    service : 'ucec/v1/common/qrysystemparambykey',
                    params : {
                        key : key
                    },
                    target : "$Gadget.recTimesToPromotin",
                    onafter : function($Gadget) {
                        debugger;
                        if($Gadget.recTimesToPromotin){
                            $Gadget.times=$Gadget.recTimesToPromotin;
                        }
                        else{
                            $Gadget.times=5;
                        }
                    }
                }, $Gadget);
            },

            // 获取系统参数 REC_TIME_TO_PROMOTIN(查询充值卡状态时单次查询时长)
            getCardStatusQueryIntervalTime : function($UI, $Gadget, $Fire) {
                var key = "REC_TIME_TO_PROMOTIN";
                debugger;
                $Fire({
                    service : 'ucec/v1/common/qrysystemparambykey',
                    params : {
                        key : key
                    },
                    target : "$Gadget.recTimeToPromotin",
                    onafter : function($Gadget) {
                        debugger;
                        if($Gadget.recTimeToPromotin){
                            $Gadget.cardStatusQueryIntervalTime=$Gadget.recTimeToPromotin * 1000;
                        }
                        else{
                            $Gadget.cardStatusQueryIntervalTime=8000;
                        }
                    }
                }, $Gadget);
            },

            // 查询方式选择事件
            onRadioQueryClick : function($Gadget) {
                debugger;

                if ($Gadget.queryType == '1') {
                    $Gadget.orderId = "";
                    if($Gadget.isRollBack){
                        $Gadget.isRollBackFlag = false;
                    }
                    // 初始化时间控件
                    this.initDataTimeCtrl($Gadget);

                } else if ($Gadget.queryType == '2') {
                    $Gadget.isRollBackFlag = true;
                    $Gadget.serviceNumber = $Gadget.authServNum;
                }
            },

            // 订单查询展示
            btnQueryClick : function($UI, $Emit, $Gadget, $Page, $Fire) {
            	if($("#queryCheckbox" ).attr("class").indexOf("checked")>0){
            		$Gadget.IsBackProcess = true;
            	}else{
            		$Gadget.IsBackProcess = false;
            	}
                $Gadget.curPage = 1;
                $Gadget.beginRowNum = 0;
                $Controller("besAdRecrollback").query($UI, $Emit, $Gadget,
                        $Page, $Fire);
            },

            query : function($UI, $Emit, $Gadget, $Page, $Fire) {
                // 查询前先进行校验
                $Gadget.loadingInfo = "";
                $Gadget.recrollbackReason = "";
                $Gadget.queryParam = {};
                var flag = $Controller.besAdRecrollback.validateQueryCond($UI,
                        $Gadget);
                if (!flag) {
                    return;
                } else {
                    $Page.showCover = true;
                    var totalRowNum = $Gadget.totalRowNum ? $Gadget.totalRowNum : 0;
                    $Gadget.queryParam.beginRowNum = $Gadget.beginRowNum;
                    $Gadget.queryParam.fetchRowNum = $Gadget.pageSize;
                    $Gadget.queryParam.totalRowNum = totalRowNum;
                    //页面选中是否包括后台业务，不选中就是不包括后台业务就一条数据，传0.选中就是包括，不传 
                    if($Gadget.IsBackProcess){  //选中
                    	$Gadget.queryParam.backProcess = null;
                    }else{
                    	$Gadget.queryParam.backProcess = "0";
                    } 
                    
                    // debugger;
                    $Fire(
                            {
                                'service' : '/recrollbackboservice/queryreception',
                                'params' : {
                                    "req" : $Gadget.queryParam
                                },
                                'target' : '$Gadget.queryOrderInfo',
                                onafter : function($Gadget) {
                                    debugger;
                                    $Gadget.pageShow = '0';
                                    $Page.showCover = false;
                                    $("#pages").empty();
                                    if ($Gadget.queryOrderInfo.reception
                                            && $Gadget.queryOrderInfo.reception.length > 0) {
                                        debugger;
                                        $Gadget.queryOrderInfo.pages = new UCD.Pages(
                                                $("#pages"),
                                                $Gadget.queryOrderInfo.totalRowNum,
                                                $Gadget.pageSize,
                                                [ 10, 20, 50, 100 ],
                                                $Gadget.curPage,
                                                function() {
                                                    if ($Gadget.queryOrderInfo.pages) {
                                                        $Controller.besAdRecrollback
                                                        .turnPage($UI,
                                                                $Emit,
                                                                $Gadget,
                                                                $Page,
                                                                $Fire);
                                                    }
                                                });
                                        debugger;
                                    }
                                },
                                onerror : function() {
                                    $Page.showCover = false;
                                }
                            }, $Gadget);

                    $Gadget.isSelectOrder = false;// 用于控制业务受理列表是否显示
                    $Gadget.isCheck = false;// 是否选中订单行
                    $Gadget.recrollbackReason = "";// 退回原因

                    $Controller.besAdRecrollback.writeBusiLog($Gadget,$Gadget.serviceNumber);
                }

            },

            // 订单详细信息
            showDetailPopup : function($Gadget, $Fire, item) {
                debugger;
                var id = item.bizType == "O" ? item.orderId : item.recId;
                $Gadget.$Emit("$bes.ad.besAdRecrollback.orderDetail", {
                    bizType : item.bizType,
                    detailOrderId : id,
                    orderFee : item.recFee
                });
            },

            // 订单行明细
            linedetailOpen : function($Gadget, item) {
                if (item.orderLineId && item.orderLineId != "") {
                    debugger;
                    $Gadget.orderLineId = item.orderLineId;
                    $Gadget.$Emit("$bes.ad.businessAccepted.lineDetail", {
                        orderLineId : $Gadget.orderLineId,
                    });
                }
            },

            // 翻页事件
            turnPage : function($UI, $Emit, $Gadget, $Page, $Fire) {
                debugger;
                $Gadget.curPage = $Gadget.queryOrderInfo.pages.getSelection();
                $Gadget.beginRowNum = ($Gadget.curPage - 1) * $Gadget.pageSize;
                $Controller.besAdRecrollback.query($UI, $Emit, $Gadget, $Page,
                        $Fire);
            },

            // 点击按钮时触发
            onRadioSelect : function($Gadget, $Fire, item,$Page) {
                debugger;
                //DTS2016020302216
                //判断是否bes上线前办理的老业务 即创建时间<系统参数配置的上线时间
                var findBusiType= false;               
                if($Gadget.besOnLineTime){
                    if($Gadget.besOnLineTime > item.createTime){

                        for(var i=0;i<$Gadget.besRollBackBusiTypeList.length;i++){
                            if(item.busiCode == $Gadget.besRollBackBusiTypeList[i].itemCode){
                                findBusiType = true;
                                //提示老用户在老系统办理
                                $(document).scope().$UI.msgbox.confirm($UEE.i18n("ad.person.label.information"),$UEE.i18n("ad.person.message.GoToTheOldSystem"), function() {
                                    debugger;
                                    var urlStr = window.location.protocol + "//" + window.location.host + "/ngrecmaster/custcare/custsvc/assistbusiness/servicerollback/queryRollBack.do?act=operationRollback";
                                    window.$BES.$Portal.tabpanel
                                    .createTabItemByConf(
                                    "operationRollbackold",
                                    "业务回退（CRM）",
                                    urlStr,
                                    "");
                                    return;
                                },
                                function() {
                                    debugger;
                                    return;
                                });
                            }
                        }
                        if(!findBusiType){
                            //禁止办理回退业务
                            $(document).scope().$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.NoFallback"));
                            return;
                        }
                    }
                }

                if (findBusiType){
                    return;
                }
//                $Gadget.isCheck = true;
//                $Gadget.checkedItem = item;
//                $Gadget.$Page.bizType = $Gadget.checkedItem.bizType;
                // $Controller("besAdRecrollback").showOrderLines($Gadget,
                // item);
                if(item.recType == '2') {
                    $("#rollBackbtn").attr('disabled', 'disabled');
                    return;
                } else {
                    $("#rollBackbtn").removeAttr("disabled");
                }
                //$Gadget.checkedItem已经选中的    （$Gadget.checkedItem未定义表示没有选中项）  item指的是点击选中的项
                if(($Gadget.checkedItem||{}).orderId==item.orderId)  //判断是否是未定义,表示已选中过
                {  
                	if($Gadget.isShowOrderLines){
                		var oneCheckBoxId = "#oneCheckBox" + $Gadget.checkedItem.recId;;
                    	if($(oneCheckBoxId).attr("class").indexOf("checked")>0){
                    		 for ( var i = 0; i < $Gadget.showOrderInfoList.length; i++) {
                                var showInfo = $Gadget.showOrderInfoList[i];
                                if(showInfo.recId == ($Gadget.checkedItem||{}).recId){
                                	showInfo.isShowButton = false;
                                	$Gadget.showOrderInfoList[i] = showInfo;
                                }
                             }
                    	}else{
                    		if(($Gadget.checkedItem||{}).recId ==item.recId){
                                item.isShowButton = false;
                    	    }else{
                    	    	item.isShowButton = true;
                    	    }
                    	}                    	
                	}
                	$Gadget.isCheck = false;
                    $Gadget.checkedItem = null;
                    $Page.checkedItem = null;
                    $Gadget.$Page.opcode = null;                	
                }else{    //已经选择过
                 	item.isShowButton = true;
                    $Gadget.isCheck = true;
                    $("#rollbackop_div").show();
                    $Gadget.recrollbackReason = null;
                    $Gadget.checkedItem = item;
                    $Page.checkedItem = item;
                    $Gadget.$Page.bizType = $Gadget.checkedItem.bizType;
                    $Gadget.$Page.checkedItem = item;
                    $Gadget.$Page.operId = item.createOperId;
                    //根据orderId查询订单详情
                    debugger;
                    $Controller("besAdRecrollback").queryOrderDetail($Gadget);               	
                }
            },

            // 查看执行进度
            onBtnProcessClick : function($Gadget, item) {
                debugger;

                $("#processback").hide();// 由于这里调用了
                $("#recrollback").hide();
                $("#queryBuessinBack").hide();
                $("#orderProgress").show();
                $Gadget.$Emit("$bes.oc.orderprogress", {
                    orderLineId : item.orderLineId,
                    orderId : item.orderId
                });
            },

            // 执行进度页面返回
            btnOrderProgressBack : function() {
                debugger;
                $("#processback").hide();// 由于这里调用了bes-ad-businessaccepted.html页面，但页面中的返回按钮的事件无法对本用例使用，所以把这一按钮隐藏起来，并新增一个。
                $("#recrollback").show();
                $("#orderProgress").hide();
                $("#queryBuessinBack").show();
            },

            // 退回按钮事件
            btnRecrollbackClick : function($Page, $Gadget, $UI, $Fire) {

                debugger;
                $Gadget.$Get('$Fire')({
                	 service : "/recrollbackboservice/checkrecrollbackclick",
 			        params : {
 							createOperId : $Gadget.checkedItem.createOperId
 					},
 					target : "$Gadget.backtion",
 					onafter : function($Gadget) {
 					    debugger;
 					    if ($Gadget.backtion) {
                             $Gadget.times = 5;
                            $Page.showCover = true;
                            //$Page.businessName = "业务回退";
                            $Page.businessName = $UEE.i18n('ad.handclickbroadband.title.bussinessrollback');
                            $Page.selectedRevocationFlag = "false";

                            // 进行后台校验（分四步校验，第一步成功后再每5秒调用第二步;如果第二部校验通过，再调用第三步校验。。。）
                            // 改成先调/queryrechargecard，如果返回为空则直接跳到/checkrollbackorder
                            // 如果/queryrechargecard不为空，则调/checkrechargecard，如果/checkrechargecard返回为空则校验失败，提示充值卡校验失败
                            debugger;
                            //问题单DTS2016032410173 修改，先做校验在做充值卡查询
//                            $Controller("besAdRecrollback").queryRechargeCard($Gadget, $UI,
//                                    $Page);
                            $Controller("besAdRecrollback").checkRollbackOrder($Gadget, $UI,
                                    $Page);
                        } else {
                            //对不起，你没有被授予此业务权限。
                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NoPermission"));
                        }
                    }
                 }, $Gadget);

            },

            // 撤销按钮事件
            btnCancelClick : function($Page, $Gadget, $UI, $Fire) {
                debugger;
                $Gadget.$Get('$Fire')({
                    service : "/recrollbackboservice/checkcancelclick",
                    target : "$Gadget.revocation",
                    onafter : function($Gadget) {
                        debugger;
                        if ($Gadget.revocation) {
                            $Controller.besAdRecrollback.queryOrderCancelDeviceInfo($Page, $Gadget, $UI, $Fire);
                        } else {
                            //对不起，你没有被授予此业务权限
                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NoPermission"));
                        }
                    }
                 }, $Gadget);
            },

            // 撤销功能
            btnCancel : function($Page, $Gadget, $UI, $Fire) {
                debugger;
                $Page.businessName = $UEE.i18n("ad.recrollback.button.cancel");//撤销
                // 获取选择的订单id
                $Page.selectedRevocationFlag = "true";
                $Gadget.validateStatusPartRevocation = $Gadget.validateStatusPartRevocation
                        || {};
                $Fire(
                        {
                            'service' : '/recrollbackboservice/validateorderrevocation',
                            'params' : {
                                req : {
                                    orderId : $Gadget.checkedItem.orderId
                                }
                            },
                            'target' : "$Page.validateStatusPartRevocation",
                            onafter : function() {
                                debugger;
                                // 如果校验通过，进行撤销算费，撤销充值卡校验
                                if ($Controller.besAdRecrollback
                                        .validateStatus(
                                                $Gadget,
                                                $Page.validateStatusPartRevocation)) {
                                    $Controller.besAdRecrollback
                                            .queryRechargeCard($Gadget, $UI,
                                                    $Page);
                                } else {
                                    // 如果校验失败，提示后台展示信息
                                    if ($Gadget.errMessage) {
                                        var message = "";
                                        for ( var i = 0; i < $Gadget.errMessage.length; i++) {
                                            message = message
                                                    + $Gadget.errMessage[i].promptMessage
                                                    + "\n";
                                        }
                                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), message);
                                    }
                                    return;
                                }
                            }
                        }, $Gadget);
            },

            // 部分撤销按钮事件
            btnPartRevocationClick : function($Page, $Gadget, $UI, $Fire) {
                debugger;
                //$UEE.i18n('ad.person.message.information')
                //    $Page.businessName = "部分撤销";
                $Page.businessName = $UEE.i18n('ad.recrollback.button.cancelPartially') ;
                // 获取选择的订单id
                $Page.selectedRevocationFlag = "true";
                $Gadget.validateStatusPartRevocation = $Gadget.validateStatusPartRevocation
                        || {};
                // 获取对应的fulfillOrderIdList
                $Gadget.fulfillIdList = [];
                $.each($Gadget.itemMap || [], function(i, val) {
                    $Gadget.fulfillIdList.push(val.itemKey);
                });


                $Fire(
                        {
                            'service' : '/recrollbackboservice/validateorderrevocation',
                            'params' : {
                                req : {
                                    'orderId' : $Gadget.checkedItem.orderId,
                                    'fulfillOrderId' : $Gadget.fulfillIdList
                                }
                            },
                            'target' : "$Gadget.validateStatusPartRevocation",
                            onafter : function($Page, $Gadget) {
                                debugger;
                                // 如果校验通过，进行撤销算费，撤销充值卡校验
                                if ($Controller.besAdRecrollback.validateStatus($Gadget, $Gadget.validateStatusPartRevocation)) {
                                    //判断订单行下的所有订单项的产品类型，如果有wireDev类型的且对应的履行订单已完成，那么就给出提示：设备押金只能在原订单上做回退处理。
                                    $Fire({
                                        service : '/recrollbackboservice/getorderlinedetail',
                                        params : {
                                            orderlineid : $Gadget.checkedItem.orderLineId
                                        },
                                        target : "$Gadget.orderItemsList",
                                        onafter : function($Gadget, $Fire) {
                                            debugger;
                                            $Gadget.orderItemsList = $Gadget.orderItemsList || [];
                                            var list = [];
                                            $.each($Gadget.orderItemsList, function(i, val) {
                                                if (!val.pOrderItemId || val.pOrderItemId == null || val.pOrderItemId == "") {
                                                    list.push(val);
                                                }
                                                return true;
                                            });
                                            $Gadget.orderItemsList = list;

                                            var alertFlag = false;
                                            $.each($Gadget.orderItemsList, function(i, val) {
                                                if (val.prodType == "PTWire") {
                                                    $.each($Page.partRevocationData, function(j, valj) {
                                                        if (valj.optionalFlag == "N") {
                                                            $.each(valj.orderItemId, function(k, valk) {
                                                                if (valk == val.orderItemId) {
                                                                    alertFlag = true;
                                                                }
                                                            });
                                                        }
                                                    });
                                                }
                                            });

                                            if (alertFlag) {
                                                $UI.msgbox.info($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.recrollback.message.wiredBusinessFulfillmentWarning"), function() {
                                                    $Controller.besAdRecrollback.queryRechargeCard($Gadget, $UI, $Page);
                                                });
                                            } else {
                                                $Controller.besAdRecrollback.queryRechargeCard($Gadget, $UI, $Page);
                                            }
                                        }
                                    }, $Gadget);
                                } else {
                                    // 如果校验失败，提示后台展示信息
                                    if ($Gadget.errMessage) {
                                        var message = "";
                                        for ( var i = 0; i < $Gadget.errMessage.length; i++) {
                                            message = message
                                                    + $Gadget.errMessage[i].promptMessage
                                                    + "\n";
                                        }
                                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), message);
                                    }
                                    return;
                                }
                            }
                        }, $Gadget);
            },

            // 校验返回数据解析
            validateStatus : function($Gadget, data) {
                debugger;
                $Gadget.errMessage = [];
                $Gadget.warnMessage = [];
                if (data.returnMessage && data.returnMessage.retCode == 0) {
                    if (data.returnMessage.busiValidateResult) {
                        for ( var i = 0; i < data.returnMessage.busiValidateResult.length; i++) {
                            if (data.returnMessage.busiValidateResult[i].level == 1
                                    && data.returnMessage.busiValidateResult[i].promptMessage) {
                                $Gadget.warnMessage
                                        .push(data.returnMessage.busiValidateResult[i]);
                            }
                        }
                    }
                    return true;
                } else if (data.returnMessage
                        && data.returnMessage.retCode && data.returnMessage.retCode != 0) {
                    if (data.returnMessage.retMessage) {
                        $Gadget.errMessage.push({
                            "promptMessage" : data.returnMessage.retMessage
                        });
                    }
                    else if (data.returnMessage.busiValidateResult) {
                        for ( var i = 0; i < data.returnMessage.busiValidateResult.length; i++) {
                            if (data.returnMessage.busiValidateResult[i].level == 3
                                    && !data.returnMessage.busiValidateResult[i].validateResult
                                    && data.returnMessage.busiValidateResult[i].promptMessage) {
                                $Gadget.errMessage
                                        .push(data.returnMessage.busiValidateResult[i]);
                            }
                        }
                    }
                    else {
                        //ad.person.message.systemError 系统错误
                        $Gadget.errMessage.push($UEE.i18n("ad.person.message.systemError"));
                    }
                } else {
                    //$Gadget.errMessage.push("系统错误。");
                    // fix DTS2015120210249
                    if(data.returnMessage){
                        $Gadget.$Get("$UI").msgbox.info($UEE.i18n("ad.person.message.information"),data.returnMessage.retMessage);
                    }else{
                        $Gadget.errMessage.push($UEE.i18n("ad.person.message.systemError"));
                    }
                }
                return false;
            },

            // 提交开始
            submitCancelOrder : function($Page, $Fire, $UI, $scope) {
                debugger;
                var request = {};

                // 适配结算页面的$Page用法，变量同名挂在$Page下使用
                request.orderId = $Page.cancelOrderId;
                if ($Page.businessName != "撤销"){
                	// 履行订单
                	request.fulfillmentOrderId = $Page.cancelFulfillmentOrderId
                	|| [];
                }
                // $Page.orderFeeAndPayment = $Page.orderFeeAndPayment || {};
                $Page.serviceRequest = $Page.serviceRequest || [];
                // 发票项
                if ($Page.serviceRequest.invoiceInfo
                        && $Page.serviceRequest.invoiceInfo.invoiceItem
                        && $Page.serviceRequest.invoiceInfo.invoiceItem.length != 0) {
                    request.invoiceInfo = $Page.serviceRequest.invoiceInfo
                            || {};

                    // 费用项
                    request.paymentInfo = $Page.serviceRequest.paymentInfoList
                            || [];
                }
                
                $Controller.besAdRecrollback.setExtInfo(request);
                
                $Controller.besAdRecrollback.submitOrderRevocation(request,
                        $Page, $Fire, $UI, $scope);
            },
            
            setExtInfo: function (request) {
                if ($Page.scanReturnOrderNo) {
                    var extInfo = {
                        "extNodeCode": "SCANCODE_ORDERNO",
                        "extXmlString": $Page.scanReturnOrderNo
                    };

                    $Controller.besAdRecrollback.addExtInfo(request, extInfo);
                }
            },

            addExtInfo: function (req, node) {
                req.extInfo = req.extInfo || {};
                req.extInfo.extNodeInfo = req.extInfo.extNodeInfo || [];
                req.extInfo.extNodeInfo.push(node);
            },
            
            // 提交
            submitOrderRevocation : function(request, $Page, $Fire, $UI, $scope) {
                debugger;
                $Fire(
                        {
                            'service' : '/recrollbackboservice/submitorderrevocation',
                            'params' : {
                                'req' : request
                            },
                            'target' : "$Page.revocationSubmitResp",
                            onafter : function() {
                                debugger;
                                $Page.goToPaymentFinishFlag = false;
                                if ($Page.revocationSubmitResp
                                        && $Page.revocationSubmitResp.responseService
                                        && $Page.revocationSubmitResp.responseService.returnMessage) {
                                    var returnMessage = $Page.revocationSubmitResp.responseService.returnMessage;
                                    // 组装详细失败信息
                                    var errorMsg = "";
                                    if (returnMessage.retCode != "0") {
                                        $.each(returnMessage.busiValidateResult
                                                || [], function(i, vali) {
                                            errorMsg +=  vali.promptMessage
                                                    + "<br/>";
                                        });
                                        $Page.trustErrorRetMessage = $scope
                                                .$Get("$sce").trustAsHtml(
                                                        errorMsg);
                                    }
                                    // 构造提交成功页面显示内容对象
                                    $Page.createOrderResult = {
                                        "createOrderResp" : {
                                            "returnMessage" : returnMessage,
                                            "orderBaseInfo" : {
                                                "refOrderId" : $Page.revocationSubmitResp.responseService.orderId
                                            }
                                        }
                                    };

                                    $Page.paymentFinishStepFlag = true;
                                    $("#checkoutPaymentContent").hide();
                                    $("#paymentFinishStep").show();
                                    $("body").scrollTop(0);
                                }
                            },
                            onerror : function() {
                                $Page.goToPaymentFinishFlag = false;
                            }
                        }, $scope);
            },

            // 撤销调用
            revocationOrder : function($Gadget, $UI, $Page) {
                debugger;
                // 声明
                $Gadget.orderFeeAndPayment = {};
                $Gadget.itemMap = $Gadget.itemMap || [];
                $Gadget.paramList = $Gadget.paramList || [];
                $.each($Gadget.itemMap, function(i, val) {
                    $Gadget.paramList.push(val.itemKey);
                });

                //履行订单
                var fulfillmentIdList = [];
                if ($Gadget.itemMap && $Gadget.itemMap[0]) {
                    fulfillmentIdList.push($Gadget.itemMap[0].itemKey);
                }
                // 先调用退费接口
                $Gadget
                        .$Get("$Fire")
                        (
                                {
                                    'service' : '/recrollbackboservice/queryorderfeeandpayment',
                                    'params' : {
                                        'req' : {
                                            'orderId' : $Gadget.checkedItem.orderId,
                                            'fulfillmentId' : fulfillmentIdList
                                        }
                                    },
                                    'target' : "$Gadget.orderFeeAndPayment",
                                    onafter : function() {
                                        debugger;

                                        // 组装结算页面的费用信息gadget
                                        $Controller.besAdRecrollback
                                                .parkFeeAndPayment($Gadget,
                                                        $Page, $Gadget
                                                                .$Get("$Fire"),
                                                        $UI);
                                        // 组装结算页面的支付方式gadget
                                        $Controller.besAdRecrollback
                                                .parkPaymentMethod($Gadget,
                                                        $Page, $Gadget
                                                                .$Get("$Fire"),
                                                        $UI);

                                        $Gadget.$Get("$Fire")({
                                            "popin" : ""
                                        });

                                        // 挂起一个变量提供给结算页面的提交使用
                                        $Page.serviceRequest = {};
                                        $Page.cancelOrderAndBusinessBackSubmitFlag = "cancelOrder";
                                        $Page.cancelOrderId = $Gadget.checkedItem.orderId;
                                        $Page.cancelFulfillmentOrderId = [];
                                        $
                                                .each(
                                                        $Gadget.itemMap,
                                                        function(i, val) {
                                                            $Page.cancelFulfillmentOrderId
                                                                    .push(val.itemKey);
                                                        });

                                        $Page.orderFeeAndPayment = $Gadget.orderFeeAndPayment
                                                || {};

                                        $Gadget.itemMap = [];
                                        // 去结算页面展示所有信息
                                        $Controller.besAdRecrollback
                                                .checkoutSuccess($Page,
                                                        $Gadget, $UI);

                                    }
                                }, $Gadget);
            },

            // 组装结算页面费用信息gadget
            parkFeeAndPayment : function($Gadget, $Page, $Fire, $UI) {
                debugger;
                // 获取费用项信息
                $Gadget.invoiceInfo = $Gadget.orderFeeAndPayment.invoiceInfo
                        || {};

                if ($Gadget.orderFeeAndPayment && $Gadget.orderFeeAndPayment.orderFeeResp && $Gadget.orderFeeAndPayment.orderFeeResp.invoiceInfo) {
                    $Page.invoiceItem = $Gadget.orderFeeAndPayment.orderFeeResp.invoiceInfo.invoiceItem;
                }
                $Page.orderDetail = $Page.orderDetail || {};

                // 角色类型 
                $Page.orderDetail.invoiceRole = $Gadget.orderFeeAndPayment.invoiceRole;
                // 费用列表转换
                $Page.orderDetail.feeItemList = [];
                $Page.orderDetail.discountAmount = 0;
                $Page.orderDetail.custPaymentInfo = $Gadget.orderFeeAndPayment.paymentInfo || [];
                $.each($Gadget.invoiceInfo || [], function(i, val) {
                    var feeItem = {
                        "currencyId" : val.currencyId,
                        "chargeItemId" : val.chargeCode,
                        "feeClassId" : val.parentChargeName,
                        "orderFee" : val.amount,
                        "orderFeeDisplay":val.amountDisplay,
                        "discount" : val.discountAmount,
                        "waive":val.waiveAmount,
                        "payType" : val.payType,
                        "unitPrice" : val.unitPrice,
                        "unitPriceDisplay" : val.unitPriceDisplay,
                        "quantity" : val.quantity,
                        "chargeName" : val.chargeName,
                        "detailInfo" : $Controller.besAdRecrollback.detailInfobusi($Gadget, $Page, $Page.invoiceItem[i].detailInfo),
                        "invoiceItemId" : val.invoiceItemId,
                        "relaInvoiceItemId" : val.relaInvoiceItemId
                    };
                    $Page.orderDetail.feeItemList.push(feeItem);
                    $Page.orderDetail.discountAmount += (val.discountAmount || 0);
                });
            },

            detailInfobusi : function($Gadget, $Page, data) {
                if (data && data.extInfo && data.extInfo && data.extInfo.extPropInfo && data.extInfo.extPropInfo.length > 0) {
                    $.each(data.extInfo.extPropInfo || [],
                            function(key, val) {
                        val.paramName = val.attrId;
                        val.paramValue = val.attrValue;
                            });
                }
                return data;
            },

            // 组装结算页面支付方式gadeget
            parkPaymentMethod : function($Gadget, $Page, $Fire, $UI) {
                debugger;
                // 获取支付项信息
                $Gadget.paymentInfo = $Gadget.orderFeeAndPayment.paymentInfo
                        || [];
                $Page.orderDetail = $Page.orderDetail || {};

                // 支付列表
                $Page.orderDetail.businessList = [];
                $Page.orderDetail.paidFee = 0;
                $.each($Gadget.paymentInfo || [], function(j, valj) {
                    var business = {
                        "businessId" : valj.paymentId,
                        "bankName" : "",
                        "bankAcct" : "",
                        "paymentType" : valj.paymentMethod,
                        "businessFee" : valj.amount,
                        "businessTime" : valj.paymentDate,
                        "status" : valj.status
                    };
                    $Page.orderDetail.businessList.push(business);
                    $Page.orderDetail.paidFee += (valj.amount || 0);
                });
            },

            // 部分撤销页面初始化
            initPartRevocation : function($Gadget, $Page, $Fire, $UI) {
                debugger;
                // 初始化动态数组
                $Gadget.itemMap = [];
                // 订单部分撤销页面数组
                $Page.orderPartRevocationData = [];
                // 订单撤销显示数组
                $Page.partRevocationData = [];
                // 确认提交的撤销订单数据
                $Page.submitPartRevocationData = [];

                // 调用接口查询部分撤销页面数据数组
                $Fire(
                        {
                            'service' : "/recrollbackboservice/queryrevocation",
                            'params' : {
                                req : {
                                    "orderId" : $Gadget.checkedItem.orderId,
                                    "orderLineId" : $Gadget.checkedItem.orderLineId
                                }
                            },
                            'target' : "$Page.partRevocationResp",
                            onafter : function() {
                                debugger;
                                if ($Page.partRevocationResp) {
                                    // 根据返回的数据，初始化对应的节点显示
                                    $Page.partRevocationData = $Page.partRevocationResp.revocation
                                            || [];
                                } else {
                                    //履行订单为空。
                                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.OrderIsEmpty"));
                                    $Fire({
                                        "popin" : ""
                                    });
                                    return;
                                }
                            }
                        }, $Gadget);

            },

            // 前面按钮点击事件
            clickCheckBox : function($Gadget, $Page, $Item, index) {
                debugger;
                if ($Item.optionalFlag == 'N') {
                    return;
                }
                $Gadget.cancellableOderList = $Gadget.cancellableOderList || [];
                $Gadget.itemMap = $Gadget.itemMap || [];
                $Item.checked = !$Item.checked;

                // list中增加，或者删除
                if ($Item.checked) {
                    // 获取对应的item元素，即value;
                    $Gadget.itemValue = $Item;
                    // 获取对应的index标识，即key;
                    $Gadget.itemKey = $Item.fuifillOrder;
                    // 创建一个对象$Gadget.itemObj;
                    $Gadget.itemObj = {
                        itemValue : $Gadget.itemValue,
                        itemKey : $Gadget.itemKey
                    };
                    // 将对象放入数组，形成map形式
                    $Gadget.itemMap.push($Gadget.itemObj);
                } else {
                    // 获取对应item元素的key
                    var key = $Item.fuifillOrder;
                    // 遍历map中的对象，找到对应的itemKey，进行删除
                    $.each($Gadget.itemMap, function(i, val) {
                        if (val.itemKey == key) {
                            $Gadget.itemMap.splice(i, 1);
                            return false;
                        }
                    });
                }
            },

            // step1:充值卡校验
            queryRechargeCard : function($Gadget, $UI, $Page) {
                debugger;
                //充值卡校验中...
                $Gadget.loadingInfo = $UEE.i18n("ad.person.message.PrepaidCardCheck");
                $Page.showCover = true;

                // 充值卡校验
                $Gadget
                        .$Get("$Fire")
                        (
                                {
                                    'service' : '/recrollbackboservice/queryrechargecard',
                                    'params' : {
                                        "biztype" : $Gadget.checkedItem.bizType,
                                        "recid" : $Gadget.checkedItem.bizType == "O" ? $Gadget.checkedItem.orderId
                                                : $Gadget.checkedItem.recId,
                                        'orderitemidlist' : $Gadget.recrollbackItemList
                                    },
                                    'target' : '$Gadget.queryRechargeCard',
                                    onafter : function($Gadget, $UI) {
                                        debugger;
                                        // 如果第一步校验成功
                                        if ($Gadget.queryRechargeCard) {
                                            debugger;
                                            $Controller("besAdRecrollback")
                                                    .checkRechargeCard($Gadget,
                                                            $UI, $Page);
                                        } else {
                                            debugger;
                                            $Page.showCover = false;
                                            if ($Page.selectedRevocationFlag == "true") {
                                                $Page.selectedRevocationFlag == "false";
                                                $Controller("besAdRecrollback")
                                                        .revocationOrder(
                                                                $Gadget, $UI,
                                                                $Page);
                                            } else {
                                                //问题单DTS2016032410173 修改，将查询服务详情移到此处，将业务回退校验移走
                                                // 查询服务详情
                                                $Controller("besAdRecrollback")
                                                        .queryRecDetail(
                                                                $Gadget, $Page,
                                                                $UI);
//                                                $Controller("besAdRecrollback")
//                                                        .checkRollbackOrder(
//                                                                $Gadget, $UI,
//                                                                $Page);
                                            }
                                        }
                                    },
                                    onerror : function() {
                                        $Page.showCover = false;
                                    }
                                }, $Gadget);
            },

            // 充值卡校验2
            checkRechargeCard : function($Gadget, $UI, $Page) {
                debugger;
                // var i = $Gadget.times + 1;
                $Gadget.loadingInfo = $UEE.i18n("ad.person.message.PrepaidCardCheck");
                $Page.showCover = true;

                $Gadget
                        .$Get("$Fire")
                        (
                                {
                                    'service' : '/recrollbackboservice/checkrechargecard',
                                    'params' : {
                                        "cardnos" : $Gadget.queryRechargeCard
                                    },
                                    'target' : '$Gadget.checkRechargeCard',
                                    onafter : function($Gadget, $UI, $Page) {
                                        debugger;

                                        if ($Gadget.checkRechargeCard) {
                                            // 进行第二步校验,进行5次充值卡状态查询（每五秒试一次）
                                            $Gadget.timer = setInterval(
                                                    function() {
                                                        debugger;
                                                        $Controller(
                                                                "besAdRecrollback")
                                                                .queryRechgCardStatus(
                                                                        $Gadget,
                                                                        $UI,
                                                                        $Page);
                                                    }, $Gadget.cardStatusQueryIntervalTime);
                                        } else {
                                            $Page.showCover = false;
                                            //"充值卡校验失败，请稍后重试。"
                                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
                                                    $UEE.i18n("ad.person.message.RechargeCardValidationFailed"));
                                        }
                                    },
                                    onerror : function() {
                                        $Page.showCover = false;
                                    }
                                }, $Gadget);
            },

            // 充值卡状态查询
            queryRechgCardStatus : function($Gadget, $UI, $Page) {
                debugger;
                // var i = $Gadget.times + 1;
                $Gadget.loadingInfo = $UEE.i18n("ad.person.message.RechargeCardStatus");

                OC.Callchain.setFireSearch($Page.pageId, 'qryresta');


                $Gadget
                        .$Get("$Fire")
                        (
                                {
                                    'service' : '/recrollbackboservice/queryrechgcardstatus',
                                    'params' : {
                                        "req" : $Gadget.checkRechargeCard
                                    },
                                    'target' : '$Gadget.queryRechgCardStatus',
                                    onafter : function($Gadget, $UI, $Page) {
                                        debugger;
                                        $Gadget.times = $Gadget.times - 1;
                                        if ($Gadget.times < 1) {
                                            debugger;
                                            clearInterval($Gadget.timer);
                                            $Page.showCover = false;
                                            //充值卡状态查询失败，请稍后重试。
                                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
                                                    $UEE.i18n("ad.person.message.PleaseTryAgainLater"));
                                            return;
                                        }
                                        // 如果充值卡校验成功，则进行第三步校验。否则，继续进行下一轮校验，直到试5次为止
                                        // 如果返回为0，为成功，1为等待，继续查，如果为非1或0则校验失败
                                        if ($Gadget.queryRechgCardStatus == "0") {
                                            debugger;
                                            $Page.showCover = false;
                                            clearInterval($Gadget.timer);
                                            if ($Page.selectedRevocationFlag == "true") {
                                                $Page.selectedRevocationFlag == "false";
                                                $Controller("besAdRecrollback")
                                                        .revocationOrder(
                                                                $Gadget, $UI,
                                                                $Page);
                                            } else {
                                            $Controller("besAdRecrollback")
                                                        .queryRecDetail(
                                                                $Gadget, $Page,
                                                                $UI);
                                            }
                                            return;
                                        } else {
                                            // 如果为非1或0则校验失败
                                            if ($Gadget.queryRechgCardStatus != "1") {
                                                debugger;
                                                clearInterval($Gadget.timer);
                                                $Page.showCover = false;
                                                $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
                                                        $Gadget.queryRechgCardStatus);
                                            }
                                        }
                                    },
                                    onerror : function() {
                                        $Page.showCover = false;
                                    }
                                }, $Gadget);
            },

            // 业务回退校验
            checkRollbackOrder : function($Gadget, $UI, $Page) {
                //$Gadget.loadingInfo = "业务回退校验中...";
                $Gadget.loadingInfo = $UEE.i18n("ad.person.title.CheckBackInBusiness");

                // 挂起全局变量，路由业务回退
                $Page.cancelOrderAndBusinessBackSubmitFlag = "businessBack";
                debugger;

                // 查询参数，业务类型为订单O传orderId,服务S传recId
                var id = $Gadget.checkedItem.orderId;
                if ($Gadget.checkedItem.bizType == 'S') {
                    debugger;
                    id = $Gadget.checkedItem.recId;
                }

                var request = {
                    "recId" : id,
                    "bizType" : $Gadget.checkedItem.bizType,
                    "serviceNumber":$Gadget.checkedItem.serviceNumber
                };
                if ($Gadget.reasonCode == "TransferWithTel") {
                    request.specFlag = "Y";
                }
                // 如果是部分订单项回退，则在request中加入订单项的list
                if ($Gadget.recrollbackItemList) {
                    request.orderItemId = $Gadget.recrollbackItemList;
                }


                $Gadget
                        .$Get("$Fire")
                        (
                                {
                                    'service' : '/recrollbackboservice/checkrollbackorder',
                                    'params' : {
                                        checkrollbackreq:request
                                    },
                                    'target' : '$Gadget.OmOrdSrvReturnMessageXMLVO',
                                    onafter : function($Gadget, $UI, $Page) {
                                        debugger;
                                        $Page.showCover = false;
                                        // 如果返回的为空的话，则显示结算页面
                                        if ($Gadget.OmOrdSrvReturnMessageXMLVO) {
                                            // 0时为成功
                                            if ($Gadget.OmOrdSrvReturnMessageXMLVO.serviceResponse.returnMessage.retCode == '0') {
                                                var busiValidateResult = $Gadget.OmOrdSrvReturnMessageXMLVO.serviceResponse.returnMessage.busiValidateResult;
                                                if (busiValidateResult) {
                                                    for ( var i = 0; i < busiValidateResult.length; i++) {
                                                        if (busiValidateResult[i].validateResult == false
                                                                && busiValidateResult[i].level == '1') {
                                                            $UI.msgbox
                                                                    .info(
                                                                            $UEE.i18n("ad.person.message.information"),
                                                                            busiValidateResult[i].promptMessage);
                                                        }
                                                    }
                                                }
                                                $Page.checkedItem = $Gadget.checkedItem;
                                                //问题单DTS2016032410173 修改，将充值卡校验已到此处进行处理
                                                $Controller("besAdRecrollback").queryRechargeCard($Gadget, $UI,
                                                        $Page);


                                                //问题单DTS2016032410173 修改，将查询服务详情移到充值卡校验中
                                                // 查询服务详情
//                                                $Controller("besAdRecrollback")
//                                                        .queryRecDetail(
//                                                                $Gadget, $Page,
//                                                                $UI);
                                            } else {
                                                // var msg = '';
                                                // var msgCnt =
                                                // $Gadget.OmOrdSrvReturnMessageXMLVO.serviceResponse.returnMessage.busiValidateResult.length;
                                                // if (msgCnt = 1) {
                                                // $UI.msgbox
                                                // .info(
                                                // "提示",
                                                // $Gadget.OmOrdSrvReturnMessageXMLVO.serviceResponse.returnMessage.busiValidateResult[0].promptMessage);
                                                // } else {
                                                // for ( var i = 1; i <= msgCnt;
                                                // i++) {
                                                //
                                                // msg = i
                                                // + ". "
                                                // +
                                                // $Gadget.OmOrdSrvReturnMessageXMLVO.serviceResponse.returnMessage.busiValidateResult[i].promptMessage
                                                // + '\n';
                                                // }
                                                // $UI.msgbox.info("提示", msg);
                                                // }
                                                // return;
                                                $UI.msgbox
                                                        .info(
                                                                $UEE.i18n("ad.person.message.information"),
                                                                $Gadget.OmOrdSrvReturnMessageXMLVO.serviceResponse.returnMessage.retMessage);
                                                return;
                                            }

                                        } else {
                                            // 1为失败，把错误信息显示给用户
                                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.BusinessBackCheckFailed"));
                                            return;
                                        }
                                    },
                                    onerror : function() {
                                        $Page.showCover = false;
                                    }
                                }, $Gadget);
            },

            // 显示订单行
            showOrderLines : function($Gadget, item) {
                debugger;
                //表示是否触发点击“查看业务受理”按钮事件
                $Gadget.isShowOrderLines = true;
                // 查询条件隐藏
                $("#recrollback_queryConId").hide();
                // 查询列表隐藏
                $("#recrollback_queryTable").hide();
                $("#recrollback_titleId").hide();
                $("#recrollback_contentId").hide();
                $("#queryBuessinBack").show();
                $("#rollbackop_div").show();
                //用来展示业务受理的
                $Gadget.clickItem = null; 
                $Gadget.checkedItem = null;
                $Gadget.isCheck = null;
                $Gadget.detailOrderId = item.orderId;
                $Gadget.isSelectOrder = true;
                $Gadget.expandButton = true;
                //选中包括后台业务的复选框，与原来保持一致
                if($Gadget.IsBackProcess){
                	 // 根据订单id找到选中的订单行
                    for ( var i = 0; i < $Gadget.queryOrderInfo.reception.length; i++) {
                        if ($Gadget.queryOrderInfo.reception[i].recId == item.recId) {
                            $Gadget.clickItem = $Gadget.queryOrderInfo.reception[i];
                            break;
                        }
                    }
                //不选中后台业务，那就重新调用接口，查看所有的业务受理列表 
                }else{
                	if(item.busiCode == 'FamilyFuseInstall'){
                		$Gadget.queryOrderInfoParam = {};
                    	var totalRowNum = $Gadget.totalRowNum ? $Gadget.totalRowNum : 0;
                    	$Gadget.queryOrderInfoParam.beginRowNum = $Gadget.beginRowNum;
                    	$Gadget.queryOrderInfoParam.fetchRowNum = $Gadget.pageSize;
                    	$Gadget.queryOrderInfoParam.totalRowNum = totalRowNum;
                    	$Gadget.queryOrderInfoParam.recId = item.orderId;
                    	$Gadget.queryOrderInfoParam.custName = item.custName;
                    	$Gadget.queryOrderInfoParam.backProcess = null;
                        // debugger;
                        $Gadget.$Get("$Fire")(
                           {
                                'service' : '/recrollbackboservice/queryreception',
                                'params' : {
                                     "req" : $Gadget.queryOrderInfoParam
                                 },
                                 'target' : '$Gadget.queryOrderInfoList',
                                 onafter : function($Gadget) {
                                     debugger;
                                     $Gadget.showOrderInfoList = [];
                                     if ($Gadget.queryOrderInfoList.reception && $Gadget.queryOrderInfoList.reception.length > 0) {
                                          debugger;
                                          //目的，给$Gadget.queryOrderInfoList.reception塞个属性
                                          for(var i = 0; i < $Gadget.queryOrderInfoList.reception.length; i++){
                                        	  var queryOrderInfo = $Gadget.queryOrderInfoList.reception[i];
                                        	  queryOrderInfo.expandButton = true;
                                        	  queryOrderInfo.isShowButton = false; //默认不展示展示按钮 ，选中后才会展示
                                        	  $Gadget.showOrderInfoList.push(queryOrderInfo);
                                          }
                                          
                                     } 
                                }
                        }, $Gadget);
                	}else{
                		 $Gadget.showOrderInfoList = [];
                		 for(var i = 0; i < $Gadget.queryOrderInfo.reception.length; i++){
                			 if ($Gadget.queryOrderInfo.reception[i].recId == item.recId) {
                				 $Gadget.queryOrderInfo.reception[i].expandButton = true;
                    			 $Gadget.queryOrderInfo.reception[i].isShowButton = false; //默认不展示展示按钮 ，选中后才会展示
                           	     $Gadget.showOrderInfoList.push($Gadget.queryOrderInfo.reception[i]);
                           	     break;
                			 }
                         }
                	}
                }
            },
            // mdy by wwx162658 【江苏移动】【C30产品实例化功能测试】【oc】【业务回退】【电信公共】业务回退菜单中，点击查看业务受理进入业务受理列表，在此页面中无返回按钮，且覆盖了原来的业务回退页面，无法返回业务回退菜单中
            btnQueryBuessinBack : function($Gadget)
            {
                // 查询条件隐藏
                $("#recrollback_queryConId").show();
                // 查询列表隐藏
                $("#recrollback_queryTable").show();
                $("#recrollback_titleId").show();
                $("#recrollback_contentId").show();
                $("#queryBuessinBack").hide();
                $Gadget.isSelectOrder = false;
                $("#rollbackop_div").hide();
                $Gadget.checkedItem = null;
                $Gadget.isCheck = null;
            },

            // 查询校验
            validateQueryCond : function($UI, $Gadget) {
                // debugger;
                $Gadget.checkedItem = {};
                $Gadget.queryserviceNumber = "";
                $Gadget.queryOrderId = "";
                var beginTime = $Gadget.beginTime;
                var endTime = $Gadget.endTime;

                if ("" == $.trim($Gadget.queryType)) {
                    //请选择查询方式。
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SelectQueryMode"));
                    return false;
                }

                if ($Gadget.queryType == '1') {
                    $Gadget.queryParam.serviceNumber = $Gadget.serviceNumber;
                }

                if ($Gadget.queryType == '2') {
                    $Gadget.queryParam.recId = $Gadget.orderId;
                }

                if ($Gadget.queryType == '1') {
                    if ("" == $.trim(beginTime)) {
                        //ad.error.tips.selectStartTime 请选择开始时间。
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.error.tips.selectStartTime"));
                        return false;
                    }

//                    if (beginTime.length != 0) {
//                        var reg = /^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/;
//                        var r = beginTime.match(reg);
//                        if (r == null) {
//                            $UI.msgbox.info("提示", "您输入的开始时间日期格式不正确!");
//                            return;
//                        }
//                    }
                    if ("" == $.trim(endTime)) {
                        //请选择结束时间
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.error.tips.selectEndTime"));
                        return false;
                    }
//                    if (endTime.length != 0) {
//                        var reg = /^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/;
//                        var r = endTime.match(reg);
//                        if (r == null) {
//                            $UI.msgbox.info("提示", "您输入的结束时间日期格式不正确!");
//                            return;
//                        }
//                    }
                    if (endTime < beginTime) {
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.StartNotGreaterEnd"));
                        return false;
                    }

                    if (this.isDiffMonth($Gadget.beginTime,$Gadget.endTime)) {
                        // 只能查询一个月内的订单，不能跨月查询。
                        //$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n('ad.exceptionorderretry.message.inquirewithinoneorders'));
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.theSameMonthOrder"));
                        return;
                    }
                    // DTS2016052401750
                    /*var reg = new RegExp("^[0-9]*$");
                    if ($Gadget.serviceNumber && !reg.test($Gadget.serviceNumber))
                    {
                        // 手机号码不合法，请重新输入。
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.PNINVPRE"));
                        $Gadget.serviceNumber = "";
                        return false;
                    }*/

                    // 改为当天的0时0分0秒开始
//                    var queryBeginTime = new Date(beginTime.replace(/-/g, "/"));
//                    queryBeginTime.setHours(0);
//                    queryBeginTime.setMinutes(0);
//                    queryBeginTime.setSeconds(0);
                    $Gadget.queryParam.beginTime = beginTime;

                    // 改为当天的23时59分59秒开始
//                    var queryEndTime = new Date(endTime.replace(/-/g, "/"));
//                    queryEndTime.setHours(23);
//                    queryEndTime.setMinutes(59);
//                    queryEndTime.setSeconds(59);
                    $Gadget.queryParam.endTime = endTime;
                }
                return true;
            },

            /**
             * 计算起止日期是否超过两个月
             */
            isDiffMonth : function(beginTime, endTime) {
                debugger;
                // 时间差的毫秒数
                var date3 = endTime - beginTime;
                // 计算出相差天数
                var days = Math.floor(date3 / (24 * 3600 * 1000));
                if (days > 30) {
                    return true;
                }
                return false;
            },


            // 查询服务详情
            queryRecDetail : function($Gadget, $Page, $UI) {
                debugger;

                OC.Callchain.setFireSearch($Page.pageId, "qryrecde");

                if ($Gadget.checkedItem.bizType == "O") {




                    $Gadget
                            .$Get("$Fire")
                            (
                                    {
                                        'service' : '/queryorderboservice/queryorderdetail',
                                        'params' : {
                                            "orderid" : $Gadget.checkedItem.orderId
                                        },
                                        'target' : '$Page.orderDetail',
                                        onafter : function($Page) {
                                            $Gadget.recrollbackItemList = $Gadget.recrollbackItemList
                                                    || [];
                                            if ($Gadget.recrollbackItemList.length > 0) {
                                                $Controller.besAdRecrollback
                                                        .recrollBackOrderFee(
                                                                $Gadget, $Page,
                                                                $UI);
                                            } else {
                                                $Page.serviceRequest = {};
                                                // 原来在结算页面获取的信息依赖于业务回退gadget，现在放在page里
                                                $Page.bizType = $Gadget.checkedItem.bizType;
                                                $Page.rollbackRecId = $Gadget.checkedItem.orderId;
                                                $Page.recrollbackReason = $Gadget.recrollbackReason;
                                                $Page.reasonCode = $Gadget.reasonCode;

                                                $Controller("besAdRecrollback")
                                                        .checkoutSuccess($Page,
                                                                $Gadget, $UI);
                                            }
                                        }
                                    }, $Gadget);
                }
                // 如果业务类型为服务则调用新的接口
                else if ($Gadget.checkedItem.bizType == "S") {



                    $Gadget
                            .$Get("$Fire")
                            (
                                    {
                                        'service' : '/recrollbackboservice/queryreceptiondetail',
                                        'params' : {
                                            "orderid" : $Gadget.checkedItem.recId
                                        },
                                        'target' : '$Page.receptionDetail',
                                        onafter : function($Gadget, $Page) {
                                            debugger;
                                            $Page.orderDetail = $Controller(
                                                    "besOcRollBack")
                                                    .assembleOrderDetail(
                                                            $Page.receptionDetail);
                                            // 部分订单项回退调用算费接口
                                            if ($Gadget.recrollbackItemList && $Gadget.recrollbackItemList.length > 0) {
                                                $Controller.besAdRecrollback
                                                        .recrollBackOrderFee(
                                                                $Gadget, $Page,
                                                                $UI);
                                            } else {
                                                $Page.serviceRequest = {};
                                                // 原来在结算页面获取的信息依赖于业务回退gadget，现在放在page里
                                                $Page.bizType = $Gadget.checkedItem.bizType;
                                                $Page.rollbackRecId = $Gadget.checkedItem.recId;
                                                $Page.recrollbackReason = $Gadget.recrollbackReason;
                                                $Page.reasonCode = $Gadget.reasonCode;

                                                $Controller("besAdRecrollback")
                                                        .checkoutSuccess($Page,
                                                                $Gadget, $UI);
                                            }
                                        }
                                    }, $Gadget);
                }
            },

            checkoutSuccess : function($Page, $Gadget, $UI) {
                // 成功后显示checkout页面
                debugger;

                $(document).scope().$Get('$timeout')(function() {
                    // 防止重复提交
                    if ($Page.goToCheckoutFlag) {
                        return;
                    }

                    $Page.goToCheckoutFlag = true;
                    // 费用明细
                    $Page.checkoutInfo = {
                        serviceNumber : $Gadget.checkedItem.serviceNumber,
                        businessName : $Page.businessName
                    };
                    $Page.paymentContentFlag = "true";
                    $("#recrollbackQuery").hide();
                    $("#ochasRecommend").hide();
                    $("#recommendoffer").hide();
                    $("#paymentContent").show();
                    $("body").scrollTop(0);
                }, 1);
            },

            // 返回修改
            btnReturnClick : function($Page) {
                $Page.goToCheckoutFlag = false;
                $Page.paymentContentFlag = false;
                // 如果是两次一号撤销，返回修改要特殊处理
                if ("TransferWithTel" == $Page.specialFlagForYou) {
                    $("#ochasRecommend").show();
                    $("#recommendoffer").show();
                    $Controller.bes.personalunifiedview.showRevoke($(
                            "#cardrevoke_revoke").scope().$Gadget, $Page);
                }
                $("#recrollbackQuery").show();
                $("#paymentContent").hide();
            },

            // 展开、收藏
            changeBtn : function($Gadget, $Fire, item, index) {
                debugger;
                if (0 == index) {
                    // 展开
                    $Gadget.expandButton = false;
                    // 订单行下的顶层Offering订单项,调用OH的QueryOrderLineDetailEx
                    $Controller.besAdRecrollback.queryOrderItems($Gadget,
                            $Fire, item);
                } else {
                    $Gadget.expandButton = true;
                }
            },
            
            changeListBtn : function($Gadget, $Fire, item, index) {
                debugger;
               
                if (0 == index) {
                    // 展开
                	item.expandButton = false;
                	$Gadget.expandButton = false;
                    // 订单行下的顶层Offering订单项,调用OH的QueryOrderLineDetailEx
                    $Controller.besAdRecrollback.queryOrderItems($Gadget,
                            $Fire, item);
                } else {
                	item.expandButton = true;
                    $Gadget.expandButton = true;
                }
            },
            
            // 获取订单行下的顶层订单项
            queryOrderItems : function($Gadget, $Fire, item) {
                debugger;


                // 订单行下的顶层Offering订单项,调用OH的QueryOrderLineDetailEx,入参:orderLineId
                $Fire(
                        {
                            service : '/recrollbackboservice/getorderlinedetail',
                            params : {
                                orderlineid : item.orderLineId
                            },
                            target : "$Gadget.orderItemsList",
                            onafter : function($Gadget, $Fire) {
                                debugger;
                                $Gadget.orderItemsList = $Gadget.orderItemsList || [];
                                // 需要办理回退的订单项
                                $Gadget.recrollbackItemList = [];
                                $Gadget.$Page.recrollbackItemList = $Gadget.recrollbackItemList;
                                var list = [];
                                $.each($Gadget.orderItemsList,
                                        function(i, val) {
                                            if (!val.pOrderItemId
                                                    || val.pOrderItemId == null
                                                    || val.pOrderItemId == "") {
                                                val.selected = false;
                                                list.push(val);
                                            }
                                            return true;
                                        });
                                $Gadget.orderItemsList = list;
                                if(item.busiCode == "ChangeProduct"){
                                    $Controller.besAdRecrollback.queryOfferingBaseInfoByIdList($Gadget, $Fire);
                                }
                                // if($Gadget.checkedItem == $Gadget.clickItem){
                                // $Gadget.recrollbackItemList =
                                // $.extend(true,{},$Gadget.orderItemsList);
                                // }
                            }
                        }, $Gadget);
            },

            queryOfferingBaseInfoByIdList : function($Gadget, $Fire){
                debugger;
                var offeringIdList = [];
                $.each($Gadget.orderItemsList,function(i, val){
                    offeringIdList.push(val.itemId);
                });
                $Gadget.mainOfferingList = [];
                $Gadget.otherOfferingList= [];
                $Fire({
                            service : '/recrollbackboservice/queryOfferingBaseInfoByIdList',
                            params : {
                                'offeringIdList' : offeringIdList
                            },
                            target : "$Gadget.offeringBasicInfoList",
                            onafter : function($Gadget, $Fire) {
                                debugger;
                                $.each($Gadget.offeringBasicInfoList || [],function(j, valj){
                                    if("Y" == valj.isPrimary){
                                        $Gadget.mainOfferingList.push(valj);
                                        //return true;
                                    }
                                    $Gadget.otherOfferingList.push(valj);
                                });
                                // 去除订单 非资费类的订单项，不显示 --- DTS2016120107769
                                if($Gadget.otherOfferingList.length > 0){
                                	for(var m=$Gadget.orderItemsList.length-1; m>=0; m--){
                                		$Gadget.isFlag=true;
                                		$.each($Gadget.otherOfferingList,function(n, valn){
                                			if($Gadget.orderItemsList[m].itemId == valn.offeringId){
                                				$Gadget.isFlag=false;
                                				return false;
                                			}
                                		});
                                		if($Gadget.isFlag){
                                			$Gadget.orderItemsList.splice(m,1);
                                		}
                                	}									
                                }
                                if($Gadget.mainOfferingList.length > 0){
                                    // 去除主offer订单项，不在页面展示
                                    for(var m=$Gadget.orderItemsList.length-1; m>=0; m--){
                                        $.each($Gadget.mainOfferingList,function(n, valn){
                                            if($Gadget.orderItemsList[m].itemId == valn.offeringId){
                                                $Gadget.orderItemsList.splice(m,1);
                                                return false;
                                            }
                                        });
                                    }
                                    // 查询主offer下必选增值offer并去除订单项，不在页面展示
                                    $Controller.besAdRecrollback.queryOfferingRelation($Gadget, $Fire);
                                }
                            }
                }, $Gadget);
            },

            queryOfferingRelation : function($Gadget, $Fire){
                debugger;
                $Gadget.mainOffering1 = null;
                $Gadget.mainOffering2 = null;
                if($Gadget.mainOfferingList.length == 2){
                    $Gadget.mainOffering1 = $Gadget.mainOfferingList[0];
                    $Gadget.mainOffering2 = $Gadget.mainOfferingList[1];
                }
                if($Gadget.mainOfferingList.length == 1){
                    $Gadget.mainOffering1 = $Gadget.mainOfferingList[0];
                }
                var offeringid1 = $Gadget.mainOffering1.offeringId;

                $Fire({
                    service : "/bes.agentdesktop.group.groupofferservice/queryofferingrelation",
                    params : {
                        'relationtype' : 'N',
                        'offeringid' : offeringid1
                    },
                    target : "$Gadget.data.goodslists1",
                    onafter : function($Gadget, $Fire) {
                        debugger;
                        if(($Gadget.data.goodslists1 || []).length > 0){
                            for(var j=$Gadget.orderItemsList.length-1; j>=0; j--){
                                $.each($Gadget.data.goodslists1, function(m,valm){
                                    if($Gadget.orderItemsList[j].itemId == valm.destEntryId){
                                        $Gadget.orderItemsList.splice(j,1);
                                        return false;
                                    }
                                });
                            }
                        }
                        if($Gadget.mainOffering2){
                            var offeringid2 = $Gadget.mainOffering2.offeringId;
                            $Fire({
                                service : "/bes.agentdesktop.group.groupofferservice/queryofferingrelation",
                                params : {
                                    'relationtype' : 'N',
                                    'offeringid' : offeringid2
                                },
                                target : "$Gadget.data.goodslists2",
                                onafter : function() {
                                    debugger;
                                    if(($Gadget.data.goodslists2 || []).length > 0){
                                        for(var j=$Gadget.orderItemsList.length-1; j>=0; j--){
                                            $.each($Gadget.data.goodslists2, function(m,valm){
                                                if($Gadget.orderItemsList[j].itemId == valm.destEntryId){
                                                    $Gadget.orderItemsList.splice(j,1);
                                                    return false;
                                                }
                                            });
                                        }
                                    }
                                }
                            },$Gadget);
                        }
                    }
                }, $Gadget);
            },

            orderItemClick : function($Gadget, $Fire, data) {
                debugger;
                if ($("#recrollback_orderItem" + data.orderItemId).hasClass(
                        'selected')) {
                    // $("#recrollback_orderItem"+data.orderItemId).removeClass('selected');
                    data.selected = false;
                    $Gadget.recrollbackItemList.splice($.inArray(
                            data.orderItemId, $Gadget.recrollbackItemList), 1);
                } else {
                    // $("#recrollback_orderItem"+data.orderItemId).addClass('selected');
                    data.selected = true;
                    $Gadget.recrollbackItemList.push(data.orderItemId);
                }
                // if($Gadget.recrollbackItemList.length ==
                // $Gadget.orderItemsList.length){
                // $Gadget.checkedItem = $Gadget.clickItem;
                // }else if($Gadget.recrollbackItemList.length == 0){
                // $Gadget.isCheck = false;
                // $Gadget.checkedItem = null;
                // }else if($Gadget.recrollbackItemList.length <
                // $Gadget.orderItemsList.length){
                // $Gadget.checkedItem = $Gadget.clickItem;
                // }
                if ($Gadget.recrollbackItemList.length > 0) {
                    $Gadget.checkedItem = $Gadget.clickItem;
                    $Gadget.$Page.bizType = $Gadget.checkedItem.bizType;
                } else {
                    $Gadget.checkedItem = null;
                    $Gadget.isCheck = false;
                }
                if ($Gadget.checkedItem == $Gadget.clickItem) {
                    $Gadget.isCheck = true;
                    $Page.checkedItem = $Gadget.checkedItem;
                    $Gadget.$Page.bizType = $Gadget.checkedItem.bizType;
                }
            },
            
            orderItemListClick : function($Gadget, $Fire, data ,$Item) {
                debugger;
                if ($("#recrollback_orderItem" + data.orderItemId).hasClass(
                        'selected')) {
                    // $("#recrollback_orderItem"+data.orderItemId).removeClass('selected');
                    data.selected = false;
                    $Gadget.recrollbackItemList.splice($.inArray(
                            data.orderItemId, $Gadget.recrollbackItemList), 1);
                } else {
                    // $("#recrollback_orderItem"+data.orderItemId).addClass('selected');
                    data.selected = true;
                    $Gadget.recrollbackItemList.push(data.orderItemId);
                }
                
                if ($Gadget.recrollbackItemList.length > 0) {
                    $Gadget.checkedItem = $Item;
                    $Gadget.$Page.bizType = $Gadget.checkedItem.bizType;
                } else {
                    $Gadget.checkedItem = null;
                    $Gadget.isCheck = false;
                }
                if ($Gadget.checkedItem == $Item) {
                    $Gadget.isCheck = true;
                    $Page.checkedItem = $Gadget.checkedItem;
                    $Gadget.$Page.bizType = $Gadget.checkedItem.bizType;
                }
            },

            orderItemClickAfter : function($Gadget) {
                debugger;
                if ($Gadget.recrollbackItemList.length == $Gadget.orderItemsList.length - 1) {
                    $.each($Gadget.recrollbackItemList, function(i, val) {
                        $("#recrollback_orderItem" + val.orderItemId).addClass(
                                'selected');
                        return true;
                    });
                }
            },

            // 获取指定订单项列表对应的费用
            recrollBackOrderFee : function($Gadget, $Page, $UI) {
                var request = {
                    'req' : {
                        'orderId' : $Gadget.checkedItem.orderId,
                        'fulfillmentId' : []
                    }
                };
                if ($Gadget.recrollbackItemList) {
                    request.req.orderItemId = $Gadget.recrollbackItemList;
                }


                $Gadget
                        .$Get("$Fire")
                        (
                                {
                                    'service' : '/recrollbackboservice/queryorderfeeandpayment',
                                    'params' : request,
                                    'target' : "$Gadget.orderFeeAndPayment",
                                    onafter : function() {
                                        debugger;
                                        // 组装结算页面的费用信息gadget
                                        $Controller.besAdRecrollback
                                                .parkFeeAndPayment($Gadget,
                                                        $Page, $Gadget
                                                                .$Get("$Fire"),
                                                        $UI);
                                        // 组装结算页面的支付方式gadget
                                        $Controller.besAdRecrollback
                                                .parkPaymentMethod($Gadget,
                                                        $Page, $Gadget
                                                                .$Get("$Fire"),
                                                        $UI);
                                        // 原来在结算页面获取的信息依赖于业务回退gadget，现在放在page里
                                        $Page.bizType = $Gadget.checkedItem.bizType;
                                        //$Page.rollbackRecId = $Gadget.checkedItem.recId;
                                        $Page.rollbackRecId = $Gadget.checkedItem.bizType == "O" ? $Gadget.checkedItem.orderId
                                                    : $Gadget.checkedItem.recId;
                                        $Page.recrollbackReason = $Gadget.recrollbackReason;
                                        $Page.reasonCode = $Gadget.reasonCode;
                                        // 去结算页面展示所有信息
                                        $Controller.besAdRecrollback
                                                .checkoutSuccess($Page,
                                                        $Gadget, $UI);
                                    }
                                }, $Gadget);
            },

            // 查询order详情
            queryOrderDetail : function($Gadget) {
                // 如果业务类型为订单则调用原来的接口

                if ($Gadget.checkedItem.bizType == "O") {

                    $Gadget
                            .$Get("$Fire")
                            (
                                    {
                                        'service' : '/queryorderboservice/queryorderdetail',
                                        'params' : {
                                            "orderid" : $Gadget.checkedItem.orderId
                                        },
                                        'target' : '$Gadget.data.OrderDetail',
                                        onafter : function($Gadget) {
                                            debugger;
                                            if ($Gadget.data.OrderDetail && $Gadget.data.OrderDetail.paymentInfos) {
                                                $Gadget.$Page.paymentInfos = $Gadget.data.OrderDetail.paymentInfos;
                                                //paymentInfo.getPaymentProp().get(0).getParamName()
                                                $Gadget.data.paymentMethod = $.extend(true,{},$Gadget.data.OrderDetail.paymentInfos);
                                                $.each($Gadget.data.paymentMethod || [], function(i, val) {
                                                    if (val.paymentMethod == 8012 || val.paymentMethod == 8012) {
                                                        $Gadget.$Page.opcode = $Gadget.$Page.opcode || {};
                                                        $Gadget.$Page.opcode.orderId = $Gadget.checkedItem.orderId;
                                                        $Gadget.$Page.opcode.createOperId = $Gadget.checkedItem.createOperId;
                                                        $Gadget.$Page.opcode.createTime = $Gadget.checkedItem.createTime;
                                                        $Gadget.$Page.opcode.paymentProp = [];
                                                        $.each(val.paymentProp || [], function(i, valProp) {
                                                            if(valProp.paramName == "taskoid") {
                                                                $Gadget.$Page.opcode.paymentProp.push(valProp);
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        }
                                    }, $Gadget);
                }

                // 如果业务类型为服务则调用新的接口()
                if ($Gadget.checkedItem.bizType == "S") {

                    $Gadget.$Get("$Fire")
                            (
                                    {
                                        'service' : '/recrollbackboservice/queryreceptiondetail',
                                        'params' : {
                                            "orderid" : $Gadget.checkedItem.orderId
                                        },
                                        'target' : '$Gadget.data.recdetail',
                                        onafter : function($Gadget) {
                                            debugger;
                                            if ($Gadget.data.recdetail && $Gadget.data.recdetail.receptionPayment) {
                                                $Gadget.$Page.paymentInfos = $Gadget.data.recdetail.receptionPayment;
                                                $Gadget.data.paymentMethod = $.extend(true,{},$Gadget.data.recdetail.receptionPayment);
                                                $.each($Gadget.data.paymentMethod || [], function(i, val) {
                                                    if (val.paymentMethod == 8012 || val.paymentMethod == 8010) {
                                                        $Gadget.$Page.opcode = $Gadget.$Page.opcode || {};
                                                        $Gadget.$Page.opcode.orderId = $Gadget.checkedItem.orderId;
                                                        $Gadget.$Page.opcode.createOperId = $Gadget.checkedItem.createOperId;
                                                        $Gadget.$Page.opcode.createTime = $Gadget.checkedItem.createTime;
                                                        $Gadget.$Page.opcode.paymentProp = [];
                                                        $.each(val.paymentProp || [], function(i, valProp) {
                                                            if(valProp.paramName == "taskoid") {
                                                                $Gadget.$Page.opcode.paymentProp.push(valProp);
                                                            }
                                                        });
                                                    }
                                                });
                                            }
                                        }
                                    }, $Gadget);
                }
            },

            undoanonymity : function($Page,$Gadget,$Item,$index,custName){
                var totalRowNum = $Gadget.totalRowNum ? $Gadget.totalRowNum : 0;
                $Gadget.queryParam.beginRowNum = $Gadget.beginRowNum;
                $Gadget.queryParam.fetchRowNum = $Gadget.pageSize;
                $Gadget.queryParam.totalRowNum = totalRowNum;
                $Gadget.queryParam.recId = $Item.recId;
                $Gadget.queryParam.custName = custName;
               
                // debugger;
                $Gadget
                .$Get("$Fire")(
                        {
                            'service' : '/recrollbackboservice/queryreception',
                            'params' : {
                                "req" : $Gadget.queryParam
                            },
                            'target' : '$Gadget.queryOrderInfoShow',
                            onafter : function($Gadget) {
                                debugger;
                                if ($Gadget.queryOrderInfoShow.reception
                                        && $Gadget.queryOrderInfoShow.reception.length > 0) {
                                    debugger;
                                    $("#showCustName" + $index).hide();
                                    $("#recrollback_custName" + $index).html($Gadget.queryOrderInfoShow.reception[0].custName);
                                }
                            },
                            onerror : function() {
                                $Page.showCover = false;
                            }
                        }, $Gadget);
            },

            showEquipment : function($Gadget,$Fire)
            {
                debugger;
                //在摊开设备弹框之前，先关闭部分撤销弹框
                $Fire({
                    "popin" : ""
                });

                $Fire({
                    "popup" : {
                        "id" : "addDeviceRecv",
                        "title" : $UEE.i18n("ad.person.title.ClaimedDevice"),
                        "width" : "900px",
                        "height" : "380px",
                        "src" : "resource.root/bes/ad/ctz/html/bes-ad-recrollback/bes-ad-recrollback-equipment.html",
                        "resizable" : "false"
                    }
                }, $Gadget);
            },

            queryCancelDeviceInfo : function($Page,$Gadget,$UI,$Fire,request)
            {
                debugger;
                $Fire(
                        {
                            'service' : 'querycanceldeviceInfoservice/querycanceldeviceinfo',
                            'params' : request,
                            'target' : '$Page.canceldeviceinfo',
                            'onafter' : function() {
                                debugger;
                                if($Page.canceldeviceinfo.body && $Page.canceldeviceinfo.body.length>0)
                                {
                                    $Controller.besAdRecrollback.showEquipment($Gadget,$Fire);
                                }
                                else
                                {
                                    if($Page.flag == "O")
                                    {
                                        $Controller.besAdRecrollback.btnCancel($Page,$Gadget,$UI,$Fire);
                                    }
                                    else
                                    {
                                        $Controller.besAdRecrollback.btnPartRevocationClick($Page,$Gadget,$UI,$Fire);
                                    }
                                }
                            }
                        }, $Gadget);
            },

            // 撤销订单查询已领取设备
            queryOrderCancelDeviceInfo : function($Page,$Gadget,$UI,$Fire)
            {
                $Page.flag = "O";
                debugger;
                var request = {
                        header : {
                            loginToken : "",
                            loginId : "",
                            locale : "",
                            serialId : ""
                        },
                        body : {
                            orderId : $Gadget.checkedItem.orderId,
                            fulfillmentOrderId:""
                        }
                    };
                $Controller.besAdRecrollback.queryCancelDeviceInfo($Page,$Gadget,$UI,$Fire,request);
            },

            // 撤销部分订单查询已领取设备
            queryPartOrderCancelDeviceInfo : function($Page,$Gadget,$UI,$Fire)
            {
                $Page.flag = "P";
                debugger;
                if($Page.partRevocationResp.revocation.length < 2){
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.TheOrderCannotBePartiallyRevoked"));
                }
                else
                {
                    var request = {
                            header : {
                                loginToken : "",
                                loginId : "",
                                locale : "",
                                serialId : ""
                            },
                            body : {
                                orderId : $Gadget.checkedItem.orderId,
                                fulfillmentOrderId : $Gadget.checkedItem.orderLineId
                            }
                        };
                    $Controller.besAdRecrollback.queryCancelDeviceInfo($Page,$Gadget,$UI,$Fire,request);
                }
            },
            writeBusiLog : function($Gadget,servNum) {
                debugger;
                $Gadget.logParamIn = {};
                $Gadget.logParamIn.servNum = servNum;
                $Gadget.logParamIn.menuId = "60131701";
                $Gadget.logParamIn.moduleId = "60131";
                //$Gadget.logParamIn.businessObject=servNum;
                $Gadget.logParamIn.objectType='S';
                $Gadget.logParamIn.operType = "QryRollbackRecLogs";


                $Gadget.$Get("$Fire")({
                    service : '/LogService/createOperLog',
                    params : {
                        logParamIn : $Gadget.logParamIn
                    },
                    target : '$Gadget.data.createOperLogResult',
                    onafter : function($Gadget) {
                        debugger;
                        $Gadget.showCover = false;
                    },
                    onerror : function() {
                        $Gadget.showCover = false;
                    }
                }, $Gadget);
            },
            getAuthInfo:function($Gadget){
                debugger;
                var $Fire = $Gadget.$Get("$Fire");



                $Fire({
                    service : '/OcQueryReceptionService/getAuthInfo',
                    params : {},
                    target : '$Gadget.authInfo',
                    onafter : function() {
                        debugger;
                        $Gadget.authInfo = $Gadget.authInfo || {};
                        $Gadget.authServNum = $Gadget.authInfo.authServNum || "";
                        $Gadget.serviceNumber = $Gadget.authServNum;
                        },
                    onerror : function() {
                        $Gadget.authServNum = "";
                        $Gadget.serviceNumber = $Gadget.authServNum;
                        }
                    }, $Gadget);
            },

            //部分撤销前，先进行公共提示，部分撤销有线业务后，如有设备押金，请在撤销完成后部分回退押金营销案
            partUndoButton : function($Gadget, $Fire, $UI)
            {
                debugger;
                // 山东代码清理  begin  by 292225
               /* if ($Page.projectVersion && $Page.projectVersion =="SHANDONG"){
                	$Gadget.$Get("$Fire")(
                            {
                                'service' : '/recrollbackboservice/queryecashlog',
                                'params' : {
                                    "orderId" : $Gadget.checkedItem.orderId
                                },
                                'target' : '$Gadget.queryEcashLog',
                                onafter : function($Gadget) {
                                    debugger;
                                    if ($Gadget.queryEcashLog && $Gadget.queryEcashLog.ecashPayInfList && $Gadget.queryEcashLog.ecashPayInfList.length > 0){
                                    	$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "当前回退的订单拥有电子券支付的支付方式，不允许部分撤销！");
                                    	return;
                                    }
                                    $UI.msgbox.info($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.recrollback.message.wiredBusinessPublicTips"), function() {
                                        $Fire({
                                            "popup" : {
                                                "id" : "partRecatPopWindowBoxwrap",
                                                "title" : $UEE.i18n('ad.person.title.PartialRevocation'),
                                                "width" : "720px",
                                                "height" : "400px",
                                                "src" : "resource.root/bes/ad/ctz/html/bes-ad-recrollback/bes-ad-recrollback-partrevocation.html",
                                                "resizable" : "false"
                                            }
                                        }, $Gadget);
                                    });
                                },
                                onerror : function() {
                                	return;
                                }
                            }, $Gadget);
                }*/
                //else {
                	$UI.msgbox.info($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.recrollback.message.wiredBusinessPublicTips"), function() {
                        $Fire({
                            "popup" : {
                                "id" : "partRecatPopWindowBoxwrap",
                                "title" : $UEE.i18n('ad.person.title.PartialRevocation'),
                                "width" : "720px",
                                "height" : "400px",
                                "src" : "resource.root/bes/ad/ctz/html/bes-ad-recrollback/bes-ad-recrollback-partrevocation.html",
                                "resizable" : "false"
                            }
                        }, $Gadget);
                    });
               // }   山东代码清理 end by292225
            }

        });
