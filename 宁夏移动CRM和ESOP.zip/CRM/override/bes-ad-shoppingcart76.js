$Controller("bes.ad.shoppingcart", {
	init : function($Gadget,$UI){
		debugger;
		
		$Gadget.data = {};
		$Gadget.data.shoppingcar = [];
		$Gadget.data.shoppingcar = ($(document).scope().$Page.data||{}).carofferingList;
		$.each($Gadget.data.shoppingcar||[],function(i,val){
			//生失效日期
			//$Controller.bes.ad.shoppingcart.effectivedate(val);
			
			//图标class
			if(val.opCode == '1'){
			    val.opClass = 'icon_subscribe';
				//生失效日期
				$Controller.bes.ad.shoppingcart.effectivedate(val);
			}
			else if(val.opCode == '2'){
				val.opClass = 'icon_transform';
			}
			else if(val.opCode == '3'){
				val.opClass = 'icon_unsubscribe';
				//生失效日期
				$Controller.bes.ad.shoppingcart.effectivedate(val);
			}
			//下拉
			if((val.subOfferings || []).length > 0){
				$.each(val.subOfferings || [],function(j,valj){
					valj.displaysuboffer = false;
					val.arrowdownflag = false;
					if(valj.opCode == '1'){
						valj.opClass = 'icon_subscribe';
						//生失效日期
						$Controller.bes.ad.shoppingcart.effectivedate(valj);
						val.arrowdownflag = true;
						valj.displaysuboffer = true;
					}
					else if(valj.opCode == '2'){
						valj.opClass = 'icon_transform';
						val.arrowdownflag = true;
						valj.displaysuboffer = true;
					}
					else if(valj.opCode == '3'){
						valj.opClass = 'icon_unsubscribe';
						//生失效日期
						$Controller.bes.ad.shoppingcart.effectivedate(valj);
						val.arrowdownflag = true;
						valj.displaysuboffer = true;
					}
				});
			}
			
		
			
		});
		
		
		
		var orderscrollbar;
		setTimeout(function(){
			debugger;
		    orderscrollbar= new ucd.DefaultScroll({
		        scrollObj: $("#orderScrollbar")
		    });
		    orderscrollbar.refreshScroll();//刷新滚动条
		}, 50);
		
		$Gadget.$Emit("$ShoppingCartReady");
		var aThumb= $(".shoppingCar:eq(0)").get(0);
		$(".shoppingCar:eq(0)").css({
		 right:($(window).width()-$('.max_area').width())/2+30
		});
		$(".shoppingCar:eq(0)").css({
		 left:$(".shoppingCar:eq(0)").offset().left,
		 _ysp_top:$(".shoppingCar:eq(0)").offset()._ysp_top
		});
		Drag.init(aThumb, null, 0, $(window).width(), 0, $(window).height());
	},
	
	effectivedate : function(offeringinfo){
		  if((!offeringinfo.effectiveWay || ((offeringinfo.effectiveWay || {}).effectiveTypes||[]).length == 0) && (!offeringinfo.expirationWay || ((offeringinfo.expirationWay || {}).expirationTypes||[]).length == 0 )){
		   return;
		  }
		  var value = "";
		  var key = "";
		  if(offeringinfo.opCode == '1' || offeringinfo.opCode == '2'){
		   
		   value = $Controller.bes.ad.shoppingcart.getValueByKey(offeringinfo.effectiveWay.selectedKey,offeringinfo.effectiveWay.effectiveTypes);
		   if(((offeringinfo.effectiveWay || {}).effectiveTypes||[]).length == 1){
		    key = offeringinfo.effectiveWay.effectiveTypes[0].key;
		   }
		   else  {
		    key = offeringinfo.effectiveWay.selectedKey;
		   }
		  }
		  else if(offeringinfo.opCode == '3')
		  {
		   value = $Controller.bes.ad.shoppingcart.getValueByKey(offeringinfo.expirationWay.selectedKey,offeringinfo.expirationWay.expirationTypes);
		   if(((offeringinfo.expirationWay || {}).expirationTypes||[]).length == 1){
		    key = offeringinfo.expirationWay.expirationTypes[0].key;
		   }
		   else  {
		    key = offeringinfo.expirationWay.selectedKey;
		   }
		  }
		  
		  
		  
		  if(offeringinfo.opCode == '1' || offeringinfo.opCode == '2'){
		   if(key == 'C'){
		    offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.effectiveWay.effectiveDate)).Format("yyyy-MM-dd");
		   }
		   else if(key == 'S'){
		    offeringinfo.displaydate = value + ' : ' + offeringinfo.effectiveWay.durationValue + offeringinfo.effectiveWay.durationUnit.value;
		   }
		   else if(key == 'F'){
		    offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.effectiveWay.fixStartDate)).Format("yyyy-MM-dd");
		   }
		   else if(key == 'BEM'){
		    offeringinfo.displaydate = "";
		   }
		   else{
		    offeringinfo.displaydate = value;
		   }
		  }
		  else if(offeringinfo.opCode == '3'){
		   if(key == 'C'){
		    offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.expirationWay.expirationDate)).Format("yyyy-MM-dd");
		   }
		   else if(key == 'S'){
		    offeringinfo.displaydate = value + ' : ' + offeringinfo.expirationWay.durationValue + offeringinfo.expirationWay.durationUnit.value;
		   }
		   else if(key == 'F'){
		    offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.expirationWay.fixEndDate)).Format("yyyy-MM-dd");
		   }
		   else {
		    offeringinfo.displaydate = value;
		   }
		  }
		 },
	getValueByKey:function(key,Types){
		if((Types||[]).length == 1){
			return Types[0].value;
		}
		var value = "";
		$.each(Types||[],function(i,val){
			if(val.key == key){
				value = val.value;
				return false;
			}
		});
		return value;
	},
	cancel : function($Gadget,$UI,index){
		
		debugger;
		var cancelOffer =  $Gadget.data.shoppingcar[index];
		
		//不为空设置空数组
		$Gadget.$Page.promInfoList=$Gadget.$Page.promInfoList||[];
		
		//删除营销存在数据
		for(var m=0;m<$Gadget.$Page.promInfoList.length;m++){
			if($Controller.bes.ad.shoppingcart.isSameOffer($Gadget.$Page.promInfoList[m], cancelOffer)){
				$Gadget.$Page.promInfoList.splice(m, 1);
				break;
			}
		}
		
		$Gadget.data.shoppingcar.splice(index, 1);
		$.each($Gadget.data.shoppingcar,function(i,val){
			if(val.postPointOfferingId == cancelOffer.offeringId){
				val.postPointOfferingId = null;
				val.postPointOfferingInstId = null;
			}
		});
		
		var delOfferingId = null;
		if(cancelOffer.relatedTransOldOffering){
			delOfferingId = cancelOffer.relatedTransOldOffering.offeringId;
		}
		$.each($Gadget.data.shoppingcar ,function(i,val){
			if(delOfferingId == val.offeringId){
				$Gadget.data.shoppingcar.splice(i,1);
				return false;
			}
		});
		if(($Gadget.data.shoppingcar||[]).length == 0){
			$(".recommend").show();
		}
		$.extend($Gadget.$Attrs.model,$Gadget.data.shoppingcar);
	},
	
	showDayConvert: function($Gadget,offeringinfo){
		$Gadget.dayConvertOfferInfo = {
			offerName: offeringinfo.offeringName,
			offerCode: offeringinfo.offeringCode
		};
		$Gadget.$Get("$Fire")({
			"popup" : {
				"id":"dayConvertPop",
				"title" : "按天计费信息查询",
				"width" : "900px",
				"height" : "480px",
				"src":"{{$Webapp}}/bes/ad/themes/default/template/bes-ad-shoppingcart/bes-ad-dayconvertpop.html",
				"resizable":false
			}
		}, $Gadget);
	},
	
	modify:function($Gadget,$UI,offeringinfo,$index){
		debugger;
		var $Page = $(document).scope().$Page;
		
		if(window._ysp_top.unifiedProductPopupFlag)
		{
			var $PartShade = $('.unifiedPartShade:eq(0)');
			$PartShade.animate({
				left:$("#groupproduct_btn_sure").offset().left,
				_ysp_top:$("#groupproduct_btn_sure").offset()._ysp_top,
				width:0,
				height:0
				},300);
			window._ysp_top.unifiedProductPopupFlag ="";
		}
		else if(window._ysp_top.productPopupFlag){
			var $PartShade = $('.partShade:eq(0)');
			$PartShade.animate({
				left:$("#groupproduct_btn_cancel").offset().left,
				_ysp_top:$("#groupproduct_btn_cancel").offset()._ysp_top,
				width:0,
				height:0
				},300);
			window._ysp_top.productPopupFlag ="";
		}
		//家庭产品begin
		//var jtwProduct = $(document).scope().isFamilyProd(offeringinfo);
		//4G多终端共享，demo数据中没有ocOfferInfo，和ocProductInfo,所以暂时写死
		//var jtwProduct = $Controller.bes.ad.shoppingcart.isFamilyAttachedProd(offeringinfo);
		var jtwProduct = $(document).scope().isFamilyProd(offeringinfo);
		if(jtwProduct) {
			$Page.isShowJTW = true;
			$Page.jtwProduct = jtwProduct;
			$Page.familyOffering = $.extend(true, {}, offeringinfo);
			$Page.familyOffering.opCode = '1';
			$Page.familyisReady = true;
		}
		//4G多终端共享，demo数据中没有ocOfferInfo，和ocProductInfo,所以暂时写死
       /* if (offeringinfo.offeringId == "10000000000000000606" && $Page.projectVersion=="SHANDONG") 
        {
            $Page.isShowJTW = true;
            var product = offeringList[i].ocProductInfoVA || offeringList[i].product;
        	//product[0].opCode = "1";
            jtwProduct = product[0];
			$Page.jtwProduct = jtwProduct;
			$Page.familyOffering = $.extend(true, {}, offeringinfo);
			$Page.familyOffering.opCode = '1';
			$Page.familyisReady = true;
        }*/
		$Page.productFlag = "MODIFY";
		//家庭产品end
		//$Gadget.$safeApply($Gadget,function(){
			$Page.data.offeringinfo = $.extend(true,{},offeringinfo);;
			$Page.data.realofferinginfo = offeringinfo;
			$Page.data.offeringId = offeringinfo.offeringId;
		//});
		
		if(offeringinfo.opCode == '1'){
			if(offeringinfo.goodType == "goodSale"){
				$Page.offeringId = offeringinfo.offeringId;
				if($Page.agentFlag == "AGENT_SALE"){
					$Gadget.$Get('$Fire')({targetstep:'agentproductsale'});	
				}
				else{
					$Gadget.$Get('$Fire')({targetstep:'personalsale'});					
				}
			}
			else if(offeringinfo.levelBaseInfo){

				//营销活动
				debugger;
				
				//添加批次ID、档次ID、商品订购MODE
				$Gadget.$Page.params={
						"offeringId":offeringinfo.offeringId,
						"levelId":offeringinfo.levelBaseInfo.offeringId,
						"mode":"ChangeProduct"
				};
				
				//跳转到营销活动
				$Gadget.$Get('$Fire')({targetstep:'promotionsetting'});
			}
			//转套餐
			else if(offeringinfo.relatedTransOldOffering){
				window._ysp_top.unifiedProductPopupFlag='6';
				$Controller.bes.personalunifiedview.showPartShade($("#personalunifiedmaininner"));
			}
			
			else{
				//window._ysp_top.productPopupFlag='1';
				var obj = "attachChildModify"+$index;
				$Controller.bes.oc.productorder.showPartShade($("#"+obj));
			
			}
		}
		else if(offeringinfo.opCode == '2'){
			//变更
			//window._ysp_top.unifiedProductPopupFlag='2';
			$Controller.bes.personalunifiedview.showPartShade($("#personalunifiedmaininner"),'2');
		}
		else if(offeringinfo.opCode == '3'){
			//window._ysp_top.unifiedProductPopupFlag='3';
			$Controller.bes.personalunifiedview.showPartShade($("#personalunifiedmaininner"),'3');
		}
		
	},
	disableBtn:function(id){
		$(id).attr('disabled', 'disabled');
	},
	gotocheckoutfromcar : function($Gadget,$UI){
		debugger;
		//按钮失效
		if((($Gadget.data || {}).shoppingcar || []).length == 0){
			return;
		}
		$Controller.bes.ad.shoppingcart.disableBtn('#gotocheckoutfromcar');
		dontTouchDataOfWholePage();
		$Controller.bes.ad.shoppingcart.gocheckout($Gadget,$UI,$Gadget.data.shoppingcar);
		
	},
	
	setDeviceRecvOfferingList:function(deviceRecvOfferingList){
		$.each(deviceRecvOfferingList||[],function(j,valj){
			valj.relaItemId = adutil.getNextNumber();
			valj.opCode = '1';
			$.each(valj.product||[],function(k,valk){
				valk.relaItemId = adutil.getNextNumber();
				valk.opCode = '1';
			});
		});
	},
	
	gerateofferingList:function(offeringList){
		debugger;
		
		$.each(offeringList||[],function(i,val){
			//转套餐 升降级 时候需要展示一个删除的offering 这个只是为了展示  
			//组装保温的时候老offer是放在心offer下面传给后端
			if(val.justForDisplay){
				offeringList.splice(i,1);
				return true;
			}
			if(val.relatedTransOldOffering){
				val.relatedTransOldOffering.relaItemId = adutil.getNextNumber();	
			}
			// 设备领取
			$Controller.bes.ad.shoppingcart.setDeviceRecvOfferingList(val.deviceRecvOfferingList);
			
			val.relaItemId = adutil.getNextNumber();
			if(val.product && val.product.length > 0){
				
				$.each(val.product ,function(p,pro){
					pro.relaItemId = adutil.getNextNumber();
					pro.opCode = val.opCode;
				});
				
				//去除掉无用的产品
				if(!val.product[0].prodId){
					val.product = null;
				}
			}
			//去除无用的有线业务信息
			if(val.wiredProdAttr && val.wiredProdAttr.newCardInfo && (!val.wiredProdAttr.newCardInfo.skuId)){
				val.wiredProdAttr.newCardInfo = null;
			}
			
			if(val.isBundled && val.subOfferings){
				$Controller.bes.ad.shoppingcart.genereateSubOffer(val.subOfferings);
			}
			
		});
	},

	gerateoffering:function(offering){
		debugger;
		//转套餐 升降级 时候需要展示一个删除的offering 这个只是为了展示  
		//组装保温的时候老offer是放在心offer下面传给后端
		if(offering.justForDisplay){
			return true;
		}
		if(offering.relatedTransOldOffering){
			offering.relatedTransOldOffering.relaItemId = adutil.getNextNumber();	
		}
		
		offering.relaItemId = adutil.getNextNumber();
		if(offering.product && offering.product.length > 0){
			
			$.each(offering.product ,function(p,pro){
				pro.relaItemId = adutil.getNextNumber();
				pro.opCode = offering.opCode;
			});
			
			//去除掉无用的产品
			if(!offering.product[0].prodId){
				offering.product = null;
			}
		}
		//去除无用的有线业务信息
		if(offering.wiredProdAttr && offering.wiredProdAttr.newCardInfo && (!offering.wiredProdAttr.newCardInfo.skuId)){
			offering.wiredProdAttr.newCardInfo = null;
		}
		
		if(offering.isBundled && offering.subOfferings){
			$Controller.bes.ad.shoppingcart.genereateSubOffer(offering.subOfferings);
		}
	},
	
	genereateSubOffer:function(subOfferings){

		//去除无效的子offer
		var list = [];
		$.each(subOfferings||[],function(j,valj){
			if(valj.opCode == '1' || valj.opCode == '2' || valj.opCode == '3'){
				list.push(valj);
			}
		});
		subOfferings.length = 0;
		$.extend(subOfferings,list);
		
		//处理子offer生失效方式
		$.each(subOfferings||[],function(k,valk){
			
			if(valk.isBundled && valk.subOfferings){
				//O-O-O结构 底层offering直接使用父级opCode
				var selectNum = 0;
				// 去除包上所挂无效产品   DTS2017060614714 选择了子商品经busivalidate接口校验之后说没有选子商品 Author:cwx430960
				valk.product = null;
				$.each(valk.subOfferings||[],function(i,vali){
					if(valk.opCode == 1 && vali.selectType == 'M'){
						vali.opCode = 1;
					}else if(valk.opCode == 3){
						vali.opCode = vali.offeringInstId ? 3:null;
					}
					if(vali.opCode){
						selectNum++;
					}
				});
				if(selectNum == 0 && (valk.subOfferings||[]).length > 0 && valk.opCode ==1){
						valk.subOfferings[0].opCode  = valk.opCode;
				}
				$Controller.bes.ad.shoppingcart.genereateSubOffer(valk.subOfferings);
			}
			
			valk.relaItemId = adutil.getNextNumber();
			if(valk.product && valk.product.length > 0){
				$.each(valk.product ,function(p,pro){
					pro.relaItemId = adutil.getNextNumber();
					pro.opCode = valk.opCode;
				});
			}
			
			// 设备领取
			$Controller.bes.ad.shoppingcart.setDeviceRecvOfferingList(valk.deviceRecvOfferingList);
			
			//去除无用的有线业务信息
			if(valk.wiredProdAttr && valk.wiredProdAttr.newCardInfo && (!valk.wiredProdAttr.newCardInfo.skuId)){
				valk.wiredProdAttr.newCardInfo = null;
			}
			
			if(valk.effectiveWay){
				
				var effectiveTypes = [];
				$.each(valk.effectiveWay.effectiveTypes||[],function(l,vall){
					if(vall.key == valk.effectiveWay.selectedKey){
						vall.selected = true;
						effectiveTypes.push(vall);
						return false;
					}
					
				});
				valk.effectiveWay.effectiveTypes = 	effectiveTypes;
			}
			
			if(valk.expirationWay){
					var expirationTypes = [];
					$.each(valk.expirationWay.expirationTypes||[],function(l,vall){
						if(vall.key == valk.expirationWay.selectedKey){
							vall.selected = true;
							expirationTypes.push(vall);
							return false;
						}
						
					});
					valk.expirationWay.expirationTypes = 	expirationTypes;
				}
		});
	},
	enableBtn:function(id){
		$(id).attr('disabled', null);
	},

	//家庭产品过滤子包
	filterOfferings : function(offering) {
		debugger;
		if (offering.isBundled) {
			var subOfferings = offering.subOfferings || [];
			var temp = [];
			// 如果已选产品是家庭网产品包
			for ( var i = 0; i < subOfferings.length; i++) {
				if (subOfferings[i].checked) {
					temp.push(subOfferings[i]);
				}
			}
			offering.subOfferings = temp;
		}
		return offering;
	},

	gocheckout:function($Gadget,$UI,offeringList){
		debugger;
		$Fire = $Gadget.$Get('$Fire');
		var $Page = $(document).scope().$Page;
		// 结算页面保存业务类型  by z00283015 for DTS2015101100934  on 2015/10/12
		$Page.businessCode = "ChangeProduct";
		var tempList = $.extend(true,[],offeringList);
		$Controller.bes.ad.shoppingcart.gerateofferingList(tempList);
		
		//家庭产品begin
		var familyOfferList = [];
		for(var i=0; i<offeringList.length; i++) {
			var prod = $(document).scope().isFamilyProd(offeringList[i]);
			//var prod = $Controller.bes.ad.shoppingcart.isFamilyAttachedProd(offeringList[i])|| [];
			// //4G多终端共享，demo数据中没有ocOfferInfo，和ocProductInfo,所以暂时写死,有同时订购的情况
			if(prod) {
				var offerFamily = $.extend(true,{},offeringList[i]);
				var familyOffer = this.filterOfferings(offerFamily);
				familyOfferList.push(familyOffer);
			}
			/*if(offeringList[i].offeringId == "10000000000000000606" && $Page.projectVersion=="SHANDONG") 
			{
				var product = offeringList[i].ocProductInfoVA || offeringList[i].product;
        		product[0].opCode = "1";
            	prod = product[0];
            	var offerFamily = $.extend(true,{},offeringList[i]);
				var familyOffer = this.filterOfferings(offerFamily);
				familyOfferList.push(familyOffer);
			}*/
		}
		tempList = $.grep(tempList,function(val,i){
			return !$(document).scope().isFamilyProd(val);
		});
		//家庭产品end
		
		debugger;
		
		//营销活动begin
		$Page.promInfoList=$Page.promInfoList||[];
		
		//保存营销方案列表
		for(var m=0;m<$Page.promInfoList.length;m++){
			
			for(var n=0; n<tempList.length; n++)
			{
				//判断产品ID是否相同
				if($Controller.bes.ad.shoppingcart.isSameOffer($Page.promInfoList[m], tempList[n])){
					
					//删除营销方案
					tempList.splice(n,1);
					break;
				}
			}
		}
		//营销活动end
		
		$Page.agentFlag = $Page.agentFlag || "";
		//成功后提交校验报文
		
		$Page.checkoutInfo = {
				businessName:"商品订购",
				serviceNumber: $Page.serviceNumber
		};
		//4G多终端共享测试
		/*if ($Page.projectVersion=="SHANDONG" && offeringList[0].offeringId=="10000000000000000606") 
		{
			tempList = [];
		}*/
		
		$Page.checkoutValidateBody = {businessType: "ChangeProduct",
				createOrderReq:{
					order:{
						orderPayment:[]
					}
				},	
			mixturePOJO:{
				offerings:tempList,familyOfferings:familyOfferList,promInfoList:$Page.promInfoList,
				businessType:$Page.agentFlag
			}
		}
		$Fire({
	        service : 'bes.agentdesktop.checkoutboservice/busivalidate',
	        params:{
	        	header:{},
	        	"checkoutbody": $Page.checkoutValidateBody
	        },
	        target : '$Page.checkoutValidateResult',
	        onafter : function(){
	        	debugger;
	        	youCanTouchDataOfWholePage();
	        	
	        	if (adutil.checkUcecResp($Page.checkoutValidateResult.header, $UI)) {
					var busiValidCheck = adutil.checkBusiValidResp(null,$UI,$Page.checkoutValidateResult.body.checkOutResp, function(){
						// 点击确认按钮表示继续执行，到结算页面
						debugger;
							
						if($Page.notNeedBackStep){
		        			//主体产品变更的时候不使用step方式
		        			$Controller.bes.ad.personalmainofferchange.validateSucess($Gadget,$Page);
		        		}
		        		else{
		        			$Page.backStep = "index";
		        			$Gadget.$Get('$Fire')({targetstep:"checkout"});
		        		}
						// 跳到结算页面引入样式
						 $("<link>").attr({ 
	 							rel: "stylesheet",
	       					type: "text/css",
	       					href: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/base.css"
	   				 	}).appendTo("head");
						
					});
					
					
					if(busiValidCheck){
						if($Page.notNeedBackStep){
		        			//主体产品变更的时候不使用step方式
		        			$Controller.bes.ad.personalmainofferchange.validateSucess($Gadget,$Page);
		        		}
		        		else{
		        			$Page.backStep = "index";
		        			$Gadget.$Get('$Fire')({targetstep:"checkout"});
		        		}
					}
					
				}
	        }
		},$Gadget);
	},
	checkoutSuccess: function($Page){
		// 成功后显示checkout页面
		debugger;
		$(document).scope().$Get('$timeout')(function(){
			$Page.paymentContentFlag=true;
			$("#paymentContent").show();
			$("#recommend").hide();
			$("#shoppingcart").hide();
			$("#productordergadget").hide();
			$("body").scrollTop(0);
	    },1);
			
	},
	orerClose : function(){
		debugger;
		//var winW = $(window).width();
		$(".recommend").show();
		if($(".recommend").css('display')!='block'){
			$(".main_outer .wrap > div").animate({"margin-right":"0px"}, 300);
			}
	    $(".currentOrder").animate({right:-300}, 300,function(){
	    	$(this).hide();
	    });
		$(".headerMenu0").removeClass('active');
		
		$("li.hide_list").hide();
	},
	
	openCart : function(target){
			debugger;
			$(".bes-ad-shoppingcart .currentOrder").css({'display':'block'});
			$("li.hide_list").show();
			$(".header_menu .header_menu_child").siblings(".active").removeClass("active");
			//$(target).addClass("active");
			//if(!$(".has_recommend").length){
			$(".recommend").hide();
			$(".main_outer .wrap > div").animate({"margin-right":$(".currentOrder").width()+10}, 270);
			$(".currentOrder").css({right:-240,'display':'block'}).animate({right:+0},500).show();
			 //orderscrollbar.refreshScroll();//刷新滚动条	
			
			//var shoppingcarGadget = $(".bes-ad-shoppingcart").scope().$$childTail.$Gadget;
			//$Controller.bes.ad.shoppingcart.init(shoppingcarGadget);
			
	},
	
	//加入购物车
	addtoshoppingcart : function(offeringinfo){
		debugger;
		if((parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0) && window._ysp_top.shoppingcart && window._ysp_top.shoppingcart.carofferingList){
			window._ysp_top.shoppingcart.carofferingList.push(offeringinfo);
		}
		else if(parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length == 0){
			$Page.data.carofferingList.push(offeringinfo);
		}
	},

    /**
	 * 判断是否同商品（兼容营销方案）
	 */
    isSameOffer : function(offer, offerCompare) {
    	if (offer && offerCompare){
    		// 默认是批次编码相同即可。
    		if (offer.offeringId == offerCompare.offeringId) {
    			// 如果存在档次，需要判断档次是否相同
    			if (offer.levelBaseInfo && offerCompare.levelBaseInfo){
    				if (offer.levelBaseInfo.offeringId == offerCompare.levelBaseInfo.offeringId){
    					return true;
    				}
    			} else {				        		
    				return true;
    			}
    		}
    	}
    	return false;
    }
});



