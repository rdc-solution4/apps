/**
 * 全局当前订单组件（类购物车）
 * 功能：该组件用于保存、展示当前将要提交订单的商品，包括业务的增删改
 */
$Controller("bes.ad.staticshoppingcar", {
    init: function($Gadget,$UI) {
        debugger;
        $Gadget.data = $Gadget.data || {};
        $Gadget.data.emailchecked = true;
       // $Page.isNotifyBy139Email = "1";
        $Page.isNotifyBy139Email = "0";
        $Gadget.projectVersion="";
		$Gadget.isHDHoffer = false;
        window._ysp_top.shoppingcart = window._ysp_top.shoppingcart || {};
        window._ysp_top.shoppingcart.hasparentshoppingcar = true;
        window._ysp_top.shoppingcart.carofferingList = window._ysp_top.shoppingcart.carofferingList || [];
        window._ysp_top.shoppingcart.offeringinfo = window._ysp_top.shoppingcart.offeringinfo || {};
        $Gadget.data.shoppingcar = window._ysp_top.shoppingcart.carofferingList || [];
        window._ysp_top.shoppingcart.cartraceidList = window._ysp_top.shoppingcart.cartraceidList || [];
        window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
        window._ysp_top.shoppingcart.$Pagea.salesFlag= window._ysp_top.shoppingcart.$Pagea.salesFlag || "";

        //  在购物车页面维护变量previousTraceIDs hwx234390
        window._ysp_top.shoppingcart.previousTraceIDs = "";
		$Fire = $Gadget.$Get('$Fire');
        $Controller.bes.ad.staticshoppingcar.querySystemParamsVersion($Fire, $Gadget);


		var newofferinfo={};
		var currentoffer={};
		var modifyofferinfo={};
		var modifyitem={};
		var isNew =false;
		var isModified=false;
        $.each($Gadget.data.shoppingcar || [], function(i, val) {
            //生失效日期

            //图标class
            if (val.opCode == '1') {
                val.opClass = 'icon_subscribe';
                //生失效日期
                $Controller.bes.ad.staticshoppingcar.effectivedate(val);
            } else if (val.opCode == '2') {
                val.opClass = 'icon_transform';
            } else if (val.opCode == '3') {
                val.opClass = 'icon_unsubscribe';
                //生失效日期
                $Controller.bes.ad.staticshoppingcar.effectivedate(val);
            }
            //下拉
            if ((val.subOfferings || []).length > 0) {
                $.each(val.subOfferings || [], function(j, valj) {
                    valj.displaysuboffer = false;
                    val.arrowdownflag = false;
                    if (valj.opCode == '1') {
                        valj.opClass = 'icon_subscribe';
                        //生失效日期
                        $Controller.bes.ad.staticshoppingcar.effectivedate(valj);
                        val.arrowdownflag = true;
                        valj.displaysuboffer = true;
                    } else if (valj.opCode == '2') {
                        valj.opClass = 'icon_transform';
                        val.arrowdownflag = true;
                        valj.displaysuboffer = true;
                    } else if (valj.opCode == '3') {
                        valj.opClass = 'icon_unsubscribe';
                        //生失效日期
                        $Controller.bes.ad.staticshoppingcar.effectivedate(valj);
                        val.arrowdownflag = true;
                        valj.displaysuboffer = true;
                    }
                });
            }
          if(window._ysp_top.shoppingcart.projectVersion=="NINGXIA"){
		  if(window._ysp_top.shoppingcart.ShoppingFlag=="Y"){
				 for (var m = 0; m < window._ysp_top.shoppingcart.$Pagea.promInfoList.length; m++) {
					if ($Controller.bes.ad.staticshoppingcar.isSameOffer(window._ysp_top.shoppingcart.$Pagea.promInfoList[m], val)) {
						if(val.pages){
							val.pages=null;
						}
					}
				}
		  }
			if(!val.itemTracId){
				val.isChecked=false;
				val.isModify=false;
				newofferinfo=JSON.stringify(val);
				isNew=true;
				currentoffer=i;
			}else if(val.isModify){
				val.isModify=false;
				modifyofferinfo=JSON.stringify(val);
				modifyitem=val.itemTracId;
				currentoffer=i;
				isModified=true;
			}
		  }
        });
        _ysp_top.updateShoppingcartNumber($Gadget.data.shoppingcar.length);

		if(window._ysp_top.shoppingcart.projectVersion=="NINGXIA"){
			$Gadget.projectVersion=window._ysp_top.shoppingcart.projectVersion;
		if(isNew && !isModified && window._ysp_top.shoppingcart.ShoppingFlag=="Y"){
		var input = {
				serviceNumber : window._ysp_top.serviceNumber,
				beId : $Page.contextForBuriedPoints.beId,
				itemData : newofferinfo,
				createOper : $Page.contextForBuriedPoints.createOperId
		};

		 $Fire({
            service : "/ucec/v1/ctz/insertShoppingcarList",
            params : {
				'req': input,
            },
            target : "$Gadget.itemTracId",
            onafter : function() {
                debugger;
                if($Gadget.itemTracId){
                    $Gadget.data.shoppingcar[currentoffer].itemTracId=$Gadget.itemTracId;
                 }
				if(window._ysp_top.shoppingcart.projectVersion=="NINGXIA" && window._ysp_top.shoppingcart.ShoppingFlag=="Y" && window._ysp_top.shoppingcart.$Pagea != {})
				{
					debugger;
					if(!window._ysp_top.shoppingcart.$Pagea.pageTracId && window._ysp_top.shoppingcart.$Pagea.promInfoList.length != 0){
						//组装对象实例化如表
					var newPageaObject={};
					if(!window._ysp_top.shoppingcart.$Pagea.salesFlag){
						newPageaObject.salesFlag=window._ysp_top.shoppingcart.$Pagea.salesFlag;
					}
					newPageaObject.promInfoList = $.extend(true, [], window._ysp_top.shoppingcart.$Pagea.promInfoList);
					newPageaObject.params=window._ysp_top.shoppingcart.$Pagea.params;
					if(!window._ysp_top.shoppingcart.$Pagea.orderInvoice){
						//$.extend(newPageaObject.orderInvoice, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
						 newPageaObject.orderInvoice = $.extend(true, {}, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
					}
					newPageaObject.productFlag = window._ysp_top.shoppingcart.$Pagea.productFlag;

					var newPagea={};
					newPagea = JSON.stringify(newPageaObject);
					var input = {
							serviceNumber : window._ysp_top.serviceNumber,
							beId : $Page.contextForBuriedPoints.beId,
							itemData : newPagea,
							createOper : $Page.contextForBuriedPoints.createOperId
						};
						$Fire({
							service : "/ucec/v1/ctz/insertShoppingcarList",
							params : {
								'req': input,
							},
							target : "$Gadget.pageTracId",
							onafter : function() {
								debugger;
								if($Gadget.pageTracId){
									window._ysp_top.shoppingcart.$Pagea.pageTracId=$Gadget.pageTracId;
								 }
							}
						}, $Gadget);
					}else if(window._ysp_top.shoppingcart.$Pagea.pageTracId && window._ysp_top.shoppingcart.$Pagea.promInfoList.length != 0){
						var newPageaObject={};
						if(!window._ysp_top.shoppingcart.$Pagea.salesFlag){
							newPageaObject.salesFlag=window._ysp_top.shoppingcart.$Pagea.salesFlag;
						}
						newPageaObject.promInfoList = $.extend(true, [], window._ysp_top.shoppingcart.$Pagea.promInfoList);
						newPageaObject.params=window._ysp_top.shoppingcart.$Pagea.params;
						if(!window._ysp_top.shoppingcart.$Pagea.orderInvoice){
							//$.extend(newPageaObject.orderInvoice, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
							 newPageaObject.orderInvoice = $.extend(true, {}, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
						}
						newPageaObject.productFlag = window._ysp_top.shoppingcart.$Pagea.productFlag;

						var newPagea={};
						newPagea = JSON.stringify(newPageaObject);
						var input = {
							itemId:window._ysp_top.shoppingcart.$Pagea.pageTracId,
							serviceNumber : window._ysp_top.serviceNumber,
							beId : $Page.contextForBuriedPoints.beId,
							itemData : newPagea,
							createOper : $Page.contextForBuriedPoints.createOperId
						};

						$Fire({
						service : "/ucec/v1/ctz/updateShoppingcar",
						params : {
							'req': input,
						},
						onafter : function() {
						debugger;

						}
					 }, $Gadget);
					}
				}
            }
         }, $Gadget);
		}
		else if(!isNew && isModified && window._ysp_top.shoppingcart.ShoppingFlag=="Y"){
			var input = {
				itemId:modifyitem,
				serviceNumber : window._ysp_top.serviceNumber,
				beId : $Page.contextForBuriedPoints.beId,
				itemData : modifyofferinfo,
				createOper : $Page.contextForBuriedPoints.createOperId
			};

			 $Fire({
            service : "/ucec/v1/ctz/updateShoppingcar",
            params : {
				'req': input,
            },
            onafter : function() {
            debugger;
			if(window._ysp_top.shoppingcart.projectVersion=="NINGXIA" && window._ysp_top.shoppingcart.ShoppingFlag=="Y" && window._ysp_top.shoppingcart.$Pagea != {})
			{
				debugger;
				if(window._ysp_top.shoppingcart.$Pagea.pageTracId && window._ysp_top.shoppingcart.$Pagea.promInfoList.length != 0){
						var newPageaObject={};
						if(!window._ysp_top.shoppingcart.$Pagea.salesFlag){
							newPageaObject.salesFlag=window._ysp_top.shoppingcart.$Pagea.salesFlag;
						}
						newPageaObject.promInfoList = $.extend(true, [], window._ysp_top.shoppingcart.$Pagea.promInfoList);
						newPageaObject.params=window._ysp_top.shoppingcart.$Pagea.params;
						if(!window._ysp_top.shoppingcart.$Pagea.orderInvoice){
							//$.extend(newPageaObject.orderInvoice, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
							 newPageaObject.orderInvoice = $.extend(true, {}, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
						}
						newPageaObject.productFlag = window._ysp_top.shoppingcart.$Pagea.productFlag;

						var newPagea={};
						newPagea = JSON.stringify(newPageaObject);
						var input = {
							itemId:window._ysp_top.shoppingcart.$Pagea.pageTracId,
							serviceNumber : window._ysp_top.serviceNumber,
							beId : $Page.contextForBuriedPoints.beId,
							itemData : newPagea,
							createOper : $Page.contextForBuriedPoints.createOperId
						};

						$Fire({
						service : "/ucec/v1/ctz/updateShoppingcar",
						params : {
							'req': input,
						},
						onafter : function() {
						debugger;

						}
					 }, $Gadget);
					}
			}
            }
         }, $Gadget);

		}
		}

		// add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 start
		// 源商品A与目标商品B有BO关系（表示订购A时，自动把B带出来）的，如果源商品退订，目标商品也要退订
		if (window._ysp_top.shoppingcart.projectVersion=="NINGXIA") {
			var onMessage = function(e) {
	            debugger;
	            e = e || window.event;
	            var data = JSON.parse(e.data);

	            var operation = data.operation;
	            if (undefined == operation) {
	                return;
	            }

	            if ("delDestEntryFollowOriEntity" == operation && data.scene) {
	            	$.each(data.scene||[],function(i,val){
	            		$Controller.bes.ad.staticshoppingcar.delDestEntryFollowOriEntity($Gadget, $UI, val);
		            });
	            }
	        };

			if (window.addEventListener) {
				window.addEventListener ("message", onMessage, false);
		    }
		    else {
		        if (window.attachEvent) {
		            window.attachEvent("onmessage", onMessage);
		        }
		    }
		}
		// add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 end

        var orderscrollbar;
        setTimeout(function() {
            debugger;
            orderscrollbar = new ucd.DefaultScroll({
                scrollObj: $("#orderScrollbar")
            });
            orderscrollbar.refreshScroll(); //刷新滚动条
        }, 50);

        $(document).bind('click', function(e) {
            if ($(e.target).attr("class") != 'form_control order_time' && $(e.target).parent().attr("class") != 'form_control order_time') {
                $(".orderSelect").hide();
            }
        });
        debugger;

        if ($Gadget.beParams == 'Ningxia'){
        	$Controller.bes.ad.staticshoppingcar.ordervalidatetest($Gadget);
		}
    },
    //批量删除
    batchdelete:function($Gadget){

        debugger;
		/*$.each(window._ysp_top.shoppingcart.carofferingList || [],function(i,valj){
			if($Gadget.hdhOfferList.indexOf(window._ysp_top.shoppingcart.carofferingList[i].offeringId) != -1 && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != "" && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != null){
			if($Gadget.hdhOfferList.indexOf(window._ysp_top.shoppingcart.carofferingList[i].offeringId) != -1 && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != "" && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != null){
				window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber--;
			}
        });*/
        if(window._ysp_top.shoppingcart.ShoppingFlag=="Y"){
        	if ($Gadget.beParams == 'Ningxia'){
        		window._ysp_top.mbanddevinfoForUnBak = null;
    			window._ysp_top.mbanddevinfoForUn = null;
        	}
            var delshoppingcarinfo=[];
			var delshoppingcarpagea=[];
            $.each($Gadget.data.shoppingcar||[],function(i,vali){
               if(vali.isChecked){
                debugger;
                var delshoppingcar={};
                delshoppingcar.beId=$Page.contextForBuriedPoints.beId;
                delshoppingcar.itemId=vali.itemTracId;
                delshoppingcarinfo.push(delshoppingcar);
				delshoppingcarpagea.push(vali);
               }
            });
            $Fire({
                service : "/ucec/ctz/delShoppingcar",
                params : {
                    'request':delshoppingcarinfo ,
                },
                target : "flag",
                onafter : function(flag) {
                    debugger;
                    if(flag){
						//不为空设置空数组
						window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
						window._ysp_top.shoppingcart.$Pagea.promInfoList = window._ysp_top.shoppingcart.$Pagea.promInfoList || [];
						window._ysp_top.shoppingcart.newTraceidList = [];
						//删除营销存在数据(含多个)
						for(var i=0;i<delshoppingcarpagea.length;i++){
							for (var m = 0; m < window._ysp_top.shoppingcart.$Pagea.promInfoList.length; m++) {
								if ($Controller.bes.ad.staticshoppingcar.isSameOffer(window._ysp_top.shoppingcart.$Pagea.promInfoList[m], delshoppingcarpagea[i])) {
									window._ysp_top.shoppingcart.$Pagea.promInfoList.splice(m, 1);
									//break;
								}
							}
						}

						if(window._ysp_top.shoppingcart.$Pagea.promInfoList.length ==0 && window._ysp_top.shoppingcart.$Pagea.pageTracId != null){
							var delshoppingcarpage={};
							delshoppingcarpage.beId=$Page.contextForBuriedPoints.beId;
							delshoppingcarpage.itemId=window._ysp_top.shoppingcart.$Pagea.pageTracId;
							var delshoppingcarinfo1=[];
							delshoppingcarinfo1.push(delshoppingcarpage);

						$Fire({
							service : "/ucec/ctz/delShoppingcar",
							params : {
								'request':delshoppingcarinfo1 ,
							},
							target : "flags",
							onafter : function(flags) {
								debugger;
								if(flags){
									window._ysp_top.shoppingcart.$Pagea.pageTracId=null;
								}
							}
						 }, $Gadget);
						}else if(window._ysp_top.shoppingcart.$Pagea.pageTracId != null && window._ysp_top.shoppingcart.$Pagea.promInfoList.length != 0){
							var newPageaObject={};
							if(!window._ysp_top.shoppingcart.$Pagea.salesFlag){
								newPageaObject.salesFlag=window._ysp_top.shoppingcart.$Pagea.salesFlag;
							}
							newPageaObject.promInfoList = $.extend(true, [], window._ysp_top.shoppingcart.$Pagea.promInfoList);
							newPageaObject.params=window._ysp_top.shoppingcart.$Pagea.params;
							if(!window._ysp_top.shoppingcart.$Pagea.orderInvoice){
								//$.extend(newPageaObject.orderInvoice, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
								 newPageaObject.orderInvoice = $.extend(true, {}, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
							}
							newPageaObject.productFlag = window._ysp_top.shoppingcart.$Pagea.productFlag;
							var newPagea={};
							newPagea = JSON.stringify(newPageaObject);
							var input = {
								itemId:window._ysp_top.shoppingcart.$Pagea.pageTracId,
								serviceNumber : window._ysp_top.serviceNumber,
								beId : $Page.contextForBuriedPoints.beId,
								itemData : newPagea,
								createOper : $Page.contextForBuriedPoints.createOperId
							};

							$Fire({
							service : "/ucec/v1/ctz/updateShoppingcar",
							params : {
								'req': input,
							},
							onafter : function() {
							debugger;

							}
						 }, $Gadget);
						}

		    			for (var i=0;i<delshoppingcarinfo.length;i++)
		    			{
		    				for (var j=0;j<$Gadget.data.shoppingcar.length;j++)
		    				{
		    					if (delshoppingcarinfo[i].itemId == $Gadget.data.shoppingcar[j].itemTracId)
		    					{
		    						$Gadget.data.shoppingcar.splice(j,1);
		    					}
		    				}
		    			}
		    			_ysp_top.updateShoppingcartNumber($Gadget.data.shoppingcar.length);

		    			//删除完成的标志
		    			if ($Gadget.beParams == 'Ningxia'){
		    				$Gadget.$Emit('$bes.isDeleteDone');
		    			}
                    }
                }
             }, $Gadget);
        }else if(window._ysp_top.shoppingcart.ShoppingFlag=="N"){
            debugger;
            var delshoppingcarinfo=[];
			var delshoppingcarpagea=[];
            $.each($Gadget.data.shoppingcar||[],function(i,vali){
               if(vali.isChecked){
                debugger;
                var delshoppingcar={};
                delshoppingcar.offeringId=vali.offeringId;
                delshoppingcarinfo.push(delshoppingcar);
				delshoppingcarpagea.push(vali);
               }
            });
            for (var i=0;i<delshoppingcarinfo.length;i++)
            {
                for (var j=0;j<$Gadget.data.shoppingcar.length;j++)
                {
                    if (delshoppingcarinfo[i].offeringId == $Gadget.data.shoppingcar[j].offeringId)
                    {
                        $Gadget.data.shoppingcar.splice(j,1);
                    }
                }
            }
    		if ($Gadget.beParams == 'Ningxia'){
            	//判断列表中除了要删除的商品外，还有没有字典表中的商品
            	var isExit = false;
            	$.each($Gadget.data.shoppingcar||[], function(i, val) {
            		$.each(window._ysp_top.mbandDeviceOffer||[], function(j, valj) {
            			if(valj.itemCode == val.offeringId){
            				isExit=true;
            			}
            		});
            	});
            	//如果不存在，删除window.top中的回收列表数据
            	if(!isExit){
            		window._ysp_top.mbanddevinfoForUnBak = null;
            		window._ysp_top.mbanddevinfoForUn = null;
            	}
            }

			window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
			window._ysp_top.shoppingcart.$Pagea.promInfoList = window._ysp_top.shoppingcart.$Pagea.promInfoList || [];
			window._ysp_top.shoppingcart.newTraceidList = [];
						//删除营销存在数据(含多个)
			for(var i=0;i<delshoppingcarpagea.length;i++){
					for (var m = 0; m < window._ysp_top.shoppingcart.$Pagea.promInfoList.length; m++) {
						if ($Controller.bes.ad.staticshoppingcar.isSameOffer(window._ysp_top.shoppingcart.$Pagea.promInfoList[m], delshoppingcarpagea[i])) {
							window._ysp_top.shoppingcart.$Pagea.promInfoList.splice(m, 1);
									//break;
							}
					}
			}
            _ysp_top.updateShoppingcartNumber($Gadget.data.shoppingcar.length);

            //删除完成的标志
            if ($Gadget.beParams == 'Ningxia'){
            	$Gadget.$Emit('$bes.isDeleteDone');
            }


        }
        $Gadget.allChecked=false;
    },
    //清空购物车
    emptyshoppingcar:function($Gadget,$Fire){
        debugger;
        if ($Gadget.beParams == 'Ningxia'){
    		window._ysp_top.mbanddevinfoForUnBak = null;
			window._ysp_top.mbanddevinfoForUn = null;
    	}
		/*$.each(window._ysp_top.shoppingcart.carofferingList || [],function(i,valj){
			if($Gadget.hdhOfferList.indexOf(window._ysp_top.shoppingcart.carofferingList[i].offeringId) !=1 && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != "" && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != null){
				window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber--;
			}
        });*/
		window._ysp_top.shoppingcart.carofferingList[0].offeringId
        if(window._ysp_top.shoppingcart.ShoppingFlag=="Y"){
            var delshoppingcarinfo=[]
            $.each($Gadget.data.shoppingcar||[],function(i,vali){
                 debugger;
                 var delshoppingcar={};
                 delshoppingcar.beId=$Page.contextForBuriedPoints.beId;
                 delshoppingcar.itemId=vali.itemTracId;
                 delshoppingcarinfo.push(delshoppingcar);
             });
            $Fire({
                 service : "/ucec/ctz/delShoppingcar",
                 params : {
                     'request':delshoppingcarinfo ,
                 },
                 target : "flag",
                 onafter : function(flag) {
                     debugger;
                     if($Gadget.data.shoppingcar.length>0&&flag){

						window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
						window._ysp_top.shoppingcart.$Pagea.promInfoList = window._ysp_top.shoppingcart.$Pagea.promInfoList || [];
						window._ysp_top.shoppingcart.newTraceidList = [];
						//删除营销存在数据(含多个)
						for(var i=0;i<$Gadget.data.shoppingcar.length;i++){
								for (var m = 0; m < window._ysp_top.shoppingcart.$Pagea.promInfoList.length; m++) {
									if ($Controller.bes.ad.staticshoppingcar.isSameOffer(window._ysp_top.shoppingcart.$Pagea.promInfoList[m], $Gadget.data.shoppingcar[i])) {
										window._ysp_top.shoppingcart.$Pagea.promInfoList.splice(m, 1);
												//break;
										}
								}
						}
						//如果有则删除
						if(window._ysp_top.shoppingcart.$Pagea.pageTracId){
							var delshoppingcarpage={};
							delshoppingcarpage.beId=$Page.contextForBuriedPoints.beId;
							delshoppingcarpage.itemId=window._ysp_top.shoppingcart.$Pagea.pageTracId;
							var delshoppingcarinfo1=[];
							delshoppingcarinfo1.push(delshoppingcarpage);

							$Fire({
							service : "/ucec/ctz/delShoppingcar",
							params : {
								'request':delshoppingcarinfo1 ,
							},
							target : "flags",
							onafter : function(flags) {
								debugger;
								if(flags){
									window._ysp_top.shoppingcart.$Pagea.pageTracId=null;
								}
							}
						 }, $Gadget);
						}

                         $Gadget.data.shoppingcar.splice(0, $Gadget.data.shoppingcar.length);
                         //删除完成的标志
                         if ($Gadget.beParams == 'Ningxia'){
                        	 $Gadget.$Emit('$bes.isDeleteDone');
                         }
                     }
                 }
              }, $Gadget);
        }else if(window._ysp_top.shoppingcart.ShoppingFlag=="N"){
            if($Gadget.data.shoppingcar.length>0){

						window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
						window._ysp_top.shoppingcart.$Pagea.promInfoList = window._ysp_top.shoppingcart.$Pagea.promInfoList || [];
						window._ysp_top.shoppingcart.newTraceidList = [];
						//删除营销存在数据(含多个)
						for(var i=0;i<$Gadget.data.shoppingcar.length;i++){
								for (var m = 0; m < window._ysp_top.shoppingcart.$Pagea.promInfoList.length; m++) {
									if ($Controller.bes.ad.staticshoppingcar.isSameOffer(window._ysp_top.shoppingcart.$Pagea.promInfoList[m], $Gadget.data.shoppingcar[i])) {
										window._ysp_top.shoppingcart.$Pagea.promInfoList.splice(m, 1);
												//break;
										}
								}
						}

                         $Gadget.data.shoppingcar.splice(0, $Gadget.data.shoppingcar.length);

                     }
            //删除完成的标志
            if ($Gadget.beParams == 'Ningxia'){
            	$Gadget.$Emit('$bes.isDeleteDone');
            }
        }
        _ysp_top.updateShoppingcartNumber('0');
    },
    //全选
    allselected:function($Gadget){
        debugger;
        if($Gadget.data.shoppingcar.length>0){
        $Gadget.allChecked=!$Gadget.allChecked;
        $.each($Gadget.data.shoppingcar||[],function(i,vali){
            if($Gadget.allChecked){
                vali.isChecked=true;
            }else{
                vali.isChecked=false;
            }

        });
        }
    },
    effectivedate: function(offeringinfo) {
        if ((!offeringinfo.effectiveWay || ((offeringinfo.effectiveWay || {}).effectiveTypes || []).length == 0) && (!offeringinfo.expirationWay || ((offeringinfo.expirationWay || {}).expirationTypes || []).length == 0)) {
            return;
        }
        var value = "";
        var key = "";
        if (offeringinfo.opCode == '1' || offeringinfo.opCode == '2') {

            value = $Controller.bes.ad.staticshoppingcar.getValueByKey(offeringinfo.effectiveWay.selectedKey, offeringinfo.effectiveWay.effectiveTypes);
            if (((offeringinfo.effectiveWay || {}).effectiveTypes || []).length == 1) {
                key = offeringinfo.effectiveWay.effectiveTypes[0].key;
            } else {
                key = offeringinfo.effectiveWay.selectedKey;
            }
        } else if (offeringinfo.opCode == '3') {
            value = $Controller.bes.ad.staticshoppingcar.getValueByKey(offeringinfo.expirationWay.selectedKey, offeringinfo.expirationWay.expirationTypes);
            if (((offeringinfo.expirationWay || {}).expirationTypes || []).length == 1) {
                key = offeringinfo.expirationWay.expirationTypes[0].key;
            } else {
                key = offeringinfo.expirationWay.selectedKey;
            }
            // 合同信息罚金计算使用
            if (offeringinfo.contractFlag == '1') {
                offeringinfo.expMode = key;
            }
        }



        if (offeringinfo.opCode == '1' || offeringinfo.opCode == '2') {
            if (key == 'C') {
                offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.effectiveWay.effectiveDate)).Format("yyyy-MM-dd");
            } else if (key == 'S') {
                offeringinfo.displaydate = value + ' : ' + offeringinfo.effectiveWay.durationValue + offeringinfo.effectiveWay.durationUnit.value;
            } else if (key == 'F') {
                offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.effectiveWay.fixStartDate.replace(/-/g, "/"))).Format("yyyy-MM-dd");
            } else if(key == 'BEM'){
		    offeringinfo.displaydate = "";
		   } else {
                offeringinfo.displaydate = value;
            }
        } else if (offeringinfo.opCode == '3') {
            if (key == 'C') {
                offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.expirationWay.expirationDate)).Format("yyyy-MM-dd");
            } else if (key == 'S') {
                offeringinfo.displaydate = value + ' : ' + offeringinfo.expirationWay.durationValue + offeringinfo.expirationWay.durationUnit.value;
            } else if (key == 'F') {
                offeringinfo.displaydate = value + ' : ' + (new Date(offeringinfo.expirationWay.fixEndDate)).Format("yyyy-MM-dd");
            } else {
                offeringinfo.displaydate = value;
            }
        }
    },

/*    isNotifyBy139Email:function($Gadget,$Page){
        $Gadget.data.emailchecked = !$Gadget.data.emailchecked;
        if(!$Gadget.data.emailchecked){
            $Page.isNotifyBy139Email = "0";
        }else{
            $Page.isNotifyBy139Email = "1";
        }
    },*/

    //查询系统参数
    //60107061880414  用于判断局点，如NINGXIA、JIANGSU、POLAND
   querySystemParamsVersion : function($Fire, $Gadget){
        debugger;
        $Fire({
            service : "ucec/v1/common/qrysystemparamlistbykey",
            params : {
            keylist : ['60107061880414','HDHOFFERLIST']
            },
            target : "$Gadget.systemParamsList",
            onafter : function() {
                debugger;
                if($Gadget.systemParamsList){
                    $Gadget.projectVersion = $Gadget.systemParamsList[0];
					if($Gadget.systemParamsList[1]){
						$Gadget.hdhOfferList = $Gadget.systemParamsList[1].split(";");
					}
                 }
            }
         }, $Gadget);
     },

    getValueByKey: function(key, Types) {
        if ((Types || []).length == 1) {
            return Types[0].value;
        }
        var value = "";
        $.each(Types || [], function(i, val) {
            if (val.key == key) {
                value = val.value;
                return false;
            }
        });
        return value;
    },

    /**
	 * US-20180521185335-2031091190
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  源商品A与目标商品B有BO关系（表示订购A时，自动把B带出来）的，如果源商品退订，目标商品也要退订
	 */
    delDestEntryFollowOriEntity : function($Gadget, $UI, destEntryId) {
    	debugger;
    	var $UI = $Gadget.$Get("$UI");
    	var $index = null;
    	$.each($Gadget.data.shoppingcar||[], function(i, val) {
			if(val.offeringId == destEntryId){
				$index = i;
			}
    	});
    	if ($index != null) {
    		$Controller.bes.ad.staticshoppingcar.cancel($Gadget,$UI,$index);
    	}
    },

	//单个
    cancel: function($Gadget, $UI, index) {

        debugger;
		/*if($Gadget.hdhOfferList.indexOf($Gadget.data.shoppingcar[index].offeringId) != -1 && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != "" && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != null){
			window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber--;
		}*/
        var cancelOffer = $Gadget.data.shoppingcar[index];
        if ($Gadget.beParams == 'Ningxia'){
        	//判断列表中除了要删除的商品外，还有没有字典表中的商品
        	var isExit = false;
        	$.each($Gadget.data.shoppingcar||[], function(i, val) {
        		$.each(window._ysp_top.mbandDeviceOffer||[], function(j, valj) {
        			if(valj.itemCode == val.offeringId && index != i){
        				isExit=true;
        			}
        		});
        	});
        	//如果不存在，删除window.top中的回收列表数据
        	$.each(window._ysp_top.mbandDeviceOffer||[], function(i, val) {
        		if(!isExit && val.itemCode == cancelOffer.offeringId){
        			window._ysp_top.mbanddevinfoForUnBak = null;
        			window._ysp_top.mbanddevinfoForUn = null;
        		}
        	});
        }


        if (cancelOffer.levelBaseInfo && cancelOffer.levelBaseInfo.hasFreeze) {
            //如果删除的这条数据有冻结金，则删除页面上的冻结支付方式
            if (window._ysp_top.$Pagea && window._ysp_top.$Pagea.freezePay) {
                window._ysp_top.$Pagea.freezePay = null;
            }
        }

    	if($Page.isrewardType =='PTTerminal' &&
    			$Page.isprodtype == 'RwdGift_Good'){
    		   $Page.isrewardType = '';
	           $Page.isprodtype = '';
	           $Page.stackPackageList = null;
		}

        //不为空设置空数组
        window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
        window._ysp_top.shoppingcart.$Pagea.promInfoList = window._ysp_top.shoppingcart.$Pagea.promInfoList || [];
        window._ysp_top.shoppingcart.newTraceidList = [];
        //删除营销存在数据
        for (var m = 0; m < window._ysp_top.shoppingcart.$Pagea.promInfoList.length; m++) {
            if ($Controller.bes.ad.staticshoppingcar.isSameOffer(window._ysp_top.shoppingcart.$Pagea.promInfoList[m], cancelOffer)) {
                window._ysp_top.shoppingcart.$Pagea.promInfoList.splice(m, 1);
                break;
            }
        }
        //删除该条数据的traceId hwx234390
        window._ysp_top.shoppingcart.cartraceidList = window._ysp_top.shoppingcart.cartraceidList || [];
        if (window._ysp_top.shoppingcart.cartraceidList.length > 0) {
            var cancelTraceId = window._ysp_top.shoppingcart.cartraceidList[index];
            var tempTraceIdList = $.extend(true, [], window._ysp_top.shoppingcart.cartraceidList);
            for (var i = 0; i < tempTraceIdList.length; i++) {
                if (index == i && cancelTraceId == tempTraceIdList[i]) {
                    continue;
                }
                window._ysp_top.shoppingcart.newTraceidList.push(tempTraceIdList[i])
            }
            window._ysp_top.shoppingcart.cartraceidList = window._ysp_top.shoppingcart.newTraceidList || [];
        }
        //修改IE下偶先的splice报错问题，规避
        try {
            $Gadget.data.shoppingcar.splice(index, 1);
        } catch (e) {
            if ($Gadget.data.shoppingcar.length == 1) {
                $Gadget.data.shoppingcar.pop();
            } else {
                //解决$Gadget.data.shoppingcar值是非数组对象的问题
                var temp = $.extend(true, [], $Gadget.data.shoppingcar);
                temp.splice(index, 1);
                $Gadget.data.shoppingcar.length = 0;
                $.each(temp || [], function(i, val) {
                    $Gadget.data.shoppingcar.push(val);
                });
            }

        }
        if(window._ysp_top.shoppingcart.ShoppingFlag=="Y" && window._ysp_top.shoppingcart.projectVersion=="NINGXIA"){
            debugger;

                var delshoppingcarinfo=[];
                var delshoppingcar={};
                delshoppingcar.beId=$Page.contextForBuriedPoints.beId;
                delshoppingcar.itemId=cancelOffer.itemTracId;
                delshoppingcarinfo.push(delshoppingcar);
            $Fire({
                service : "/ucec/ctz/delShoppingcar",
                params : {
                    'request':delshoppingcarinfo ,
                },
                target : "flag",
                onafter : function(flag) {
                    debugger;
                    if(flag){
                        //      $Gadget.data.shoppingcar.splice(index, 1);
                        $.each($Gadget.data.shoppingcar, function(i, val) {
                            if (val.postPointOfferingId == cancelOffer.offeringId) {
                                val.postPointOfferingId = null;
                                val.postPointOfferingInstId = null;
                            }
                        });

                        var delOfferingId = null;
                        if (cancelOffer.relatedTransOldOffering) {
                            delOfferingId = cancelOffer.relatedTransOldOffering.offeringId;
                        }
                        $.each($Gadget.data.shoppingcar, function(i, val) {
                            if (delOfferingId == val.offeringId) {
                                $Gadget.data.shoppingcar.splice(i, 1);
                                return false;
                            }
                        });
						_ysp_top.updateShoppingcartNumber($Gadget.data.shoppingcar.length);

						if(window._ysp_top.shoppingcart.$Pagea.promInfoList.length ==0 && window._ysp_top.shoppingcart.$Pagea.pageTracId != null)
						{
							var delshoppingcarpage={};
							delshoppingcarpage.beId=$Page.contextForBuriedPoints.beId;
							delshoppingcarpage.itemId=window._ysp_top.shoppingcart.$Pagea.pageTracId;
							var delshoppingcarinfo=[];
							delshoppingcarinfo.push(delshoppingcarpage);

							$Fire({
								service : "/ucec/ctz/delShoppingcar",
								params : {
									'request':delshoppingcarinfo ,
								},
								target : "flags",
								onafter : function(flags) {
									debugger;
									if(flags){
									window._ysp_top.shoppingcart.$Pagea.pageTracId=null;
									}
								}
							 }, $Gadget);
						}else if(window._ysp_top.shoppingcart.$Pagea.pageTracId != null && window._ysp_top.shoppingcart.$Pagea.promInfoList.length != 0)
						{
								var newPageaObject={};
								if(!window._ysp_top.shoppingcart.$Pagea.salesFlag){
									newPageaObject.salesFlag=window._ysp_top.shoppingcart.$Pagea.salesFlag;
								}
								newPageaObject.promInfoList = $.extend(true, [], window._ysp_top.shoppingcart.$Pagea.promInfoList);
								newPageaObject.params=window._ysp_top.shoppingcart.$Pagea.params;
								if(!window._ysp_top.shoppingcart.$Pagea.orderInvoice){
									//$.extend(newPageaObject.orderInvoice, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
									 newPageaObject.orderInvoice = $.extend(true, {}, window._ysp_top.shoppingcart.$Pagea.orderInvoice);
								}
								newPageaObject.productFlag = window._ysp_top.shoppingcart.$Pagea.productFlag;

								var newPagea={};
								newPagea = JSON.stringify(newPageaObject);
								var input = {
									itemId:window._ysp_top.shoppingcart.$Pagea.pageTracId,
									serviceNumber : window._ysp_top.serviceNumber,
									beId : $Page.contextForBuriedPoints.beId,
									itemData : newPagea,
									createOper : $Page.contextForBuriedPoints.createOperId
								};

								$Fire({
								service : "/ucec/v1/ctz/updateShoppingcar",
								params : {
									'req': input,
								},
								onafter : function() {
								debugger;

								}
							}, $Gadget);
						}
                    }
                }
             }, $Gadget);
        }else if(window._ysp_top.shoppingcart.ShoppingFlag=="N"){

            //      $Gadget.data.shoppingcar.splice(index, 1);
                        $.each($Gadget.data.shoppingcar, function(i, val) {
                            if (val.postPointOfferingId == cancelOffer.offeringId) {
                                val.postPointOfferingId = null;
                                val.postPointOfferingInstId = null;
                            }
                        });

                        var delOfferingId = null;
                        if (cancelOffer.relatedTransOldOffering) {
                            delOfferingId = cancelOffer.relatedTransOldOffering.offeringId;
                        }
                        $.each($Gadget.data.shoppingcar, function(i, val) {
                            if (delOfferingId == val.offeringId) {
                                $Gadget.data.shoppingcar.splice(i, 1);
                                return false;
                            }
                        });
						_ysp_top.updateShoppingcartNumber($Gadget.data.shoppingcar.length);
        }
        $.extend($Gadget.$Attrs.model, $Gadget.data.shoppingcar);
        this.buryPointQuery($Gadget, cancelOffer);
    },

    /*
    ContextUtils.getChannelId()
    *埋点前准备
    */
    buryPointQuery: function($Gadget, cancelOffer) {
        debugger;

        // add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 start
        // 源商品删除，存在BO关系的目标商品也要删除
        var $UI = $Gadget.$Get("$UI");
        if ($Gadget.projectVersion == "NINGXIA") {
        	$.each($Gadget.data.shoppingcar||[], function(i, val) {
    			if(val.oriEntityId == cancelOffer.offeringId){
    				$Controller.bes.ad.staticshoppingcar.cancel($Gadget,$UI,i);
    			}
        	});
        }
        // add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 end

        if (!window._ysp_top.shoppingcarBuryPoint) {
        	//删除完成的标志
        	if ($Gadget.beParams == 'Ningxia'){
        		$Gadget.$Emit('$bes.isDeleteDone');
        	}
            return;
        }
        var ecommerceItems = [];
        var deleteoffering;
        var totalamount = 0;
        for (var indexoffer = 0; indexoffer < window._ysp_top.shoppingcarBuryPoint.length; indexoffer++) {
            if (window._ysp_top.shoppingcarBuryPoint[indexoffer].offeringCode == cancelOffer.offeringCode) {
                deleteoffering = indexoffer;
                continue;
            }
            totalamount = totalamount + window._ysp_top.shoppingcarBuryPoint[indexoffer].priceValue;
            var ecommerceItem = { productSKU: window._ysp_top.shoppingcarBuryPoint[indexoffer].offeringCode, productName: window._ysp_top.shoppingcarBuryPoint[indexoffer].offeringName, productCategory: window._ysp_top.shoppingcarBuryPoint[indexoffer].classificationId, brand: "", variant: "", price: window._ysp_top.shoppingcarBuryPoint[indexoffer].priceValue, quantity: 1 }
            ecommerceItems.push(ecommerceItem);
        }
        $BuriedPoinStat.removeEcommerceItem(ecommerceItems, totalamount);
        window._ysp_top.shoppingcarBuryPoint.splice(deleteoffering, 1);
        //删除完成的标志
		if ($Gadget.beParams == 'Ningxia'){
			$Gadget.$Emit('$bes.isDeleteDone');
		}
    },



    showDayConvert: function($Gadget, offeringinfo) {
        $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(offeringinfo, offeringinfo.opCode, "dayConvertPop");
        $Controller.bes.ad.staticshoppingcar.orerClose();
    },

    modify: function($Gadget, $UI, offeringinfo, obj) {

        debugger;
		/*if($Gadget.hdhOfferList.indexOf($Gadget.data.shoppingcar[index].offeringId) != -1 && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != "" && window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber != null){
			window._ysp_top.shoppingcart.hdhinfo.campONSeqNumber--;
		}*/
        // MODIFY 2015-09-28 by l00289267 DTS2015092110004 start
        // MODIFY REASON:点击修改的时候，把购物车栏关掉
        $Controller.bes.ad.staticshoppingcar.orerClose();
        // MODIFY 2015-09-28 by l00289267 DTS2015092110004 end

        var $Pagea = window._ysp_top.shoppingcart.$Pagea || {};
        window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};

        //家庭产品begin
        var jtwProduct = $Controller.bes.ad.staticshoppingcar.isFamilyProd(offeringinfo);
        if (jtwProduct) {
            $Pagea.isShowJTW = true;
            $Pagea.jtwProduct = jtwProduct;
            $Pagea.familyOffering = $.extend(true, {}, offeringinfo);
            $Pagea.familyOffering.opCode = '1';
            $Pagea.familyisReady = true;
        }
        $Pagea.productFlag = "MODIFY";
        //家庭产品end
        //旺铺 yubin
        var hotProduct = this.isHotProd($Gadget, $Page,offeringinfo);
        if(hotProduct) {
            //需要放入地址信息的产品类型,组装报文的时候，找到该类型的产品放入地址信息
            $Pagea.needAddressProd = "WPMP";
            $Pagea.offerDetailShowAddress = true;  //显示联系地址详情
            $Pagea.familyisReady = true;

            $Pagea.isShowJTW = true;
            $Pagea.jtwProduct = hotProduct;
            $Pagea.familyOffering = $.extend(true, {}, offeringinfo);
            $Pagea.familyOffering.opCode = '1';
            $Pagea.familyisReady = true;
        }
        else{
            $Pagea.offerDetailShowAddress = false;
        }
         //旺铺 yubin end

        window._ysp_top.shoppingcart.offeringinfo = $.extend(true, {}, offeringinfo);
        window._ysp_top.shoppingcart.realofferinginfo = offeringinfo;
        window._ysp_top.shoppingcart.offeringId = offeringinfo.offeringId;
        if (offeringinfo.opCode == '1') {
            if (offeringinfo.levelBaseInfo || offeringinfo.parentOffering) {

                //营销活动
                debugger;

                //添加批次ID、档次ID、商品订购MODE
                if (offeringinfo.levelBaseInfo) {
                    window._ysp_top.shoppingcart.$Pagea.params = {
                        "offeringId": offeringinfo.offeringId,
                        "levelId": offeringinfo.levelBaseInfo.offeringId,
                        "mode": "ChangeProduct"
                    };
                    offeringinfo.opCode = '1';
                    $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(offeringinfo, offeringinfo.opCode);
                }
            } else {
                $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(offeringinfo, offeringinfo.opCode);

            }
        } else if (offeringinfo.opCode == '2') {
            //变更
            $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(offeringinfo, offeringinfo.opCode);
        } else if (offeringinfo.opCode == '3' || offeringinfo.opCode == 'F') {
            $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(offeringinfo, offeringinfo.opCode);
        }
        $Gadget.questionnaireSubmitSuc = false;
    },
    //yubin add 20160617 是否旺铺产品
    isHotProd:function ($Gadget, $Page, offering)
    {
        debugger;
        var result = false;
        var  retrunProd = null;
        // 如果已选产品是旺铺产品包
        $.each(offering.subOfferings ||[], function(i, val) {
            $.each(val.product||[],function(j,valj){
                    if(valj.prodType=="WPMP"){
                       retrunProd = valj;
                       return false;
                    }
            });
        });
        return retrunProd;
    },
    disableBtn: function(id) {
        $(id).attr('disabled', 'disabled');
    },
    gotocheckoutfromcar: function($Gadget, $UI) {
    	// 退订魔百和IPTV设备回收扩展节点
    	if ($Gadget.projectVersion == "NINGXIA") {
    		var exit = false;
    		$.each(window._ysp_top.shoppingcart.carofferingList || [], function(j, valj) {
    			if(valj.mbanddevinfoForUn
    	        		&& valj.mbanddevinfoForUn.retCode == "0000"
    	        			&& valj.mbanddevinfoForUn.MbandDevAttrInfoList
    	        			&& valj.mbanddevinfoForUn.MbandDevAttrInfoList.length > 0){
    				exit = true;
    			}
    		});
    		if(exit){
    			$UI.msgbox.confirm($UEE.i18n('ad.person.message.information'), "拆机后，需到“宽带终端回收”菜单进行设备回收，否则该用户进入黑名单，限制办理宽带业务，若无法提供设备请到“宽带赔付”菜单进行赔付", function() {
    				$Controller.bes.ad.staticshoppingcar.togotocheckoutfromcar($Gadget, $UI);
    			});
    		}else{
    			$Controller.bes.ad.staticshoppingcar.togotocheckoutfromcar($Gadget, $UI);
    		}
    	}else{
    		$Controller.bes.ad.staticshoppingcar.togotocheckoutfromcar($Gadget, $UI);
    	}
    },
    togotocheckoutfromcar: function($Gadget, $UI) {
        debugger;
        //按钮失效
        if (((window._ysp_top.shoppingcart || {}).carofferingList || []).length == 0) {
            return;
        }

        $Controller.bes.ad.staticshoppingcar.calculatePriceTotal($Gadget);
        $Controller.bes.ad.staticshoppingcar.disableBtn('#gotocheckoutfromcar');
        $Controller.bes.ad.staticshoppingcar.dontTouchDataOfWholePage();
        var isZGNetTv = false;
        var addZGNETTVFeeProd = false;
        // 补充自购互联网电视的赠送offer
        $.each($Gadget.data.shoppingcar || [], function(i, val) {
            if (val.isBundled && val.subOfferings) {
                $.each(val.subOfferings || [], function(j, valj) {
                    if (valj.isZGNetTv) {
                        isZGNetTv = true;
                    }
                });
            } else if (val.isZGNETTVFeeProd) {
                addZGNETTVFeeProd = true;
                return false;
            }
        });
        if (isZGNetTv && !addZGNETTVFeeProd) {
            $Controller.bes.ad.staticshoppingcar.addZGNetTvFreeProd($Gadget, $UI, $Gadget.data.shoppingcar);
        } else {
            $Controller.bes.ad.staticshoppingcar.gocheckout($Gadget, $UI, $Gadget.data.shoppingcar);
        }
    },

    setDeviceRecvOfferingList: function(deviceRecvOfferingList) {
        $.each(deviceRecvOfferingList || [], function(j, valj) {
            if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                valj.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
            } else {
                valj.relaItemId = adutil.getNextNumber();
            }
            valj.opCode = '1';
            $.each(valj.product || [], function(k, valk) {
                if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                    valk.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
                } else {
                    valk.relaItemId = adutil.getNextNumber();
                }
                valk.opCode = '1';
            });
        });
    },
    gerateofferingList: function(offeringList) {
        debugger;

        //$Controller.bes.ad.staticshoppingcar.addDeviceToOfferingList(offeringList);

        $.each(offeringList || [], function(i, val) {

            //转套餐 升降级 时候需要展示一个删除的offering 这个只是为了展示
            //组装保温的时候老offer是放在心offer下面传给后端
            if (val.justForDisplay) {
                offeringList.splice(i, 1);
                return true;
            }
            if (val.relatedTransOldOffering) {
                if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                    val.relatedTransOldOffering.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
                } else {
                    val.relatedTransOldOffering.relaItemId = adutil.getNextNumber();
                }
            }

            $Controller.bes.ad.staticshoppingcar.setDeviceRecvOfferingList(val.deviceRecvOfferingList);
            if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                val.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
            } else {
                val.relaItemId = adutil.getNextNumber();
            }

            if (val.product && val.product.length > 0) {

                $.each(val.product, function(p, pro) {
                    if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                        pro.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
                    } else {

                        pro.relaItemId = adutil.getNextNumber();
                    }
                    pro.opCode = val.opCode;
                });


                //去除掉无用的产品
                if (!val.product[0].prodId) {
                    val.product = null;
                }
            }
            //去除无用的有线业务信息
            if (val.wiredProdAttr && val.wiredProdAttr.newCardInfo && (!val.wiredProdAttr.newCardInfo.skuId)) {
                val.wiredProdAttr.newCardInfo = null;
            }

            if (val.isBundled && val.subOfferings) {

                //去除无效的子offer
                var list = [];
                $.each(val.subOfferings || [], function(j, valj) {
                    if (valj.opCode == '1' || valj.opCode == '2' || valj.opCode == '3') {
                        list.push(valj);
                    }
                });
                val.subOfferings = list;

                //处理子offer生失效方式
                $.each(val.subOfferings || [], function(k, valk) {
                    if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                        valk.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
                    } else {

                        valk.relaItemId = adutil.getNextNumber();
                    }
                    if (valk.product && valk.product.length > 0) {
                        $.each(valk.product, function(p, pro) {
                            if (window._ysp_top.shoppingcart.hasparentshoppingcar) {
                                pro.relaItemId = $Controller.bes.ad.staticshoppingcar.getNextNumber();
                            } else {
                                pro.relaItemId = adutil.getNextNumber();
                            }
                            pro.opCode = valk.opCode;
                        });
                    }

                    //设备领取
                    $Controller.bes.ad.staticshoppingcar.setDeviceRecvOfferingList(valk.deviceRecvOfferingList);

                    //去除无用的有线业务信息
                    if (valk.wiredProdAttr && valk.wiredProdAttr.newCardInfo && (!valk.wiredProdAttr.newCardInfo.skuId)) {
                        valk.wiredProdAttr.newCardInfo = null;
                    }

                    if (valk.effectiveWay) {

                        var effectiveTypes = [];
                        $.each(valk.effectiveWay.effectiveTypes || [], function(l, vall) {
                            if (vall.key == valk.effectiveWay.selectedKey) {
                                vall.selected = true;
                                effectiveTypes.push(vall);
                                return false;
                            }

                        });
                        valk.effectiveWay.effectiveTypes = effectiveTypes;
                    }

                    if (valk.expirationWay) {
                        var expirationTypes = [];
                        $.each(valk.expirationWay.expirationTypes || [], function(l, vall) {
                            if (vall.key == valk.expirationWay.selectedKey) {
                                vall.selected = true;
                                expirationTypes.push(vall);
                                return false;
                            }

                        });
                        valk.expirationWay.expirationTypes = expirationTypes;
                    }
                });
            }

        });
    },
    enableBtn: function(id) {
        $(id).attr('disabled', null);
    },

    //家庭产品过滤子包
    filterOfferings: function(offering) {
        debugger;
        if (offering.isBundled) {
            var subOfferings = offering.subOfferings || [];
            var temp = [];
            // 如果已选产品是家庭网产品包
            for (var i = 0; i < subOfferings.length; i++) {
                if (subOfferings[i].checked) {
                    temp.push(subOfferings[i]);
                }
            }
            offering.subOfferings = temp;
        }
        return offering;
    },

    gocheckout: function($Gadget, $UI, offeringList) {
        debugger;
        var tempList = $.extend(true, [], offeringList);
        var saleCardofferinList = [];
        // 家庭套餐补充必选子offer
        $.each(tempList || [], function(i, val) {
            if (val.isBundled && val.subOfferings) {
                $.each(val.subOfferings || [], function(j, valj) {
					//宁夏US-20170930145437-2031039043 商品包下子商品支持重复订购
					if($Gadget.projectVersion == "NINGXIA"){
						var selectNumList = [];
							if(valj.quantity > 1 && valj.opCode){
								//循环数量解析成多个子商品
								for(var i=1;i<valj.quantity;i++){
									//进行匹配
									var tempProd = $.extend(true, {}, valj);
									tempProd.quantity = 1;
									selectNumList.push(tempProd);
								}
							}
							//循环解析完成后把用来循环的子商品数量改回1
							valj.quantity = 1;
						$.each(selectNumList, function(k, valk){
							val.subOfferings.push(valk);
						});
					}
                    valj.opCode = valj.opCode || valj.opCodeTemp;
                });
            }
            //充值卡售货
            if (val.goodType == "goodSale" && val.offeringlist) {
                $.each(val.offeringlist, function(k, valk) {
                    saleCardofferinList.push(valk);
                });
                val.goodType = "NeedCancel";
            }
        });
        for (var i = 0; i < (tempList || []).length; i++) {
            if (tempList[i].goodType == "NeedCancel") {
                tempList.splice(i, 1);
                i--;
            }
        }
        $.each(saleCardofferinList, function(i, val) {
            tempList.push(val);
        });


        $Controller.bes.ad.staticshoppingcar.gerateofferingList(tempList);
        window._ysp_top.shoppingcart.previousTraceIDs = $Controller.bes.ad.staticshoppingcar.noRepeat(window._ysp_top.shoppingcart.cartraceidList).join("#");
        //家庭产品begin
        var familyOfferList = [];
        for (var i = 0; i < (tempList || []).length; i++) {
            var prod = $Controller.bes.ad.staticshoppingcar.isFamilyProd(tempList[i]);
            if (prod) {
                var offerFamily = $.extend(true, {}, tempList[i]);
                $.each(offerFamily.subOfferings || [], function(i, val) {
                    if (val.opCode == "3") {
                        val.expDate = null;
                    }
                });
                //  var familyOffer = this.filterOfferings(offerFamily);
                familyOfferList.push(offerFamily);
            }
        }
        tempList = $.grep(tempList, function(val, i) {
            return !$Controller.bes.ad.staticshoppingcar.isFamilyProd(val);
        });
        //家庭产品end

        debugger;
        $Fire = $Gadget.$Get('$Fire');
        var $Pagea = window._ysp_top.shoppingcart.$Pagea || {};

        //营销活动begin
        $Pagea.promInfoList = $Pagea.promInfoList || [];

        //保存营销方案列表
        for (var m = 0; m < $Pagea.promInfoList.length; m++) {
            //快选的奖品 且需要融合设置奖品
            if ($Pagea.promInfoList[m].needQuickSet) {
                $UI.msgbox.error($UEE.i18n("ad.checkout.label.information"), $UEE.i18n(
                    "ad.staticshoppingcar.message.neenquickset", [$Pagea.promInfoList[m].offeringName]));
                $Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
                return false;
            }
            for (var n = 0; n < tempList.length; n++) {
                //判断产品ID是否相同
                if ($Controller.bes.ad.staticshoppingcar.isSameOffer($Pagea.promInfoList[m], tempList[n])) {

                    //删除营销方案
                    tempList.splice(n, 1);
                    break;
                }
            }
        }
        //营销活动end
        //增值产品不能有 营销方案 add by h00297092
        var checkIfPromMsg = '';
        for (var z = 0; z < tempList.length; z++) {
            if (tempList[z].levelBaseInfo) {
                checkIfPromMsg = checkIfPromMsg + tempList[z].offeringName + ",";
            }
        }
        if (checkIfPromMsg != '') {
            checkIfPromMsg = checkIfPromMsg.substring(0, checkIfPromMsg.lastIndexOf(","));
            checkIfPromMsg = checkIfPromMsg + $UEE.i18n('ad.staticshoppingcar.message.orderexceptiondeleteafterregistration'); //订单异常，请删除后重新办理
            $Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
            $UI.msgbox.error($UEE.i18n('ad.checkout.label.information'), checkIfPromMsg);
            return false;
        }

        if (!$Controller.bes.ad.staticshoppingcar.checkMnpProm($UI, $Pagea.promInfoList, tempList, familyOfferList)) {
            $Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
            return false;
        }

        $Pagea.agentFlag = $Pagea.agentFlag || "";


        window._ysp_top.checkoutInfo = {
            businessName: $UEE.i18n('ad.staticshoppingcar.title.orderinggoods'), //商品订购
            serviceNumber: window._ysp_top.serviceNumber
        };

        //判断最后加入购物车是否是强制退订业务类型  qwx300045  start
        var length = window._ysp_top.shoppingcart.carofferingList.length - 1;

        var offeringActionType = window._ysp_top.shoppingcart.carofferingList[length].opCode;
        if (offeringActionType == "F") {
            window._ysp_top.checkoutInfo = {
                businessName: "",
                serviceNumber: window._ysp_top.serviceNumber
            };

        } //END

        var quickPickOfferingIdList = [];

        $.each(window._ysp_top.shoppingcart.quickPickOfferingIdList || [], function(i, val) {
            if (quickPickOfferingIdList.length > 0) {
                return false;
            }
            $.each(offeringList || [], function(j, valj) {
                if (val == valj.offeringId) {
                    quickPickOfferingIdList.push(val);
                    return false;
                }
            });
        });

        $.each(window._ysp_top.shoppingcart.quickPickPromOfferingIdList || [], function(i, val) {
            var exist = false;
            $.each(quickPickOfferingIdList, function(j, valj) {
                if (val == valj) {
                    exist = true;
                    return false;
                }
            });

            if (!exist) {
                quickPickOfferingIdList.push(val);
            }
        });


        window._ysp_top.checkoutValidateBody = {
                businessType: "ChangeProduct",
                createOrderReq: {
                    order: {
                        orderPayment: [],
                        extInfo:{
                            extNodeInfo: [{
                                extNodeCode: "ISNOTIFYBY139EMAIL",
                                extXmlString: $Page.isNotifyBy139Email
                            }]
                        }
                    }
                },
                mixturePOJO: {
                    offerings: tempList,
                    familyOfferings: familyOfferList,
                    promInfoList: $Pagea.promInfoList,
                    businessType: $Pagea.agentFlag,
                    quickPickOfferingIdList: quickPickOfferingIdList
                }
            }
			$.each(window._ysp_top.shoppingcart.carofferingList || [], function(i, vali) {
				$.each($Gadget.hdhOfferList || [],function(i,valj){
					if (vali.offeringId == valj){
						$Gadget.isHDHoffer = true;
						return;
					}
				});
			});
	        // 退订魔百和IPTV设备回收扩展节点
        	if ($Gadget.projectVersion == "NINGXIA") {
        		var mbanddevinfoForUn = null;
        		$.each(window._ysp_top.shoppingcart.carofferingList || [], function(j, valj) {
        			if(valj.mbanddevinfoForUn
        	        		&& valj.mbanddevinfoForUn.retCode == "0000"
        	        			&& valj.mbanddevinfoForUn.MbandDevAttrInfoList
        	        			&& valj.mbanddevinfoForUn.MbandDevAttrInfoList.length > 0){
        				// 设置IdentityStatus为0，表示未回收
        				if(!mbanddevinfoForUn){
        					mbanddevinfoForUn=valj.mbanddevinfoForUn;
        					$.each(mbanddevinfoForUn.MbandDevAttrInfoList|| [], function(i, vali) {
        						vali.identityStatus = 0;
        					});
        				}else{
        					mbanddevinfoForUn.MbandDevAttrInfoList = mbanddevinfoForUn.MbandDevAttrInfoList || [];
        					$.each(valj.mbanddevinfoForUn.MbandDevAttrInfoList|| [], function(i, vali) {
        						vali.identityStatus = 0;
        						mbanddevinfoForUn.MbandDevAttrInfoList.push(vali);
        					});
        				}

        			}
        		});
        		if(mbanddevinfoForUn){
        			var extNodeInfo1 = {
        					extNodeCode : "MBAND_DEV_INFO",
        					extXmlString : JSON.stringify(mbanddevinfoForUn)
        			};
        			window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo = window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo
        			|| {};
        			window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo = window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo
        			|| [];
        			window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(extNodeInfo1);
        		}
	        }

			if($Gadget.isHDHoffer){
				var custInfo = {};
				window._ysp_top.shoppingcart.hdhinfo = window._ysp_top.shoppingcart.hdhinfo || {};
				custInfo.certType = window._ysp_top.shoppingcart.hdhinfo.reserverCertType || "";
				custInfo.certId = window._ysp_top.shoppingcart.hdhinfo.reserverCertId || "";
				custInfo.userName = window._ysp_top.shoppingcart.hdhinfo.reserverCertName || "";
				custInfo.certAddress = window._ysp_top.shoppingcart.hdhinfo.reserverCertAddress || "";
				custInfo.picNameZ = window._ysp_top.shoppingcart.hdhinfo.picNameZ || "";
				var XNFH_MSISDN_NAME = {
					extNodeCode :"XNFH_MSISDN_NAME",
					extXmlString: custInfo.userName,
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo = window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo || {};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo =
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo || [];
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_MSISDN_NAME);
				var XNFH_IDCARD_TYPE = {
					extNodeCode :"XNFH_IDCARD_TYPE",
					extXmlString: custInfo.certType,
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_IDCARD_TYPE);
				var XNFH_IDCARD_NUM = {
					extNodeCode :"XNFH_IDCARD_NUM",
					extXmlString: custInfo.certId,
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_IDCARD_NUM);
				var XNFH_ADDRESS = {
					extNodeCode :"XNFH_ADDRESS",
					extXmlString: custInfo.certAddress,
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_ADDRESS);
				var XNFH_PicNameT = {
					extNodeCode :"XNFH_PicNameT",
					extXmlString: "",
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_PicNameT);
				var XNFH_PicNameZ = {
					extNodeCode :"XNFH_PicNameZ",
					extXmlString: custInfo.picNameZ,
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_PicNameZ);
				var XNFH_PicNameF = {
					extNodeCode :"XNFH_PicNameF",
					extXmlString: "",
					extNodeType: "Transparent"
				};
				window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(XNFH_PicNameF);
			}
        /* --------- 订单预约审核 start ----------- */
		var fromOrderReservation = JSON.parse(sessionStorage.getItem('param'));
        if (window && window._ysp_top && fromOrderReservation) {
            var SynSaleOrderFromOAP = {
                extNodeCode :"SynSaleOrderFromOAP",
                extXmlString: "1",
                extNodeType: "Transparent"
            };
            window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(SynSaleOrderFromOAP);
	        //US-20180122151649-2031066924
        	var ReserveSeq = {
                    extNodeCode :"ReserveSeq",
                    extXmlString: fromOrderReservation.reserveSeq,
                    extNodeType: "Transparent"
    	        };
        	window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(ReserveSeq);
            var OAPOrderId = {
                extNodeCode :"OAPOrderId",
                extXmlString: fromOrderReservation.OAPOrderId,
                extNodeType: "Transparent"
            };
            window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(OAPOrderId);
            for (var i = 0; i < fromOrderReservation.OAPSubOrderIds.length; i++) {
                var OAPSubOrderId = {
                    extNodeCode :"OAPSubOrderId" + (i + 1),
                    extXmlString: fromOrderReservation.OAPSubOrderIds[i],
                    extNodeType: "Transparent"
                };
                window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(OAPSubOrderId);
            }
            for (var i = 0; i < fromOrderReservation.OAPSubOperTypes.length; i++) {
                var OAPSubOperType = {
                    extNodeCode :"OAPSubOperType" + (i + 1),
                    extXmlString: fromOrderReservation.OAPSubOperTypes[i],
                    extNodeType: "Transparent"
                };
                window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push(OAPSubOperType);
            }
        }
        /* --------- 订单预约审核 end ----------- */


        if ('SALE_CARDS' === window._ysp_top.shoppingcart.$Pagea.salesFlag) {
                window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push({
                       extNodeCode: "InvoiceServNumber",
                       extXmlString: window._ysp_top.shoppingcart.$Pagea.orderInvoice.serviceNumber
                });

                window._ysp_top.checkoutValidateBody.createOrderReq.order.extInfo.extNodeInfo.push({
                       extNodeCode: "InvoiceCustName",
                       extXmlString: window._ysp_top.shoppingcart.$Pagea.orderInvoice.custName
                });
        }

            //若为营销工作台跳转的快选营销包，传recommendOid到后台
        if (window._ysp_top.shoppingcart.recommendOid) {
            window._ysp_top.checkoutValidateBody.mixturePOJO.recommendOid = window._ysp_top.shoppingcart.recommendOid;
        }
		if($Gadget.isHDHoffer && window._ysp_top.shoppingcart.hdhinfo.reserverCertType && window._ysp_top.shoppingcart.hdhinfo.reserverCertId && window._ysp_top.shoppingcart.hdhinfo.reserverCertName){
			$Controller.bes.ad.staticshoppingcar.yzwhStart($Gadget, $Fire, $UI);
		}
		else{
			$Controller.bes.ad.staticshoppingcar.businessValidateResult($Gadget,$Fire,$UI);
		}
    },
	businessValidateResult : function($Gadget,$Fire,$UI){
		// c00311908 融合属性验证
		$Controller.bes.ad.staticshoppingcar.checkFuseFamily($Gadget,$Fire,$UI);

		//成功后提交校验报文
        $Fire({
            service: 'bes.agentdesktop.checkoutboservice/busivalidate',
            params: {
                header: {},
                "checkoutbody": window._ysp_top.checkoutValidateBody
            },
            target: '$Gadget.checkoutValidateResult',
            onafter: function() {
                debugger;
                window._ysp_top.checkoutValidateResult = $Gadget.checkoutValidateResult;
                var result = ($Gadget.checkoutValidateResult || {}).body;
                $Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
                if ($Controller.bes.ad.staticshoppingcar.checkUcecResp(window._ysp_top.checkoutValidateResult.header, $UI)) {
                    $Gadget.notSaleApply = true;
                    var busiValidCheck = $Controller.bes.ad.staticshoppingcar.checkBusiValidResp($Gadget, $UI, window._ysp_top.checkoutValidateResult.body.checkOutResp, function() {
                        // 点击确认按钮表示继续执行，到结算页面
                        $Gadget.$Get('$Fire')({ targetstep: 'checkout' });

                        if (parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0) {


                            $Controller.bes.ad.staticshoppingcar.orerClose();
                            $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(result, "0");
                        }
                    });

                    if(busiValidCheck){
                        $Gadget.$Get('$Fire')({targetstep:'checkout'});

                        if(parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0){


                            $Controller.bes.ad.staticshoppingcar.orerClose();
                            $Controller.bes.ad.staticshoppingcar.portalClickProdProcess(result,"0");
                        }
                    }

                }
            }
        }, $Gadget);
	},

	checkFuseFamily:function($Gadget, $Fire, $UI)
	{
		debugger;
		var $Page = $Gadget.$Page;
		window._ysp_top.showAmalgamation = false;
		$Page.isBuy = false;

		var isAttr_FuseFamily = false;
		var fuseOfferingList = [];
		$.each(window._ysp_top.checkoutValidateBody.mixturePOJO.offerings || [], function(i, vali){
			// 找其下的资费商品 这一层是资费包
			$.each(vali.subOfferings || [], function(j,valj){
				if (valj.opCode == '3'){
					// 如果是退订 不处理
					return;
				}
				// 这一层是O下挂的子商品或产品
				$.each(valj.attributeGroups || [], function(k, valk){
					// 这一层的属性
					$.each(valk.attributes || [], function(m, valm){
						if (valm.attrCode == 'FuseFamily'){
							// 有这个属性
							isAttr_FuseFamily = true;
							return;
						}
					});

					if (isAttr_FuseFamily)
					{
						return;
					}
				});

				if (isAttr_FuseFamily)
				{
					return;
				}
			});

			if (isAttr_FuseFamily)
			{
				return;
			}
		});

		// 只要有一个商品包含有该属性，则要判断该用户是否已经加入FMC
		if (!isAttr_FuseFamily)
		{
			return;
		}

		$Fire({
			service : '/queryBroadbandOrderService/checkIsUserInFMC',
			params : {
				"servNumber" : window._ysp_top.serviceNumber
			},
			target : '$Page.checkFuseFamilyResult',
			onafter : function() {
				debugger;
				if ($Page.checkFuseFamilyResult && $Page.checkFuseFamilyResult=='NO')
				{
					// 没有加入FMC
					window._ysp_top.showAmalgamation = true;
				}
			},
			onerror : function() {
				debugger;
			}
		}, $Gadget);
	},

	//TODO
	yzwhStart:function($Gadget, $Fire, $UI){
        debugger;
		$Gadget.yzwhAttr = {};
		$Gadget.yzwhAttr.certType = window._ysp_top.shoppingcart.hdhinfo.reserverCertType;
		$Gadget.yzwhAttr.certId = window._ysp_top.shoppingcart.hdhinfo.reserverCertId;
		$Gadget.yzwhAttr.userName = window._ysp_top.shoppingcart.hdhinfo.reserverCertName;
		$Controller.bes.ad.staticshoppingcar.checkCertNumNew($Gadget, $Fire, $UI);
    },
	checkCertNumNew: function($Gadget, $Fire, $UI) {
        debugger;
        $Fire({
            service : "/common/dictkey2",
            params : {
                "dictkeylist" : ['OH_CERT_TYPE_CODE']
            },
            target : "$Gadget.yzwhDictList",
            onafter : function($Gadget)
            {
                debugger;
                $Gadget.dictitem = {};
                $Gadget.yzwhAttr.userInfoCertType = "";
                // 证件类型
                $Gadget.dictitem.TYPE_CODE = $Gadget.yzwhDictList["OH_CERT_TYPE_CODE"] || [];
                $.each($Gadget.dictitem.TYPE_CODE || [], function(i, vali){
                    if(vali.value == $Gadget.yzwhAttr.certType){
                        $Gadget.yzwhAttr.userInfoCertType = vali.key;
                    }
                });
                if($Gadget.yzwhAttr.userInfoCertType == ""){
                    $Gadget.yzwhAttr.userInfoCertType = "99";
                }
                $Controller.bes.ad.staticshoppingcar.inityzwhCertType($Gadget, $Fire, $UI);
            } // 查字典结束
        }, $Gadget);
    },
	reCampOn: function($Gadget, $Fire, $UI) {
        debugger;
        if ($Gadget.Campon_Certtype == "Y" && window._ysp_top.PSeq && $Gadget.enrollUserInfoDatabak){
            debugger;
            //调用解除预占服务
            var request={};
            request.customerName = $Gadget.enrollUserInfoDatabak.userName;
            request.idCardType = $Gadget.enrollUserInfoDatabak.reserverCertType;
            request.idCardNum = $Gadget.enrollUserInfoDatabak.reserverCertId;
            request.campON = "02";
			request.pSeq = window._ysp_top.PSeq;
            request.campofftype = "2";
            request.recdefid =  $Gadget.enrollUserInfoDatabak.recdefid;
			request.servnumber = $Gadget.serviceNumber;
            $Fire({
                service : "/bes/oc/occupyConnector",
                params : {
                    'request' : request
                },
                target : "$Gadget.campONSeq",
                onafter : function($Gadget) {
                    debugger;
                    if ($Gadget.campONSeq) {
                        // 清空预占凭证与备份的客户信息
                        window._ysp_top.PSeq = null;
                        $Gadget.enrollUserInfoDatabak = {};
                    }else{
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "解除预占失败。");
						$Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
                        return false;
                    }
                    $Controller.bes.ad.staticshoppingcar.campON($Gadget, $Fire, $UI);
                }
            },$Gadget);
        }else {
            $Controller.bes.ad.staticshoppingcar.campON($Gadget, $Fire, $UI);
        }
    },
	campON : function($Gadget, $Fire, $UI) {
		debugger;
        if($Gadget.Campon_Certtype == "Y"){
            //调用预占服务
			debugger;
            var request={};
			var attrList = [];
			for(var amount = 0;amount < window._ysp_top.shoppingcart.carofferingList.length;amount++){
				if($Gadget.hdhOfferList){
					if($Gadget.hdhOfferList.indexOf(window._ysp_top.shoppingcart.carofferingList[amount].offeringId.toString()) != -1){
						attrList = window._ysp_top.shoppingcart.carofferingList[amount].attributeGroups || [];
						$Gadget.amount = amount + 1;
						break;
					}
				}
			}
			if(attrList.length > 0 && $Gadget.amount <= window._ysp_top.shoppingcart.carofferingList.length)
			{
				one:for(var number = 0;number < attrList.length;number++){
					two:for(var value = 0;value < attrList[number].attributes.length;value++){
						if(attrList[number].attributes[value].attrCode == "FOLLOWMSISDN"){
							$Gadget.countermark = attrList[number].attributes[value].newValue;
							break one;
						}
					}
				}
			}
			else{
				$Controller.bes.ad.staticshoppingcar.businessValidateResult($Gadget,$Fire,$UI);
			}
            request.idCardType = $Gadget.yzwhAttr.userInfoCertType;
            request.idCardNum = $Gadget.yzwhAttr.certId;
            request.campON = "01";
            request.customerName =$Gadget.yzwhAttr.userName || "";
            request.recdefid = window._ysp_top.businessCode;
			request.servnumber = $Gadget.countermark;
            $Fire({
                service : "/bes/oc/occupyConnector",
                params : {
                    'request' : request
                },
                target : "$Gadget.campONSeq",
                onafter : function($Gadget) {
                    debugger;
                    if ($Gadget.campONSeq) {
                        debugger;
                        if ($Gadget.campONSeq.body && !$Gadget.campONSeq.body.pSeq) {
                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "预占接口调用失败，请30分钟后再试。");
							$Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
                            return false;
                        } else {
                            window._ysp_top.PSeq = $Gadget.campONSeq.body.pSeq;
                            $Gadget.enrollUserInfoDatabak = {};
                            $Gadget.enrollUserInfoDatabak.reserverCertType = $Gadget.yzwhAttr.userInfoCertType;
                            $Gadget.enrollUserInfoDatabak.reserverCertId = $Gadget.yzwhAttr.certId;
                            $Gadget.enrollUserInfoDatabak.userName = $Gadget.yzwhAttr.userName;
                            $Gadget.enrollUserInfoDatabak.recdefid = window._ysp_top.businessCode;
         	       		    $Gadget.enrollUserInfoDatabak.servnumber = $Gadget.countermark;
							$Controller.bes.ad.staticshoppingcar.assemblingCounterMark($Gadget);
							$Controller.bes.ad.staticshoppingcar.businessValidateResult($Gadget,$Fire,$UI);
                        }
                    } else {
                        // 预占接口调用失败，弹窗报错
                        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "预占接口调用失败，请30分钟后再试。");
						$Controller.bes.ad.staticshoppingcar.youCanTouchDataOfWholePage();
                        return false;
                    }
                }
            }, $Gadget);
        }
		else{
			$Controller.bes.ad.staticshoppingcar.assemblingCounterMark($Gadget);
            $Controller.bes.ad.staticshoppingcar.businessValidateResult($Gadget,$Fire,$UI);
        }
    },
	assemblingCounterMark : function($Gadget){
		for(var figure = 0;figure < window._ysp_top.shoppingcart.carofferingList.length; figure++){
			if($Gadget.hdhOfferList){
				var sign = true;
				if($Gadget.hdhOfferList.indexOf(window._ysp_top.shoppingcart.carofferingList[figure].offeringId.toString()) != -1){
					if(sign){
						sign = false;
						for(var quantity = 0;quantity < window._ysp_top.shoppingcart.carofferingList[figure].product.length; quantity++){
							var counterMarkSeq = {
										extNodeCode :"window_top_PSeq",
										extXmlString: window._ysp_top.PSeq
									};
							window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo = window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo || {};
							window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo.extNodeInfo = window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo.extNodeInfo || [];
							window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo.extNodeInfo.push(counterMarkSeq);
						}
					}
					else{
						for(var digit = 0;digit < window._ysp_top.shoppingcart.carofferingList[figure].product.length; digit++){
							var counterMarkSeq = {
										extNodeCode :"window_top_PSeq",
										extXmlString: "11111111111111111111111111111111"
									};
							window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo = window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo || {};
							window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo.extNodeInfo = window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo.extNodeInfo || [];
							window._ysp_top.checkoutValidateBody.mixturePOJO.offerings[figure].product[quantity].extInfo.extNodeInfo.push(counterMarkSeq);
						}
						}
				}
			}
		}
	},
	inityzwhCertType : function($Gadget,$Fire, $UI) {
		debugger;
        $Fire({
            'service': 'ucec/v1/common/qrysystemparamlistbykey',
            'params': {
            	keylist: ['OH_CAMPON_CERTTYPE']
            },
            'target': '$Gadget.ValidMaxUser',
            onafter : function($Gadget)
            	{
                	debugger;
                	$Gadget.Campon_Certtype = $Gadget.ValidMaxUser[0];
					$Controller.bes.ad.staticshoppingcar.reCampOn($Gadget, $Fire, $UI);
            	} // 查系统参数结束
        	}, $Gadget);
	},
    // 通用订单校验返回是否成功,通用校验场景，出现的弹出框为error型和confirm型
    checkBusiValidResp: function($Gadget, $UI, busiValidResp, warningConfirmCb, warningCancelCb, errorCb, dialogTitle) {
        debugger;
        var wanConfirmCb = null // error级别校验成功，但是出现warning或者info级别的校验失败时，点击confirm弹出框的确定时的回调
        var wanCancelCb = null; // 出现warning级别校验失败时，点击confirm弹出框的cancel按钮或者点击右上角叉号时的回调
        var errCb = null; // error级别校验失败，关闭error弹出框的回调
        var fontList = ["<font color='#333'>", "<font color='#333'>", "<font color='#333'>", "<font color='#EC4E5C'>"];

        if ($Gadget && !$Gadget.notSaleApply) {
            if (warningConfirmCb) {
                wanConfirmCb = function() {
                    $Gadget.$apply(warningConfirmCb);
                };
            }

            if (warningCancelCb) {
                wanCancelCb = function() {
                    $Gadget.$apply(warningCancelCb);
                };
            }

            if (errorCb) {
                errCb = function() {
                    $Gadget.$apply(errorCb);
                };
            }
        } else {
            wanConfirmCb = warningConfirmCb;
            wanCancelCb = warningCancelCb;
            errCb = errorCb;
        }

        if (!busiValidResp || !busiValidResp.returnMessage) {
            $UI.msgbox.error($UEE.i18n('ad.staticshoppingcar.message.businesscheckfailed'), $UEE.i18n('ad.staticshoppingcar.message.noresponsemessage'), errCb, errCb, errCb); //业务校验失败   //无响应报文。
            return false;
        }
        var returnMessage = busiValidResp.returnMessage;
        $Gadget.traceId = returnMessage.traceId;
        dialogTitle = dialogTitle || $UEE.i18n('ad.checkout.label.information'); //提示
        var msgList = [];

        if (returnMessage.busiValidateResult) {
            for (var i = 0; i < returnMessage.busiValidateResult.length; i++) {
                if (returnMessage.busiValidateResult[i].promptMessage) {
                    msgList.push(returnMessage.busiValidateResult[i]);
                }
            }
        }

        if ("0" != returnMessage.retCode) { // 出现error级别错误时的弹出框
            if (msgList.length == 0) {
                //message = returnMessage.retMessage || "校验失败，无校验提示报文";
                message = $UEE.i18n('ad.staticshoppingcar.message.systemerrortryagain'); //"系统错误，请稍后重试";
                $UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
                return false;
            }
            //$UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
            //pc校验失败会继续处理   目前只处理互斥情况
            if (returnMessage.returnOffering && returnMessage.returnOffering.length > 0 && returnMessage.returnOffering[0].actionType == 'D') {
                var retOfferingType = returnMessage.returnOffering[0].offeringType;
                //活动 档次 奖品 互斥不继续处理
                if(retOfferingType =='3' || retOfferingType =='4'|| retOfferingType =='5'){
                    msgList[0].promptSuggestion = $UEE.i18n("ad.person.message.handlePromError");
                    adtips.tipserror($Gadget,dialogTitle,msgList);
                }else{
                    adtips.tipscontinue($Gadget,dialogTitle,msgList,returnMessage.returnOffering,warningConfirmCb);
                }
            } else {
                adtips.tipserror($Gadget, dialogTitle, msgList);
            }
            return false;
        } else if (msgList.length > 0) { // 出现info跟warning错误时的弹出框
            //$UI.msgbox.warning(dialogTitle, message, wanConfirmCb,wanCancelCb,wanCancelCb);
            adtips.tipswarning($Gadget, dialogTitle, msgList, warningConfirmCb);
            return false;
        } else { // 不出现弹出框，返回true
            if (wanConfirmCb) {
                wanConfirmCb();
            }
            return true;
        }
    },
    checkUcecResp: function(respHeader, $UI) {
        if (!respHeader) {
            $UI.msgbox.error($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.staticshoppingcar.message.interfacedataretrunfail')); //接口数据返回失败
            return false;
        } else if (respHeader.resultCode != 0) {
            $UI.msgbox.error($UEE.i18n('ad.checkout.label.information'), respHeader.resultMessage || $UEE.i18n('ad.staticshoppingcar.message.interfacedataretrunfail')); //接口数据返回失败
            return false;
        } else {
            return true;
        }
    },
    orerClose: function() {
        debugger;
        var inner = parent.getPageById("60131004");
        if (inner) {
            var innerPage = parent.getPageById("60131004").find("iframe")[0];
            $(innerPage.contentWindow.document).find(".recommend").show();
        }

        $(".recommend").show();
        if ($(".recommend").css('display') != 'block') {
            $(".main_outer .wrap > div").animate({ "margin-right": "0px" }, 300);
        }
        $(".currentOrder").animate({ right: -300 }, 300, function() {
            $(this).hide();
        });
        $(".headerMenu0").removeClass('active');

        $("li.hide_list").hide();
    },

    openCart: function($Gadget) {
        debugger;
        $(".bes-ad-staticshoppingcar .currentOrder").css({ 'display': 'block' });
        $("li.hide_list").show();
        $(".header_menu .header_menu_child").siblings(".active").removeClass("active");
        var inner = parent.getPageById("60131004");
        if (inner) {
            var innerPage = parent.getPageById("60131004").find("iframe")[0];
            $(innerPage.contentWindow.document).find(".recommend").hide();
        }
        $(".recommend").hide();
        $(".main_outer .wrap > div").animate({ "margin-right": $(".currentOrder").width() + 10 }, 270);
        $(".currentOrder").css({ right: -240, 'display': 'block' }).animate({ right: +8 }, 500).show();
        //orderscrollbar.refreshScroll();//刷新滚动条
        var shoppingcarGadget = $(".bes-ad-staticshoppingcar").scope().$$childTail.$Gadget;
        $Controller.bes.ad.staticshoppingcar.init(shoppingcarGadget);

    },

    portalClickProdProcess: function(offeringinfo, opcode, operation) {
        debugger;
        var item = {};
        //jiwenzhi 00215236 此处传值会导致购物车的修改不起作用。现在他们通信是使用的html5方式，但是html5不支持克隆不同方式的数据。只支持全是退订或者订购的。
        var offeringInfoTmp = {}; //$.extend(true, {}, offeringinfo);
        window.shoppingcart.currOfferingInfo = offeringinfo;

        if (opcode == "0") {

            item = {
                title: $UEE.i18n('ad.staticshoppingcar.title.settlement'), //结算
                url: "resource.root/bes/ad/html/bes-ad-checkout.html#/checkout",
                id: "60131_checkout77",
                pageid: "resource.root/bes/ad/html/bes-ad-checkout.html#/checkout",
                httpsFlag: "",
            };
            operation = "checkout";

            if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131_checkout77")) {
                if (_ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel) {
                    window.$BES.$Portal.tabpanel.closeTabItem("60131_checkout77");
                }
            }
            window.$BES.$Portal.tabpanel.createTabItem(item);

            setTimeout(function() {

                if (parent.getPageById("60131004") && parent.getPageById("60131004").find("iframe") && parent.getPageById("60131004").find("iframe")[0].contentWindow.document.readyState == "complete") {
                    var msg = {
                        operation: operation,
                        offeringinfo: offeringInfoTmp,
                    };
                    if (navigator.userAgent.indexOf("MSIE") != -1) {
                        msg = JSON.stringify(msg);
                    }
                    parent.getPageById("60131004").find("iframe")[0].contentWindow.postMessage(msg, "*");
                    return;
                }

            }, 2000);

        }
        if (opcode == "1") {
            debugger;
            item = {
                title: $UEE.i18n('ad.staticshoppingcar.title.orderinggoods'), //商品订购
                url: "resource.root/bes/ordercapture/html/bes.oc.index.productorder.base.business.html#/index",
                id: "60131004",
                pageid: "resource.root/bes/ordercapture/html/bes.oc.index.productorder.base.business.html#/index",
                httpsFlag: "",
            };
            operation = operation || "prodorderfromportaldetail";

            // 特殊处理 如果商品类型是代理商
            if (offeringinfo.offeringlist && offeringinfo.offeringlist.length > 0) {
                var flag = offeringinfo.offeringlist[0].agentFlag;
                if ("AGENT_SALE" === flag) {
                    debugger;
                    // 代理商页签ID
                    var agentSaleItemId = "60131614";
                    // 注入顶级Tab控制对象
                    var tabPanel = _ysp_top.window.$BES.$Portal.tabpanel;
                    // 尝试进入代理商页签
                    if (!tabPanel.showTabItem(agentSaleItemId)) {
                        var agentUrl = "resource.root/bes/ordercapture/html/bes-oc-agentproduct.html";
                        // 进入失败，创建页签
                        tabPanel.createTabItem({
                            id: agentSaleItemId,
                            pageid: agentUrl,
                            title: $UEE.$I18n['ad.marketplan.title.agentsale'],
                            url: agentUrl,
                            httpsFlag: "",
                        });
                    };
                    // 结束portalClickProdProcess函数的执行
                    return;
                }
            }

            if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131004")) {
                //将焦点放到商品订购页面
                _ysp_top.window.$BES.$Portal.tabpanel.showTabItem("60131004");
                var msg = {
                    operation: operation,
                    offeringinfo: offeringInfoTmp,
                };
                if (navigator.userAgent.indexOf("MSIE") != -1) {
                    msg = JSON.stringify(msg);
                }
                parent.getPageById("60131004").find("iframe")[0].contentWindow.postMessage(msg, "*");
                return;
            }

            if (offeringinfo.relatedTransOldOffering) {
                item = {
                    title: $UEE.i18n('ad.staticshoppingcar.title.personalunifiedview'), //个人统一视图
                    url: "resource.root/bes/ad/html/bes.ad.personalunifiedview.html",
                    id: "60131006",
                    pageid: "resource.root/bes/ad/html/bes.ad.personalunifiedview.html",
                    httpsFlag: "",
                };
                operation = "prodorderfromportalchange";
                if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131006")) {
                    if (_ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel) {
                        _ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("60131006");
                    }
                }

                setTimeout(function() {
                    if (parent.getPageById("60131006") && parent.getPageById("60131006").find("iframe") && parent.getPageById("60131006").find("iframe")[0].contentWindow.document.readyState == "complete") {
                        var msg = {
                            operation: operation,
                            offeringinfo: offeringInfoTmp,
                        };
                        if (navigator.userAgent.indexOf("MSIE") != -1) {
                            msg = JSON.stringify(msg);
                        }
                        parent.getPageById("60131006").find("iframe")[0].contentWindow.postMessage(msg, "*");
                    }

                }, 2000);

            } else {
                window.$BES.$Portal.tabpanel.createTabItem(item);
                setTimeout(function() {

                    if (parent.getPageById("60131004") && parent.getPageById("60131004").find("iframe") && parent.getPageById("60131004").find("iframe")[0].contentWindow.document.readyState == "complete") {
                        var msg = {
                            operation: operation,
                            offeringinfo: offeringInfoTmp,
                        };
                        if (navigator.userAgent.indexOf("MSIE") != -1) {
                            msg = JSON.stringify(msg);
                        }
                        parent.getPageById("60131004").find("iframe")[0].contentWindow.postMessage(msg, "*");
                        return;
                    }

                }, 2000);

            }

        }
        if (opcode == "2" || opcode == "3" || opcode == "F") {

            item = {
                title: $UEE.i18n('ad.staticshoppingcar.title.personalunifiedview'), //个人统一视图
                url: "resource.root/bes/ad/html/bes.ad.personalunifiedview.html",
                id: "60131006",
                pageid: "resource.root/bes/ad/html/bes.ad.personalunifiedview.html",
                httpsFlag: "",
            };
            operation = "prodorderfromportalchange";
            /*if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131006"))
            {
                if (_ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel)
                {
                    _ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("60131006");
                }
            }*/

            setTimeout(function() {
                if (parent.getPageById("60131006") && parent.getPageById("60131006").find("iframe") && parent.getPageById("60131006").find("iframe")[0].contentWindow.document.readyState == "complete") {
                    var msg = {
                        operation: operation,
                        offeringinfo: offeringInfoTmp,
                    };
                    if (navigator.userAgent.indexOf("MSIE") != -1) {
                        msg = JSON.stringify(msg);
                    }
                    parent.getPageById("60131006").find("iframe")[0].contentWindow.postMessage(msg, "*");
                }

            }, 2000);
        }





    },
    /**
     * 加载过程，不允许修改页面数据
     */
    dontTouchDataOfWholePage: function() {
        var loadingCover = $('#loadingcover');
        if (loadingCover && loadingCover.length > 0) {
            loadingCover.show();
        } else {
            var a = "<div class=\"fullcover\" id=\"loadingcover\"><img class=\"loading\" src=\"resource.root/bes/ad/images/indicator_verybig.gif\" /></div>";
            $('body').append(a);

        }

    },

    /**
     * 加载结束，放开限制，允许修改页面数据
     */
    youCanTouchDataOfWholePage: function() {
        $('#loadingcover').hide();
    },

    number: 100000000, // 临时规避，防止和后台的序列重复，以后需要都在前台生成序列

    getNextNumber: function() {
        return $Controller.bes.ad.staticshoppingcar.number++;
    },

    //判断是否为家庭产品
    isFamilyProd: function(offering) {
        if (offering.isbindOffer == "Y" || offering.isBundled) {
            var subOfferings = offering.ocOfferInfoVA || offering.subOfferings || [];
            //如果已选产品是家庭网产品包
            for (var i = 0; i < subOfferings.length; i++) {
                //                  if(subOfferings[i].bundleSelectType == "M" || subOfferings[i].selectType == "M"){
                if (subOfferings[i].isbindOffer == "N" || !subOfferings[i].isBundled) {
                    var product = subOfferings[i].ocProductInfoVA || subOfferings[i].product;
                    if (product && product[0]) {
                        if (product[0].prodType == "JTW" || product[0].prodType == "JTVW" || product[0].prodType == 'WPMP') {
                            return product[0];
                        }
                    }
                }
                //                  }
            }
        } else {
            //如果是单个产品
            var product = offering.ocProductInfoVA || offering.product;
            if (product && product[0]) {
                if (product[0].prodType == "JTW" || product[0].prodType == "JTVW" || product[0].prodType == "JTGX" || product[0].prodType == 'WPMP') {
                    return product[0];
                }
            }
        }
        return null;
    },



    //加入购物车
    addtostaticshoppingcar: function(offeringinfo) {
        debugger;
        if ((parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0) && window._ysp_top.shoppingcart && window._ysp_top.shoppingcart.carofferingList) {
            window._ysp_top.shoppingcart.carofferingList.push(offeringinfo);
        }
    },
    //使数组中无重复的元素
    noRepeat: function(arr) {
        var result = [],
            isRepeated;

        for (var i = 0; i < arr.length; i++) {
            isRepeated = false;
            for (var j = 0; j < i; j++) {
                if (arr[i] == result[j]) {
                    isRepeated = true;
                    break;
                }
            }
            if (!isRepeated) {
                result.push(arr[i]);
            }
        }


        return result;
    },

    changeEffMode: function($Gadget, offeringinfo, effType) {
        debugger;
        offeringinfo.displayChangeMode = !offeringinfo.displayChangeMode;
        if (effType.key != 'C' && effType.key != 'P') {
            offeringinfo.postPointOfferingId = null;
            //子offer
            if (offeringinfo.effectiveWay.selectedKey) {
                offeringinfo.effectiveWay.selectedKey = effType.key;
            } else {
                offeringinfo.effectiveWay.effectiveTypes[0] = effType;
            }
            $Controller.bes.ad.staticshoppingcar.effectivedate(offeringinfo);
            return;
        }

        //弹出框
        window._ysp_top.shoppingcart.effectiveofferinginfo = offeringinfo;
        window._ysp_top.shoppingcart.effType = effType;
        _ysp_top.loadPopup("resource.root/bes/ad/html/bes.ad.modifyeffectivemodefromshoppingcar.html");
    },
    changeExpMode: function($Gadget, offeringinfo, effType) {
        debugger;
        offeringinfo.displayChangeMode = !offeringinfo.displayChangeMode;
        if (effType.key != 'C') {
            //子offer
            if (offeringinfo.expirationWay.selectedKey) {
                offeringinfo.expirationWay.selectedKey = effType.key;
            } else {
                offeringinfo.expirationWay.expirationTypes[0] = effType;
            }
            $Controller.bes.ad.staticshoppingcar.effectivedate(offeringinfo);
            return;
        }

        //弹出框
        window._ysp_top.shoppingcart.effectiveofferinginfo = offeringinfo;
        window._ysp_top.shoppingcart.effType = effType;
        _ysp_top.loadPopup("resource.root/bes/ad/html/bes.ad.modifyeffectivemodefromshoppingcar.html");

    },
    clickEffMode: function($Gadget, offeringinfo) {
        debugger;
        offeringinfo.displayChangeMode = !offeringinfo.displayChangeMode;
        $.each($Gadget.data.shoppingcar || [], function(i, val) {
            if (val != offeringinfo) {
                val.displayChangeMode = false;
            }
            $.each(val.subOfferings || [], function(j, valj) {
                if (valj != offeringinfo) {
                    valj.displayChangeMode = false;
                }
            });
        });
    },

    ordervalidatetest : function($Gadget) {
    	debugger;
    	if($Gadget.validateFlag == "Y") {
    		$Controller.bes.ad.staticshoppingcar.ordervalidate($Gadget);
        }
    },

    /**
     * 判断该商品是否可以订购
     * */
    ordervalidate : function($Gadget) {
    	debugger;
    	var showofferlist = window._ysp_top.showOfferingLists;
		var serviceNum = window._ysp_top.serviceNum;
    	if (null == serviceNum || "" == serviceNum || serviceNum.length < 10){
    		return;
    	}

    	var offeringList = showofferlist.offeringList;

    	if (!offeringList){
    		return;
    	}
    	debugger;
    	//新建一个集合存放
    	var newOfferList = [];
    	var childList = [];
    	for (var i = 0; i < offeringList.length; i++){
    		if (offeringList[i].isBundle == "N" && offeringList[i].isMainOffer == "N"){
    			newOfferList.push(offeringList[i]);
    		}
    		if (window._ysp_top.keyWord4NX != ""){
    			if (offeringList[i].isBundle == "Y" && offeringList[i].offerType != "3"){
    				newOfferList.push(offeringList[i]);
    				var pcHitChildOfferingList = offeringList[i].pcHitChildOfferingList;
    				if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
    					for (var j = 0; j < pcHitChildOfferingList.length; j++){
    						childList.push(pcHitChildOfferingList[j].childOfferingId);
    					}
    				}
    			}
    		}
    	}
    	debugger;

    	$Gadget.newOfferList = newOfferList;
    	$Gadget.childList = childList;
    	if ($Gadget.childList && $Gadget.childList != null){
    		$Controller.bes.ad.staticshoppingcar.queryChildOffer($Gadget);
    	}

    },
    /**
     * 查询子商品
     */
    queryChildOffer : function($Gadget){
    	debugger;

    	$Page = $Gadget.$Page;

    	$Gadget.$Get('$Fire')({
			service:"/recrollbackboservice/queryOfferingBaseInfoByIdList",
			params:{
				offeringIdList : $Gadget.childList
			},
			target:"$Gadget.childOfferList",
			onafter:function($Gadget,$Page){
				debugger;
				var carofferlist = $Gadget.data.shoppingcar;
		    	//将购物车中的商品传过来
				var newCarOfferList = [];
				for (var i = 0; i < carofferlist.length; i++){
					newCarOfferList.push(carofferlist[i]);
				}
		    	for (var i = 0; i < carofferlist.length; i++){
		    		var subOfferings = carofferlist[i].subOfferings;
		    		if (subOfferings != null && subOfferings.length > 0){
		    			for (var j = 0; j < subOfferings.length; j++){
		    				if (subOfferings[j].checked == true){
		    					newCarOfferList.push(subOfferings[j]);
		    				}
		    			}
		    		}
		    	}
		    	debugger;
		    	var newOfferList = $Gadget.newOfferList;

		    	if ($Gadget.childOfferList && $Gadget.childOfferList != null){
		    		for (var i = 0; i < $Gadget.childOfferList.length; i++){
		    			newOfferList.push($Gadget.childOfferList[i]);
		    		}
		    	}

		    	debugger;

				if(newCarOfferList.length == 0 && newOfferList.length == 0){
				     return;
				}
				$Page.checkoutValidateBody = {businessType: "ChangeProduct",
						needCacheBusiValidate: 'N',
						createOrderReq:{
							order:{
								orderPayment:[]
							}
						},
					mixturePOJO:{
						offerings: newOfferList,
						packageFee:'N',
						seniorId:'CHANGE_OFFER',
						eventId:'AddOfferPreCheck'
					}
				};
				$Gadget.$Get('$Fire')(
						{
						'service': '/validatebeforeorderservice/validatebeforeorder',
							'params' : {
								'carOfferList' : newCarOfferList,
								'header' : {},
								'checkOutBody' : $Page.checkoutValidateBody
							},
			    			'target' : '$Page.ValidateResultInfoPOJO',
			    			'onafter' : function($Gadget) {
			    				debugger;
			    				var showofferlist = window._ysp_top.showOfferingLists;
			    				var offerList = showofferlist.offeringList;
			    				if ($Page.ValidateResultInfoPOJO != null){
				    				if($Page.ValidateResultInfoPOJO.length > 0) {
				    					//现将界面上所有的置空
				    					for(var k = 0;k < offerList.length;k++) {
				    						offerList[k].disableFlag = false;
											offerList[k].score = null;
											var pcHitChildOfferingList = offerList[k].pcHitChildOfferingList;
											if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
												for (var a = 0; a < pcHitChildOfferingList.length; a++){
													pcHitChildOfferingList[a].disableFlag = false;
													pcHitChildOfferingList[a].score = null;
												}
											}
				    					}

				    					for(var i = 0;i < $Page.ValidateResultInfoPOJO.length;i++) {

				    						var validateResultInfo = $Page.ValidateResultInfoPOJO[i];

				    						for(var f = 0;f < offerList.length;f++) {
												if(validateResultInfo.isPackage == "Y"){
													if (window._ysp_top.keyWord4NX != ""){
														var pcHitChildOfferingList = offerList[f].pcHitChildOfferingList;
														if (offerList[f].offeringId == validateResultInfo.packOfferId){
															if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
																for (var j = 0; j < pcHitChildOfferingList.length; j++){
																	if (pcHitChildOfferingList[j].childOfferingId == validateResultInfo.srcOfferId){
																		if(validateResultInfo.item == "E" || validateResultInfo.item == "UE") {
																			pcHitChildOfferingList[j].disableFlag = true;
																			if (validateResultInfo.destOfferNameList.length == 1){
																				pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"互斥";
																			}else{
																				pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"等互斥";
																			}
																		}else if (validateResultInfo.item == "D" || validateResultInfo.item == "UD"){
																			pcHitChildOfferingList[j].disableFlag = true;
																			if (validateResultInfo.destOfferNameList.length == 1){
																				pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0];
																			}else{
																				pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0]+"等";
																			}
																		}
																	}
																}
															}
														}else if (validateResultInfo.packOfferId == null || !validateResultInfo.packOfferId){
															if (offerList[f].offeringId == validateResultInfo.srcOfferId) {
																for (var j = 0; j < pcHitChildOfferingList.length; j++){
																	if(validateResultInfo.item == "E" || validateResultInfo.item == "UE") {
																		pcHitChildOfferingList[j].disableFlag = true;
																		if (validateResultInfo.destOfferNameList.length == 1){
																			pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"互斥";
																		}else{
																			pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"等互斥";
																		}
																	}else if (validateResultInfo.item == "D" || validateResultInfo.item == "UD"){
																		pcHitChildOfferingList[j].disableFlag = true;
																		if (validateResultInfo.destOfferNameList.length == 1){
																			pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0];
																		}else{
																			pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0]+"等";
																		}
																	}
																}
															}
														}
													}
												}else{
													if(offerList[f].offeringId == validateResultInfo.srcOfferId) {
														if(validateResultInfo.item == "E" || validateResultInfo.item == "UE") {
															offerList[f].disableFlag = true;
															if (validateResultInfo.destOfferNameList.length == 1){
																offerList[f].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"互斥";
															}else{
																offerList[f].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"等互斥";
															}
														} else if(validateResultInfo.item == "D" || validateResultInfo.item == "UD") {
															offerList[f].disableFlag = true;
															if (validateResultInfo.destOfferNameList.length == 1){
																offerList[f].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0];
															}else{
																offerList[f].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0]+"等";
															}
														}
													}
												}
											}
				    					}
				    				}else{
				    					for(var k = 0;k < offerList.length;k++) {
				    						offerList[k].disableFlag = false;
				    						offerList[k].score = null;
				    						var pcHitChildOfferingList = offerList[k].pcHitChildOfferingList;
				    						if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
				    							for (var a = 0; a < pcHitChildOfferingList.length; a++){
				    								pcHitChildOfferingList[a].disableFlag = false;
				    								pcHitChildOfferingList[a].score = null;
				    							}
				    						}
				    					}
				    				}
			    				}else{
			    					for(var k = 0;k < offerList.length;k++) {
			    						offerList[k].disableFlag = false;
			    						offerList[k].score = null;
			    						var pcHitChildOfferingList = offerList[k].pcHitChildOfferingList;
			    						if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
			    							for (var a = 0; a < pcHitChildOfferingList.length; a++){
			    								pcHitChildOfferingList[a].disableFlag = false;
			    								pcHitChildOfferingList[a].score = null;
			    							}
			    						}
			    					}
			    				}
			    				//先赋值做标记，调用修改购物车的方法
						        debugger;
						        window._ysp_top.refreshShowFlag = true;

						        if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131004")) {
						            //将焦点放到商品订购页面
						            _ysp_top.window.$BES.$Portal.tabpanel.showTabItem("60131004");
						            var msg = {
						                operation: operation,
						                offeringinfo: offeringInfoTmp,
						            };
						            parent.getPageById("60131004").find("iframe")[0].contentWindow.postMessage(msg, "*");
						        }
			    			}
			    		}, $Gadget);
			}
		},$Gadget);
    },

    //两城一号预约营销，做特殊校验
    checkMnpProm: function($UI, promInfoList, tempList, familyOfferList) {
        var $Pagea = window._ysp_top.shoppingcart.$Pagea || {};

        var mnpPromFlag = false;
        for (var j = 0; j < promInfoList.length; j++) {
            if (promInfoList[j].mnpPromFlag) {
                mnpPromFlag = true;
                break;
            }
        }

        if (mnpPromFlag) {
            for (var k = 0; k < promInfoList.length; k++) {
                if (!promInfoList[k].mnpPromFlag) {
                    //两城一号营销方案预约，只能订购携入地营销方案，不能办理其他业务。
                    $UI.msgbox.info($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.message.mnpprom_exclusive"));
                    return false;
                }
            }

            if (tempList.length || familyOfferList.length) {
                //两城一号营销方案预约，只能订购携入地营销方案，不能办理其他业务。
                $UI.msgbox.info($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.message.mnpprom_exclusive"));
                return false;
            }

            //购物车中根据这个flag传递businessType
            $Pagea.agentFlag = "TransSubsPreReward";
        } else {
            //如果没有两城一号预约营销，将标记去掉
            if ($Pagea.agentFlag && $Pagea.agentFlag.indexOf("TransSubsPreReward") >= 0) {
                $Pagea.agentFlag = "";
            }
        }

        return true;
    },

    addZGNetTvFreeProd: function($Gadget, $UI, offeringList) {
        debugger;
        $Fire({
            service: 'ucec/v1/common/qrysystemparambykey',
            params: {
                key: "ZGNETTVFeeProd"
            },
            target: "$Gadget.zgNetTvFeeProd",
            onafter: function() {
                debugger;
                //没有赠送产品 则走原来的逻辑
                if (!$Gadget.zgNetTvFeeProd) {
                    $Controller.bes.ad.staticshoppingcar.gocheckout($Gadget, $UI, offeringList);
                    return;
                }
                var queryReq = {
                    'offerid': $Gadget.zgNetTvFeeProd,
                    'condition': {
                        businessCode: 'ChangeProduct'
                    }
                };
                debugger;

                $Fire({
                    'service': 'bes.oc.queryofferdetailservice/queryofferdetail',
                    'params': queryReq,
                    'target': '$Gadget.data.offeringinfo',
                    'onafter': function() {
                        if (!$Gadget.data.offeringinfo) {
                        	$Controller.bes.ad.staticshoppingcar.gocheckout($Gadget, $UI, offeringList);
                            return;
                        }
                        var oldOffer = $.extend(true, {}, $Gadget.data.offeringinfo);
                        var offering = {};
                        $Fire({
                            service: 'ucec/v1/offering/offeringattributes_query',
                            params: {
                                header: null,
                                body: {
                                    offeringId: oldOffer.offerId
                                }
                            },
                            target: '$Gadget.productAttrs',
                            onafter: function() {
                                debugger;


                                offering.offeringId = oldOffer.offerId;
                                offering.offeringName = oldOffer.offerName;
                                offering.offeringDesc = oldOffer.offerDesc;
                                offering.offeringCode = oldOffer.offerCode;
                                offering.isShowDayConvert = oldOffer.isShowDayConvert == "Y";
                                offering.isZGNETTVFeeProd = true;

                                if ($Gadget.productAttrs && $Gadget.productAttrs.body) {
                                    var commattr = $Gadget.productAttrs.body.attributeGroups || [];
                                    offering.attributeGroups = commattr;
                                }

                                if (offering.offeringId == ($Page.data || {}).icrmMarketingOfferingId) {
                                    offering.recommendOid = $Page.data.recommendOid;
                                    $Page.data.icrmMarketingOfferingId = null;
                                }
                                offering.opCode = '1';
                                if (oldOffer.ocEffectiveMode) {
                                    //取默认生效方式
                                    offering.effectiveWay = $.extend(true, {}, oldOffer.ocEffectiveMode);

                                    var tempSelectedMode = offering.effectiveWay.selectedMode;
                                    for (var i = 0; i < ((offering.effectiveWay || {}).effectiveTypes || []).length; i++) {
                                        if ((offering.effectiveWay.effectiveTypes[i] || {}).key !== offering.effectiveWay.selectedMode) {
                                            //次日会改成nd
                                            if (offering.effectiveWay.selectedMode == 'S' && (offering.effectiveWay.effectiveTypes[i] || {}).key == 'ND') {
                                                tempSelectedMode = 'ND';
                                                continue;
                                            }
                                            offering.effectiveWay.effectiveTypes.splice(i, 1);
                                            i--;
                                        }
                                    }
                                    offering.effectiveWay.selectedMode = tempSelectedMode;
                                    offering.displaydate = (((offering.effectiveWay || {}).effectiveTypes || [])[0] || {}).value;
                                    //将所有生效方式保存下来
                                    offering.effectiveWay.effectiveWays = $.extend(true, {}, oldOffer.ocEffectiveMode);
                                }

                                if (oldOffer.ocExpireMode) {
                                    //取默认失效方式
                                    offering.expirationWay = $.extend(true, {}, oldOffer.ocExpireMode);
                                    for (var i = 0; i < ((offering.expirationWay || {}).expirationTypes || []).length; i++) {
                                        if ((offering.expirationWay.expirationTypes[i] || {}).key !== offering.expirationWay.selectedMode) {
                                            offering.expirationWay.expirationTypes.splice(i, 1);
                                            i--;
                                        }
                                    }
                                    //将所有失效方式保存下来
                                    offering.expirationWay.expirationWays = $.extend(true, {}, oldOffer.ocExpireMode);
                                }
                                offeringList.push(offering);
                                $Controller.bes.ad.staticshoppingcar.gocheckout($Gadget, $UI, offeringList);
                            }
                        }, $Gadget);
                    }
                }, $Gadget);
            }
        }, $Gadget);
    },

    /**
	 * 判断是否同商品（兼容营销方案）
	 */
    isSameOffer : function(offer, offerCompare) {
    	if (offer && offerCompare){
    		// 默认是批次编码相同即可。
    		if (offer.offeringId == offerCompare.offeringId) {
    			// 如果存在档次，需要判断档次是否相同
    			if (offer.levelBaseInfo && offerCompare.levelBaseInfo){
    				if (offer.levelBaseInfo.offeringId == offerCompare.levelBaseInfo.offeringId){
    					return true;
    				}
    			} else {
    				return true;
    			}
    		}
    	}
    	return false;
    },
    /*
     * 计算商品包下子商品是否降档
     */
    calculatePriceTotal: function($Gadget){
        debugger;
        window._ysp_top.$Page = window._ysp_top.$Page || {};
        $Page.questionnaireForLower = window._ysp_top.$Page.questionnaireForLower;
        $Page.isDropGrade = false;
        if (!$Page.questionnaireForLower) {
            return;
        }
        var gradePriceTotal = 0;
        var goalGradePriceTotal = 0;
        var isPmBaseOffer = false;
        var isPmBaseOffer_goal = false;
        var doQuestionnaire = false;
        var hasPackageOffer = false;
        $.each($Gadget.data.shoppingcar || [], function(i, vali){
            if (vali.isBundled) {
                hasPackageOffer = true;
                $.each(vali.subOfferings || [], function(j, valj){
                    if (valj.opCode == "1") { // 新套餐
                        isPmBaseOffer = false;
                        $.each(valj.attributeGroups || [], function(k, valk){
                            $.each(valk.attributes || [], function(m, valm){
                                if (valm.attrCode == "PM_BASE_OFFER" && valm.newValue == "1") {
                                    isPmBaseOffer = true;
                                }
                                if (valm.attrCode == "PM_OFFER_PRICE" && valm.newValue) {
                                    if (adutil.checkNumberChar(valm.newValue)) { // 数字验证
                                        gradePriceTotal = parseInt(valm.newValue);
                                    }else{
                                        gradePriceTotal = 0;
                                    }
                                }
                            });
                        });
                    }
                    if (valj.opCode == "3") { // 旧套餐
                        isPmBaseOffer_goal = false;
                        $.each(valj.attributeGroups || [], function(k, valk){
                            $.each(valk.attributes || [], function(m, valm){
                                if (valm.attrCode == "PM_BASE_OFFER" && valm.newValue == "1") {
                                    isPmBaseOffer_goal = true;
                                }
                                if (valm.attrCode == "PM_OFFER_PRICE" && valm.newValue) {
                                    if (adutil.checkNumberChar(valm.newValue)) { // 数字验证
                                        goalGradePriceTotal = parseInt(valm.newValue);
                                    }else{
                                        goalGradePriceTotal = 0;
                                    }
                                }
                            });
                        });
                    }
                });
                if (isPmBaseOffer && isPmBaseOffer_goal) { // 表示降档了,需要做问卷调查
                    if (gradePriceTotal < goalGradePriceTotal) {
                        doQuestionnaire = true;
                    }
                }
            }
        });
        if (hasPackageOffer && doQuestionnaire) {
            // $Page.serviceNum = (window._ysp_top.subsInfo || {}).serviceNumber;
            // $Page.familyDropGradeBusinessId = (window._ysp_top.subsInfo || {}).subsId;
            // $Page.questionnairePop = true;
            $Page.isDropGrade = true;
        }else{
            // $Page.questionnairePop = false;
            $Page.isDropGrade = false;
        }
        window._ysp_top.$Page.isDropGrade = $Page.isDropGrade;
    }
});

Date.prototype.Format = function(fmt) {
    var o = {
        "M+": this.getMonth() + 1, // 月份
        "d+": this.getDate(), // 日
        "D+": this.getDate(), // 日
        "h+": this.getHours(), // 小时
        "H+": this.getHours(), // 小时
        "m+": this.getMinutes(), // 分
        "s+": this.getSeconds(), // 秒
        "q+": Math.floor((this.getMonth() + 3) / 3), // 季度
        "S": this.getMilliseconds() // 毫秒
    };
	if (/(y+)/.test(fmt) || /(Y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "")
            .substr(4 - RegExp.$1.length));
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
    return fmt;
};
