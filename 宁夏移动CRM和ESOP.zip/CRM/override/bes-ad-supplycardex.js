//读卡器返回信息分隔符，方便统一处理  
var splitChar = "&";
// 控件函数结果码索引，方便统一处理  
var resultCodeIndex = 0;
// 控件函数结果信息索引  
var resultInfoIndex = 1;
// 函数错误码位置索引 ，湖北和其他省相同  
var errCodeIndex = 1;
// 控件函数结果码，正确码  
var successCode = "0";

var readCardObj = document.getElementById('NewWriteCardOcx');

//TODO 系统参数待配置

//var commonDownLoadAddr = "${bl:paramValue('ComponentDownLoadAddr')}";
//var dllDirPath = "${bl:paramValue('NewWriteCardDllPath')}";
//var dllName = dllDirPath.substring(dllDirPath.lastIndexOf("/")+1, dllDirPath.lastIndexOf("."));
//var dllParentDirPath = dllDirPath.substring(0, dllDirPath.lastIndexOf("/"));
//var newWriteCardDllVersion = "${bl:paramValue('NewWriteCardDllVersion')}";
//var newWriteCardOcxName = "${bl:paramValue('NewWriteCardOcxName')}";

$Controller("bes.ad.supplycardex.initBlankCard", function($Page,$Gadget){
		debugger;		
		//是否使用空白卡
		$Gadget.isUseBlankCard=false;
	     var isUseBlankCard = [{key:"Y", value:"是"},{key:"N", value:"否"}];
	     var droplist = {
	    		 isUseBlankCard : {
						data : isUseBlankCard,
						onValueChange : function(self) {
							debugger;
							$Gadget.$apply(function() {
								// 改变类型，清空输入框及原有信息
								$Controller.bes.ad.supplycardex.cleardata($Gadget);
								
								$Gadget.data.isUseBlankCard = self.$input.attr("key");
								
								writeLocalFile($Page, "是否使用空白卡："+$Gadget.data.isUseBlankCard);
								if($Gadget.data.isUseBlankCard == 'Y'){
									$Gadget.isUseBlankCard=true;
									$("#validateCard").addClass("disabled");
									$("#simcardReadSIM").removeClass("disabled");
									// 读卡不用号卡校验
									$Gadget.$Page.checkSimAndTelNumResult = true;
									$("#newcardnum").attr("readonly","readonly");
								}else{
									$Gadget.isUseBlankCard=false;
									$("#validateCard").removeClass("disabled");
									$("#simcardReadSIM").addClass("disabled");
									// 实体卡需要校验
									$Gadget.$Page.checkSimAndTelNumResult = false;
									$Gadget.$Page.simcardReadFlag = true;
									$("#newcardnum").removeAttr("readonly");
									
									//如果切换是否使用空白卡需要情况空白卡信息，防止不使用空白卡时也提交到结算页面
									if($Page.blankCardInfo){
										$Page.blankCardInfo = "";
									}
								}
							});
						},
						selectedKey : isUseBlankCard[1].key
					}
				};
	     $("#simcardReadSIM").addClass("disabled");//读卡默认不可用，只有选择了使用空白卡才可用

	     $Gadget.droplist = droplist;
});

//清空输入信息
$Controller("bes.ad.supplycardex.cleardata", function($Gadget){
	if($Gadget.data && $Gadget.data.cardNo){
		$Gadget.data.cardNo = "";
	}
	$("#newcardnum").val("");
	if($Gadget.data && $Gadget.data.blankCardSN){
		$Gadget.data.blankCardSN = "";
	}
	$("#blankCardSN").val("");
	if($Gadget.data && $Gadget.data.newCardInfo){
		$Gadget.data.newCardInfo.typeName = null;
		$Gadget.data.newCardInfo.resTypeName = null;
		$Gadget.data.newCardInfo = {};
	}
	if($Page.blankCardInfo)
	{
		$Page.blankCardInfo = null;
	}
});

// 读SIM卡按钮
$Controller("bes.ad.supplycardex.read", function($Gadget, $Fire, $UI, $Page) {
	debugger;
	$Gadget.data = $Gadget.data || {};
	// 读卡
	$Controller.bes.ad.supplycardex.newReadCard($Gadget, $Fire, $UI, $Page);
});

$Controller("bes.ad.supplycardex",{
	
	/**
	 * 读卡
	 */
	newReadCard : function($Gadget, $Fire, $UI, $Page){

		debugger;
		//判断读卡是否完成并成功，否则不允许提交业务
		$Gadget.simcardReadFlag = false;
		// 防止重复点击读卡
        if ($Gadget.isNewReadCardFlag) {
            return;
        }
        $Gadget.isNewReadCardFlag = true;
		writeLocalFile($Page, "");
		writeLocalFile($Page, "点击读卡！");
		
		if(!$Gadget.isUseBlankCard)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "您当前没有选择使用空白卡，如果确实需要，请先选择使用空白卡！");
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),"您当前没有选择使用空白卡，如果确实需要，请先选择使用空白卡！");
			return false;
		}
		
		//下面补卡业务
		if(!judgeNewOCX($UI))
		{ 
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "控件校验失败！");
			return;
		}
			
		var configReaderResult = OPSConfigReader(); 
		if("" != configReaderResult)
		{
			if("" == analyzeReadCardInfo(configReaderResult, "读卡器设置失败，请检查读卡器！",$UI))
			{
				$Gadget.isNewReadCardFlag = false;
				writeLocalFile($Page, "读卡器设置失败，请检查读卡器！");
				return false;
			}
		}
		
		var getBlankCardSNResult = OPSGetCardSN();
		var blankCardSN = analyzeReadCardInfo(getBlankCardSNResult, "获取空白卡序列号错误！",$UI);
		if("" == blankCardSN)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "获取空白卡序列号错误！");
			return false;
		}
		
		// 赋值空白卡号  
		$Gadget.data = $Gadget.data || {};
		$Gadget.data.blankCardSN = blankCardSN;
		// 判断是否为预置空卡  
		writeLocalFile($Page, "判断是否为预置空卡:" + blankCardSN);
		$Fire({
			service : '/readblankcardboservice/ispresetblankcard',
			params : {
				blankCardNo : blankCardSN
			},
			target : "$Gadget.preSetBlankCardInfo",
			onafter : function() {
				debugger;
				if(!$Gadget.preSetBlankCardInfo){
					$Gadget.isNewReadCardFlag = false;
					writeLocalFile($Page, "校验预置空卡失败，请重新读卡。");
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "校验预置空卡失败，请重新读卡。");
					return false;
				}else if(!$Gadget.preSetBlankCardInfo.isPresetCard){
					$Gadget.isNewReadCardFlag = false;
					writeLocalFile($Page, "此卡不是预置空卡，请重新插入一张预置空卡。");
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "此卡不是预置空卡，请重新插入一张预置空卡。");
					return false;
				}else{
					$Controller.bes.ad.supplycardex.analyzeBlankCardInfo($Gadget, $Fire, $UI, $Page);
				}
			}
		}, $Gadget);

	},
	
	/**
	 * 解析读卡结果
	 */
	analyzeBlankCardInfo : function($Gadget, $Fire, $UI, $Page){

		debugger;
		writeLocalFile($Page, "解析读卡结果...");
		var getPreSetCardInfoResult = OPSGetCardInfo();
		var preSetCardInfo = analyzeReadCardInfo(getPreSetCardInfoResult, "获取卡片信息错误！",$UI);
		if("" == preSetCardInfo)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "获取卡片信息错误！");
			return false;
		}

		var arr = preSetCardInfo.split("0E");// 0E为卡号tag  
		if(!arr || arr.length != 2)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "读取卡片信息错误。" + preSetCardInfo);
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "读取卡片信息错误。");
		    return false;	
		}
		
		var arr1 = arr[0].split("08");// 08为ICCID tag   
		if(!arr1)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "读取卡片信息错误。arr[0]:" + arr[0]);
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "读取卡片信息错误。");//读取卡片信息错误！
		    return false;	
		}
		// 去除split后的空串   
		for(var i=arr1.length-1; i>=0; i--)
		{
		    if(!arr1[i] || null == arr1[i] || "" == arr1[i])
		    {
		        arr1.splice(i,1);
		    }
		}
		
		// 判断卡ICCID数据是否满足单号卡或者一卡N号卡的要求  
		if(arr1.length != 1)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "此卡不是单号卡，请重新插入一张预置空卡。arr1.length:" + arr1.length);
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "此卡不是单号卡，请重新插入一张预置空卡。");//此卡不是单号卡，请重新插入一张预置空卡
		    return false;
		}
		
		// 以下目前先支持单号卡  
		// 卡片iccid信息tlv格式，tag部分split时去掉了，还剩下LV部分   
		var iccidInfo = arr1[0];
		if(iccidInfo.length < 2)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "读取卡片信息错误。arr1[0]:" + arr1[0]);
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "读取卡片信息错误。");//读取卡片信息错误
		    return false;
		}
		
		// iccid串长度，将string转成int   
		var iccidLen = parseInt(iccidInfo.substring(0,2), 16);
		var iccid = iccidInfo.substring(2);
		if(iccid.length != iccidLen*2)
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "读取卡片信息错误。iccid.length:" + iccid.length + " iccidLen*2:" + iccidLen *2);
		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "读取卡片信息错误。");//读取卡片信息错误
		    return false;
		}
		
		if(iccid != 'FFFFFFFFFFFFFFFFFFFF')
		{
			$Gadget.isNewReadCardFlag = false;
			writeLocalFile($Page, "非空卡,请插入一张空白卡。iccid:" + iccid);
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "非空卡,请插入一张空白卡。");//非空卡,请插入一张空白卡
			return false;
		}
		
		
		$Gadget.data.SimInfoPojo = {};
		if ($Gadget.data.blankCardSN) {
			$("#simcardItemId").val($Gadget.data.blankCardSN);
		}
		
		var writeCardDataObj = {
			cardSN : $Gadget.data.blankCardSN,
			isPresetCard : '1'
		};
		writeCardDataObj.blankCardSn = $Gadget.data.blankCardSN;
	    $Page.blankCardInfo = {
            serviceNumber: $Controller.bes.ad.supplycardex.getRelserviceNum($Gadget), //$Gadget.data.oldNumber,//老的号码
	    		writeCardData : writeCardDataObj,
	    		businessCode  : '补卡',
	    		userName 	  : ''//TODO：用户名哪里取？
	    };
	    
	    $Controller.bes.ad.supplycardex.validateBlankCard($Gadget, $Fire, $UI, $Page);
	},
	
	//校验空白卡
	validateBlankCard : function($Gadget, $Fire, $UI, $Page){
		debugger;
		var blankCardSN = $Gadget.data.blankCardSN;
		$Gadget.preSetBlankCardInfo = $Gadget.preSetBlankCardInfo || {};
		var cardItemTypeId = $Gadget.preSetBlankCardInfo.itemTypeId;
		// 校验预置空卡  查询卡类型、校验是否可用  
		writeLocalFile($Page, "校验预置空卡  查询卡类型、校验是否可用.blankCardSN:" + blankCardSN + " cardItemTypeId:" + cardItemTypeId);
		$Fire({
			service : '/writeblankcardboservice/presetblankvalidate',
			params : {
				blankCardNo : blankCardSN,
				itemTypeId : cardItemTypeId
			},
			target : "$Gadget.preSetBlankValidate",
			onafter : function() {
				debugger;
				$Gadget.preSetBlankValidate = $Gadget.preSetBlankValidate || {};
				//校验失败
				if(!$Gadget.preSetBlankValidate){
					$Gadget.isNewReadCardFlag = false;
					writeLocalFile($Page, "空白卡校验失败，请重新读卡。");
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "空白卡校验失败，请重新读卡。");
					return false;
				}
				if($Gadget.preSetBlankValidate.retCode && $Gadget.preSetBlankValidate.retCode != '0'){
					$Gadget.isNewReadCardFlag = false;
					writeLocalFile($Page, "空白卡校验失败，请重新读卡。");
					if($Gadget.preSetBlankValidate.errorMsg){
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $Gadget.preSetBlankValidate.errorMsg);
						return false;
					}else{
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "空白卡校验失败，请重新读卡。");
						return false;
					}
				}
				
				debugger;
				//判断空白卡与用户品牌是否匹配
				$Controller.bes.ad.supplycardex.isBlankCardMatchBrand($Gadget, $Fire, $UI, $Page);
			},
			"onerror" : function() {
				debugger;
				$Gadget.isNewReadCardFlag = false;
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "空白卡校验失败，请重新读卡。");
				return false;
			}
		}, $Gadget);
		
	},
	
	//查询空白卡与产品品牌是否匹配
	isBlankCardMatchBrand : function($Gadget, $Fire, $UI, $Page){

		debugger;
		$Page = $Gadget.$Page;
		var offeringId = null;
		
		var input = {
			offeringId : $Gadget.data.cardInfo.offeringId,
			menuId : $Page.menuId
		};
		writeLocalFile($Page, "查询空白卡与产品品牌是否匹配.");
		$Fire(
				{
					'service' : 'bes.oc.choosesimservice/querysimcardtypelistbyofferingid',
					'params' : {
						"input" : input
					},
					'target' : "$Gadget.data.simTypeList",
					'onafter' : function() {
						debugger;
						if ($Gadget.data.simTypeList) {
							
							var isMatch = false;
							var blankCardSkuCode = $Gadget.preSetBlankValidate.blankCardInfoPOJO.skuCode;
							$.each($Gadget.data.simTypeList, function(i,val){
								if(blankCardSkuCode == val.skuCode){
									//空白卡在可用列表中
									isMatch = true;
								}
							});
							if(!isMatch){
								$Gadget.isNewReadCardFlag = false;
								$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "此空白卡类型与产品品牌不匹配，请重新读卡。");
								return false;
							}
							//根据空白卡号查询IMSI 
							$Controller.bes.ad.supplycardex.queryAndLockIMSIbyBlankCardNO($Gadget, $Fire, $UI, $Page);
						}
					},
					"onerror" : function() {
						debugger;
						$Gadget.isNewReadCardFlag = false;
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "查询空白卡类型对应产品品牌时异常，请重新读卡。");
						return false;
					}
				}, $Gadget);
	},
	
	//查询IMSI
	queryAndLockIMSIbyBlankCardNO : function($Gadget, $Fire, $UI, $Page){
		debugger;
		var inputParam ={
						telNumItemTypeId : null,
            telNum: $Controller.bes.ad.supplycardex.getRelserviceNum($Gadget), //$Gadget.data.oldNumber,
						imsiSkuCode : $Gadget.imsiSkuCode,
						simTag : "blank_sim_data",//暂时写死，等INV确认 20160616
						netTypeKey : "1000006022",//INV 提供的，后续可能会变 20160617
						netType : $Gadget.preSetBlankValidate.blankCardInfoPOJO.netType
					};
		writeLocalFile($Page, "查询IMSI.imsiSkuCode:" + $Gadget.imsiSkuCode
				+ " telNum:" + inputParam.telNum);
		debugger;
		$Fire({
			service : '/writeblankcardboservice/queryandlockblankimsi',
			params : {
				input : inputParam
			},
			target : "$Gadget.data.IMSIInfo",
			onafter : function() {
				debugger;
				
				if($Gadget.data.IMSIInfo){
					if($Gadget.data.IMSIInfo.lockId){
						$Page.IMSIInfo = $Gadget.data.IMSIInfo;//作废空白卡时用。
						//查询SIM卡信息1
						$Controller.bes.ad.supplycardex.querySimByIMSI($Gadget, $Fire, $UI, $Page);
					}else{
						$Gadget.isNewReadCardFlag = false;
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "IMSI资源预占失败，请重新选择");
						return false;
					}
				}else{
					$Gadget.isNewReadCardFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "查询IMSI信息失败，请重新读卡。");
					return false;
				}
			},
			"onerror" : function() {
				debugger;
				$Gadget.isNewReadCardFlag = false;
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "查询IMSI信息失败，请重新读卡。");
				return false;
			}
		}, $Gadget);
		
	},
	
	// 针对$Gadget.data.oldNumber加密的情况，获取未加密的 serviceNumber
	getRelserviceNum: function($Gadget){
		if($Gadget.data.oldNumber.indexOf("*") == -1){
			return $Gadget.data.oldNumber;
		}
		else{
			return $Gadget.data.info.srcNumber;
		}
	},
	
	//查询SIM卡信息1
	querySimByIMSI : function($Gadget, $Fire, $UI, $Page){
		debugger;
		writeLocalFile($Page, "查询SIM卡信息1.$Gadget.data.IMSIInfo.iccid:" + $Gadget.data.IMSIInfo.iccid);
		if ($Gadget.data.IMSIInfo.iccid) {
			$Fire({
				service:'bes.oc.ocsupplyservice/querysimcardinfobyiccid',
				params : {
					itemid : $Gadget.data.IMSIInfo.iccid
				},
				target: '$Gadget.data.newCardInfo',
				onafter: function() {
					debugger;
					if($Gadget.data.newCardInfo)
					{
						writeLocalFile($Page, "查询SIM卡信息1结果.$Gadget.data.newCardInfo.itemId，即imsi:" + $Gadget.data.newCardInfo.itemId);
						//查询SIM卡信息2
						$Controller.bes.ad.supplycardex.querySimCardInfo($Gadget, $Fire, $UI, $Page);
					}
					else{
						$Gadget.isNewReadCardFlag = false;
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "未查到SIM卡信息。");
						return false;
					}
				},
				"onerror" : function() {
					debugger;
					$Gadget.isNewReadCardFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "查询SIM卡信息失败，请重新读卡。");
					return false;
				}
			}, $Gadget);
		}
	},
	
	//查询SIM卡信息2
	querySimCardInfo: function($Gadget, $Fire, $UI, $Page) {
		debugger;
		writeLocalFile($Page, "查询SIM卡信息2.$Gadget.data.IMSIInfo.skuCode:" + $Gadget.data.IMSIInfo.skuCode);
		if ($Gadget.data.IMSIInfo.skuCode) {
			$Fire({
				service:'/writeblankcardboservice/querysiminfobyskucode',
				params:{
					"skuCode": $Gadget.data.IMSIInfo.skuCode
				},
				target: '$Gadget.data.SimInfoPojo',
				onafter: function() {
					debugger;
					if ($Gadget.data.SimInfoPojo) 
					{
						//订单组装用
						$Gadget.data.SimInfoPojo.itemTypeId = $Gadget.data.IMSIInfo.itemTypeId;
						$Gadget.data.SimInfoPojo.iccidValue = $Gadget.data.IMSIInfo.iccid;
						$Gadget.data.SimInfoPojo.itemId = $Gadget.data.IMSIInfo.imsi;
						$Gadget.data.cardNo = $Gadget.data.IMSIInfo.iccid;
						writeLocalFile($Page, "查询SIM卡信息2.$Gadget.data.SimInfoPojo itemTypeId:" + $Gadget.data.IMSIInfo.itemTypeId
								+ " iccidValue:"+$Gadget.data.IMSIInfo.iccid
								+ " itemId:"+$Gadget.data.IMSIInfo.imsi
								+ " cardNo:"+$Gadget.data.IMSIInfo.iccid);
						//锁定资源后进行 加密
						$Controller.bes.ad.supplycardex.encryptBlankCardData($Gadget, $Fire, $UI, $Page);
					}else{	
						$Gadget.isNewReadCardFlag = false;
						//未查到SIM卡详情
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SIMInfoNotFound"));
						return false;
					}
				},
				onerror: function(){
					$Gadget.isNewReadCardFlag = false;
					//查询SIM卡详情失败。
				    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SearchSIMInfoFail"));
				    return false;
				}
			}, $Gadget);
		} else {
			$Gadget.data.SimInfoPojo = null;
		}
	},
	
	/*
	 * 写卡数据加密
	 */
	encryptBlankCardData : function($Gadget, $Fire, $UI, $Page){
	    debugger;
	    //获取唯一流水号
	    $Fire({
			service:'/bes.oc.occustomerservice/generateseqacctid',
			target: '$Gadget.data.writeCardSeqNumber',
			onafter: function() {
				debugger;
				$Gadget.writeCardSeqNumber = adutil.getNextNumber();
				if($Gadget.data.writeCardSeqNumber){
					var seqLength = $Gadget.data.writeCardSeqNumber.length;
					if(seqLength > 10){
						$Gadget.writeCardSeqNumber = $Gadget.data.writeCardSeqNumber.substring(seqLength-10,seqLength);
					}
				}
				
				 //组装入参
				var reqParam = {
			    	seqNo : $Gadget.writeCardSeqNumber,
			    	imsi : $Gadget.data.IMSIInfo.imsi,
			    	iccid :　$Gadget.data.IMSIInfo.iccid,
			    	pin1 : $Gadget.data.IMSIInfo.pin1,
			    	pin2 : $Gadget.data.IMSIInfo.pin2,
			    	puk1 : $Gadget.data.IMSIInfo.puk1,
			    	puk2 : $Gadget.data.IMSIInfo.puk2,
			    	cardSn : $Gadget.data.blankCardSN,
                    msisdn: $Controller.bes.ad.supplycardex.getRelserviceNum($Gadget), //$Gadget.data.oldNumber,
			    	smsp : $Gadget.data.IMSIInfo.smsp,  //该字段需要IVN增加接口返回字段，IVN接口定义中已增加  吴骏华
			    	channelFlag : '2'  //受理渠道，跟SE确认，营业厅网厅编码为2
			    };
				
				//个性化数据加密
				$Fire({
					service : '/writeblankcardboservice/encryptblankcardinfo',
					params : {
						input : reqParam
					},
					target : "$Gadget.data.encryptData",
					onafter : function() {
						debugger;
						
						if($Gadget.data.encryptData && $Gadget.data.encryptData.restCode == '0'){
							$Gadget.data.issueData = $Gadget.data.encryptData.issueData;
							if($Page.blankCardInfo && $Page.blankCardInfo.writeCardData){
								$Page.blankCardInfo.writeCardData.issueData = $Gadget.data.issueData;
								$Page.blankCardInfo.writeCardData.seqNo = $Gadget.writeCardSeqNumber;
								$Page.blankCardInfo.writeCardData.iccid = $Gadget.data.IMSIInfo.iccid;
								$Page.blankCardInfo.writeCardData.blankCardType = $Gadget.data.newCardInfo.typeName;
								//订单组装用
								$Page.blankCardNo=$Gadget.data.blankCardSN;
								
								writeLocalFile($Page, "个性化数据加密. issueData:"+$Gadget.data.issueData
										+" seqNo:"+$Gadget.writeCardSeqNumber
										+" iccid:"+$Gadget.data.IMSIInfo.iccid
										+" blankCardType:"+$Gadget.data.newCardInfo.typeName
										+" blankCardNo:"+$Gadget.data.blankCardSN);
							}
							$Gadget.isNewReadCardFlag = false;
							$Gadget.simcardReadFlag = true;
							//校验成功后加载补卡原因
							$Controller.bes.oc.supplycard.getFreeSupplyUserInfo($Gadget,$Gadget.$Get('$Fire'));
						}else{
							$Gadget.isNewReadCardFlag = false;
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "个性化数据加密失败，请重新读卡。");
							$Controller.bes.ad.supplycardex.cleardata($Gadget);
							return false;
						}
						
					},
					"onerror" : function() {
						debugger;
						$Gadget.isNewReadCardFlag = false;
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "个性化数据加密失败，请重新读卡。");
						return false;
					}
				}, $Gadget);
			},
			onerror: function(){
				$Gadget.isNewReadCardFlag = false;
				//生成流水号失败。
			    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "生成写卡流水号失败，请重新读卡。");
			    return false;
			}
		}, $Gadget);
	    
	}
});


/************************************************
 * 控件接口调用工具方法
 ***********************************************/
//判断是否安装OCX及DLL版本是否最新  
function judgeNewOCX($UI)
{
  if(connectNewOCX($UI))
  {
		// 判断服务器端通过系统参数保存的dll版本号和客户端的dll版本号是否一致  	      
		var getVersionResult = OPSGetVersion();
		var versionAnalyzeResult = analyzeReadCardInfo(getVersionResult, "获取控件版本号失败！");
		if("" == versionAnalyzeResult)
		{
			return false;
		}

//		if(versionAnalyzeResult != newWriteCardDllVersion)
//		{
//		    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "您目前使用的终端中没有包含读写此类型卡的组件或组件版本不新\n请点击“确定”后保存到" + dllParentDirPath + "目录下。");
//			var url = commonDownLoadAddr + "?fileName=" + dllName;
//			openTopWin(url, "_blank");						
//			return false;
//		}

		return true;
  }
}

//判断是否有OCX控件  
function connectNewOCX($UI)
{		    
	debugger;
	if(!readCardObj){
		readCardObj = document.getElementById('NewWriteCardOcx');
	}
	return true;
//	var fso = new ActiveXObject('Scripting.FileSystemObject');
//	var dir = fso.GetSpecialFolder(1);
//	var isExist = fso.FileExists(dir.Path + "\\" + newWriteCardOcxName);
//	if(isExist)
//	{
//	    return isExist;
//	}
//	else
//	{
//		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "您没有安装新预置空卡读写卡控件，请先进行安装注册。");
//	    return false;
//	}            
}



//根据错误码获取错误信息  
function OPSGetErrorMsg(errorCode, showErrMsg,$UI)
{
	
	var errMsg = errorCode;
	if("" == errMsg)
	{
		errMsg = showErrMsg;
	}
	$UI.msgbox.info($UEE.i18n("ad.person.message.information"), errMsg);
}

//公共函数 ：解析读卡控件返回信息  
function analyzeReadCardInfo(readCardResult, showErrMsg,$UI)
{	
	var readCardResultArr = readCardResult.split(splitChar);
		if(!readCardResultArr || readCardResultArr.length != 2)
	{
	    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), "读取卡片信息错误。");
	    return "";	
	}
	
	if(readCardResultArr[resultCodeIndex] != successCode)
	{
		// 显示错误码对应的错误信息  
		OPSGetErrorMsg(readCardResultArr[errCodeIndex], showErrMsg,$UI);	
	 	return "";
	}
	
	// 返回结果信息  
	return readCardResultArr[resultInfoIndex];
}
var isDebug = !ysp._globalInfo || ysp._globalInfo && ysp._globalInfo.device == "studio";
var isIOS = ysp.appMain.isIOS();
//获取版本号  
function OPSGetVersion()
{
	return '0&Ver1.1.0';
}

//设置读卡器  
function OPSConfigReader()
{
	if(isDebug){
		return '0&Identiv SCR35xx USB Smart Card Reader 0';
	}else{
		return isIOS?top.yspUser.Ysp_OPSConfigReader():window.yspCheckIn.Ysp_OPSConfigReader();
	}
}      

//获取空白卡序列号  
function OPSGetCardSN()
{
	if(isDebug){
		return '0&291700A6080071342112';
	}else{
		return isIOS?top.yspUser.Ysp_OPSGetCardSN():window.yspCheckIn.Ysp_OPSGetCardSN();
	}
}

//获取卡片信息  
function OPSGetCardInfo()
{
	if(isDebug){
		return '0&080AFFFFFFFFFFFFFFFFFFFF0E0A291700A6080071342112';
	}else{
		return isIOS?top.yspUser.Ysp_OPSGetCardInfo():window.yspCheckIn.Ysp_OPSGetCardInfo();
	}
}


//记录读写卡本地文件 c00311908
function writeLocalFile($Page,content)
{
	debugger;
	// 关闭系统参数writeLocalFile  不写本地日志
	if ($Page.writeLocalFile != "Y")
	{
		return ;
	}
	
	try
	{
		var fso = new ActiveXObject('Scripting.FileSystemObject');
		var tmpPath = "C:\\tmp\\";
		if (!fso.FolderExists(tmpPath))
		{
			fso.CreateFolder(tmpPath);
		}
		
		var tmpFile = "C:\\tmp\\writecardlog.txt";
		var file = null;
		// 1. 文件的绝对路径 
		// 2. 文件的常数 只读=1，只写=2 ，追加=8 等权限。（ForReading 、 ForWriting 或 ForAppending 。）； 
		// 3. 一个布尔值 允许新建则为true 相反为false； 
		file = fso.OpenTextFile(tmpFile, 8, true);
		
		// 在内容前边加上个日期时间
		var myDate = new Date();
		var time = myDate.toLocaleDateString() + " " 
			+ myDate.toLocaleTimeString() + "==>";
		
		file.WriteLine(time + content);
		file.Close();		
	}
	catch(e)
	{
		// 记失败了能咋滴
	}
}
