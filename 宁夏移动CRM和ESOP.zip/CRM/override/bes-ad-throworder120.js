$Controller(
    "bes.ad.throworder", {
        init: function($Gadget, $Page) {
            debugger;
			$Page.displayPic = [{attrCode:"Pic1",newValue:null,uploadResult:false,index:1},
								{attrCode:"Pic2",newValue:null,uploadResult:false,index:2},
								{attrCode:"Pic3",newValue:null,uploadResult:false,index:3}];
			$Page.timestamp = "";
        },
		
        // 备注信息校验-----
        checkRemark: function($Page, $Gadget, $UI) {
            debugger;
            $Gadget.remark = $.trim($("#suspendOrResumeRemarkId").val());
            $Page.remark = $Gadget.remark;
            var len = $Gadget.remark.len();

            //增加非空校验 230437
            if ($Page.essentialRemarkInfo && 0 == len) {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterRemarks"));
                return false;
            }

            // 1.检查安全性
            if (!adutil.checkInputdata($Gadget.remark)) {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.hasInvalidCharacters"));
                return false;
            }
            // 2.检查长度
            if (len > 300) {
                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.InputTooLong"));
                return false;
            }
            return true;

        },
		
        addFilePath : function($Gadget,$Item,file,$UI,$Page){
    		debugger;   		
    		// 校验文件的类型
    		if(!$Controller.bes.ad.throworder.previewImage(file,$UI,$Gadget,$Page))
    		{
    			return false;
    		}
    		
    		var file_up = $("#personalUpload_"+$Item.attrCode);
    		
    		var fileName = file.value || "";
    		if(fileName == null || fileName === ""){
    			file_up.val(fileName);
    			file_up.attr("title",fileName);
    			return;
    		}
   		
    		file_up.val(fileName);
    		file_up.attr("title",fileName);
    		$Item.newValue = fileName;
    		
    		//IE浏览器下显示上传文件的真实路径
    		if (file_up && window.navigator.userAgent.indexOf("MSIE")>=1){
    			file_up.select();
    			var realpath = document.selection.createRange().text;			
    			file_up.val(realpath);
    			file_up.attr("title",realpath);
    		}
    					
    		return true;	
    	},
    	
    	// 点击上传后真正上传
    	uploadBefore : function($Gadget,$UI,$Page,$Item) {
    		debugger;
    		var textVal = $("#personalUpload_" + $Item.attrCode).val();
    		if(!textVal) {
    			$UI.msgbox.info($UEE.i18n("ad.group.message.promot"),$UEE.i18n("ad.group.tips.selectFilefirst"));
    			return false;
    		}
    		$Item.uploadFlag = true;
    		
    		$Page.file || ($Page.file = {});
    		$Page.$Meta || ($Page.$Meta= {});
    		$Page.$Meta.$File || ($Page.$Meta.$File = {});
    		$Page.$Meta.$File["$Page.file"] = ["realeUpload_"+$Item.attrCode];
    	    try {
    	    	OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
    	    	// 查询当前系统时间
    		    $Gadget.$Get("$Fire")({
    				service : "bes.oc.subscribeinfoservice/getadservercurtime",
    				target : "$Gadget.adServerCurTime",
    				onafter : function() {
    					debugger;
    					if (null == $Gadget.adServerCurTime) {
    						$Gadget.adServerCurTime = new Date();
    					} else {
    						$Gadget.adServerCurTime = new Date($Gadget.adServerCurTime);
    					}
    					
    					//获取文件名称
    					var fileName = "";
    					//统一图片时间戳
    					if(!$.trim($Page.timestamp)){   						
        					$Page.timestamp = new Date($Gadget.adServerCurTime).Format("yyyyMMddHHmmss");
    					}
    					
						//上传的文件并且强制重命名为：yyyyMMddHHmmss+手机号码+序号.文件后缀
    					fileName = $Page.timestamp+$Page.phonenum+$Item.index;
    					
    					//获取文件后缀
    					var extention = textVal.substring(textVal.lastIndexOf(".")+1).toLowerCase();
    					var fileName = fileName + "." + extention; 
    					
    			        // 上传到FTP
    			        $Gadget.$Get("$Fire")({
    			            service: '/bes.oc.productchange/uploadftpfile',
    			            params: {
    			                fileName: fileName
    			            },
    			            region: '$Page.file',
    			            target: '$Gadget.$data.result',
    			            onafter: function() {
    			                debugger;
    			                $Controller.bes.ad.throworder.uploadResult($Gadget,$Page,$UI,$Item);
    			            },
    			            onerror: function() {
    			                debugger;
    			                $Controller.bes.ad.throworder.uploadResult($Gadget,$Page,$UI,$Item);
    			            }
    			        }, $Gadget);
    					
    				}
    			}, $Gadget);
    	    }
    	    catch (e){
    	    	$UI.msgbox.info($UEE.i18n("ad.group.message.promot"),$UEE.i18n("ad.group.message.uploadFall"));
    	    }
    		return false;
    	},
    	
    	// 校验文件的类型
    	previewImage:function(file,$UI,$Gadget,$Page)
    	{
    		debugger;
    		var allowExtention=".jpg,.bmp,.gif,.png";//允许上传文件的后缀名
    		var extention=file.value.substring(file.value.lastIndexOf(".")+1).toLowerCase();
    		if(!(allowExtention.indexOf(extention)>-1))
    		{
    			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.imageTypeNotSupported"));
    			$Gadget.fileType = false;
    			return false;
    		}

    		$Gadget.fileType = true;
    	  	return true;

    	},
    	//上传之后的结果处理
    	uploadResult : function($Gadget,$Page,$UI,$Item) {
    		debugger;
    		$Gadget.$data = $Gadget.$data || {};
    		if(!$Gadget.$data.result) {
    			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.systemError"));
    			return false;
    		}
    		   		
    		// 上传失败的原因
    		if($Gadget.$data.result.uploadResult == 'false') {
    			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$Gadget.$data.result.failedReason);
    			return false;
    		}
    		else {
    			// 上传成功
    			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.uploadedSuccessfully"));
    			$Item.fileName = $Gadget.$data.result.fileName;
    			$Item.uploadResult = $Gadget.$data.result.uploadResult;
    			$("#btn_uploadcert_click_"+$Item.attrCode).addClass("disabled"); 				
    		}
    	}

    });