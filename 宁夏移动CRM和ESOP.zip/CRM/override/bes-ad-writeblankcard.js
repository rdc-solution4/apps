var writeCardObject = document.getElementById('NewWriteCardOcx');
	
// 读卡器返回信息分隔符，方便统一处理  
var splitChar = "&";
// 控件函数结果码索引，方便统一处理  
var resultCodeIndex = 0;
// 控件函数结果信息索引  
var resultInfoIndex = 1;
// 函数错误码位置索引 ，湖北和其他省相同  
var errCodeIndex = 1;
// 控件函数结果码，正确码  
var successCode = "0";

$Controller("bes.ad.writeblankcard",{
	
	init : function($Gadget,$Page){
		debugger;
		$Gadget.writeCardObj = $Page.blankCardInfo.writeCardData;
		$Gadget.servicenumber = $Page.blankCardInfo.servicenumber;
		$Gadget.writeCardSuccess = false;
		$Page.createOrderWithBlankCard = 'false';
		
	},
	
	writeoperator : function($Gadget,$Page,$Fire,$UI){
		debugger;
		if("" == $Gadget.writeCardObj){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "写卡数据报文错误。");//写卡数据报文错误
			return false;
		}
		$Controller.bes.ad.writeblankcard.doWriteCard($Gadget,$Page,$Fire,$UI);
	},
	
	writeCardpopin : function($Gadget){
		debugger;
		if($Page.blankCardInfo){
			$Page.blankCardInfo = ""; //置空,点击弹出窗口右上角的x时
		}
		if($Gadget.writeCardSuccess){
			$Page.createOrderWithBlankCard = 'true';
			$Gadget.$Emit("$bes.ad.gotoCreateOrder");
		}else{
			$Page.createOrderWithBlankCard = 'false';
		}
		$Gadget.$Get('$Fire')({
			popin : ""
		});
	},
	
	/**
	 * 写卡操作
	 */
	doWriteCard : function($Gadget,$Page,$Fire,$UI){	
		debugger;
		// 预置空卡写卡数据加密报文  
		var preSetBlankCardData = $Gadget.writeCardObj.issueData;
		writeLocalFile($Page,"开始写卡！preSetBlankCardData:"+preSetBlankCardData);
		
		//写卡
		var writeCardResult = OPSWriteCard(preSetBlankCardData);
		var writeCardInfo = analyzeReadCardInfo(writeCardResult, "写卡失败",$UI);
		writeLocalFile($Page,"写卡返回报文 ！writeCardInfo:"+writeCardInfo);
		if("" == writeCardInfo)
		{
			var writeCardResultArr = writeCardResult.split(splitChar);
			if(writeCardResultArr && writeCardResultArr.length == 2)
			{
				// 写卡错误代码  
			    var errorCode = writeCardResultArr[resultCodeIndex];	
				//TODO
				// 调用空白卡作废处理逻辑，如果错误码类型为1，则作废空白卡  
				//$("#writeCardCommonDiv").trigger({type:'wrtNewBlankCardFailSD' , errorCode:'' + errorCode, blankCardNum:'' + SIMSerialCommon});
			}
			return false;
		}
		$Gadget.writeCardResp = writeCardInfo;
		$Controller.bes.ad.writeblankcard.validateWriteCardResult($Gadget,$Page,$Fire,$UI);
	},
	
	/**
	 * 写卡报文回传与校验
	 */
	validateWriteCardResult : function($Gadget,$Page,$Fire,$UI){
		debugger;
		var validateInput={
				seqNo : $Gadget.writeCardObj.seqNo,
				cardSn : $Gadget.writeCardObj.cardSN,
				iccid : $Gadget.writeCardObj.iccid,
				cardRsp : $Gadget.writeCardResp
		}
		writeLocalFile($Page,"写卡报文校验 ！seqNo:"+$Gadget.writeCardObj.seqNo
				+" cardSn:"+$Gadget.writeCardObj.cardSN
				+" iccid:"+$Gadget.writeCardObj.iccid
				+" cardRsp:"+$Gadget.writeCardResp);
		// 写卡结果回传校验  
		$Fire({
			service : '/writeblankcardboservice/validatewritecardstatus',
			params : {
				input : validateInput
			},
			target : "$Gadget.validateResult",
			onafter : function() {
				debugger;
				//校验成功，则继续提交订单
				if($Gadget.validateResult && $Gadget.validateResult.resultCode == '0'){
					//应该不需要这里的提示了，页面上的提示足够了。
					//$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "写卡成功。")
					
					$Gadget.writeCardSuccess = true;
				}else
				{
					// 调用inv空白卡作废接口
					$Controller.bes.ad.writeblankcard.revokeBlankCard($Gadget,$Page,$Fire,$UI);
					return false;
				}		
			}
		}, $Gadget);
		
	},
	//校验失败，调用inv接口作废卡
	revokeBlankCard : function($Gadget,$Page,$Fire,$UI){
		debugger;
		var params = {
			regionId : $Page.IMSIInfo.regionId,
			ouId : $Page.IMSIInfo.ouId,
			blankCardNo : $Page.blankCardInfo.writeCardData.blankCardSn,
			wrCardOId : $Page.blankCardInfo.writeCardData.seqNo,
			wrCardRegion : 100,
			iccid : $Page.IMSIInfo.iccid,
			imsi : $Page.IMSIInfo.imsi,
			imsiItemIypeId : $Page.IMSIInfo.itemTypeId,
			imsiSec : null,
			isWrCardSuccess : false
		};
		
		// 调用接口
		$Fire({
			service : '/writeblankcardboservice/revokeblankcard',
			params : {
				input : params
			},
			target : "$Gadget.data.revokeBlankCardResp",
			onafter : function() {
				debugger;
				if($Gadget.data.revokeBlankCardResp && $Gadget.data.revokeBlankCardResp.resultCode == '0'){
					//作废成功
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "写卡结果报文验证失败,空白卡作废成功，请重新读卡后再写卡。")
				}else
				{
					//作废失败
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "写卡失败，请重新读卡后再写卡。")
					return false;
				}		
			}
		}, $Gadget);
	}
});

/*********************************************************
 * 控件接口调用工具方法
 * *******************************************************/	
var isDebug = !ysp._globalInfo || ysp._globalInfo && ysp._globalInfo.device == "studio";
var isIOS = ysp.appMain.isIOS();
// 获取空白卡序列号  
function OPSGetCardSN()
{
	if(isDebug){
		return '0&291700A6080071342112';
	}else{
		return isIOS?top.yspUser.Ysp_OPSGetCardSN():window.yspCheckIn.Ysp_OPSGetCardSN();
	}
}

// 写卡  
function OPSWriteCard(issueData)
{	
	if(isDebug){
		return '0&301D4364FB';
	}else{
		return isIOS?top.yspUser.Ysp_OPSWriteCard(issueData):window.yspCheckIn.Ysp_OPSWriteCard(issueData);
	}
}

// 公共函数 ：解析读卡控件返回信息  
function analyzeReadCardInfo(readCardResult, showErrMsg,$UI)
{	
	var readCardResultArr = readCardResult.split(splitChar);
	if(!readCardResultArr || readCardResultArr.length != 2)
	{
		$UI.msgbox.info($UEE.i18n("ad.person.message.information"), "读取卡片信息错误。");
	    return "";	
	}
	
	if(readCardResultArr[resultCodeIndex] != successCode)
	{
		// 显示错误码对应的错误信息  
		OPSGetErrorMsg(readCardResultArr[errCodeIndex], showErrMsg,$UI);	
	 	return "";
	}
	
	// 返回结果信息  
	return readCardResultArr[resultInfoIndex];
}

// 根据错误码获取错误信息  
function OPSGetErrorMsg(errorCode, showErrMsg,$UI)
{
	var errMsg = errorCode;
	if("" == errMsg)
	{
		errMsg = showErrMsg;
	}
	$UI.msgbox.info($UEE.i18n("ad.person.message.information"), errMsg);
}

//记录读写卡本地文件 c00311908
function writeLocalFile($Page,content)
{
	debugger;
	// 关闭系统参数writeLocalFile  不写本地日志
	if ($Page.writeLocalFile != "Y")
	{
		return ;
	}
	
	try
	{
		var fso = new ActiveXObject('Scripting.FileSystemObject');
		var tmpPath = "C:\\tmp\\";
		if (!fso.FolderExists(tmpPath))
		{
			fso.CreateFolder(tmpPath);
		}
		
		var tmpFile = "C:\\tmp\\writecardlog.txt";
		var file = null;
		// 1. 文件的绝对路径 
		// 2. 文件的常数 只读=1，只写=2 ，追加=8 等权限。（ForReading 、 ForWriting 或 ForAppending 。）； 
		// 3. 一个布尔值 允许新建则为true 相反为false； 
		file = fso.OpenTextFile(tmpFile, 8, true);
		
		// 在内容前边加上个日期时间
		var myDate = new Date();
		var time = myDate.toLocaleDateString() + " " 
			+ myDate.toLocaleTimeString() + "==>";
		
		file.WriteLine(time + content);
		file.Close();		
	}
	catch(e)
	{
		// 记失败了能咋滴
	}
}

