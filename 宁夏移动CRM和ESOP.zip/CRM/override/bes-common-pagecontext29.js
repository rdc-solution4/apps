(function(){
  $Controller("bes.common.pagecontext", {

    $Gadget : null,

    init : function($Gadget)
    {
      if (this.$Gadget)
      {
          return;
      }

      this.$Gadget = $Gadget;
      $Gadget.$root.$BesContext = $Gadget;
      $Gadget.$IsLoaded = false;
      $Gadget.$Emit("$bes.context.load");
    },

    put : function(key, value, onsuccess)
    {
      if(this.isValueChanged(key, value))
      {
        this.syncToServer(key, value, onsuccess);
      }
    },

    syncToServer : function(key, value, onsuccess)
    {
      if(!key)
      {
          return;
      }

      var me = this;
      var handler = me.$Gadget.$Data.data[key];

      if (!handler)
      {
        handler = { key : key, readOnly : false };
        me.$Gadget.$Data.data[key] = handler;
      }

      if(!handler.queue)
      {
        handler.queue = [];
        handler.queue.count = 0;
        handler.doo = function()
        {
          if(handler.queue.length == 0)
          {
            return;
          }

          var data = handler.queue[0];
          if(!data)
          {
            return;
          }

          me.sync(data, handler);
        };
      }

      handler.queue.count += 1;
      handler.queue.push( {index : handler.queue.count, key : key, value : value, onsuccess : onsuccess} );
      if(handler.queue.length == 1)
      {
        handler.doo();
      }
    },

    sync : function(data, handler)
    {
      var key= data.key, value = data.value, onsuccess = data.onsuccess;
      $ChangedValue = {
            key : key,
            value : angular.isObject(value) ? angular.toJson(value) : value
      };

      var fire = this.$Gadget.$Get('$Fire');

      fire({
            service : 'PageContextService/put',
            params : { key : $ChangedValue.key, value : $ChangedValue.value },
            onafter : function() {
              handler.value = value;
              if (onsuccess)
              {
                  onsuccess(key, value);
              }
              handler.queue.shift();
              handler.doo();
            }
        }, this.$Gadget);
    },

    loaded : function()
    {
      var me = this;
      var $Gadget = this.$Gadget;
      var data = $Gadget.$Data.data;
      for ( var i in data)
      {
        var handler = data[i];
        if(handler.value)
        {
          try
          {
        	handler.value = angular.isObject(handler.value) ? angular.toJson(handler.value) : handler.value; 
          }
          catch(e)
          {
              //console.log('Error',e);
          }
        }
        $Gadget.$Data[handler.key] = handler.value;
      }

      var i = $Gadget.$watch('$Data', function(newV, oldV)
      {
        if(angular.equals(newV,oldV))
        {
          return;
        }

        for ( var i in newV)
        {
          if (i == "data")
          {
            continue;
          }

          if (!me.isValueChanged(i, newV[i],oldV[i]))
          {
            continue;
          }

          me.syncToServer(i, newV[i]);
        }
      }, true);

      $Gadget.$PutData = function(key,value,onsuccess)
      {
        me.put(key, value, onsuccess);
      };

      $Gadget.$IsLoaded = true;
      $Gadget.$Emit("$bes.context.loaded");
    },

    isValueChanged : function(key, newV, oldV)
    {
      var handler = this.$Gadget.$Data.data[key];
      if (handler == null)
      {
        return true;
      }

      if (handler.readOnly)
      {
        return false;
      }

      if (angular.equals(oldV, newV))
      {
        return false;
      }

      return true;
    }
  });

  window.$BES = window.$BES || {};
  $BES.$ContextAccessor = {};

  $BES.$ContextAccessor.getOperatorId = function()
  {
    return $BES.$ContextAccessor.getAttribute("OPERATOR");
  };

  $BES.$ContextAccessor.getRegionId = function()
  {
    return $BES.$ContextAccessor.getAttribute("REGION");
  };

  $BES.$ContextAccessor.getBeId = function()
  {
    return $BES.$ContextAccessor.getAttribute("BE_ID");
  };

  $BES.$ContextAccessor.getLocale = function()
  {
    return $BES.$ContextAccessor.getAttribute("LOCALE");
  };

  $BES.$ContextAccessor.getBeCode = function()
  {
    return $BES.$ContextAccessor.getAttribute("BE_CODE");
  };
  
  $BES.$ContextAccessor.getBizBeid = function()
  {
    return $BES.$ContextAccessor.getAttribute("BIZ_BE_ID");
  };
  
  $BES.$ContextAccessor.getDeptId = function()
  {
    return $BES.$ContextAccessor.getAttribute("DEPT_ID");
  };

  $BES.$ContextAccessor.getHttpsPort = function()
  {
    return $BES.$ContextAccessor.getAttribute("HTTPS_PORT");
  };

  $BES.$ContextAccessor.putAttribute = function(key, value)
  {
    $Controller.bes.common.pagecontext.$Gadget.$Data[key] = value;
  };

  $BES.$ContextAccessor.getAttribute = function(key)
  {
    var value = $Controller.bes.common.pagecontext.$Gadget.$Data[key];
    return value;
  };
})();

// below code used to show js in chrome's Sources panel.
//# sourceURL=bes-common-pagecontext.js