$Controller(
		"bes.oc.cardupload",
		{
			init : function($Gadget, $Fire) {
            	if (window._ysp_top.uploadUseTopPara) {
            		$Gadget.uploadUseTopPara = true;
                    window._ysp_top.uploadUseTopPara = null;
            	}

                if (window._ysp_top.loginPageContextTag || $Gadget.uploadUseTopPara) {
                	this.cardupload(null, $Gadget, $Fire);
                }
			},
			
			cardupload : function($Event, $Gadget, $Fire) {
				if(!window._ysp_top.loginPageContextTag)  {
					if($("#cardUploadGadgetPop") && $("#cardUploadGadgetPop").length>0)
					{
						$("#cardUploadGadgetPop").show();
					}
					else if($("#cardUploadGadgetPopAuth") && $("#cardUploadGadgetPopAuth").length>0)
					{
						$("#cardUploadGadgetPopAuth").show();
					}
				}
				
				if (!$Gadget.cardupload) {
					$Gadget.cardupload = {
						cerTypeList : null
					};
				}
				$("#personelCard").html("");
				$("#otherCard").html("");
				
                var para = null;
                if ($Gadget.uploadUseTopPara) {
                	para = window._ysp_top.carduploadpop;
                } else {
                	para = window._ysp_top.loginPageContextTag ? window._ysp_top.carduploadpop :
                		$Event && $Event.$Data;
                }
				
				if (!$Gadget.cardupload.cardTypeDroplist && para && 
						para.authdropList) {
					// 证件类型
					$Gadget.cardupload.personelCardDroplist = new UCD.Droplist(
							$("#personelCard"), para.authdropList);
					$Gadget.cardupload.personelCardDroplist.init();
					$Gadget.cardupload.personelCardDroplist
							.setOnValueChange(function() {
								debugger;
								var key = $Gadget.cardupload.personelCardDroplist.$input
										.attr('key');
								$Gadget.$Emit("$Gadget.updateCardType", {
									updateCardType : key
								});
							});
					// 代办证件证件类型
					$Gadget.cardupload.otherCardDroplist = new UCD.Droplist(
							$("#otherCard"), para.authdropList);
					$Gadget.cardupload.otherCardDroplist.init();
					$Gadget.cardupload.otherCardDroplist
							.setOnValueChange(function() {
								debugger;
								/*var key = $Gadget.cardupload.otherCardDroplist.$input
										.attr('key');*/
								/*$Gadget.$Emit("$Gadget.updateCardType", {
									updateCardType : key
								});*/
							});
				}

				if (para) {
					$Gadget.cardupload.personelCardDroplist
							.selectItem(para.authSelectedKey);
					$Gadget.cardupload.otherCardDroplist
							.selectItem(para.authSelectedKey);
				}
			},
			cardconfirm : function($Event, $Gadget, $Fire, $UI) {
				debugger;
				if($("#cardUploadGadgetPop") && $("#cardUploadGadgetPop").length>0)
				{
					if(!$("#fileNamepersonelUpload").html()&&!$("#fileNameotherUpload").html()){
						$UI.msgbox.info("提示", "请上传文件。");
						return;
					}
					$("#cardUploadGadgetPop").hide();
				}
				else if($("#cardUploadGadgetPopAuth") && $("#cardUploadGadgetPopAuth").length>0)
				{
					$("#cardUploadGadgetPopAuth").hide();
				}				

				if (window._ysp_top.loginPageContextTag
                    || $Gadget.uploadUseTopPara) {
					this.closePop();
				}
			},
			cardcancel : function($Gadget) {
				if (window._ysp_top.loginPageContextTag
                    || $Gadget.uploadUseTopPara) {
					this.closePop();
					return;
				}
				
				if($("#cardUploadGadgetPop") && $("#cardUploadGadgetPop").length>0)
				{
					$("#cardUploadGadgetPop").hide();
				}
				else if($("#cardUploadGadgetPopAuth") && $("#cardUploadGadgetPopAuth").length>0)
				{
					$("#cardUploadGadgetPopAuth").hide();
				}
			},

			closePop : function() {
				debugger;
				$('#closeBoxBtn_carduploadPopup', parent.document).click();
			},
			
			//上传文件后显示证件图片
			showIcCardImg : function($Gadget, $Data){
				debugger;
				
					if(($Data || {}).fileId == "personelUpload"){
						$("#iccardImg_personelUpload")[0].style.filter
			            = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\"" + $Data.fileName + "\")";
						$("#iccardImg_personelUpload")[0].style.display = "block";
						//$("#iccardImg_serv_upload").eq(0).attr("src","file:///d:/psb123.jpg");
						debugger;
						window._ysp_top.EinvoiceIdCardInfo.showuploadservcard = true;
						//将上传的证件图片，上传到对应目录下--本人
						upLoadIDCardForPrint($Data.fileName, 'serv');
                        window._ysp_top.uploadCustPic = true;
					}else if(($Data || {}).fileId == "otherUpload"){					
						$("#iccardImg_otherUpload")[0].style.filter
			            = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\"" + $Data.fileName + "\")";
						$("#iccardImg_otherUpload")[0].style.display = "block";
						//$("#iccardImg_delegate_upload").eq(0).attr("src",$Data.fileName);
						debugger;
						window._ysp_top.EinvoiceIdCardInfo.showuploaddelegcard = true;
						//将上传的证件图片，上传到对应目录下--经办人
						upLoadIDCardForPrint($Data.fileName, 'delegate');
					}										
			},
			
			//删除文件后隐藏图片
			hideIcCardImg : function($Gadget, $Data){
				debugger;
				
					if(($Data || {}).fileId == "personelUpload"){
						$("#iccardImg_personelUpload")[0].style.filter
			            = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\"" + "\")";
						$("#iccardImg_personelUpload")[0].style.display = "none";
						//$("#iccardImg_serv_upload").eq(0).attr("src","file:///d:/psb123.jpg");
						debugger;
					}else if(($Data || {}).fileId == "otherUpload"){					
						$("#iccardImg_otherUpload")[0].style.filter
			            = "progid:DXImageTransform.Microsoft.AlphaImageLoader(enabled='true',sizingMethod='scale',src=\"" + "\")";
						$("#iccardImg_otherUpload")[0].style.display = "none";
						//$("#iccardImg_delegate_upload").eq(0).attr("src",$Data.fileName);
					}										
			}
		});