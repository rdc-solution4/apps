$Controller("bes.oc.prodDispachUrl", {
	distributePages: function($Page, $Gadget, $Fire, $UI) {
		debugger;
		var ocProductInfo = null;
		var ocNetType = null;
		//获取网络类型
		if($Gadget.data.offeringinfo && $Gadget.data.offeringinfo.specialAttr){
			ocNetType = $Gadget.data.offeringinfo.specialAttr.networkType;
			window._ysp_top.ocNetType = ocNetType;
		}

		//添加档次参数
		if($Gadget.$Promotion){
			$Gadget.$Promotion=null;
			//判断登陆状态
			this.issubscribelogin($Page, $Gadget, $Fire, $UI, ocProductInfo);
			return ;
		}

		if ($Gadget.data.offeringinfo.ocProductInfoVA) {
			//modify by liumei00289267 on 20150910 for DTS2015090911054
            //begin-->
			$Gadget.data.offeringinfo.ocProductInfoVA = $Gadget.data.offeringinfo.ocProductInfoVA || [];
			for (var i = 0; i < $Gadget.data.offeringinfo.ocProductInfoVA.length; i++) {
				ocProductInfo = $Gadget.data.offeringinfo.ocProductInfoVA[i];
				$Gadget.adProductInfo = ocProductInfo;

				if (ocProductInfo.complexFlag == "1") {
					// 跳转一卡双号页面
					if (ocProductInfo.prodType == adutil.offeringProdType.YKSH) {

						this.closePortalTab("cporder");
						adutil
						.openTopTab(
								"60131_cporder",
								$UEE.i18n("ad.person.title.cporderRegisterAlternate"),
								"/bes/ad/html/bes-agentdesktop-cporder.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId + "&#/cporder");
						/*
						 * window.open(
						 * "bes.oc.index.cporder.base.business.html?offeringId=" +
						 * $Gadget.data.offeringinfo.offerId + "&#/cporder",
						 * '_blank');
						 */
						$Page.isClickBtn = false;
						return;
					}
				}

				if (ocProductInfo.complexFlag == "0" && ocProductInfo.isPrimary == "Y") {
					for(var i=0; i<(ocProductInfo.ocPcProductIdentityTRSVO || []).length; i++){
						// 小区宽带开户或者校园宽带
						if (ocProductInfo.ocPcProductIdentityTRSVO[i].isMain == "Y"
							&& ocProductInfo.ocPcProductIdentityTRSVO[i].idenTypeCode == adutil.idenTypeCode.BroadBandAccountId) {
							this.closePortalTab("broadbandopen");
							adutil
							.openTopTab(
									"60131_broadbandopen",
									$UEE.i18n("ad.person.title.LocalRegistration"),
									"/bes/ad/ctz/html/bes-ad-ctz-broadbandopen.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&#/broadbandaccount");
							$Page.isClickBtn = false;
							return;
						}

						// 个人/家庭副卡开户
						if (ocProductInfo.ocPcProductIdentityTRSVO[i].isMain == "Y"
							&& ocProductInfo.ocPcProductIdentityTRSVO[i].idenTypeCode == adutil.idenTypeCode.MSISDN) {
							var confirmCallBack = function(){
							this.closePortalTab("openvicecardaccount");
							adutil
							.openTopTab(
									"60131_register",
									$UEE.i18n("ad.person.title.openaccount"),
									"/bes/ad/html/ctz.bes-agentdesktop-openaccount.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId +"&quickPickRoutePath="+ $Page.data.quickPickRoutePath+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&outTelNumber=" + $Gadget.outTelNum +"&#/openaccount");
							}
							$Page.isClickBtn = false;
							this.isMainOfferCanBuy($Gadget, $Fire, $UI,confirmCallBack);
							return;
						}

						// 政企通固话开户
						if (ocNetType == 7) {
							this.closePortalTab("goventtelephone");
							adutil
							.openTopTab(
									"60131_goventtelephone",
									$UEE.i18n("ad.person.title.goventtelephoneBusiName"),
									"/bes/ad/html/bes-agentdesktop-goventtelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&#/goventtelephone");
							$Page.isClickBtn = false;
							return;
						}

						// 异网互联网开户
						if (ocNetType == 11) {
							this.closePortalTab("differentnetwork");
							adutil
							.openTopTab(
									"60131_differentnetwork",
									"异网用户互联网账号开户",
									"/bes/ad/html/bes-agentdesktop-differentnetwork.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&#/differentnetwork");
							$Page.isClickBtn = false;
							return;
						}
						// 集团IMS固话服务
						if (ocNetType == 1 && ocProductInfo.ocPcProductIdentityTRSVO[i].idenTypeCode == adutil.idenTypeCode.MSISDN12) {
							this.closePortalTab("imstelephone");
							adutil
							.openTopTab(
									"60131_imstelephone",
									"IMS固话开户",
									"/bes/ad/ctz/html/bes-ad-ctz-grpimstelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId +
									"&methodFlag=person" +"&#/imstelephone");
							$Page.isClickBtn = false;
							return;
						}
						
						//$Gadget.data.offeringinfo.offerCode = 'PRI_HJIMS';
						if (ocNetType == 8 && $Gadget.data.offeringinfo && $Gadget.data.offeringinfo.offerCode == 'PRI_HJIMS'){
							this.closePortalTab("imstelephone");
							adutil
							.openTopTab(
									"60131_imstelephone",
									"和家固话开户",
									"/bes/ad/ctz/html/bes-ad-ctz-agentdesktop-imstelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId +
									"&methodFlag=person" + "&offerFlag=hjims" +"&#/imstelephone");
							$Page.isClickBtn = false;
							return;
						}
						
						// 家庭融合IMS固话服务
						if (ocNetType == 8 && ocProductInfo.ocPcProductIdentityTRSVO[i].idenTypeCode == adutil.idenTypeCode.MSISDN12) {
							this.closePortalTab("imstelephone");
							adutil
							.openTopTab(
									"60131_imstelephone",
									"IMS固话开户",
									"/bes/ad/ctz/html/bes-ad-ctz-agentdesktop-imstelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId +
									"&methodFlag=person" +"&#/imstelephone");
							$Page.isClickBtn = false;
							return;
						}


						// IMS固话开户
						if (ocProductInfo.ocPcProductIdentityTRSVO[i].idenTypeCode == adutil.idenTypeCode.GRP_MEM_IMS_FSISDN) {
							this.closePortalTab("imstelephone");
							adutil
							.openTopTab(
									"60131_imstelephone",
									"IMS固话开户",
									"/bes/ad/html/bes-agentdesktop-imstelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&#/imstelephone");
							$Page.isClickBtn = false;
							return;
						}

						// 有线固话开户
						if (ocProductInfo.ocPcProductIdentityTRSVO[i].idenTypeCode == adutil.idenTypeCode.FSIDN) {
							this.closePortalTab("wiredTelephone");
							adutil
							.openTopTab(
									"60131_wiredTelephone",
									$UEE.i18n("ad.person.title.telephoneBusiName"),
									"/bes/ad/html/bes-agentdesktop-wiredtelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&#/wiredTelephone");
							$Page.isClickBtn = false;
							return;
						}
					}

					// 个人/家庭副卡开户
					if (ocNetType == 1 || ocNetType == 2 || ocNetType == 13) {

						var confirmCallBack = function(){
						this.closePortalTab("openvicecardaccount");
						adutil
						.openTopTab(
								"60131_register",
								$UEE.i18n("ad.person.title.openaccount"),
								"/bes/ad/html/ctz.bes-agentdesktop-openaccount.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&outTelNumber=" + $Gadget.outTelNum + "&#/openaccount");
						}
						$Page.isClickBtn = false;
						this.isMainOfferCanBuy($Gadget, $Fire, $UI,confirmCallBack);
						return;
					}

					// 有线固话开户
					if (ocNetType == 3) {
						this.closePortalTab("wiredTelephone");
						adutil
						.openTopTab(
								"60131_wiredTelephone",
								$UEE.i18n("ad.person.title.telephoneBusiName"),
								"/bes/ad/html/bes-agentdesktop-wiredtelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs + "&#/wiredTelephone");
                                                $Page.isClickBtn = false;
						return;
					}

					// IMS固话开户
					if (ocNetType == 8) {
						this.closePortalTab("imstelephone");
						adutil
						.openTopTab(
								"60131_imstelephone",
								"IMS固话开户",
								"/bes/ad/ctz/html/bes-ad-ctz-agentdesktop-imstelephone.html"+getVersionUrlStr(1)+"&offeringId=" + $Gadget.data.offeringinfo.offerId +
								"&methodFlag=person" +"&#/imstelephone");
						$Page.isClickBtn = false;
						return;
					}

					$Page.isClickBtn = false;
					return;
				}

				//裸机销售 add by lwx207718 2015-06-09 begin
				if ("PTTerminal" == ocProductInfo.prodType)
				{
					//判断是否为空
					if(!$Gadget.imeiResult || !$Gadget.imeiResult.body){
						$Gadget.imeiResult={
								"body":{"skuId":""}
						};
					}

					this.closePortalTab("specialpersonalproduct");

					var appointParams = "";
					if($Gadget.selectedAppointmentInfo){
						appointParams = "&servNum=" + ($Gadget.selectedAppointmentInfo.servNum || "") +
						    "&custName=" + ($Gadget.selectedAppointmentInfo.custName || "") +
						    "&preContractSeq=" + ($Gadget.selectedAppointmentInfo.preContractSeq || "") +
						    "&resColor=" + ($Gadget.selectedAppointmentInfo.resColor || "") +
						    "&resNum=" + ($Gadget.selectedAppointmentInfo.resNum || "")
					}

					adutil
					.openTopTab(
							"60131_specialpersonalproduct",
							$UEE.i18n("ad.person.title.terminalSale"),
							"/bes/ad/ctz/html/bes-ad-ctz-bareorder.html"+getVersionUrlStr(1)+"&offeringid=" + $Gadget.$Item.offeringId + "&imei=" + $Gadget.offerCondition+"&skuId="+$Gadget.imeiResult.body.skuId+"&isAgentCreateSubs=" + $Page.isAgentCreateSubs +appointParams+"#/index");

					$Page.isClickBtn = false;

					return;
				}

				//cly
				//售货类显示售货页面
				//if(($Gadget.data.offeringinfo.ocProductInfoVA || []).length==1&&$Gadget.data.offeringinfo.ocProductInfoVA[0].inventoryItemType!=null)
				if (ocProductInfo.inventoryItemType!=null)
				{
					/*				this.closePortalTab("orderbycard");
				adutil.openTopTab(
							"orderbycard",
							"售货",
							"/bes/ordercapture/html/bes-agentdesktop-orderbycard.html?offerId=" + $Gadget.data.offeringinfo.offerId);
				$Page.isClickBtn = false;*/

					//走购物车逻辑
					if ($Page.subscriber == undefined
							|| $Page.subscriber.loginStatus == false) {
						$Page.serviceNumber = null;
					} else {
						$Page.serviceNumber = $Page.subscriber.subscriberInfo.serviceNumber;
					}


					debugger;
					$Page.data = $Page.data||{};
					$Page.data.offeringId = $Gadget.$Item.offeringId;
					$Page.data.offeringinfo = {};

					//add by lwx207718 on 2015-10-10 for DTS2015100600224
					$Page.data.resouceNum = $Gadget.offerCondition;
					$Page.data.formorderbutton = true;

					this.showsalecardPage($Gadget);

					$Page.isClickBtn = false;
					$Page.callfrom = $Gadget.callfrom ;


					return true;
				}
			}
		}

		if($Gadget.data.offeringinfo.ocProductInfoVA == null){
			var tmooffer = $Gadget.data.offeringinfo.offerId ;
			if(tmooffer == '35029' || tmooffer == '35030' || tmooffer == '35031' || tmooffer == '35032' || tmooffer == '35033'
				|| tmooffer == '35034' || tmooffer == '35035'){

				if ($Page.subscriber == undefined
						|| $Page.subscriber.loginStatus == false) {
					$Page.serviceNumber = null;
				} else {
					$Page.serviceNumber = $Page.subscriber.subscriberInfo.serviceNumber;
				}

				debugger;
				$Page.data = $Page.data||{};
				$Page.data.offeringId = $Gadget.$Item.offeringId;
				$Page.data.offeringinfo = {};

				//add by lwx207718 on 2015-10-10 for DTS2015100600224
				$Page.data.resouceNum = $Gadget.offerCondition;
				$Page.data.formorderbutton = true;

				this.showsalecardPage($Gadget);

				$Page.isClickBtn = false;
				$Page.callfrom = $Gadget.callfrom ;


				return true;
			}

		}

		//判断登陆状态
		this.issubscribelogin($Page, $Gadget, $Fire, $UI, ocProductInfo);
	},

	showsalecardPage:function($Gadget, offeringid){
		debugger;
		$(".recommend").hide();
		window._ysp_top.productPopupFlag='2';

		offeringid = offeringid || $Gadget.$Item.offeringId;
		var objstr = "#productaddtocar"+offeringid;

		var obj = $(objstr) || $("#productordermainImpl");

		if(offeringid){
			obj = $("#productordermainImpl");
		}

		setTimeout(function(){
			var scope = $(document).scope();
			scope.$apply(function(){
				if(window._ysp_top.productPopupFlag != '2'){
					window._ysp_top.productPopupFlag = '2';
				}
			},scope);

		},1);
		$PartShade = $('.partShade:eq(1)');

		ShadeLeft=$('#productordermainImpl').offset().left;
		newWidth = $('#productordermainImpl').width();

		$PartShade.css({
			'display':'block',
			'left':obj.offset().left,
			'_ysp_top':obj.offset()._ysp_top+3
			});

		$PartShade.animate({
			left:ShadeLeft,
			_ysp_top:3,
			bottom:0,
			height:$("body:eq(0)").height(),
			width:newWidth+10
			},300,function(){

				});

		/*窗口改变大小时，弹窗收起*/
		$(window).resize(function () {

			debugger;
			var width = $('#productordermainImpl').width()-5;
			$(".fix_btns").css("width",width);
			var newWidth = $('#productordermainImpl').width()-15;
			$PartShade.css({
				'height':$("body:eq(0)").height(),
				'width':newWidth+10
				});
		});
	},

	//判断登录
	issubscribelogin:function($Page, $Gadget,$Fire, $UI, ocProductInfo){
		debugger;
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
		//判断登陆状态
		$Fire({
			'service': 'bes.oc.subscribeinfoservice/issubscribelogin',
			'params': {},
			'target': '$Page.subscriber',
			'onafter': function($Page, $Gadget, $Fire, $UI) {
				debugger;
				$Gadget.busiValid = false;
				$Gadget.issublogin = $Page.subscriber.loginStatus;
				//家庭主offer模式商品订购
				if($Page.familyMianOffer)
				{
					$Controller.bes.oc.prodDispachUrl.familyMianOpen($Page, $Gadget,$Fire, $UI, ocProductInfo);
					return;
				}
				//DTS2016101811119商品订购增加鉴权方式判断
				if($Gadget.issublogin && !$Page.isCsp){

					var len = ($Gadget.menuAuthCheckList||[]).length;
					if(len > 0) {
						var exist = false;
						$.each($Gadget.menuAuthCheckList,function(i,val){
							if(val == $Page.subscriber.authType){
								exist = true;
								return false;
							}
						});

						//没有配置当前鉴权方式需要重新鉴权
						if(!exist){
							$Controller.bes.oc.productorder.queryControlTypes($Page, $Gadget,$Fire, $UI, ocProductInfo);
							return;
						}
					}
				}

				if ($Gadget.issublogin) {
					if($Page.isCsp)
					{
						$Page.serviceNumber = $Page.subscriber.subscriberInfo.serviceNumber;

						$Controller.bes.oc.productorder.beforeGetOfferingInfoDetail($Page, $Gadget, $Fire, $UI);

						//一站式融合家庭开户
						if ("FMC" == (ocProductInfo||{}).prodType)
						{
							adutil
							.openTopTab(
									"60131_orderningxiafamily",
									$UEE.i18n("AD.FAMILY.TITLE.ONE_STOP_FAMILY"),
									"/bes/ad/ctz/gadget/person/family/one-stop-familyopen/bes-ad-one-stop-familyorder-base.html"+getVersionUrlStr(1)+ "&offeringid=" + $Gadget.$Item.offeringId);
							$Page.isClickBtn = false;
							this.closePortalTab("60131004");
						    return;
						}
					} else {
						var params = {
		                    "header" : {
		                        "loginToken" : "",
		                        "loginId" : "",
		                        "locale" : "",
		                        "serialId" : ""
		                    },
		                    "body" : {
		                        "seniorId" : "ChangeBandAddress",
		                        "eventId" : "PreCheck",
		                        "busiCode" : "ChangeBandAddress",
		                        "remark":"",
		                        "isCache" : false
		                    }
		                };
						$Gadget.$Get('$Fire')({
			            service : "ucec/v1/changeBandAddress/enter_check",
			            params : params,
			            target : "$Gadget.validation",
			            onafter : function($Gadget, $UI) {
			            	debugger;
			            	$Fire({
						'service': '/ucec/v1/accessAuth',
						'params': {
							tabid: $Page.menuId
						},
						'target': '$Page.subscrity',
						'onafter': function($Page, $Gadget, $Fire, $UI) {
							debugger
									if($Page.subscrity && !$Page.isCsp)
							{
								$Controller.bes.oc.productorder.queryControlTypes($Page, $Gadget,$Fire, $UI, ocProductInfo);

							}else{
					//追加黑名单校验
					//var confirmCallBack = function(){
								$Page.serviceNumber = $Page.subscriber.subscriberInfo.serviceNumber;

						//TODO:加入生效方式
	//					$Controller.bes.oc.productorder.getOfferingInfoDetail($Page, $Gadget, $Fire, $UI);
								$Controller.bes.oc.productorder.beforeGetOfferingInfoDetail($Page, $Gadget, $Fire, $UI);
					//};
					//$Controller.bes.oc.productorder.isBlackChecklist($Gadget, $Fire, $UI, confirmCallBack);

								//一站式融合家庭开户
									if ("FMC" == (ocProductInfo||{}).prodType)
									{
										adutil
										.openTopTab(
												"60131_orderningxiafamily",
												$UEE.i18n("AD.FAMILY.TITLE.ONE_STOP_FAMILY"),
												"/bes/ad/ctz/gadget/person/family/one-stop-familyopen/bes-ad-one-stop-familyorder-base.html"+getVersionUrlStr(1)+ "&offeringid=" + $Gadget.$Item.offeringId);
										$Page.isClickBtn = false;
										this.closePortalTab("60131004");
									    return;
									}
								}
							}
						},$Gadget);
			            }
			        },$Gadget);

					}


				} else {
					//和家庭计划家宽融合套餐根据商品属性判断是否开户
					if ("FMC" == (ocProductInfo||{}).prodType && $Gadget.FMC_propvalue != "1")
					{
						adutil
						.openTopTab(
								"60131_orderningxiafamily",
								$UEE.i18n("AD.FAMILY.TITLE.ONE_STOP_FAMILY"),
								"/bes/ad/ctz/gadget/person/family/one-stop-familyopen/bes-ad-one-stop-familyorder-base.html"+getVersionUrlStr(1)+ "&offeringid=" + $Gadget.$Item.offeringId);
						$Page.isClickBtn = false;
						return;
					}
					$Controller.bes.oc.productorder.queryControlTypes($Page, $Gadget,$Fire, $UI, ocProductInfo);
				}
			}

		}, $Gadget);
	},

	//家庭网主商品开户
	familyMianOpen:function($Page, $Gadget,$Fire, $UI, ocProductInfo)
	{
		debugger;
		//如果的是登录用户直接跳转

		if ($Gadget.issublogin) {
			adutil.openTopTab("BLCS_FamilyMemeberMgr",$UEE.i18n("AD.FAMILY.LABEL.HWJT"),
					"/bes/ad/person/family/bes-ad-family-base-business.html"+getVersionUrlStr(1)+ "&offeringid=" + $Page.offeringId);
		} else {
			$Controller.bes.oc.productorder.queryControlTypes($Page, $Gadget,$Fire, $UI, ocProductInfo);
		}
	},

	//判断主offer能否用来开户
	isMainOfferCanBuy:function($Gadget, $Fire, $UI, confirmCallBack)
	{
		debugger;
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
		$Fire({
			'service': 'bes.oc.pcsearchex4telecomqueryservice/queryfilterofferlist',
			'params': {
				'searchofferingcond': {"recType": "CreateSubscriber","offeringIdList":[$Gadget.data.offeringinfo.offerId]},
				'pageinfo': {beginRowNumber:0, recordPerPage:12, curPage:1}
			},
			'target': '$Gadget.data.mainOfferJudge',
			'onafter': function($Gadget, $Fire) {
				debugger;
				if($Gadget.data.mainOfferJudge && $Gadget.data.mainOfferJudge.offeringList){
					confirmCallBack();
				}
				else{
					$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.DirectOrderNotAllowed", $Gadget.data.offeringinfo.offerName));
				}

			}
		}, $Gadget);
	},

	closePortalTab : function(tabid)
	{
		if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist(tabid))
		{
			if (_ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel)
			{
				_ysp_top.window.$BES.$Portal.tabpanel.closeTabItem(tabid);
			}
		}
	},
	directAddtoShoppincar:function($Page, $Gadget){
		debugger;
		var oldOffer = $.extend(true,{},$Gadget.data.offeringinfo);
		var offering = {};
		offering.offeringId = oldOffer.offerId;
		offering.offeringName = oldOffer.offerName;
		offering.offeringDesc = oldOffer.offerDesc;
		offering.offeringCode = oldOffer.offerCode;
		offering.isShowDayConvert = oldOffer.isShowDayConvert == "Y";
		offering.oriEntityId = oldOffer.oriEntityId; // add for US-20180521185335-2031091190
		if(offering.offeringId == ($Page.data||{}).icrmMarketingOfferingId){
			offering.recommendOid = $Page.data.recommendOid;
			$Page.data.icrmMarketingOfferingId = null;
		}
		offering.opCode = '1';
		if(oldOffer.ocEffectiveMode)
		{
			//取默认生效方式
			offering.effectiveWay = $.extend(true,{},oldOffer.ocEffectiveMode);

			var tempSelectedMode = offering.effectiveWay.selectedMode;
			for(var i=0;i<((offering.effectiveWay||{}).effectiveTypes||[]).length;i++)
			{
				if((offering.effectiveWay.effectiveTypes[i]||{}).key !== offering.effectiveWay.selectedMode)
				{
					//次日会改成nd
					if(offering.effectiveWay.selectedMode == 'S' && (offering.effectiveWay.effectiveTypes[i]||{}).key == 'ND')
					{
						tempSelectedMode = 'ND';
						continue;
					}
					offering.effectiveWay.effectiveTypes.splice(i,1);
					i--;
				}
			}
			offering.effectiveWay.selectedMode = tempSelectedMode;
			offering.displaydate = (((offering.effectiveWay || {}).effectiveTypes || [])[0] || {}).value;
			//将所有生效方式保存下来
			offering.effectiveWay.effectiveWays = $.extend(true,{},oldOffer.ocEffectiveMode);
		}

		if(oldOffer.ocExpireMode)
		{
			//取默认失效方式
			offering.expirationWay = $.extend(true,{},oldOffer.ocExpireMode);
			for(var i=0;i<((offering.expirationWay||{}).expirationTypes||[]).length;i++)
			{
				if((offering.expirationWay.expirationTypes[i]||{}).key !== offering.expirationWay.selectedMode)
				{
					offering.expirationWay.expirationTypes.splice(i,1);
					i--;
				}
			}
			//将所有失效方式保存下来
			offering.expirationWay.expirationWays = $.extend(true,{},oldOffer.ocExpireMode);
		}


		//预校验 added by h00308289
		var offeringList = null;
		if($Page.isNewOpenFlag){
			offeringList = $.extend(true,[],$Page.data.carofferingList);

		}else{
			offeringList = $.extend(true,[],window._ysp_top.shoppingcart.carofferingList);
		}

		// 如果是短信炸弹防护类商品,定制生效方式
		$Controller.bes.oc.prodDispachUrl.isSMSBOMPOffer($Page, $Gadget, offering);

		offeringList.push(offering);

		var tempList = $.extend(true,[],offeringList);
		$Controller.bes.ad.shoppingcart.gerateofferingList(tempList);
		$Page.checkoutValidateBody = {businessType: "ChangeProduct",
				needCacheBusiValidate: 'N',
				createOrderReq:{
					order:{
						orderPayment:[]
					}
				},
			mixturePOJO:{
				offerings:tempList,
				packageFee:'N',
				seniorId:'CHANGE_OFFER',
				eventId:'AddOfferPreCheck'
			}
		};
		dontTouchDataOfWholePage();
		$Fire({
	        service : 'bes.agentdesktop.checkoutboservice/busivalidate',
	        params:{
	        	header:{},
	        	"checkoutbody": $Page.checkoutValidateBody
	        },
	        target : '$Page.checkoutValidateResult',
	        onafter : function(){
	        	debugger;
	        	youCanTouchDataOfWholePage();

	        	if (adutil.checkUcecResp($Page.checkoutValidateResult.header, $UI)) {

					if('0' == (($Page.checkoutValidateResult.body.checkOutResp||{}).returnMessage||{}).retCode){
						debugger;
						// add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 start
						if (!$Gadget.data.offeringinfo.oriEntityId) {
							offering.destEntryIdList = [];
						}
						// add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 end
						
						if(parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0){
							//向购物车增加商品时增加一个traceid
							window._ysp_top.shoppingcart.cartraceidList=window._ysp_top.shoppingcart.cartraceidList||[];
							window._ysp_top.shoppingcart.cartraceidList.push($Page.traceId);
							window._ysp_top.shoppingcart.carofferingList.push(offering);
						}
						else{
							$Page.data = $Page.data ||{};
							$Page.data.carofferingList = $Page.data.carofferingList||[];

							$Page.data.carofferingList.push(offering);
						}
						
						// add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 start
						if (!$Gadget.data.offeringinfo.oriEntityId) {
		    				$Controller.bes.oc.prodDispachUrl.queryRelationOffer($Page, $Gadget, offering);
						}
						// add for US-20180521185335-2031091190  【宁夏】物联网流量功能月功能费产品优化申请需求 end
						
						$Gadget.$Emit("$ShoppingCartReady");
						$Gadget.$Emit("$ShoppingCartInit");
						var shoppingCar = $(".shoppingCar");
						if(shoppingCar.length == 0){
							shoppingCar = _ysp_top.$(".shoppingCar");
						}

						if(!$Page.isNewOpenFlag){
							shoppingCar.click();
						}
					}
					else{
						$Page.data = $Page.data||{};
						$Page.data.offeringId = $Gadget.$Item.offeringId;
						$Page.data.offeringinfo = {};
						window._ysp_top.productPopupFlag='1';
						var obj = "productaddtocar"+$Gadget.$Item.offeringId;
						$Controller.bes.oc.productorder.showPartShade($("#"+obj),"../../ad/usl/bes-ad-goofferingdetail.uslx");
					}
		        }
	        }
		},$Gadget);

	},
	// 如果是短信炸弹防护类商品,定制生效方式
	isSMSBOMPOffer: function($Page, $Gadget, offer){
		debugger;
		$Gadget.dictList = $Gadget.dictList || {};
		var isSure = false;
		var offerIdList = $Gadget.dictList.AD_SMSBOMB_PROT_OFFER || [];
		for (var i = 0; i < offerIdList.length; i++) {
			if($Gadget.data.offeringinfo.offerId == offerIdList[i].key){
				isSure = true;
				break;
			}
		}
		if (isSure) {
			// 默认生效方式
			var effectiveType = [{ "key": "C", "selected": true, "value": "客户指定时间"}];
			var effectiveWay = {};
			var expirationWay = {};
			effectiveWay.effectiveDate = new Date().getTime();
			effectiveWay.effectiveTypes = effectiveType;
			effectiveWay.expirationDate = $Page.TimeUtil.nowDateFirstSecond + 3600*1000*24;
			effectiveWay.roamDays = 1;

			expirationWay.expirationDate = $Page.TimeUtil.nowDateFirstSecond + 3600*1000*24;
			expirationWay.expirationTypes = effectiveType;

			offer.effectiveWay = effectiveWay;
			offer.expirationWay = expirationWay;
		}
	},
	
	/**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  查询与商品A有BO关系（表示订购A时，自动把B带出来）的目标商品B
	 */
	queryRelationOffer: function ($Page, $Gadget, oriEntityInfo) {
    	debugger;
    	$Fire({
    		'service': 'com.huawei.bes.pc.base.common.PcRelationBOService/queryRelationByOriginForValidate',
    		'params': {
    			'searchVO': {
    				"oriEntityType": "O",
    				"oriEntityId": oriEntityInfo.offeringId,
    				"relaType": "BO"
    			},
    			'beIds': null
    		},
    		'target': '$Gadget.relationList',
    		'onafter': function ($Gadget) {
    			debugger;
    			$Gadget.notOrderdestEntryIdList = [];
    			if ($Gadget.relationList && $Gadget.relationList.length > 0) {
    				for (var i = 0; i < $Gadget.relationList.length; i++) {
                		if ($Controller.bes.oc.prodDispachUrl.checkOfferInShoppingcartList($Page, $Gadget, 
                				$Gadget.relationList[i].offeringId)) {
                			continue;
                		}
    		    		$Gadget.notOrderdestEntryIdList.push($Gadget.relationList[i].destEntryId);
                	}
    				if ($Gadget.notOrderdestEntryIdList && $Gadget.notOrderdestEntryIdList.length > 0) {
                    	$Controller.bes.oc.prodDispachUrl.orderOfferByDestEntryId($Page, $Gadget, oriEntityInfo.offeringId);
                    }
    			} 
    		}
    	}, $Gadget);
    },
    
    /**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  查询目标商品的商品详情信息，并订购
	 */
    orderOfferByDestEntryId: function ($Page, $Gadget, oriEntityId) {
    	debugger;
    	$Fire({
            'service' : 'bes.oc.queryofferdetailservice/queryofferdetailbyofferidlist',
            'params' : {
            	'offerids' : $Gadget.notOrderdestEntryIdList
             },
            'target' : '$Gadget.destEntryOfferdetailList',
            onafter : function() {
                debugger;
                if ($Gadget.destEntryOfferdetailList) {
                	for (var i = 0; i < $Gadget.destEntryOfferdetailList.length; i++) {
                		$Gadget.data.offeringinfo = $Gadget.destEntryOfferdetailList[i];
        				$Gadget.data.offeringinfo.oriEntityId = oriEntityId;
        				$Controller.bes.oc.prodDispachUrl.directAddtoShoppincar($Page, $Gadget);
                	}
                }
            }
        },$Gadget);
    },
    
    /**
	 * US-20180521185335-2031091190  
	 * 【宁夏】物联网流量功能月功能费产品优化申请需求
	 *  判断购物车订购列表中是否存在目标商品
	 */
    checkOfferInShoppingcartList: function ($Page, $Gadget, destEntryId) {
    	for (var i = 0; i < window._ysp_top.shoppingcart.carofferingList.length; i++) {
			if (window._ysp_top.shoppingcart.carofferingList[i].offeringId == destEntryId) {
				window._ysp_top.shoppingcart.carofferingList[i].destEntryIdList.push(destEntryId);
				return true;
			}
		}
    	return null;
    }
});
