$Controller(
	"bes.oc.productValidate", {

	//提交人工授信相关信息
	qryValidateButton : function($Gadget){
		debugger;

		//请求初始化数据
		$Gadget.$Get("$Fire")({
			'service' : 'ucec/v1/common/qrysystemparambykey',
			'params' : {
				key : "OC_PRODUCTORDER_VALIDATE_BUTTON"
			},
			'target' : '$Gadget.validateButton',
			onafter : function($Gadget) {
				debugger;
              	//如果值为空，默认给0
	            if (!$Gadget.validateButton || $Gadget.validateButton === "" || $Gadget.validateButton == null) {
	                $Gadget.validateButton = 0;
	            }
			}
		}, $Gadget);
	},
	busiValidate : function($Page,$Item,$Promotion,$Gadget,$UI){
		debugger;

		$Gadget.$Get("$Fire")({
			'service': 'bes.oc.subscribeinfoservice/issubscribelogin',
			'params': {},
			'target': '$Page.subscriber',
			'onafter': function($Page, $Gadget, $Fire, $UI) {
				debugger;
				$Gadget.busiValid = false;
				$Gadget.issublogin = $Page.subscriber.loginStatus;
				if ($Gadget.issublogin) {

					//营销准入校验
					var promValidateReq = $Controller.bes.oc.productorder.generatePromValidateReq();
					//添加批次ID、档次ID、商品订购MODE
					$Page.params={
							"offeringId":$Item.offeringId,
							"levelId":$Promotion.levelBaseInfo.offeringId,
							"mode":"ChangeProduct",
							"promValidateReq":promValidateReq
					};
					
					if($Gadget.isCancelAccount == "9"){
						$UI.msgbox.info("提示", "该用户已销户，不予受理。");
						return;
					}


					for (var i = 0; i < (($Page.data||{}).carofferingList || []).length; i++) {
						if ($Controller.bes.oc.productValidate.isSameOffer($Item, $Page.data.carofferingList[i])) {
							$UI.msgbox.error("提示", "购物车中已存在。");
							return ;
						}
					}
					
					$Controller.bes.oc.productValidate.busiValidateByFire($Page,$Gadget,$Item.offeringId,$Promotion.levelBaseInfo.offeringId,$UI);

				} else {
					// 登陆逻辑
					$UI.msgbox.warning("提示",
						"此商品需要登录才能购买,确认登录？", function() {
							//增加业务类型
							$Page.businessCode = 'ChangeProduct';
							window._ysp_top.businessCode = 'ChangeProduct';
							
							$("#recommend").hide();
							$("#shoppingcar").hide();
							$("#productordermainImpl")
								.hide();
							$("#orderauthentication")
								.show();
						}, function() {
							$Page.isClickBtn = false;
						});
				}
			}

		}, $Gadget);
	},

	// 未登录用户
	busiValidateByFire: function($Page,$Gadget,offeringId,leveId, $UI) {
		debugger;
		$Gadget.$Get("$Fire")(
			{
				'service' : 'bes.agentdesktop.promotionservice/doauthentication',
				'params' : {
					"offeringid" : offeringId,
					"levelid" : leveId,
					"promvalidatereq" : $Page.params.promValidateReq
				},
				'target' : '$Gadget.promotionInfo',
				'onafter' : function($Gadget, $UI) {
					debugger;
					if (!$Gadget.promotionInfo.auth) {
						$UI.msgbox.error("提示",
								$Gadget.promotionInfo.retMessage);

						return;
					} else {
						$UI.msgbox.info("提示", "校验成功，可以订购该产品。");
					}
				}
			}, $Gadget);
	},

	promotionBundle : function($Page, $Gadget, $Fire, data, $UI) {
		debugger;
		//判断登陆状态
		$Fire({ 
			'service': 'bes.oc.subscribeinfoservice/issubscribelogin',
			'params': {},
			'target': '$Gadget.subscriber',
			'onafter': function($Page, $Gadget, $Fire, $UI) {
				debugger;
				var bundle = $Page.promotionBundle;
				if ($Gadget.subscriber.loginStatus) {
					if((bundle.promotionBundle.mainOffer || []).length >0){
						//已鉴权，并包含主产品。打开主体产品变更页面
						//首先打开客户统一视图
						/*
						item = {
						title : "客户统一视图",
						url : "resource.root/bes/ad/html/bes.ad.personalunifiedview.html",
						id : "60131006",
						pageid : "resource.root/bes/ad/html/bes.ad.personalunifiedview.html",
						httpsFlag : "",
						};
						
						if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131006"))
						{
							if (_ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel)
							{
								_ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("60131006");
							}
						}
						window.$BES.$Portal.tabpanel.createTabItem(item);
						*/
												
						setTimeout(function(){
							if (parent.getPageById("60131006") 
								&& parent.getPageById("60131006").find("iframe") 
								&& parent.getPageById("60131006").find("iframe")[0].contentWindow.document.readyState == "complete")
								{
									if (navigator.userAgent.indexOf("MSIE") != -1) {
									       bundle = JSON.stringify(bundle);
									}
									parent.getPageById("60131006").find("iframe")[0].contentWindow.postMessage(bundle, "*");
								}
							
						},2000);
									
					}else{

						window._ysp_top.shoppingcart = window._ysp_top.shoppingcart || {};
						window._ysp_top.shoppingcart.carofferingList = window._ysp_top.shoppingcart.carofferingList || [];
						window._ysp_top.shoppingcart.quickcarofferingList = [];
						
						for(var i = 0; i < bundle.promotionBundle.offer.length;i ++){
							var hasInCarList =false;
							for(var j =0; j<window._ysp_top.shoppingcart.carofferingList.length;j++){
								if($Controller.bes.oc.productValidate.isSameOffer((window._ysp_top.shoppingcart.carofferingList[j]||{}), (bundle.promotionBundle.offer[i]||{}))){
									hasInCarList =true;
									break;
								}
							}
							if(!hasInCarList){
								bundle.promotionBundle.offer[i].opCode='1';
								window._ysp_top.shoppingcart.carofferingList.push(bundle.promotionBundle.offer[i]);
								window._ysp_top.shoppingcart.quickcarofferingList.push(bundle.promotionBundle.offer[i]);
								
								// 弹出购物筐
					            var shoppingCar = $(".shoppingCar");
					 			if(shoppingCar.length == 0){
					 			 	shoppingCar = _ysp_top.$(".shoppingCar");
					 			}
					 			shoppingCar.click();
							}
						}
						
						if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("quickSelectSet"))
						{
							if (window._ysp_top.shoppingcart.quickcarofferingList.length > 0) {
								$Controller.bes.oc.productValidate.addToQuickSelectSetList(window._ysp_top.shoppingcart.quickcarofferingList);
							}
						}
							
						var item = {
								title : "快选商品融合设置",
								url : "resource.root/bes/ordercapture/html/batchbusisetforquicksel.html",
								id : "quickSelectSet",
								pageid : "resource.root/bes/ordercapture/html/batchbusisetforquicksel.html",
								httpsFlag : "",
							};
							
						window.$BES.$Portal.tabpanel.createTabItem(item);

						for(var i = 0; i < bundle.promotionBundle.promotionOffer.length;i ++){
							var prmotion = $.extend(true,{},bundle.promotionBundle.promotionOffer[i]);
							prmotion.levelBaseInfo = bundle.promotionBundle.promotionOffer[i].parentOffering;
							bundle.promotionBundle.promotionOffer[i].parentOffering={};
							prmotion.opCode = '1';
							prmotion.offeringName = prmotion.levelBaseInfo.offeringName+'(' +prmotion.offeringName+')';
							
							var hasInCarList =false;
							for(var j =0; j<window._ysp_top.shoppingcart.carofferingList.length;j++){
								if($Controller.bes.oc.productValidate.isSameOffer((window._ysp_top.shoppingcart.carofferingList[j]||{}), prmotion)){
									hasInCarList =true;
									break;
								}
							}
							if(!hasInCarList){
								$Controller.bes.oc.productValidate.assemblerPromInfo($Page,$Gadget, $Fire,prmotion);
							}
						}
					}

				} else {
					/*
					if((bundle.promotionBundle.mainOffer || []).length >0){
						//用户未鉴权，且营销包里有主offer的情况
						$Controller.bes.oc.prodDispachUrl.closePortalTab("openvicecardaccount");
						adutil
						.openTopTab(
								"60131992",
								"开户",
								"/bes/ad/html/bes-agentdesktop-openaccount.html?offeringId=" + bundle.promotionBundle.mainOffer[0].offeringId + "&#/openaccount");
						
						setTimeout(function(){
							
							bundle.promotionBundle.mainOffer=[];

							if (navigator.userAgent.indexOf("MSIE") != -1) {
							    bundle = JSON.stringify(bundle);
							}
							var curtabid = parent.tab.selectedItem().attr("innerid");
							parent.getPageById(curtabid).find("iframe")[0].contentWindow.postMessage(bundle, "*");
						},2000);

					}else{
						$Page.isFromQuickPick=true;
						$Page.isClickBtn = false;
						$Page.isOperatTab = '1';
						$Gadget.$Get('$Fire')({popup:{'id':'productorderloginpopup','title' : '客户登陆','width' : '550px','height' :'410px',
							'src':'resource.root/bes/ad/popup/bes-ad-productorderlogin.html',resizable:false}},$Gadget);

						}	
						*/		
					//未鉴权统一走鉴权页面
					$Page.isFromQuickPick=true;
					$Page.isClickBtn = false;
					$Page.isOperatTab = '1';
					$Gadget.$Get('$Fire')({popup:{'id':'productorderloginpopup','title' : '客户登陆','width' : '550px','height' :'410px',
						'src':'resource.root/bes/ad/popup/bes-ad-productorderlogin.html',resizable:false}},$Gadget);
				}
			}

		}, $Gadget);

	},
	assemblerPromInfo:function($Page,$Gadget,$Fire,prmotion){
		
		var req = {
			"offeringId" : prmotion.offeringId,
			"levelId" : prmotion.levelBaseInfo.offeringId,
			"mode" : "ChangeProduct",
			"prizes" : prmotion.prizes
		};
		$Fire(
				{
					'service' : 'ucec/v1/promforquickpick/initwithprize',
					'params' : {
						"req" : req
					},
					'target' : '$Gadget.Prom',
					'onafter' : function($Gadget, $UI) {
						debugger;
						if (!$Gadget.Prom) {
							return;
						}
						var pageProm = $.extend(true,{},$Gadget.Prom);
						window._ysp_top.shoppingcart = window._ysp_top.shoppingcart || {};
						window._ysp_top.shoppingcart.carofferingList = window._ysp_top.shoppingcart.carofferingList || [];
						window._ysp_top.shoppingcart.$Pagea = window._ysp_top.shoppingcart.$Pagea || {};
						window._ysp_top.shoppingcart.$Pagea.promInfoList = window._ysp_top.shoppingcart.$Pagea.promInfoList || [];
						window._ysp_top.shoppingcart.$Pagea.promInfoList.push(pageProm);
						window._ysp_top.shoppingcart.carofferingList.push(prmotion);
						var quickcarofferingList = [];					
						quickcarofferingList.push(prmotion);
						$Controller.bes.oc.productValidate.addToQuickSelectSetList(quickcarofferingList);
						
						// 弹出购物筐
			            var shoppingCar = $(".shoppingCar");
			 			if(shoppingCar.length == 0){
			 			 	shoppingCar = _ysp_top.$(".shoppingCar");
			 			}
			 			shoppingCar.click();
						$Gadget.$Emit("$ShoppingCartInit");

					},
					'onerror':function(){
					}
				}, $Gadget);
	},
	
	addToQuickSelectSetList:function(offerList) {
		debugger;
		
		setTimeout(function(){
			if (parent.getPageById("quickSelectSet") 
				&& parent.getPageById("quickSelectSet").find("iframe") 
				&& parent.getPageById("quickSelectSet").find("iframe")[0].contentWindow.document.readyState == "complete") {
				var msg = {
						operation : "addToQuickSelectSetList",
						offerList : offerList
					};
							
				if (navigator.userAgent.indexOf("MSIE") != -1) {
				    msg = JSON.stringify(msg);
				}

				parent.getPageById("quickSelectSet").find("iframe")[0].contentWindow.postMessage(msg, "*");
			} else {
				//修复环境慢时，数组拼接会覆盖原offer列表问题
				window._ysp_top.shoppingcart.quickcarofferingList = window._ysp_top.shoppingcart.quickcarofferingList.concat(offerList);
				//$.extend(true, window._ysp_top.shoppingcart.quickcarofferingList, offerList);
			}				
		}, 1000);
	},

    /**
	 * 判断是否同商品（兼容营销方案）
	 */
    isSameOffer : function(offer, offerCompare) {
    	if (offer && offerCompare){
    		// 默认是批次编码相同即可。
    		if (offer.offeringId == offerCompare.offeringId) {
    			// 如果存在档次，需要判断档次是否相同
    			if (offer.levelBaseInfo && offerCompare.levelBaseInfo){
    				if (offer.levelBaseInfo.offeringId == offerCompare.levelBaseInfo.offeringId){
    					return true;
    				}
    			} else {				        		
    				return true;
    			}
    		}
    	}
    	return false;
    }
});