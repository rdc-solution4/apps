(function(window) {
	window.onmessage = function(e) {
		e = e || window.event;
		var data = null;
		try {
			data = JSON.parse(e.data);
		} catch(e1) {
			data = e.data;
		}
		var operation = data.operation;
		if (undefined == operation) {
			return;
		}

		if ("On_Tab_Show" == operation) {
			$BES.$Portal.tabpanel.onShowTab();
		} else if ("On_Tab_Close" == operation) {
			$BES.$Portal.tabpanel.onCloseTab();
		}
	};

	window.$BES = window.$BES || {};

	$BES.$Portal = {
		tabpanel : {}
	};

	$BES.$Portal.tabpanel = jQuery.extend($BES.$Portal.tabpanel, {
		getTabItem : function() {
			try
			{
				if ("BES" == _ysp_top.TabSet.portalName) {
					return _ysp_top.TabSet.getTabItem();
				}
			} catch (err) {
			}
		},
		

		getAllTabItems : function() {
			try
			{
				if ("BES" == _ysp_top.TabSet.portalName) {
					return _ysp_top.TabSet.getAllTabItems();
				}				
			} catch (err) {
			}
		},
		
		// close tab
		closeTabItem : function(tabId) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.closeTabItem(tabId);
				} else {
					_ysp_top.TabSet.prototype.removeTabByCode(tabId);
				}
			} catch (err)  {
				TabSet.closeTabItem(tabId);
			}
		},

		// close all tab
		closeAllTabItem : function() {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.closeAllTabItem();
				}
			} catch (err)  {
				TabSet.closeAllTabItem();
			}
		},

		// close all tab except self
		closeAllTabItemExceptSelf : function(tabId) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.closeAllTabItemExceptOne(tabId);
				}
			} catch (err)  {
				TabSet.closeAllTabItemExceptOne(tabId);
			}
		},

		// close all tab except one tab
		closeAllTabItemExceptOne : function(tabId) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.closeAllTabItemExceptOne(tabId);
				}
			} catch (err)  {
				TabSet.closeAllTabItemExceptOne(tabId);
			}
		},

		// create tab
		createTabItem : function(item) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.createTabItem(item);
				} else {
					_ysp_top.TabSet.appendTab(item.id, item.title, item.url);
				}
			} catch (err)  {
				TabSet.createTabItem(item);
			}
		},

		createTabItemByConf : function(id, title, url, pageid, httpsFlag, openMode, tabType) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.createTabItemByConf(id, title, url, pageid,
							httpsFlag, openMode, tabType);
				} else {
					_ysp_top.TabSet.appendTab(id, title, url);
				}
			} catch (err) {
				TabSet.createTabItemByConf(id, title, url, pageid, httpsFlag, openMode, tabType);
			}
		},

		showTabItem : function(tabId) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.showTabItem(tabId);
				}
			} catch (err) {
				TabSet.showTabItem(tabId);
			}
		},


		refreshTabItem : function(id, title, url, httpsFlag) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.refreshTabItem(id, title, url, httpsFlag);
				}
			} catch (err) {
				TabSet.refreshTabItem(id, title, url, httpsFlag);
			}
		},

		hideTabItem : function(tabId) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.hideTabItem(tabId);
				}
			} catch (err) {
				TabSet.hideTabItem(tabId);
			}
		},

		addShortCut : function(menuId, menuName, menuUrl, menuImg, httpsFlag, openMode, tabType) {
			try {
				if ("BES" == _ysp_top.TabSet.portalName) {
					_ysp_top.TabSet.addShortCut(menuId, menuName, menuUrl, menuImg,
							httpsFlag, openMode, tabType);
				}
			} catch (err) {
				TabSet.addShortCut(menuId, menuName, menuUrl, menuImg,
						httpsFlag, openMode, tabType);
			}
		},

		onShowTab : function() {
		},

		onCloseTab : function() {
		},

		init : function() {
			if (navigator.userAgent.indexOf("MSIE") != -1) {
				window.attachEvent('onmessage', onmessage);
			} else {
				window.addEventListener('message', onmessage, false);
			}
		}
	});

	$BES.$Portal.tabpanel.init();

	window.jCRM = {
		BuziTabMgr : {
			main : {}
		}
	};
	window.jCRM.BuziTabMgr.main.showTabItemByConf = window.$BES.$Portal.tabpanel.createTabItemByConf;

})(window);
