$Controller("besOcRollBack", {
	showStep1 : function($Page) {
		$Page.paymentContentFlag = false;
		$("#transferAcctIndex").show();
		$("#paymentContent").hide();
		$("body").scrollTop(0);
	},

	assembleOrderDetail : function(receptionDetail) {
		debugger;
		// 桩数据 end
		if (receptionDetail) {
			var orderDetail = {};
			// 经办人信息转换
			orderDetail.agentName = receptionDetail.agentName;
			orderDetail.agentNumber = receptionDetail.agentNumber;
			orderDetail.agentCertType = receptionDetail.agentCertType;
			orderDetail.agentCertNumber = receptionDetail.agentCertNumber;
			orderDetail.agentCertAddr = receptionDetail.agentCertAddr;
			// 业务类型转换
			orderDetail.businessCode = receptionDetail.bizCode;
			// 扩展信息
			orderDetail.attr = receptionDetail.attrs;

			// 角色类型
			orderDetail.invoiceRole = receptionDetail.invoiceRole;

			// 费用列表转换
			orderDetail.feeItemList = [];
			orderDetail.discountAmount = 0;
			$.each(receptionDetail.receptionInvoiceItem || [],
					function(i, vali) {
						var feeItem = {
							"chargeItemId" : vali.chargeCode,
							"feeClassId" : vali.parentChargeName,
							"orderFee" : vali.amount,
							"discount" : vali.waiveAmount,
							"payType" : vali.payType,
							"unitPrice" : vali.unitPrice,
							"quantity" : vali.quantity,
							"chargeName" : vali.chargeName,
							"feeType" : vali.feeType
						};
						orderDetail.feeItemList.push(feeItem);

						// 计算总的优惠金额，用于展示支付信息优惠金额
						orderDetail.discountAmount += (vali.waiveAmount || 0);
					});

			// 支付状态
			if (receptionDetail.receptionPayment) {
				orderDetail.paymentStatus = "正常";
			} else {
				orderDetail.paymentStatus = "未支付";
			}
			// 支付列表
			orderDetail.businessList = [];
			orderDetail.paidFee = 0;
			$.each(receptionDetail.receptionPayment || [], function(i, vali) {
				var business = {
					"businessId" : vali.paymentId,
					"bankName" : "",
					"bankAcct" : "",
					"paymentType" : vali.paymentMethod,
					"businessFee" : vali.amount,
					"businessTime" : vali.paymentDate,
					"status" : vali.status
				};
				orderDetail.businessList.push(business);

				// 原有订单详情组装支付时间,已付费用方式
				orderDetail.paymentTime = receptionDetail.paymentDate;
				orderDetail.paidFee += vali.amount;
			});

			return orderDetail;
		} else {
			return null;
		}
	},

	assembleOrderDetail1 : function(receptionDetail) {
		debugger;
		if (receptionDetail) {
			var orderDetail = {};
			// 经办人信息转换
			orderDetail.agentName = receptionDetail.agentName;
			orderDetail.agentNumber = receptionDetail.agentNumber;
			orderDetail.agentCertType = receptionDetail.agentCertType;
			orderDetail.agentCertNumber = receptionDetail.agentCertNumber;
			orderDetail.agentCertAddr = receptionDetail.agentCertAddr;
			// 扩展信息
			orderDetail.attr = receptionDetail.attrs;

			// 费用列表转换
			orderDetail.feeItemList = [];
			orderDetail.discountAmount = 0;
			$.each(receptionDetail.receptionInvoiceItem || [],
					function(i, vali) {
						var feeItem = {
							"chargeItemId" : vali.invoiceItemId,
							"feeClassId" : vali.parentChargeName,
							"orderFee" : vali.amount,
							"discount" : vali.waiveAmount,
							"payType" : vali.payType,
							"unitPrice" : vali.unitPrice,
							"quantity" : vali.quantity,
							"chargeName" : vali.chargeName,
							"feeType" : vali.feeType
						};
						orderDetail.feeItemList.push(feeItem);

						// 计算总的优惠金额，用于展示支付信息优惠金额
						orderDetail.discountAmount += (vali.waiveAmount || 0);
					});

			// 支付状态
			if (receptionDetail.receptionPayment) {
				orderDetail.paymentStatus = "正常";
			} else {
				orderDetail.paymentStatus = "未支付";
			}
			// 支付列表
			orderDetail.businessList = [];
			orderDetail.paidFee = 0;
			$.each(receptionDetail.receptionPayment || [], function(i, vali) {
				var business = {
					"businessId" : vali.paymentId,
					"bankName" : "",
					"bankAcct" : "",
					"paymentType" : vali.paymentMethod,
					"businessFee" : vali.amount,
					"businessTime" : vali.paymentDate,
					"status" : vali.status
				};
				orderDetail.businessList.push(business);

				// 原有订单详情组装支付时间,已付费用方式
				orderDetail.paymentTime = receptionDetail.paymentDate;
				orderDetail.paidFee += vali.amount;
			});

			orderDetail = orderDetail;
			serviceRequest = {};
			return orderDetail;
		}
		return null;
	},

	// 去结算页面
	goToCheckout : function($Page) {
		debugger;
		// 防止重复提交
		if ($Page.goToCheckoutFlag) {
			return;
		}

		$Page.goToCheckoutFlag = true;

		$Page.checkoutInfo = {
			serviceNumber : $Page.checkedItem.serviceNumber,
			businessName : "回退"
		};

	}
});