
	//切换选择项的样式
	//flag 范围标识
	//count 标识的元素总个数
	//index 当前点击元素的坐标
	function changeBgc(flag,count,index)
	{				
		for( var i = 0 ; i <= count ; i++)
		{		
			$('#'+flag+i).removeClass('span_selected');
		}
		$('#'+flag+index).addClass('span_selected');
				
	}
	
	function changeBgc2(flag,count,index)
	{				
		for( var i = 0 ; i <= count ; i++)
		{		
			$('#'+flag+i).removeClass('span_selected2');
		}
		$('#'+flag+index).addClass('span_selected2');
				
	}
	
	function changeBgc3(flag,count,index)
	{				
		for( var i = 0 ; i <= count ; i++)
		{		
			$('#'+flag+i).removeClass('span_selected3');
		}
		$('#'+flag+index).addClass('span_selected3');
				
	}
	
	function changeBgc4(flag,index)
	{				
		$('#'+flag+index).toggleClass('span_selected');
				
	}
	
	//套餐详情 TAB页切换
	//flag 范围标识
	//count 标识的元素总个数
	//index 当前点击元素的坐标
	//oriBc 元素类名称
	//targetBc 目标类名称
	//flag2 标识不同tab页控制的显示范围
	function changeTab(flag,count,index,oriBc,targetBc,flag2)
	{		
		for( var i = 0 ; i <= count ; i++)
		{
			$('#'+flag+i).removeClass(targetBc);
			$('#'+flag+i).addClass(oriBc);
			if(flag2)
			$('#'+flag2+i).hide();
		}
		$('#'+flag+index).removeClass(oriBc);
		$('#'+flag+index).addClass(targetBc);
		if(flag2)
			$('#'+flag2+index).show();
	}
	
	//鼠标放上样式
	function mouseOver(obj)
	{
		$(obj).removeClass();
		$(obj).addClass("mouseOverClass");

	}
	
	//鼠标离开样式
	function mouseOut(obj)
	{
		$(obj).removeClass();
		$(obj).addClass("mouseOutClass");
	}
	
	
	function mouseOver1()
	{
		document.image1.src ="../resources/default/images/step_09.png"
	}
	function mouseOut1()
	{
		document.image1.src ="../resources/default/images/step_03.png"
	}
	function mouseOver2()
	{
		document.image2.src ="../resources/default/images/step_09.png"
	}
	function mouseOut2()
	{
		document.image2.src ="../resources/default/images/step_03.png"
	}

	//切换收藏按钮
	function toggleFavorite()
	{
		if($(event.srcElement).attr("value") == "收藏")
		{
			alert("收藏成功");
			$(event.srcElement).attr("value","取消");
		}
		else 
		{
			alert("取消收藏成功");
			$(event.srcElement).attr("value","收藏");
		}
	}
	
	//切换订购按钮
	function toggleBuy(element)
	{		
		if($(element).attr("value") == "订购")
		{
			$(element).attr("value","取消");
			return "订购";
		}
		else 
		{
			alert("取消成功");
			$(element).attr("value","订购");
			return "取消";
		}
	}
	
	function validateData(validate)
	{         
		var isSuccess=true;
		cancelStyle();
		validate = validate.replace('\specialCharacterDouble','"');
		validate=validate.replace('\specialCharacterSingle',"'");
		validate=validate.replace('\specialCharacterAdd',"\\+");
		validate=validate.replace('\specialCharacterRBracket',"\\)");
		var patrn =validate;
		var selectCtrlArray = document.getElementsByTagName("INPUT");
		for(var i =0;i < selectCtrlArray.length;i++)
		{   
			if (selectCtrlArray[i].type=="text" && !selectCtrlArray[i].readOnly && !selectCtrlArray[i].disabled)
			{      
				var r = new RegExp();   
				r.compile(patrn);   
				if(r.test(selectCtrlArray[i].value))
				{ 
					if(window.addEventListener)
					{ 
						selectCtrlArray[i].addEventListener('onchange', controlStyle, false);   
					} 
					else 
					{   
						selectCtrlArray[i].oldBorderColor = selectCtrlArray[i].style.borderColor;
						$(selectCtrlArray[i]).addClass("cbme_invalid");
						selectCtrlArray[i].attachEvent('onchange', controlStyle);  
					}
					isSuccess=false;
				}  
			}
		}
	     
		var selectCtrlArray = document.getElementsByTagName("TEXTAREA");  
		for(var i =0;i < selectCtrlArray.length;i++)
		{   
			if (!selectCtrlArray[i].readOnly && !selectCtrlArray[i].disabled)
			{
				var r = new RegExp();   
				r.compile(patrn);   
				if(r.test(selectCtrlArray[i].value))
				{ 
					if(window.addEventListener)
					{ 
						selectCtrlArray[i].addEventListener('onchange', controlStyle, false);   
					} 
					else 
					{    
						selectCtrlArray[i].oldBorderColor = selectCtrlArray[i].style.borderColor;
						selectCtrlArray[i].style.borderColor="#FB5A2F";
						$(selectCtrlArray[i]).addClass("cbme_invalid");
						selectCtrlArray[i].attachEvent('onchange', controlStyle);  
					}
					isSuccess=false;        
				}
			}
		}
		
		if (!isSuccess)
		{
			alert("红色文本框内的数据包含特殊字符请检查");
		}
	     
		return isSuccess;
	}

	/**
	 * 选择军官证类型,校验输入的军官证号码是否符合三位中文汉字+数字（6-10位）的规则
	 * @remark create swx190332 OR_CHQ_201211_208
	 */
	 function checkPLAIdRule(certType,inputPLAId)
	 {
	    if("PLA" != certType)
	    {
	       return true;
	    }
	    var inputPLAIdFormat = /^[\u4e00-\u9fa5]{3}\d{6,10}$/;
	    if(!inputPLAIdFormat.test(inputPLAId))
	    {
	        alert('军官证号码格式有误,请重新输入!\n注：三位中文汉字+数字(6-10位)');
	        return false;
	    }
	    return true;
	 }
	 
	/**
	 *检查是否存在非法字符
	 *@return true表示存在 false 表示不存在
	 */
	function validateExpressChar(validate,name)
	{
	    cancelStyle();
	    validate=validate.replace('\specialCharacterDouble','"');
	    validate=validate.replace('\specialCharacterSingle',"'");
		validate=validate.replace('\specialCharacterAdd',"\\+");
		validate=validate.replace('\specialCharacterRBracket',"\\)");
	    var patrn =validate;
	    var regExp = new RegExp();   
	    regExp.compile(patrn);   
	    if(!regExp.test(name.value))
	    {
	        return false;
	         	
	    }
	    if(window.addEventListener)
	    { 
	     	name.addEventListener('onchange', controlStyle, false);   
	    } 
	    else 
	    { 
	    	 name.oldBorderColor = name.style.borderColor;
	         name.style.borderColor="#FB5A2F";
	         name.attachEvent('onchange', controlStyle);  
	    }
	    return true;
	}
	
	function cancelStyle()
	{
		var selectCtrlArray = document.getElementsByTagName("INPUT");  
		for(var i =0;i < selectCtrlArray.length;i++)
		{
			if (selectCtrlArray[i].type=="text")
			{  
				$(selectCtrlArray[i]).removeClass("cbme_invalid");
				selectCtrlArray[i].detachEvent('onchange', controlStyle);
			}  
			if (selectCtrlArray[i].type=="textarea")
			{  
				if (selectCtrlArray[i].oldBorderColor != undefined) 
				{
					selectCtrlArray[i].style.borderColor=selectCtrlArray[i].oldBorderColor;
				}
				selectCtrlArray[i].detachEvent('onchange', controlStyle)
			} 
		}
	}
	
	function controlStyle()
	{
		var e =  window.event;
	    var object=e.srcElement;
	    if (object.type=="text")
	    {
	    	$(object).removeClass("cbme_invalid");
	    }
	    if (object.type=="textarea")
	    {
			if (object.oldBorderColor != undefined) 
			{
				object.style.borderColor=object.oldBorderColor;
	        }
	    }
	    e.srcElement.detachEvent('onchange', controlStyle)
	}
	
	//小键盘读取密码
	function readPassword(password,repassword)
	{
		try
	    {
			var passwordObj = document.getElementById(password+"_input_value");
			passwordObj.value = "";
            
            var pwd1 = document.getElementById("KeyCard1").ReadKey1();
            if(pwd1.length != 6)
            {
                alert("密码必须为6位!");
                logStepUncontroledStopped("End","","831086");
                return false;
            }

            var pwd2 = document.getElementById("KeyCard1").ReadKey2();
            if(pwd2.length != 6)
            {
                alert("密码必须为6位!");
                logStepUncontroledStopped("End","","831086");
                return false;
            }
            if(pwd1 != pwd2)
            {
                alert("密码不一致!");
                logStepUncontroledStopped("End","","831087");
                return false;
            }

            var repasswordObj = document.getElementById(repassword+"_input_value");
            if(repasswordObj)
            {
                repasswordObj.value = pwd1;
            }
            passwordObj.value = pwd1;
            passwordObj.focus();
	    }
	    catch(e)
	    {
	    	logStepUncontroledStopped("End","","8310147");
	    	alert("小键盘硬件读取异常:"+e+"!");
            return false;
	    }
	}

    /**
     * 读取二代证
     * @return
     */
    function read2ndCertInfo(otherEvmsPrintUrl, busiInfoXML, tokenXML)
    {
        // 调用无纸化平台令牌生成接口，获取返回报文
        var tokenNum = null;
        
        // 解析XML
        var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
        xmlDoc.async = "false";
        xmlDoc.loadXML(tokenXML);
        if (xmlDoc.documentElement != null)
        {
            xmlNode = xmlDoc.getElementsByTagName("resp")[0];

            // 返回码；0 获取令牌成功，1 错误工号请求 2 错误功能请求 3 请求超时 4 其他错误-->
            var retcode = xmlNode.childNodes[0].text;

            // 返回内容
            var retMsg = xmlNode.childNodes[1].text;

            // 单据号
            var ticket = xmlNode.childNodes[2].text;

            if(retcode != '0')
            {
                alert("调用无纸化平台报错：" + retMsg);
                logStepUncontroledStopped("End","","8310088");
                return false;
            }
            else
            {
                tokenNum = ticket;
            }
        }
        
        // 打开外围无纸化平台界面并返回返回证件信息
        var randomVal = getNowDateTime(true) + getRndNum(6) + "";
        var url = otherEvmsPrintUrl + "&cardInfo=" + busiInfoXML+ "&ticket=" + tokenNum + "&serialNo=" + randomVal;
        var style = "dialogWidth:800px;dialogHeight:600px;edge:Raised;center:Yes;help:No;resizable:no;status:No;";
        var pop = window.open(url, "", style);

        // 新窗口显示在最前面
        pop.focus();

        // 定时器循环监听弹出窗口是否关闭，如已关闭则从粘贴板中获取数据进行处理
        var chkLoaded = window.setInterval(function() {
            if (!(pop) || pop.closed)
            {
                // 关闭循环监听
                window.clearInterval(chkLoaded);

                // 获取证件信息
                var certInfo = readEvmsCardInfo(randomVal);
                
                // 回填证件信息
                initCertInfo(certInfo)
            }
        }, 500);
    }

    /**
    * 获取证件信息
    * @remark create cWX143640 2012-03-18 R003C13L03n01 OR_CHQ_201302_614
    */
    function readEvmsCardInfo(randomVal)
    {
        // 返回对象
        var obj = new Object();
        
        // 获得系统文件夹对象
        var fso = new ActiveXObject("Scripting.FileSystemObject");
        var systemFolder = fso.GetSpecialFolder(1);        
        if (fso.FileExists(systemFolder.Path + "\\HWUtilOCX.ocx"))
        {
            var filePath = "c:\\RETXML" + randomVal + ".txt";        
            
            var rtnInfo = document.getElementById("HWUtilOCX").ReadFile(filePath);
            if (rtnInfo != '')
            {
                /**rtnInfo='<?xml version="1.0" encoding="UTF-8"?><resp><name>丁毅</name><e_name>未知</e_name><sex>男</sex><nation>未知</nation><ethnic>汉</ethnic><birthday>19880828</birthday>'+
                //'<address>四川省开江县长岭镇</address><card_no>51302319880828XXXX</card_no><issue_org>开江县公安局</issue_org><issue_date>未知</issue_date><card_type>0</card_type><b_valid_date>20080129</b_valid_date>'+
                //'<e_valid_date>20180129</e_valid_date><remarks>未知</remarks><base_string></base_string></resp>';*/
                // 解析XML
                var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
                xmlDoc.async="false";
                xmlDoc.loadXML(rtnInfo) ;
                
                if (xmlDoc.documentElement != null)
                {
                    var nodesLength = xmlDoc.getElementsByTagName("resp").length;
                    if (nodesLength > 0)
                    {
                        xmlNode = xmlDoc.getElementsByTagName("resp")[0];
                        
                        // 姓名
                        var name = xmlNode.childNodes[0].text;
                        obj.name = name;
                        
                        // 英文姓名
                        var e_name = xmlNode.childNodes[1].text;
                        obj.e_name = e_name;
                        
                        // 性别
                        var sex = xmlNode.childNodes[2].text;
                        obj.sex = sex;
                        
                        // 国籍
                        var nation = xmlNode.childNodes[3].text;
                        obj.nation = nation;
                        
                        // 民族
                        var ethnic = xmlNode.childNodes[4].text;
                        obj.ethnic = ethnic;
                        
                        // 出生日期
                        var birthday = xmlNode.childNodes[5].text;
                        obj.birthday = birthday;
                        
                        // 地址
                        var address = xmlNode.childNodes[6].text;
                        obj.address = address;
                        
                        // 证件号码
                        var card_no = xmlNode.childNodes[7].text;
                        obj.card_no = card_no;
                        
                        // 颁发机关
                        var issue_org = xmlNode.childNodes[8].text;
                        obj.issue_org = issue_org;
                        
                        // 颁发日期
                        var issue_date = xmlNode.childNodes[9].text;
                        obj.issue_date = issue_date;
                        
                        // 证件类型0-二代身份证
                        var card_type = xmlNode.childNodes[10].text;
                        obj.card_type = card_type;
                        
                        // 开始有效期
                        var b_valid_date = xmlNode.childNodes[11].text;
                        obj.b_valid_date = b_valid_date;
                        
                        // 结束有效期
                        var e_valid_date = xmlNode.childNodes[12].text;
                        obj.e_valid_date = e_valid_date;
                        
                        // 备注
                        var remarks = xmlNode.childNodes[13].text;
                        obj.remarks = remarks;
                        
                        // 图片Base64串
                        var base_string = xmlNode.childNodes[14].text;
                        obj.base_string = base_string;
                    }
                }
            }
            else
            {
                alert("通过【HWUtilOCX.ocx】控件获取无纸化返回报文为空！");
                logStepUncontroledStopped("End","","8310089");
            }
        }
        else
        {
            alert("通过【HWUtilOCX.ocx】控件获取无纸化返回报文失败！");
            logStepUncontroledStopped("End","","8310090");
        }
        return obj;
    }

	/**
	 * 通过业务规则检查
	 * @returns {Boolean}
	 */
	function confirmPassRecRuleCheck()
	{
		var recRuleCheckFlag = window.recRuleCheck;
		if(recRuleCheckFlag && recRuleCheckFlag == 'true')
		{
			return true;
		}
		return false;
	}
	
    //如果"证件类型"或"证件号码"发生onchange事件时调用该函数,
    //只有操作员有"CanUseJSX"令牌时"证件类型"才可以选择"介绍信",
    //并且如果证件类型选择了"介绍信",那么证件号码必须满足已JSX打头的格式.
    //参数说明:
    //certType:证件类型id
    //certId:证件号码id
    //recType:业务类型(开户有一点特殊逻辑)
    //isCanUseJSX:操作员是否有办理介绍信业务的令牌
    function jsxBusiness(certType, certId, recType, isCanUseJSX)
    {
        //"证件类型"下拉框对象
        var certTypeObj = document.getElementById(certType);
        var oldValue = certTypeObj.oldValue;
        var newValue = certTypeObj.value;
        if(newValue == 'JSX')
        {
            if(!isCanUseJSX)
            {
                alert('无权使用介绍信办理业务！');
                certTypeObj.value = oldValue;
                return false;
            }

            //"证件号码"对象
            var certIdTextObj = document.getElementById(certId);
            var certIdTextValue = certIdTextObj.value;
            if(certIdTextValue != '')
            {
                //验证"介绍信"的正则表达式:只能以JSX打头,并且JSX后面至少一位.
                var jsxFormat = /^JSX\w+$/;
                if(!jsxFormat.test(certIdTextValue))
                {
                    alert('介绍信号码格式有误，请重新输入！\n注：必须以JSX打头，JSX后跟一个或多个字符。');
                    certIdTextObj.value = '';
                    if(recType == 'Install')
                    {
                        document.getElementById('certID_input_value').value = '';
                    }
                    return false;
                }
            }
        }
    }

    //当鼠标放到控件上时执行onmousemove事件,控件当前值设置到新建属性oldValue中,
    //便于控件的值改变后还可以取到上一次的值.
    function setObjOldValue(id)
    {
        var certTypeObj = document.getElementById(id);
        certTypeObj.onmousemove = function()
        {
            this.oldValue = this.value;
        }
    }
    
    /**
     *功能：判断是否是合法的电话号码
     */
    function validatePhone(value)
    {
        return /(^[0-9]{3,4}\-[0-9]{7,8}$)|(^[0-9]{7,8}$)|(^\([0-9]{3,4}\)[0-9]{7,8}$)|(^0{0,1}13[0-9]{9}$)|(^0{0,1}[0-9]{10,11}$)/.test(value);
    }
    /*
     * 检查电话号码是否是11位移动手机号
     */
    function validateCMMobile_(value) 
    {
    	 var reg = /^13[4-9]\d{8}$/;
    	 var reg2 = /^15([0-3]|[7-9])\d{8}$/;
    	 var reg3 = /^18[2,3,7-8]\d{8}$/;
    	 var reg4 = /^0317\d{7}$/;
    	 var reg5 = /^147\d{8}$/;
    	 return  ( (reg.test(value)) || (reg2.test(value)) || (reg3.test(value)) || (reg4.test(value)) || (reg5.test(value)) );
    }
    
    /**
     *功能：对于输入的有html标签的东西进行字符转换
     */
    function replaceUnlikelihood()
	{       
         var selectCtrlArray = document.getElementsByTagName("INPUT");
         var selectTextareaArray = document.getElementsByTagName("TEXTAREA");
        
         for(var i =0;i<selectCtrlArray.length;i++)
         {   
	         if (selectCtrlArray[i].type=="text" )
	         {
                var str=selectCtrlArray[i].value; 
                str = str.replace(/\>/g, "&gt;");    
                str = str.replace(/\</g, "&lt;");    
                str = str.replace(/\"/g, "&quot;");    
                str = str.replace(/\'/g, "&#39;");    
                selectCtrlArray[i].value=str;
	         }
         }
         for(var i =0;i<selectTextareaArray.length;i++)
         {
            var str=selectTextareaArray[i].value;  
            str = str.replace(/\>/g, "&gt;");    
            str = str.replace(/\</g, "&lt;");    
            str = str.replace(/\"/g, "&quot;");    
            str = str.replace(/\'/g, "&#39;");    
            selectTextareaArray[i].value=str;
     	 }
	} 
    //检查身份证号码合法性
	function checkIDNo(IDNO,minYear)
	{
	    if((IDNO.length == 15)||(IDNO.length == 18))
		{
			var year ;
			var month ;
            var day;
			if (IDNO.length == 15)
			{
				if(isNaN(IDNO))
				{
					alert("15位身份证必须为数字!");
					return false;
				}
				year= "19"+IDNO.substring(6, 8);
				month= IDNO.substring(8, 10);
				day= IDNO.substring(10, 12);
			}
			else
			{
				if(isNaN(IDNO.substring(0, 17)))
				{
					alert("18位身份证前17位必须为数字!");
					return false;
				}
				year= IDNO.substring(6, 10);
				month= IDNO.substring(10, 12);
				day= IDNO.substring(12, 14);
			}
			//如果身份证号字符串合法，则判断年的正确性
			if(!minYear)
			{
				minYear = 1800;
			}
			if (year < minYear)
			{
				alert("身份证号码出错:"+ "，出生年（" + year + "）太小");
				return false;
			}
			else if (year > new Date().getYear())
			{
				alert("身份证号码出错:"+  "，出生年（" + year + "）太大（大于今年）");
				return false;
			}
			else
			{
				//如果年也合法，则判断月的正确性
				//month
				if (month < 1)
				{
					alert("身份证号码出错:"+  "，出生月（" + month + "）太小");
					return false;
				}
				else if (month > 12)
				{
					alert("身份证号码出错:"+  "，出生月（" + month + "）太大");
					return false;
				}
				else
				{
					//如果月也合法，则判断日的正确性
					//day
					var dayMax = 31;
					if (month == 2)
					{
						if (year % 100 == 0)
						{
							if (year % 400 == 0)
							{
								dayMax = 29;
							}
							else
							{
								dayMax = 28;
							}
						}
						else
						{
							if (year % 4 == 0)
							{
								dayMax = 29;
							}
							else
							{
								dayMax = 28;
							}
						}
					}
					if (month == 4 || month == 6 || month == 9 || month == 11)
					{
						dayMax = 30;
					}
					if (day < 1)
					{
						alert("身份证号码出错:"+  "，出生日（" + day + "）太小");
						return false;
					}
					if (day > dayMax)
					{
						alert("身份证号码出错:"+ "，出生日（" + day + "）太大（大于" + dayMax + "）");
						return false;
					} //day
				}//month
			} //year
		}
		else
		{
			alert("身份证必须为15位或者18位！");
			return false;
		}
		return true;
	}

    /** 
     * 获取相应位数的随机数
     */
    function getRndNum(n)
    {
        var rnd = "";
        for (var i = 0; i < n; i++)
        {
            rnd += Math.floor(Math.random() * 10);
        }
        return rnd;
    }

	/**
	 * 得到YYYY-MM-DD hh:mm:ss格式的当前日期时间
	 */
	function getNowDateTime(isNoSpaceMark)
	{
		var now = new Date();
		var year = now.getYear();
		var month = now.getMonth()+1;
		var date = now.getDate();
		var hh = now.getHours();
		var mm = now.getMinutes();
		var ss = now.getSeconds();
		if (month < 10)
		{
			month = "0" + month;
		}
		if (date < 10)
		{
			date = "0" + date;
		}
		if (hh < 10)
		{
			hh = "0" + hh;
		}
		if (mm < 10)
		{
			mm = "0" + mm;
		}
		if (ss < 10)
		{
			ss = "0" + ss;
		}
        var dt;
        if (isNoSpaceMark)
        {
            dt = year + month + date + hh + mm + ss + "";
        }
        else
        {
            dt = year + "-" + month + "-" + date + " " + hh + ":" + mm + ":" + ss;
        }
        return dt;
    }

	/**
	 * 得到YYYY-MM-DD格式的当前日期
	 */
	function getNowDate() 
	{
		var now = new Date();
		var year = now.getYear();
		var month = now.getMonth()+1;
		var date = now.getDate();
		if (month < 10)
		{
			month = "0" + month;
		}
		if (date < 10)
		{
			date = "0" + date;
		}
		var dt = year + "-" + month + "-" + date;
		return dt;
	}
	/*-- 全局只允许一个购物车 
	* submitType 提交类型：0：icrm营业厅提交； 10086：客服提交；sample：简单提交；
	*                      10086ShoppingCart：客服购物车提交； esopShoppingCart ：重庆ESOP购物车提交
	--*/
    function onlyOneShoppingCart(submitType)
    {
    	/*-- 客服内嵌 --*/
	    if(submitType == '10086' || submitType == 'sample'||submitType == 'esopShoppingCart')
	    {
	    	return true;
	    }
        var canCommit = true;
        var mainTab = _ysp_top.publicObject["mainTab"];
        var openMenu = _ysp_top.publicObject["openMenu"];
        var curTab = obtainCurTabCode(mainTab);
        
        //是否要在用户标签页下打开购物车
        var openSubTab = false;
        
        //在用户登陆标签页下打开的，则需要在用户标签页下打开购物车
        if(curTab.indexOf("BOSS^") == 0)
        {
           openSubTab = true;
        }
        var menuID = "BLPUB_ShoppingCart";
        var menuName = "购物车";
        var menuUrl = obtainWebContextPath("custsvc")+"/business.action?BMEBusiness=bundles.balanceCommit";
        
        //登陆用户
        var customer;            
        for(var tmp in  _ysp_top.publicObject["container"].customers)
        {
            if(null != tmp)
            {
                customer = _ysp_top.publicObject["container"].customers[tmp];
            }
        }

        if(customer != null )
        {
            if(mainTab.hasTab(menuID) && openSubTab)
            {
                alert("请先提交关闭顶层购物车，否则无法打开用户" + customer.id + "的购物车！");
                canCommit = false;
            }
            else
            {
                var custShoppingCart = "BOSS^" + customer.id + "^BLPUB_ShoppingCart~" + customer.id;
                //当前登陆用户的页签ID                   
                var userTabSetCode = "BOSS^" + customer.id;   
                 
                 //开着用户购物车
                if(undefined != _ysp_top.publicObject[userTabSetCode] && _ysp_top.publicObject[userTabSetCode].hasTab(custShoppingCart) && !openSubTab)
                {
                    alert("请先提交关闭用户" + customer.id + "的购物车，否则无法打开新的购物车！");
                    canCommit = false;
                 }
            }
        }
        return canCommit;
    }

    // 提交之后,三秒之内不可重复提交 
    function setAcctBtnDisableTimer()
    {
        setAccountBtndisabled("disabled");
        setTimeout("setAccountBtndisabled('')", 3000);
    }

    // 设置去结算和加入购物车按钮是否可用 
    function setAccountBtndisabled(disabled)
    {
    	// 根据样式来查找按钮,并设置置灰属性
        $("A[class*='account_btn']").attr("disabled", disabled);
        $("A[class*='shoppingcart_btn']").attr("disabled", disabled);
    }

    /*-- 去结算&购物车 去结算&购物车 0代表加入购物车，1代表去结算 
	* submitType 提交类型：0：icrm营业厅提交； 10086：客服提交；sample：简单提交；
	*                      10086ShoppingCart：客服购物车提交； esopShoppingCart ：重庆ESOP购物车提交
	* innerEsopRemoveMenuId:重庆ESOP框架中需要关闭的当前iCRM菜单编号
	* esopOpenTabAddr : 重庆ESOP中打开菜单的URL，在系统参数中配置
	* esopRemoveTabAddr : 重庆ESOP中打开菜单的URL，在系统参数中配置
	--*/
    function openBanlanceCommit(obj,submitType, recType,innerEsopRemoveMenuId,esopOpenTabAddr,esopRemoveTabAddr)
    {
    	//add by s00194076 2013-10-28 发送一个请求，用于监控加入购物车动作  
    	if(undefined != recType)
    	{
    		$.post(obtainWebContextPath("custsvc")+"/Blank_.jsp?_BOME_recType=" + recType);
    	}
    	
		//增加对重庆ESOP嵌入功能的支持，当嵌入重庆ESOP时，使用ESOP框架打开购物车菜单，同时关闭当前菜单
		if('esopShoppingCart' == submitType)
	    {
			//去结算时，需要打开购物车界面
			if(obj=='1')
			{
				openTabInnerEsop('BLPUB_ShoppingCart','购物车',obtainWebContextPath("custsvc")+"/business.action?BMEBusiness=bundles.balanceCommit",esopOpenTabAddr);
				// modify by f00186409 2015-03-19 OR_HEB_201502_54 代理商WEB专区_产品统一支撑方案 begin
				if (undefined !=esopOpenTabAddr && esopOpenTabAddr.length > 0 && esopOpenTabAddr.indexOf('cmcvs') < 0)
				{
					window.setTimeout(function(){removeTabInnerEsop(innerEsopRemoveMenuId,esopRemoveTabAddr);},1000);
				}
				// modify by f00186409 2015-03-19 OR_HEB_201502_54 代理商WEB专区_产品统一支撑方案 end
			}
			else
			{
				alert("加入购物车成功");
				removeTabInnerEsop(innerEsopRemoveMenuId,esopRemoveTabAddr);
			}
			
			return true;
		}
    	else if(submitType == '10086')
	    {
	    	$("#orderSubmitFor10086").trigger("orderSubmit");
			return true;
	    }
    	else if(submitType == 'sample')
	    {
	    	$("#orderSubmitForSample").trigger("orderSubmit");
			return true;
	    }
    	var mainTab = _ysp_top.publicObject["mainTab"];
        var openMenu = _ysp_top.publicObject["openMenu"];
        var curTab = obtainCurTabCode(mainTab);
        
        //是否要在用户标签页下打开购物车，默认为否
        var openSubTab = false;
        
        //在用户登陆标签页下打开的业务，则需要在用户标签页下打开购物车
        if(curTab.indexOf("BOSS^") == 0)
        {
           openSubTab = true;
        }
        
        var menuID = "BLPUB_ShoppingCart";
        var menuName = "购物车";
        var menuUrl = obtainWebContextPath("custsvc")+"/business.action?BMEBusiness=bundles.balanceCommit";
        
        var customer = _ysp_top.publicObject["container"].getFocus();
        
        //去结算  
        if(obj=='1')
        {
            if(mainTab.hasTab(menuID))
            {
                if(openSubTab  && customer != null)
                {
                   alert("请先提交并关闭顶层购物车，切换到用户" + customer.id + "标签页再打开购物车查看");
                   hideTabByCode(curTab);
                   return;
                }
                else 
                {                   
                   mainTab._focusTab(menuID);
                   mainTab.refresh(menuID);
                }
            }
            else
            {
                if(customer == null )
                {
                    openMenu(menuID,menuName,menuUrl);
                }
                else
                {
                    var custShoppingCart = "BOSS^" + customer.id + "^BLPUB_ShoppingCart~" + customer.id;
                    //当前登陆用户的页签ID                   
                    var userTabSetCode = _ysp_top.publicObject["mainTab"].sSelectedTabCode;   
                     
                     //开着用户购物车
                    if(_ysp_top.publicObject[userTabSetCode].hasTab(custShoppingCart))
                    {                   
                       if(openSubTab)
                       {
                            _ysp_top.publicObject[userTabSetCode]._focusTab(custShoppingCart);
                            _ysp_top.publicObject[userTabSetCode].refresh(custShoppingCart);
                       }
                       else
                       {
                           alert("请先关闭用户" + customer.id + "的购物车，切换到非此用户标签页后再打开购物车查看");
                           hideTabByCode(curTab);
                           return;
                        }
                    }
                    else
                    {
                        openMenu(menuID,menuName,menuUrl);
                    }
                }
            }
        }
        else
        {
            alert("加入购物车成功");
            
            if(mainTab.hasTab(menuID))
            {
                if(!openSubTab  || customer == null)
                {
                	 mainTab._focusTab(menuID);
                     mainTab.refresh(menuID);
                }
            }
            else
            {
                if(customer != null)
                {
                    var custShoppingCart = "BOSS^" + customer.id + "^BLPUB_ShoppingCart~" + customer.id;
                    //当前登陆用户的页签ID                   
                    var userTabSetCode = _ysp_top.publicObject["mainTab"].sSelectedTabCode;   
                     
                     //开着用户购物车
                    if(_ysp_top.publicObject[userTabSetCode].hasTab(custShoppingCart))
                    {                   
                       if(openSubTab)
                       {
                            _ysp_top.publicObject[userTabSetCode]._focusTab(custShoppingCart);
                            _ysp_top.publicObject[userTabSetCode].refresh(custShoppingCart);
                       }
                    }
                    
                   //没有打开购物车菜单，并且有手机用户登录，关闭菜单后，需要显示当前用户下的其他的已经打开的菜单
                    var openTabs = _ysp_top.publicObject[userTabSetCode].lOpenedTabs;
                	if(openTabs.size() > 0)
                	{
	                	for(beginIndex = openTabs.size() - 1; beginIndex >= 0; beginIndex--)
	    		    	{
	    		    		var tabCode = openTabs.get(beginIndex);
	    		    		if(tabCode != curTab)
	    		    		{
	    		    			//add by y00227433 OR_NX_201312_1310 iCRM_客服购物车优化需求  在业务提交时放开隐藏菜单的功能 begin
	    		    			//非客服时，增加是否隐藏逻辑
	    		    			if(_ysp_top.publicObject[userTabSetCode]._isHideTab(tabCode))
	    		    			{
	    		    				continue;
	    		    			}
	    		    			//add by y00227433 OR_NX_201312_1310 iCRM_客服购物车优化需求  在业务提交时放开隐藏菜单的功能 end
	    		    			
	    		    			_ysp_top.publicObject[userTabSetCode]._focusTab(tabCode);
	    		    			break;
	    		    		}
	    			     }
                	}
                }
                else
                {
                	//没有打开购物车菜单，并且没有手机用户登录，关闭菜单后，需要显示其他的已经打开的菜单
                	var openTabs = mainTab.lOpenedTabs;
                	if(openTabs.size() > 0)
                	{
	                	for(beginIndex = openTabs.size() - 1; beginIndex >= 0; beginIndex--)
	    		    	{
	    		    		var tabCode = openTabs.get(beginIndex);
	    		    		if(tabCode != curTab)
	    		    		{
	    		    			//add by y00227433 OR_NX_201312_1310 iCRM_客服购物车优化需求  在业务提交时放开隐藏菜单的功能 begin
	    		    			//非客服时，增加是否隐藏逻辑
	    		    			if(mainTab._isHideTab(tabCode))
	    		    			{
	    		    				continue;
	    		    			}
	    		    			//add by y00227433 OR_NX_201312_1310 iCRM_客服购物车优化需求  在业务提交时放开隐藏菜单的功能 end
	    		    			
	    		    			mainTab._focusTab(tabCode);
	    		    			break;
	    		    		}
	    			     }
                	}
                	
                	
                }
            }
        }
        //add by y00227433 OR_NX_201312_1310 iCRM_客服购物车优化需求  在业务提交时放开隐藏菜单的功能 begin
        //10086客服打开购物车时，不用隐藏菜单功能，而是直接删除对应菜单
//        if('10086ShoppingCart' == submitType)
//        {
//    		mainTab.removeTabByCode(curTab);
//        }
//        
//        else
//        {
        	hideTabByCode(curTab);
//        }
        //add by y00227433 OR_NX_201312_1310 iCRM_客服购物车优化需求   在业务提交时放开隐藏菜单的功能 end
    }
    
    /*-- 关闭隐藏tab页方法 --*/
    function hideTabByCode(curTab)
    {
    	if(typeof(_ysp_top.refreshBuyBus) == 'function')
        {
        	_ysp_top.refreshBuyBus('+',1,false,"true");
        }

        if (curTab != null) 
        {
            //mainTab.removeTabByCode(curTab);
        	if(curTab.indexOf("TabMenu_") == 0)
        	{
        		var mainTab = _ysp_top.publicObject["mainTab"];
        		mainTab._hideTab(curTab,'false');
        	}
        	else
        	{
            	var menuId = _ysp_top.getMenuId(curTab);
            	var hideMenu = _ysp_top.publicObject["hideMenu"];
            	hideMenu(menuId);
        	}
        	
        	// 将隐藏的tab页签保存在隐藏tab列表中 
        	var getHiddenMenus = _ysp_top.publicObject["getHiddenMenus"];
			var hiddenMenus = getHiddenMenus();
        	hiddenMenus.push(curTab);
			var setHiddenMenus = _ysp_top.publicObject["setHiddenMenus"];
        	setHiddenMenus(hiddenMenus);
        }
    }
    
    /*-- 取得当前焦点tabcode，兼容老版csp --*/
    function obtainCurTabCode(mainTab) 
    {
    	var selectedTabCode = mainTab.sSelectedTabCode;
        if (mainTab.getSubSelectedTabCode) 
        {
            selectedTabCode = mainTab.getSubSelectedTabCode();
        }
        return selectedTabCode;
    }
     
	 /**
	 * show all type open window
	 * auto add a random number parameter and a reserved open flag parameter
	 * wintype: 0/modal:showModalDialog; 1,modeless:showModelessDialog; other:window.open
	 */
    function showWindow(wintype, url, args, style)
    {
       if(arguments.length==3)
       {
           style = arguments[2];
           args = arguments[1];
           url = arguments[0];
           wintype = "0";
       }
   
       var sUrl = url;
               
       if(url != "" && url != "about:blank")
       {
    	   var param = "?ngcrm_rnd=" + Math.random() + "&ngcrm_reserved1=1";
    	   var idx = url.indexOf("?");
    	   if(idx >= 0)
    	   {
    		   sUrl = url.substring(0, idx);
    		   param = param + "&" + url.substring(idx+1); 
           }
           sUrl = sUrl + param;
           
           sUrl += "&noCrmSSO=1";
       }
   
       if("0" == wintype || "modal" == wintype)
       {
    	   return window.showModalDialog(sUrl, args, style);
       }
       else if("1" == wintype || "modeless" == wintype)
       {
    	   return window.showModelessDialog(sUrl, args, style);
       }
       else
       {
    	   return window.open(sUrl, args, style);                
       }
    }  
  	 
  	/**
  	 * 设置render模式的fire调用为同步模式,用于一些js复杂交互场景,使用:在fire的onbefore里doSyncRender(this) 
  	 * */ 
  	function doSyncRender(obj)
  	{
  		if(obj && obj.options)
  		{
 	 	    obj.options["async"]=false;
 	 	    return true;
  		}
  		else
  		{
  			return false;
  		}
  	}
  	
  	function openTopWin(url, name, style)
  	{
  	    _ysp_top.win = showWindow("2", url,name,style);
  	}
  	
  	function localFuncInvoke(funcname)
  	{   
  	   if(typeof funcname == 'function')
  	   {
  	        return funcname.call();
  	   }   
  	}    
  	
	function getDateTime(dStr)
	{
	  var v = new Array();
	  if(validateDateTime(dStr))
	  {
	      v[0] = true;
	      v[1] = parseDateTime(dStr);
	  }
	  else if(validateDate(dStr))
	  {
	      v[0] = true;
	      v[1] = parseDate(dStr);
	  }
	  else
	  {
	      v[0] = false;
	  }
	  return v;
	}
	/**--转换日期格式 yyyy-MM-dd--*/
    function parseDate(dStr)
    {
    	var pos1 = dStr.indexOf("-");
    	var pos2 = dStr.indexOf("-", pos1+1);
    	var year = dStr.substring(0, pos1);
    	var month = dStr.substring(pos1+1, pos2);
    	var day = dStr.substring(pos2+1, dStr.length);
    	var v = new Date(year, month-1, day);
    	return v;
    }
    /**--转换时间格式 yyyy-MM-dd HH:mm:ss--*/
    function parseDateTime(dStr)
    {
    	var pos1 = dStr.indexOf("-");
    	var pos2 = dStr.indexOf("-", pos1+1);
    	var pos3 = dStr.indexOf(" ", pos2+1);
    	var pos4 = dStr.indexOf(":", pos3+1);
    	var pos5 = dStr.indexOf(":", pos4+1);

    	var year = dStr.substring(0, pos1);
    	var month = dStr.substring(pos1+1, pos2);
    	var day = dStr.substring(pos2+1, pos3);
    	var hour = dStr.substring(pos3+1, pos4);
    	var minu = dStr.substring(pos4+1, pos5);
    	var sec = dStr.substring(pos5+1, dStr.length);
    	var v = new Date(year, month-1, day, hour, minu, sec);
    	return v;
    }
    /**--验证控件值是否为日期时间格式 --*/
	function validateDateTime(value) 
	{
	  var reg = /^[1-2]\d{3}[-][0-1]\d[-][0-3]\d\s[0-2]\d[:][0-5]\d[:][0-5]\d$/;
	  return reg.test(value);
	} 
	/**--验证控件值是否为日期时间格式 --*/
	function validateDate(value) 
	{
	  var reg = /^[1-2]\d{3}[-][0-1]\d[-][0-3]\d$/;
	  return reg.test(value);
	}
	
	// add begin qWX197540  2013-12-12 V200R005C10LG0024 OR_HEB_201305_928
	/**
	 * 打开稽核界面
	 * @param contextPath: 
	 * @param feeFrame: 费用frame对象
	 * @param recType: 业务类型
	 * @param servNumber：受理号码
	 * @param formnum：受理流水
	 * @param recFee：应收费用(单位分)
	 * @param disCount：减免费用(单位分)
	 */
	function busiAudit(contextPath,feeFrame,recType,servNumber,formnum,recFee,disCount,otherParams)
	{
	    otherParams = otherParams ? otherParams : "";
		 
	     recType = recType ? recType : "";
	     servNumber = servNumber ? servNumber : "";
	     formnum = formnum ? formnum : "";
	     recFee = recFee ? recFee : "";
	     
	     var param = "recType="+recType+"&servNumber="+servNumber+"&formnum="+formnum;
	     var url = obtainWebContextPath("ngcustcare")+"/custsvc/common/busiAudit.action?random=" + Math.random();
	     var response = execService(url, param);
	     var msg = eval("("+response + ")");
	     var stat = msg.stat;
	     //当前业务不校验
	     if ("needAudit" != stat)
	     {
	         return true;
	     }
	     
	     /** 
	      *iCRM和例行页面结构不同，不支持此方式获取用应收费和减免费用
	      *
	     //获取应收费用和减免费用
	     if (feeFrame && feeFrame != "")
	     {
	         if (!recFee)
	         {
	             recFee = parseFloat(feeFrame.document.all.payTotal.innerText)*100;
	         }
	         
	         if (!disCount)
		     {
		         disCount = parseFloat(feeFrame.document.getElementById("discountTotal").innerText)*-1*100;
		     }
	     }*/
	     
	     recType = msg.recType;
	     servNumber = msg.servNumber;
	     formnum = msg.formnum;
	     var orgId = msg.orgId;
	     var operId = msg.operId;
	     
	     // 调本地判断逻辑，确定是否需要进行稽核
	     var auditParams = "&formNum="+formnum+"&servNumber="+servNumber+"&recType="+recType+"&recfee="+recFee+"&discount="+disCount+"&recOpid="+operId+"&recOrgId="+orgId+ otherParams;
	     var isNeedAuditUrl = contextPath+"/heb_refundAudit/doccamera/valite.action?random=" + Math.random();
	     var responseText = execService(isNeedAuditUrl,auditParams);
	     var jsons = eval( " ( " + responseText + " ) ");
	     var isNeedAudit = jsons.FLAG;
	     
	     //0不稽核提交；1稽核；2可选择(是，稽核；否，不稽核提交)
	     if (isNeedAudit == '0')
	     {
	         return true;
	     }       
	     if (isNeedAudit == '2')
	     {
	         if (!confirm(jsons.TIPMSG))
	         {
	             return true;
	         }
	     }
	     var width=690;
		 var height=620;
		 var topheight = (window.screen.height - height)/2;
		 var topleft = (window.screen.width - width )/2;
		 var auditUrl = contextPath+"/heb_refundAudit/doccamera/init.action?random=" + Math.random()+"&formNum="+formnum+"&servNumber="+servNumber+"&recType="+recType+"&recfee="+recFee+"&discount="+disCount+"&recOpid="+operId+"&recOrgId="+orgId + otherParams;
		 var returndata = showWindow(auditUrl,"","dialogWidth: "+width+"px;dialogHeight: "+height+"px; dialogTop:"+topheight+"; dialogLeft: "+topleft+";status:no; help:no;");
		 if("1" == returndata)
		 {
		     return true;
		 }
		 return false; 
	}
	
	/*
	 * Returns a new XMLHttpRequest object, or false if this browser
	 * doesn't support it
	 */
	function newXMLHttpRequest() {

	  var xmlreq = false;

	  if (window.XMLHttpRequest) {

	    // Create XMLHttpRequest object in non-Microsoft browsers
	    xmlreq = new XMLHttpRequest();

	  } else if (window.ActiveXObject) {

	    // Create XMLHttpRequest via MS ActiveX
	    try {
	      // Try to create XMLHttpRequest in later versions
	      // of Internet Explorer

	      xmlreq = new ActiveXObject("Msxml2.XMLHTTP");

	    } catch (e1) {

	      // Failed to create required ActiveXObject

	      try {
	        // Try version supported by older versions
	        // of Internet Explorer

	        xmlreq = new ActiveXObject("Microsoft.XMLHTTP");

	      } catch (e2) {

	        // Unable to create an XMLHttpRequest with ActiveX
	      }
	    }
	  }
		
	  return xmlreq;
	}
	
	/**
	 *url			提交的路径
	 *parameters	参数对（例如：param1=v1&param2=v2）
	 *callback		回调函数
	 *
	 *如果要传输的数据过长需要将数据组织成参数对的形式传到parameters
	 *服务器端程序在取数据时候需要增加UTF-8编码，例如
	 *String curValue = java.net.URLDecoder.decode(request.getParameter(param), "UTF-8");
	 *修改人：wangzhaowu 20070724
	 */
	function execService(url, parameters,callback) {
		var xmlhttp = newXMLHttpRequest();
		
		if(xmlhttp == null){
			alert("初始化失败");
			return ;
		}
		var async = false;
		if (arguments.length == 3){ 
			async=true;
		}
		xmlhttp.open("POST", url, async);
		//修改url超长的问题 add by wangzhaowu 20070724
		xmlhttp.setRequestHeader("Cache-Control","no-cache");
		xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		if (async) { 
			var f = function() {
				if (xmlhttp.readyState==4) {
					callback(xmlhttp.responseText);
				}
			}
			xmlhttp.onreadystatechange = f;
		}
		parameters=encodeURI(parameters);
		parameters=encodeURI(parameters);
		xmlhttp.send(parameters);
		
		if (!async) {
		    var obj = xmlhttp.responseText;
			if(typeof(obj) =='string' || typeof(obj) =='function' || typeof(obj) =='object')
			{
			  return xmlhttp.responseText;
			}
		}
	}
	// add end qWX197540  2013-12-12 V200R005C10LG0024 OR_HEB_201305_928
	
	function release_tabpanel(id) {
		if (id && jBME.vars[id]){
			for ( var i = 0; i < jBME.vars[id].items.length;){
				jBME.vars[id].memoryLeak_CloseItem(jBME.vars[id].items[i].id);
            }
        }//releaseTabpanel before render it,prevent IELEAK,from BME
	}
	
	/**
	 * 在重庆Esop系统中打开Tab页
	 * @param menuId 菜单ID
	 * @param memuName 菜单名称
	 * @param menuUrl 菜单URL
	 * @param esopOpenTabAddr Esop开放给Boss系统的url地址
	 * @remark create dwx207649 2014-03-28 V200R005C10LG0027 OR_huawei_201403_1034 
	 */
	function openTabInnerEsop(menuId, memuName, menuUrl, esopOpenTabAddr)
	{
		// modify by f00186409 2015-03-19 OR_HEB_201502_54 代理商WEB专区_产品统一支撑方案 begin
		if (undefined !=esopOpenTabAddr && esopOpenTabAddr.length > 0 && esopOpenTabAddr.indexOf('cmcvs') > -1)
		{
			//bodyRSA();
	        //var url = encryptedString(rsaKey, menuUrl);
	        var url = encodeURIComponent(encodeURIComponent(menuUrl));
			var esopOpenTab = esopOpenTabAddr + "?CRM_MenuID=" + menuId + "&CRM_MenuUrl=" + url;
			if(undefined!=parent.document.all.menuUrl)
			{
				parent.document.all.menuUrl.src = esopOpenTab;
			}
		}
		else
		{
			var esopOpenTab = esopOpenTabAddr + "?id=" + menuId + "&name=" + encodeURI(encodeURI(memuName)) + "&url=" + menuUrl;
			if(undefined!=document.all.frame4InnerEsop)
			{
				document.all.frame4InnerEsop.src = esopOpenTab;
			}
		}
		// modify by f00186409 2015-03-19 OR_HEB_201502_54 代理商WEB专区_产品统一支撑方案 end
	}
	
	/**
	 * 在重庆Esop系统中关闭Tab页
	 * @param menuID 菜单ID
	 * @param esopRemoveTabAddr Esop 开放给Boss系统的url地址
	 * @remark create dwx207649 2014-03-28 V200R005C10LG0027 OR_huawei_201403_1034 
	 */
	function removeTabInnerEsop(menuID, esopRemoveTabAddr)
	{
		var esopRemoveTab = esopRemoveTabAddr + "?opcode=" + menuID;
		if(undefined!=document.all.frame4InnerEsop)
		{
			document.all.frame4InnerEsop.src = esopRemoveTab;
		}
	}
	/**
	 * 日志监控一期需求
	 * 
	 * <正常开始，正常结束用此方法>
	 * 
	 * @param stepFlag  请求状态
	 * @param reqCode   请求步骤
	 * @param errorCode 错误码
	 * @remark create lWX163735 2015-01-08 R003C14LG1201 OR_JS_201412_625  
	 */
	function writeLogStatStepRecord(stepFlag, reqCode)
	{
	    $.ajax({
	        async : false,
            type: 'POST',
            url: "servlet/logStatStepServlet?stepFlag=" + stepFlag + "&reqCode=" + reqCode,
            dataType: "json",
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
	}
	
	/**
	 * 日志监控二期优化需求
	 * 
	 * <未知错误终止>
	 * @param stepFlag    请求状态
	 * @param reqCode     请求步骤，不知道第几个，传空
	 * @param errorCode   错误码
	 * @param contextPath 请求应用名称
	 * @remark create lWX163735 2015-01-08 R003C14LG1201 OR_JS_201412_625  
	 */
	function logStepUncontroledStopped(stepFlag, reqCode, errorCode, contextPath)
	{
		var curContextPath = "custsvc";
		if (arguments.length == 4)
		{
			curContextPath = arguments[3];
		}
	    $.ajax({
	        async : false,
            type: 'POST',
            url: obtainWebContextPath(curContextPath) + "/servlet/logStatStepServlet?stepFlag=" + stepFlag + "&reqCode=" + reqCode + "&errorCode=" + errorCode,
            dataType: "json",
            error: function (XMLHttpRequest, textStatus, errorThrown) {
            }
        });
	}
	
	/**
	 * 异步提交 url,只是提交_RUEI_recType参数，不涉及任何业务,每 maxRUEIrecTypeValue 种业务提交一回。 方便ruei统计
	 * @param contextPath 应用上下文，如 'custsvc','charge'等。
	 * @param recType 业务类型
	 * @param maxRUEIrecTypeVAlue 分组的阀值，该参数可为null，不传，此时默认为50.
	 * @remark create w00232996 2014-09-09  R003C14LG0901  OR_SD_201408_134 关于前台业务提交URL中增加业务标识rectype 
	 */

	function openRueiCommit(contextPath, recType, maxRUEIrecTypeValue){
		if (recType){
			var arr = recType.split(",");
			var i=0;
			var arr1 = [];	

			maxRUEIrecTypeValue = parseInt(maxRUEIrecTypeValue);
			if (isNaN(maxRUEIrecTypeValue)){
				maxRUEIrecTypeValue = 50;
			}

			while ((arr1=arr.slice(i, i+maxRUEIrecTypeValue)).length){			
				$.post(obtainWebContextPath(contextPath)+"/Blank_.jsp?_RUEI_recType=" + arr1.join(","));
				i += maxRUEIrecTypeValue;
			}	
		}
	}
	
	/**
	 * 证书签名
	 * @certType 证书类型，01设备证书；03操作员证书
	 * @param srcData 传过来一个n行2列的二维数组，第一列为key，第二列为value
	 * @create f00186409 2015-04-15 OR_HEB_201502_460 web专区代理商开户提交数据cmca签名 
	 * @modify 1Line by d00232995 20150508 web专区引入操作员ID
	 */
	function cmcaCertSign(certType, srcData, userOperId)
	{
		var buffer = [];

		if(null != srcData && srcData instanceof Array)
		{
			var rowData;
			for(var row=0; row<srcData.length; row++)
			{
				rowData = srcData[row];
				if(null != rowData && rowData instanceof Array && rowData.length == 2)
				{
					buffer.push(rowData[0]);
					buffer.push("=");
					buffer.push(rowData[1]);
					buffer.push("@");
				}
			}
		}
		
		// 将最后一个@去掉
		if(buffer.length > 0)
		{
			buffer.pop();
		}

		// 进行签名
		var dataAfterSign = "";
		// 设备证书
		if("01" == certType)
		{
			dataAfterSign = deviceSignature(getMacAddress(), buffer.join(""));
		}
		// 操作员证书
		else
		{
			// UKEY初始化，如果初始化成功优先用UKEY加密
			if(1 == ukeyInitProv())
			{
				dataAfterSign = ukeySignStrComp("", buffer.join(""));
			}
			else
			{
				// 操作员工号，与证书申请及更新传参一致
			    // modify 1Line by d00232995 20150508 web专区引入操作员ID
			    usrInitProv();
				dataAfterSign = usrSignStrComp("", buffer.join(""), userOperId);
			}
		}
		
		if("" == dataAfterSign)
		{
	   		return "";
		}
			
		// 签名成功后进行赋值
		// 对签名结果进行编码，防止js提交时过滤加号等特殊字符
		dataAfterSign = encodeURIComponent(encodeURIComponent(dataAfterSign));
			
		return dataAfterSign;
	}
	
	