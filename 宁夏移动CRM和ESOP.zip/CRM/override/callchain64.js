if (!this.OC) {
    var OC = {};
}
OC.Callchain = function() {
    var number = 0; // fireid计数
    var number_start = "init";
    var number_end = "99999999";
    var counter = 0; // 请求计数

    /**
     * 填充数字
     */
    function fillNumber(num, length) {
        var temp = 0;
        if (!num || !length) {
            num = 0;
        }
        if (!length) {
            length = 0;
        }
        num = num.toString();
        temp = length - num.length;
        if (temp > 0) {
            for (var i = 0; i < temp; i++) {
                num = "0" + num;
            }
        }
        return num;
    }

    /**
     * 获取cookie信息
     */
    function getCookie(cookieName) {
        //debugger;
        var reg = new RegExp("(^| )" + cookieName + "=([^;]*)(;|$)");
        var arr = document.cookie.match(reg);
        if (arr) {
            return unescape(arr[2]);
        } else {
            return "";
        }
    }

    function getParam(param) {
        var url = location.href;
        var paraString = url.substring(url.indexOf("?") + 1,
            url.length).split("&");
        var paraObj = {};
        for (var i = 0; i < paraString.length; i++) {
            var j = paraString[i];
            paraObj[j.substring(0, j.indexOf("=")).toLowerCase()] = j.substring(j.indexOf("=") + 1, j.length);
        }

        var returnValue = paraObj[param.toLowerCase()];
        if (typeof(returnValue) == "undefined") {
            return "";
        } else {
            return returnValue;
        }
    }

    return {
        getServNum: function() {
            //debugger;
            return getCookie("besServNum");
        },
        getNextCounter: function() {
            return counter++;
        },
        getInitFireId: function() {
            return number_start + "0000";
        },
        getNextInitFireId: function() {
            number++;
            var fireId = fillNumber(number, 4);
            return number_start + fireId;
        },
        getNextFireId: function() {
            number++;
            var fireId = fillNumber(number, 8);
            return fireId;
        },
        getEndFireId: function() {
            return number_end;
        },
        initError: function() {
            //debugger;
            $Page = $(document).scope().$Page;
            $Page.callchainInit = true;
        },
        initFireSearch: function() {
            //debugger;
            $Page = $(document).scope().$Page;
            var trace = $Page.smTrace || {};
            $Page.traceId = trace.traceId;
            $Page.traceFlag = trace.traceFlag;
            //初始化fireid为init0000
            $Page.fireId = "init0000";
            var ocTransferCounter = this.getNextCounter();
            $Page.ocTransferCounter = ocTransferCounter;
            //			$Page.serviceTransferCounter = ocTransferCounter;
            //$Page.menuId = getParam("menuid");
            if (_ysp_top && _ysp_top.window && _ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel && _ysp_top.window.$BES.$Portal.tabpanel.getTabItem() && _ysp_top.window.$BES.$Portal.tabpanel.getTabItem().key) {
                $Page.menuId = _ysp_top.window.$BES.$Portal.tabpanel.getTabItem().key;
            }
            $Page.serviceNum = this.getServNum();
            $Page.callchainInit = true;
        },
        setFireId: function(fireId) {
            $Page = $(document).scope().$Page;
            $Page.fireId = fireId;
        },
        setPageId: function(pageId) {
            $Page = $(document).scope().$Page;
            $Page.pageId = pageId;
        },
        setOcTransferCounter: function(ocTransferCounter) {
            $Page = $(document).scope().$Page;
            $Page.ocTransferCounter = ocTransferCounter;
        },
        //		setServiceTransferCounter : function(serviceTransferCounter) {
        //			$Page=$(document).scope().$Page;
        //			$Page.serviceTransferCounter = serviceTransferCounter;
        //		},
        setFireSearch: function(pageId, fireId, previousTraceIDs,step) {
            $Page = $(document).scope().$Page;
            $Page.pageId = pageId;
            $Page.fireId = fireId;
            if (!fireId || fireId == "undefined") {
                fireId = "init0000";
            } else {
                $Page.fireId = fireId;
            }
            //$Page.ocTransferCounter = this.getNextCounter();
            //			$Page.serviceTransferCounter = $Page.ocTransferCounter;
            $Page.previousTraceIDs = previousTraceIDs || ($Page.previousTraceIDs || "");
            //			if(fireId == 'closetab') {
            //				$Page.callNumber = $Page.totalCallNumber;
            //			}

            //step stepFlag createOrderStep 仅用于宁夏
			if(step){

				$Page.stepFlag=true;
				if(typeof step=="number"){
					$Page.step=step;
				}else if(step=="createorder"){
					if($Page.createOrderStep<1){
						$Page.step++;
					}
					$Page.createOrderStep++;
				}else{
					$Page.step++;
				}


			}else{
				$Page.stepFlag=false;
			}
        },
        /**
         * 从页面获取serviceNum
         * param:当前页面的手机号码
         *
         */
        setServiceNumber: function(serviceNum) {
        	debugger;
           $Page = $(document).scope().$Page;
           $Page.serviceNum = serviceNum;
        },

        /**
         * 从页面获取businessType
         * param:当前页面的业务类型
         *
         */
        setBusinessType: function(businessType) {
        	debugger;
           $Page = $(document).scope().$Page;
           $Page.businessType = businessType;
        },

        /**
         * 简化服务调用链在页面的写法
         * callbackFunc固定参数为($Gadget, $Fire, $UI)
         * 2016/06/10 by l00185610
         */
        initCallChain: function($Gadget, pageId, callbackFunc) {
            //debugger;

            var $Page = $Gadget.$window.$Page;
            var $Fire = $Gadget.$Get("$Fire");
            var $UI = $Gadget.$UI;

            OC.Callchain.initQueryTraceFlag($Page, $Gadget, $Fire);

            $Page.functype = $Page.menuId;
            $Page.phonenum = OC.Callchain.getServNum();
            $Page.pageId = pageId;

            $Fire({
                service: "smservicetracebo/querytraceinfo",
                params: {
                    functype: $Page.functype,
                    phonenum: $Page.phonenum
                },
                target: "$Page.smTrace",
                onafter: function() {
                    //debugger;
                    OC.Callchain.initFireSearch();
                    if (typeof callbackFunc === 'function') {
                        callbackFunc($Gadget, $Fire, $UI, true);
                    }
                },
                onerror: function() {
                    //debugger;
                    OC.Callchain.initError();
                    if (typeof callbackFunc === 'function') {
                        callbackFunc($Gadget, $Fire, $UI, false);
                    }
                }
            }, $Gadget);
        },

        //服务调用链开关控制
        initQueryTraceFlag: function($Page, $Gadget, $Fire) {
            //debugger;

            if (_ysp_top && _ysp_top.window && _ysp_top.window.$BES && _ysp_top.window.$BES.$Portal && _ysp_top.window.$BES.$Portal.tabpanel && _ysp_top.window.$BES.$Portal.tabpanel.getTabItem() && _ysp_top.window.$BES.$Portal.tabpanel.getTabItem().key) {
                $Page.menuId = $Page.menuId || _ysp_top.window.$BES.$Portal.tabpanel.getTabItem().key;
            }

            $Page.callNumber = 0;
            $Page.totalCallNumber = 0;
            //step stepFlag createOrderStep 仅用于宁夏
			$Page.step=0;
			$Page.stepFlag=false;
			$Page.createOrderStep=0;

            var searchForCallChain = function($Page) {
                if (typeof($Page.ocTransferCounter) == "number" && $Page.ocTransferCounter >= 0) {
                    $Page.ocTransferCounter = OC.Callchain.getNextCounter();
                }
                var trace = $Page.smTrace || {};
                if ($Page.traceId == "undefined" || $Page.traceId == undefined) {
                    $Page.traceId = trace.traceId;
                    $Page.traceFlag = trace.traceFlag;
                }
                if ($Page.fireId == 'closetab') {
                    $Page.callNumber = $Page.totalCallNumber;
                }
                //debugger;

                var param = {
                    fireId: $Page.fireId,
                    pageId: $Page.pageId,
                    traceId: $Page.traceId,
                    traceFlag: $Page.traceFlag,
                    menuId: $Page.menuId || $Page.pageId,
                    transferNumber: $Page.ocTransferCounter, //请求次数（oc）
                    callNumber: $Page.callNumber, //请求次数（平台）
                    serviceNum: $Page.serviceNum, //用户号码
                    businessType:$Page.businessType,//业务类型
                    previousTraceIDs: $Page.previousTraceIDs, //购物车页面维护变量
                    BusiNo: $Page.busiNo,
                    grpBizBeId: $Page.grpBizBeId ? $Page.grpBizBeId : "",
                    subscriberId: $Page.callChainGroupCustId ? $Page.callChainGroupCustId : "", //集团客户编号
                };

                //step stepFlag createOrderStep 仅用于宁夏
			 	if($Page.stepFlag){
			 		param.BusinessSerial=$Page.traceId+$Page.step.toString();
			 		$Page.stepFlag=false;
			 	}

                return param;
            };

			adutil.addFireSearchFunc('callChain', searchForCallChain);

            var globalAfterForCallChain = function(data, status, headers, config) {
                //debugger;
                if (!$(document).scope()) {
                    return false;
                }
                var $Page = $(document).scope().$Page;

                function getTranfer(param) {
                    var arr = param.split("&");
                    var paraString = "";

                    for (var i = 0; i < arr.length; i++) {
                        if (arr[i].substring(0, 14) == "transferNumber") {
                            paraString = arr[i];
                        }
                    }
                    var tran = paraString.split("=");
                    if (tran.length > 0 && parseInt(tran[1]) >= 1) {
                        return true;
                    } else {
                        return false;
                    }

                }
                if ($Page && $Page.totalCallNumber >= 0 && parseInt(headers('CallNumber')) >= 0 && getTranfer(config.url)) {
                    $Page.totalCallNumber += parseInt(headers('CallNumber'), 10);
                }

                if (headers('BusiNo')) {
                    $Page.busiNo = headers('BusiNo');
                }
            };

			adutil.addFireGlobalAfterFunc('callChain', globalAfterForCallChain);

            $Page.queryTraceFlag = true;
        }
    }
}();

function onBesTabClose() {
   debugger;
    try {
  		// 清空预约订单审核信息
        if (window && window._ysp_top && window._ysp_top.fromOrderReservation) {
            window._ysp_top.fromOrderReservation = "";
        }

        var $Page = angular.element(document).scope().$Page;

        //ywx454179 20170426修改清空购物车
        if($Page.menuId=='6013120170417153053'){
      	  window._ysp_top.shoppingcart.carofferingList=[];
            shoppingCar = _ysp_top.$(".shoppingCar");

    		shoppingCar.click();
    		window._ysp_top.shoppingcart.create=false;
        }

        // add by l00380145  山东业务受理计时功能  US-20170518100906-2031000316 2017-06-17 begin

        if('function' === typeof clearBusinessTimer) {
            clearBusinessTimer($Page.menuId || $BES.$Portal.tabpanel.getTabItem().key);
        }

        // add by l00380145  山东业务受理计时功能  US-20170518100906-2031000316 2017-06-17 end

      //ywx454179 20170426修改结束
        OC.Callchain.setFireSearch($Page.pageId, 'closetab');
        //	   if($Page.pageId&&$Page.pageId=="ChkOut"){
        //$Page.previousTraceIDs="";
        //	   }
        if ('RecoverSubs' == $Page.businessCode && !$Page.enrollUserInfoDatabak){
        	$recoverySubsinfoGadget = adutil.getGadgetObj($(".bes-ad-renewaccount"));

        	$Page.dictitem = {};
        	$Page.userInfoCertType = "";
            // 证件类型
        	$Page.dictitem.TYPE_CODE = $Page.dictkeylist["OH_CERT_TYPE_CODE"] || [];
            $.each($Page.dictitem.TYPE_CODE || [], function(i, vali) {
                if (vali.dictName == $recoverySubsinfoGadget.customerInfoResponse.intfCustomerAndIndividualInfo.reserverCertType) {
                	$Page.userInfoCertType = vali.itemCode;
                }
            });
            if ($Page.userInfoCertType == "") {
            	$Page.userInfoCertType = "99";
            }
            $Page.enrollUserInfoDatabak = {};
            $Page.enrollUserInfoDatabak.servnumber = $Page.phonenum;
      		$Page.enrollUserInfoDatabak.recdefid = $Page.businessCode;
            $Page.enrollUserInfoDatabak.reserverCertType = $Page.userInfoCertType;
            $Page.enrollUserInfoDatabak.reserverCertId = $recoverySubsinfoGadget.customerInfoResponse.intfCustomerAndIndividualInfo.reserverCertId;
            $Page.enrollUserInfoDatabak.userName = $recoverySubsinfoGadget.customerInfoResponse.intfCustomerAndIndividualInfo.userName;
        }
        // 页面关闭时处理证件的预占，不需要返回，请求发送成功即可。
        if (window._ysp_top.PSeq && $Page.enrollUserInfoDatabak
            && $Page.enrollUserInfoDatabak.reserverCertId
            && $Page.enrollUserInfoDatabak.reserverCertType){
			debugger;
			//调用预占服务
			var request={};
			request.customerName = $Page.enrollUserInfoDatabak.userName;
			request.idCardType = $Page.enrollUserInfoDatabak.reserverCertType;
			request.idCardNum = $Page.enrollUserInfoDatabak.reserverCertId;
			request.campofftype = "2";  // 预占解除类型  2表示关闭页面等被动解除预占的操作
			request.servnumber = $Page.enrollUserInfoDatabak.servnumber;
			request.recdefid = $Page.enrollUserInfoDatabak.recdefid;
			request.campON = "02";
			request.pSeq = window._ysp_top.PSeq;

			$(document).scope().$Get('$Fire')({
				service : "/bes/oc/occupyConnector",
				params : {
					'request' : request
				},
				target : "campONSeq",
				onafter : function(campONSeq) {
					debugger;
				}
			});
			window._ysp_top.PSeq = "";
		}

	   angular.element(document).scope().$Get("$Fire")({
		     onbefore: function(){
                                     var searchObj =  window.$UEE.$Fire.search($Page);
                                     var servlet = window.$UEE.$Fire.servicePrefix || "/u-route/";
                                     var url = window.$UEE.$Webapp + servlet + 'ucec/v1/common/qrysystemparambykey?t='+ $.now() + '&token=' + $UEE.token();
                                     angular.forEach(searchObj, function(value, key){
                                        url+= "&" + key + "=" + encodeURIComponent(value);
                                     });

                                     $.ajax({
                                               method: "POST",
                                               headers:{"content-type": "application/json"},
                                               url: url,
                                               dataType : "json",
                                               async:false,
                                               data: JSON.stringify({ model: null, params:{key:""}}),
                                     })

                return false;
            },

            service: 'ucec/v1/common/qrysystemparambykey',
            params: {
                key: ""
            },
            target: "$Page.callchainEndVal",
        }, angular.element(document).scope());
    } catch (e) {
        debugger;
    }
}

function beforeCloseTab() {
	debugger;
	var $Page = angular.element(document).scope().$Page;
    var $UI = angular.element(document).scope().$UI;
    var $Fire = angular.element(document).scope().$Get('$Fire');

	//如果为免填单推送页面，但仍在请求中，则关闭时提示 免填单正在推送中，请稍候 c00311908
	if ($Page.pushEReceiptForceCloseTab == "N" && $Page.showCover2)
	{
		$UI.msgbox.info("提示","免填单正在推送中，请稍候");
		return false;
	}
	else if(!$Page.prePushReceptFlag && $Page.initPrintLog == "Y" && $Page.pushRecList && $Page.pushRecList.length > 0)
	{
		debugger;
		if ($Page.callCreatePDF == false)
		{
			$UI.msgbox.info("提示","检测到免填单推送存在异常，请确认是否推送成功！", function(){
					$Page.callCreatePDF = true;
				}, 
				function(){
					$Page.callCreatePDF = true;
				});
			return false;
		}
		return true;
	}
	else if($Page.showAmalgamation && !$Page.isBuy && $Page.order_resp && $Page.order_resp.body && $Page.order_resp.body.refOrderId)
	{
		if ($Page.finishForceNoClose == 'Y')
		{
			// 强制不可关闭
			$UI.msgbox.info('提示', '您还未加入融合套餐，不办理融合套餐用户会产生单独的宽带费用，会引发投诉，请继续办理融合套餐！');
			return false;
		}
		else
		{
			// 只提醒
			$UI.msgbox.confirm('提示', '您还未加入融合套餐，不办理融合套餐用户会产生单独的宽带费用，会引发投诉，请确认是否不继续办理融合套餐！', function(){
				// 确认，关闭当前页面
				$Page.isBuy = true;
				Close_tabSet();
			},
			function(){
				// 取消，则留在当前页
				return false;
			});
			return false;
		}
	}		
	else
	{
		return true;
	}
}
