if (!this.OC) {
	var OC = {};
}
if (!OC.Comm) {
	(function() {
		OC.Comm = {};
	})();
}

/**
 * Desc: 检验Filed域的是否为空,不为空:返回true, 为空:返回false; <br>
 * 
 * @param {}
 *            str |字符串参数 <br>
 * @return {Boolean}
 */
OC.Comm.checkNull = function(str) {
	if (str == undefined || str === "") {
		return false;
	}

	return true;

};

/**
 * Desc: 检验Filed域是否为数字,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            number |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isNumber = function(number) {
	var newPar = /^\d+$/;
	if (number.length > 0) {
		if (newPar.test(number) == false) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为整数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            integer |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isInteger = function(integer) {

	var newPar = /^(-|\+)?\d+$/;
	if (integer.length > 0) {
		if (newPar.test(integer) == false) {

			return false;
		} else if (integer < -2147483648 || integer > 2147483647) {

			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为浮点数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            float |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isFloat = function(float) {
	var newPar = /^(-|\+)?\d*\.?\d+$/;
	if (float.length > 0 && newPar.test(float) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否包含有中文信息,是:返回false, 否:返回true; <br>
 * 
 * @param {}
 *            strValue |输入的要校验的数值 <br>
 * @return {Boolean}
 */
OC.Comm.isNotContainsChinese = function(strValue) {
	var newPar = /^[\u0000-\u00ff]+$/;
	if (strValue.length > 0) {
		if (newPar.test(strValue) == false) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验是否是电话号码,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            phone
 * @return {}
 */
OC.Comm.isPhone = function(phone) {
	var reg = /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/;
	return reg.test(phone);
};

/**
 * Desc: 检验是否是固话,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            phone
 * @return {}
 */
OC.Comm.isTelephone = function(phone) {
	var reg = /^(0\d{2,3}-\d{7,8})$/;
	return reg.test(phone);
};


/**
 * Desc: 检验是否是手机号码,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            mobile
 * @return {}
 */
OC.Comm.isMobile = function(mobile) {
	debugger;
	var reg = /^(1[345789]\d{9})$/;
	var a = reg.exec(mobile);
	if (a == null) {
		return false;
	}
	return true;
};

/**
 * Desc: 检验是否是邮箱地址,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isEmail = function(str) {
	var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	return reg.test(str);
};

/**
 * Desc: 检验是否是金额,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isFund = function(str) {
	var reg = new RegExp(/^[\-\+]?([0-9]\d*|0|[1-9]\d{0,2}(,\d{3})*)(\.\d+)?$/);
	return reg.test(str);
};

/**
 * Desc: 检验是否是身份证,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isIdCard = function(str) {
	var reg = new RegExp(/^([\d]{15}|[\d]{18}|[\d]{17}[x|X])$/);
	return reg.test(str);
};

/**
 * Desc: 检验是否是字母的数据组合,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isLetterAndNumber = function(str) {
	var reg = /[^a-zA-Z0-9]/;
	return !reg.test(str);
};

/**
 * Desc: 检验是否是字母组合,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isStartLetter = function(str) {
	var reg = /^[a-zA-Z]/;
	return reg.test(str);
};

/**
 * Desc: 字符串去掉空格 <br>
 * 
 * @param {}
 *            str ｜字符串 <br>
 * @return {}
 */
OC.Comm.trimStr = function(str) {
	return str.replace(/(^\s*)|(\s*$)/g, "");
};

/**
 * Desc: 检验Filed域是否为银行帐号(234214-32423-234234-23424-2342),是:返回true, 否:返回false;
 * <br>
 * 
 * @param {}
 *            strBankAccout |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isBankAccount = function(strBankAccout) {
	var newPar = /^[0-9]\d*[0123456789-]*\d*[0-9]$/;
	if (strBankAccout.length > 0 && newPar.test(strBankAccout) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为正浮点数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strFloat |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isPositiveFloat = function(strFloat) {
	var newPar = /^\d*\.?\d+$/;
	if (strFloat.length > 0 && newPar.test(strFloat) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为小数点为两位的正浮点数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strFloat |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isPositiveTwoFloat = function(strFloat) {
	var newPar = /^0(\.[0-9]{1,2})?$|^[1-9][0-9]*(\.[0-9]{1,2})?$/;
	if (strFloat.length > 0 && newPar.test(strFloat) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为无符号整数(不包含负整数),是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strInteger |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isUnsignedInteger = function(strInteger) {
	var newPar = /^\d*[0123456789]\d*$/;
	if (strInteger.length > 0) {
		if (newPar.test(strInteger) == false) {
			return false;
		} else if (strInteger < 0 || strInteger > 2147483647) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为正整数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strInteger |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isPositiveInteger = function(strInteger) {
	var newPar = /^\d*[0123456789]\d*$/;
	if (strInteger.length > 0) {
		if (newPar.test(strInteger) == false) {
			return false;
		} else if (strInteger <= 0) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验是否是邮政编码,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isPostcode = function(str) {
	var reg = /^(\d){6}$/;
	return reg.test(str);
};

/**
 * Desc: 检验是否是中文,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isChinese = function(str) {
	var reg = /^[\u0391-\uFFE5]+$/;
	return reg.test(str);
};

/**
 * Desc: 返回不同字符集下字符长度 <br>
 * 
 * @param {}
 *            str ｜字符串 <br>
 * @return {}
 */
OC.Comm.getStrlen = function(str) {
	var Charset = jQuery.browser.msie ? document.charset
			: document.characterSet;
	if (Charset.toLowerCase() == 'utf-8') {
		return str.replace(/[\u4e00-\u9fa5]/g, "***").length;
	} else {
		return str.replace(/[^\x00-\xff]/g, "**").length;
	}
};

/**
 * 替换字符
 * 
 * @param {}
 *            orgStr ｜原字符串
 * @param {}
 *            pos |替换的位置
 * @param {}
 *            replacetext |替换的文本
 * @return {}
 */
OC.Comm.replaceStr = function(orgStr, pos, replacetext) {
	if (pos > orgStr.length) {
		return orgStr;
	}
	pos = Number(pos);
	var start = orgStr.substring(0, pos);
	var end = orgStr.substring(pos + 1, orgStr.length);
	return (start + replacetext + end);

};

/**
 * 时间比较(yyyy-mm-dd hh:mi:ss)
 * 
 * @param {}
 *            beginTime
 * @param {}
 *            endTime |
 * @return {} <0 endTime小; >0 endTime大 ; ==0 时间相等
 */
OC.Comm.comptimeTime = function(beginTime, endTime) {
	var beginTimes = beginTime.substring(0, 10).split('/');
	var endTimes = endTime.substring(0, 10).split('/');

	beginTime = beginTimes[1] + '-' + beginTimes[2] + '-' + beginTimes[0] + ' '
			+ beginTime.substring(10, 19);
	endTime = endTimes[1] + '-' + endTimes[2] + '-' + endTimes[0] + ' '
			+ endTime.substring(10, 19);

	return (Date.parse(endTime) - Date.parse(beginTime));
};
/**
 * 
 * 获取URL中参数，并将参数封装为一对象
 * 
 */
OC.Comm.getUrlParamObj = function() {
	debugger;
	var url = window.location.href; // 获取url中"?"符后的字串
	var theRequest = new Object();
	if (url.indexOf("?") != -1) {
		var str = url.substr(url.indexOf("?") + 1);
		if (url.indexOf("#") != -1) {
			str = str.substr(0, str.indexOf("#"));
		}
		strs = str.split("&");
		for ( var i = 0; i < strs.length; i++) {
			theRequest[strs[i].split("=")[0]] = unescape(strs[i].split("=")[1]);
		}
	}
	return theRequest;
};

/**
 * 处理校验报文
 * $scope 
 * $UI 
 * busiValidResp 校验结果  {
						        "retCode": 0,
						        "retMessage": "sucess",
						        "busiValidResults": [
						            {
						                "promptId": "11",
						                "promptMessage": "错误1",
						                "level": 1
						            }
						        ]
						    }
 * dialogTitle 提示框标题
 * succFunc 校验成功的回调函数
 * errFunc 校验失败的回调函数
 */
OC.Comm.checkBusiValidResp = function($scope, $UI, busiValidResp, dialogTitle, succFunc, errFunc){
	debugger;
	var succCb=null;
	var errCb=null;
	var fontList=["<font color='#333'>","<font color='#333'>","<font color='#333'>","<font color='#EC4E5C'>"];

	if($scope){
		if(succFunc){
			succCb=function(){         
				$scope.$apply(succFunc());
			};
		}
		if(errFunc){
			errCb=function(){         
				$scope.$apply(errFunc());
			};
		}
	}else{
		succCb=succFunc;
		errCb=errFunc;
	}
	
	dialogTitle=dialogTitle||$UEE.i18n("ad.sr.message.TS");
	var messageCount=0;
	var message=null;
	
	if (!busiValidResp) {
		$UI.msgbox.error($UEE.i18n("ad.sr.message.YWXYSB"), $UEE.i18n("ad.sr.message.WXYBW"), errCb);
		return;
	}
	
	busiValidResp.busiValidResults = busiValidResp.busiValidResults || [];
	for ( var i = 0; i < busiValidResp.busiValidResults.length; i++) {
		var validResp = busiValidResp.busiValidResults[i];
		if(validResp.promptMessage){
			if(messageCount==0){
				message=fontList[validResp.level]
					+validResp.promptMessage+"</font>";
			}else{
				message=message+"<br>"+fontList[validResp.level]
					+validResp.promptMessage+"</font>";
			}
			messageCount++;
		}
	}

	if("0" != busiValidResp.retCode){                               // 出现error级别错误时的弹出框
		if(!message){
			//message=busiValidResp.retMessage||"校验失败，无校验提示报文";
			message = $UEE.i18n("ad.person.message.SystemErrorLaterRetry");
		}
		$UI.msgbox.error(dialogTitle, message, errCb);
	}else{  
		if (messageCount>0) {                                                   // 出现info跟warning校验时的info弹出框
			$UI.msgbox.warning(dialogTitle, message, succCb, errCb);
		} else {
			// 不出现弹出框，返回true
			if (typeof succCb === 'function') {
				succCb();
			} 
		}
	}
};

/**
 * 本方法1$Gadget.validateResult加上info，2
 */
OC.Comm.addValidateInfo = function($Gadget, $errCode, $stringId){
	debugger;
	if(!$Gadget.validateResult){
		$Gadget.validateResult = [];
	}
	var Info = {
		retCode : $errCode,
        retMessage : $UEE.i18n($stringId)
    };
    $Gadget.validateResult.push(Info);
        
    $Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.group.message.MSGBOXINFO"), Info.retMessage);	
};

/**
 * 集团属性校验
 * req={
 * 		"custId":"", //客户ID
 * 		"subsId":"", //用户ID，开户不需要
 * 	    "offeringId":"",
 * 		"offeringInstId":"",//开户不需要
 * 		"opCode":"",
 * 		"relaItemId":"",
 * 		"attr":{//需要校验的属性
 * 			com.huawei.bes.ad.businessmodule.common.Attribute结构
 * 		}，
 * 		"businessType":""//业务类型
 * 		"seniorId":""//场景ID
 * 		"eventId":""//事件类型
 * 		"ownerType":""//如果是原子产品或者是组合产品的时候，ownerType塞值为S,如果是群产品的时候，ownerType塞值为G
 * 	}
 */
OC.Comm.validateAttr = function($Page,$Fire,$scope,req,successback,failback){
	debugger;
	dontTouchDataOfWholePage();
	var $UI = $scope.$Get('$UI');
	
	$Fire({
		service : '/ucec/v1/groupcommon/attrvalidate',
		params : {
		    header:{},
		    "body": req
		},
		target : '$Page.attrValidateResult',
		onafter : function () {
		    debugger;
		    youCanTouchDataOfWholePage();
		    if (adutil.checkUcecResp($Page.attrValidateResult.header, $UI)) {
		    	var busiValidResp = $Page.attrValidateResult.body;
		    	/*if (!busiValidResp || !busiValidResp.returnMessage || "0" != busiValidResp.returnMessage.retCode) {
		    		$scope.$safeApply($scope,failback);
		    		return false;
				}
		    	
		    	$scope.$safeApply($scope,successback);*/
		    	var checkResult = adutil.checkBusiValidResp($scope,$UI,busiValidResp,successback,successback,failback,null);
		    	if(checkResult)
		    	{
		    		$scope.$safeApply($scope,successback);
		    	}
		    }
		    else
		    {
		    	$scope.$safeApply($scope,failback);
		    }
		},
		onerror : function() {
			debugger;
			youCanTouchDataOfWholePage();
		}
	}, $scope);
};

/**
 * 常量
 */
OC.Comm.Constants = {
		// 活动类型
		PM_GrpRewardClass : {
			General : 10,	// 通用集团营销方案
			Agreement : 11,	// 协议总消费
			Minimum : 12,	// 月最低消费
			Fixed : 13,	// 月固定功能费组合消费
			Multi : 14,	// 多产品打折
			Important : 99,	// 重要集团维护
			Member : 88	// 成员消费与限制
		},
		
		// 判断offer的类型
		ClassificationId : {
			Recharge : 24022,	//	充值
			Consume : 24023,	//	消费
			Goods : 27001,	//	物品(充值卡)
			Terminal : 27002,	//	终端
			MemberFee : 24024,	//	成员话费返还
			Coin : 24025,	//	商城币返还
			Sounds : 24026,	//	集团语音统付返还
			General : 24027,	//	集团业务统付
			MemberPay : 24028	//	成员消费限制
		},
		
		// 判断offer实例的类型
		PromotionType : {
			Recharge : "Template_Recharge",	//	充值
			Consume : "Template_GroupConsume",	//	消费
			Goods : "PuTongShiWuTemplate",	//	物品
			Terminal : "TerminalTemplate",	//	终端
			MemberFee : "Template_ReturnConsume",	//	成员话费返还
			Coin : "Template_MallcoinFeedBack",	//	商城币返还
			Sounds : "Template_GrpVoiceUniPay",	//	集团语音统付返还
			General : "Template_UniPay",	//	集团业务统付
			MemberPay : "Template_MemberConsume"	//	成员消费限制
		}
},

/**
 * 该分页方法只能在单个gadget，有单个分页的情况使用
 */
$Controller("bes.agentdesktop.group.page", {
	initPage : function($Gadget) {
		debugger;
		if ($Gadget.$Items != null && $Gadget.$Items.length > 0) {
			$("#page_items_is_null").attr("style", "display:none");
			$Gadget.currentPage = $Gadget.currentPage || 1;
			$Gadget.currentSize = $Gadget.currentSize || 5;
			$Gadget.totalPage = Math.ceil($Gadget.$Items.length
					/ $Gadget.currentSize);
			$Gadget.$Page_Items = $Gadget.$Items.slice(0, 5);
		}
	},

	gotoPage : function($Gadget, $Event) {
		debugger;
		$Gadget.currentSize = $Event.$Data.sizeperpage;
		$Gadget.currentPage = $Event.$Data.page;
		$Gadget.totalPage = Math.ceil($Gadget.$Items.length
				/ $Gadget.currentSize);
		$Gadget.$Gadget.$Page_Items = $Gadget.$Items.slice(
				($Gadget.currentPage - 1) * $Gadget.currentSize,
				$Gadget.currentPage * $Gadget.currentSize);
	}
});
$Controller(
		"bes.agentdesktop.group.drop",
		{
			/**
			 * 初始化下拉框
			 * @param dataArray 带key、value变量的数组
			 * @param dropId 下拉框ID
			 * @param $Page
			 */
			initDropList : function(dataArray, dropId, $Page) {
				debugger;
				var _dropId = "#" + dropId;
				var dropListGroupDropList = new UCD.Droplist($(_dropId),
						dataArray);
				dropListGroupDropList.init(); // 必须使用初始化函数
				dropListGroupDropList.enableInput(false);
				dropListGroupDropList.$input.attr('id', dropId + '_drop_list_id');
				dropListGroupDropList
						.setOnValueChange(function() {
							debugger;
							/*for ( var i = 0; i < dataArray.length; i++) {
								if (dataArray[i].value == dropListGroupDropList.selectItemArray[0]) {
									$(_dropId).attr("value",
											dataArray[i].key);
									if(typeof ($Page) != "undefined" && $Page != null) {
										$Page[dropId] = new Object();
										$Page[dropId].key = dataArray[i].key;
										$Page[dropId].value = dataArray[i].value;
									}
								}
							}*/
							$(_dropId).attr("value", dropListGroupDropList.$input.attr('key'));
							if(typeof ($Page) != "undefined" && $Page != null) {
								$Page[dropId] = {};
								$Page[dropId].key = dropListGroupDropList.$input.attr('key');
								$Page[dropId].value = dropListGroupDropList.selectItemArray[0];
							}
						});
				dropListGroupDropList.selectItem(dataArray[0] && dataArray[0].key);
				return dropListGroupDropList;
			},
			/**
			 * 初始化下拉框
			 * @param dictList 字典list
			 * @param dropId 下拉框ID
			 * @param $Page
			 */
			initDictDropList : function(dictList, dropId, $Page) {
				debugger;
				var dataArray = $Controller.bes.agentdesktop.group.drop
						.changeDictList2Array(dictList);
				$Controller.bes.agentdesktop.group.drop.initDropList(dataArray, dropId, $Page);
			},
			// 数据字典数据返回处理成符合UCD.Droplist的数据形式
			changeDictList2Array : function(data) {
				var arr = [];
				if(typeof(data) == 'undefined' || data == null) {
					return arr;
				}
				for ( var i = 0; i < data.length; i++) {
					obj = {};
					obj.key = data[i].itemCode;
					obj.value = data[i].itemName;
					if (i == 0) {
						obj.selected = true;
					}
					arr.push(obj);
				}
				return arr;
			}
		});

/**
 * 手机号码校验
 */
$Controller("bes.agentdesktop.group.mobile", {
	verifyPhoneFormat : function($Gadget, $UI) {
		var phoneNum = $Gadget.phoneNumber;
		var reg = /^(1[345789]\d{9})$/;
		$Gadget.NotificationVerify = reg.test(phoneNum);
		if (phoneNum.length != 11 || !$Gadget.NotificationVerify) {
			$Gadget.NotificationVerify = false;
			var ismsg = $Controller.bes.agentdesktop.group.mobile.ismsgbox();
			if (ismsg == 0) {
				$UI.msgbox.info("提示", "您输入的手机号码有误。");
			}
			return false;
		}
		return true;
	},
	// 校验是否已经有弹出窗
	ismsgbox : function() {
		var msgFlag = $(".popwin");
		return msgFlag.length;
	}
});

//增加集团产品通用框架处理能力byl00185610
$Controller("bes.ad.grouptype",
{
	/**
	* 加载当前产品对应的js.
	* $offeringId来源于pm_offering.offering_id
	* $prodcode来源于pm_product.prod_code
	*/
	loadGrouptypeScript : function($prodcode, $offeringId){
		debugger;
		
		//通用
		try{
			eval("$(\"script[src$='bes-ad-prodcode-Common.js']\").remove()");
		}catch(exception){
			
		}
		
		if($prodcode){
			//定制
			try{
				eval("$(\"script[src$='bes-ad-ctz-prodcode-"+$prodcode+".js']\").remove()");
			}catch(exception){
				
			}
			//基线
			try{
				eval("$(\"script[src$='bes-ad-prodcode-"+$prodcode+".js']\").remove()");
			}catch(exception){
				
			}	
		}
		if($offeringId){
			try{
				eval("$(\"script[src$='bes-ad-ctz-offering-"+$offeringId+".js']\").remove()");
			}catch(exception){
				
			}
			try{
				eval("$(\"script[src$='bes-ad-offering-"+$offeringId+".js']\").remove()");
			}catch(exception){
				
			}
		}
		
		//通用 
		try{
			$("<script>").attr({ 
				type: "text/javascript",
				src: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp 
				+ "/bes/ad/gadget/group/common/grouptype/bes-ad-prodcode-Common.js"
			}).appendTo("head");
		}catch(exception){
			
		}
		
		if($prodcode){
			//定制
			try{
				$("<script>").attr({ 
					type: "text/javascript",
					src: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp 
					+ "/bes/ad/ctz/gadget/group/common/grouptype/prodcode/bes-ad-ctz-prodcode-"+$prodcode+".js"
				}).appendTo("head");
			}catch(exception){
				
			}
			//基线
			try{
				$("<script>").attr({ 
					type: "text/javascript",
					src: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp 
					+ "/bes/ad/gadget/group/common/grouptype/prodcode/bes-ad-prodcode-"+$prodcode+".js"
				}).appendTo("head");
			}catch(exception){
				
			}
		}
		
		if($offeringId){
			//定制
			try{
				$("<script>").attr({ 
					type: "text/javascript",
					src: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp 
					+ "/bes/ad/ctz/gadget/group/common/grouptype/prodcode/bes-ad-ctz-offering-"+$offeringId+".js"
				}).appendTo("head");
			}catch(exception){
				
			}
			//基线
			try{
				$("<script>").attr({ 
					type: "text/javascript",
					src: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp 
					+ "/bes/ad/gadget/group/common/grouptype/prodcode/bes-ad-offering-"+$offeringId+".js"
				}).appendTo("head");
			}catch(exception){
				
			}
		}
	},
	
	/**
	 * 执行指定的业务--$business来源于select t.item_code from sys_datadict_item t where t.dict_code='OM_BUSINESS_CODE' and t.item_code like 'Group%';或者自定义
	 * 这是一个多态的实现
	 */
	processGrouptypeBusiness : function($Page, $Gadget, $Fire, $prodcode, $offeringId, $business){
		debugger;
		
		//如果入参不合法
		if((!$prodcode && !$offeringId) || !$business){
			return;
		}
		
		//搜索顺序：通用(必执行)->定制（先执行定制,如有异常则再执行基线）->基线，prodcode-offering
		try{
			eval("$Controller.bes.ad.grouptype.Common." + $business + "($Page, $Gadget, $Fire)");
		}catch(exception){
			
		}
		
		if($prodcode){
			try{
				eval("$Controller.bes.ad.ctz.grouptype." + $prodcode + "." + $business + "($Page, $Gadget, $Fire)");
			}catch(exception){
				try{
					eval("$Controller.bes.ad.grouptype." + $prodcode + "." + $business + "($Page, $Gadget, $Fire)");
				}catch(exception){
					
				}
			}
		}

		if($offeringId){
			try{
				eval("$Controller.bes.ad.ctz.offering." + $offeringId + "." + $business + "($Page, $Gadget, $Fire)");
			}catch(exception){
				try{
					eval("$Controller.bes.ad.offering." + $offeringId + "." + $business + "($Page, $Gadget, $Fire)");
				}catch(exception){
					
				}	
			}
		}
	}
});
