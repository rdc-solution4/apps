if (!this.OC) {
	var OC = {};
}
if (!OC.Comm) {
	(function() {
		OC.Comm = {};
	})();
}

/**
 * Desc: 检验Filed域的是否为空,不为空:返回true, 为空:返回false; <br>
 * 
 * @param {}
 *            str |字符串参数 <br>
 * @return {Boolean}
 */
OC.Comm.checkNull = function(str) {
	if (str == undefined || str === "") {
		return false;
	}

	return true;

};

/**
 * Desc: 检验Filed域是否为数字,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            number |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isNumber = function(number) {
	var newPar = /^\d+$/;
	if (number.length > 0) {
		if (newPar.test(number) == false) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为整数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            integer |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isInteger = function(integer) {

	var newPar = /^(-|\+)?\d+$/;
	if (integer.length > 0) {
		if (newPar.test(integer) == false) {

			return false;
		} else if (integer < -2147483648 || integer > 2147483647) {

			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为浮点数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            float |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isFloat = function(float) {
	var newPar = /^(-|\+)?\d*\.?\d+$/;
	if (float.length > 0 && newPar.test(float) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否包含有中文信息,是:返回false, 否:返回true; <br>
 * 
 * @param {}
 *            strValue |输入的要校验的数值 <br>
 * @return {Boolean}
 */
OC.Comm.isNotContainsChinese = function(strValue) {
	var newPar = /^[\u0000-\u00ff]+$/;
	if (strValue.length > 0) {
		if (newPar.test(strValue) == false) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验是否是电话号码,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            phone
 * @return {}
 */
OC.Comm.isPhone = function(phone) {
	var reg = /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/;
	return reg.test(phone);
};

/**
 * Desc: 检验是否是固话,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            phone
 * @return {}
 */
OC.Comm.isTelephone = function(phone) {
	var reg = /^(0\d{2,3}-\d{7,8})$/;
	return reg.test(phone);
};


/**
 * Desc: 检验是否是手机号码,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            mobile
 * @return {}
 */
OC.Comm.isMobile = function(mobile) {
	debugger;
	var reg = /^(1[345789]\d{9})$/;
	var a = reg.exec(mobile);
	if (a == null) {
		return false;
	}
	return true;
};

/**
 * Desc: 检验是否是邮箱地址,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isEmail = function(str) {
	var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
	return reg.test(str);
};

/**
 * Desc: 检验是否是金额,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isFund = function(str) {
	var reg = new RegExp(/^[\-\+]?([0-9]\d*|0|[1-9]\d{0,2}(,\d{3})*)(\.\d+)?$/);
	return reg.test(str);
};

/**
 * Desc: 检验是否是身份证,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isIdCard = function(str) {
	var reg = new RegExp(/^([\d]{15}|[\d]{18}|[\d]{17}[x|X])$/);
	return reg.test(str);
};

/**
 * Desc: 检验是否是字母的数据组合,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isLetterAndNumber = function(str) {
	var reg = /[^a-zA-Z0-9]/;
	return !reg.test(str);
};

/**
 * Desc: 检验是否是字母组合,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isStartLetter = function(str) {
	var reg = /^[a-zA-Z]/;
	return reg.test(str);
};

/**
 * Desc: 字符串去掉空格 <br>
 * 
 * @param {}
 *            str ｜字符串 <br>
 * @return {}
 */
OC.Comm.trimStr = function(str) {
	return str.replace(/(^\s*)|(\s*$)/g, "");
};

/**
 * Desc: 检验Filed域是否为银行帐号(234214-32423-234234-23424-2342),是:返回true, 否:返回false;
 * <br>
 * 
 * @param {}
 *            strBankAccout |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isBankAccount = function(strBankAccout) {
	var newPar = /^[0-9]\d*[0123456789-]*\d*[0-9]$/;
	if (strBankAccout.length > 0 && newPar.test(strBankAccout) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为正浮点数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strFloat |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isPositiveFloat = function(strFloat) {
	var newPar = /^\d*\.?\d+$/;
	if (strFloat.length > 0 && newPar.test(strFloat) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为小数点为两位的正浮点数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strFloat |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isPositiveTwoFloat = function(strFloat) {
	var newPar = /^0(\.[0-9]{1,2})?$|^[1-9][0-9]*(\.[0-9]{1,2})?$/;
	if (strFloat.length > 0 && newPar.test(strFloat) == false) {
		return false;
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为无符号整数(不包含负整数),是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strInteger |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isUnsignedInteger = function(strInteger) {
	var newPar = /^\d*[0123456789]\d*$/;
	if (strInteger.length > 0) {
		if (newPar.test(strInteger) == false) {
			return false;
		} else if (strInteger < 0 || strInteger > 2147483647) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验Filed域是否为正整数,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            strInteger |输入的字符串 <br>
 * @return {Boolean}
 */
OC.Comm.isPositiveInteger = function(strInteger) {
	var newPar = /^\d*[0123456789]\d*$/;
	if (strInteger.length > 0) {
		if (newPar.test(strInteger) == false) {
			return false;
		} else if (strInteger <= 0) {
			return false;
		} else {
			return true;
		}
	} else {
		return true;
	}
};

/**
 * Desc: 检验是否是邮政编码,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isPostcode = function(str) {
	var reg = /^(\d){6}$/;
	return reg.test(str);
};

/**
 * Desc: 检验是否是中文,是:返回true, 否:返回false; <br>
 * 
 * @param {}
 *            str
 * @return {}
 */
OC.Comm.isChinese = function(str) {
	var reg = /^[\u0391-\uFFE5]+$/;
	return reg.test(str);
};

/**
 * Desc: 返回不同字符集下字符长度 <br>
 * 
 * @param {}
 *            str ｜字符串 <br>
 * @return {}
 */
OC.Comm.getStrlen = function(str) {
	var Charset = jQuery.browser.msie ? document.charset
			: document.characterSet;
	if (Charset.toLowerCase() == 'utf-8') {
		return str.replace(/[\u4e00-\u9fa5]/g, "***").length;
	} else {
		return str.replace(/[^\x00-\xff]/g, "**").length;
	}
};

/**
 * 替换字符
 * 
 * @param {}
 *            orgStr ｜原字符串
 * @param {}
 *            pos |替换的位置
 * @param {}
 *            replacetext |替换的文本
 * @return {}
 */
OC.Comm.replaceStr = function(orgStr, pos, replacetext) {
	if (pos > orgStr.length) {
		return orgStr;
	}
	pos = Number(pos);
	var start = orgStr.substring(0, pos);
	var end = orgStr.substring(pos + 1, orgStr.length);
	return (start + replacetext + end);

};

/**
 * 时间比较(yyyy-mm-dd hh:mi:ss)
 * 
 * @param {}
 *            beginTime
 * @param {}
 *            endTime |
 * @return {} <0 endTime小; >0 endTime大 ; ==0 时间相等
 */
OC.Comm.comptimeTime = function(beginTime, endTime) {
	var beginTimes = beginTime.substring(0, 10).split('/');
	var endTimes = endTime.substring(0, 10).split('/');

	beginTime = beginTimes[1] + '-' + beginTimes[2] + '-' + beginTimes[0] + ' '
			+ beginTime.substring(10, 19);
	endTime = endTimes[1] + '-' + endTimes[2] + '-' + endTimes[0] + ' '
			+ endTime.substring(10, 19);

	return (Date.parse(endTime) - Date.parse(beginTime));
};
/**
 * 处理校验报文
 * $scope 
 * $UI 
 * busiValidResp 校验结果  {
						        "retCode": 0,
						        "retMessage": "sucess",
						        "busiValidResults": [
						            {
						                "promptId": "11",
						                "promptMessage": "错误1",
						                "level": 1
						            }
						        ]
						    }
 * dialogTitle 提示框标题
 * succFunc 校验成功的回调函数
 * errFunc 校验失败的回调函数
 */
OC.Comm.checkBusiValidResp = function($scope, $UI, busiValidResp, dialogTitle, succFunc, errFunc, isNotShowDialog,closeBack){
	debugger;
	var succCb=null;
	var errCb=null;
	var fontList=["<font color='#333'>","<font color='#333'>","<font color='#333'>","<font color='#EC4E5C'>"];

	if($scope){
		if(succFunc){
			succCb=function(){         
				$scope.$apply(succFunc());
			};
		}
		if(errFunc){
			errCb=function(){         
				$scope.$apply(errFunc());
			};
		}
	}else{
		succCb=succFunc;
		errCb=errFunc;
	}
	
	dialogTitle=dialogTitle||$UEE.i18n("ad.person.message.information");
	var messageCount=0;
	var message=null;
	
	if (!busiValidResp) {
		$UI.msgbox.error($UEE.i18n("ad.group.message.MSGBOXERROR"), $UEE.i18n("ad.error.tips.businessFailed"), errCb);
		return;
	}
	
	busiValidResp.busiValidResults = busiValidResp.busiValidResults || [];
	for ( var i = 0; i < busiValidResp.busiValidResults.length; i++) {
		var validResp = busiValidResp.busiValidResults[i];
		var promptMessage = validResp.promptMessage || validResp.promptMessage;
		if(promptMessage){
			if(messageCount==0){
				message=fontList[validResp.level]+promptMessage+"</font>";
			}else{
				message=message+"<br>"+fontList[validResp.level]+promptMessage+"</font>";
			}
			messageCount++;
		}
	}

	if("0" != busiValidResp.retCode){                               // 出现error级别错误时的弹出框
		if(!message){
			message=busiValidResp.retMessage||$UEE.i18n("ad.person.message.NoResponse");
		}
		
		//$UI.msgbox.error(dialogTitle, message, errCb);
		$UI.msgbox.error(dialogTitle, message,errCb); 
	}else{  
		if (messageCount>0 && !isNotShowDialog) {                                                   // 出现info跟warning校验时的info弹出框
			
			//$UI.msgbox.warning(dialogTitle, message, succCb, errCb, closeBack);
			$UI.msgbox.warning(dialogTitle, message, succCb, errCb, closeBack); 
		} else {
			// 不出现弹出框，返回true
			if (typeof succCb === 'function') {
				succCb();
			} 
		}
	}
};
/**
 * 
 * 处理校验报文 包含header、body两部分
 * 
 */
OC.Comm.checkBusiResp = function($scope, $UI, busiResp, dialogTitle, succFunc, errFunc, isNotShowDialog){
	debugger;
	if (!busiResp || !busiResp.header) {
		$UI.msgbox.error($UEE.i18n("ad.group.message.MSGBOXERROR"), $UEE.i18n("ad.error.tips.businessFailed"));
		return;
	}
	if (busiResp.header.resultCode == '1') {
		$UI.msgbox.error(dialogTitle+$UEE.i18n("ad.person.message.information"), busiResp.header.resultMessage);
		return;
	}else if(busiResp.header.resultCode != '0') {
		
		$UI.msgbox.info(dialogTitle+$UEE.i18n("ad.person.message.information"), busiResp.header.resultMessage);
		return;
	}
	OC.Comm.checkBusiValidResp($scope, $UI, busiResp.body, dialogTitle, succFunc, errFunc, isNotShowDialog);
	
};
/**
 * 校验特殊符号
 */
OC.Comm.checkSpecialChar = function(value) {
	var keyword = /\$|\^|\[|\]|\{|\}|\<|\>|\+|\\|\*|\?|\||\、|\‘|\？|\！|\；|\×|\//;
	if(keyword.test(value))
	{
	    return true;
	}else{
		return false;
	}
};
/**
 * 校验URL
 */
OC.Comm.checkUrl = function(value) {
	var keyword = /^http:\/\/[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"])*$/;
	if (keyword.test(value)) {
		return true;
	} else {
		return false;
	}
};
/**
 * 计算字符串的字符数
 */
OC.Comm.countCharNum = function(str) {
	var totalCount = 0;
	for ( var i = 0; i < str.length; i++) {
		var c = str.charCodeAt(i);
		if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
			totalCount++;
		} else {
			totalCount += 2;
		}
	}
	return totalCount;
};
/**
 * yyyy-MM-dd 或者 yyyy-MM-dd hh:mm:ss 
 */
OC.Comm.getDateByFormatStr = function(dateStr) {
	if(!dateStr) {
		return null;
	}
	var dateStr = dateStr.trim();
	var dateArr = dateStr.split(" ");
	var tempDate = new Date();
	if(dateArr && dateArr[0]) {
		var date1 = dateArr[0].split("-");
		tempDate.setFullYear(date1[0], date1[1], date1[2]);
	}
	if(dateArr && dateArr[1]) {
		var date2 = dateArr[1].split(":");
		tempDate.setHours(date2[0]);
		tempDate.setMinutes(date2[1]);
		tempDate.setSeconds(date2[2]);
		tempDate.setMilliseconds(0);
	}
	return tempDate;
};
/**
 * 判断一个对象是否为空对象
 */
OC.Comm.isNullObj = function(obj) {
	if(!obj){
		return true;
	}
	for(var attr in obj) {
		return false;
	}
	return true;
};
/**
 * 比较两个对象，并将修改的字段保存到新的对象中并返回
 * 前台条件：两个对象的字段是一样的
 */
OC.Comm.reassembleModifyObj = function(originalObj, modifyObj) {
	if(OC.Comm.isNullObj(modifyObj)) {
		return null;
	}
	if(!originalObj) {
		return modifyObj;
	}
	var modifiedObj = {};
	for(var attr in modifyObj) {
		if(!modifyObj[attr]) {
			continue;
		}
		if(!originalObj[attr] ||originalObj[attr] != modifyObj[attr]) {
			modifiedObj[attr] = modifyObj[attr];
		}
	}
	if(OC.Comm.isNullObj(modifiedObj)) {
		return null;
	}
	return modifiedObj; 
};
/**
 * 验证身份证号性别
 * 男 返回 1, 女 返回 0
 */
OC.Comm.getSexByIdCard = function(value) {
	var valiValue = value[value.length - 2];
	var evenNum = /^[02468]$/;
	if (evenNum.test(valiValue)) {
		return "0";
	} else {
		return "1";
	}
};
/**
 * 按钮置灰，不可点击
 */
OC.Comm.disableBtnById = function(id) {
	$('#' + id).attr('disabled', 'disabled');
	$('#' + id).removeClass("btn_positive").addClass("btn_negative");
};
/**
 * 按钮恢复，可点击
 */
OC.Comm.enableBtnById = function(id) {
	$('#' + id).attr('disabled', null);
	$('#' + id).removeClass("btn_negative").addClass("btn_positive");
};