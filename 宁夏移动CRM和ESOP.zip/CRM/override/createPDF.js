;
var CreatePDF = {
	win : null,
	serialNo : "",
	unitePrint : "0",
	tempType : "",
	custCert : "0",
	busiInfo : "",
	busiInfoXML : "",
	newCustCert : "0",
	certContentChk : "0",
	proTempType : "",
	luckyTelType : "",
	pdfTplFiles : [],
	hasPad4Sign : true,
	cardImages : null,
	/*-- add begin l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/
	memberCardImages : null,
	/*-- add end l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/
	tplFileNames : "",
	servcard : null,
	delegcard : null,
	formNums : "",
	serviceNumber : "",

	/*--
	初始化
	serialNo：免填单打印流水号
	unitePrint：是否合打 1：合打 0：非合打
	tempType：电子免填单模板
	transActCond：业务敏感类别
	busiInfo：免填单打印内容(数组)
	busiInfoXML：免填单打印内容(XML)
	newCustCert:过户时需要新客户证件(0不需要,1需要)
	certContentChk:是否证件内容校验(0不需要,1需要)
	proTempType:电子免填单协议模板(支持多个文件,多个文件时文件与文件之间用逗号分割)
	luckyTelType:电子免填单优质号码协议模板
	pdfTplFiles:电子免填单模板数组(模板文件名称@模板文件路径)
	hasPad4Sign:是否有手写板进行签名
	tplFileNames:模板路径及名称
	--*/
	init : function(serialNo, unitePrint, tempType, custCert, busiInfo,
			busiInfoXML, newCustCert, certContentChk, proTempType,
			luckyTelType, pdfTplFiles, hasPad4Sign, tplFileNames, servcard,
			delegcard, newservcard,newdelegcard, formNums, serviceNumber) {
		this.servcard = servcard;
		this.delegcard = delegcard;
		//过户添加
		this.newservcard = newservcard;
		this.newdelegcard = newdelegcard;
		this.serialNo = serialNo;
		if (unitePrint == "1") {
			this.unitePrint = "1";
		}
		this.win = window;
		if (this.unitePrint == "1" && this.win.dialogArguments) {
			this.win = this.win.dialogArguments.parent;
		}
		this.tempType = tempType;
		this.busiInfo = busiInfo;
		this.busiInfoXML = busiInfoXML;
		if (true/* province == 'JS' */) {
			this.custCert = "0";
		} else {
			this.custCert = custCert;
		}
		this.custCert = custCert;
		this.newCustCert = (newCustCert != undefined && newCustCert != null) ? newCustCert
				: this.newCustCert;
		this.certContentChk = (certContentChk != undefined && certContentChk != null) ? certContentChk
				: this.certContentChk;
		this.proTempType = (proTempType != undefined && proTempType != null) ? proTempType
				: this.proTempType;
		this.luckyTelType = (luckyTelType != undefined && luckyTelType != null) ? luckyTelType
				: this.luckyTelType;
		this.pdfTplFiles = (pdfTplFiles != undefined && pdfTplFiles != null) ? pdfTplFiles
				: this.pdfTplFiles;
		this.hasPad4Sign = (hasPad4Sign != undefined && hasPad4Sign != null && "true" == hasPad4Sign) ? true
				: false;
		this.tplFileNames = (tplFileNames != undefined && tplFileNames != null) ? tplFileNames
				: this.tplFileNames;
		this.formNums = formNums;
		this.serviceNumber = serviceNumber;
	},
	replaceCertifications : function(formNumbers) {
		/*-- add begin l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/
		if (/* memberIdCardTemplate */false) {
			var topWindow = this.obtainTopWin();
			var leftCsp = topWindow.middleFrame.leftFrame.cutomerInfo;
			// var tabOid4E = getTabOid4E(topWindow);
			refreshMemCertOidToFormnuber(cardsOid, curOrderID, topWindow,
					loginServerNumber);
			clearTabOid4EMemberCert(cardsOid);
			var memberCardImages = null;
			if (formNumbers != "") {
				memberCardImages = getMemberCertFromClient(formNumbers
						.split(","), leftCsp);
			}
			this.busiInfoXML = appendMemberCertImageToEinvoice(
					this.busiInfoXML, memberCardImages, memberIdCardTemplate);
			this.setMemberCardImages(memberCardImages);
		}
		/*-- add end l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/

		if (/* loginCheckTemplate */false) {
			var topWindow = this.obtainTopWin();
			var leftCsp = topWindow.middleFrame.leftFrame.cutomerInfo;
			var cardsOid = getCardsOid(topWindow);
			/*-- modify begin l00201782 2014-01-18 R003C13LG1201 --*/
			refreshCertificationsInClient(cardsOid, curOrderID, topWindow,
					loginServerNumber);
			/*-- modify end l00201782 2014-01-18 R003C13LG1201 --*/
			clearUserCertifications(cardsOid);
			var cardImages = null;
			if (formNumbers != "") {
				cardImages = getCertificationFromClient(formNumbers.split(","),
						leftCsp);
			}
			this.busiInfoXML = appendCertImageToEinvoice(this.busiInfoXML,
					cardImages);
			this.setCardImages(cardImages);
		}
	},
	setCardImages : function(cardImages) {
		this.cardImages = cardImages;
	},

	/*-- add begin l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/
	setMemberCardImages : function(memberCardImages) {
		this.memberCardImages = memberCardImages;
	},
	/*-- add end l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/

	/*-- 获取顶层窗口 --*/
	obtainTopWin : function() {
		var topWin = this.win._ysp_top;
		if (!topWin.publicObject && topWin.dialogArguments
				&& topWin.dialogArguments._ysp_top) {
			topWin = topWin.dialogArguments._ysp_top;
		}
		if (!topWin.publicObject && topWin.opener && !topWin.opener.closed) {
			topWin = topWin.opener._ysp_top;
		}
		return topWin;
	},
	/*-- add begin l00227362 2013-04-01 R003C13LG0401 OR_HEB_201303_288--*/
	chgKeepCommitBtnDisabled : function(status) {
		if ("1" != "${eInvoiceCommitBtnAutoDisable}") {
			return;
		}
		if ($("#btn_submit")[0]) {
			$("#btn_submit").attr("disabled", status);
		}
	},
	/*-- add end l00227362 2013-04-01 R003C13LG0401 OR_HEB_201303_288--*/
	/*--下载文件 --*/
	downProFiles : function(proFiles) {
		if (!(proFiles && proFiles.length > 0)) {
			return true;
		}
		var urlParams = "";
		var fso = new ActiveXObject('Scripting.FileSystemObject');
		for ( var i in proFiles) {
			var tokInx = proFiles[i].indexOf("@");
			if (tokInx > 0 && tokInx < proFiles[i].length - 1) {
				var fileName = proFiles[i].substring(0, tokInx);
				var filePath = proFiles[i].substring(tokInx + 1);

				/*-- modify begin s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 --*/
				if (fileName != "" && filePath != "") {
					var existFilePath = "C:\\protocol\\" + fileName;
					if (fso.FileExists(existFilePath)) {
						if (billAndCertAutoDownload == '1') {
							var rtnInfo = this.invalidExistFileMD5Consistent(
									this.tplFileNames, fileName);
							/*-- 本地模板与服务端模板不一致 --*/
							if (rtnInfo) {
								try {
									/*-- 删除本地模板  --*/
									var f = fso.GetFile(existFilePath);
									f.Delete();
								} catch (e) {
									this.commonDealErr("删除客户端过时模板文件'"
											+ filePath + "'报错，请关闭打开文件的工具。");
									return false;
								}
								urlParams += "&filePath=" + filePath
										+ "&fileName=" + fileName;
							}
						}
					} else {
						urlParams += "&filePath=" + filePath + "&fileName="
								+ fileName;
					}
				}
				/*-- modify end s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 --*/
			}
		}
		if (urlParams == "") {
			return true;
		}
		var winObj = this.win;
		if (winObj.sourceWindow) {
			winObj = winObj.sourceWindow;
		}

		urlParams = urlParams.substring(1);
		var DownLoadOcxObj = document.createElement("object");
		DownLoadOcxObj.setAttribute("id", "DownLoadOcx");
		DownLoadOcxObj.setAttribute("name", "DownLoadOcx");
		DownLoadOcxObj.setAttribute("width", "0");
		DownLoadOcxObj.setAttribute("height", "0");
		DownLoadOcxObj.setAttribute("hspace", "0");
		DownLoadOcxObj.setAttribute("vspace", "0");
		DownLoadOcxObj.setAttribute("classid",
				"clsid:96A29281-312B-4512-8BF4-D0EE63556AB1");
		DownLoadOcxObj.webPath = downLoadOcxPath;
		DownLoadOcxObj.PluginFilesName = 'pluginXml?' + urlParams;
		DownLoadOcxObj.alldownload();
		return true;
	},
	/*-- 回调父页面函数 --*/
	callParentFunc : function(opType, otherInfo) {
		if (this.win.printCommitUnite4EInvCallBack) {
			if (opType == "OK" && this.unitePrint == "1" && window.parent) {
				window.parent.close();
			}
			this.win.printCommitUnite4EInvCallBack(opType, otherInfo);
		}
	},
	upLoadIdcard : function(custCert, newCustCert, certContentChk) {
		/*--调用子页面的printCommitUnite4EInv.usl的方法 --*/
		if (this.win.showIdcard) {
			this.win.showIdcard(custCert, newCustCert, certContentChk);
		} else {
			upLoadIdcard(custCert, newCustCert, certContentChk);
		}

	},
	/*-- 自定义alert提示方法 --*/
	alertMsg : function(message) {
		/*-- 如果是免填单调阅过来的，不弹出提示--*/
		/*
		 * if (isPreviewEInvoice) { isPreviewEInvoice = false; return; } if
		 * (this.win.printCommitUnite4EInvCallBack) {
		 * this.win.printCommitUnite4EInvCallBack("ALERT", message); } else {
		 * window.alert(message); }
		 */
		window.alert(message);
	},

	/*-- 获取双屏控件 --*/
	obtainDBScreenOCX : function(leftFrameRegWin) {
		var CurUseableDBOcx = _ysp_top.document.getElementById("DBScreenOCX");
		if ($Page.Corporation && $Page.Corporation == 'SHANDONG')
		{
			CurUseableDBOcx = document.getElementById("sdDBScreenOCX");
		}
		if ($Page.Corporation && $Page.Corporation == 'NINGXIA')
		{
			CurUseableDBOcx = document.getElementById("ControlObj");
		}
		if (!CurUseableDBOcx) {
			var topWindow = this.obtainTopWin();
			CurUseableDBOcx = topWindow.middleFrame.leftFrame.cutomerInfo.CurUseableDBOcx;
			/*-- add begin l00201782 2011-12-19 R003C11L12n01 外设控件回调 --*/
			if (leftFrameRegWin) {
				topWindow.middleFrame.leftFrame.cutomerInfo.leftFrameRegWin = leftFrameRegWin;
			}
			/*-- add end l00201782 2011-12-19 R003C11L12n01 外设控件回调 --*/
			if (topWindow != this.win._ysp_top) {
				var topCurUseableDBOcx = CurUseableDBOcx;
				CurUseableDBOcx = document.createElement("object");
				CurUseableDBOcx.setAttribute("id", "DBScreenOCX0");
				CurUseableDBOcx.setAttribute("name", "DBScreenOCX0");
				CurUseableDBOcx.setAttribute("width", "0");
				CurUseableDBOcx.setAttribute("height", "0");
				CurUseableDBOcx.setAttribute("classid",
						topCurUseableDBOcx.classid);
				CurUseableDBOcx.setAttribute("VIEWASTEXT", "true");
			}
		}
		return CurUseableDBOcx;
	},

	/*-- 下载PDF(废弃逻辑) --*/
	browserDownloadPDFFile : function(dealNo, filePath, svrName, password) {
		if (window.ActiveXObject) {
			try {
				this.obtainDBScreenOCX().SetLoginInfo(svrName, password);
				var rtnMsg = this.obtainDBScreenOCX().DownloadPDFFile(filePath,
						120);
				if (rtnMsg == -1) {
					this.alertMsg("发送合同到双屏失败。");
				}
			} catch (e) {
				this.alertMsg("下载合同到双屏异常，请联系管理员。");
			}
		} else {
			this.alertMsg("双屏控件问题，请联系管理员。");
		}
	},

	/*-- 生成电子免填单 --*/
	doEinvoice : function() {
		debugger;
		if (false/* "${isESign}" == '1' || this.custCert != "0" */) {
			this.upLoadIdcard(this.custCert, this.newCustCert,
					this.certContentChk);
		} else {
			this.toEInvoiceCreatePdf("");
		}
	},
	toEInvoiceCreatePdf : function(rtnObj) {

		debugger;
		/*-- add begin l00227362 2013-04-03 R003C13LG0401 OR_HEB_201303_288--*/
		this.chgKeepCommitBtnDisabled(true);
		/*-- add end l00227362 2013-04-03 R003C13LG0401 OR_HEB_201303_288--*/
		/* alertSaveRecInvoice("保存电子${billFormName}中，请稍后..."); */
		var idCardIdiograf = "";
		var cardAddData1 = "";
		var cardAddData2 = "";
		var otherCardPath = "";
		var otherCardAddDatas = "";

		if ("" != rtnObj) {
			idCardIdiograf = rtnObj.idCardPath;
			cardAddData1 = rtnObj.cardAddData1;
			cardAddData2 = rtnObj.cardAddData2;
			otherCardPath = rtnObj.otherCardPath;
			otherCardAddDatas = rtnObj.otherCardAddDatas;
		}
		var parameters = "serialNo=" + this.serialNo + "&unitePrint="
				+ this.unitePrint;
		parameters += "&newCustCert=" + this.newCustCert;
		parameters += "&idCardIdiograf=" + idCardIdiograf + "&tempType="
				+ this.tempType + "&proTempType=" + this.proTempType
				+ "&luckyTelType=" + this.luckyTelType;
		parameters += "&cardAddData1=" + encodeURI(cardAddData1);
		parameters += "&cardAddData2=" + encodeURI(cardAddData2);
		parameters += "&otherCardPath=" + otherCardPath;
		parameters += "&otherCardAddDatas=" + otherCardAddDatas;
		var isMultiCardReader = "true";
		debugger;
		try {
			// 每次清空 c00311908
			$Page.servcard_upload = null;
			$Page.servcardData_upload = null;
			if (isMock())
			{
				this.servcard = '身份证|12311456413136543|女|19900101-19990101';
				var servcardData = '/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAGbAUoDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7113xLrnivWr/AEbwzdro2labJ9n1PxAYllm8/aC1vaIwKb1BG+VwyoSFCu27bPN8J9OmtlMuu+JL2ZuDcv4gu1Y5AGcRyIg5weFA9utTfCm1jtPhd4bRw7XU1nHdTSlD89xN++kbP+07ufxNdQLiC6tGieN5HAKkqh9ODnt271Spx6r7zO7etzk7j4WaW9i0kd1r0rmMlSfEV+hBwef9dg9T6fpVW2+HOgtaGV5vEyqWcq//AAkN8do3cZ/f44x79/Wuwsord7CNpRMkgDBmbfjd3Pf0607SzHFZxrDepGqAqI3YFdoOQecEcMPzqvZU19lP5E3ff8ThbL4b6ZeO/k3OuTQrn5T4iv1c+nHn8/Lzx6io5vAGj/asrJ4jgCLl0uNe1HYzc/KD52V45yR6V3dpLJPBIZLAXarIY/NikBJxhcr0PbsaopdNY6pMTKYY1wYlvWK72ZVGN4z0CjBOetaKlTu/dX3Im7stWclJ8O9Is4I0upPEMcoUYlj8QX7q59CPP57cg5xz61Uk+HmmIU3XGuI00uA0XiK/lRVyRgfvx6dME88dBXdX8Uh1G1jsYPJYfvXUsGgJ2uF4BwP4uRjp05qK6R9Mt4hcWzphdjTWKb1kxxiRCMEH86ap09+VX9EGrdrs5Cb4daNCsrS32rvISPLVPEd+q5zjj98DjPVWx3wahj+HOjr5YW61yVmHyL/b+oHe3cKpmBxnGQTlT03CustV+0qJl3KJFKvNABLHu4CqVboAp5DE47VY3R2ds8YuE6Evvf5ZAe7E4/I4YdjTdKmtOVfcv8g17nGv8PNKDbWn1eQ/dxF4hvigLHj5jOCwwewyvcVO3w30aHczHXIotyjfPr19+65GS5E/Q9Aw9TkAV1MIWaaJZfOjikJuTPEP++T74yPmHI/ipl3K1qkRRZ7mBNzwToQBIxyoIx0ye3Kt1ApezpvTlX3ItJ9zlz8OdEuoGMMmsKZFYq512/cRc4UtiflQDnIweB9atx/DHS3kUpFqc8By0gj1+9kwu4AFD54LcA8EDrkeldBgwXAJeNGkKr+6lwPLUnO1iccncCjdMgCpdPgmjV5ysWn3bwgrEpCrgAnch5HLHlTkDj1qHTp20ivuRol/Wpy4+GegRabJdNcarLsQGInW71gzkthT++GeNoPTBz71Bd/DnTFiiiFnqIZnDeYut3zAqCAR/rc4OD05wOldbNGsAtI77MUzPuZomKrLnCKPqAxzn3Iq/wDboTqr/ZkSS3s41LSJKMKAG4/8eP4g9xU+zh/KvuRojmbb4S+Grjz5YzqTxphY5W1m9ZSQvzEjzueuO2CO1Zdt4J8PQ2TS3VnfrJcNst3TVrzymPTduM3yjJz7Be9dLeot3YOBLIl7eThZokcqURycAp0IxxnHPPNWpp/K12C2ukjeGyi+R4cAMWGFBU4wTjgAkYFT7Gm1dxX3I0j2RyFz8JdGtbiKyZ764aSPzZVh1G73KmcEpumPJHAx9cE4qVPhf4YkvpI4IdQuLCLbJMw1S7L7j0VcSA7e5HscdDXSwStptrcalFFLDDK37iF0DgJ0QAbgw3e2Rgj0p8m+wht44p8T3X7x5oZA6sSfmdgQcDnG8dyBQ6VN/ZX3IrV9Tlx8L/D99ftFbQzvb8iORtTugLhsZKBhJwQOdwHOB6VA3gPw5hYYtOkeaDcs7rf3GPLPYjzeHGRnqAMnkEV2osp4tml2wFrDjeVbMnlAHhkfOWyT3yRzUTSR2MMNrHZTCZyAIlBKrMOd27GCGB69xxjmkqVL+VfchHKTfCDQrWC6KQ3BkjZSQNSuGXawG0hixI5BBPcAn0FS3Pw98JEyWttYzSTyQiaBY7y4kdcZDb/3nHTGTjkmt2KJpGt2u5FjiIMTADescW4gqC3dW2glhwCSOKBDp+lXNvvdVijLJcxecfvjglhx94YYk9dvSn7KnfWK+4dl1ML/AIV/4X1pGhttJkaWS3ZSy3MyiCYZzljJ/tDgA8D3qvZ+A/C+s3FtAmj4ujCHlJvJ1TcMZYMHO4/KwIx9cV0st1a20llM9u32aCWS2mkX5Y2Qfdbgjd8oB4B4BqK4ItXsrl7TfAkjw7RIQ1wvzbfkHouDz16H1qlSppaRX3Al0SMCy+GXh64e1tU01Ay70a8FxcHJXg43OckZJ5yuG9qrj4ceGPsrNDYpcQwXYS5upbpydjOMMnzdMEE9F64rrNY/0sWuoLGquZlZbOFtzPGQVy/8IOPbjGMmo4Z47h7pbmOK71A7hEYT+6jGwHcue5xwOpPHA5p+zhb4V9wtjnpPh/4SbVEgs9DeS2dRgRs7SytHg9S+UU7wCxweOMDmoX+HHh9/tcc2n2tqtuxVo/mAizkjzX3fMSG+VV9OeldffvPY3ENw7iCS5zFNcKwaWVcZDAYxGq4+90Xdz0NVFmRbqQR2sNxO6L9mmlBaMEZ3BA3MhGQS/Tk5OBTVOG6iZM5r/hW/ha407dbaBGrPHlpbqZjIwHcc4Vdw6nBOMKKif4Z+ELq2aWz0IXJkDlZUh8tVAAyYoyfmHQZbI47munsJbK8kkVlkvbgy7/s4mVow5G7cAGAlP/jox0ANW9PeI/ahFHNNIkoLQorGKMcgFtvL4GRsHCleg61XJBfZ/Az1OUh+GHgm4hjuRolnfmRR+8jgcQIR97vud+p9u+0Zqxpnwp8HPZgzaDpzvjLxxwqJBjAzJJnagOAflx6jOa6eyfTrSS48uczTK5BMdwI02kbhk5/dryflHOQeKZZW4tnKh9kTSFo1K/IeBtKREbnbGBlvQUvZwV0l+BF3uc3YfCHwh5ayHw3oZRJGieSe2AjwScBT95zggDOOCaRfg94NjVyfDOlgB2Eck1nHkkHlViPJzgcnkZP49Vc/aLKc3fml5NuWjnUNOABjcAoITgfpzU1pMkU9zKzvHICXMacsFIHLO5wB1/LinyR3SX3Cucza/CfwMZdreEdFiLlSsk9irOylRwqgAdSeh/Cnp8HvBIs5Jv8AhDdIgZi3zzWsOW+bAwu04HIPbGa6qIRxR2xhjRpiEOYA0juduTlsj69aWxCQxwwtbrbSRnazFHlZivUg46ZA5zS5I7pCTfU5WP4SeCGS6T/hCdGmmVsBnsYghycAgbQfQ9PxqTUPhF4Fik2J4R0BHVSVSGxj3Y4Xnjrzwa6y4lzKJ2jE6easWZE2DjOOe2CT1qx5hkhlPl2/lTfIv73HGOOg55zQkr7B0scFqOg33w58zWfCP2++0yFRNf8AhqaZ51khGSzWnmEmOcDJCA+W+3bhWIavRtO1GDVdPtr2zliubS5iWaGZX4kRgCrD2IINU7EosUeydzJMwUgspYYwMk47Ba+Gdc8bar4d1rUNKsdUlisbG4ktYI1PCxoxVQPYACuSdJRfuo0TfU+xPhtcG28CeF18tmWTSbMpxgk+Qnrjtn8hXQW0s0NxcoqLmQ+aFZyMcDjp7VzHgGaS5+HHhC4hj/1GlWZ3kjn9wgYY9P8AD2rp7rzDD9piKOYjuGFIJXnI6+x/KuyxnshlvLcWl5LbLBvjceYrB9qoOQRnHPbjFMtFCXt3DJaQvIxEz8g53dhkcjIbr3p17DLAsN207NsP7wqAAIz1wPbg85puox/Z7iKeOZ/MIMbAKDwR1+703AGq3FruRW5htHvIpkuLRTKJIzEp3cgk42Zzyp7Uy21ANfXFus8c5KIxW+XyiR8wAxgZ6HsKle0exvre5+1M0kpEEsrov/AfTAzxgHjd7069WazvRcOlvPFKhjcMCvIJZeOQTgmjS/qFrGctvNZa1OYwdPiWJXKRBrhDksM4OCBgHoPerF5fXN41pBA8EyMxk+0W77mAUH+D1+YH734VDdGez1C3dLd9PjkQp8gDrGFBblcemRtGMYJz1qO4hlu9Qjliu0uHZXIks9sUwxtzklsE/wC9kYGMVT3TYXeqLs0gjgaaPy5FQbDLB8soIO0KyNw3TocVT8m3+xM89u6pIuZnhJZOcn95Fwcdsc9sdKNRhN3eWsf2lZZVmC7ZIfLnTClsBxjIwPTB45NWr6W5tbaSeRd/ljrtMM6ZPABGVbr7DkZ60bJeZRnS3SRiKKG7jXJAWNXwnJ4Cnqp6nnBAyOatW0R0+WVrmJbkOwOzIyqD5U9AfrjBJxkHimWlmYbZ/OiAuhjzZLeLc6+zxEZYZyeM8kkHvTG0uaa48u3maBUPmLFGSVDYzlGI+UkHgdOO9Da2uJXHwQx36tcLIDbMWyz/ADbV3fKpfqvHcgkZ5PNJb25v554oZop0XCmBztlA4yUI+UEkH5l4OOlJPeTWO2GIM3mgJ50fysEJC4cDByMnDA5+tVnmgh0xl8sW0ioWWEkbo8kkGJhwy8jK9D1HOaWrVzVF+3s1ub6Zoyt1HDgG2kAUgA4x/skHccEAE/nVa1+zjSp3sJkimml8oRAAifJAxt6jPzc9hnOaje0tYdJMm/zkc/LdB8PBngKwBBxjp7tz6m7deVBdaTaTvH9mjDSx3CAjhVAzuHCnLDBBwc/hSNEEyQ3Op2Vvcj7C9hEG8zcCWY4AAfGBwrHnk54FVbaK5GggKguJtUfImf8A1m0nvnriMcYxipJLiZLLWJPLW8t7l/JS5kBIbA2DIxyMkjI46mrkKNZ3MFxF5F3a2tqzAxOR5anA+XcSCAFPof5VL0NNkMkRBqcJSc28Vv8AvVt7onbvIK7gDygABxnjJOB3qzZQLCj6o80MAmyMeWfL2E5AUHBBJ5PqT04ptjI19ZqsKSefeYlnkZGTykPOPm744C9s5wBTjZEX7jT0jEds6k28oKxM5HJXHQgHPQ8nseksPIbeQrHbwxacfN1NZDteX5WQdGLA87cYGMY+6feo7y5tILUT/a5mJ4ngZsycA5YLn5WU8k4xweop+oaWI999OvmX822ParkMox92NjyMYLZHofpUtprCpFtvmid3IhWSENmUlQQB6lgcgj3HBFLpoLpoUL22umty13OFzG0yrbDG7/noM8jJXnjqScCmRW9tpcc6ycxRBWO9iUcryxIJOdyEEE5PB9Ktp9r+wPHcQpJ9kb5liyJVTBKspycsFOMZ55GearW1pZJcuL+ZJkERAluHG1VTlGX0yh69RhuadzS/QrQS2VuxVImuXidHt12tuZAdpxuwMFCpz0PNR2ksNjNJGkMKSfahsuHcMiJkBoy3fAb7vv14pss1i1m6R+VcsuxpRtUhnwY2YsTyTlWyM8CnS3FzqETLao1qHnSRIWjK+USBGdzdFAKn5QCST2qtyxZIXhspQssdrpwuQJDtEUkjAhwQRgoMH3OMEYFXLpLUzXqafLFHavAPNfbujQYYKy45L5HQdee+M5X2p7lbtrmZGu2ZRJ5RMkjMpwUj28Iny53E5x1xnNAt5hMj20v3UIj8s7lU88RkjkgfekGByec1SRnYriWY2cd3PI9wIfJ86GRQVfj5dzDnnnEQyckZ5xV0X328StdRpqEm7YseCqOcnAI9uB5S5PPzH0qy3k7aeg8pRbsw8l4ZeI2LfKSTggFuDJ94/wAOetD3M0nkGW2khuIshbZF2qUYYKhVOQOR8o+Zv4iM4quXQzltqXoYbFdTlmvhJOXxG1sse7DDIVTt4CkYwinHy85Ipz30F1dyMyRRw9UDOsewkAMrN1HQHYmfvEZ4NRQXwhuI5jutomP2ctNiIjBIC7AMoMnG1B/dy3NPhjhuHmSO2jnilXzRJLDsCKQA+3J2xnOTnluR1ot1ZzvUktLWGS5mtvIEsiBeiHIU9QsYICDIPzM2eOlPtvMgt/P+1yJOSEmRFLZUORlpOACeOhGR69az4NUtYZIkub97mZh5EtvCFVVPzcDpvOR0ORz0GedSJJUt0P2JTE06pBNOVLgFxhfLyApBGOvYcU3fYjYtSBZNLuI4I5ZEIKFWUQxgnkHaOW+8PUHPWrN7bSsbhDJFshtWygiAQZPHfPQHBqs0N7cTyCS5ESXEvlNt2mQhVzuBx1BXHfp7UxrWe4kkikuldp7ny2Lg7ii8EgbsAde38VZ7dRvU0I57qGRXkthi1t+drjBJ6np6L0x3pJReWUcVwV3OsbJhcsd7MCPTqRjjpUfkzPLbxmV5jcBncO7J8qHg5A75FSG4uLN/3jbowBIyvK0uzBwOSAeuPXkcdaT8g9SK5muLSFvLDSpEu5g8W0hm/wD1k81dEUEcocQAJACv3R1wM9PoB+NVFvnjRDIYH8xi8rxtnJIwoIPvgc9hUyxRxAKJj5VuoZ2DZDSdhzn+fcUALZxvaojIsckYIjjBbHU+uDnk4z6Cvz48bW3/ABWevZzn7fcfwf8ATRv9mv0D09o7eOIGSQPCoRY37t3xxyM8ZzjrXwJ4xlT/AIS7XN1xGW+3T5PH/PRqmSYrXPtr4aGaDwH4XB2RwzaZZFN2W5+zx8dRjP8AnrXQpauJTbu5W2K7wqcF/wC8pPUDnt2xz1rn/h4n274c+F7aVsMuj2ZwU5/1Cd/xramSKeOTzrgfakO0eaw2g54wPRs/rVq7JtYIEtbV5rW4YFACytLISGQnGDz26flWD4x8SReG/AviG/gto7iays5ZSJAUV1CnBZ8HoM+vII4rZmeHUbOBoIf9JV8+UiDtwwJ/ukY59xVfxTZXXiPw7cRWkk1h58Zja5Ty2dYifnAVgy5wD1HBFXFJSXNtcmV2monhOmfHbxRdax4b03VIrC1t2/0O6+2XMcT3lxEkqyTBgG+RpY1K4UHcpGcc17zJK2pafMZkuftIdtq/MFjcEELgYwOByfXNcFa/BaHQpNOm0XXNS0aw0uV/strBLHNFbh4/LYp5kbMRyScn+I4Aru9WhwZ7W9kheyv4XjuFWHdu+XaeCedwwuTkZAHeuuvKjJxdJWOWgq0U/aO54Knxu1rVPG0thaa3pdlJ58FwdO1IJLBp1ntdWc3IlAa4YZzEM4LKB8oJr3eeWSVhqC7LkRMQGBVW2FsE7V56jOc9B715refAWFE1TRrDUpdJ0vVvOnhsYLeHyLbcsYaIDyyeig53DPPTHPeXNv58MsckEbJHM0ivGRl0LP8AKGIzgHIP1HrTrulLl9l/WwYWNVNqocx8ftYn8GfB7xj4hXVtRs73RNKutUgksUgW4Jt4TMUjeeGeFPMEe0s0TkByQMgEfnxdftAfFzw/8Q/GF9deKfHdzZ6TZanqE1kBcJhIbPRpT8svhjy4sb875IIUTzdzNAJTLe/pNcWmn6tp95pmoWMeoWN7A1tdW17D9oinRlKPG6OCpQjIII5xg8Zr4a8I/sIa/Y6T4K0zWPD3ga5i0680p9TuGm0ub7XDbXEL3C7F8PRXDeakbrte8y2/EjyAvu8+cZX0PVULHt/7SvxP8ceF/B/xI8M+HIrXUJ/DngAavceKdT1l9P1SOSZL+IT2yWtmUaVDYvIcNAu9lChAMj1XSfHHjnxDfePfBmoeH9I8L+LNJ8OWd/pt5oviBr6GQ3ZvoYd0k+noIWR7InJgmXDg7WwVPFftAfs9+GPjnovi+4k8KaPeeOL7w3Lo1hqur2wm+xuFnMDoWVzDtluGYvEu88H5tigblh8Bvhvotrr0dr8PvDun6frqW1vqGmw6TBHYX620kkkXm2oXyi6PKzbtuSduSdi7RxehXs2eUG4+JF5qWuXNp4++I9zc2nhHRPEGkeHrrTdFtdTe91Ca/iW0ucaW6wYe1gVmZdsOZXkbYpK/TgkkuZvJeJJoY2DSgDy488kKoI/due4zj6E146f2QvhzYfEDXPET/DP4ey+G7nSNOs7SyGh2rLBcwz3zXEpjMOweYtxaruU7m8nBA2Ln2Dw5pek6Nodjo9iiaJBaxrBBHaw+VaBVXaI1TaE2KAFEeAQFGOlON0rsz6k7S293qqNIrW7wx+bLPJCRIjbsKJRjB/i57jmrFoUtb6/vIvItnRVXYGzDLgbmwR0zkHj8Qais7eSOVS6Sx3Dt5kLKdrYCgAJuPzLgDKNz+mJElMOnMbV1ilmLM8Aj2KSzkFoycDI5PHUDPuU+xaGaZcR3gsYbCcCZGMs0DnKZwWzx3yeq8ccirFzFdJaXosYYBNczBJJFk2ZkyA20ccAA5ORnnipRJY6ncwyBlgt7dWRJf9W4kJBwp/2QvPUciq1hfxomnCWY3Vx83kwLHs3yNncSx+UkA4Jz1z3oNNxl3fczF57mcWoG60uU2iRsZIyoHAGDySOc0xtHvC9vbLG0TyHzbh1YeYhB5ET8lRzt+h65JqvLrk0tuIWEdq11cPMBc52lQ+Q5bptyFAXGTinrdapIkl5Glz5spWEK4CuoBPU4C9SeBg9+MCizNFew+3vLnTjJeTjy44mMcSlWkDHIUtuyQpJwDj69M0jW9rJaT6j5MR1A4Etq0eArZyqID33DnH3st04w+DWDDObfUYnFtZgKFWIjJI4YgnLcdO+ScjpT7qyuNLmj1REZSBhYQ+ViU9mz68cggjkDIoAtWki3ssYae6srtUIRsqfNQ5IVgcglefQ8H3qOPRrVUNw0DSz2k22RmBZmjXjAH93awIA469ap3yz3Nv8A2pYlLaOU+YMMHZWGSSSOFJO5SAT949CeIbprfTJLe5t/llYmVWYtJKjjcrbiMkhiFGcY64qbPoFn0JJ5PJnu/sduLmODewdMFI0cK3y+mGU/L15NQ3tvfXC3UstxHHbmRg8Ui7d+F81eVP3cM2B19TWpbXNzqmrS3VuqWtlPbAJJLHuZ9rnlum0YJGCc9TxWKbwzBfsJkvvJMThyQ0Vu6naVbpuO3GCew5NUrhuQ3QtZ7a7uI8tCJEkNxJHiQocKVwBgLgHCAbjxx3pzfawLlFl+0xIODOMNJnG0ED5fl5GPujjdzVjVNOWK4ge+uft10T5U8byErBvUhfu45Le2SCQMDmpJVTRZLWS4kYO2IUaVVdnGfl/coBgAjjnjPI7i7he6KcEF28aFgLa1uXd4bhySxbBPyqBktjJDnnA421xPxo+O3hn4HaUl7rd0Bdk7IdMs5Ve7lycMQu8CNeCTyDxyWPFZX7Rfxns/g94HvL2e8+z63MksOk2UsWbhmwMs2GwsalgSF7becnFfkf4s8W6l4u1u4vNQupLq7ndpZJXPzSH1Pt7Ucy6s4qs2lZLU+1tc/wCCk8lnJqEWh+ELSBJjtjmvbkvKMAjcyquBnjIHfvXn3xH/AG9PHvjzw7HaRSJpr5ybixJRh9GzuGe/rXyfJp0t2VVG2k9h3q1H4ev7SMggunuef50c8U73MUqjVzp5/iT4jn1eXUW1a8W/lfzWnE7h2brncGzxXrfw9/bS+JHgG1S1GvPq9kFwLTVMzBTu3EhvvZ6jOeB9BXgsUKwW7eYG80ngEYqMj0xuxxmt7RkriUGk3sz9Sv2bP2w/D3xfuINC16OLQ/EJCiBEl/cXDA5YqeCG5JKnqDnJwcfT8ttp73syw7FeRxEUQqQv8Tv0ODjHPrjvX4P6TqV3pN3Hc20xhuI3V45UJDIwOQwI5BB7197/ALI37XUOtQw+DfHmoM90wENlrEmGdwcYjkJ/i4wrH2B5xnOUddxp2VpH3fDYmGOO5huJhEIiuwy7Qsecgg47D1HemwXc0bP56PIxdXCu43EY/dpngZPBx65pu24ktxH9qLlI0dg0aMhbHCcY68d+wqSLM8ZDRLNI2fMhYjDyE4xz1CgcVj01Lt2LEgeYPH88czHczZG7ecY2nuF/kPeorm2dim8xARyBVmjyjM579Oxz/kUx7VUkQwK2FU/vY3Occbm5OOvAGf5U8tG0yxukhtgoZUKbiFI4H/AsY/D3NNeRLJzdGNopnhKx58uFFOQM9XIx7fkfU18Oa9byNrmolp3LG5kyWC5+8evzV9uSGO4mhzvNwX+eIFgQoOduD+H69sV8a6wjnV747if3787D/eNZyS0DU+p/A4SX4ZeGDHJK1wukWZCDngW6HAwOhGf1roxgpFNYxOrL95QDtYH7wPbPbP0rn/h/E1v4G8KTpGoibR7MFuMZMEfI9+B6frWd4+1jXdL1jQk0y/ttI0WeR59V1b7J5/krEY5BFgkCESx/aMyuCq7dow8kZqpS5IczVzpwtB4qqqUWlu7vbRN9E300STbeiOya4Z91/DABEU2uW+8wB64H93n/ACKh1B5bODzo2jNvPkyFFzglcBhzwDzk/SvF/h9d2ngnWNU1RV0Pwv4BtImtL3UNMmFnpt/eb4US6jgZAsO0+dExDtuLRLvl2DZ3Hibx7omj+Ar/AMWadqNlquhQW8jWt4t1G9qJiTH8shcK4DZBGc5yo5OBlRrQqq70f6d9baee3y1PQx+WVcFU5YJzi2kmlrzPaLSckpdeW7dmrpO6XYuEtLrybm6PkTghQJAi7sfMD6ZxkHPXIrMie2Y/YrmVvJuVcK54edAQFXPUYAzgYyMHivKPC3xp1S713RtNv/DMlvY3dqw8tnt47iWURwsSu6QHYrSNsIyXXaRkg161eSX1lY3okjt47mNHu4riWTZkjOCTjGRjB5xg+hrvlRnTlaX6Hz9OtCorxexGluup2v2JVZri1lXfPJuCkLyG567v7v1qK61JLm3WcYiEDKkcCou1CAM/NzkZyAP9n8a8Qufj14gvPDuo3s9nYjUJLRkBQNGkEsdrdSTRsu5jIFeFF3AgHd/smvcppXufJvhIhEkSmWOJcAbSCTyevJGR2rWrQqUmvaKxWHrQrSvAjuMyyNIqzwRgAo0Y3IVIPGSMjJwO3c9Kk+0i5urRJJBCGldSxcHC4XjHAHBIHHFcf8afE134A+E/jjxPYvZz3eiaHf63awXRaSF5YYGeONgpUspZRkKRxkZFfM/j/wDad+IHhkeNfI1ayuD4Z8OQ69b+d8IPEdl9qkf7ZmKXzLr/AEaMfY0/0iX923mPj/UvXLKSTsemmlofXaxn7RFEkvy7j5e9lIJBbnGOM9sk1LNbme2huYRLIryHG4hcbd2QACR2PHHPPNNkbabXyoQjb9wlRRkEnp74Jx0qeGJnt0Ma4UschUYgEjB4BI5OfzFW+5TexK0Ra2R/s3nwsAxlWACMklR90c5PHTP4c0t7qAlDFvJhuZThpbdxID6ZUgbwOuRhhgYrI1nUZ9M8KatfRSLHd6XaT3awzFjvMaM6jAYYGV5ryvwr8aPEuv6/pthcXOmXkMj2sl9HPHBEuybJUo/2hskFcYAJ6AgGtKdCdWLcdkcFatCjLklu9j2GV5ZLGS3jMsizsYxvkJ64BOWw3QnB4ZT1DCrr6kNtvZ310jxLID+7Us8gAJVcAdOM716heoNVNSidE8+WymWdWLgea4V5FHyoN3qcANwQM4rwKx/aC1eXVdNVtKs1Ei3Xmrvd3Lu2YQSiMUIQYbIZXLA9jVUsNOtF8nTzHUxFOjZTe59CXF2fNvJIbgecsJjill2oy4yWWWNsE/w/MBngdOpge0igtri2muIIrVbHyxbxyLIMnOcbgNpJXpyB7Vgz6lDY+GtY1Fryw0c/YpZpNQ1dDJZ2SrCWMkp3xF4EOCULRkKudyg5rirnxl8Q7jx1qvhXT/A3hSe50fRNN1CW8uvGN1AqJeNcIYY9umOWCS2U65bG5PLbClmROSVovlOxSXQ9ct9XsdLmDWyvsS1UI/Ijdy2Ad7cY+Vcc/wAR4oPiCSMxbbGW5e3jLRoAwMj4wWJClRwT0Jxnpwa5X4WeM9N8e/DTwx4vNtDpkniPS7DUHtPO8w2wmt1mdWICg4Dld4Rc4HA6V2v9o2t555+0bBOwaTeCm23TPAB/vHP13H0pO25fnYr2Wo2upWxtZpwqgNc3cko2eb3+UjsMjPfAXjrSWCRabNGlzbSvYOCts03OzJ6bAMAtn68jpnjTbT4NYSWW4wLuQh4j/wAtIFAOzjt6ke9VrgRXdvJFqV7m8XCrGg+6+PldUHLEjnv3AxUXQr9DPSL7LqX9nXJmisb87tsirukJ42uecZ6Ejn7uSM02w/0K4u9Mtcy3UmFV2cYEigcs55KkckcnIPFS3MU2taFOt3dJHd2WQwdFGGwMFs+o7cA4qvfzz31lbarbbdPhjRFWYhcO38LBRnYASQM5+90xVIvV7/12GQvCsq22rzJKwY+Tb2xKsZCBuyDyc5PXCjBOM4IW6uGsLlrXLC4ZpEFvEf3casA67nPUZyDu4wGGOlJc263tkLjTg1qt1tjZUXdc3L5O/G703cluwz8uM1WGqyRQ+VLDA8W4u6S5MKSE4+ZsZldXBGADjIOelUtWP0Fi1pJLQiWIFXAkha2jaIJ0DCBQCzON33uM9OOlXVaxTzvPeRBgnE0m+6mDAEkt0QfKOh7dR0pbOWzlv/LMT294CWwSPOkPIOXHEa7sjaPY968i/aq+IMfwp+D2rXdjqC2+oXY+x2sEL7QGk25KyEZdk/1gHoCOnReRlNqKuz4C/a5+NUvxJ+J1+IXT+zdPLWVqsR+UorHLkdCWYsxYAZGPrXDfCz4USeLg9/NGxgDARgfx8dR+OOK83kkm1bxA8W8YM6rgDoDjjP5191fB7wnDpvh3TVSMKWjGfU9efyrzcXJUtE7jy+l9Ynd+v9fIyfAf7P8AZSjfNa7gq7eF7447f5xWzrn7PUDxuYoBGhPK7e1e5aDpotFLIAin+Hrn0NbTRM6ZKEp644rxViZs+rWFp2Phzxp8BLm3tZWgt23dlA7dOleH654RvNGdreWJ47gZOH9K/UybwvBeW5la3DI3BA5/HFeH/Fv4KQeJI5preNY5eWBXvjtx713UcdOK5TzcRl8H7yZ8AlJLYsk2Qynnd2qay1BrSZJo32gHOVP617XefCpbq4kgvbdre9Q4YnIDeuAK8v8AHHhKXwvfrEQNsgJXA444r1aeI9orHiVcN7OJ+ln7EH7QcvxW8BzaPq80Z13RCkfnsp3PCy7UmJJ+ZvlZcDJ4zwCBX0/Akd9OhgYoTHsMiyEHZ/CpBGSxGCcjOD16V+Nn7KfxVuvhj8a9AuIpGjguZls7tGYBHikIU544AO1sDrtx0zX7IxbJ7BY7Wec5jDoHGCBxjkjIJ/8Ar9K65Kz9Tz4Nte8TCMNviJleEHaqbAySlcbeg6D074PUU5FMxM7vKLhWbDBDtxkjdgjpj+tRMslt5k7eYGUbWbCkRLkfIuO57n/61XFh8lAoMiRjPmshyD7DuAPb6VNyiCw8yW/3xzyNHgD7QEBB5BYnjrxj2AFfHeofZWv7khpHBlb5vXk89K+x9OUKWLeYYjIC2CDuORx9Bjp746Cvky6TdcynDcuT1HrUT1YkfR3w4nV/h/4ZiEUBX+xrTPnNg/6iPrntx19vat6xRLN5opTbD5sAuNx6dM57/wA81g/D6XyvAXhN44yiNo9mzuYT8v7mMHOcZH9cH1rpLy2lkBkbzg8Tbg3lgHHf69OfXtWqZPQ8n8W6X4U+HC+HL3Xbq4j8G+F7eaS3e5jm1C2tZy8Yhd9zPIZEBlETYYIHcZUlAcrT/ANx8T7m88SeK7STQ9LlDy6L4euLYZt5jCIo7++UL+8udioEQkiBURcl/ueyavo9p4r0d7K+08ajYXKAPb3cUTQsM85VhyvTg9gKo6Npt/5+oy3msahqCzSgx21ybdI7IqTwmyJGIzyN5Y9PfPD9XXtE7e7o7LulbXySSsl1+Vvq4ZxP6pJKb9vaScm224SldqOmkpNyc5N3cUkmryUvNovg3qb63ol1c6tp8z6farZ27z6ErSShUjUl3MoYuBGNjnkZJxxXZ66WutGubRflvhuWG6vg08efmUM8ZOGyDgjocn1rC8bfEDVm16w0Hwxo8niC8truJ9dYXUXl2luUYqEeSeNROxaNwo3MqZZl5Td0NpeR6zaRz+ZIJJkV4pb3zI5cMMj924DIeeVYAg8EA16McSq0+X+X+tO9uvZnivLJYSlGpNK1RXtfVLpdbrmWsb/EtVdHkc3wHjn0bUYLW8iW6nt47eG6nsgqQIDKs0jBHG93+1TYzgLlRg4r2K6dGsUuYYxtLL/oynJQKvfPG7pz6HuarqgnjBhAiYHLEyfIFHUYx0OPfp0p8txDcnfvMFxETlElYb4+cYAwAO2T75HSumrWnVa5nsc1OhTov3FY4n4zaZFqHwl8U6c0UyWeo2rW84/sS81jdbynypYza2UiXDhkYrmN1KZ3nhTXy7q37O/izS/Dep63458TX89x4kYadc6LBY+Ldcnhswkgis5Vs9bcvGA0zurmWNJbuZFldGTP2wieYp2iZpGVnKq4AUc4GSOfXPfNK6g2ySiBNxcgR7j6An6jH5Y9c1zOKb1OrlMTwXe6xceCfDkniWzh0fxXNp9tJqdrZSCSG2vGiQzopDPlQ+4LtduAeW6nTSd0jngQK6v9+RB8w5ODnHHTvVhpRa20axna3IkypZW4BHUEd/5UkcsdsQMvEZUKtJjgZbIIAPTp09adtC1roVvE3haPXtK1jSE1NLS4u7aS3jnCb0XehXpu6jPTPcVxE3wgvba30i4stYe21O1iSA3/ANggdJ4AyuF8sKApX+Bsll3NnOTjvpEbJQOlxI0uRKp+ZuFIGcDj8eoomysUEiW7RsqszOnBy2Tnt1GM+ua2p1Z01aLMKmHhVknJXF1C8u7qwuIk1CWGUpKIGaEExMVZVfBPzFck4PGa8xvfgHp2rZe9m/0ZNn2K4isInmguI4lSNn3D540jjXMZwHLOSTwB6rcCyktbe2Nvhgy/vfKB3A5yW4AzzzWrY3FtaWbzebLcSW6kJDIwUHgD5V7Z4HOetTGtOknyaXMquHp1EueN7HMQ3N3pGkXFxY6dJ4lewhZ/Js1it5p2RPlRFkkVUXIKqGYICMbgMmvB9R8Paj490u6t7Xw4mn6dpmhy+HfEejabE+jWmsWBuEK6TYfaIl87yLdZUjvT5UJW6mWDyGunmsfqC70+eWaOae2jcMm157ByjrkYbcpPzqTj8Aaa62uorFNKsd6kn7qFbUbSW6lj02EAcg9CD9K5JNPU2SVrGL4Ul0jxbptrqthbX4tZZ9kaaxp9xYXAVcmQGC4RJUBK4G5RleR8rAnq77UYLCwknh8qc9ERCDvfoBnp171m/ZLPZGLWd45JLhVeKWUhlyQz/KTkMVX8ug5qW/tIUvJGgjgt3KiIOsQwrHDM54/hRf1Gah67s0texJcWJ02G2Nqiy6gXJwox9pzy+4nJC9854wtKLrUHgGo+aqQIN7WYh3uAPvgtwd2Q3AA6Y5rMJjtFF7DG9nAwVZYt4UpET8gBbox4YgEcH1xWjCbuwukgisYoLe5OVRpgAr4+YYAIyQM4yckHmmKzEuraOHWI7xLVLo3UOwdB868qcnpwTz1GOlYdkiWOo3unTxQggNNCDN+6hVh85I4JYY4IGeOgrYK6gumSQCziBsg3lOl0w34GQAQMj5SRz39RUWr2tnLaafJartvVUS2iJy7ggZz16Z5Y9M55oi+jLTaVmYcv2jS4pHjkkuYmQec8gKu0TZxuA5j3HHCjceT2qzBqUZuRBdA21yV2bXZYw0QH3VJOIo+vGNxxzV/Tjb6TfeXqOyO8A8xPKLPGpbqPUycZLEZI6egtatG+rQTBrJYIIwzJc3DBWDLkhlC84yM844PTmqv3Bu+6Mq80u1ltJF2QwRuuzd/qbYH8fmkP3fmHpwa+Rv8AgoB4S1vxD4D8M65bxS3dvYNNBM4ClI8gfOQuAE+THODk19nxQPHYrfXL/Z28rzZAf3kifLkrvfOB7Adq5bx34WfXPhZrul3dtb3RutPm3lWCyOSpbjcpGc+vFEZWZlJ3i0fiN8PNOu7jxY5vk3mS4UxmNSAfug4B/Gvvrw7frp1rawqNzIApI45zXx94A0a5PxRsLWWFozFMYpIXUq6MvJUjqCCCMY7Yr6513UV8OwLeR2/muxwEUZB/D8K8fH1FUqrlPVyyLjBuSO6h+JV7pXlpBoN5eIOGmj27cD68/lXc+HvHUPiGMGWzazdhkwuy5/Svm3VviV4mh1HS7KLTE8m+jWQSqSQgLYYNhCBjHIzXqnw7e5uniuLuMRSfdwOh98/h+teXL3eh7dOHNds9I8VeLrfw9YOscTSypwqL7V4nqPjHxlrV0WsNJWKxBPyyYy/ocgcfrXf/ABLnSXUrXYSI5CAxbpy2M/rXlPxKvPFGnaVczaNII5Em8qO0WHJZN338gjjFXSlfRCrR1u9jH8QaZf3tyLq4g8i5Od6fjXhPx504qlrOQVZVwc9/m/8A116daat4qFxbR6gqXBlXMjIm0xHHTBzn/wCtWd8Z9AF/4LlZQTJFtBwOwySa6KU3Grys4K1OMqTsrHzt8PdPutc8dabY2UXmXkk8UcQyMlywx1xj86/dDSdNaKysVkXyZoLdAzMd3IUBieeOeB6V+S/7FXgq5n+Pnhi+vLcraNc+aFkTIkCxtgD3zgj025r9dkcPJ88odiMsjoeAOgB46HPFfQOXN8j5jkcdZdSu0cs1oZYiIlJHl7mYbx13EHpxnr9e9TyQxx7Xe3GzICR+Uwz6Drg//rNOSyZpWkMayMflG5gQq+3zd+Py+lQIqwEmaApIrbBnaxbIzkHIHcj/AOtTXYzY6GLybtZGQKQy4QRFhnIHY9ew7dT618iXkkq3c4a3+YO2ePf619epCqXcU4kDS7gCpAOBntgnjHH/AOuvkOW4Jlf5D94/w/8A1qJ62IvbQ+nPASJcfDrwspmijb+ybM5WQsR+4QdPxxXQQskqqNqM7A4UQs5BHHr/AIVj/DR5J/hx4VZnkK/2RaYSEY/5YIDknGa2pVNtE0LRBNzFl8yU4bnOeMD681XSweZWt/tFrcS26O8aDDr8i7uc5OScDp/M964H41XviPQvCOo6x4Wvba21e2gaeV7+2W5PlKvzGJA6qJQDlS+VJVUbAbcO6volbMoEeUIDCNWf5SRnBwOcd8/zNZHjbw/P4k8J6voenz/2fc3tq6pciJQImPRyFO7tjORntV8sZ+7J2T7aM0pV5YapGrCKk4tNKSunbo090+p4NZeN9Q0MR+FPAd3o651GO0tdf1PWjd30r3EQnubqWHygJmyzk/vFAYAbQAQJ/AvxAs/DPgfyNG0Sf/hG9M059StLvVb8wXupWisz3F4kbQ7XySz/ADOhLSR7xEkiMe2t/B3jGTX555tQ0NopdWs9Quo7Rpo5ykSKmEI3DkLyCDnJGai8beD/AA7oHhg2fimPTLrwrZOstpFr0MkyW88W6SEyvGMJCqK0I3plwVRmcyEPy4rDqi1OhK1k1q1ZbWW2i76Nuy7H1eUZtDGxnh8woubnOMny8zlN+9zSaveU9bRXNGK5p2SbuUtI+L48SeIkhOg6pZRPp6XcY/s+eWYlpnRd2E27CgVs46swzxXpNs8r3CLHKxlXhGiUFMHk8qORn0r5njt/FUklx8Um8O2dn4at7Jp00l5r1769VC8qTiLY7JG0khZVEka4AeQYAx9VQRIILO4mMtuxKsPOk27eBvCoOmSOh4rpjiaWIX7pNJd+q6NeTPKxuX4rK3GOIlGTkteVp8slbmg7fajdX9V6Ll/HfiWw8AeFNb8V+Mb6DRvD+lQNc3V/d/JGgGAqjALMzMVCoAWZmCqCWArxkftn+D9W+HPw/wDFejeHPFOqz+ODqraN4fsbKGXU50sRL9rfZ5yxfIIsqokaRy6BEY7gv0dPPDHJLBZCeS4kTAZ5y6DJByBk/wAh+tfG2nfsc+MdK/Zd+GHw3vNG8Da/4k8OLrXnTarf6nZII703P+ovbQxzKmJ41ntnjKXCEruQorFTclsed7Rnp1/+1BpcNv4V1Xwx4K8U+OPDniu9h0/QtY0CPTpre/mkhkkZBG94k0QjEVwJTNHGIzDJuKhc11Pwk+NNr8aNFj1zwp4W10+Ebr7T/Z/ii9NrHZ3/AJFwYW8uAXDXKhmjcgywRnauTgkA+c/DH9ln/hVvxH+FlxDqWnar4H+G/g66stMjWSWO4/t67nJvr7bhv3U0JYbHldY2bCIMBqX4K/s6+Ifhj8U9D8SQeFPA3g+0sLbWrO5uPBUclu2vG8vIJoFubee3dreOJYWZUS6kCPtRGWLMZlc7eo/aH0Le3dhodm1/qAMdnCjTSzvEdqwgElsDrgY6e3WvIfB3x6XWdRi02TRGjvbpsgRalbBFgebbFkGTPmYALJjIPavar7S7maC4tftv9n7SJLfyJAjKM5OwkEL3GCCOemK820H4UWWieKFm0jWtWj0z+yxaWkMco85GErySI+YyNh3dckg59q76LpKEudXfzOWtUrc8PZ7ddj1DSdGW5sJo0uFUMQqooyuRg847cj868Btv28fhS/hT4uata3t/q+j/AA7e2jvtYsrVbi1vprlpEiS0YPmQGaIx722RklWDlDvr6J8PITaKxgSNIpCFiVwzALj5WOOoOffpXyZ8ZP2P9c+JI/abkg8Q6Pptj8UF8O/2IxMsjwz6cg3pdIIxsEkqBQYzIQHLFSQFPmycm7HY5tnsngn496F4/wDBPjXxFounatpF34bvb/SdQ0i8jjSa21CzBM8LmJpYm4MZ3ozqVfrkEBPBnxH1PXNe0mxvdKtWuNVsZdSGoWKXKSx7REeRLGocESAYQkHb0rmPhz8OPiE3hDx6viPU9IXXfHHiObVrqS3LSQ6ZYzwRWsVvEwjjM7LbW0SCR44yWJyCRubrNN+GEHhvxZpusaVY2lrptjpU1u0WnzSpdTSs0acknbhAg4z36cV101T5Hz/EzmqOr7SPJt1OX+NP7V3gP4L+Kk0vxRDfX+oQaT/amo6jpdijRaXp8l9DYxXdwHdWYGaYLsgEsg2u3lgbd0GmftM/DjVviNfeFY7XU9PsY9euvC0Pie9tgmkXOswiJ5dPSXzN6zbHPliVESVo38tpCFB4r9o/9l/xb8VvidqGv+C/EumaSuteC28Da42oxOZ7C1bUI7ia4hjETC5eSAzxeUTCVJVhLn7udcfsjzeJf2itM8Za7pfhG00PT9euPFdpd6Tc6lFcXd08MKxNLZ+ebWF1mjWWa4jJa4NpDujjBlDcnvXO2PNsj6Q8ZeLp/BlvYTwWkF1Je6hHY+XfXHlJA8iMSSzZyQihSSDywHqKyvB3i+XXr3WNJudItHvdEW2uJLqyvxPDIsrOFVhgbcIvOAcZzxVj4heE7vxfpulW1jJZQyWmpw3uzUIxIrJGsgMezPztukBI4+bIzxWf4a8KXug+IfEOqX0mmvHqOm2sdtHbW32TY0RkzwpYPnzByeeoOK7Eqfsn/N6vv2ucrdX2yS+H/gf5ndm9axlmt4TBawOVYx2uSo/hI3YAX+HOMnniqEN/LY8eZFGs7DzJtxWRRj5VJOSUJ4BByOBu5yIHVtVw7Nuii4BGF4PDDA6c4wAPzrRt4TM0kZcmBQpd2UlFBztY4PQlT1GRjrXPZI9DSI6SSQWIVJMM7hEAyuZCflA2/KCODlmc8cnmrxSeW/t7W4e7Mkys5Zp1CrGPvcJjB+ZRnnr1+WoYLqJBd38nlC2tF8tllJIlTn94M5POcD15HpTbJfst00gY21/PMwt7Ro8jyc8LjtgklmHQn2rN9jLoW5IZ7e+jtFmlvImQPNFOwdlUMMY4GS3IwfSo5XW8lhitbaQwI264TbtxjO1NrYGc8kDtjrmnwXxsrg2lyyrqc6GXzmA8rAYgDOc4UEcHrk4qrcSS20MdtbvJ9tlB/fLcF8HqXdQORz6dwO1SidT87dd+HUcfxSuvEEUOyE6jfFwOACJGUcD3LflXs+g+GP8AhJLcFk3RkAhQM8f5/lVT4r6I/h/xfqlosUnlfaGkVipUEMS2eevJPPfB+g6j4bavAltHtwGAA25Hv0r5nESlKrqrWPsqNKFKmlF3Ts/wIZvh/CZ449rJt7Akc+mO9a1rpaaVdQQldrhTwDxmu1+22zL5gKnHfvXn/i7xf/wj+rWzJpl5qMk7H5baNW2AnqckDAx+tZONzVLojO8djE0TOPljXnPY9f6VHpekQ+JtMiaQEAJg7jzzn/CsL4l/EC5Ey/Z9Aubn5wH2FFxnvk9eOePetb4ez3PmndG0do+SAf7oHHP4Hmpd1sW433LVx8PtMsbRnRGZgerHJ/OvNPFWgxXcU0MkREToysFH3TgjNez+JdYgFvMy4yTnaDwD9a8c1+7NzlY5AP8Aa6jNaUXaXMYVIpw5Q/Zu0aOL4l+C47eMxyWMxicvkgnZJ+fUc1+gUJDqybl80H58pg+/v+NfG/7K3guW78dpdESOmnIZzJDg4cjaoIPY5b6cfQ/aLIzkqjkM2HO8dP8ACvfw8uaLfdnzGYOPPGK6IqhvOjaSMRzBmCDy5CATnB9h2/X2p4szblQsbxyFiS8b5HrnBx+VRsjiQNLaxywIvzNEfv56deuMetPkQWrl0Nwkj8KjZKn055wOtdx5BNArSSCZZfnBxtPseh4/+vXxVqRZdRug0DbhK+flX1PtX2pHA7uI3eO5jPzbhwSCeQT+PHTpXw3rYRdavwEOBcSf8tP9o+9QxPU+uPh3NLYfDbwu3KwHTLMu+TiMfZ0HBI6Ejk9sn0rdu4wxV18tVQ7xcsdyRt6lmPzdcYHrWJ8OpWk8AeGEk/cgaTZfvTh96mBOmOEJxWy7F4lktSWjQZECsCBx13H5UOOec/hmtES9hzXheUkowaIBt8rAdzyNwxjjqBn6YqqsH2aTfMFhs2bCM43MPl9G5wTntkY6AGpnNuqtNLhJ1VWRWfDpk4B3t64HsMdDVO5uZrFJrq8nzbJEZ2uUHlhEUZbI6kAfMSu3PP4UlfYlu24TyuUU2ySQTSEpEYyGd9x+bcT278DC4yD0rM17wlonibQbnRfFCQT6ZOohlsHdx5nQowYMGJ3KGDKAQQDkFc0umePvDV5LawaPrdrJdXdml9HCV2i5jY4BxjKvkjK9RkZWtPTJv+PS4nR4xtZvtW3f5zEYO5hkKOM4z6c05RbTjJaMqjVlTmqlOTUotNNOzTWzT6NFTV9aXQrLThJDcGznkjtp9QneK0Cs+UjMhO0/NJsTCKTulQAY3Y4HwSZ9L8X+I5bq5kutTtNdubG+hkvHa2eyeOO5tZIYjGdskcU9vGQpQOfNZ2kZYyex1Lxfo3i7SoNPtpIdRs9cX7PEHj8yK6R4XlKlSMBGjVwS3B5GK4XxP4M0i21mx0y9DaV4dvo7/XNfku5plhuJ1a3ihtppC+BEyzOPLz8wt1QDywynjxEalNqdtvPvp2+972v3PpMqqYauqmGl8U09Ur/D72iuru11GOkXLkejVz1USXmo3yhE+yC3bILphtpHoeSG6YGBx61AIbO1e9a7Zr24gLTMg5JGMjgd8cYJ+leTWvjzwp4f07xD4p0Gyg0rwdpelrJdXGmRiO11CRQVjS0fesTSKqeU21fmY26M4MXlr2viH4teA/hjb2V1r/jDw7oVlqm9rNtZ1OGzkn2bd2wysN4XeuVH3dy+taU68Z+7dX8vzODGZfVwlpyjLlel2rO9k2mruzs07XvZq9ndLp4FvVsJCkMNtCwADFd8mwnqQODjPp0GaZd2Fviyt7i5n1NQ/wDqQ27OBwxCkcAgdT3qtrmo2eg6ZfXusasml6HbwyTyzynyktolXczPIxwEADE5IAAPTmtaBYUhiS2hWGWNvlFuu1ccbsgdARnjkitedHmpFW3sQb2cQWUNvtRR/pJ3tnkggDtj35wfSiErtS1/tDymDFjDbwh2TBPQ4JA9z64qxBNpmp3moBdSjvLiydbS7t4ZF/0ZyiTCKULyG2SxvhsHbIpxhhS315Z+GdI1LUry+t9L0u1ja7nubzbFBbRIpZ3dywAVQCxJwAAealzVjRaFcRyNqCTFL5/NGNjAQ/OOQTgrxjg5B7VXuzFZ+diCK22lmlMl6AxbG5WUkE7s9Dnt3FaN1psl7bENM91KAWTHyhTtYZGCOTnHOeGNVtMmsNZ0bTtW0SaymhvLQTWl5bMssEsbhXSRJFO1lKhWDbjkNkZFLmRSM25nwZ0aezCLBk+XJnfuLbwMbcZ4bb/ewRjkU8XCJI5klEkYY+Yysqo2SNx9fmABxkcqykDOTJoDJr+haXqVjrUep2NxGL2OezmVoLhJDvSWN0zvUg7hgkYIwcYqZNLOoXsiu0iRrPveRbhyZAOVJGRtxhcDk5x2zmro0TXUI7UX0UaSuJJkwhDklfMLkOxKkEknB64ArJvz9lhnkeVngcebITGg3A7gHCr1IA4J55Gc44veTaxarHYy6oo1O5gnu4bZpVMrxpJH5kiI3zFUaSEEgYUyLnBfmM3NtpttPcavqEVrDO8VoktzceWu+SQRwxfMcEvJIqKDkszhRkkCldIuMkndsjsrjFvJuhki3jd5LDfk8cAHh8dSOMA56ktVaO5d5Gt1jEDRfLMA2VIbkcZAH3uc8cZ6k1JfeI9G8OC+S/1Wwsm0azGp3vmzRxC0gcSYnmBI2RnyZfnbA/dPz8pwxHt2nj0wXdtDqt8j3MVs1z5bvDC0ayMkK4yqmWJWbBAMign5hmuZFJxTNKC3FnbCL5dzHYqMcBGEvlncMsCnzE/h2zw1bmKKIBVzA2Y7nyvvzBmZkKJ6EZ+b0J64qS00kvaGKWdluQwPnIQ+5gGJJz1JZz6denao7KyjEMZwjlF2qrjHzDqNoxjJz0x1JwKi6uK6b1ZUa/jnht2uAs4hi8qKzjA2kZXDZU5DYB5xtGDjpUsV9LaI1wWmM6qV3MwJMaknADByvoSM9iexq/dWPyRSQoz/AOw3BOOMZ6Z4GcgjjOKpnyizCV1jgWcqAhIJIK7SwU8H73K44Iz6VSasO8WtDTsZp+biS4SN5I1Zi9sdqggkL5gOCFz2/PkUC2lvrp3MkFxLCqAMgC4BG7ODu64zwRUSXBCzFIZFMLBJZwNu1du7cGUAsORkFc9atwiK2TNy3+khDuukxlgxH3cDgZYYGPSo6mbPMfi18LrvxZGLm0RIrhYmR/O2hMYwuCp6gk8kdPoK8C0uzvfDepzaXdKIbq3fZIvX3yPz/Wvsu1SeW0ZZhNIqtmMXJVZDjoxI4HOCO5xk14F8bfD6aZ4uGqB18q6HzDgFZO6nHTjBH4+lePjKSjF1IrXqevgcRJtU5PZaGPaa2yjEg8xfUcEVV1vXLKMRSSzRwqRjdIPWsorBfQNB5uCecoeRXn/inwPa/bUnubq8mWJgw3TYHqMgAAj9K8+mk2fS0rSWp1ev+JdDEILahC7Aggk8D/OKpWXxCsJJgttPEyL2jBXFcLqo0O/gurcxOxnbf8sccbL7AqM44Hf19aPC3hLSbCWNvshjZVKrvIJ9u1aTgl1HUstj0bW9QN5aKYvuuhK8/UVY+EHgKDxz4wt7C+dltSjzuF4LKuOOvGcj8vxHN3mqxwvHCi7yo2hV7f5zX0d+zT4PezsLrX7q38trkCK2LjnyxjJHsTn8geRitMNTvNX1PHxdbkpuz1PTPBfw+0LwEZxpFi1sZiPMkJLMcdMn09v/AK9dRtkCtkpnkAqD+FRhzIxKYU9mI4P1pZ5FjTJwh7OecAn074r2klFJJHy0pSm+aTuyoI0WVZXU2sCjC7fl8xh0LY4xzxnr9OKuN5iNEUdZmYEAN0I4OcjsPp3qGO1k3lUlO0EbiCC5x/Dn/PB60GVLidcblZSdpQgB+OTnoQD256VsZMWKO3F5Eyx/ZJs5ZgeGHpkcHk5/CvgnxGJl8Q6oq3hCi6lAH/Az7V99Qv5SozBHjVh5bIO3rj8+nX0r4A8SNE3iLVCZ1ybqXsf759qVhcx9p/Dzzrf4aeFC22RZNLs8+XnzHzAnHU5/AitYNbyTCEMLaZmBa1C4jA65Knhjx1HX8Kwvh/KF+G3ho+a0cqaVZGLOQFzbxgk5GD3J9j710kkMuDB5MV2hcPK4PzEZzznjPbGfpWiMm+wmolmlAaGOdIVBcsBiPPVgpOCSD/nNcP8AEfw5a6/8MPFGnrdX6xSWUo8gSHzpljQsIycbwrEAYHUNjvXZXJtyBckzWsCISCoyN4Pccg47e+ealsJnncuZLa6E+XzG2SuB0PUHtz/9atItxtJdCZRU04vqfNug+HnHju11a50q6ksWs7cmSPwonEplGUdtobOP+WgySDyeK+hvFN3aP4Z1aBxd/wDHrIrQWZaGcjb0jPHze4NQ+Qba4nWSOa0iRmmmmhO+OTJJUMo9BgnI7AZq5LqVrq+lrH9st4blgpCyjAEnBwyMQeuMj3retWdWUZNbGFKgqcJQT3PmDwh4WutLvfDtrrnh3X7KOyhsormXT2uZHjMcF8rFZk5wWmh+RGKgOBzgmvoLXr9MwW32pnUYkWO6TYRwRySBz6Due4xW5A9xDfEW9r5sJA8028v7sNgYYAnjAGCBngiqmqyx3lvuFtdQ3AKrGXgDB2OQOOQQCSfbk8U6ld1pptDoUVRi0meJftA+CtVvPh742kuNXXULuXTZoPCyxWMFzEL6RZyLe4t3t5YpfMxHbK8iksk/lKBM3mTfEnhHXPif8NdY+ICfD/Tdb0PWZdBtL20s9I8JXFrcEE3xt7e6tF8ONbu6OJF3xi0jkLOfOk58j9MvFfha2+IHhHU/DMmsfZPtlv8AZp7qzsreSYxEgSK0d1FNC6SIGRleNgwduAcEfIFj+xd8FdL8E6j8Sz4lml8P3ukjxBJqMfhjRWg/s1Y5J451tJtLl8pvKkG5Ylj3lR+6UqqL4ro2rX1a1+/z6vsuiXyPr3mCq4KdN2UvdW28U72ikuWCuuab3lLay5k/QviPcjSfiX4kTxFcePPE2leHvCGhzOvh/wAXnQfILzav9qvrjZeWFsdwtYt7cbcDaiqDt5b4VXWl+Hv2aNV8TT+APiJoFvovgiW6u7dvH93DpwubGNXmsbRY9VnubJlmt2iw0SPGkckUmCWjbc122tfG2r6hr8V/rPi3wvM1loV6s8MDyeNUtlkza2ywRJuhgke7uZHRNly008TMtqmE9z/4VX4V8S6f4iSC6u7rwj4ktbyx1PwvBIg06WeVjHdzIVQXEE7sJVkSOVU8wyyNGJnd2qlXp1W1B7fj5ry/4fZpvmxuV4vL4QniI25vvT/ll2drO3TWL96Mox+P9f8AD3iXwL45+KOu6p4Vu7yDw74L07V760tfjP4kWY28curSfJOYA8rEROBFJtjjI3K2ZpMexfGz4i33gfx5o2gW0B8c6PodnaanZ+Gbix15pLLB8u1ur+6gstRN7J5trcPF5vk7GTzGWeVYpYdzx3rnwA8Yrc6x4p+IOjaZp3xE8L6ZDLp2peJF0hrrS1kuZ4JFXfFcIsv2qVHywDKpQqPnDd744+Bnhvxn45vfFWpXHiOG7udMtNLePR/El9pkHk28tzKjFbOWIyMWupOZC4AA2hcuW6NOh5RwX7Kfji/1G71zRZfJ8O6XpkMUsPg2XTNTWfTY52YQPb3N7a2WLQm3ulW2W3kERXCTLGsdvHz37Pl1EU/ZrdpW3J8HbxACD8pH/CPcj9R+FeqaB+zdoWiX2v3ulaz4qt38Q2djY3k1xr93eziC2knk2w3F00k8PmC5mjZo5FKg7ojFJ+8rj7L4x/B/VLzwTrHh/Tdd0qH7JDomgalH4P1mx02K1vprRIYopDapbrHI8NmqOSFGFCsoY5StcD59+HnhfwrrvhXw5rfiLRvDGt3Ph74VeBpbO28T6RDqNveGT+1EayAaKWVGnZokQ2ymTzlg/dz4aCXR+I/gLwTD8JvE/iix8MeBvAcV54i0TSLrTJ/D9lDbaLBHrVg7w6mV8ppvMV4p5V8wW5iEXlM6Yup/ddP/AGU9FjuvC0mi+NvEPh6Pw9oem6JZvBDpd080dit2kE5NzZS7Jdl7cIzR7QyyMCvr0kf7OFvc67NeeIPiHr/iKaW402cLqFrpEDs1jfx39spktrGGQgSxsNu7btnmwAzBg9h30PgzxNoPhnxAvgaym8H6rNDf6dpXhCYav4ZvdVl05LbSVeWHzxZ3IuGhdL2GSHTTpNws8M+/kfaIPqnx3rdvrN7YrrHw78YeIp/E3ht/Dd5JpkunaNaa+lxbrcSJ9kur+O8SSJVuxHFJh4Vlu8btxetf42fsf+HPix4nXxD4k8Uarql/bzu9nFNomgTrbRHzQLcPLpjySQqJ32pK74ba5y6hh7R4T+Fdp4Y1ldauby98R+IhaRWI1LVniLwRCOMSrCsUcaIJZE82QqoLvsBOyKBIlsilotT5X8d+OZ/+FQfGfxfL4K1VbuWGfUprvxBBaahp00djKsUeitDpuoy3Hkr5cqzLI3kCSW+klVI5Hgr5l+NuixzeJPiJ4itfCtlLL4Z0mG2sZYfBPkWMCDRdPnIltJdBvQmxwNqXN5G8EZ8vdChLv+j3xG+CWgeJofFtvJNqVha+LdJudK1eDTn2pdebEIUuSpjdftEcYMaycbl2CQSiGER+deIP2K/hHrVtq95deErC51LWTbsuo3EMFzeWzw8iUSyRN50hm8ySV7gzNcNIVmMsYSNXuUc5+2x4a0G8+Fnja7v/AINx+L9Wg8I37w+MY7LSpDpWIrgoDJcTpcr5RPm/uo2xuym5sium+H+g6Fqng7xfD4H+Deh+BEuyLK4s9VstJXT9aMcssNxZznTp5sbcTQMZVbymmJ8uXa8Z7Hxx+z1F448P6t4atvHfiTwz4Pv9KGlP4Y0Kz0eGyt7Q24gaGIyWDyopXPSTK7vl2gABPCnwRsoNT8S2niTxZ4g8Z6XrIRtQ0/V7bTYLe+mzCWeZrK0gkmylvHEySO0bw5ikR1wAriutbHxd+0V4t8BeIrn4gafbWXwt19v7Nu9PsLi50xb/AMTz2qeEG1G21X+05Ll5JgJkjhEjRsThf3hbmv0A0m0sfD+n2WlaVb6fpVjpwSK1trG0coUiRQI0VAAiLkLtA4CgcDpj/Gv4W6X4++H+veHodSu/C9n4iLHWZdAt7RbnUongFvIkjTQSgkxLGodQJB5MYDgLiuns/tFxexq7+WvmMyvIp8wujdQONrMh+YdDycDkVS2uVG1rk9w4W4iEst1cLdOI5Fij8pd2PlHY9jnk1fjjcQyW0WnJawMCmXcLkdBwuTj3zxxWf5Ilimj1C6nhkt9sh3S/JjcdjgjGclTwee3eqs0sEvlSrp6SxvIscxnO1FOcKwyM89BkDORmna4m7l2K5D2cccmoCW5j+9GGzkKRlWA5OQCPfNVPEnhy08X6FeWE0JWKWP5CRtbd1DfXJ/nVm3jvhuh22trtLAqkZLBc5QhuM8f561HqvjHSPDttvvr+ESHny42DO3TOFHPGamUU00yFLllddD45a4bw9q7W90rBo5GRjwNpBwf1rsbN9MvIw8zCTB/D+VY2sJb+INS1NnACS3DyJgAEAkkZI+oriNX8L65Ao/s652xjgIwLH+dfMODhK0j7CnWUoJwPTLq20NJCIbOMNzgqi5I/KuT8Q6lp1nG7xrtOeCDxXmd7B49gLfuX2AcuI84/Ws6ysdWuEC3rOSOzZXFOUUveuQ5yZ0Kaj9vvmeEkKMsc+ueP5V9+fB8gfDHwwSAP9Cj/AJV8B2VnHYxFQTzgkk17/wDDj9pAeCvDOn6fqlhNqFnDHsWSBgHUBsKuDwRj37D3NduEfvPQ8zHawVj6q84K+Nm4YyX6f56GoAZEbMrfuhz5v3dvPQjP5GuP8MfFjwv4uRGsdWiFwzEpBdOEYnaeMHrxzn/A12CTCaPLcpKvHykjntXsNHg3uMkZt8ptSofI3DJZWx2x0XuM/SpSqSqrSKzkciNsFgefTgfWqhbZNHDh3XaWDTHHQgADPfng4zjFOuCXmSWPyyU3DG7cWX8eM5HH061aRMn2JIJHF9FlhJGSAu0b2jOOm7pg9c+or4W1yEtreoH5ubiQ/eX+8a+74fL82NgkszcLuKEAdPXAHavg/WDew6texwH9wk7rH8o+6GOO/pS3Jdz7H+HUwfwJ4RX7SoRNJtCqvgbj5CZxjGQAT+P0rXWGFUJRGjnkdtsqnK4BIJGPTp09K534c5b4f+FIiEcvpFmvmIGUlRAmRkHGc9CPQ+ldDFAROWigeFo8gmLd9NuDxzwePr3rZKxHNceFCPFbxXwKowfbIgyDn5Rxjrz15qG60+5ZXmmtLWR5vkLwsUdB2II5B7nnrirOmysZ0LySFnIZ0aPBJHU9enar62fmu0nmkebkbdvv6/jUSk4s0jFS1MO8sCIMMLqNRtE0kMgYyADhgGyD8wBqnBqs8L7pJ7mR5WywmtN4EYJ+bK45wfQ88Vr2x8+O4Bx5sPyPzuz7de3rWBcb4pZI2iu4MHEk8b5DKRwiHkBvb8ua0g27pkzSSuh09tuaRYIre6QZuELQsgdmZsgsDngHjp1HXArVRpJ7UW91EJSgBLmRhkjoc4zkevtUWn3Bi05meW4lEbNGqS/eTBPy8DnHT8KmF4PPdVUBvK6Ec5zWc5O9kdEKcXG5xnxT0PW9a+HPiCx0m3nv9avkEOmJBrFzYiGUsPKklnglhmSFHxJL5cm9oxIqhywRvjmbw5e2n7AfhqafQvF1pGfBF7NHqOmeM9TuIY5f7CW6guHiWYKtmyW7RNFKFjgn/dRxSRzmZv0OgEszKIyY1VRnAGM9857Vwfib4GeGvEvw70f4bvaXkPgGxs008adp+s3lmTbRweQttJJDMkk0RjZgySMwbALAkA1m9XqSrwa5XZo+Zvin8OP+EM/aM+BFvD4x8Qx3mzWNO8NaQEtmt9LtY9OHmuBkmR1i89VkZWYmaDeWEBSf5n+DUWoXGkeLbe1n8QeJPE3/AAh9y3jWTSL23s7We4i8QCRF1Jri3lX7QI01NXS5ik8yxjVVRhM0afrbA8i3EzqrfZsloljORISSWLHr36e1eeeKPBfhp/DlroXiPRpvHvh+a9t7e107UtObUpI3aRkEjuQQ0SRuAXcbtiuZHkaQ586VH2Tcoab/AC2/q3otkrfW0sz+vJUsVFSbcb2Wsrc19rK7Vld6r3pJ80puXwl8QfFniHxV8PfiHq1lqnjPWVufhTbrrOp6HeeH7u0vJvtPiATS3rvcXG2F3E7LFp8pMSF41CeXGi+lftNjwHpPx48Ma9aatcwfF/Rda0KV9BR5bXVtcimlNpb2um3V1Mtutn/pNy9xFboUmKFJXhbdIPQ9Y+BXhP4qfEbxvc69qmr6hrhuf7F1/Q9L8SX1rHcabKrfZFMS3UChY7efc2QyOz3wCSM6lfe9GsbTToIrM3901vpqJY2s9xcSTSkKoDGSWQs0r8AMzsxbBJ5JrupzVSN1/X9PQ+exOFnhJKE2m2r6X2eq3S0aakns01Z7pfnz8FH+Nw/b48Q3XiyO50Px74m8E3M1pBrSW2q2Hh7TzqqeTEotryPzoBHB5e5DHJ58zM8RUPK8mgaHJ4f8C6Je6/rfiDwxpmiGHURpOqeA/H1zY6Ra2cizWzTI+qG2xCsULMgDxRspCvIqiRv0SS0h1B7me6YXEMZ8lHc7QQMMx44+9xkf3a5jxR4P8M+O7afSdc+0XlgLreNOtdRniS7XZ88U6ROPOgYu4aCXdEw4ZSMVpY5C3pzXljp+m2d/d293d21vH59xHbmzSSboTHEzOyoSCQpZiAVG5jzU97qlwl99pl/dEnG4Y2o3oc8jP0HSp5rWeOWS8SA2ls6oGi3neAOrsq89MZUN2qTT4oL5fLtJY7yLafNucDbhgRtjUYA78/qTWl7GqstTPm1C5voJFlKxiGQDJO3PTIzg+uemcc4Awa1G1aRYjHalZJYoQ0ZMbyRkjjk9e3X6+mKhigttPtrqyed5LtmdIf4pQrD5SBgY7ZI445NOF6k89tdrqMshkXY21ADGGwRkYIyDwc8jJx6VLsVp2A+IJ430+b7P8tyDsxJuaTIGFCr+IyehFQapcPqbR+QdoRtqgAMrfOEyR3UuxHHZG9aY8JkkktQhlhnOYhJDsafPUMwxhFJL9icike0kQIYbqdVI8xeFOQB5cfbuxJA7AHqeaNEOyRNJ4iu4rRvNijuUaNNk1tGDl2J27lJ6YAPBOM0WGrDTYiqsrTXAEsl55m+2CnuO655wCBn1pP7NuoNQgt4L0ZERlDSRD76gRqDjHy7WOB1zUhS5EhZQ+ilgftM0YR42IwFKg9znrjoMEGjQehLd6jNJCfPtluobdir3FqRwCM8KSM4OM4JqK3lnu5Nv2eZZCsZnygXy51xh8k91IBxk4AFRR2tpHaiCWNrKLAcXlrL+4lO8Yyc4yTjIYcnPapbOW+uL+aa1ubS6tvkR5GBAfGT8pUkcAjnv+FLQh2MrXPFGl6OE1HV9Q+y3EZJhtONy8kMNgyX3DAJP6V5nr3x8aB2g0KxwkamJbi8YklSem0dQOcZPfpXl82TI2eOTUMkCuckc+orp9lpocs3Jr3TV1j4h+I9dY/adWnEeSRFE3lque2Fx+tY+nnyZNzseVKgk8k4OKVrZcfKefenxx7EweeaqNO25zRjNy94faskVyVz87/N+mKtu+25RsjywDkCs66sXkKyhWG0cHkfrVOa4vYo8RgvHnhsbmrycTgfau6dj28NjvYrksbup6jZLp82518z0JHPHpXnErpqF63lDAY569vWtKWcEODBKzeqsKg3ziICFViGOjqM/pXHHLp31Z21My8infWItXKGQAk9GUjpUrwB7DYGI+UEE+vX+dMj0+4vLhXnbc44AArdt9IkAw6lQOwr1aOH9klG55FfEurqzl7e3uAhAcoP7o5rstA8f+LvDUbDTtdurdSAPLd98Yx0AU5A/CojpcY/if9P8KQaanq2frXa1Z+8ef7RPdntHwv8AjjrHijxHY6FqtlayXF20hW9gHllAkZfGO+drZOf4vavoGCV3QNCJEDgNgFEAyBn3NfKXwTsoovidokhiLBTP6n/lhJX1NaKweVWjMe5iVPlAk988n68dO9RUs3oioyuS20aSYjndGYPgq0mByc5x7g+tfIpsEmPmANh/m/OvrZc2+pK6pIWfau4hRxuwRzx7j8a+TbZ5GtojvflAe3p9KwcblXsfR3w+iL/D7wkAADDo9mSxwDu8iPjAOT0OQf51uQLFPGI0QCNc+YW8sH2P1IHX3rI+HSlvhp4Sd02Qro9kWKxKefIXvxx+HpW1bKTG4lDGFGCjaoO5sj5QOv4YH5CtFsS+4ttcst2AJvJVQGbztoyg7j0z/IZ71fFwGyTcho3AIjQ4I9TmsmWN5LmTzVmklCgrFCiqT1IU5yDjGSTxk/SlnhMlwscchluAwJD4APPQcZCjByfw6mlKKZcZuOhpp5Om3L4ZjG3I5LceprmXngN5NPb35hPnsyLISyxsSOccZkbOAvPGO1a1xdTaSj7d00ixNNJvIJAA+/xz97jH+FY09xaCN57iK4EMJErCHLswJAL4jPzSHcM/3VpwVrsJO9kacW6C0js55VVwAHCjG0nJ2k5OTgjJH171eu7JPKUo0UbYxuY9u3/6vpWJpttPf3iytBNbF3YtBec/KDzjDH5c454LEegp0LNeagwvIlZG/eB7cl/k7AKBnPXt0J7kVLgr3TLU2lY0b5f3CQGZ7eaX70gYgBF+8ceuOnuaLg/ZdIhhKH7RIDHFgfOpIzx/tAY/H8alcQa1eKhVXhtSHwy4ZnPQ4PIC/qfpVd7ZV1e3Amk3o+yMSSlz93MjYbPYqM0klswbvqgZ59E0owlQ/BUSJJyCeBgEdAMd+1R3sVvb+Hbu31HT0vYJLVorlJo1ljmRlIZGB+8hyQQRgg0/VLeS7vbO0acvtfzHG0KSpyMn19OMU7xDJMsUEb3EYjllAcGPBUdeu78OnWhxvZMcXKLTT1Ryd5JB4D1CxvdUtbvWLnXZ4bHUdWvrgNFCUhk8gBMBIw8hCKqKis83Uu6q+H8PdSGh6VK934nEj+HzNpfiGe/vGaF5EX7SbsKxdVbEwyquiokrIxbyI1X0XXrCDWdIv7SaKbULSeF4pYpkBhkRhhlZCAHBUkEYPSvKtT0208LaxFfw6rc+E/ClrZXV06+HoIba1W8ZZBLc3bFW8wbGVowUZN8fzjcY1bz6sJUnzw2X4X3/AM2733XXT63A1qeOpzoVG1UaXdqXKnypWTadnyxilyq0Zbxs+/8AC+raV4n0uz1HSLmy1a1eSRku7HF1vbe24hwSi85HU8g1daa6tLh7m32SoTtnRpN+T2xJjG7jG1c444NeR+HNduPDOn6t468XXNn4Z0zW7iCG3sY4ZLV5NpkEUjQF5C91LG0YMS7m2W6biCDHF6bb6/HexXE8N1FPFE8sbtEQGhMRKzINpIQqytz94FSD8wrqo1lViuj7dfJ26XPOx+Alg6suS7p3spbq9k3FSsk3FuzatfeyuTXPiU3QliaJ7ZU4lyThWPUOw5Uey/McnkYNMuppbDyr2D53jjBeJkLHyz0Z1HCAnGEHIxnrmpI5La7XdIVj5YJIoyWAI+SIDl85BLHk7uncGnlrYy2V45gj7QQOWdn7jn5iOhwMg87jXRZdDzUjRtrxTc2sguZbpZ/lM+zbEGI3IF9uo4yMnGc061WEm/0+YnarmTDtjKPzkH0DZHtge1ZdnHd3mkywSXMcU9k+5Y3AJVlbKl2ycDgjHGM+1aluz6zawz/Y7csVxi4O45yCVHBwMjr7Dis2rMTVjOhiGugLI73cnR7p/kUL6xYAB355IzwTmpo7Cea/lSK9TbDIjTSeSNxIUFIyOgAUg8AdR15rT8qPU3t7y3doZlG3J5BXPzIwzjr3+hqhazzwW8a2kccnnyPIXnJVmXPzSt2GSRgehHIApX7Cu3sQ3tvcWk1xdTXJYm3ZnWItGgWNTgdTyWfJPoAOgqpLBqsNx/x9i5jtnQiKUYMspA4PpgkdD+FLcwahqFs91PceSnkGXy4sr+7ByoIHOSQM4btVWfRPs7XCy3qecjID5i7N7nBZg27IwOS3X1J6VaXc006sbPqL2slw9yX0+9difswUGGUdB8meWbGdwz1HPpYk1K4WGBdRtPsFiPmaSxkJQnHC/LjAzk++B15xXltLiB7jy7yC7VslYQykE7fRueAOi4zz901VYrY3UbRTrYzA+Y0buroi4wWI2g5OSOQRk4ODzVqKZTSZ84JiZkYHKvg7l6HPcVfW1iQZ25x3avdZfD2n7w9xo+mrFsxmC3i5Izk4HA7cHkU1PC2hzxuTplkoLBUV7ZCPXJIHatXdnG6EpdbHhF7bRhyY3RccYyOaouVjfa8kan0LgV7xL4R0N5PLGlafKqnG/wCyJhsHGRkVJZeC/DZnSWfQ9KwckyG2jyvGT/D3ya1ulsWqPLuzxaK6g8sKssbjGANwOaqNHFcSsroVB67GAH4V7ung3w+oiaPQdOd2OHxBGdx7cY4+hq6ng7QxayMdB01SVYFRbpxg+uwfl+tZ3SWpCoKOzPnKfw/ZLPtWRVX3Y5AobSLKzB6SuD1DdK+hj4e0pMAaRYBOP+XZDjj6VI3hXRmDqdMsm+YLk2qAHnvxSSfUboyfU+axIDKFjVQPUirY6DnpX0hbeCNAkPlrpGmLPGScm2jUHk98VHH4Y0VoFK6bYmRiTta3j4x7Y60RVndihSklqfOMkYbIYYP6imrEi89frX0Z/wAI/pBG46Rpznrj7LGf/Za1D4V8OxuhOj6a6sn7wLbR/Ie3OK0c7bg6HWx4l8JJBF8QNJcrkAy8dP8Alk4/rX0pdws224BiKqAShYkN3yeenvWRo2g6Pp1wk1vo1hDMWKxXCwJGRkY+8F4zn8a2YzLaXa27iOOGRdy85wccjJArFu7ujKW9gAtnEbxpBubsYycjPIP+I6Yr5h0N2bRdPKzNtNvHjp/dHvX1DbAWEsStOjIZOGRR3I/Idj6cGvmfwzDG/hzSmKHJtIj93/YFZu/QzPePhzG6/DLwhJKh2/2LZKkYl2kkW65bg44Hp298Y3obeYICVaSdkzGWlI8sd2PoeMde2PWsDwHEzfDjwkgQ/aH0qxXcpO1R5EZ28c84/T8+gvU8mFxHEwxtjeRWGHckALg9uec9gRS6DZHEY3SUncyIfmnYjcin/wBmb+o9skdpDHFDdxQjzWAWKAuwOOy59c7ie3XPQVKywyIrtGEy2InkUglucu2D07geg9xURtlghMitJF+7OH3n91FjO7ngM3f/AOsae+iD1K0ly1ntUsBLMz/vZJBtynAyW5KqdxHqaQW9tPpzM/8Ay2yolAzKEB5b/rozHt3I9K4+1+K9te2djqr6TNF4cv8AU30xNRkdViCLlbaQg9IpZBgH/bQnhqz/AInfE+w8BeKNK0eSztWvjZm7S8ur2GzjVt5VlzIOcY3YHIyDW0aU3LkSdzB1oJczeh6F9hu7a2ukDxHzv3IiZOjbSNikYGOef+BHvRpkzW8F1KYH81QQHji3AkjO/I55wox2CqK4P4e/FD/hY9heWtjFbxPpDxLK6Xa3CyRvEWLCRCfnAIBB6FqxNP8A2lNFM11aSaRqMUUl5FbRSJ5JaSdpvJePy9+5UUqqZwSQScCtFh6rbXLdrcX1ikrScrJnq2hXdos7TtcrHtiCFJWwy87iCDz0G4+7NV62jh1LUJrzcrCMeTEUk6/3249/l/4Ca43W/iXa+DNYayuonuJhZ3Oo3ZJCtFbwABpAP4y8ziJVHJ/CrXgnxRda5f3OnS6TLp+p6UFWeC5lBcxzokkcuRk4++pxwGRxkkVhKEknI2jVi2o3N+8hVdct2eGQxkYRlZju9R17YJxx1FGsWXnWiSi2W2VHDOGQOxA6Zx7gHOeDXjMn7SVxLAl/PpNnGBI8K2dtqwN0p88RH92YiSxxnGelegeI/iTd+GfEWk6ANFudRuNTMqQXhmhiQiPBk3IzhshWXkDksMCrlQqxaTWv+W5EcRSkm1I6aK5a6XE6tNKGYCWfKQcHPT6c1Sv9KW+i8weTfQIyuGvF2whlbKhR36AD0KrzXHeDfiNH4vupYjZLYBdOj1GG7vr1ZYXTzXjXIAUjJibgr0U4rr2a8nuIyqtao5DCWaIsVPGdkak7c8cn356ZiUJRk09Dpp1Odc0GfP7yeLNcuvh34w1nxTY2F1JEkMNrPEfKstVYXEbR/ZJLlRIQss1sy7vOWaCIjCtKg7fwveXfhLWLzTDPq/xD8Ru3n6nYW0qfZbF2lllEjefLsj+WXYIRIzGOGMhflZq7F/AHhw+LDq7eHtOuNZKxk6nc2sT6g0iqEUmUruUFNq7QdxA6Dvw3hf4j+EovHPi/wdp2uaNqutw3NzqV5d6brNpL9lUExyC9gMpkhMA225JjZVRYs4JZE8WOHdKSb3vvq+lr9k3bd3ttfY/Qq2bU8fTlTilZR0haMV8TaimvecY3ekXFydpct1K/fabd2esWKavpE3m2k6jGpXMbpIrrkFNjAMu0rtYMAUYFSMgir1xcLcfZLqzZb26R8TT5OA+CV+boASMbRwA1cL4f8S+A/hb8MNK1HUPiNoL+EnvprZNYvdWgW2vbl5JXm/fEhHlMqytsU4VhIMYXC9DffFX4e6d4hHg2+8eeFbHxPeSQWy6Ldatbx3rGUKYVFsZA/mOHQquMneuM5GfSpzbgnLc+QxCp0q84UW3FNpX0dr6XXe25s3iJBe2mrTxRSW06DzwEwob3B6sADgnk4YdcVLdwpY3z3DwXK6bcsDKgYBS2B8xUfNg9CMjOOnQVxXhX4zfC/wAYxavBa/EXwnrJ061k1Od7TXbW4Nlbx7TLcPschIlOCzMABnk81d8N/FzwDrXgrUPEB8eeHZfBemSC1vNbh1iA2kcpKARPPvKJkyR4UsDmRR6ZvmRjzI6y8tZ5Ve6tR9nt7wiJrULhplIxkdlyMduFyetV5NRmY3SzWLxllWAoWwqIP4ATxls85wORyccZreNvDPhXxvpnhWfxLpkeu6hCZ7HRLy/iS+aD590kUG7c4/dOdwUg7G6YNYOn/tJfCG/vLe20/wCJ3g68S3jmuTHD4jspHKxxtJJKwEuQqIHcnsAT0WpumTddjrXur/UWnVLdoNxRSIlKYXjbyw98gd8imSaPKPOlu5olZZo1dnyQ4GCFb06gsQeTxisl/jF4FvPA03ivTPHvhm98MafelNR1+DV7drSCYlfkM2/y1fMsYCsed8f94Z0p9b8J6f4t07wvq/iHTofGGqE6ja6HLqECahJEoch0hLB2UeVIxZQeY25+U0+Zbl8+mgs9qskWorFOsskkih55omOcqNqE4wMdATgg85PQv1Swnt2tTKUs44pSTJNIp3nYQDnORyxG444I3L3rMsfFfgjxLp3i5B490eeTw+8jeIZ7PVYd+mKpfct3tf8AchfJkyX2/wCrf0OCL4ofDrQvDlh4ruviR4Yj8H3INlYare6xbfY55dzBliuC4Vj+5cFVY/cbgbTRz2lYnmRJYbJrqRYQ93EiESzRhdykk4Q8dRj7uSDxtIHFTQadcyAifh9p3lG3ADjg56EjseetP1fxJ4S0uPQdTn8U6XBo3iKSK30q4ku41gvZJgGgS1l3bZfMXLLGC28ZK5qhL8UfAWiWfiG5g+IHhyWPw5cJba5cza5b7tMkZzEkd2xcLGS6sgSTadykDkYrT2i6Bz9ixBDDPMEjdpRvAby0PAyOecfrUcMccbgGUiXLKo2ZzjgYJzkHP4Yrdu9b8Nan4tXw8mu2ieKRYLfppouIzci2DlPPEJO8Rb2K7wAM8ZzWra6LZ3G0lfNlx5bSQAoPc46f/qpqqhKocnFatF5EpkaJZCRkDPGQCcfj/OrEELS7i90sCSg/vCF2sQBke3FdNJpWmtJ9kyZtvymMOTtx+NE+n6VaXLW0cflSY3PMqkspPSj2lw9ocz9gKxjzrmJIWB2tuLhscHAH1FLBYxyl8+ZsBwoOA3UkEg+w+vNbl/pMNpGryBBdSvtBVioBPTaCc8nrz3psUOm3tu0xWWRrcY/eEkkZxxyf0p85LqWMI2sbW3meagdmAEe7Jxwcn3zj86SG3jlVSWK5ODx2wf8A9f0P1rsrGw0+dPtELLuKgbkwAox6H8M0aVpyC4u5ssUeTIaTuwABZfxz+INHtVqHtWtjml0aR4vNT5VG3G9cjJbBB9h/Iircmi7LvyZJFihJOSAMH0X27/lWiEs7K4kt5rmWSKYnYjS5Hum0fmPqfSizFvJ5kMqq7uoZVVS2AAAeR3yBn6ip5nuYyqSZFFa28cbW88u+FvmiKtkSLwRkDqwNS2sKvEYJ4GEw+YMcZYZ4bk9eeR9falaeS6hW0ER+0oQ/nMNgAB+Vx79OB6mpNk+oRqyeXb3MTbSRk4I7fQ1PTUx6lYLPcyG0MaLJGVbc64J9DweeuP1r598GwP8A8IhofL/8eMHYf881/wBmvoi1je6jhvUcm4XAK9BweRj8K8C8FvE3g7Qj5Y5sIO//AEzX3ok2rWJ9T1X4bwCX4feDtjuPL0WzLOhYlW8iPJ/Lgcd+nFdLNdWzsomlRLVEOFfrt45/4FkAe2fWue+FIkn+G3hhVCGNtIsixB2kBbdMLx0z83ft7104YzyyXDb4hCAdoXIYYyo9+cnj1HpQx9NCHUIBcQsCZFd0xtTGFXI2oc55J9vXsKyPFul22s6DfaZqdvd3tlcqVvLeNmjefjIRXQjggcjOMcdzWxceZDdpNhGfdvcZP3iMIDj0w386ZPdva7UJV5Y1baVbcJJGHVuh4GT+PtVRbVmJpO6Pnuw0/wAQS6fc6jf/AA2vL0avcx2eqaRdCAommKDEttbKJs7olIfhcMd44wprY8b/AAym1T4iaXp9hYav/wAI7/YJ0ua8t9UaBIolnImEshYySHy+i4OTjJHWvcbiGzMS20ci5QqqwxylV6g5xn8azptL82ef52VZ5zCGlZ8ogGWOdw43Z4PrXUsVLm5krfeccsJHl5ZO54/4S0fxd4StLnTJbTX3urTSWZtVmuUvbaby3QQrbwyPgO4yWjbbtKY3EEGvOvEPwm8Xy+GIYksb5Un1CMSQJEst95jzrNI8jwsI7VFDOd25jwBx1r6llsZtQjspBqRVGk2ORtCsqZYAkHPJUdCOKgtnhhSMz3VxLbXQd5UAfk5XHPJ6YBAPat4YycJc0Ur9TKWCjJcrbsjyH4h/DWC31+I2XhdNWibSZdORFdzGZozD9l81mYfIpYsSemxmwzCn/D/4PaVpeq68dQ0O8mIS20qG+Mro93EIFE7K6P8AcklXcOh69M169JaRD7Obex85ZJWZGmG5JAQTwCeeOefT0pJJpIrZ4muN8MbkC1iULhVY5G/scDgA54FQ8RNw5b/1c3WFp8/P/W1j598YfCnU/CjMmm27avLqF5I1tBJbzzfYomkXKzT/AGjEaIj4Vipzt9eD0/jr4NS6l4o0a/8ADSW+npZWEUX2jXGluDGsN3DLF5Kliyk+WxLkHOcHqCPV5IzCXKx/Z4p05LuZJRxwfm6ZHdu496rTTzQiMiKU3RQyeYxADAHHHBwSDkFvUY7Gq+tVHbvqT9Tp2aezt+B5V4D+HF/4L+KUVzOJf7Nt9Nkilv4XnaBgWUxRpHLLIwKM07cKAoc4zur1WW6TyniiCWy2zGSOMtiQqc/xc54DA9gBzk4AmFzGkqKIp0DHDEoyncQeCc55APQ7mxjioYJ4TCI3bf5TABEQYPPGOzNtPT7qjk5rCrVdaXNJa7HbQoqjHliDWyBWh2tHGpFyqqSoyeCxOdwDAf7zZ6DpXx1+z78N9S8OQ6L8I2b4hp8O00vX4tc0jxXZPoB0l11KOWzW3v7KAC7eXfMCI7x45Iy7/IuID9kJapbz3TxtHBGMhpGG9cMMMqE/efgnIG0ZPWpDHbCMsyea0EIYq2QsLRtyHz34x6+gFcrV2dcW07xPzWPgzx1/wp39njxJ4y+HniDxJ/Ztv45tdf8AD0OnT29476hDci2tTbwRmW3inClFeOMJErKcoNtdB420++s4PA/wxl+HFxoviLwn4e8N6nrN1p2lM2r+JNTs7BfIFreWqM4t7Py5EluIJDcMf9Hg8tWkkr7w1Tw5BrF9Z3T2M1vf6ZG62U44ERkVoXkCn5CTGw+ZlJAYgcMc87aeBbH4XT/8JBE9xf67rd7Bpt9rV1Mk07Fm8uNZGYqEXfsiCwqAC0f7sDJHnV41Yx5YWiu/ZeS7/glr5H0mXLBzrKvir1Z78j05ptu3NK9+W1m7e/J+6kr85+dV18HJfiX8CfHN7rumeKPDnibS7LZp/hPTfCE2mf2Xoh1NL+8nuD5NvBcM32e8nhs2nMKHCofOYFfSPjp8GNY+K37NPxnew8J+I/Ek2meKLXU/ClzLos2k6tqdzcJpwvrm40q2s7VLhgHugtzJFI5VpgNoTc/2B4Yz4b+PPjPTLa4vV/trSbDxHb/aXU20To0ltJGw4Ks6RwjBDcxOcjaFrd0fWoNB1m18JWfnQaTYeH47m/1iSKK3W2jDmOD5FRY1VxHdH5QqosRG0LtqKElGPK9k2lu3o+r1vda+RvmWDeJre1hrOUI1HZRjF80U3ZJRUVFvktq5PbV2Pj/9qf4Ga343+P3iOy8G3Pivw/e+LtW8M393rv8AwjUV1Y2j2Mc6G/tNUFygsvs8KsWiYLcySqiRMYpzjf8Aif8AC/UP2hvDf7TXinxn4e8RW81xcQeFfCunaZosUmqrpWmTLc/arIzGH7VDczyNOYgwLCHy0kkYR7ftg28Gq3C2LRQvBDhxLGR84GNoX0IPUjpx/eqG5trMG4lhvTLdHKhCw+ZvRAMDd0zj15rusj5ayPgn9pb4e+Jvjf8Asw/Fgz6f408dy+Gtc0//AIQSbV9PutP1a5WRLEXrPpUNpapKsRku0Sd4nba84GwJufZ+JHw08Tp+194tubn4d6vrsXiHxr4C8RaNrcCSpZ2NvpkEwv7t5kBh3qqSwfZ5nR2NyrorEJn7misltJLSHc97NErPFCdoCnjc5bGepwPr0OOIIr8SfbWaR7aa8fyYWI3ICvyHa3TIO4446ClYfLc/LTwF+ztret/B7UPBfiL4beMdO1Pw58PdU0bW9S0m3El3c3n/AAkwv7S1tLe4aOK7WFbeSdntpG81Ljyw4fygeu8C/BnXrX4xz/GnxNrfxG0f7R4x1SSxm8IeCIoRYpJYvFPdy6U/2me2F1IFiSV7aR2W13T4e4jkj/RSa5gg1ExTwiRNPtgsU1mcYzzk9AuAozyR1+lQTq50vTIbxIlS7beLqI7pI1OJGJGMHPfHHOccVfKPkR+dHxm+Ef7QnxL8R/AD4meKtJtNU1G0vPDlraaRY3t2rWDkGe9u9UtvsWy1eSZY/NliwsCxpGUmwrjDX4Yax8LtR00W3hP4k634M8L+Gtf8NP4Ubwa1lqGqrf3l2I9NuNQtZ5PtsX72S5a6hU20SwwGNRPcba/Tu4jln1oTC5i8m3h3x3sSAoXP3fMGcYxjkcc9qrmC9kvow/kgIWWO2QkI5/6ZufutwW2c9sdxQoruJxsj5r/YN+Ges/s/Q+JvAvjrR0fxdbCC/h8Z6bHc3Wn65p6QrBbwm9k6SWuGhFsyw7YwrRowMkh+sofEUKRxALOsUoJNwkY8sHsuQcg/h3rkmnh1KeNGSZRG+64kSMoJADwJVB+XJVl3LwevtWlJcPZ7riH9+wCrt4EhTnG7jZLHgEBuG7ZB4quTZGbVjTsp4p726ZZisjIEWQgKxJyTjnnHH50ujzxw6i8Jk812jZsYO9SCMlwceoxg81Q0yB7ez3ygTuXZ5HZN0O4n7pwN8RGcdPqOabbCG5u7iSF4VtVVQqTS4DyMcsElA6Y24znknpVtbmZp3FzNcXf7i4RZcHC/cOR0BODgdOgzUNjqafbbq3mE0E6opDTqG7dMjGfyFQyWqi9giRpEuGO9kvHG4Ko7OMggk44HWrF/bC3ltUQyWxeYBhMu5CNjH7wxxwO9Ky0M2zVslEcMcO5TGItqIDz1OePxpNHeVZZo542MqS7SxIwqkZU9fT+tZ9/5ME9pLOEAIdXazlxkEDBByCMEfrU0NyqXy/vp445gEJlIDEckMDjI9Ovep5dB31HXLG/VLeP5LhCxYxH5lbBXPHQZPcjjgVaEkk9nBNHbOskQ4Qlfoy9enX8hT4litb+Lymj8udfL+VsncvI/MbvyoeR4b1oYdm2f52cnIjfBzke4AwMjvSb6IXqQeZPcL/aCov7sFQiZLMoPzA9O/wDKn3Sk7bwXBijIAdo8KWQnuTnpmnxpcW9+0LXD7JV8yMhR97+Ic5x6/nSQW9tBcTW8snmJ95Fd8KufvD0znJx70Ji1GyW8VneRS4RojjeDyQePm5/z+deBeC9//CHaFtJ2/YIMdf8Anmte9WKw2k7WrBJMMDGygFiCenHp+nPtXgvg3avhDQ1EkmBYwDkc/wCrX/ZoduoLyPTvhFdR3nw38O2lyvk3unW66ZfKGP7u4tv3EsZP+9GTj+6R6iurhO+Z5f8Al3/1hZX5PAC7v/Qgc9xXLeJPC1/4e1XU/E/ha+s7NrpRJq+mam5isrvYoH2gygEwTLGoUybWVlVQ6nCsvEwftI6XEkqy6JfFDMC0mmS2l3bsNucLKswBHy9x2FYqqktS2uh639qktZFMyO7lWlEbFdxbOFUNnBwDinSMsc8KXUWyNVLyTuwwXb5R9Op6e1eSv+0vpW6KSbw7rjQlwTI0dqNwA4/5b+pzUV1+0NpqqVTwNr7CWQOz+XbIFGR/01/2fzIqvbR6/kyUmesXU9rO9yBLO8UERUhSxXcQe4HYY796r/Y7bzZpInkE0MCnZIozuOc/fBI5Ck/ga8zb9oywaEqfCfiJJLi43nK2wyMjgfvjngDp71VvP2g7LUI7l38HazOWVGEDx27D5Tnr53A4Izg9CMcVSrRtuHK+qPVZLXTo9SlijRrybyACIz5rBs4DY6Kcd/SoYEniu7KIwC0nW3Kgh1Z8LtyxJJwPpk4ryw/tDwTMGHhLXktZIwPLge3hjVQTk5WUluoHUDntTbj496dNEd/hHXyHO0Sf6PGsTdtoE2d2T3bPUe1P20U7NhZvVI9TEcM1uwEkswViFHmFYmbcSCCOX5OOAOtRIWtbeWaARoCgkJHLouOTuJIQYx1OT7V5Xb/tBxLJLIvhvxAJmIjYkWxdnGAVyJflGeNoyR680QfHuBIwv/CK67LCTm2gKWxjPGSMCQEkepJIHIPWr9tBdRWZ6qsNwlkrSRIYN277Tu2KSTw+Pr1Yg+o4o8xiobynZoQZZAoKDkYLbjkdD95sk44A4ryq4/aEe5sYxL4b1za0JG1fs3ltgDDk+Zlj0OegOeCcUH9oeCRIy/hXWPKJBMS+QdzHBDli/wAznPBPA446GpdaHctJo9T+1iW7LCJVITCxo+wMPmOCW5QdSR95vYVC1vDcQvuAublHIEIO1yof6/JGu4jHJ9c8CvM5v2g4nCu3hDWILSPcpLNCxRuDuJL4L8g5bpnPXmkf492LWN2lp4Q1jymYhnaSEmNwo+bduOD6g/Wk60Fsylc9cNrLYT+VdXoPmQFFZY2YscH5Uz0J59+uMVC0K20wZLSPAtPuRnfIAeC7HHBHynoSffFeUN+0REzfbLrwnqVyzoQJi0WxFyDmNQ3Yn1PJzuxxTZ/j35CtDJ4X1O2gWKUSyKYd7RkgncDx90Alj03VPto9WaLQ9Yd7i5zLu+RrYGTfCYwd2AMc5JGF5P6VDqGlHVNJvrLUDHd6beqBNaTBXWbzBghjgDazfKwxyH615aPj7LBaJ5nhnV4bJI2Uyho8sjBSMnoMNnBHOO/rGvx0nnRIJvDOrfvEZVHmqGYY3dgN2CcjpjnOcVLrU3o2axk4u63OoaXwh8C49Z16303UWe/2TXEqJcX93etmKKCITyFiZBJIsSxO4HLEAKjkZfg7wdONP1jWPFU9n4dOrTXOr6tDaXBW2Nv5aokNxcZDSC3jTBZHhiIZzsf7xxoPjdZpM5uPC2rXWzm5aaVS3zZ6gDHDLkEjPJzkgVxvin4watqviGLUdV8O31x4X094ru0stPRlcagrIokuCA7S7WxIiIqLnBcEojHzavso2aWi2WyTe7f9dXvc+swOOqYjmpObVSXxTbcpyUbKNOCtve1rvdRs48uvqnhbxJqkV6ti2kf8I74QnuVt9M+3SG2n08BMACF1QpbzsCsUJJljOBtCMEt/UxpgvhFb3EMVrFAAY4YJcsG7NkAFQO3vyc18oeIPjlqGtfEbQriPw1cfZLB5rnTdLm3SS3kpjMbaleS+WfLt40lcJGql97ElchUrY0L4++IbKOystd0qy1OK9nENtd6Paz28sUoDvJGCzTbwyo+GJTAX7rZ+RUMXBXjd2T3tp/w19lrp5WOnNcpqv2dZKKnON+VSbk7Xu+t5KKvOWicrxV5qSPom2unVJpEuopWnxF5pYG42glU+UcMxySOgy3NSvLHBc2OmEyWcNvGJZJVcYwPlXcR03Ek8148/x5e6ltvtnha7Fvaq3ltDO8RL4wGOI8LtG7oeCCeOlMH7QFzZtqJTw1PJdSYRpLiWQuijhFbEHpk8jkn616fPHe/5Hxd1uesS3E76LeSW5V7a8lMEYZvnA3BAVIBDAgNxj3zTraNJ9aB04tBHYwFmguQwVZG4OF6r8vccc8DPNePwfGlbY2V3ZeGbh4LIHDTXUpjyRtByLfAyG6j16VKfjrdX1rqFwvhS58+UsEljuJwY1wc5Itc5weRyOB6U/arv+IOS/q56ZZJItleXSXRs7u7kLLb7QImjYBflHfHJOOfboadDYjT9MKieK2mMYmksrtiscqgEjYeoxhcEfMpA5ryVvjRqmqQW0EvhoXNjBh90M9xkdcsMWmOgIHPQn6U9fjFPJECvhtm0worpl7gFY1wSyMLXCjLjOBgj61XtI9/xQpST6/gz13zJLGwUPGXvyY443C4eMsBhHXnzEweSuc5OQDVOK0iaXzLm0SJHlZo8I0aSc8MATlSMDBAP3skHGa8qufjTdNqJRvDsQZVzEGkuhLEm09F+x4xksSOB904BzV27+OOo3ljPbSaHtsF/dMTNdEqxIGC5sc9Dx3BPUjFUqiX/AA5k2v6uen/brxJIxp1ytw7qnEo2zhSdoHQiUdW3eg4PIq/a+ZZR/KiiGRiGlt0MtuSM8SRdVI45HoM5rx1PjFN553eFU+YZCLLffLERlWGbHAYjJI6EAnjHEsPx01ZbsmDQy0kseIf318CQCRkj7Ad4yMAkn0B5qvaJ6WMWesaa1vqeoz3KpDb25/cxF08y3lIwXAyB3xzx93p6z6gIrW7tf3KWEskoMjeYJIyo6kDsM4zwvavJrH43avbRyeX4ahiuGlKu8cl+VkkJyQ6/YPmbnrw2O4HNWbT446rb3zzv4PgSdkZyE/tIYXauP+YdnHHfv9Kh1Nb2Jtp/w56zfiJLSS6S1hd0ZALiycEMA4+8PbPQ7qt3l+ZLVjDfQT4IZUlUq+QQRg+v1HevGdT+Nd9qNt5sXhKOBkff58a6mo43LneNO5wcH8BUl38ftSudOlSXw1bTQyAqpkTVBg8cH/iW46HOcDoffCU7pe6w76nsGqRSXEBlbThAYiJvMUqW4BOOgI/XrRcJZrpgltomjKhZEJRvnHB6jqSpP515E/xz1W2s2B8LizgKjI26sUwwOBzpuBn0FR2Px48RQWMUR8N2/lou0EWmsE7AduR/xLvTHbqR7U1JtaJi06ntN01jJB5kbu4jwwKOzFR0Prjjin3slt9nWe1MTeSd3I4x34rx6y+OuspapYt4YSTZHtKi31hjtwME40z3/wA81JF8cNdSL7OfDsMOQQsktlrRCjkcj+zhxn3HWi7X2XoCae36nofjPxfY+GNEm12SN3FjkxxRoQ08jDbHAnHzO7lFAHc+gzWb4S+FFppfhXRrK+dDfW1lDDOd2f3ioA3OfUGsv4eaZYeMbqDX7/xXbeMLvS5DFDZ2KeTZaVNjqICWcTbWI3ysWAY7QgJr0/8Ad+jflUc8WaKLZ5LqOiH4t6rqd9qsX2zwdpN09tp+l7h5V7cQtia6nTpKEkDpHGcr8jOQSU29zfXF9d6EBBapBbtGhyZQCq8Zwig/l71zfwgkvV8JWVqgghT99cEylnba88mSPqcnqeWrq9Ggnjhl05rnm2XZ5YjBGw5x9cj3rRJQXTTUjSbv3HXsputMNwliMlRIjRbXzjn2PTPbvUK6jaXWlLPDPcRNJASEi3ld23kFcEZB9O9P0kXxF3YtcIiWsnlBxFl2DKGB5OOjeh7+lSaMt3HYtaqYD9kkNsEZGHyAjacg91wenWjRbiSvt2INJn1K60u23R2N9E0au6F2RlJ+bBB3DjP6VW03UjpM0yzyS2QMrR5nRnhwGYjEmeDy3t7CpLA7oFs5dNe7ntHaPz4HUeWoY7fmJVgcdhn9ak0q6kWOVZLhrb96wMV3CWUMW6b+M/1696btroNa2ZAYLnVdSuBZzLZW4jHzQNvSQZ67SMYJGOCOAc5p+q3WoWjTO9qHmZWCSWzEq4A/5aIc7uw9e3FQ6NZT2pv2SW4gzcMmbLaYoiADxG2Tg5z369BUvmS6lqBfzftcNpGpZrQBXZtwbG1iem3pkdOlVpzW6IWtvUoi1UQiSUzW0OVgWW3lLIwBHDqeRnHQYPcVLc6itvbSSJMdw4RSxEbkDA2MeCc45yGGec4xVjVbmRoXa0bzZ58QGWBdsyEnB8xCMNgeoB9PWot0UJab7MI1Q4NzbKzxqQOkkZ+ZT7gZ5zmqTvqyeW2iHQJ+5aO+lubZYYgodWAbty2CV56ZHDc5x0qrdpIJ445NkAwsaKzMV2KA7qAAcjGMryABwRioDLHcXKwxzKVbd5Ucj4RmIOWEg7E8AEdiSD1qzb3B0exaO6sxcs5beIl2uH6kkfwjPp7YJp2sONihdXjsWgF6jSgFpVZ1KFpCoQfMcOmG4J+Yd84xVqaC5tx5UdylvftMivbTSnciswUAf89U4wM88HBHSmLZJ9mjubmRDaK+9drL5cjDJLrIVHzbi33hhtoyTUNjp0N6kVwH+22wdp3iEey6gOCoIDZ+RQeUOcHp0xSdmdES9iyOsW9rdSG3ubcq0lv5pCFjuff1GQW2H69asvrNylvqmo21sbnAZIWVwzMe2FyMj5UOMgkVl21jFa6PeX80sepW+zHnMRui3KuZB68jGOoCgDPSrAZVh0qz0+VbtZmMr2YcZAXBcgn7v3gMHjkYxUNJ6G8bdia4sPtdzpVra3UjxITNMZHLxbkxtDJkdweOMYFTLfxvcX93qUZLRL5PlQAyfdOWK4565xkAjNZ1xc/a73WNSSSXTL6FBFHANokk28MSckMCxVcg8dz0qeWxNqNP0y5tkS3h/fz3ERLtIBnkjBYFnxnPXPBzUeRaVtxkN1qGmWBieVo7+/fAa5XHzHAIV92Nqg8bucjvnFOkt3W6j0BTMtuY/MktPMUo6Z4CyHDAkjlcdASMDmmx3AGqXNxJcRXMMUHkJbahJtkUN83Iwc7iNuG+bC1ci0eXS7ApLdxRGdhIWly0kMmOFjPVgoGAD0+hIoehL904mHwpdWXjzXdYsrPU9RF9b2kM179sUNDHCwQ2UcLFVjGJDNldwd/MB2EqH5n4neM7O+8HaXcaZcSaS1pq1nFc3v7lZ9LilnWF1jlIkhWaKSYxMw3bVEwJLZz6/cT/AGC8tn09y1sUEl3dYEiBM8PkH75J5OPuknsK8r8feD28MeE7nwhZSaNY+CtSt7mA3Mk5hnsIJVzcL8yNG/mOZHEzPGEJU7XKYfz60HCnJQ2d/veq/Hd30/FfU5XiaWIxVKeJ1lFwWuqcIrla1bu1FLlio+9trpGWnDDq9x4o1Dw5fwX91pw04X73ZldEgmRkj+yRszZkaREeVnZmddwLNiVQvWHS2hGoWQnuXtvJE8AlkG1yo3qZCACcgAZJ52NkmvM/GGv+CviZZWun3fxC8P8A9nWdwssllpurWsgvliUlY5t24NGVfaRjBJUH0N/4d6aup2Gs6hqH2u2sRqk40htYja3uI4jHEyM6yfOA832kqsnISRAAqhVG1OtHn5E7ryd7f5L57+Rhi8BN4dYipBwkrJpxau9ErN7yeraSXuq7ble/cytpscN9F/aEx0yWA3EC+d+6AGTsH94ZJ+XkdqjjnttO1ea0nbUv7NmjjeCCQnEjAkbcD5ipyoAOOetIy2l9BA6zzXt35D+T5Z3yRlSrRlQBhQFbnOPvEH0qBPs9/Zlx+8uI7Nlmvp5dohkQ4GG/4HnavHzCu9I+btZFmVbnTNZWJ0lnjubUCPTzLuZwhPysVGMhScZyOMcnFU7SCNtO0ly0msXCsodW3SW0IdeQEJ5IKq23qcHAUYFaVjH9v1aCOWBLNJ0aYOAfNuhwQSWyV6N6nAHQE1lxStommxvYxLHFaXfltMoIjKmUjyyn8bjnG3qMZPOKEunUh2toaVndTWdzdabbvct5jK++cH7TPGVUYGfuoCrgu2NowACcVlstumiW0YluLmRYnETIT9nt2TosS9HYEDls4xliOlRx6lHJqM8lxCNQuSqooRtwZi3AkwepBH7lemAPcWjdWSJPcPJI7zriWFNyRjGflkCj5SPm/dKex3E/eFpNMyauTahLDeWKwvdi6usiUwRMTF5oG4huf3rnBypOMAjgdbt1aXF3YGISBriJRI32U5WMgZBduMkgcIuAM+4NN03SIks5Iru9k2uvkC2LjeeePu/MOckKpx65piWuLHbak2SWylkiiKgxEHJDSY+QHBG3JOD9KemyMvUu3lkba1ctKsl0iiTNom2Tbz05wiY9R27mnO1xNFKs4jlt3UK8iybYeTy2WGXPPABI5wKrQ2xtoo0iLSW5k5jkVtrbsjKjJZzyBuIwavWq3CzJBMNl0sYcSySK7sCT0zwvTnANS1prqSQS39xNbyJPDKr+WeHVgoK44jjAGepIJ9R9Kn1JFM9r9oO1ppSM3RDO3ynpGDgcD69OtMNrDdXMaEi4QCQusLGViflG3e3uT0xjFJaxRaa1sPMltod8i7jIpUKGKrl8buMqDknGaWmjQO5WBi0+7WCaf91HLGsM98jHBIJAUEgDoOw7Vdm8udrprgXl5CkZDSkCONAPmbrjj7uOD0FLHJp7RmON43ku5vMIG52KBgc5GT91QevU+1CRx3jtCba4mlNzIztvBVQHPGGYdto6fxUPXUW2gy3d7K1lmnvjZiCGOIRoqKxKqDxnPUtjgdxUlwvlT25imNzcovzwtKw+ZuMjscF8/wD6qdDF9rvpBFLJYkSCUw7AEKJwCcdiwJyD/DUepNM8NneNPMmbgOPKhUOIlRucEH3OP9oCn1F02OW8d+FZbV18T+GrJdO8VaTB5olAVRqUCjBtLnb99XwSCeY2CsOjA97ofiLTNf0XT9Us7w/Y723juYd4wdjqGXPvgisqO6WFcSajunmkzNHMqDYuMFTgAjsvflq8D8Gyyw+ENDjgJhgSxgWONX4RRGuAOOgFc0qeuhoqjjoevfD60ltfBGi6i0r/ACiaGTyQARGZ5D1A55x+OPeut1K3jgu7G8+1yRxSOIpCZSAynkYI9wB9D2rmfhMN/g/TLOdpzE6TPGwkwrjz5Pl45z/n0rcsINPR7zT7phPID5aFmLloiBgAc7SDnOMcitLvr0/ILaepYuP7Pt9Qgw8D2s4aKVQ+7BOSGzn/AHgfrWTrmpaT4bQ3t1dpZaEyLHJL5zAtIu7aicksW4UAZJIAGareMviFpfgnwZqF7rK3Di02wgRQnzJXZsRFQccscdcDIOSMV8za7431v4ueIY9Uu5BYwWirdQRmRWSxTrnKk/vMAlm6kcDC4DcOJxXsLJay/TufU5NkVXNW6jdqcd359kep6t8X9Slup18PWX9h6ayKTc3ZEtySONwgLbUGNuN5JweVBriptW8Z6teXUTa5q2pTXDgQSTubMBwTuxHCyAqBjouSQ3XFeHeJv2irPwvcz2/hu2i1LVDF5E+oyvi2jPAkjRVADoTv/wBnG3GcEnmfCdl8WfjlebtJvLy8tnuVS4ktLiOFLUsQCzIpVgACTkjn1JzXydXNlUqeyjeUvI/aMJwfHB4V4mtGNKmlpKe/9fNX7H094h03xN4L169tdP1bWIJBOZ1ns7yVw8RC4CRyM4baMDJQ57E10Wh/EzxHo121zeSjxNbKiG43bLLUQRkFlKhY3GFwFdYwc9cnJ+YPi34D+J/wT1/WZ7bUdUTwrBOPsmo3N2kkcisAQu2ViWboNuDyuccVZ8E/tRDVnt9P8aWsYj+4urWiFTGS3JdAcAYODtHYdMGtFmqpV3SqJwfnt95jLhJZhgIYrDctaFtXHSW3bv5Xuj7e8M+I7Dx7cNeabqV1PJZRhZrKdFgvLZ3wQjDb1wuRnIIxhiM53NTnmdraBGM93OxjJZfLuI0C5JIB2sMA+xyMV8vW51PTddstf0m8tg85jELggxyrkEwvs6x/N8wHc7lw1e4+APiRYfE62W7tIZtNa3BiuLa7cMYZuCqJMMgKRlg34YB4r6vDYpVrJ7r8T8dzfI55fepT1g932fZ/kdm6j7KQygYH7yVVLKSB1mQ/MvJJ3DkYznHFZS2YubiKVb6aPcm63hZtryJkttjJwGAO3hjk4P3e9y+dne3tPPa4ncH5bkoH2Dn/AFg4Zcgcd/wqTU5NlrMZrKOZWOZkWPGSeBvibnPbehOfcV33a+Z8wktjLvb+6aCW38qO4Mj4maN9sRfgAsCPkcMVJBGDwDyaqa2+nGCKzZ5YmDCInOLmFEU8OBncmQAH6jODwa1Esp4INwunivH/ANZkCUOMYICklZEwOg+cY4rNtZppbhbt7Z7mIARWjWsh8xQvV4N33lBJ/dk7sZ6gcNWvfobLZEUmo+GrzXo9Gt77Tpb+3mjM81vfRkgbVkTzk3ZDFWU4YfMCCDzx5T8MPj3qXjb9pz4yeENfm0TSbDwQtrDpt9Z70nuDMu/5yzlHxggrjPIx0JPknge2tbv/AIKM/Gi8k8Nx61ajw3p8SiSyRbczGO03A+dtCORuHBJyWGDWP+z7Z2D/ALVn7TkS+DYvszSaTHFp81rbYsUaNskbm2AhecDOcZzxWL5na5fM72R9m6T4gs9fsLbT7W70q6e1vCt9It0sn2eXG8owUkxuCyjaxU8jHXjD+O3xft/2cvg7428d36R3J06HbZqZW/0i6JEcETBm3HLsM7T0VjgYrwf9iHwPcaJ8bP2mdYTwvL4esL3xDFDpyajYtbxPb5nYhDjDKvykhcj5hzyK779rv4NX/wAUvgbrFhpWgTeItbg0W5j0aweRD5dw4CmdYzgCVkYqCWOxdwUAkmoldqz3L5rrQ47xZ+0t428E/se+CviHrfhnwwuoavfad9rt5LiY2Rtrn7srOQGEudrtgsqgfePbvvhB+1RpnxY+LGreHvBfhnXPEPhXTYhbW/jnYf7KaYZLxLK3LZ4CuMlsAdMMfmH9pDwFe+KvhV8CfhENNurj4l+ILKwh02PULxmsNMk062j+1RSxeZsUkbslUJwmCTu49J0eL9oJPH/gbw54p1f4V+DdOtbsalJpGkTTR3uq28KndGkLMpKqGDZTG0hCeBioS7fddfqQpPY+uZ7NtCvIvIk8y8uXL8sFUyZO5W/2GzgcHDY7tXhX7XP7SWl/ADwn4XSXwPY+JofFOqf2XPYSTrBHtZNysTsYMhyVZWAHLenPskOsyWcUj3tqJ3uT5Yt51dpEjH3FY45C9Sccgk5ytfGf7dfhZfiT8ePgB8OdJkF9eXd9davcTR7pHt4R5a73GTtTckhGSOQ2eeauSvaLL5nTtJOzR9T6je6v4H8M3uvahqYl0DS9OlvreNkNzekQoJhDLcNIBIVCSIjlQ7KQHcsGaTktN8M6H8KdCn8f+O7+XXfHVxcxKLuziLvI8uGj0/TITztO+RVC4LEM77VBCT/s4fEMfHf4F29295ENYt4TpfiHRL2JZmstQgHlSoVyNqyFC4VgR854+8K3NX8B/D7wJqGk+JPFN5dyxxQSw2+s61fTTpZmRvNJ3E7Iiy/IsnylsKmWZwG4KlK1pxtps29F5+em21tddT6zL8fGpCVCak3UfvKnFc1RJaQurOKcvjdpXunyvlSPGvgV+0TZeLfC19qt1YW+n2dt4g1HS7iXXNYkiS4mWQzNEJVR42Ea3IjQFtzx25baoyq63xn/AGgvEXwP8T/C2FPBej6pF4m1GLw+Y/7ScywOBgOdsIVWG5Djk4UjjOa8e+AXwytNL8OeLYdMsNR8YXh1rUWj+xNFbLZavLEXALMysJoFMJWIco+WfbMPJt4Pgr4THjj4KfD+/wDGXhBPE194H1RmuNfk8VxxwR3St5jzzTGQ+aqRkAANscoMNtZTVUKjTjGTfL03u0lq3/SOXH4R1XOrTV6ibdRJrljKUvdhDq2tmlzbO10mz7YezFx/Z8DiZ5BHJHGTjzJTGf7uR5UeN/OQffNeTftH/F7Wvgf8EvEXi/TbSz1ibRjE1ukxdIiDcxpIE2EFRyfn4OSNpxmvS7GHiNYIQnnKkkyXR3oZV4JKqBywbAiGegJVc5r5U/bSs/Cni/4AePY9E8Pw3/jG+eJ4haWTS3ckxuIjJgom52GH5HyAZGMivWl8LSPmHsdx49/aMvtN8cfAjw+uiaZdx+PS0N95kskUVkuy3lIhAVmIPmOMnDuR/CDmvbPBnjXQPF8M1/o2s6dqVmrvbl7CZWRXU7JYvkY7PmC/u0+Y8bjxXxT8R/Dnh3VPih+zJLaeGp5dO0maSPxHImiXAjt1NtbAC5VYyw+ZZPvksfm+6AMfTvwZ17wHqN34s0nwr4cl8I20Fyq3E11oD6Yl5hfLWS33IokQheNnz4wWYZBMw7NmMnroaXxe+LFp8IfAmua6PCGv+JE0m1kuZ5tJhiiSKJRuBkmkdUUKvBCCRvlPU1578MP2rtXHwv0rx58VPCkXgrQdevoG0W8029a7imiuQ32dZIlBeKTgEvgBgR93Ncr/AMFHPF7eEv2dtSay1DVhruvMuhxWrylkkiA33ZWEoflESPlgePMznpXzBr3i3wNc/s6eEvDtte+JbP4hQHwjLf6ZqV+09jPabVaKe2QMY1AEqjBCuu/Bzk1nOTUrNsSV0fo9F8evCS/FCL4ZHUJbDxbdWP8AatvZy2M8K3MCs4IEroCWHlMMcDjgk8VhftNfHYfAjS/B95aaFa+IbfXPEdpoNxDdTG3EQuFm2yggMcqYl+8DwT3rz7X7t0/4KleHIIYgrn4bvHtml+b/AI/5nJ44BwM4HGO1S/8ABQr7TP4M+DVw7xR+Z8TtEURoCQpC3GCWPXqf4fT6U23y6slLU9Vvv2itI0e4gS41vwfbXjRtbWsFzr5jluXG0tsjMOTjHIGTkjI9PL4f20dRuvid8I/DOgeHbXUNM8W399otxc3bXNlc2rwrCxkVJIlyu194O0hgR905rn/2n7/xF/w1t+zdJe2dsLmLUtauraCG9Z8qtumCSYfl4j4G1icY965Hxb8RNV+KHxz/AGOPFOpX2kau2q61rN1bXehSTNatCRAqLiaJHR02lHUg/MhIxnFRy62bv/XUSfU+8LWa7aWM+WkbWq+QqyJJgkqpbkL7KM88ZqOee31CSWSS0Z5pdkKDySfLJXMjH6ZOf90cVNHqtxp9pIJYIRMm9thmKlzuOCuVAI6d6jjW1cRm3uVM7IttbyRy4fOA0jsM84yDjn071t1vYXZIcthBdSCKzjjMDJ9mETrhSqnLZ4yOcL/nNMcb7uG5igijimlKgJJhZIkBYsRjHLKuOM4HvRHbSRXjxxTT/ZnAUumHIRflYsdpPJGAeOhOTSNc2t/Lm6mT7JHGJEZgY22BgAMcHLEZyOwUdzTIvdFmW6kIBuIpYbm6dUjb721AwIBweD+AyxFfPfhxY08PaWrRwKwtYgQucD5B056V75cxb5tPkeWcySSeZt3q4jwfkBbaeQ3PPH3ic7a8K0Ka4bQ9OLXKljbx5PmN12is5aW1LW7PXPAAs7v4cWEVxObe5zOI5PNYsD5z8jnOOBkf/WroxJ9usbafT7Voby3B2xqoCBiBujPPQ/0rlPALFvCWiXFpYb2t2nDs4AGzz33fw4BHUdyM11t3PcW6vq1rEkqFM3EKs2XUDrjH3hjp6A07WsaJPW54r8fPGA1bVdK0y3SS3gt4Wv7ptuXlO7ZDHtBz8rh3IPdF6CvlL44+NBoekwaNYrGmo6pGLu6uYT88cZzhSynlmDEHI3KARn5jj6G8eWEviD4va1cl/tYgvoY9qybESNLeBmdeCBy5PcnsM18ZfHDWYtY+JutPbSCa0tzHawOOhjjQAY9s7sdeMcnqfz7OsRKEJNaXdl6f1of1DwBl1KpKjSauox55evS/33t5G14P+H/hHWfhRruv6h4ne0162fFnpQhRJJvLUtIke6QB8qyHOBt2HAYnAq/Af4qQfBrxo3ieSK4vpobN47fT4ZjElxI/yqJG/uKMtjByQMDjNeal/kC4z35r1C51H4cv8Eo7eG1uP+E8FxC888LGONlxIAQZA24AHDhNuWKkcA18vQq3aqU7QcF97/zP1jMcHyU6mGxXPXp15pWSXuRelrq1l576ml8fPj0fjtaeHb27tJdN1bT45ILmzilZ7WQEgrNHn7rfeUg89OTVJfh94Uf4JP4m/wCEnK+JxcJIdGMSNKsO5ovuiT7jPsIcjKhfunINN+HOq/Diy8A+IovFFncS680kZ0ybyhNHE5SRQ3ljaWRflZ1ZiCdmBkc+XKAApzziqrV9fb1bTlOP3Pa/qYYHLlCH9n4FToU6M09laaerSb6a279D3/8AZt8fySSy+EL2QFJcGxmkbmM7jujyTtAG7eCwIG0jFfQ3ws8VPp3xC09YpCNO19VsLyKJiNkyFmicPnByEkj45O5Px+Hvh5qj6R450C6imNsUvIl81TgpubbkHBweevavqrU4Lzw9r1reSyRJFBPZ3lrPCR/paxTQ7mRQMAjj5M985Oc19HkuJnOnFv7Lt8j8843yuhGtUitFUi381v8Aoz7Ji0RmuXkgDxRMhJivAZEkdmBOVPPGOxHJHHFR3skMX2Zby3+zztIPKlM7tFGdvLqw+71AGQOWHvUi2062168dwzyq77t7MH45GGHsRxioJLS/jWFkkeNXj8lf3m5stzuwflY8ex59q/QleT1Z/KrSiyprcc1pHIhkgYT/ADqYI8s57kxgH5gOjr3xnjNI0theQRR2zz2tyEzFYPuaOUA4UqOhG7kOpBHXoKfsu9PuYrhdOijMQISRwMN8uCfk+ZcdMHd948jrVG7vLea6hXb5alzLIlsGKs4HBVRyjHJJdCRhfm61duiKRLDbyWNpcRxW4gnQBZTIoZpAWIw6j/WcsSHU56DHWvnT4GeBfEvg/wDbA+PfiDWPD1/pvhTX7rTW07ULllC3QghIJVWO4rkg5xxtA6ivf7i5murm1iikkiWF/tAlaUZTaNq8c9STjPyN/smr8epQaldg3czR3kUYSCW3gYlM8sxBHByMFCM4HTBzTatqzTluWNUjS4iu7z7X9jlchISG2ho2AX94mfmB+Y8gEAcEVl69pug6jcXl/f2MWu30MAVN0O020X8IAYjqxLY6/kKdEhu7eFUEDQXFwJpkLKsMsa5Zdq8mP7oyOmM/UT/ZrQwk6jeQNG12GG997cAAYk6nAVh05I71nyrqWkmtT5h+Mnwnl1X9qH4E6vovgwzeH/Dx1Ntfmt4httfMtwsQl3nliQCCARnp0r2Bfhb4Xmv9H1m48D6Lca3AftdvqM2lhp7bHzbFdlMi4ODlSBzjAya706zaWq3cMEcpeW4Kk8h9owGAL8sx+bkdNy5I4pJPFXnGadYDE8gES3Ck7YE4J6gfNkkgcZ+TGapLl1SFya3sUtd8SXE9jPPZaTNrWtu4trOwFwLVc5ILmRs7BlTvOGOBtAavM/hd8D2+G/xJ1zx142v08WePfEkAsptSjtiltZWi4CWlmCfljA2hy2GkOXOOc+v3dtYalaNd23+hLGqxQPDDiaT0BHDEEgADPUZ6gEU4Wgv7G5stUeddZUMo8wec+3lQFUdQR97+9nJPINCSTuJxufLvir9lb4g+Cf2lD8SPhX44t/A1n4kmD+KtMvLYXEDoFJa48gMElYsGLAMpVnLBxuIH00i6daJJo3iC4t9QtjELa6s7xPOiuSQcN5LluGG0bcn72MnrVmNH1+0ntrl3W5007/JWPbIwzyu/uOChA/2c54zBBerdadHHYW8d5PGdt1IuFUq2xgzsf4yCBjk8seMUlBPcaUoO6dmfD3wL+BXxY+G66h4S8ZeOYvh34Q1TxPqGrQXOlymO+ubrdCiIbgSAIZUYSRxF3YrHKSpYK0cvjTwD8S/CviHx03wph0bxT4T1bWIrS90fUr+O3tr6QpEtwyswCGSSWVbZZI5Y2XbJGAzGPyfuG50xNetZkvpZLu8kT/kGQsfKb5ByQeo6EkkDPA560dQmsrjTZNLmt7LU9NeMpPZgeTbQQSpgqzdQpyyshGCrdBgVxywcZTb/AK2ta99utu59Hh84lSw8aNnzWte60ftOfnSa+P7PM3fl09PPPgSnjef4baRH8TNOi0Txqk08t3aRXKSQIsssh2hYicZBUeUC2AqhjgVyHxz+Gfj74y2uoeCbXVf+FdeBnbzdS1m4YPqmpRZ3fZ7a3jbEUZKkGR2zggCNVyH6jUvGmreEbyz8N+FXXVvE08TtZyahEfL0+0yUJnclnkSOQPskH7yYcNvZWlPVeGr+80DXtG8MX+orrvia80+51W4vLdRDLNCksEKBlDv5YfzM53kFoW+Ybtq6rEx5uW2i0fZPt5v0vbrY4auUV4UlVU0005RWvM4JNudraRVre81d/DzWZy3iP9njUNX+Gen6DpuueJvD+qaXaNDpPiv+27i61m3kIJRpZFZTJFuwGj6bSAAMUv7MDfFnSPh1bp8akhtPF9tfTWK6k90s51G1wPKkaOPjOcgH5TjBIya9R3vojiCKZdOaJmQW8Eb3Mjo+TGpC5AKsQM4JA46Gt61tdPutMjnf9zIxV2mlbMwkBDAF25OPbseOtdTaTTa+48C3S54t+0d8FLb4j/Dr4iapptle+JPG8vhi70rRYJh5TWxnjO8QKwVQ8xCBnPJVFTIxz54P2P4viX+zr8NPCuprYeAfHGnWmivq2pJZRzXzfYo1H2V3Vlz8xyDuYAr0OK+qbRo7/Ur2GW9a5PlqgCfuiw+82CvJA3Lzn1o1HTrOz3htPQxSiOOKSKINIHJYf72QCCD7HmktG0+pm1szxy//AGcf7O/aZ074vHxZe3TWvhmXw+un6kolkeRpmYS+fkbVxKfkCcbSd2CRXNfto/CnxD8VfA3w1s/COnnXJtP8d6fq11vv0hENjEs4Mm6RuANyj5QT8wODX0drFwGaNXSWFAHbzZI8qvGNxGecKW69yKjdLCPT7e18uFRM24wKoyEyW2gD8FoSXKkyHdSbPFdc+Cl14u8YeHvFes6df3mseGjPcaZdt4ox9jMy7XIQWmGZkAyGB7cc15Hrf7NXjTSP2iPgbreh6Bd3OiaJ4g1HVNZmuPEX2yO0a5jiLGOORIzGDsYlIgy5A4Hf7GjsJIdPuBDNIk0kqqoBBDSYGckjkZGCf9g0iXMltDMzFmCRrsudqjG9zuc5x8xIyPXA9aHGJOqa1JWvri5l2vC9puLQQPvVk3Hhn6jOB045555FNmtUZ5GDxLFIu7bNEHWOAcbgc/KWwPXtxwaRXSZpMxOjKir5RXa0PXy41yPvE/MT04Hbqii4ht3Z1iljicefcM+FkccDII+4hxxnHHXrVLTYd7kNvcy+TNFIIpUhIFwu4h9g4WMDaScjnpznGfm4txSXExa8B3Oz7VtZQcNIuVwCOy5IJwRnJ7CopGjRbeZ7TZIoPkvMiv8AMTzKx6854HfIHU8Vltjplq8f2QwyxwjMsEoXyIxjHOR856+/0FU1cjYtWKXEesTNCiS3DuFZvMIRTxufGCOMhccZ6Z614V4cMv8Awj2l/Kf+PWLsP7g/2a9x02NnhJe2ntiHMlzcrIA7YOAoIbOduM56cjGTXh2hRxf2Hp3lxx+X9nj2/KOm0YrKdrmsG7Hqnw2ZbDwdp8hupxA6ysVh42nzpBxjOTlh9ceorZZII7pGaK5m02dNnlyMFVXJ6kZwcjHuMGsf4eNJqXgS1tne5BUzBSYSwXEzlSRnrgjr2BIroLeZWjeyljv7h4gFZVJJAxnDZx7cjr8p7mnfTXcceh82+P7G/wBH8Y+NYHgMGnz6hFfMm1ZHmt2tYtyMOQEASQYP3iNvAJ3fIXx70uWw+KmtmWMqtyy3Ctu3CQFQCwOFyCVPYdDX2z8efBd5cT2WpiGeWXH9nSrPKoUqW3WznPCnc0kef9tPevC/iV8LYvGFj4Wnu0+wXoupFvry3VW2WikebMFwuduFYDBOWPvXweb4OdVShHdO6+Z/TXA+cUMJGliqjSTi4y7qyvtv0/E+WNuO2D3r2zS/2RvGusaTYajHPo9rBeBAqX18sMqyMM+Uyk5D54x1PFer2f7IXw3Xy7uP4nyyQ27BZpYXgwsuAybWxgeuDk/Suo0i20LUtZ1CLU/GZs9ObyZMzB/MkCICpfJHkOXyojOSwXGfXx8LlChf61Z32tJfM+zzbjWWIjF5S2uW7lzU5PskktPU8OH7G3jOKB7i41Tw/HBDIYZvL1BXZHBxsAHVz2XryBxXh19ZS6bfXVpco8VxBI0UscgwyspwQR2PtX3R4hh0WDSYrqy8YmO8vpxPfQvvt0ghMgDKfnYxOoIKoxO4xn3rntT/AGVPBHjC5bXrv4kXUE+outwyT26RlEYhQu1jlCCAvJOMY5NPF5VCaSwq1W95I58p40rUW55tJuL0XLTkmmvS58qfDrTX1jx7oFokTTb72JjGpALKrBm6+ymvsDXL6bxLpj6faYvzdX1pBp7oyMBcNOp3qwUA/fc54O1DwOc8b4R+Amm+B/EXifUtNvJPFVjZW7Lp7RqgM4C/vl7gtkSRqRkE85BFehfA3wjP4n+I76i1vFJHpSfbWndgiSTyKRCoVRhvkZ5COweHGK9HKcHUoL2ct29fTY8Hi3O8JmCeKpP3YQVr6O7123XRep9My3c0st0sJlVGALKnlgBVK/MRnJBVu39KSPw273dok8sW1YIzwpf5kyDt3E4+8OQM8GrWneVp9nBMQIoHUQzRsgXa+SACB05O3H0+tVIHubySyhfekUUkkQJVhtUKdoYhgSdvHHcGv0GLs7R2P5flq7vcdDpcttZpMl47Tg+SqliCWLgZyzEk5A65HoKy9N1BtfhsNQ0u/s/E9jKzxRz2swnVdufMIkGMMGVRwcgjBFa9holrbQWiyeawtrw79xIIYnG4HqByhznHJ9a/NX9hLQLK5+JP7RMVx4a1HX47XXXit2tZ4kS3zPc7g3mTR/eCrnbk/J24zDk+bT8ik7H6HPCYb4C6sprSRkykSB5Ac5LHB6DOOmQTnIyayLfXLdNYvdFgv7RtTihS6ks7abFxHERw/lEFlGQcOVyCTtLAYHhvi/4k/DPwF8SND8Faz4Pvz4k19I/sOm38tuyzo0hjGx1umXcXBG3cDn2FeF3/AMJdTj/4KZeGNbj8Aar4S8L2WnwzXF0kObe3lW1kCyNLFIyE7wgxvzkcj10jJydlr8i1NRPvi2htrmDTYWugsAbOLgMpkk2nDbwcBsk4Yfe64NX7LQ4ppYZft0W2e4lmZ4go8wjP7xlJKkDGAQO/NU5bUxJay39qsVsp2i5t8EkkYVSp4PO0kYHIz16y2Wk2OqvapDf+YJ5mxG7BpPLCkhmJ53cKcjHJPLVT9TX1E0u+8O2l4ttb3VrcXNsjXc1sJllkQSf6kFeSN4bIGOce1bUdwqRD9208lr+8eFVJ826f+HHXjJ/76B7V+dvxNGgW/wDwVY8C/wBsjfoN54cWS5jmRisubO68veqDLYIjx15A9K+pvGvjP9n7wYNPt9audE8Ovfs0EUl9FPbOUA+cRkhST8wGF7tz1rmc+7M3JXaR69eQWOk6xY28F3Yr4llSS6Fk8gWa+jX/AFpRMhmCluwwMgHrTtVmMcVvqVtqgub1B5phiOI5oSeQEGSAAThjnBz3r81v2rrDwVN+378A7Hw/bR2OlyvYLeRWwls/ma+fudpXIxyOK/UGF7izu0jvEtgLxmU+RCygycsQc5ByA3Jx+tOMpbsSlqc/qMQXUdP1qVYZ7K7Ajl8nds2kfLxn5yR7Y+XBFVZQNN1O5WZBp+nXoBmBAEvlMflyOigHcvALYYcA1bOhxJZanpUVm8t2hkFtIFPlxo3zJgnhfvYIXk4NZ0czazpMNyHMl3ERHPc3abo1boYI0H3mPHv3Yn7tbLa5p0K2vX9v4KtftNzexaFpqR7mmuHVZAjuY182R2AjG54xlj1GAQadFqNjq1jBNLbwCznVUgms286JE6fuwvMzBw3z8qODnk18H6/8QPFP7RnjX48/ADxp4mTR/Cmn6wot9Qs9Ha7v/JivUaOBjGwDBViTG4ZyMZ6CtD9o74o6x+yx+zj4ftfhZqel6Zp9nqdvYbrbw3PEZojFIzpLNNI6lnMYLqvJDZyO+ftJLVoy51ex9eW/gfWtG1Lxvrvhy2srvxD4ivYJoFurx4nihitY4lNxMInKlZEmby1xkNgMvbkvDttpmjeEfE2pWfibV9eubjURZ6vrXhzT542LRsB9mi2hpBEpHlq8Bdh58j7shmHpmiW+oL4f0bULqVL2WS3tm1GOC3aO1eR0TcwXcWI3Yxkt35OaxvGfw317xVoDeHl1YxeCt8klzaw2/wDZ032RVXZYpswPJPzqz7Vby1SPDFnkrhq0eW0qa5t9POXXdb3d3q7bWPsMBmkav7vFT5Nad5LdwppJL4ZXsox5Y3jFyS5uaytp+BNeGt6j4l02LTNXttDtryMWs89u6vNMUDTLEXQSeXGwQiWQnc0jhG2ItW9C8QaTouvW+mX15p9rrGrSyfYLXUrxVubnylXcIQ2TJgNHkAnG7A4o0zxPcaFc6XaajqFvDo16kUOn3NkEAinKgfZ5928hnb/VuMKxbyyFfy/O/PXx5Z+Hf2sf287Twp4m1aK18B/D60llvne4WJLq4TM9zH5m4bNzKQzLjCwOQAOR1QkqcHFy2fpu9Pl0R4GLpVMRWU6VPSSTSV5XtH3m31ejc9FZ3dkj9LrAzHWr6V/JVELFnIOEIwG5JGOpP0HPQVetb1r7UoZRLBLa7SsMkIyruV3FgcnjaMZBxkmvi/4O/tM+MviD+0x8QvAui+H7HV/hdok6aXd6zO8kM1qyp5DLvAdZt8iyBVYBiqZLcGm/sF/FzTPCnw+1P4VtHBZ+I/A2qahYzadOmyaWL7S5FyAPvDHyMexUdmFaOXvXeiPETSVj7R1UmTUkVcZEYC5yQSSSVOOg4Vj7DHQ1X1S8tr+X7PGVlWFBJkcOhPy7sdc4IA9S3tS6BqQvLV7+aB47h4klaNfn2K6BwAeucYzn+6O1Mtwt/freyOVSFjIWViCDtwF6jnBGBzwM9X42St8iZO/zMnVNe0vT9Y0/w6+u2S66tsJDpUt5Es8itwCiH5yDtYFv7u7kZrWnuWQJDNBJnZ9pkLBXjJ/vYycqmOFA5IWvl39tn4DeG/2gNH8IaPqPjfR/BHiRNdLaRqOozKZmZkPnWqfMG3DEbcH76KMd66/4sfEvwh8Gf+ESj8ceMvE2m3GvtHp2nyWnm3AuJ4kjTzXRYmILbkPH3mLH6Z8z3unb7ybX8j3SHT/tbFrYFWbDs3mMGCENtORyHbcxz2HHYVFJfzyXQsTFDPa/dWJbgMJWXIaPJUZVTgvnpjBznFfG0fizxLcft56x8I5vHmt2fw/tPDQ1JoWuEhnSUwR8m4EYkXBfIwy49R0r6J+DXwQ8M/ATR9T0zwsmp2uk3s7XU8d/d3F8sTE7v3e9mMbuGBfGMtt6kCnBylulb8ROyO+a2Se6itooYvtG/wA13b/VkjIwuD91SQcZ5OBjk0t8CtgSiKkMsmxXNxkXMnYkkYwcen6U9oIbm6Czww28KIgMK2+coThVK4yM49fQdjUV/EyqskoW2LkblW1KYA5DEE/NxwRzyAOnXdbol7MfNCwgSXyZLaABVht0umAdt2ckcZJGfwOT0rxLw5Kn/CPaX/r4v9Fi/dm4fK/IOPvdq9zltlZVe4t1EzlSsEdmzKmDuwOx6DJP8sV4f4aDTeHNKkYLue0iY/IO6D/ZqW9ENRfQ9J+HDhPDNks1xBjMyIrzyJj985UYGOOwwODn2rfvrY2M9vcJBbyFpVjbBkZVT1LMOmOSe2BjvWX4BdIvBOjS4mWSNpSh84D5fOcFVUHPT24xXQ3TmeLYzx2+erzXzMy85BCj86zvqapaMo+LfBsXibRLywu7S1uLK4haKa2jVj50bDDLknnqSOOoBr4u1VNZ0fxnqtjJe/af7IjTS4byJQxkCuH/AHitkBvmj3dh5ZIOQDX2Zp04bTwk0iusR8l3m85t5A7YIB4xwPevgzx1qcumfEXWbLVbC78O3F1eXNykWqR+SsytK7ho8tnZgjDAdjXz2b3hCLfRn61wFavXq0pNWcVo+990vQt+KvgTo3jLR59Xs2h0jWHkPyQlnhnYYYkgk5JQhhgg+xqt8LP2XrbU1u5/FDfaSZpLa3trW68qNtu0GV5AC6kNuUJtOcEnaBmuv8FeJ5o7K5+1alDaCCY/v5WTMikYIKtnJPJ3YySWAFdVo2u6ZfXNxBcagunadBiSGBl+zGVPlc4mcgA7xyhKllPXjnwKeHw9Saqta9unzP03F5jmeFoVMNCo1FPdatLsnv8A10POPix+zJosXh+71PwoGtNRtT5s9hJcebFNE8gAdZGbgKA5ABYttPIIxVHwl+ztY+HbF9U1yVNU1G3yfsYJEKptyCe5ydoGcDJ4BFeu6y+laD5g07VIry6u5Bay6dF/pkUa8I+9lYlDtGCAy7sAAcEnD13WEtdHf7JcWx+1TpbxPC7CSFljZjuBI3OAQRlRjIPUCqlhsPGp7TlV/wAPuOfC5tmVTDRwzqNpvd726q71tvrcp6rrmq+HNR069t0gkuEvvKjilkMccEbs8AZ2CsWUZgyTk4QbeBz9QfDb4dJ8N9EtdMe4R5iTI96iH57piWdnyc4ByqA8bAFPIr4d13XLrXdR/szTbSXVdevsRi0tNpd2ChQCgbcANo/hOO+K/QGD7V4h0q3lki2yDErWzOoxkfdYEEZwSM9Aw6cCveyy03KXbQ/O+NIywsaNJP4rtpdbWt+u42e4k1V1W3Uo1wudm/anmBfvZ+9jH6EHqK01SBbYoJPLhnIIcjmOcYznnruA49QR3qhbRw6eFMsxdJx0UKHtmUnGOBxyByOD14JqtIJ9YlYySC1RyqE7SESYcq7dgTwuD0PHXBr6Fxvp0R+Upvcs20txr9yoYpDFcRAoqM213ViGBPGTjHbge4r4I/4J4WE09z8adettS0nw8Nd8az2VjJrMIn86WMSzeTH+8T5wJQ3BbIR+OM19r/F7x/8A8K1+HOta3a2cs+oQRmLTtOtU8yaTUnyLeJF53eZIyjoQBuJwMkfm9+1h8Err9n//AIJ7+B/D95fG41STxbb6lf3EB3p/aEtvcmbDr1KBVQE8naSMZrJptNrSxdzv/j5aanL/AMFIfgN/xMtOe+udNDrLaWDokWTcnBjWYliOvDL2/H69g0jxNqfxL8MPb/Fa1dNIdpdV8L2FiiG8hlQhDdB5WkQAY8sgKMndzXJ/2f8As43Wm6Nq09p4SudTtIoWS4kg3T5K4ZQxBYclsgHrnvXzP8N7LwXqv/BV/Xbnw3awXmh2nh37XbCxZo4vOWzhVmIJG4fM4Ibg5z2FQrOyTuCfc/QaWy/siT7VdQ29m6klbiNmNo+cqA6HlDhiMjOOfpUt1Z2LPOLi3kadyZJJLINsiDNgDPGTwTkDPBPHWo42aKGO2S8udPlB8qf7QoaIZGcBjkAkHACsP0pI5Dp2DbLBp8UOUkuYtz2spxgBh2x3bnGMZ7VpqdCPgz4nQywf8Fdvh3/Z1rHrUh8OFo7e5nEaOPsd6MB9pGAOnBzjFUP+Cnj6/YeG/hj44vfDVvZW3h/xKHL22o/aBsZQ0KMAilQ32V/mH+FcH+0r8VLv4df8FK/D/il/AOpawbPRo4LTRtKkzNqfm21xGksJQElTJKeMZIjPGTX074i+G/xD/aw+E+ueGfHfgzSvhtoepRK1laXGoS32qx3KjFvLJtCxQhZELPncxUOuBxWXK763MdNdT0HxHYeKPGGveENe034e+EddlW8WVNV1vU/Nn+wt8z/ZplhLhgWDISQmFbOeDXtE0l7Np0kZs2murCQSAySKrPswyHAB5ZePTOa/MX4Nft0+Jf2XLFfhR8dfDOrJPoUcaaXrdtFmfyEx5UeCVEkJTISVGzgjIPUfX37Iv7Qdj+0j4X13xTb290yS6vd2q6ZcXGDY20XlfZ0Zt3JaNjK5yfmd8ZAqou+li1bc9+nuDfTWcslvdW9pekRMjSBdxwSm5VyQDlh94ds5rmPFoTwnqUlzYadf6gbwbZLbTLV5nhIBGSVz5aHJBI+YcYwDkaE+uSXVjbR+bHH5IKq0RB2Mh2lt7AbsdgvHIJYZAPP+JPiLp3gS3ht9Xe4tHlH7uysra4u7m+YKC7JHErTSEcdlAzhiRirSdrodtz5E+AHgzxF4O/av+PXi3WLDxd4Y8P6/fOdOutL0tXe6X7QWKNE0UjIMFT0U+/Necf8ABULxToEHw10fw7/bfimTxLcatDf/ANk+IrOK3zbLFMpuERIk2/OwXJ65IAwM19V6l4y+MvxS1J7H4beGE+GFi0bwy+KvF0UE92Itw2vb6dCG2kYbaZ2xyQRkV8E/t2/Db4X/AAx8Fixi8Q6/4q+NF7rEV1rGreKLe5hvZYPLnEhVXURiLesWNpY+jEDFZyumraL8/wDIw0vdH07+yL+y98VD41Hxo+KfijULHXPEHkIvhOzIUT2ojGxbpSNsYSNfkRfmXaCWBJFfbOtW0VxHBZiyu47y6kWON5ZWYY+85LBzwFU5B65HWofCsj3lhpqXqva/Y7WGGKVQUBl8tdxDcgELtQgn+9xV22uoZr9576/YwRsY7OaRfKDcfO+5eDzlR04U8c5rVabL7gs7anL/AB31i4tvh7faTbaZDc6nro/suxScRPbrLNlAXMhVMDccByA5KIPmdVPwR+zd4T1D4YftC/tA+GvCks7ay2lm0tzrkiyTaVcyIkj3d66t5RDyKN3kyNyVHAHH6D3c9rr0d+9/L9tiuInt7exuIEMctu3ys0oZSCsmfT5kxgEgivzy8Eauul/tjfHDS7jXo/C1grRWuq+KZbljNZWWzdPLJPKSWkxHFbI75IaRGx5rFn4cRzQ97W3lbf5p/wCSPpMsdCqlh7Lmbd3Jztyvf4JR2Su1ZuWiV9Edf8PPiz4Z+Auh2nwV0zwf/aHiSCee/wBX1y21e2K3UiCUy3E2H85cBCrbl2qAfujOPBfiV4O8SfHX9rfxI/w9sX8FePdKMc11Mt6zQHZGgknaVVykgBGU24YKR975T2XwouPDml/Fbx98R/EFnL4H+Hz2cmjaDqMMFxHcWlnKy/ZJpmCsY2nQPIjyfNl1y214i3S/sCaifGPx7+OHxD09Lh/Cl1dx6fDeXbu0rCWRjEzM7F2bEaM4yWO7JJqMNKbjyT6du68+vrpr0ObPKOGjVVahzJz973rK6lqnypLkvq1G8lytNSas39/+B9J1zRPh/wCHdL1bWk8S6l9miN3qT2qW73A2ZU+WuFByFUDHIQ571uSFf7NRWspW+0szMJMFiu3JAOeM4BJOO564Fclb32osxtbm2kt1gjWykZGR1EahV8w85weT8vJ3LnjFbb3N1dzRzyfa43miWNUXncwJkKEkYAAGGIPUjpXqRa0R8y9bs+GP+Ck3hDQhdfBC4j0yyjbVPFyR3p+xpGbgMId2/C7mUhsYJPAz3q1/wUe1aE/ED4BafHqNo17a+M1kltxKvnxgyWwSSSMgGNSFwoPGF44rR/4KM/DTx/8AFBfg7p3g+D7c8PiFgdR8tvMs7iVIzFcOcELbjy5DuI/gAOSRnzL9rTwJ4a+Ftv8As6aVZ6zZ+JdVPjM3niDXpbxZ7jUbkva+ZNcNuJA4IC5wiqB61Du27mitodrfR+I7v/gqZ4rTwwNPtddk8H7LeXV4ZJoY2MMWJXRDlsHDYOAfavrL4E+HfH/gfwd/ZPxA8Y2HjvVbW6f7FfQ6W1o7AliyyDdtcq3RwBhc9SAa+V9EubKL/gq14mkW8shaN4WXbP8AbI2ji+WHGHPBYeh5z3r6j+E37Rvw/wDjNrniPTPBXiZb248P3H2K6gEfnKT5hHmxcZeJiNokXKk+mRmlyN+Zm7npF5JJA6TTtHdMSOTDt+diNmCWxgAgDn1ODmpPKnZZI9qm7chlZVGEII5HzH5QfUc/Wi4Q3P8AobOhSZdjrJEIgq9znZkE9BzzjPY1LFB5aSM1uZXd9m+3lLDkjA5BI25zjnHzVrdJeZmU7acWzBnt8TtKIlh8oZQEfKuNwx9wH/62DXiXhyVz4e0v+H/RYvl44+Qf7de5xwxxzQkSvb3bybQssahZCcbgEK54AB6dvrXiWiFv7FsPlb/j3j9f7o96UnF9Ckn1PWPhxpsT+BNMci3hBM5MjoXcsJ3wQSQAfzreiluJpDF5kimMYk8lQu7PTb0wvuSeuPeuW+GdwYvDGneYGdd1wkciRY8thcS/LuYYGcZ3D0we1dTcQj7SLhyrSxgAmVg0YUkN87NgMe429PxrCzvqb37GeUNpepOgZYTF5UjTTYSJtw2nKjqeQcH0yfXmvHvw+8O/E/SxY+I7C31OKIGaISCQNC2Mb1IJdTgnuvXp0rq7HzdRRxKFkucbXHljCckcFsgj/dXvmq17dRaPZxxktflWWJbidjsRsgHg8HGCQVB6YpziqnuyVzehXqYeaqUpOLWzWjR4no37Jngf7O9xLFqt0rwrGjXN35P2Rj82YnUiQNgkZIO4MeOTVVP2T9GhtXsx4v8AEsVoyGQR7rYb+CNoLxbhjIAJ6jGcGvatQ06/vpUvY5oVSNDIr3W5o5DjI3AkDGD97aNp554Fa+iXtqXKWdjcGQYRmKBFQcfKDwPf5eOnqK5JYPDtaQR78OIs0Ur+3l83c+fU/ZTs7PypLbxF4jt9NiCtIrTW8R4yPlfys8AknHp3rWf9lPwFJY/2dazatHM5zNcW1680k67QMPJIGXAGMbFGBjnk162L68u9SnfVIrfTbS4Bt7S7WTzmB+YcFgAhJwRwcnjPAp9p4mt01c6fYJv2qItssh2blJTcCevKhSe5IpxwdC1lBCnxFmc5KUq70/rp+pyPw5+Cfh34aW8tt4a0OKG48wLLfXR8y5mGAQZHYD5cMQAB0x36drcPGiyi61ARKoKEQ5OVIOAoUYxgj8QaWGP+0YZri8uJom2mGWMLsXI5OQfTPTvnvnh8ctq+lqtjaqJ5lwsroQFIzg7sdAw4XP4V1QjCEVGCsl2PDr4iti5urWm5N63e7K4aKSNCLO5nnaRkyvyxvgDjryGBPHXA/wBmrpjuGu54vJgsopogzxudyueV3cDGQdvbpg9uIdTmngmtm1C7dLMHLmAeWoI5GWxk+wGDkmqcFw0Eks/2JLpSiFZZ5cbH6mIMxHG3LZ7ZxzVtp6mCJJbWyufs93fuJ5I8xSR7izKwPysh/iK7u2M7uOhFcn8TPh74U+Luj/2J4r8NR+KNLtp0u5I76FlgEqoyJcDBBDqrMDgbSM8dMdNaXDyaU+8Q6cuWk+yeUu+IEbupIDFc8H+8Ku2t5584nSS/vriNSA8CIqPkg7QWABHAOenJOTSv1NE1sWYbOXT2tZ7lYZbQBSwh4S1cDh1HOQckEjpkEcZxycnwy8F6X8VJfGiaBZS+NLyEWjasilriW1YCMwk7tox8gBIGVAGa37SwkeG/gNo5iU5BubgquxgCFypK/KQwwMDgZrMkkl0+K1hjjs7WJl3fZzPuESNlnRgFBwSwIA+6eh6Cs/maJI2YpZTaCV5YIkMcLtufzN21iuWIIHB4br/Wo5oVtraYMDaqJnExhZjAFUjdmIdB04HXPJPOc+F9Ru7PImt4JZN4aJgXLtgqwOSAQ65+bgFkVu5q7Mx2OTcXMZfdITESGZWA7gYDbFxnOQQcdRVFpnNv4b0tfEb+I49G09tTa3GmxanHb7X+yGTf5aSOSYQzSN8vCnJ7ni+IIfKZYofsp3sGieTYFZuqEHIC44LdhG2Acmrcun2cctxK6HzjKwMojDFiGCooQ8EEOq4IPLdsEirJpwto4/tLSXIjUrAmVymAzbF9flJ49hngU7ji10MrxX4S8N+M7aC18V+HrfxHYeYEeLUrG3nQ+Z/y02uWIJOCAcdgADgHM8IeFPC/w20BdG8M6Lpeg2EF1cTPa6ciRwO5YhX8gnIfou7BGQQQ3ArsLxraSCPyLRb8nCNbYVd4O7eSx5xnPJJ39R0yM6KxgvwrQxRS26SFyJnyQ+5slvX5sHgH7zEcGhTfXYnRO9hA6S3sdwNwExDKQpzvzgrxySTyCMck8HvcW+snuJLtcEW0JLBP3bmLIPygxAnn5ccYP1NT3NosG+N7eK3ZFWJnZQdkZZFO3IGNvXaDj5R0yKU6akX2W6Kz3T2xEtrCcbpATnexJ7ADqAcqM5zQ5dUJu5YlkksNOkmkjla/vIjLaOsrFh8gIj9cLnJ6gjcepxXL+Ofgx4O+IN9pl14j8L6P4t1XSy0+m3t/aee1k0rrvYoTtcbhuAP9zp3rpNAhtrK9upbdvMnQbYVC7Y4lbHyBf4fmJJA9u2KTXdTn0LS5Z2RIpWkQOSRwT0LY6f8A1qylNopQUldmlNNDeWC2enLJ9gbMc7oDvReQVAbB3HnnsOepFZOr3M84j0GyYfZ41iWcyxLGEjHPlqOAWKjGOg4z3B5j4r6NZ3nhKWVy03lktAwGzacc7cHODivFLTR9amkmv2haG4LS3ckjqyRPuHzfKM92JAJ/lUqppcwqPkdj6A8QysZ7XRrUyOzyK93PJtKopK4J5AYk+nXB+lcVqPwC+H1tq+oeKrnwXZT69rl15mo3M0QllupUfcrsG+ViCobaFUE84JAI1PBFhL4b8M6DplzcRQXRiEzW8EQ/eIwBXeQP0r0Rrt55bNY2/dSgqQZMLkDJG3vxntS9pfcuMNpX1PMpfhnoGqeAtS8L3nhu3n0bUrc2z6WkHkQtEx8yQCOPHlAuQc5ypPpWl8JPAfhnwd4Ym8KeF9M07RNPkUypa2dn5MW8/e3Mr7pHwPvZBIxn3627nQG5eyt0juYox5kxjGVU8DPqOeR7CvNNctfEOpeJLbw7ZXq6foWqhw/iLQomt7+Big3RFW3+UW+dhckEDAQBZCkhTmqcLRjfpZHRh6DxtdqrUS3k5Sb6at9W3a7tuyxY+J11y41e3QJqkPhmRLG+vUddk8yMS8bIpb5oV8oluR+9I4aMrXRWeqpcWDy3Ooi0mM+UciTfGc/vCxAAKnb2BOTy1cvAkPg6yey+H9hbr4V022+w3UqsZ4LRVXfIzQq3mzyOJUKoq7nY8nLZbA8MeINSudQtLwTJc6LewIyrHLFts2KHlCV/eQuMYZSzqxHLK37rGnUaVp6y6221/NLa/wB/W3RjMHTcnWw3u07e7zP3nypavdRlLWSi3tpG9483rU9/NZyXFxa+dc27QiSJIp1KrCwwC+8kEE5wo4z0A61TvfDmiW8hjl0nT4d6mb/S9JjdXYYzLLtXO0HOASN3GDWolp9psrgwQqTFsg/1q7ygHGCPlDk/dLEjjoDTZrp7JnuJLeYiB4whEW6SQsAH3tjlwQM5OefSu5Ss00eHy30K9n4W0HVISzeHdAlN0rz288VoispIAyflO3OQev54rRstA0vTb4XFrYNpCwfJMLSJDjoVB2j7oG1unpxway4m/wBTcRWttelU3XUtoFV1if8A1cSrwNuTgh8nknFbN08UDGOSee0wrGRiHZC4IKx/MSegUkA4IHTtW3M777mdl2NiG5uRaNLBdQXM0zgYfoDwATjnpg7fU9agKPC8UMlhLHIhMz3EEgldeT8zADJJPPf6YFFvdTvdTRX1lBciSINiIKCVXAO4M2Mktkc8DjtRZZWJLe3nltb9hiYT8hG6cKx5PGFwcY71HfQp9CxZ3jPdLOt5BcFPlEdwDG4TI5H1/wB3nI6dD4Bok3/ElsP3UY/0ePjb/sj/AGa9/wBryGxeTT1uoYCUBgYF1x8oYbsEjAPQnr3rwLRI1/sWwxjH2ePq65+6P9qspW0KuepfDy5az8E6c212d5rpBKAJCi/aZt2EH0HPTnk10FrbsJ4/sJjCS5JRn8xgAOGDDhOcDgYrnfhoJl8IRPBOixRTXUcpkOCf9LnICtjjqPX9K6jT1h8+WRraXTppEX5BnJ9yR8pOWxz6c9ataIrqRXk8KyJaFJIBFy0rtxuPbzCcA9c9+2KhtIJra2jllV7+3iYsnl4VyFGQxLEbumBjA4BxSIZprRxFt1TzVdltyBthBJJ34+VjnIAIB4xx1ovZbUaYrxm4g8yFF2tkgxnAZ9oJXgE+nPfiqtol/X+Yr3d2UftkN+d1s7G0aaKXyW+6WbBxt643YJPCkZ64zVXVNQu4G82/LwxCZQPJkKhyB6HkY2Mc4PUc96v2CzedBdQ7L+OXzPLuFYLLKkjDDNlSDgbTwR9O1S31xs2JbwzR3gb5GyUWMLlPmZCVIAGNvX6dal2b5ehSd1zHNW0Q1yQJqMqfZXWN0Q3CZQsnBXbnBIJXcDjP14z9T1ufwdq0kEPm3C7lcQXETbjs6hpA2XYYHIznIxkDA3rix8qwT/R4SYN+6SKNY3I2jzAo+797PCsCDz16xQ6pPdXlsZ7M3H2Qt5bYMimRRjO4KTwNy9Oqnkc0LV26Ih6a9Rg1SG7vZJ7u3ivJiiFo4yQsR2FtpA6/MxAIzk7uprWi1ufUoGt7e4ge0Vdry42Fc4KqB13YI5HTng7gRnatqWnw2lxPc6LDHcIPNLxssbbtu1SRnJwCuQeRzgVHbQ2Uehm80+G4tGuH8pISGKo/AwcZ242qSeuVA9cpu65mNWTsjQmDR2w/tR3VYsYuriQurDcFYngAdFIPUbwOecl2zX93NMcbJol8qI8yNh9y/KTgEZIzjp16VkW+uN/a8VgtyLlY4vOlh5ZcYynBJ4O5hv59+lbtlc28MAmjXzJPKEm8hnGwfcIBAPzNjtxk9O8vpcqLvcuahYaeLe3WOGX7ST5aIXxMGODnaf4gQDkdOvrmrpd7cQhYnISVEBeSNTIoOAfvkYI+cfN3AOfZPD93HLZOklu0xe4cSw8SA7m2fKDyFGMYxkj2znE1DxBFpV3YNctItjdq8iQqzMQFBypUhRkg8/NyB0BFLW9jW50M00dxCEmt/td3bsfOSRy6ueVUsBztzyML/PJTU4vtEEcMmILVZ0AjtUyduQRjcCGGFOQBnqOtZOia1aa3DPqFgFMUTsyW4dWdGxnIXOVBLDCg9eMcVKbdV8lLgSbnVIcu+ScjavB5Z8HA6Ekt160Fp3Rda2M9mk8XmLcjEYZZQrJ0BQNjsU5BPvjjBgGpGeUJOJGRIlwkTE/u2Vj91j1x17DB44qOOCa4ctK8cksjCELnHzPzjKgnORk5+7zxzVia08q/nUT2tqLfDuyqP3LsSATgfeLN+pPrRsUOjx9ouWE63F0LgKxgH3d6rtkPzH5flU/73Y5xUttfW16jRJeM5imZdygtCcn+InjJyw+XpnA6VVs9NtzO4SORpyuZ544xhVztKgEHBwxOOuMdOtVNS8phbWdo7lojuEkIOD8rfKVAGQxYHaxA4GKe4XN24SNzdytuUsp+chtsbocLtHAwBnj375rDNsjXEawzNG0YVC0hKSTIrL8pVhhhyQCOgYevEula1BNaz2c1u9rfwgN9ndPLaF+2QvAcnDAZ5Bq7p+lHVEtZJH2XMESADy8l8bfmbjuR3OeD9KQDBMba4SWW6bIVNqAMiAFiYyAc/N8xDDryDg4ottKkSGBr64w7lowwYkLheRvyeOX+Y4wQM4q3dW8Lr9g1GMyxx/MkzqCqrkrjOTg9t3fPTrWelle6U7/ZTCbP5nuMMqknd8pIx2J52gA9MDqS+geRd0e5hntpI4YmQqzISF24PGCwxncTnPJ5BPQiovGlhNdaTbwGNZkbaX3Dnlh1x1psNxJevFfyh2mZBNgOFjC4PGeM4JI565zgVj6ve3lzHDJFeLZvLPDCrmTc0YaRQTjGOVdOM9c+lZtalKdlqRfFFLFPDhsLwkLIhMUAyrbl9CPb6V4V8P7u4TTby7aQTzwvcOIZbZtiRBEbZ5bf3ckY78cd69b+JOlbL2we9u21BFtpZERcIMiSNd2Qcnh2GM9u9cf4ZsoYtUs5LOxeH7XbTi4Mh2nGYvm3Pu2jJJDdgc47VKWtjlqy5paF34b3niLxJ4b8MX9pJaXd5AzC4e4kU7YA55AHOMDgdsgV2k17FfzraGC7u/s9wxdYVMbeW+0AiTtyDnGMjjvXmnjHwVN8NLk6jpMgtrfUYysUFq5fbJu2lV5GcErgYIwSSfkrp577xVpegW1+jtfadNCskl5FEQ0DYyyuoGcLggt04PSlyuxpGpy6HYamZYdRlcsHVAgRX3Dy/mHcEZ7Dn1rHnj+2qiuvnWyxO7JIxj8wb9pLgKDj5S2D7Vhabr0txEJbyc3ltcIzxbIdwOAcbTuG5iQO+Bk9SK1otauLnctvdzwoRGjA2II288tkfe5UZGAea0i+xzyaldmVr1lrmkxX1v4Zs9A063vb6Vp9VR5Yms5tqZllTDm6ddzsgMkaqPLT+HNZPhrwzc/DHwvpmn6bpWoaqkZg0+CC2RZJ0Ejhclmkjzgnc5UBQOcKoJHXrBJqDRma9SSOQF1mRRGkfByQq/e4xk8EHnrxWPpNneeA/D3iCe5udZ8QxQzyao0Ny4uJliEYPkWqEDauEwoPGWxkFhjmdFQk5rs9ey30Xm/62PoYY+eLpRoVEn70W463qS+Fc0r7xi2lsld6Xcm7P/CZ6P4Ua4bVpbKysQVWeaZ44ohJvCjzg5IUEkDPVeoPau9s5RcXV1bSS/aEuAGVJfMfbGgztRsBWYf3sgdOTXmniXV47nTdAvp/Dlxd6lcyf6Oglgg1KOdoGPl+XM6IxWL7QsjiTcCOkgLEbPwostc03QNOfXfMkvLmS6uGSO6a5ighlleSGPzSBvCbgDjGNuVGNtXGrzVXBbej8uu3XY5auC9hhI15O0r2tzRu/iV1FO9k42bejbSW132ttYWwH22Ldb24jyhiuP3U7YwD/tN8oyOoIyGNTvc3BQyeXHKUgDmPzPlYPgn5T98qNoJPJDgE0DUTDEiyx4jhRntnkG6S3kBw4xjDYGNp2nvk55Nh7AXhivLdwjx71hk3bvLYjDAZJJb027Rx0GK7F0bPI8kN06eBUuWSa5tCsYKxLt3N8uQuw8A8jainj2zirMpAthb3sPmxBt/lQ4ZmZm4EmfunJGcH8axjLb3iR6dO0NuRGJIoDKsYZWPEkYX5jyMfKBg55OcVtQvLZ28JmUSbR5iWoBDx+hKjJbHPJ546ZrS3Ui/YuxyzQm1htJlZ0IMxk+aJEz/ePOc9Bn8MV86aPMf7JssyZPkJ/A/90V9APEZXhulbdO4DRysQ3nnqAIlzleRyTkDuK8B0RH/saw8yJfM+zx7sMuM7Rn+GspJDTPU/h55DeE4pZ0mhitrq/Xz4B8yn7ZMQeOwGevc11FlPJHIsi30N5K/yRxXHEgQkAAEAE9s8H9K5X4dXUNr4SgijlkguJNT1BjtIcH/Tpskgnpx1A7CusknhvDNNdxQT2sXykKdu07fmZg2CDyAOeg4q1qhvR7/1cS6tnZ38y0KTM2+aa0YsxQ9AOhzxjkYwKpi/i1OGa0iv0jVeFjuF2uoUcNtJHAYFc9DitCS2/wBGLxQ3cbMNm2J8sseR8uM4zgkjuOazJrhJwkaXWy3tj8i3VrwzBSMHGG4x0HJ9+9JJq7FfXQdHNL56XZsd91cRpILq26LGMkBkbAU89AW5PfFTT3KSRxXs09zZyRBlB2MY2JXcdysMsM5+XPGOo5rIvLcX4mlszbLLdBUyrNCYVADDKjB9QT1BYZBAwLdnexKz2qJNbllEKiC7EzZAOCd3JAAIHPOGI9aHG+oJ9BsF3eW07Jbtbm83LcLbRbkZAW2sSuMfdPUAjIbJ4zWHeGOa9t7dlmtpFZZzHFt+/sIG4fLj5s8Y6fUk6NzNLLcSi4MwjE2WkNsrMH5ZB8mG98cE5wfvHFfUtXiuV/fpKJERoGke2Cpb8HPzFueFYLlemSOnM8tncL3WppXEM2s2ESyWqIqgsgnQqqc/OrNgYbrxjHA5zXM2PladFM88aLKjo4LxyRlioIJyCOCVJHU4BwMdHR6nZafI17b6kiRuXeWySYjzEPCvktzgEZZTjLAnkYrLtRPrmqOgMEVtHPtNtASjKSCxXCjIYjn6DnGSaS0umNvZmX8VZptQi0y5jto5RaSEmeBXOyMjpvJzjO0EAEDnoDWtZatdnWdOt/O3mW3kWMgKWYLnAYmPghByp6AnPrWnNoTahdRiKCOS9b5oys7sq/8APPkj7oHBJGCMkDoa6J5rDw7E2nLa3FxOYybiWIh1Td0QknPJwFyD2zS7CitWyjZWVnoPh43uony7U/M0bqeAxAC8KRxuwApHpXJ6TPp3ia+0SygnMUQsntdqx7gkhjPzqNq5YOBnIPQeta3iLUr+6mCaaY0vYot0kV0rPFDEdwyvyHeGJ25IxnHJIxXDtp/2XVreNdJispNNlhgv4BcuMoQuNq9MHI3lDkZwRySYbu3c1vY7w3cPhW8sVFms1pMfKkFtGGRbhUX5853bSvzjvlQRXRyzWlyUMSfakcBbZIZgm89ivQOcqF6jAB+tY3ia5a/NnOJA1vFrTCSJk53bjCnQZwoyfTPsBVjQCkF9qJLeX9nnV0kijDqjYYNu/h4+X/8AXmoXkaI0Ifst5YRzYgn1BlELPK3CktnB45TLc8emMYAE9lDKAkCRvIYtomklcSEy4z1wAwwSM9fm7EVzrXtxI3mQhI551keVGICSpHjHOCVP3TxjJGM8VtWLRPqt2BskMkBLQJnbIC2HIPYZC9fTt1qrXL3A6vGwk+0K3kRTGGeJ8DyskhSq5OAxwBg856U62tvsOnhoJ2vXELSyMESTG3Bzs25U5A45GT7VStbJf7elkkjV7SaJY2t5nILKGXDL3PD/AMOMkHkinxX6W13btA21NyqkLFkwcPllb+P5iq4J9hk8U9imzQXT7HVP+Jk0xjdFId4Jv3flkAtgHgcgYOe4wcGs7UpIIIFNpKLZEclGVmILZz8w6DOCcsecjgCq8yNbXi6hxbxggFlXhHLDO4ZwDhFGF5yTngUs000uqPK0m+VgYzazumx9wC4UgYb5lC5xyVbG4YNSQXrHV4NQgSAnzpJDl2jjCEIoycjHBOcNjPOcdquK0V1bAJMZ2mQOFJVfL3biXYcY+YqQDjPFYOpC1juyGEX2kt5kcSld4HIHkk435xjyyDnGf9msS71q/wDEE+rT/a7cQRRqsolbb5caKWdWVRhg24HJ2kk4XgVQN2QzxdfRJEiWWoxQSaazxJD5nlNczYx8pJA8tc5LFsDJHJAB5LSdc8S2fi7wvaXUsiWF9qKi4juYS7qyh3LZ2hgT5a9DgqemDmuq8S6Udd0RrmwllS7iieSLJCo4eOPaGxwNu1FJz8o3E56VxXh6Ya6DqHnpDqbGNPNMzKrsqgI3mEg42gAsAwIUcHk1k9zBt3PQPjR8+oaWdjzvHaPJ8oHzZkUf0/lXKaVbfb/EcTy2DysizkGbeFADRnd9QBkBhtB68Vvy6JcayimSe4uLyIJGk9yABsDK5C5J3DLMehJHAKgc4ZuNV8P63DOuzVLYElLi2SRHhfjCoSMMMrwWJGVxznFC7ie9z1S60U6v4cezW3tFZomMSvMWVyrHA4wSOdrDPQkdK5PwNqkraddWVxMY9RjLRyQI6yqUwpw43HL4K5POMtnrXouk2kcthbySyeeTukGDwwy3YexB4xzXm2q6euj+NZTZqojmPmxqd5lCsrN8q7duA3mD5u7DPArTrct90UvF3gmx0oza7p1vJ/ZrOHmtGBVIGP3mxnAUNhvQM3SsrSdWuYLlWgu9lrEwkC7AzkMPugkHKkgsCRg9ge3qpuEW5WeY+baMGSZDuIZQMHHb+7jOSckDmvNfEHhp9A1lo/MX+x5cG1uSxKoWJOwkDPLbiVOcHHY8NrXQzatqbXh/U47e38+5lW9YhjLyRuUqGy/PXvgc/L2rWnjGo6Jd2V5O8FrPbyB7uCUwRojqOrqAV3EcGPbtPIYMcVytpcfY54AqLbBmBEUzbll5OMBvvAkHoPWtPSL+a7jvyIdksR+y+WQx2x5DOm45DAk8YXd8vHAotfcSm4tNOzRjP8K4LHxNbeKdQ8WaxqeuWGntFpc2sfZ/s9i0qeUJTDCkCySDeQCXJZTgAMFK5uvWuv8AxH1m+8J6X4gupY4TEdZ1qzmFsmjODmO3svKRJGklyCwkaQQjBcvuCt6S32S8N7pE0RvtPuvKtpoJ4i6zxOCpEm4EFMfLgqobjvmuVutR8L/Anw7oguVmbTbjVl0u0WGCSa4M8spdYyqgZTq5ZiZH2ZbzXbLefUw8IXbdobyd3r019e+/RdGvs8DmmIxLilH2ldWjTioRtHeV1Zacru+VWi3Jyldc0Zdtouiw6VNYWNqZLptPDBWnd3dQy8eYSx3vjC72ZiepPSpLeF7SaWUCaOII0rsVKpFKMBtoHXIDck8jJ5qjYeFm0fWdb8QNq2o3r6sbZ/s17N5tnbIilQlqrKAm/cpbGQWCEY6CpbeNY9Q8c3nhCKzna5g0+PUFu441niCs3l/v2dsxzb/NxGw5WPcGJyi96moJKWl3Zfp96Pmvq067nKg+flipSe1tubfe0na/XfY6HThbXfkPBsUylXiYDc8SjJGAueSefmJJzgjHTS0f7U1kIljlEkfDmRhEmRxk7cu2cE56enSs21SZma0dmBgRIwrMgXaBkKzAYxxjoenXPS1PPBHJaBfs8wChWaWcnPGQMAAdsgD34rpavoedzLcnks4NDubCGR0FpK4Ro1XZmQtlfcr1+X159q+ftFFv/Y9hiRFHkR8bhx8or6Ea3e5R0LrEXyNtrbMQDkYbOOoxn07188aCsn9h6d8sv/HtH1k5+6P9qs5Ri/iYeiPUfhrdNF4fu/3zNImp6gqxlGbj7dPlV9zgdRycdhXTTWxaa3NwiSXDSbirl1GBnjO0DCjaffH0rlfBi+R4fFwsLSyR6xqWMxFtg+3T5bqBjBx25Jwa7EW0sb8IJLl1zt8lmWMHoQQ33c546kn8tF8KaBr3mOuYlXk208nmOcIrsd5I4xweOOvbk1mys8beTPczIkQD/ZWQvukYkgj7pZQccHnLDOMZqxp4jktwq27y3A/d52lkiUHBbg56846k8dBTcCO5C2YklhcbmW5cjOSN8zZYcYOAOOmR0pr3dBPWzG3Uc09rJFLPAqyo7TefCWVe+NxIJPUcY9R2rnr7S7ht0I063urk4keNGKi3XO4BWB5kPY46/hnev7pEtJbmfTXS2gDNh/LIf5gGkb5skryffd9azo1hmllgJNhCn74qzoTGN3zFnzksxycZHb7wPInpdDa1MzXLl0kvleyvpi6GT/RJwuNw2qoI3fOQmN2BgHr1FZEeqhLa1dHeON1acrcYZjEuw4AZcDrwTj1zxiuos1uY762uhIbiEL5M0c4LBST+8AIXLDBHI4GSucCrDa7puq3r219pqeU0a4yAyAbfu7WUY+8SPUc9MVLfcSTMpTc3OmTGVkt5Z7d0DImDGSPkycqcY528YyATnmotF0VtHtnlkiBmMYVYc5ZQSExnqRnJ5wRu2lsnnqY00WK8T7Hp6I6kBRDbYOMjc2SPm5O3H1qxNrsV/fyWUcUivbOPNUHGNw4BOfRlOM5rM1SMvSjb6LZ3Ou6tbzQmVUCB03FQe2BkqWZgCPRF9M1HFBArRXV9KJb+ciSNHUoIdvUA9TzwD0yM4z0k1K8bxHJbQS7IPJmLBQzIdyp8wyR15xu5HJqG71zT11TTLKe8CqVGEljYKxGGG1umCQOo6n3pdfUpCzRxT2ivcahIk6OLphK2DIcKAhDDOOWAAHNeS60JbbV4bm5uC+o3bea0ByXgiAOEY8LhQcZ5xnpXoLafD4k8VahbPJc20BKu0qyneGZn3KDjKrhAeCPwFWtb+Hen3sE9xbfatO8x1Rri2kYEJu+6wcHK5YEgdlA6ZFZ6sdnLYz/FV95Hw3k1KeS3hupb8OLgNsLqZC2RwTzt6c5waxfBXiuJLu5ZNPkv4tyrMYV+WJhyz5xjqBnjqRzmu+1Pwxp93YWEGpXDLpsLjy422QQXEmMKsgU7pBnovHU5zXM6z4ov9FvLOw0iC4u0jbZDtPkpEqgZ3KOAozgA4wQM8HBOty7PuTt4q0XS7+1W+nInjjCEYYgMSVKDPyhhtU+/rTlvYNV02bULS9KWUWXhZMiQjyyQ7bgeHJx+Z5IFYWgWVpa+HVj1Bk1jUo2MxEDB3eRyZGcseEwScuDk+nOK4HSLmWfV3OoX6WulzR5SV496RZGTGnc9c9hnkg0ar1DmZ7z8lrMrWkrxTiQvLLtyAxUK4LMcEjAfJYE7enPKxaZZmS4tbjUWZd3m7VXeIhnA2nHUleSOpYAdK8v1Ow1K2T+zk1K8dLMfuo41JAgDEKOGzlThv8BzXQaX8T7RtKWeV/NW3KsZI4PLl3Mw3kIBgjIPUcEZpXHzdzq72NYdPjjMMo2SFd0Lk+WyYJ3Kw55+Y8DAHFNgVzJM0l8saYaRsQqERlQbjtAwAr7+CQcjjrUVx5WHvI79DAiF47u7YEORj963zYHDEZOCOc9cUthpdzc27XuoQpb6fBHmK0kUvuCYYXMjKxyDtyExk8FiaY35GBqd9e61Bf6elrJc2FzbSmOa2GwwrGCgcggFXbayqoJODnNWNM8NXGq6tcXt6yPEHh220cflhxEgQEtk/wB7dnvtx7U4x3V1cSSyB1mdl8xon2PJHgty5xxjqecEEAdq6HTYruGCdZ7NbmO4CSecny+WjZZRj7wIY5Oe2Pwcbis2U9Ss5b7TNVihurhkWI2+SNjhpHCkH5eNq4J79CcVjeMfDltpmi6QLawdLthb2aXIl/frEvmPtZMgHGSM4yu84IwK19QnjawurOxgbWBbASO+0JN5zSBm3Lgc9TnGOR2ql4mkjv8AU4L9pfJ1S5WSHTob0fuYdqsdzKG6HHODk7h2zSsxSWlznPHUl8tlptjZ3xW6mfbcJJ80gYR5STAAOV2Y+8CcqTyMGdiv2D7Da2Ugvbm0CG6VC8MEhAVQCcEgBRnPBII7VDovgHUtOYaw17Z65qF9L5skhfYsfBPRSRgABQqjC561L4X1K+vby7t7otZrHctAzwlmiCBlCDZnGWAztB+XJxnpRbQzZ1PgO8vLmzj0m7ktpbi0Iki+zuCPlYhweQTg4HAxyvHNUvitZRWcenXMOXuJ5fLWczGNQryKCrY4f75x3GCR3rO07SLzwt8Q7O4XTohHeSyIk1uEAZCgPzdxnvx34HamfF3WHv8AVrO0tbhrUxXEDb3XDgBkmYoMZwcICWx1wvQ076BfTU0vBbNq9i9v5qNtV1LwnKqeWUgEgnBIOeeQDxurob/TotZ0m+0tiv7yINHJIgwyEH5cBuOuG6feY1zPgySCC4lj+3TP8zyRGVg3bBUEnAB3AYGABtA9uo0qCKO7F24tJWHy+YmzAUn5m+8cZ5HB5AJwad+oR2PNLK3+xzSabNdzNdWjcSrGkplU9GAwBuwxDbc5KsOgNa9qZLoXdsYhLfRxBoJYQD5YBBVwWIwf4efUDmpfiVpdnpmpAxx+TE4eI7WZDH5hJJGO2/AwB1mJqnYP9rEEO4ZVsBNwxIwyFPUEHDcbic8D2oW5j5M2o7sanaST7W+3xbJJFEQ2Nc7irD3U4ztGfuj0NbcUf260uh5fmFnFzKscR3XCD7wQlsnB4B45XBxzXO2EymOFl2297bxCFo5Ax3tlm2kKCQCTwQQVIPStgjfLPcBIbdwQJdsu2STGCQzKeXXHUMSwz3GK0W41puc9428Va54evYbDS9ItozfzRwQ6/cENbWMk275p4wQwLYRUUFhJKwjJiJjL7PgvwVpXwp0CXS4XW2sUEl5c6hqDo91cyH55byeRuHc8Fm5wF2jCgAbpFqjwvJBZ262kDmfnsR90KBz93njuODxXDX2iaj4bu/EviGx0a88T61rdzarbwWt+gkjtobYCJHNxJEsCGbzyQm5m81ick7U5JxcKntJa/K9lboktbux9Hh6yxWF+pQtT2b1SVSXMkuZyaUeWLk09lrortl/TtSutF1LQtK8V6zpVx4yuLV7ue30u2WOLyxKqsIlcEiNWkUCRjuYhiABuC9/dJcraeYJZi6ESA/ugU7HhRzgZ7881518J/A9j4R8LW1uln4ftfEMqp/aE2k6PHbpLMCW2gxpEHRQzhQVyFI3ZJLN3OjxSS2qxz7YzsICrZkttzwcnkdxzzxXTQU1TXtFZr5v5vqzzcylQeLmsM7xu9Ukk3feMV8Mey1010vZXLSbzI4xdysZFYCQS3gXBBGThQAR0PTGDXzzoWwaHp3zY/wBHj43f7I/2a960lvsd2LREldkbB2wjhsjplR8uAD7EEV4F4ekZtA0w7ZBm1iPM4z9we9OejOGD01PTvCLxxeGbxIzEJG1fU2Z97K3/AB+z8deTjPToPciuuVIkjMUcsbW8ePMm8xvMkI42DHU5yOOnQVzfguRv7MmgmmMcC63qchYKQVAu5ckEZ9cYPrnsBXQ6qktzbeUJ1ZcBEgEKmSNSQC2MgbsHAGOpHoauGsYozldykRQCPyYXu4LUyZZc7MSTMf4AeflGMHnBC9cdWLZ21+ZZmeBfMBUwsA0cpUNlcf3AOh6EgnB6VchnLzoZZkV5MQuBlfsyn+BM98DJOPfoBS6ki3Vs8Fo6pbMSi4wVeU9l9AOScHnJHrVtgloZ0lzPEoPmq0R+feELbVGFD4ycEgthcZPJIFVZJrGMtHOkK3Em9Gic7VbnHLlflaQgZzweeu2pXvbkxz7kinDSuFkVVIdAceb3AKk8AjHzckk1GJor+WO2j8xPJUeTG4ZZgSSAocHcFcqOWXOOvJC1OysO99SC00toLS4uIL8W9lIpQExAL8qn5sY5UDgHGDt53FsVa0+JLOzku/LExhYD7Q23cSqJwFbLL8w5Azjp2q5cwmySGGG5C2tsuwGQ4WaU/MRjAwo2huPXA7imXrO+j2X2e2mjhzsVEkBkKgn58NjJHfnOenSpfvadxpJalqOQz6dJfXQEx2ttUdd4dsAHPQcDtnrnnFZsMMVop2q8s7SrIx3EJ5pUbieRnapUAHHXjNX7S5gtYorVIHEManaptWSN2bG0HI5ySBx+lWdJ03zAFaKGSGJWRsxAGWUn5m7/AKnvWbVrmq1seI/Fj4p+I/hx4isbuw0axvdD8to3kub4/wBo3k3J8uzto0d3VBEFkYoM+ar5CI7Vynhrxx4l8YWVx4g1HT9H1DVtO02S1t08J3y3Q1HYGeNon4WNWLBQjZOclsDArr/i/wDAtviFr63ieHvCpl8uOC51C+QLcuUAKKG8lyVTaB8rKCJXDDGCIvhx8GNQ8IeE9agYaf4c168E0Kan4Rtkizl3k3r5sfyeWHMcYbdsUA5JBoWraIaucT4f/aE1dNUu54dDubW7stTi0a9tLom4ni8q2DXARVlJkZbmV0+4Bsj3HkV0vjX9q+bQtc1Kyt/DTajHaeG5NajN9MkLXTKyL8oLhljyHUsInORkDaCa50/s/wCu+HNQl8TWuo+H7NrOJ5F8NwWE8tusxg8p7xLkyiWW8kiyryuMHJJUOxYweLPgOniHULvxGTaQ6nqVtHa3j6yC9z5Ec0ChYmbJi3RebEApAzcSHB3czrszRO2x0mifETxB4i066vL+1iW4tL7UtOaC1lAEjW1yIo0WWdlRC4QgbsfMcZGTnJ0T4z+IdV8Q2Ojah4UFktq8kepy2tzbOHuZSHtDGBcuzp9mfzH+9tb5BnZW98PfDGuad4C8Y6ffTaDd6Zc6he32m6XqMDtZyNNO8sqXeQTOuWXaEUcKDnJwtXQv2T7bwt4iXXdM/wCEcutauLuOXXI77QohZ3O3a6NYwxEPYvGvyoUdt+0GQMx30OL6lpNo0r/VNe165UWGhTbkK7okQ5XjcpklB2ksELAemBnkGvG/jp4z1D4UaL4buRHJpLaneizj1m6itHs7T9zJKsI+0ahZeS7LExBeTHyFSMsmfsuW3gs7pU1CSKBmJY26SfO6MyhmOeTyM8e4ya8N/aX0TVdbsPD9l4X8MX2oTW2pvf297pZ8ia0l8mSFDuj1fTZUDx3Eqhllddu8OgypptD5O585fBH9ou48Y/EXwhbprmsXGt6rf3+jzaLod14efTNkZuVW4WJLuW+ijEEJndzLIrPkRtJG8av6nr1z8Q9S0iLxZ4XsfCHh3R7PxXPoK3us61dNPqLLqsml7JYYtMcxedMQVKTEIWRnJUSK3K/s9/Cz4jeEPHvh8eMvBHiW8trPXdTvkMl+9wlt9rkul+0/vPE00SkR3bmRhayyYaQb5ZGMzdDqn7P1v8VNAh0LXPCXh/StWS51jX08Q6nptpqV4v2y+1G7sNPRdrBhbzXMNxOBL5MhiMKm4inmKZ22BxR3nibWvGfws8Lpqfin/hX/AIct7y9eBX1j4gT2NopaFdgjkk0zZJI+2dijx8eWCC+WC8l8If2sPE3xB0/Q/Di6r8MdT1eTVrrTZZdO8ciTVLmG3upYvtQs47ALJmGHztyGNJVIdUgRgidN4c+H+rrL4Lm0jwRoHwyj8NeJJ9V1PQ9Ntbe2tpXk0i6tDdQm3LBona4jUNMkUuyIl0QhVLfD/gzxTp974DGp2mk6fZ6B448S+JLuSS6Z52huptXFqkSIjiQSrfrIWcxlFTlWOQj5Wxpdi7rGuaxrGr+NLXwz4ltdHur2KXwr4RmvLRWgfX1tL67vZVkjidTAgWCNi+4LNp91HsDDElXxl+02+kaJ4L1jRrrwvo1rr9lPcTyeOvFkegvaTwtAHsmTy53knR5Zo5EAxEYnR23FBTn8O/E6LxLq1xpPhHwVY6fp+ky+G/C7WPiKfT30iwl8osUt/wCy50+0O9vC2198Ua28SImBK89TxR4e8SX/AMIP+Ee13wbLpPjvxA7prtx4V1bToNOWWCVI1muGu8ma1uYYIg8Zt7p1tiYpI2YBXrVIDgPgp+1VfeKPD/ga3v7z4ZazqesXViskcPj+GPW9lzKqgy2jWaI9zFHLmWJHTzJEkEaLuWMcJrfi74leKPE3i+9i1XxXdfZtd1fS7R7Kwu5YoraC/uIIoo2i8MXiYCIAdt0+SCWKtlV+j9Jh8eWPxI0vV/FA07xXdWOlLpEmrWExt/7JWVopriOSHykW6aYwW6tdx+WC6xCOzt0EznxOw+AmvXmq6x4u1zw94G1C1ura7ntdI8U+GYfEN/AZNW1XUVhG67toYZWW/ijJErROy8uAis6s3sLyO1+GXxqsvD3wQhufEmt3t54qs9Ru9OupdRtbjSdPtJTMktut9eT2VtFaqtvd2e6V4UMp3eTHNJtjbo/hf8V9BPjiDwsfH+i/FJdRw633hRkvXWZ9qSJdWts8zQwBpf3dy37tUPl3EgkRZbnyzwh8LfFvh34R+EtP0Ow1VTeeJLSeWwm16fQppNOtvDkenbrqfTnmeIvd2cUwhiebhogx4cp0+n2PjfwL4+8D6s+iXFhBbavMmpeT8UNZ177RC1jdpHDJaXyJFzO8DBgS6lVJULvZVZks7LUPiD4k8Oz/ABGa5MWrXuieOtC8N6Pp9wqm3toL0aSJsMm1mfN/M6lywVioIZRtrmfFfxP/AOEZt/iRY6l4istG1oa3b6Dp99qMtug0uCTTtLmn1CVmAR47a4vpJ8TMA7tBbBlaWJar6/aa1q9r4uS7nsdP17xH4u0XxLNaSz749JW0lsCbd50BSSYRaYu7Z+7WSXYJHVfMOppmgeO/DmmfEOPTlt7TXfEXiXzLLWBLDPFp8DaPZRC7dWY72je3kAhKku6oG2ROZVPUm8WzU8FfHLwpq/xuXTrX4haH4n8NXdgIrRNF1G3mOn3q3CLGJCrOwW6+0JEHYpGsltDEGaS6RW8ovvjF8YNb8QeKZ7HVPFyWtp4h1iwto9M0qdoI7aDUJ4Y4kMPha8Q7UjVS32qU5UklWyg9X+EPhq+sPiV4cuNL8K3nhzwn4U0G/wDD1lJqd1FMl1FLNYGFrcpNK2xI7BgfPMb/ALyP5WO/ZyB/Zb8Tavfa54v1Dw34D1mW+tbq5tNB8VeHYNfvYpJdY1fUTbxs17bwwSCPUbdHIldGkQ/MEjV3a7oFa1ju/hf4q1f4ifAFr3V9RfXPFej3t5purzXtlNa3KEsLy1idJrO1LyLbPZgyCBFfcxA5rqLGaJryK2eG2ubXnyZCg2RrtyvUlfphhjA/HA/Z1+FuqfC74K3ttq8Mscd7d6eLe2uHga4WK20rT9M8yUQSzxqXazmfbHNIAkiZIbcq7fhfw8Ld7Cz8mSa3vVinhScsE3MoI3gcYJAIORjkY+bFVuYTS5jp9Mkmvprhr2IW95FlN6uubnkDqu3bjJIGcjIyOa6fT7NYpLhhBDbXJVUllhYxvJtyScYyjYHTGT1Bz1yNN+zzyxadNK5lZZHt51Yea0uMMgU9OMDJyc5xjmtWzgW6FhPJEJb8nyskbhE65wCSM5HOGwB0PrVrYEaFqrSw3WoQEJPM7IYEgK+Zs4JKHLM4/wBoZPTBwKluriWN5bm2vlEU/wA06xxCV1A+VXjUEj1yGB/Aih7yKWSbUYFc27xt58UjKN2zA3spJYMhz90c9+1Kvn2n+lIsCWM0qs7vubByCZCBgEt3YdCc9Mihasb0HXKfYc3trdTy2uAJwA27AH3lOPTHT3z1OG3kkkl3FNBFdzx/dcqVTeWA57A5XAz9KvTwz2TLamZILG5JUNt3bWP8HIxg89fp3qtut9JUWlxdObFlCRHcrjbj7p4+n5jsa1i+trsi19NiOe3w1pdwW0oaR0AdpVIzx82VOeigEdxjuK+e/DlyzeHtLLJHuNrFnGcfcFfQNlbwyXz21wJ7hHkVopAF3E8kHd16Y5B/Wvnrw5CF8PaWF8vaLWID5V/uD2qJtLQai2e0eA4G8nVZd+JotZ1CKGPI+cm6kbkY4AyT+vYV0N1vhv1LzW6yjOLiZcKHyBxk8beMDpk/WsTwPA8trqmyKKV5dX1HbIzDdEounDHbjB5A79SPQY27OSP7MyRRyfZslpmDK4WIZIjHOeeSeO7etEdkN72CGdLgKiyhIkBdJw+SyHIeXnnJ5UdeuRnjBdwvGzTRAR7IWHlDAKxkBUj/AN5ic/gB0FQ3Fqt4z3iwx/KnzxOnEgJ/dxHbzngMeDyw4pzyz6SiK8KTN5oICyllWYrwpLDhRkEfQ1SXYSfdDbm6t/LdppFilj2ySbl2bWHKxgkcKo4zjgkH6UYhazymJpo5XBLSPBOeZCGMpwFxj5NoJ55Y+gO/LepZaZLEGHnKqqWcLtd3bbuyDjG45P5ViWGmJLeW8lo77IC0EXlzOp8pQuTuy2QWHAI5wOnJpW0bL6pEdxCDLO6TmcEsojlY/vIxhSNyg/KTgDjKgMR0ybWpm6trn7TKLd7to9m0sQUJY7SDg/KflYjPG33qtdabcRzPMlyxlj3ToJQCNqMdgx0BLdxjOSTwAKtakDZajFPPdFE2M3l7EQMVKgDcccqWPf5sggfKKfVC76Fi9mC6dF9mkQOHjZfMcKCANxDHn3JI4AI54NN02WeOy2tPbpdXTFygdSWznbuyDwQMkgHgHiqCzqsj288s15LEwVA0ZyA6gYA2g4OSPmHPHIzyTGSK2uHithZ7YQ3mkq5yoOSuMrkHIxgfePSs+V7FqS0ZNcxyTCa2gMxbG83IcHzVJYnqQOmQeOQB0wDVq8sIr5IgimSBFRkjgUBGTkbSxPIPPb0681xvib4reFPAd3DZeJPEmmw3ly8UEVtcX6RMDM2FzEzA4yoPmlflUNnGDWtYeMdB17SGvrDXrLVtMgKQSSaZdQzQwEHgNKGPKkrjk/w4BJot3KTGatDa6L4blsbSfzxKhQuuEJLDvIxwMhQDgg1n6d4R86zhh1KSa7EOY47VZcRONhyZJDySSWOB7A8AVkaR8RfDniXUtLXTLuC6vtSifUdNMWfJNsjJuLbiNrjzFyGCkl8djg1z4v8AgfTPF8+narrtpZaxLDCJYLt9gheRJim4n7p2QyjOMKV4BJBLtoWtTrdMsjaXk77IY7O22xbgo3hgOCiYwq7Mc8E461RtNGl1CcXUFyLYXLxySzxIMuqvtOw54G3cDn+6D2rM0jx/4Zl0a71uPU4L21tEjhu7maOVdjMqPFmIgMNyyxlMKWYMhxg5MOm/GbwFq2qQQaf4mtLvULhhFbsqSgM8sazwLvICIWAyFJBIOMc8zs9DRG7caS8c9zDa3X22TzBcQoSu6JWBITrjaMFlzg8ZG6rU/h8tNbT3V88Nvp4dUs1IO/eSC5c8tzyeB0yDmtrTbtbjUmNmht4nhCjzY+GKud2OePvjr9eledfFT4rH4RvoRtPBHjnxtHqlveyGHwtYx3a2Qt40kMU8jypsZuQiBi0rKyKC20GXpvuUTXcNxqd3C5uCl3bYjMcETAzy5y0hYfdygCg5IADdia2PDmiWwsHu7u78thODFGI9qn5QMKFOW3AEnnP0AxXz54M/bg+FuueL/DVtpQ1S+t9SOl6Yb+0gge0sbzU4p5bawusSFzORE4byVeOJ1CO6kOQum/t/fDK40fxP4id9bsNP0vSZNftLgWAcalZC/bThNaqJCRvu44023Igf94pKhC7KO3QlLW59KDWvsFwiXVo8lx/rZnOMlR8u4lsDZ8qgkHkjpzTzqpuglxIW33EwYysuURUIyo6FVIA+dsj5nIOOvn3h/wDaJ8GeJvCHjC61+C58N6v4RNwPEmi63bA3mlRxRtKWZITJvieFDJFLEZFkXlWZgwHm2m/t8fCC78H+KfGmrjU/D8Hh62siNH1SONr+9W9t/tNkIRFLJG5ljHCeZuj8tzII1DGjTsVse6ahrl4theT2KxJJcukNvH5ZlVsEKzseGIBJA6EnIzzisPVdFvb++W4uJUUzCC2b7TGpQRqTuOG+ZTnPI6jbkCs0/HuyT4TaN8RNG8I+J/FlpcaXZ6wNM8N6et5qBFwE2IYlfAZRMWdVZsBHOeM15v4h/bL8D6Z4L8U+IPE8d/4Mu/CesGyv9C1dYG1l5DF5lt9miWeRZVmEitHJuCSCOV8+XGzUNpbEPyPbBLfNf3rAtGpiVIvItQwtIhu2bycO7s2H2jgKVHpnAub06zaRLBpaXt7JHv8AtNrCWjLN0DFc9Cedw5IUDpxiah8VLfR/ggnxMsPCnijxTpmpabY6jbQWkIn1FobtIVRUtVk2M6rKhbBwPnIJKnPkvin9u7w3pF9PpOo6F4p0zxFpWo3323wZ5FpBeRW1pZG7mu+LjyzD5O5kfzP33WMSAZB5kWZ6jr2o3Gn+ILbTtXMulpsEZksCt00jZb5NgcCPIU/M/wAyll46GsjU75/FEpnttIENqgeSOe9/0i7kfb8u6QfeVQw+WMYXIzk8jz/xd+0/4RuLm2urrwX4qTwPPd6WsHja7sIrPSma/hR4Lmd3kVvKVTteQIRHkAjcUD9R8Df2kfA/xT1vS9GsE1eyg1GGe78P3msRfZ7XWFt7h0nNkyOX/clGZlk2TeW6yNGVzsPUhxdzvU8FS2zyz3UXmLaxxx747vZ0UnbgxknaT32gFgOBVyayt9QcRpE0UMCmIW7RICACRkrwmTyxOP0rgYP2v/h5rXxYl8IhbmztoL6/08+IL0RJpkk2nQRz6hGWRt+IEm3GaRUjZUfa7YBOx8Cfi7oX7RngzU/EXhhrq/0XS9Vn0e4mvY3gW6kiSOXzLdA24RMskZBlCOMnKAinqS422PRfCmnQSTy3VvPIP3iwthGRcA/MB1DHBYnBxgY7gjrbzWI7a0llikJjfbsxPjAD98zjqxyOhx8pxXz/APDD9rDSNW1q30DxT4Z8UfDSSfR7rXopPGlvBp6XEdlJ+/jBM+4yIu6V43VW8lDIcIVJ7n4C/tCeD/2m/Cmuap4MGoy2em6lPpQnvxJA928cUTGeJfMLGM+ahUMFZR1RabtoUk0j0ea3e/0FYt73An8mYAwsSU8wPj7xPGfUjgVz+laXajSbG3aWWRp4lUiUnyMLGpVumWOW4bkEjGcCut1K9MehmaKNMxSbxGxPmLgHJye+M4BwPQ1kQ6fHor6XJIhRokaIjB+dSmAoJC8DjqAPmPpTtdmTEsLa7Wzjfy4vPhuWjY4MflhWGFIACqTnJVeTkEd6ksxI1usqOrhbYyyqV3sUfO4kHlnPGM/3eQetWFWO2u2MTRhFCqJA5cJINpGedu7jpk4yPWrlrNZPfys18k8NziWLy5TvLI3zA45zkrwBxg980/QLdxt7NdRPOHnXZNAEUIDhWBVXfdjOGDqSR3HfFWEge1vYrWcyizmQiNyyqkb4AMR/iIwDgjHcGodEjsrNnt7qWOJUQvHHJKAwVnfhud3APAbOAfXNWXaxltJLbyUlnB8pWiiyWzyrAgcdPzU0JW0DzZFELCUXFrNG91FIpWGdUaQlP7gIB+6R2zng9aCJb2B7F7QGZPnWdlEXAI2tjGeOh47YwatkSX9iIRbyR3Vq4CuAoCOvRgN3QjnHofYVGsl/qSx3gRLWS3YoYV+ZiejqT07cD6eoqk7EvaxLtn1SFo5fLguoc9Qcg/njH+IPpXzH4cnlfw9pbbyc2sR5l5+4K+j9SjJjtdUFyZfLkBkjcKoKdxgDGQe57E89K+cdDB/sXT9pk2/Z48fIB/CKNwdlue3+D7hIdK1pUuNsj6xqTOjnAKi5k+UE8jOMfKT3OOtdJF9iuXIjuFby8S3Bgl4ZjghSoP4/QKO9YHgqaOLQtc3oRHJrepGVwwbCrcuOfTsvfGTXViwlYLayyJP0nmZos59A3POT3x0Woi/dRo78zMpI7mCSaRo7jaH80CJkY+ewzgggcjOOM8ntiprW4ktr2NbiN5ZEDltiqnmyNtyxBbqFPT0NJazyQoIppTGtqDNua3aTJYsVJIPUDHvzViG88u3ufNs3myPPLMm0Et2IcjpgDjgjGK0faxml2K9/cafNb3ZuIorQmEQgTbFOTjdyDjIJXvng1VcWY8iSCS6MKTJDAYxJgKmd53Y5GAw/CrqxSWktvG9lHI0MTzTKHGW3HBbGMcnecZ7dag0qLT4LqwxA3nR228qI3dt5wM8Ajpu56c+9EdFpcHdspXi6VDLK0ZaQSXCFQrBlK7QxZXY8EnP8XrUjwW8lg6RaYGxM0cTTH5M784Ln5gCQR8uevSrq3FwdPsnEdvYFTlBdEOXBzgBV9QeP5VRV4ntpY7m58y4hkLPEQSV+fO4lgFXPUHH41S13C1hlzHcq86vNa2R8xZWSIlnY4XDL36A85HfilmtAVQyCO6tlH+svnLKjL75wAeCQMknHHpJNbxwzQSJGlvHMxjLxqW38ZUbiC0h4YYUDOSM065tbyWeG3SaR5FXdH5jLvU4x82OEXnrksR6mjT0HqfOvx08BeL/E3xf8HS272WrWdnFdvZ6YkLWa27iFQ11NOJUfcfNkjRNwVV3HazOdrfBNvquv/s3eK4tT/tDfPq+oRwfZLKS9m8lLsxxpFGS0kiOF8tWDbwpLK643r9Fvbz2d6BM0KlI1YLF1IyQxyQAp3DqQSdxxzwUlNzbvuCrACN6tICXQk7exyob15Y8461Nk9upSPi7w7ol5ZeOPDd/4m8I3EBF8B4kge0fUNP0K6WeS5tYLZ1VgVmaeEEBjgKhk8tdorR/aA8J+K9d+LWt+LbTRv7U0jT7O10wQq0jvfTeReAYTyv3sga8iXMeY4yyckbin1vNeG00797mJ4yPMZn2si78jOMbE5wedzZ570y00W21HVnNhMtvJHDtFykQUspP3UUEbF+ZTnqdoPPWpcI21N4rSx83+EPCWq+Ffh7470GeSfUli1jToHlsBOUcxW2mxzNHLK7nMbAguCwQo2AAMVyXhDwH4h0P4uaTfX2gXdxFo2r6euoTWunNJFDJFYWcME0UwjVpUAWeKVt/lxsVkZQOB9j6XcrLHaI5SaeAvE29QsNspUleO5IwcDJ5wTSW087C1to4CtoUdY3KAPOpXDKFY4HIHLHkc470rJ9DVQuLbG9u2gkVhZovlrHIUDbCQY8EbvnXK4O7ByQe1eO/tHfCn4n/FOLR/Dfh++0u68IzzTnxTp17qU+lSX1qURo7WK7ht53SGVy6zbVWR0XYrIHkNetpp99L5UL3XltLCxSPdsc7ju+YgckMjEYxgnrzk2pbd5nk864a5mlhxG6/KvPMRwOM5DrnnkjkZqWjS19EfJFn+zD8Qbb4t3mtWep+C/B/hLxJqvhXUtX0XSLlrx7WLQ1cW2nWyG1iEiSvFZOZAITEQyBJFUl8TwV+xL8QvCfw/v/BOuav4L8ReH9C8O6l4Z8N6XrNpcSWepPfap9umvrzy/Kltzst7VFWKWYxSIsqNuQLJ9rT3lnfWUlnJeMJzsltZIvmmOcFAAOrDBXB6jk9TV211S4vNOGoPFE0AYl7dMl4QAQ2ScZZT1XA6dTxWfLYjlZ8keCP2SbnwV4H+KOnXg8M6HdfFKTUoNe1mLXL6/wD7Gikt3hsYojdqz6hM0k00ssrvbMXlcDcFVRl/Dj9kTxzo/wAJPiboOteIvD8mu6x4FtPCuj2GjyyT2sNvbWE8AeWZoY3YzXVxJMV8tjH8oDPwq/YNv/pOpz3cEcU8aMXit3kMZGVx52CMfMQRyOnI5JBiu9POmQG+julhvrxikxjcJBIWBAJz02KCQw5PJ5zina2g7HiVz4U+Kvw5/Z00LwP4Lk8JnxBaeENL0O18TXd1NLCmpAxW0irAtrh4hEZHjkZid6qHh2lifKfGf7D1747+CknhfUoLPwpf6LHqN7pbWviZtXj1/V7yB45tQ1mS50xN8wK5SVB5iiRxGYtkePsm2uZJJ4FWyBis1DxxWkwkVQVIDFm2jpuAUZ7nis66ZNYthLHP5d1e3CrHbNGpKI2Au7I3D5FzkEcnGTTUe4cuh88aV+z38XPAPwI8LeFfBvxXnm8b2miWsSafr9nYvoFtIkKRna6WH2kiIZaLezbmjj8xWUsp88uP2R/Hei6v4O1rwU/gzwn4p8InV44Z9S8S3OpXGp32o2UkMup3dzLpsZe5jmWGUKYpFl3Mm6FYkU/aF5qEQ16dtQRrE2dsqLdQEkBmOcK2MDIC4VuucEd6ozWt8mgWVvexxxS3UpuJbuF23woxDMSAOTggEZIx9KrluhNI+YLf9n/4l+GvEPhCW6s/C3xH8MfDzSNMsPC2kS6xc6U0N9b20ccuoXNqLK5E1zkEQ4k2xKxZF8xt4qfDX9kXWPhr8VLr4kDw94DfW/DFnd2ug6VoutanZW8kt1dSSSTtFJ9oTTUjtpplW0ijmjMtxM24AR7frO/guZ5IElu1eyhAY3tsDkR7TjeAfmHKcjgBie+Qt/Fex3MULCFo5yTLMHBikGAuSMYVyCQCflY4zzzTUVuQ1ofMnw3/AGaPF3gr4uaprieK9Fm+HFr4w1rx4tpHHJFf3d9f2ItYraRRFi3Fusl3iSOVxJvTMK5Gzt/gH8OfG/wQufHwMWk6k3i74jaj4jmD6lPE9vpdwYiTtFswkuUCkmNdqndzKuMV6/q93FDJNFG13FFCwlcxvsuQRkmLaR86leNx6Z6kchun2/2KCQRSB5pMsVkkKo7Dc3yN95GBYnGcHJK7gcC+RWM22j5h0n9mHx/4207xiPi3Jpcus+M7V7LWfGPhXxROL6y01HM0WmadayadsgtmZVSVGmJl82V3aRiFHe/sYfs5a/8As6eHfiDpN/rttc2mteKLnVNMsbRIlht4Gji8tmEdtEEmZQA6pmFRGnlqoLbvbC82oXsT3FrJi22t8jKZSPlILr0bHy9Mjj1NXbrUIobG5nSULgBPMgYmM5OPnjP3WOfx9ahw2RCl1LkGy50e0imhjs4zGoMUnKL0wpJ5POQc9Tj1qvpemrbwuJYniBHl7rZRgBTgDI5PQ9R0OOlSQWrWFpbxtNNaxonMsbK8J4IIZSOPUkAD3qLS7UC1dh58UAlkImtHID477RycnJ49OnSnZJOxLbbV0R26NNoQV7uC8uY1ZQJFG8Sg/L0OclgPwq5c2tzqWnG4ciC4RGeIW7Fir4wRk/Qrgep7imaZZo099sigvYNwAGADtKLwAeOTknOOTSW95a2QntWNzYHJZIlVmKAhSegYdT196HvoSvMuTbPsFre2ahFhCyhNoGYyPmXPY7efqopmoXwj8vUFiZIrdijyOwUGM8Fh14BwRkdAao6K32sz26X6m3gkO2NVBZlLMyq2Rxjpj259Ku6XHcSRXNpJKP8AR3aHDw53IRlDwR/CcfhSatuNO+yC5S4tr1b6G2TMgWGYGXhgThWPH8OfyNRmGfTtREj3JEFz/rAqgKJeOcHO3jH5U6ysZr2yltbi53JBI0O2NcbgD8pY8ngY446VHaWUt9YSQ3V9cGZMpICUADY4ONvtn86rTqLXoMS2gsPEYWd2aKeMEb8BVfcAQcADnPf1Ar5t0S2DaLYGOUbDbx7fn7bRivpHRorG80u2kR4RdAjLFyWLg4xknP8A+selfN/hyE3fh7S54wssctrE6ybR8wKAg9e9TJu9gVlq0ewX8qeDPF+q6RqMn2XTPEk4utI1CVtkC3TY8+zc5+8WUzICBv3yKMlMHs7myM0Aje3mE94xG9LgqwXnHfPCjritbWtD0/xJaT6VqtlBqOm3Ueya1uUDpIPQg18efFXx14j+GHxHufD3hvXdQstHt4mWK2muXudi/JwGlLMB7ZrNTaj6FzS37n1KWmgnmtHCxpJcL87RvKSgRTgnv2X6Ecd6L6S6lW5uIUkuQjoX3RiIFUYPtH8Q5J7HPeviq+/aB+IFjqFmYPEkyE+bn9xEc/XKc/dX8qoH9oT4hXkN6k/iWeVBNIuxoYiuOeMbMd6vnSV7GN9ND7meW5kW/nPmbym1lto8BAoOBuf0JJwB36VUeS7tI7b7JeNct8sPlwneGUDgtIcAHIPAwOa+Hz8efHjyyodfcRtCxaJbeFUPyjqoTB/Krcv7QfxBurtEl8RySRoEZUNtDtB+bnGzHYflVe0Wmn9WJTu3c+0NNvbW3tGRWSJlQecgYQpxwxaQEs30Bomntp2tyJEKBfI2LHtQq2eFiH7w8heW4P418XxftA/EC41NzL4ikk+zyDyt1vCQnyHp8nuaqzftAfEA2ol/4SSfznmKtKIYt5HPG7ZnHyjj2p86Wtgvc+3m0hrNYpZrqe2UHYzySI0keclWYjheQBhSc55JPNSzfabZrdoz9ni5KKXO9yRgsA33ByclvUHtz8V3nxx8bojyJrjRvFsZGS2hUqdyjOQlN/4Xz48NpZznxDKZnG9pDBFuZvUnZzS9o3Zsa8j7PZbqBradYpF8xnYI7rLKxOTuQMeuAPmYgAdAMVLEZ4WR1I+fLRSTqZH3YwSgyC7EFRubGBnHy18T2Hx58eT2tpNL4hlllY72eSCJiSOnJTp7dKIf2gfiDc6xeiXxLcSBUdAGiiIChumNvvz6981Ptbp6bGkHfU+0c2/9m6hLfRmWSAuHcQhkQlQ24sOpO4ZIJA6D1qtqU9zZavZytM9tbTwvbpOUxNKFZSisQcjdnAPB4JOM18bSfH3x9PcbZPEMjJ5I+Q28O3oR02Y6UkHx78fNeSFvEUz7WWFQ8MTAJs5UZTgHuO9HPdXN4zPte3ZptPttmLa8jYvBZ2yK0ihGIO9jkevpzjkmokubm9S0aEsdQS5liXzFKQQyHLc5GW5A4ByR6Hmvi3Tvj54/sYZPs/iSeIP5kjKsUWCxYEnG3Gajs/j/APEGGSYr4mufnEc7ZjjOXIHzcr14FRKaV3Y1VTTY+1Le3uNSe2eGRraWK5eAMzgpEc71AQe6gcmp4rCTUoo0uLiSNQ7QPgMDh8FQQT03ALgDsfrXxHYfH74gCS8P/CTXOWKSHMcZ+bcefu9aii+Ovj2W2Z38S3TPLF87FUy37wH+77fz9TS9rZ2sWpWbPtg3WnaVaYuvKhVXMUkaMWyp+V4weu5Www6fLj0Jp9jENQVjfQPFZbwJwWCC4c4KSzJxwQB07g5GK+LYvjb43i1KeVNelWTzlTcIYuFK8gfLxnv696ik+P3xBurKKOXxNdSI8Co4ZIzvX5eG+Xn7zdfU0c12g5uh9v3nl3FwYzcqtlFKVhncb0E2cmNz/cHIAOOe+VFUbe6treefWNlvY7AFisJOFkUjDOnYM5ACsByAM9ePi67+O/j2OO2jTxJcxqYDCdkcakpjoSFyanuPjT43+0yWh8R3bWsToywttKcEcEEYI56Hjp6ChTT6EuVkfYzWUjaWbeI3VnqmqyN9qSKEmPDfeI7fKg2gqfT14vskeq6sYZttgmmQ4i8j5ZixUg7SR90KO3HzcmviUfHDxzaXyXMHiGeGXyQMRxxqnzOpY7Au3JxycZNTH41eN57OeKTxHdukjyu2dud2TyDjI/Ch1FtYrnPsvfPbeHEhmVpU1KXJuFOWLE5IdTknhOoyMA5wKfPPcnV5jpZSbT7CDzv3mWDPyNinPC8HA9VOMcV8Y2Hxy8dyx6Vv8S3beTDujyE+U4Vcj5euGIz71cPxx8dl7pD4mvNrhgw+Xnhval7a3QhSvufXNra3cNtf3iynS76V1PkCUbApKgsp+7gMW45xjoDS3Vn/AGbbyxhYLC6uCkEcMB3xNCxALKSPmXLEspAxngj7x+Or341eOLq1QyeJb5iitMpDAEPu+9wOtSp8WvGLPk+Ir4FtjfLJjadpbK4+7yxPGOtUquuxDkfYGlzz6Sv21kwgDvFHJciXcG7gknIwFUMpLDncCMVGrrq2pXItlj85B5bW0MXMQJDSfKeCMFehXcRkc5r5APxW8XxC6KeIb5fK27AJOFwG6DoM7Rn15znJqxafF3xpFfSFPEuortkfAExwM7SR9PbpWntbRc7akOz0PsOG7itrVI7e6DSIxAWUsMP1ZhJgbTjPoR91gcirrTzT3Mck9rn7MfMaeNVSYEjAyozuHPUZU47Y4+J5vir4w2JIPEmpLIYmk3LcMDu2Bt2R/Fknnrg46cVYj+LHjIPtXxLqSASKVCXDLtJJzjHTOTnHXvSc1a9iPU+1pNSghQhXKMZNpktAyqe5DIOj4U9M1d06xtGs1a3laGUqPNkgcqd3csCMde5H86+Hrf4neLppYZH8Sao0ibir/an3DOM85z3NMuviT4subPzH8SaqXD53LeSKSdvfB56D8qettP6/AhO7ufbVlbwzXVzL5aX7B1Id2AmBAHQ8DGAOBipILq0t9QvBFfC2n+RniuvTB/vYPryOK+MtO8f+KLiKC2k8Sau8JUOVN9LncX653ZzyeaW08e+Jx5WfEust5oIffqMzbgOBnLe9Uk5X/r9Ab5bJH2P5jL4hV3tRcpd2pz5MqugCMMNhiOofGeelMQImu/vrSe0gltgdpkPzMpPOEJyME8e3SvkeHxPrlsxlh1/WIXcNuMepTrnG7HR6vN4t8QvIjnxJrZZHIU/2pccA4/263VKb7bd2QnZan1fmws9XXbOsUMyhdolKbXA47jnA7+tRSvp415hNIr2k0O/MsjMvmAkHg8fdH+c18wP4n12SJXbxFrZZGypOqXHB2j/b9z+daWmatq2pahBHceINddNiHC6xdLyTz0kHoKXsqittt3/4ApTSk128v+Cez+P/ABdPot+/h3w/tv8AxXrEDLYWkRX/AENTgNeTED93DFuLZbG4lEXLHjrvDfgrRfC/h3S9Gt7JJYNOtYrOOSUjeyxoEBb3IHNM8G+BdB8ErcR6Np0do16TNdzlmknuZAwAaWVyXkIHALMcDgV1Q6CuO7Z1wimrn//Z';
				
				parameters += "&servcard=" + this.servcard;
				parameters += "&servcardData=" + servcardData;
				// c00311908 将证件信息存起来
				$Page.servcard_upload = this.servcard;
				$Page.servcardData_upload = servcardData;
			}
			else
			{
				if (this.servcard && "" != this.servcard && "null" != this.servcard) {	
					var imgPath = this.getCardPicPath("serv");
					var servcardData = getBase64OfImage(imgPath);
					if(servcardData==null || servcardData =="")
					{
						isMultiCardReader = false ;
						var fso = new ActiveXObject("Scripting.FileSystemObject");
						var tmpfolder = fso.GetSpecialFolder(2);
						var idCardPath = tmpfolder.Path + "//servimage.jpg";
						servcardData = getBase64OfImage(idCardPath);
					}
					parameters += "&servcard=" + this.servcard;
					parameters += "&servcardData=" + servcardData;
					// c00311908 将证件信息存起来
					$Page.servcard_upload = this.servcard;
					$Page.servcardData_upload = servcardData;
				}
			}
			
			$Page.delegcard_upload = null;
			$Page.delegcardData_upload = null;
			if (this.delegcard && "" != this.delegcard && "null" != this.delegcard) {		
				var imgPath = this.getCardPicPath("delegate");
				var delegcardData = getBase64OfImage(imgPath);
				if(delegcardData==null || delegcardData =="")
				{
					isMultiCardReader = false ;
					var fso = new ActiveXObject("Scripting.FileSystemObject");
					var tmpfolder = fso.GetSpecialFolder(2);
					var idCardPath = tmpfolder.Path + "//delegimge.jpg";
					delegcardData = getBase64OfImage(idCardPath);				
				}
				parameters += "&delegcard=" + this.delegcard;
				parameters += "&delegcardData=" + delegcardData;
				// c00311908 将证件信息存起来
				$Page.delegcard_upload = this.delegcard;
				$Page.delegcardData_upload = delegcardData;
			}
			
			$Page.newservcard_upload = null;
			$Page.newservcardData_upload = null;
			if (this.newservcard && "" != this.newservcard && "null" != this.newservcard) {	
				var imgPath = this.getCardPicPath("newserv");
				var newservcardData = getBase64OfImage(imgPath);
				if(newservcardData==null || newservcardData =="")
				{
					isMultiCardReader = false ;
					var fso = new ActiveXObject("Scripting.FileSystemObject");
					var tmpfolder = fso.GetSpecialFolder(2);
					var idCardPath = tmpfolder.Path + "//newservimge.jpg";
					newservcardData = getBase64OfImage(idCardPath);
				}
				parameters += "&newservcard=" + this.newservcard;
				parameters += "&newservcardData=" + newservcardData;
				// c00311908 将证件信息存起来
				$Page.newservcard_upload = this.newservcard;
				$Page.newservcardData_upload = newservcardData;
			}
			$Page.newdelegcard_upload = null;
			$Page.newdelegcardData_upload = null;
			if (this.newdelegcard && "" != this.newdelegcard && "null" != this.newdelegcard) {	
				var imgPath = this.getCardPicPath("newdelegate");
				var newdelegcardData = getBase64OfImage(imgPath);
				if(newdelegcardData==null || newdelegcardData =="")
				{
					isMultiCardReader = false ;
					var fso = new ActiveXObject("Scripting.FileSystemObject");
					var tmpfolder = fso.GetSpecialFolder(2);
					var idCardPath = tmpfolder.Path + "//delegimge.jpg";
					newdelegcardData = getBase64OfImage(idCardPath);
				}
				parameters += "&newdelegcard=" + this.newdelegcard;
				parameters += "&newdelegcardData=" + newdelegcardData;
				// c00311908 将证件信息存起来
				$Page.newdelegcard_upload = this.newdelegcard;
				$Page.newdelegcardData_upload = newdelegcardData;
			}
			parameters += "&isMultiCardReader=" + isMultiCardReader;
			parameters += "&formNums=" + this.formNums;
			parameters += "&serviceNumber=" + this.serviceNumber;
		} catch (e) {
		}

		try {
			if (this.cardImages != null) {
				var cardObj = this.splitHash(this.cardImages.serv.hash,
						this.cardImages.serv.path);
				parameters += "&cardHash3serv=" + cardObj.hash;
				parameters = this.addReqParams(parameters, "cardBase64serv",
						cardObj.image, true);

				cardObj = this.splitHash(this.cardImages.delegate.hash,
						this.cardImages.delegate.path);
				parameters += "&cardHash3delegate=" + cardObj.hash;
				parameters = this.addReqParams(parameters,
						"cardBase64delegate", cardObj.image, true);

				cardObj = this.splitHash(this.cardImages.newserv.hash,
						this.cardImages.newserv.path);
				parameters += "&cardHash3newserv=" + cardObj.hash;
				parameters = this.addReqParams(parameters, "cardBase64newserv",
						cardObj.image, true);

				cardObj = this.splitHash(this.cardImages.newdelegate.hash,
						this.cardImages.newdelegate.path);
				parameters += "&cardHash3newdelegate=" + cardObj.hash;
				parameters = this.addReqParams(parameters,
						"cardBase64newdelegate", cardObj.image, true);
			}

			/*-- add begin l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/
			if (this.memberCardImages != null) {
				var cardObj = this.splitHash(
						this.memberCardImages.memberCertA.hash,
						this.memberCardImages.memberCertA.path);
				parameters += "&memberCardAHash=" + cardObj.hash;
				parameters = this.addReqParams(parameters, "memberCardABase64",
						cardObj.image, true);

				cardObj = this.splitHash(
						this.memberCardImages.memberCertB.hash,
						this.memberCardImages.memberCertB.path);
				parameters += "&memberCardBHash=" + cardObj.hash;
				parameters = this.addReqParams(parameters, "memberCardBBase64",
						cardObj.image, true);

				cardObj = this.splitHash(
						this.memberCardImages.memberCertC.hash,
						this.memberCardImages.memberCertC.path);
				parameters += "&memberCardCHash=" + cardObj.hash;
				parameters = this.addReqParams(parameters, "memberCardCBase64",
						cardObj.image, true);

				cardObj = this.splitHash(
						this.memberCardImages.memberCertD.hash,
						this.memberCardImages.memberCertD.path);
				parameters += "&memberCardDHash=" + cardObj.hash;
				parameters = this.addReqParams(parameters, "memberCardDBase64",
						cardObj.image, true);

			}
			/*-- add end l00227362 2014-05-08 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2 --*/

			/*-- add begin l00201782 2013-07-02 R003C13LG0501 OR_huawei_201307_23--*/

			if (typeof signInfo != 'undefined') {
				/*
				 * if (signInfo == "0") { if (province == 'HUB') {
				 * printNormalReceipt(); } return; } else
				 */
				//将控件从页面移到portal后，电子免填单签名点击确定，回调函数没有被调用到，需要这里再次处理一次
				if (signInfo == "") {
					try {
						try{
						signInfo = CreatePDF.obtainDBScreenOCX()
								.GetSignatureValue(2, signImgPath, 1);
						}catch (e) {
							//宁夏的控件 我认为这地方无用
							signInfo = document.getElementById("ControlObj")
										.GetSignatureValue(2, signImgPath, 1);
						}
						var vectorsign = "VECTORSIGN=1.0;";
						var generalsign = "GENERALSIGN=1.0;";
						if (vectorsign == signInfo.substr(0, vectorsign.length)) {
							var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
							xmlDoc.async = false;
							xmlDoc.loadXML(signInfo
									.substring(vectorsign.length));
							var apNode = xmlDoc.getElementsByTagName("ap");
							signInfo = vectorsign
									+ apNode[0].childNodes[0].nodeValue;
						} else if (signInfo
								&& signInfo != "0"
								&& generalsign != signInfo.substr(0,
										generalsign.length)) {
							signInfo = generalsign + signInfo;
						}
					} catch (e) {
						signInfo = "";
					}
				}				
				
				if (signInfo != "") 
				{
					parameters = this.addReqParams(parameters, "signInfo",
							signInfo, true);
				}
			}

			/*-- add begin l00201782 2014-06-25 R003C14LG0601 OR_huawei_201405_1051 --*/
			/*
			 * if (photoInfo) { parameters = this.addReqParams(parameters,
			 * "photoInfo", photoInfo, true); }
			 */
			/*-- add end l00201782 2014-06-25 R003C14LG0601 OR_huawei_201405_1051 --*/
		} catch (e) {
			if (e.message != "CommitSubPackEx") {
				throw e;
			}
			if (confirm('电子${billFormName}保存失败（子包）。点击“确定”再次尝试保存？')) {
				return this.doEinvoice();
			} else {
				/*--add begin jKF10813 2013-08-10 R003C13LG0701 OR_JS_201307_1061--*/
				if ("true" == "${logDebug}") {
					var errorReason = e.errorDetail;
					var paramsSize = e.paramLength;
					var elecMode = this.obtainTopWin().middleFrame.leftFrame.cutomerInfo.document.all.elecMode.value;
					var params = "recData=FailReason:" + errorReason
							+ ";PackSize:" + paramsSize;
					params = params + "&clientInfo=TabletMode:"
							+ (this.hasPad4Sign ? "1" : "0");
					params = params + ";DoubleScreen:"
							+ (elecMode == "singleScreenMode" ? "0" : "1");
					params = params + "&formNum=" + this.serialNo;
					// 成功页面调用
					$("#commonSuccessViewDiv").trigger({
						type : 'recordEInvoiceExceptionLog',
						parameters : params + ''
					});
					// 提交页面调用
					$("#balanceCommitDiv").trigger({
						type : 'recordEInvoiceExceptionLog',
						parameters : params + ''
					});
					// 免填单打印池调用
					$("#receiptView").trigger({
						type : 'recordEInvoiceExceptionLog',
						parameters : params + ''
					});

				}
				/*--add end jKF10813 2013-08-10 R003C13LG0701 OR_JS_201307_1061--*/

				return true;
			}
		}
		/*-- add end l00201782 2013-07-02 R003C13LG0501 OR_huawei_201307_23--*/

		/*--add begin s00227425 2013-05-14 R003C13L04n01 OR_JS_201303_824 --*/
		if ("${useTTTempType}" == "true") {
			parameters += "&useTTTempType=" + "true";
		}
		/*--add end s00227425 2013-05-14 R003C13L04n01 OR_JS_201303_824 --*/

		// this.callParentFunc("MSG", "保存电子${billFormName}中...");
		/*-- add begin qWX161270 2013-2-6 R003C13L02n01 OR_HUB_201301_500 无纸化营业厅专题-支持多功能证机具优化--*/
		var winObj = this.win;
		if (winObj.sourceWindow) {
			winObj = winObj.sourceWindow;
		}
		/*-- add end qWX161270 2013-2-6 R003C13L02n01 OR_HUB_201301_500 无纸化营业厅专题-支持多功能证机具优化--*/

		/*--add begin jKF10813 2013-08-10 R003C13LG0701 OR_JS_201307_1061--*/
		this.parameters = parameters;
		/*--add end jKF10813 2013-08-10 R003C13LG0701 OR_JS_201307_1061--*/

		/*
		 * // 成功页面调用 $("#commonSuccessViewDiv").trigger({ type :
		 * 'eInvoiceCreatePdf', parameters : parameters + '' }); // 提交页面调用
		 * $("#balanceCommitDiv").trigger({ type : 'eInvoiceCreatePdf',
		 * parameters : parameters + '' }); // 免填单打印池调用
		 * $("#receiptView").trigger({ type : 'eInvoiceCreatePdf', parameters :
		 * parameters + '' });
		 */

		return true;
	},
	
	// 获取图片路径
	getCardPicPath: function(kind)
	{
		debugger;
		var imgFolder = "C:\\temp\\certifications\\00000000000\\"+window._ysp_top.certImageDirectory.directory + "\\";
		var imgPath = imgFolder + window._ysp_top.certImageDirectory.timestamp + "new"+kind+"card.jpg";
		if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
		{
			imgPath = imgFolder + window._ysp_top.certImageDirectory.timestamp + "new" + kind + "card_"+window._ysp_top.serviceNumberForCardName+".jpg";
		}
		return imgPath;
	},
	
	/*-- 拆包 --*/
	addReqParams : function(curParams, pName, pValue, discerptible) {
		debugger;
		var retParams = curParams;
		if (retParams != "") {
			retParams = retParams + "&";
		}
		var encodedPValue = pValue;
		if (/* ${not empty postPackMaxSize} */true) {
			if (discerptible) {
				var pValueLen = pValue.length;
				var expectTotalLen = curParams.length + pValueLen;
				var packMaxLen = parseInt("${postPackMaxSize }") * 1024;
				if (expectTotalLen > packMaxLen && pValueLen > 0) {
					var dummyParamKey = pName + Math.random();
					var pValueTmp = pValue;
					for ( var i = 0; pValueTmp != ""; i++) {
						var tmpLength = (pValueTmp.length >= packMaxLen ? packMaxLen
								: pValueTmp.length);
						var splitData = pValueTmp.substring(0, tmpLength);
						pValueTmp = pValueTmp.substring(tmpLength);
						var encodedSplitData = splitData;
						var splitReqParams = "DummyParamKey=" + dummyParamKey
								+ "&" + dummyParamKey + "=" + encodedSplitData;
						/*-- 成功页面调用 --*/
						$("#commonSuccessViewDiv").trigger({
							type : 'eInvoiceCreatePdf',
							parameters : splitReqParams
						});
						/*-- 提交页面调用 --*/
						$("#balanceCommitDiv").trigger({
							type : 'eInvoiceCreatePdf',
							parameters : splitReqParams
						});
						/*-- 免填单打印池调用--*/
						$("#receiptView").trigger({
							type : 'eInvoiceCreatePdf',
							parameters : splitReqParams
						});
						if ("ok" != splitPackResult) {
							var commitError = new Error("CommitSubPackEx");
							commitError.errorDetail = (splitPackResult.length > 100 ? splitPackResult
									.substring(0, 100)
									: splitPackResult);
							commitError.paramLength = splitReqParams.length;
							throw commitError;
						}

					}
					encodedPValue = dummyParamKey;
				}
			}
		}
		retParams = retParams + pName + "=" + encodedPValue;
		return retParams;
	},
	splitHash : function(hash, imagePath) {
		var theImage = "";
		var theHash = (hash ? hash : "");
		if (hash) {
			var hashArr = hash.split("|");
			/*-- 二代证 --*/
			if (hashArr && hashArr.length > 9) {
				var tokinx = hash.lastIndexOf("|");
				theImage = hash.substring(tokinx + 1);
				theHash = hash.substring(0, tokinx);
			}
		}
		/*-- 非二代证时独立图片 --*/
		if (!theImage && imagePath) {
			theImage = getBase64OfImage(imagePath);
		}
		var obj = new Object();
		obj.hash = theHash;
		obj.image = theImage;
		return obj;
	},
	/*-- 双屏展示免填单 --*/
	playPdfByClient : function() {
		try {
			var topWindow = this.obtainTopWin();
			var elecMode = topWindow.middleFrame.leftFrame.cutomerInfo.document.all.elecMode.value;
			var screenWidth = window.screen.availWidth + "px";
			var screenHeight = window.screen.availHeight + "px";
			if (dbsNeedSign == SCREENMODE_1) {
				needSign = SCREENMODE_1;
			} else {
				needSign = SCREENMODE_0;
			}
			this.callParentFunc("MSG", "客户确认${billFormName}中...");
			if (elecMode == "singleScreenMode") {
				/*-- 江苏单屏模式 --*/
				var style = "dialogWidth:" + screenWidth + ";dialogHeight:"
						+ screenHeight + ";status:no;help:no;scroll:yes;";
				var url = jBME.context.path
						+ "/business.action?BMEBusiness=bundles.singleMode&targetstep=singleModeViewAndConfirm&t="
						+ $.now();
				var rtnValue = showWindow("0", url, window, style);
				if (rtnValue) {
					confAccResult = rtnValue[0];
					signInfo = rtnValue[1];
				}
			} else {
				var dbScreenOCX = this.obtainDBScreenOCX(window);
				if (eInvDbsBtnHeight != '' && eInvDbsBtnHeight != null) {
					dbScreenOCX.SetParam("EXTTOOLBTNHEIGHT", eInvDbsBtnHeight);
				}
				if (eInvDbsFontSize != "") {
					dbScreenOCX.SetParam("EXTTOOLBTNFONTSIZE", eInvDbsFontSize);
				}
				if (signParam != '' && signParam != null) {
					if (dbsignParam == '' || dbsignParam == null) {
						dbsignParam = signParam;
					}
					var signParams = signParam.split(":");
					var dbSignParams = dbsignParam.split(":");
					if (this.newCustCert == '1') {
						dbScreenOCX.SetSignatureType(2, '', dbSignParams[0],
								dbSignParams[1], dbSignParams[2],
								dbSignParams[3], 2);
					} else {
						dbScreenOCX.SetSignatureType(2, '', signParams[0],
								signParams[1], signParams[2], signParams[3], 2);
					}
				}
				/*-- 0: 客户屏幕 1: 营销代表屏幕 2:全部 --*/
				var screenMode = SCREENMODE_2;
				if (this.hasPad4Sign) {
					needSign = SCREENMODE_1;
					/*-- 设备模式 --*/
					var equipType = topWindow.middleFrame.leftFrame.cutomerInfo.document.all.equipType.value;
					/*-- 启用单屏手写板 --*/
					if (EQUIPTYPE_CODE == equipType) {
						screenMode = SCREENMODE_1;
					}
				}
				confAccResult = dbScreenOCX.ViewTransationInfo(
						this.busiInfoXML, screenMode, needSign);
			}
			return confAccResult;
		} catch (e) {
			this.alertMsg(e);
			return false;
		}
		return true;
	},

	playPdfByClientSimple : function() {
		if (isMock())
		{
			// c00311908 桩
			getMockData();
			return true;
		}
		writeLocalFile($Page, "屏幕显示免填单，待用户签名...");
		try {
			debugger;
			var elecMode = "2Screen";
			// var topWindow = this.obtainTopWin();
			// var elecMode =
			// topWindow.middleFrame.leftFrame.cutomerInfo.document.all.elecMode.value;
			// var screenWidth = window.screen.availWidth + "px";
			// var screenHeight = window.screen.availHeight + "px";
			var needSign = 1;// SCREENMODE_1;???
			/*
			 * if (dbsNeedSign == SCREENMODE_1) { needSign = SCREENMODE_1; }
			 * else { needSign = SCREENMODE_0; }
			 */
			this.callParentFunc("MSG", "客户确认${billFormName}中...");
			if (elecMode == "singleScreenMode") {
				/*-- 江苏单屏模式 --*/
				/*
				 * var style = "dialogWidth:" + screenWidth + ";dialogHeight:" +
				 * screenHeight + ";status:no;help:no;scroll:yes;"; var url =
				 * jBME.context.path +
				 * "/business.action?BMEBusiness=bundles.singleMode&targetstep=singleModeViewAndConfirm&t=" +
				 * $.now(); var rtnValue = showWindow("0", url, window, style);
				 * if (rtnValue) { confAccResult = rtnValue[0]; signInfo =
				 * rtnValue[1]; }
				 */
			} else {
				var dbScreenOCX = this.obtainDBScreenOCX(window);
				
				if (this.hasPad4Sign) {
					needSign = 1;
				}
				/*-- 0: 客户屏幕 1: 营销代表屏幕 2:全部 --*/
				var screenMode = 1;// ???	
				if ($Page.Corporation && $Page.Corporation == 'JIANGSU') 
				{
					screenMode = 1;
					
					var signParam = "1:2:3:4";// ???
					var dbsignParam = null;// ???

					if (signParam != '' && signParam != null) {
						if (dbsignParam == '' || dbsignParam == null) {
							dbsignParam = signParam;
						}
						var signParams = signParam.split(":");
						var dbSignParams = dbsignParam.split(":");
						if (this.newCustCert == '1') {
							dbScreenOCX.SetSignatureType(2, '', dbSignParams[0],
									dbSignParams[1], dbSignParams[2],
									dbSignParams[3], 2);
						} else {
							dbScreenOCX.SetSignatureType(2, '', signParams[0],
									signParams[1], signParams[2], signParams[3], 2);
						}
					}
					
					// 不知道干啥的 江苏在用
					var eInvDbsBtnHeight = 1000;// ???
					var eInvDbsFontSize = 12;// ???
					if (eInvDbsBtnHeight != '' && eInvDbsBtnHeight != null) {
						dbScreenOCX.SetParam("EXTTOOLBTNHEIGHT", eInvDbsBtnHeight);
					}
					if (eInvDbsFontSize != "") {
						dbScreenOCX.SetParam("EXTTOOLBTNFONTSIZE", eInvDbsFontSize);
					}
				}
				else if ($Page.Corporation && $Page.Corporation == 'SHANDONG')
				{
					// 山东手写屏 c00311908
					dbScreenOCX.SetSignatureType(2,			//获取签名方式 1：生成签名图片到本地 2：生成签名编码信息到内存
									'c:/signature.jpeg',	//当nType为1时，表示签名图片文件的名称；当nType为2传空
									275,			//签名结果的宽度
									200,			//签名结果的高度
									4,				//控制签名笔迹的粗细
									0,				//控制签名笔迹的颜色
									2				//图片格式，可选项,  0：BMP  1;gif  2:jpeg(系统默认)
									);	
					screenMode = 2;
				}
				else if ($Page.Corporation && $Page.Corporation == 'NINGXIA')
				{
					// 宁夏手写屏，目前跟山东一样，后边可能不一样，预留一个else c00311908
					//宁夏采用新的控件 xWX275970
					// dbScreenOCX.SetSignatureType(
					// 		275,
					// 		200,
					// 		4,
					// 		Number("0xffff00")
					// );
					screenMode = 2;
				}
				else {
					alert("System Error!不知道当前是哪个局点");
				}
				
				// confAccResult = dbScreenOCX.ViewTransationInfo(
				// 		this.busiInfoXML, screenMode, needSign);
			}
			// return confAccResult;
		} catch (e) {
			this.alertMsg(e);
			return false;
		}
		return true;
	},

	/*-- 生成电子免填单预处理 --*/
	beforeDoEinvoice : function() {
		var playResult = true;
		playResult = this.playPdfByClientSimple();
		if (!playResult) {
			return false;
		}
		/*
		 * if (noCreatePdfByServer == '1') { if (createPdfByClient == '1') {
		 * playResult = this.playPdfByClient();-- 客户端生成pdf -- if (!playResult) {
		 * return false; } } } else { if (createPdfByClient == '1' &&
		 * clientBeforeServer == '1') { playResult = this.playPdfByClient();--
		 * 客户端生成pdf -- } if (!playResult) { return false; } }
		 */
		return true;
	},

	/*--
	判断库中此模板MD5摘要和控件计算的本地模板MD5摘要的一致性，不一致则终止业务
	create by cWX143640 20131029 R003C13LJS1007 OR_JS_201309_727 无纸化客户端的PDF模板加密需求
	--*/
	validMD5Consistent : function(fileNames) {
		/*-- 返回值 --*/
		var rtnInfo = "";

		/*-- 格式：file1在库中MD5摘要@file1路径,file2在库中MD5摘要@file2路径,file3在库中MD5摘要@file3路径 --*/
		var files = fileNames.split(",");
		for ( var i in files) {
			var file = files[i];

			/*-- 数据库中存储的模板MD5摘要 --*/
			var md5StrData = file.split("@")[0];

			/*-- 本地文件路径 --*/
			var filePath = file.split("@")[1];

			if (md5StrData != '' && filePath.indexOf('_band') == -1) {
				/*-- add begin s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 --*/
				/*-- 判断本地模板文件是否为空，如果为空，说明下载失败 --*/
				var fSize = this.getFileSize(filePath);
				var fSizeInt = parseInt(fSize);
				if (fSizeInt == 0) {
					rtnInfo = "invalid:" + filePath;
					break;
				}
				/*-- add end s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 --*/

				/*-- 通过控件计算本地模板文件的MD5摘要 --*/
				var topWindow = this.obtainTopWin();
				var leftCsp = topWindow.middleFrame.leftFrame.cutomerInfo;
				var md5StrLocal = leftCsp.document.getElementById("HWUtil")
						.GetMD5DigestInFile(filePath);

				/*-- 判断库中此模板MD5摘要和控件计算的本地模板MD5摘要是否一致，不一致则终止业务 --*/
				if (md5StrLocal != ''
						&& md5StrData != md5StrLocal.toUpperCase()) {
					rtnInfo = filePath;
					break;
				}
			}
		}
		return rtnInfo;
	},

	/*-- 生成电子免填单后处理 --*/
	afterDoEinvoice : function(doResult) {
		splitPackResult = doResult;
		if ('ok' == doResult || "SplitPackError" == doResult) {
			return;
		}
		/*-- add begin qWX161270 2013-2-6 R003C13L02n01 OR_HUB_201301_500 无纸化营业厅专题-支持多功能证机具优化--*/
		$('#elecPrintLoading').hide();
		/*-- add end qWX161270 2013-2-6 R003C13L02n01 OR_HUB_201301_500 无纸化营业厅专题-支持多功能证机具优化--*/

		/*-- add begin l00227362 2013-04-03 R003C13LG0401 OR_HEB_201303_288--*/
		this.chgKeepCommitBtnDisabled(false);
		/*-- add end l00227362 2013-04-03 R003C13LG0401 OR_HEB_201303_288--*/
		/*-- 江苏不需要打印纸质免填单 --*/
		var execPrint = false;
		/*-- 重庆需要打印纸质免填单 --*/
		if (isPaperInvoice == '1') {
			execPrint = true;
		}
		/*-- 湖北打印电子免填单失败时需要打印纸质免填单 --*/
		if (province == 'HUB') {
			execPrint = true;
		}

		var retObject = this.chkResult(doResult);
		/*-- 打印电子免填单成功 --*/
		if (retObject.code == 1) {
			/*--设置成功保存电子免填单标志 --*/
			jQuery('#balanceCommitDiv').trigger({
				type : 'createElePdfSuccessEvent',
				printEInvoiceSerialNo : this.serialNo
			});
			jQuery('#commonSuccessViewDiv').trigger({
				type : 'createElePdfSuccessEvent'
			});
			jQuery('#receiptView').trigger({
				type : 'createElePdfSuccessEvent'
			});
			/*-- add begin qWX161270 2013-02-25 R003C13L02n01 OR_HEB_201301_1202 --*/
			if ("1" == "${chgCancelComBtStus}") {
				/*-- TODO 要确认到底做不做  --*/
			}
			/*-- add end qWX161270 2013-02-25 R003C13L02n01 OR_HEB_201301_1202 --*/
			/*-- modify begin l00227362 2013-07-04 R003C13LG0601 OR_SD_201306_419 --*/
			if ("1" == "${printModelChoose}") {
				if (succeedConfirm("流水号：" + this.serialNo
						+ "电子${billFormName}生成成功。\n 点'确定'打印纸质单据，点'取消'取消打印。")) {
					var screenWidth = (window.screen.availWidth - 200) + "px";
					var screenHeight = (window.screen.availHeight - 150) + "px";
					var modalDialogParam = "status:no;help:no;resizable:yes;"
							+ "dialogHeight:" + screenHeight + ";dialogWidth:"
							+ screenWidth + ";";
					var modelChooseUrl = jBME.context.path
							+ "/business.action?BMEBusiness=bundles.printModelChoose"
							+ "&serialNo=" + this.serialNo + "&t=" + $.now();
					var modelChooseRtnValue = showWindow("0", modelChooseUrl,
							window, modalDialogParam);
					if ('printPaper' == modelChooseRtnValue) {
						execPrint = true;
					}
				}
				/*-- modify end l00227362 2013-07-08 R003C13LG0601 OR_SD_201306_419 --*/
			}
			/*-- add begin s00227425 2013-01-24 R003C13L01n01 OR_HEB_201212_1452 --*/
			else if ("1" == "${promptPrtPaperInv}") {
				execPrint = !succeedConfirm("流水号："
						+ this.serialNo
						+ "电子${billFormName}生成成功。\n点'确定'不打印纸质${billFormName}，点'取消'打印纸质${billFormName}。");
			} else {
				this.alertMsg(retObject.errInfo);
			}
			/*-- add end s00227425 2013-01-24 R003C13L01n01 OR_HEB_201212_1452 --*/
			/*-- 清除打印流水 --*/
			if (this.hasPad4Sign) {
				/*-- TODO 要确认到底做不做  --*/
			}
			this.callParentFunc("OK");
			/*-- 打印电子免填单失败 --*/
		} else {
			/*-- add begin l00201782 2013-07-02 R003C13LG0501 OR_huawei_201307_23 --*/
			if ('JS' == province) {
				var exceptionMsg = "<font color='red'>电子${billFormName}保存失败（子包）。</font>"
						+ "点击“确定”再次尝试保存？";
				if (exceptionConfirm(exceptionMsg)) {
					this.doEinvoice(true);
					// TODO return
					return;
				} else {
					/*--add begin jKF10813 2013-08-10 R003C13LG0701 OR_JS_201307_1061--*/
					if ("true" == "${logDebug}") {
						/*-- 失败原因 --*/
						var errorReason = "";
						if (doResult.split("~").length > 4) {
							errorReason = doResult.split("~")[4];
							errorReason = (errorReason.length > 100 ? errorReason
									.substring(0, 100)
									: errorReason);
						}

						/*-- 报文总大小 --*/
						var paramsSize = 0;
						if (this.parameters) {
							paramsSize = this.parameters.length;
						}

						var elecMode = this.obtainTopWin().middleFrame.leftFrame.cutomerInfo.document.all.elecMode.value;
						var params = "recData=FailReason:" + errorReason
								+ ";PackSize:" + paramsSize;
						params = params + "&clientInfo=TabletMode:"
								+ (this.hasPad4Sign ? "1" : "0");
						params = params + ";DoubleScreen:"
								+ (elecMode == "singleScreenMode" ? "0" : "1");
						params = params + "&formNum=" + this.serialNo;

						// 成功页面调用
						$("#commonSuccessViewDiv").trigger({
							type : 'recordEInvoiceExceptionLog',
							parameters : params
						});
						// 提交页面调用
						$("#balanceCommitDiv").trigger({
							type : 'recordEInvoiceExceptionLog',
							parameters : params
						});
						// 免填单打印池调用
						$("#receiptView").trigger({
							type : 'recordEInvoiceExceptionLog',
							parameters : params
						});

					}
					/*--add end jKF10813 2013-08-10 R003C13LG0701 OR_JS_201307_1061--*/
				}
			}
			/*-- add end l00201782 2013-07-02 R003C13LG0501 OR_huawei_201307_23 --*/
			if ('1' == isPaperInvoice) {
				var exceptionMsg = "<font color='red'>"
						+ retObject.errInfo
						+ "</font></br>"
						+ "\n点'确定'打印纸质${billFormName}，点'取消'不打印纸质${billFormName}。";
				execPrint = exceptionConfirm(exceptionMsg);
			} else {
				if (!this.win.printCommitUnite4EInvCallBack) {
					/*-- modify begin s00227425 2013-01-24 R003C13L01n01 OR_HEB_201212_1452 --*/
					if ("1" != "${promptPrtPaperInv}") {
						this.alertMsg(retObject.errInfo);
					} else {
						var exceptionMsg = "<font color='red'>"
								+ retObject.errInfo
								+ "</font></br>"
								+ "\n点'确定'打印纸质${billFormName}，点'取消'不打印纸质${billFormName}。";
						if (exceptionConfirm(exceptionMsg)) {
							execPrint = true;
						}
						/*-- add begin l00164512 2013-04-09 R003C13LG04n01 OR_HEB_201303_1425--*/
						/*-- 打印电子免填单失败且没有打印纸质免填单时，将继续提交按钮置灰 --*/
						else if ("1" == "${eInvoiceCommitBtnAutoDisable}") {
							this.chgKeepCommitBtnDisabled(true);
						}
						/*-- add end l00164512 2013-04-09 R003C13LG04n01 OR_HEB_201303_1425--*/
					}
					/*-- modify end s00227425 2013-01-24 R003C13L01n01 OR_HEB_201212_1452 --*/
				}
			}
			this.callParentFunc("NG", retObject.errInfo);
		}

		/*-- 打印纸质免填单 --*/
		if (execPrint) {
			/*-- add begin qWX161270 2013-02-25 R003C13L02n01 OR_HEB_201301_1202 --*/
			if ("1" == "${chgCancelComBtStus}") {
				/*-- TODO 要确认到底做不做  --*/
			}
			/*-- add end qWX161270 2013-02-25 R003C13L02n01 OR_HEB_201301_1202 --*/
			printNormalReceipt();

		}
	},

	/*-- 生成电子免填单后处理(判断生成结果) --*/
	chkResult : function(doResult) {
		/*-- 打印电子免填单失败 --*/
		var retObject = new Object();
		retObject.code = 0;
		retObject.errInfo = "";
		if (doResult.split("~")[0] != "0") {
			/*--modify begin jKF10813 2013-03-26 R003C13L03n01 OR_huawei_201212_848--*/
			var errMsg = "电子${billFormName}生成失败：" + doResult + "\n";
			var emergency = "${emergency}";
			if (emergency == "1") {
				var topWindow = this.obtainTopWin();
				topWindow.middleFrame.leftFrame.cutomerInfo.document.all.isMustPrintPaper.value = "1";
				var datFilePath = "C:\\dat\\" + this.serialNo + ".dat";
				errMsg = "电子${billFormName}保存失败:" + doResult
						+ "\n后续所有业务强制打印纸质${billFormName}。";

				/*-- 获得系统文件夹对象 --*/
				// var fso = new ActiveXObject("Scripting.FileSystemObject");
				// var systemFolder = fso.GetSpecialFolder(1);
				var dbScreenOCX = this.obtainDBScreenOCX(window);

				if (dbScreenOCX) {
					var base64 = dbScreenOCX.GetPDFFile(2, "");
					if (base64 != "0") {
						(document.getElementById("HWUtilOCX") || document.getElementById("HWUtilOCXS")).SaveToFile(
								datFilePath, this.serialNo, base64);
						errMsg = "电子${billFormName}保存失败：" + doResult
								+ "\n生成临时文件" + datFilePath + "。";
					}
				}
			}
			retObject.errInfo = errMsg;
			/*--modify end jKF10813 2013-03-26 R003C13L03n01 OR_huawei_201212_848--*/
			return retObject;
		}

		/*-- 打印电子免填单成功 --*/
		var msginfo = "订单号：" + this.serialNo + "电子${billFormName}生成成功，请继续。";
		if (clientBeforeServer != '1' && isDoubleScreen == '1') {
			msginfo = "订单号：" + this.serialNo + "电子${billFormName}生成成功，请客户确认。";
		}
		retObject.errInfo = msginfo;
		if (clientBeforeServer != '1' && createPdfByClient == '1') {
			if (!this.playPdfByClient()) {/*-- 客户端生成pdf --*/
				retObject.errInfo = "客户不同意协议或${billFormName}。";
				return retObject;
			}
		}
		if (createPdfByClient != '1' && isDoubleScreen == '1') {
			/*-- 客户端从服务器加载pdf --*/
			this.browserDownloadPDFFile(this.serialNo, doResult.split("~")[1],
					doResult.split("~")[2], doResult.split("~")[3]);
		}

		retObject.code = 1;
		return retObject;
	},
	pdfAction : function($scope) {
		debugger;
		/*-- modify begin l00201782 2012-08-13 R003C12L08n01 OR_SD_201207_1015 --*/
		// var topWindow = this.obtainTopWin();
		var evmsFlag = true;// topWindow.middleFrame.leftFrame.cutomerInfo.document.all.evmsFlag.value;
		/*
		 * if(evmsFlag != "true" && skipClient != '1') { // 湖北设备连接异常时需要打印纸质免填单 /
		 * if (province == 'HUB'||province == 'HEB') { printNormalReceipt(); }
		 * return false; }
		 */
		ifAutoExecPrint = false;
		var execFlag = true;
		if (evmsFlag) {
			/*-- modify begin w00219983 2014-3-31 OR_HEB_201401_805 无纸化-客户端PDF模板自动更新 --*/
			/*
			 * var autoDownTemplate = true; if(eInvoice_NG40 == '1' ||
			 * printEInvoiceAfterCommit == '1' || autoDownTemplate) { try {
			 * if(!this.downProFiles(eval(this.pdfTplFiles))) { return false; } }
			 * catch(e) { alert("下载模板失败：" + e); return false; } }
			 */
			/*-- modify end w00219983 2014-3-31 OR_HEB_201401_805 无纸化-客户端PDF模板自动更新 --*/

			/*-- add begin cWX143640 20131029 R003C13LJS1007 OR_JS_201309_727 无纸化客户端的PDF模板加密需求 --*/
			/*-- 判断库中此模板MD5摘要和控件计算的本地模板MD5摘要的一致性，不一致则终止业务 --*/
			/*
			 * if(billAndCertAutoDownload == '1' && this.tplFileNames != '') {
			 * var rtnInfo = this.validMD5Consistent(this.tplFileNames);
			 * if(rtnInfo != "" && rtnInfo.indexOf("invalid:") != 0) {
			 * this.commonDealErr(rtnInfo + "模板内容已发生变化，请确认。"); return; } else
			 * if(rtnInfo.indexOf("invalid:") == 0) { rtnInfo =
			 * rtnInfo.substring(rtnInfo.indexOf("invalid:") + 8);
			 * this.commonDealErr("下载" + rtnInfo + "服务端模板失败，请联系维护人员。"); return
			 * false; } }
			 */
			/*-- add end cWX143640 20131029 R003C13LJS1007 OR_JS_201309_727 无纸化客户端的PDF模板加密需求 --*/

			execFlag = this.beforeDoEinvoice();
		}
		debugger;
		/*-- modify end l00201782 2012-08-13 R003C12L08n01 OR_SD_201207_1015 --*/
		// 桩 
		// execFlag = true;
		if (execFlag) {
			try {
				execFlag = this.doEinvoice();
			} catch (e) {
				;
			}
			debugger;
			
			var formNums = this.formNums;
			if (!this.formNums){
				formNums = this.serialNo;
			}
			
			// DTS2017101005861 增加遮罩 c00311908
			$Page.showCover2 = true;
			$Page.recformnums = formNums;

			// 设一个全局变量 记录推送次数 c00311908
			window._ysp_top.createPDFTimes = 0;
			
			// 标记当前未调createpdf方法
			$Page.callCreatePDF = false;
						
			writeLocalFile($Page, "免填单数据parameter:"+this.parameters);
			
			if($Page.prePushReceptFlag){
				writeLocalFile($Page, "免填单提前推送...");
				// 先调接口 上传证件及签名图片 只江苏有 c00311908
				if ($Page.Corporation && $Page.Corporation == 'JIANGSU'
					&& $Page.isNewuploadLssType == 'Y')
				{
					var uploadReq = this.getUploadReq($Page);
					this.uploadCardPic($scope, $Page, uploadReq);
				}
				
				$scope.$emit("$bes.oc.prepusheInvoice.createPDF", {
					parameters : this.parameters
				});
				/***
				$scope.$emit("$bes.oc.prepusheInvoice.createLog", {
					serialNo : formNums
				});
				*/
			}else{
				try {
					debugger;
					// 先调接口 上传证件及签名图片 只江苏有 c00311908
					if ($Page.Corporation && $Page.Corporation == 'JIANGSU' 
						&& $Page.isNewuploadLssType == 'Y')
					{
						writeLocalFile($Page, "免填单文件上传LSS...");
						var uploadReq = this.getUploadReq($Page);
						this.uploadCardPic($scope, $Page, uploadReq);
					}
					
					if ($Page.callCreatePdfByRest == "YY")
					{
						// 系统参数控制 使用直接调用rest请求的方式
						var sendData = {};
						sendData.parameters = this.parameters;
						if (window._ysp_top.resendReceptionPage == true)
						{
							if (typeof $Controller.OcQueryReceptionController.createPDF == 'function')
							{
								// 补推送
								$Controller.OcQueryReceptionController.createPDF($Page, $scope.$Inject('$Fire'), $scope, $scope.$UI,sendData);
							}
							else
							{
								alert('推送异常，请重新打开补推送页面进行推送!');
								return;
							}
						}
						else
						{
							if (typeof $Controller.bes.oc.einvoice.createPDF == 'function')
							{
								$Controller.bes.oc.einvoice.createPDF($Page, $scope.$Inject('$Fire'), $scope, $scope.$UI,sendData);
							}
							else
							{
								alert('推送异常，请重新打开补推送页面进行推送!');
								return ;
							}
						}
					}
					else
					{
						writeLocalFile($Page, "免填单正常推送...抛createPDF事件!");
						// 原来的方式 抛事件
						$scope.$emit("$bes.oc.eInvoice.createPDF", {
							parameters : this.parameters
						});	
					}
					
					if ($Page.initPrintLog == "Y")
					{
						if (window._ysp_top.resendReceptionPage == true)
						{
							if (typeof $Controller.OcQueryReceptionController.printLogInit == 'function')
							{
								writeLocalFile($Page, "免填单补推送...调用printLogInit方法!");
								var sendData = {};
								sendData.printType = "EleInit";
								sendData.serialNo = formNums;
								// 补推送
								$Controller.OcQueryReceptionController.printLogInit($Page, $scope.$Inject('$Fire'), $scope.$UI,sendData);
							}
						}
						else
						{					
							if (typeof $Controller.bes.oc.einvoice.createLogInit == 'function')
							{
								writeLocalFile($Page, "免填单正常推送...调用createLogInit方法!");
								var sendData = {};
								sendData.printType = "EleInit";
								sendData.serialNo = formNums;
								//
								$Controller.bes.oc.einvoice.createLogInit($Page, $scope.$Inject('$Fire'), $scope.$UI,sendData);
							}
						}
					}
					else 
					{
						writeLocalFile($Page, "免填单记录推送日志，系统参数initPrintLog开了不会走这个逻辑!");
						// 记日志是记日志 调ICRM是调ICRM c00311908
						if (window._ysp_top.resendReceptionPage == true)
						{
							$scope.$emit("$bes.reprint.createLog", {
								printType : "Er"
							});
						}
						else
						{					
							$scope.$emit("$bes.oc.eInvoice.createLog", {
								serialNo : formNums
							});
						}
					}					
				} 
				catch (e) 
				{
					$Page.showCover2 = false;
					alert('推送异常，请重新打开补推送页面进行推送!');
					return ;
				}
			}			
			
			// alert("业务流水：" + this.serialNo + " 电子免填单生成成功，请继续");
			$("#a_paymentFinishReceiptPrintPush").attr("disabled", "disabled");
			$("#a_paymentFinishReceiptPrintPush").css("background-color",
					"#6a8399");
			$("#a_paymentFinishEReceiptPrint").removeAttr("disabled");
			   $("#a_paymentFinishEReceiptPrint").css("background-color",
			     "#64cb64");

		} else {
			debugger;
			/*
			 * $scope.$emit("$bes.oc.eInvoice.createLog", { serialNo :
			 * this.serialNo });
			 * 
			 * $scope.$emit("$bes.oc.eInvoice.createPDF", { parameters :
			 * this.parameters });
			 */
			this.callParentFunc("NG", "客户不同意协议或${billFormName}。");
		}

		/*-- 置打印完标志位true --*/
		printFlag = true;
		//打印免填单所需证件图片信息置空
		$.cookie('besservcard', "");
		$.cookie('besdelegcard', "");
		
		//过户添加
		$.cookie('besnewservcard', "");
		$.cookie('besnewdelegcard', "");
	},
	
	/**
	 * 拼装免填单要上传LSS的信息
	 *  c00311908
	 */
	getUploadReq : function($Page)
	{
		debugger;
		var uploadReq = {};
		uploadReq.formNums = $Page.recformnums;
		if ($Page.servcard_upload && $Page.servcardData_upload)
		{
			uploadReq.servCard = {};
			uploadReq.servCard.cardInfo = $Page.servcard_upload;
			uploadReq.servCard.cardPic = $Page.servcardData_upload;
		}
		if ($Page.delegcard_upload && $Page.delegcardData_upload)
		{
			uploadReq.delegCard = {};
			uploadReq.delegCard.cardInfo = $Page.delegcard_upload;
			uploadReq.delegCard.cardPic = $Page.delegcardData_upload;
		}
		if ($Page.newservcard_upload && $Page.newservcardData_upload)
		{
			uploadReq.newservCard = {};
			uploadReq.newservCard.cardInfo = $Page.newservcard_upload;
			uploadReq.newservCard.cardPic = $Page.newservcardData_upload;
		}
		if ($Page.newdelegcard_upload && $Page.delegcardData_upload)
		{
			uploadReq.newdelegCard = {};
			uploadReq.newdelegCard.cardInfo = $Page.newdelegcard_upload;
			uploadReq.newdelegCard.cardPic = $Page.newdelegcardData_upload;
		}
		if (signInfo)
		{
			// 把签名的前缀去掉
			var infos = signInfo.split(';');
			uploadReq.sign = {};
			uploadReq.sign.cardPic = infos[1];
		}
		
		return uploadReq;
	},
	
	/**
	 * 上传证件图片到LSS
	 */
	uploadCardPic : function($scope, $Page, uploadReq)
	{
		debugger;
		var $Fire = $scope.$Inject('$Fire');
		$Fire({
			"service":"bes.oc.oceinvoicectzservice/uploadcardpic",
			"params":{
				'uploadReq':uploadReq
				},
			"target":"$Page.uploadResult",
			"onafter":function(){
				debugger;
				if ($Page.uploadResult != "success"){
					// 啥也不做
					alert('上传证件图片出错');
				}
			},
			"onerror":function(){
				debugger;
				alert('上传证件图片异常');
			}
			
		}, $scope);
		
	},

	/*--
	 * 判断服务器模板摘要和给定文件名生成的模板摘要是否一致，不一致的话，返回true，否则返回false
	 * @remark create by s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 
	--*/
	invalidExistFileMD5Consistent : function(fileNames, existFileName) {
		var result = false;

		/*-- 格式：file1在库中MD5摘要@file1路径,file2在库中MD5摘要@file2路径,file3在库中MD5摘要@file3路径 --*/
		var files = fileNames.split(",");
		for ( var i in files) {
			var file = files[i];
			var fileArr = file.split("@");
			if (fileArr && fileArr.length == 2) {
				/*-- 数据库中存储的模板MD5摘要 --*/
				var md5StrData = file.split("@")[0];
				/*-- 本地文件路径 --*/
				var filePath = file.split("@")[1];

				var index = filePath.lastIndexOf("\\") == -1 ? filePath
						.lastIndexOf("/") : filePath.lastIndexOf("\\");
				var fileName = filePath.substring(index + 1);

				if (existFileName == fileName) {
					if (md5StrData != ''
							&& existFileName.indexOf('_band') == -1) {
						/*-- 通过控件计算本地模板文件的MD5摘要 --*/
						var topWindow = this.obtainTopWin();
						var leftCsp = topWindow.middleFrame.leftFrame.cutomerInfo;
						var md5StrLocal = leftCsp.document.getElementById(
								"HWUtil").GetMD5DigestInFile(filePath);

						/*-- 判断库中此模板MD5摘要和控件计算的本地模板MD5摘要是否一致，不一致则终止业务 --*/
						if (md5StrData != md5StrLocal.toUpperCase()) {
							result = true;
						}
					}

					break;
				}
			}
		}
		return result;
	},

	/*--
	 * 获取文件大小
	 * @remark create by s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 
	--*/
	getFileSize : function(fileUri) {
		try {
			var fso = new ActiveXObject("Scripting.FileSystemObject");
			var file = fso.GetFile(fileUri);
			return file.size;
		} catch (e) {
			return 0;
		}
	},

	/*--
	 * 公共处理错误
	 * @remark create by s00227425 20140708 V200R003C14LG0601_EJS OR_JS_201406_515 关于无纸化本地协议版本自动更新的需求 
	--*/
	commonDealErr : function(rtnInfo) {
		if (this.win.printCommitUnite4EInvCallBack) {
		} else {
			alert(rtnInfo);
		}
		this.callParentFunc("NG", rtnInfo);
	}
};

function alertSaveRecInvoice(args) {
	/*
	 * var style = "dialogHeight:116px; dialogWidth:232px; help: No; resizable:
	 * no; status: No; scroll:no; dialogTop:"+(screen.height-116)/2+"px;
	 * dialogLeft:"+(screen.width-232)/2+"px;"; var sUrl =
	 * "${BMETheme.customPath}/jsp/alert.htm?ngcrm_rnd="+Math.random()+"&ngcrm_reserved1=1";
	 * return showWindow("0",sUrl, args, style);
	 */
	alert(args);
};
/* <%--设置控件返回结果 --%> */
function setConfAccResult(rst) {
	confAccResult = rst.rev1;
	signInfo = rst.rev2;
}/*
	 * <%--用来提示“开始生成电子免填单” --%>
	 */
function alertSaveRecInvoice(args) {
	var style = "dialogHeight:116px; dialogWidth:232px; help: No; resizable: no; status: No; scroll:no; dialogTop:"
			+ (screen.height - 116)
			/ 2
			+ "px; dialogLeft:"
			+ (screen.width - 232) / 2 + "px;";
	var sUrl = "${BMETheme.customPath}/jsp/alert.htm?ngcrm_rnd="
			+ Math.random() + "&ngcrm_reserved1=1";
	return showWindow("0", sUrl, args, style);
}

Function.prototype.bind = function(obj) {
	var method = this;
	return function() {
		return method.apply(obj, arguments);
	};
};

/* <%--双屏时回调函数定义---------begin-------- --%> */
if (true/* isDoubleScreen == '1' */) {
	if (true/* "JG" == dbsResolvent */) {
		var signImgPath = "c:\\signature.jpeg";
		var signInfo = "";
		
		// 存储拍照信息
		var photoInfo = "";
		
		function OnViewTransInfoDone(Data) {
			debugger;
			if (/* Data == "1" */true) {
				if (/* "1" == dbsNeedSign || CreatePDF.hasPad4Sign */true) {
					try {
						try{
							signInfo = CreatePDF.obtainDBScreenOCX()
									.GetSignatureValue(2, signImgPath, 1);
							if (/* '1' == einvoice_PreviewEInvoice */false) {
								CreatePDF.obtainDBScreenOCX().GetPDFFile(1,
										"c:\\protocol\\invoiceWithSign.pdf");
							}
						}catch (e) {
							// 这是什么写法？搞不清 我认为也没用
							try{
								//宁夏的控件
								signInfo = document.getElementById("ControlObj")
											.GetSignatureValue(2, signImgPath, 1);
							}
							catch(e){
								// 如果不把宁夏的try起来，江苏有可能异常退出
							}
						}
						
						var vectorsign = "VECTORSIGN=1.0;";
						var generalsign = "GENERALSIGN=1.0;";
						if (vectorsign == signInfo.substr(0, vectorsign.length)) {
							var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
							xmlDoc.async = false;
							xmlDoc.loadXML(signInfo
									.substring(vectorsign.length));
							var apNode = xmlDoc.getElementsByTagName("ap");
							signInfo = vectorsign
									+ apNode[0].childNodes[0].nodeValue;
						} else if (signInfo
								&& signInfo != "0"
								&& generalsign != signInfo.substr(0,
										generalsign.length)) {
							signInfo = generalsign + signInfo;
						}
						writeLocalFile($Page,"签名信息:"+signInfo);
					} catch (e) {
						signInfo = "0";
					}
					if (signInfo == "0") {
						CreatePDF.alertMsg("获取签名结果失败。");
					}
					
				} else {
					CreatePDF.alertMsg("客户已确认。");
				}
			} else {
				if (Data == "0") {
					CreatePDF.alertMsg("客户取消。");
				} else {
					CreatePDF.alertMsg("控件异常，请联系管理员。");
				}
				if (dbsNeedSign == '1') {
					signInfo = "0";
				}
			}
		}
	} else {
		document
				.write('<object id="DBScreenOCX" name="DBScreenOCX" width="0" height="0" classid="clsid:81047BE4-C9CB-496D-BD51-874C0CE63D95"></object>\n');
		document
				.write('<script type="text/javascript" FOR="DBScreenOCX" EVENT="PDFDownComplete(Data)">\n');
		document.write('return OnPDFDownComplete(Data);\n');
		document.write('<\/script>\n');
		function OnPDFDownComplete(Data) {
			if (window.ActiveXObject) {
				if (Data == 1) {
					CreatePDF.alertMsg("客户已确认，请继续。");
				} else if (Data == 2) {
					CreatePDF.alertMsg("客户取消。");
				}
			} else {
				CreatePDF.alertMsg("双屏控件问题，请联系管理员。");
			}
		}
	}
};

function getMockData()
{
	debugger;	
//	signInfo = "GENERALSIGN=1.0;/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAGbAUoDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7113xLrnivWr/AEbwzdro2labJ9n1PxAYllm8/aC1vaIwKb1BG+VwyoSFCu27bPN8J9OmtlMuu+JL2ZuDcv4gu1Y5AGcRyIg5weFA9utTfCm1jtPhd4bRw7XU1nHdTSlD89xN++kbP+07ufxNdQLiC6tGieN5HAKkqh9ODnt271Spx6r7zO7etzk7j4WaW9i0kd1r0rmMlSfEV+hBwef9dg9T6fpVW2+HOgtaGV5vEyqWcq//AAkN8do3cZ/f44x79/Wuwsord7CNpRMkgDBmbfjd3Pf0607SzHFZxrDepGqAqI3YFdoOQecEcMPzqvZU19lP5E3ff8ThbL4b6ZeO/k3OuTQrn5T4iv1c+nHn8/Lzx6io5vAGj/asrJ4jgCLl0uNe1HYzc/KD52V45yR6V3dpLJPBIZLAXarIY/NikBJxhcr0PbsaopdNY6pMTKYY1wYlvWK72ZVGN4z0CjBOetaKlTu/dX3Im7stWclJ8O9Is4I0upPEMcoUYlj8QX7q59CPP57cg5xz61Uk+HmmIU3XGuI00uA0XiK/lRVyRgfvx6dME88dBXdX8Uh1G1jsYPJYfvXUsGgJ2uF4BwP4uRjp05qK6R9Mt4hcWzphdjTWKb1kxxiRCMEH86ap09+VX9EGrdrs5Cb4daNCsrS32rvISPLVPEd+q5zjj98DjPVWx3wahj+HOjr5YW61yVmHyL/b+oHe3cKpmBxnGQTlT03CustV+0qJl3KJFKvNABLHu4CqVboAp5DE47VY3R2ds8YuE6Evvf5ZAe7E4/I4YdjTdKmtOVfcv8g17nGv8PNKDbWn1eQ/dxF4hvigLHj5jOCwwewyvcVO3w30aHczHXIotyjfPr19+65GS5E/Q9Aw9TkAV1MIWaaJZfOjikJuTPEP++T74yPmHI/ipl3K1qkRRZ7mBNzwToQBIxyoIx0ye3Kt1ApezpvTlX3ItJ9zlz8OdEuoGMMmsKZFYq512/cRc4UtiflQDnIweB9atx/DHS3kUpFqc8By0gj1+9kwu4AFD54LcA8EDrkeldBgwXAJeNGkKr+6lwPLUnO1iccncCjdMgCpdPgmjV5ysWn3bwgrEpCrgAnch5HLHlTkDj1qHTp20ivuRol/Wpy4+GegRabJdNcarLsQGInW71gzkthT++GeNoPTBz71Bd/DnTFiiiFnqIZnDeYut3zAqCAR/rc4OD05wOldbNGsAtI77MUzPuZomKrLnCKPqAxzn3Iq/wDboTqr/ZkSS3s41LSJKMKAG4/8eP4g9xU+zh/KvuRojmbb4S+Grjz5YzqTxphY5W1m9ZSQvzEjzueuO2CO1Zdt4J8PQ2TS3VnfrJcNst3TVrzymPTduM3yjJz7Be9dLeot3YOBLIl7eThZokcqURycAp0IxxnHPPNWpp/K12C2ukjeGyi+R4cAMWGFBU4wTjgAkYFT7Gm1dxX3I0j2RyFz8JdGtbiKyZ764aSPzZVh1G73KmcEpumPJHAx9cE4qVPhf4YkvpI4IdQuLCLbJMw1S7L7j0VcSA7e5HscdDXSwStptrcalFFLDDK37iF0DgJ0QAbgw3e2Rgj0p8m+wht44p8T3X7x5oZA6sSfmdgQcDnG8dyBQ6VN/ZX3IrV9Tlx8L/D99ftFbQzvb8iORtTugLhsZKBhJwQOdwHOB6VA3gPw5hYYtOkeaDcs7rf3GPLPYjzeHGRnqAMnkEV2osp4tml2wFrDjeVbMnlAHhkfOWyT3yRzUTSR2MMNrHZTCZyAIlBKrMOd27GCGB69xxjmkqVL+VfchHKTfCDQrWC6KQ3BkjZSQNSuGXawG0hixI5BBPcAn0FS3Pw98JEyWttYzSTyQiaBY7y4kdcZDb/3nHTGTjkmt2KJpGt2u5FjiIMTADescW4gqC3dW2glhwCSOKBDp+lXNvvdVijLJcxecfvjglhx94YYk9dvSn7KnfWK+4dl1ML/AIV/4X1pGhttJkaWS3ZSy3MyiCYZzljJ/tDgA8D3qvZ+A/C+s3FtAmj4ujCHlJvJ1TcMZYMHO4/KwIx9cV0st1a20llM9u32aCWS2mkX5Y2Qfdbgjd8oB4B4BqK4ItXsrl7TfAkjw7RIQ1wvzbfkHouDz16H1qlSppaRX3Al0SMCy+GXh64e1tU01Ay70a8FxcHJXg43OckZJ5yuG9qrj4ceGPsrNDYpcQwXYS5upbpydjOMMnzdMEE9F64rrNY/0sWuoLGquZlZbOFtzPGQVy/8IOPbjGMmo4Z47h7pbmOK71A7hEYT+6jGwHcue5xwOpPHA5p+zhb4V9wtjnpPh/4SbVEgs9DeS2dRgRs7SytHg9S+UU7wCxweOMDmoX+HHh9/tcc2n2tqtuxVo/mAizkjzX3fMSG+VV9OeldffvPY3ENw7iCS5zFNcKwaWVcZDAYxGq4+90Xdz0NVFmRbqQR2sNxO6L9mmlBaMEZ3BA3MhGQS/Tk5OBTVOG6iZM5r/hW/ha407dbaBGrPHlpbqZjIwHcc4Vdw6nBOMKKif4Z+ELq2aWz0IXJkDlZUh8tVAAyYoyfmHQZbI47munsJbK8kkVlkvbgy7/s4mVow5G7cAGAlP/jox0ANW9PeI/ahFHNNIkoLQorGKMcgFtvL4GRsHCleg61XJBfZ/Az1OUh+GHgm4hjuRolnfmRR+8jgcQIR97vud+p9u+0Zqxpnwp8HPZgzaDpzvjLxxwqJBjAzJJnagOAflx6jOa6eyfTrSS48uczTK5BMdwI02kbhk5/dryflHOQeKZZW4tnKh9kTSFo1K/IeBtKREbnbGBlvQUvZwV0l+BF3uc3YfCHwh5ayHw3oZRJGieSe2AjwScBT95zggDOOCaRfg94NjVyfDOlgB2Eck1nHkkHlViPJzgcnkZP49Vc/aLKc3fml5NuWjnUNOABjcAoITgfpzU1pMkU9zKzvHICXMacsFIHLO5wB1/LinyR3SX3Cucza/CfwMZdreEdFiLlSsk9irOylRwqgAdSeh/Cnp8HvBIs5Jv8AhDdIgZi3zzWsOW+bAwu04HIPbGa6qIRxR2xhjRpiEOYA0juduTlsj69aWxCQxwwtbrbSRnazFHlZivUg46ZA5zS5I7pCTfU5WP4SeCGS6T/hCdGmmVsBnsYghycAgbQfQ9PxqTUPhF4Fik2J4R0BHVSVSGxj3Y4Xnjrzwa6y4lzKJ2jE6easWZE2DjOOe2CT1qx5hkhlPl2/lTfIv73HGOOg55zQkr7B0scFqOg33w58zWfCP2++0yFRNf8AhqaZ51khGSzWnmEmOcDJCA+W+3bhWIavRtO1GDVdPtr2zliubS5iWaGZX4kRgCrD2IINU7EosUeydzJMwUgspYYwMk47Ba+Gdc8bar4d1rUNKsdUlisbG4ktYI1PCxoxVQPYACuSdJRfuo0TfU+xPhtcG28CeF18tmWTSbMpxgk+Qnrjtn8hXQW0s0NxcoqLmQ+aFZyMcDjp7VzHgGaS5+HHhC4hj/1GlWZ3kjn9wgYY9P8AD2rp7rzDD9piKOYjuGFIJXnI6+x/KuyxnshlvLcWl5LbLBvjceYrB9qoOQRnHPbjFMtFCXt3DJaQvIxEz8g53dhkcjIbr3p17DLAsN207NsP7wqAAIz1wPbg85puox/Z7iKeOZ/MIMbAKDwR1+703AGq3FruRW5htHvIpkuLRTKJIzEp3cgk42Zzyp7Uy21ANfXFus8c5KIxW+XyiR8wAxgZ6HsKle0exvre5+1M0kpEEsrov/AfTAzxgHjd7069WazvRcOlvPFKhjcMCvIJZeOQTgmjS/qFrGctvNZa1OYwdPiWJXKRBrhDksM4OCBgHoPerF5fXN41pBA8EyMxk+0W77mAUH+D1+YH734VDdGez1C3dLd9PjkQp8gDrGFBblcemRtGMYJz1qO4hlu9Qjliu0uHZXIks9sUwxtzklsE/wC9kYGMVT3TYXeqLs0gjgaaPy5FQbDLB8soIO0KyNw3TocVT8m3+xM89u6pIuZnhJZOcn95Fwcdsc9sdKNRhN3eWsf2lZZVmC7ZIfLnTClsBxjIwPTB45NWr6W5tbaSeRd/ljrtMM6ZPABGVbr7DkZ60bJeZRnS3SRiKKG7jXJAWNXwnJ4Cnqp6nnBAyOatW0R0+WVrmJbkOwOzIyqD5U9AfrjBJxkHimWlmYbZ/OiAuhjzZLeLc6+zxEZYZyeM8kkHvTG0uaa48u3maBUPmLFGSVDYzlGI+UkHgdOO9Da2uJXHwQx36tcLIDbMWyz/ADbV3fKpfqvHcgkZ5PNJb25v554oZop0XCmBztlA4yUI+UEkH5l4OOlJPeTWO2GIM3mgJ50fysEJC4cDByMnDA5+tVnmgh0xl8sW0ioWWEkbo8kkGJhwy8jK9D1HOaWrVzVF+3s1ub6Zoyt1HDgG2kAUgA4x/skHccEAE/nVa1+zjSp3sJkimml8oRAAifJAxt6jPzc9hnOaje0tYdJMm/zkc/LdB8PBngKwBBxjp7tz6m7deVBdaTaTvH9mjDSx3CAjhVAzuHCnLDBBwc/hSNEEyQ3Op2Vvcj7C9hEG8zcCWY4AAfGBwrHnk54FVbaK5GggKguJtUfImf8A1m0nvnriMcYxipJLiZLLWJPLW8t7l/JS5kBIbA2DIxyMkjI46mrkKNZ3MFxF5F3a2tqzAxOR5anA+XcSCAFPof5VL0NNkMkRBqcJSc28Vv8AvVt7onbvIK7gDygABxnjJOB3qzZQLCj6o80MAmyMeWfL2E5AUHBBJ5PqT04ptjI19ZqsKSefeYlnkZGTykPOPm744C9s5wBTjZEX7jT0jEds6k28oKxM5HJXHQgHPQ8nseksPIbeQrHbwxacfN1NZDteX5WQdGLA87cYGMY+6feo7y5tILUT/a5mJ4ngZsycA5YLn5WU8k4xweop+oaWI999OvmX822ParkMox92NjyMYLZHofpUtprCpFtvmid3IhWSENmUlQQB6lgcgj3HBFLpoLpoUL22umty13OFzG0yrbDG7/noM8jJXnjqScCmRW9tpcc6ycxRBWO9iUcryxIJOdyEEE5PB9Ktp9r+wPHcQpJ9kb5liyJVTBKspycsFOMZ55GearW1pZJcuL+ZJkERAluHG1VTlGX0yh69RhuadzS/QrQS2VuxVImuXidHt12tuZAdpxuwMFCpz0PNR2ksNjNJGkMKSfahsuHcMiJkBoy3fAb7vv14pss1i1m6R+VcsuxpRtUhnwY2YsTyTlWyM8CnS3FzqETLao1qHnSRIWjK+USBGdzdFAKn5QCST2qtyxZIXhspQssdrpwuQJDtEUkjAhwQRgoMH3OMEYFXLpLUzXqafLFHavAPNfbujQYYKy45L5HQdee+M5X2p7lbtrmZGu2ZRJ5RMkjMpwUj28Iny53E5x1xnNAt5hMj20v3UIj8s7lU88RkjkgfekGByec1SRnYriWY2cd3PI9wIfJ86GRQVfj5dzDnnnEQyckZ5xV0X328StdRpqEm7YseCqOcnAI9uB5S5PPzH0qy3k7aeg8pRbsw8l4ZeI2LfKSTggFuDJ94/wAOetD3M0nkGW2khuIshbZF2qUYYKhVOQOR8o+Zv4iM4quXQzltqXoYbFdTlmvhJOXxG1sse7DDIVTt4CkYwinHy85Ipz30F1dyMyRRw9UDOsewkAMrN1HQHYmfvEZ4NRQXwhuI5jutomP2ctNiIjBIC7AMoMnG1B/dy3NPhjhuHmSO2jnilXzRJLDsCKQA+3J2xnOTnluR1ot1ZzvUktLWGS5mtvIEsiBeiHIU9QsYICDIPzM2eOlPtvMgt/P+1yJOSEmRFLZUORlpOACeOhGR69az4NUtYZIkub97mZh5EtvCFVVPzcDpvOR0ORz0GedSJJUt0P2JTE06pBNOVLgFxhfLyApBGOvYcU3fYjYtSBZNLuI4I5ZEIKFWUQxgnkHaOW+8PUHPWrN7bSsbhDJFshtWygiAQZPHfPQHBqs0N7cTyCS5ESXEvlNt2mQhVzuBx1BXHfp7UxrWe4kkikuldp7ny2Lg7ii8EgbsAde38VZ7dRvU0I57qGRXkthi1t+drjBJ6np6L0x3pJReWUcVwV3OsbJhcsd7MCPTqRjjpUfkzPLbxmV5jcBncO7J8qHg5A75FSG4uLN/3jbowBIyvK0uzBwOSAeuPXkcdaT8g9SK5muLSFvLDSpEu5g8W0hm/wD1k81dEUEcocQAJACv3R1wM9PoB+NVFvnjRDIYH8xi8rxtnJIwoIPvgc9hUyxRxAKJj5VuoZ2DZDSdhzn+fcUALZxvaojIsckYIjjBbHU+uDnk4z6Cvz48bW3/ABWevZzn7fcfwf8ATRv9mv0D09o7eOIGSQPCoRY37t3xxyM8ZzjrXwJ4xlT/AIS7XN1xGW+3T5PH/PRqmSYrXPtr4aGaDwH4XB2RwzaZZFN2W5+zx8dRjP8AnrXQpauJTbu5W2K7wqcF/wC8pPUDnt2xz1rn/h4n274c+F7aVsMuj2ZwU5/1Cd/xramSKeOTzrgfakO0eaw2g54wPRs/rVq7JtYIEtbV5rW4YFACytLISGQnGDz26flWD4x8SReG/AviG/gto7iays5ZSJAUV1CnBZ8HoM+vII4rZmeHUbOBoIf9JV8+UiDtwwJ/ukY59xVfxTZXXiPw7cRWkk1h58Zja5Ty2dYifnAVgy5wD1HBFXFJSXNtcmV2monhOmfHbxRdax4b03VIrC1t2/0O6+2XMcT3lxEkqyTBgG+RpY1K4UHcpGcc17zJK2pafMZkuftIdtq/MFjcEELgYwOByfXNcFa/BaHQpNOm0XXNS0aw0uV/strBLHNFbh4/LYp5kbMRyScn+I4Aru9WhwZ7W9kheyv4XjuFWHdu+XaeCedwwuTkZAHeuuvKjJxdJWOWgq0U/aO54Knxu1rVPG0thaa3pdlJ58FwdO1IJLBp1ntdWc3IlAa4YZzEM4LKB8oJr3eeWSVhqC7LkRMQGBVW2FsE7V56jOc9B715refAWFE1TRrDUpdJ0vVvOnhsYLeHyLbcsYaIDyyeig53DPPTHPeXNv58MsckEbJHM0ivGRl0LP8AKGIzgHIP1HrTrulLl9l/WwYWNVNqocx8ftYn8GfB7xj4hXVtRs73RNKutUgksUgW4Jt4TMUjeeGeFPMEe0s0TkByQMgEfnxdftAfFzw/8Q/GF9deKfHdzZ6TZanqE1kBcJhIbPRpT8svhjy4sb875IIUTzdzNAJTLe/pNcWmn6tp95pmoWMeoWN7A1tdW17D9oinRlKPG6OCpQjIII5xg8Zr4a8I/sIa/Y6T4K0zWPD3ga5i0680p9TuGm0ub7XDbXEL3C7F8PRXDeakbrte8y2/EjyAvu8+cZX0PVULHt/7SvxP8ceF/B/xI8M+HIrXUJ/DngAavceKdT1l9P1SOSZL+IT2yWtmUaVDYvIcNAu9lChAMj1XSfHHjnxDfePfBmoeH9I8L+LNJ8OWd/pt5oviBr6GQ3ZvoYd0k+noIWR7InJgmXDg7WwVPFftAfs9+GPjnovi+4k8KaPeeOL7w3Lo1hqur2wm+xuFnMDoWVzDtluGYvEu88H5tigblh8Bvhvotrr0dr8PvDun6frqW1vqGmw6TBHYX620kkkXm2oXyi6PKzbtuSduSdi7RxehXs2eUG4+JF5qWuXNp4++I9zc2nhHRPEGkeHrrTdFtdTe91Ca/iW0ucaW6wYe1gVmZdsOZXkbYpK/TgkkuZvJeJJoY2DSgDy488kKoI/due4zj6E146f2QvhzYfEDXPET/DP4ey+G7nSNOs7SyGh2rLBcwz3zXEpjMOweYtxaruU7m8nBA2Ln2Dw5pek6Nodjo9iiaJBaxrBBHaw+VaBVXaI1TaE2KAFEeAQFGOlON0rsz6k7S293qqNIrW7wx+bLPJCRIjbsKJRjB/i57jmrFoUtb6/vIvItnRVXYGzDLgbmwR0zkHj8Qais7eSOVS6Sx3Dt5kLKdrYCgAJuPzLgDKNz+mJElMOnMbV1ilmLM8Aj2KSzkFoycDI5PHUDPuU+xaGaZcR3gsYbCcCZGMs0DnKZwWzx3yeq8ccirFzFdJaXosYYBNczBJJFk2ZkyA20ccAA5ORnnipRJY6ncwyBlgt7dWRJf9W4kJBwp/2QvPUciq1hfxomnCWY3Vx83kwLHs3yNncSx+UkA4Jz1z3oNNxl3fczF57mcWoG60uU2iRsZIyoHAGDySOc0xtHvC9vbLG0TyHzbh1YeYhB5ET8lRzt+h65JqvLrk0tuIWEdq11cPMBc52lQ+Q5bptyFAXGTinrdapIkl5Glz5spWEK4CuoBPU4C9SeBg9+MCizNFew+3vLnTjJeTjy44mMcSlWkDHIUtuyQpJwDj69M0jW9rJaT6j5MR1A4Etq0eArZyqID33DnH3st04w+DWDDObfUYnFtZgKFWIjJI4YgnLcdO+ScjpT7qyuNLmj1REZSBhYQ+ViU9mz68cggjkDIoAtWki3ssYae6srtUIRsqfNQ5IVgcglefQ8H3qOPRrVUNw0DSz2k22RmBZmjXjAH93awIA469ap3yz3Nv8A2pYlLaOU+YMMHZWGSSSOFJO5SAT949CeIbprfTJLe5t/llYmVWYtJKjjcrbiMkhiFGcY64qbPoFn0JJ5PJnu/sduLmODewdMFI0cK3y+mGU/L15NQ3tvfXC3UstxHHbmRg8Ui7d+F81eVP3cM2B19TWpbXNzqmrS3VuqWtlPbAJJLHuZ9rnlum0YJGCc9TxWKbwzBfsJkvvJMThyQ0Vu6naVbpuO3GCew5NUrhuQ3QtZ7a7uI8tCJEkNxJHiQocKVwBgLgHCAbjxx3pzfawLlFl+0xIODOMNJnG0ED5fl5GPujjdzVjVNOWK4ge+uft10T5U8byErBvUhfu45Le2SCQMDmpJVTRZLWS4kYO2IUaVVdnGfl/coBgAjjnjPI7i7he6KcEF28aFgLa1uXd4bhySxbBPyqBktjJDnnA421xPxo+O3hn4HaUl7rd0Bdk7IdMs5Ve7lycMQu8CNeCTyDxyWPFZX7Rfxns/g94HvL2e8+z63MksOk2UsWbhmwMs2GwsalgSF7becnFfkf4s8W6l4u1u4vNQupLq7ndpZJXPzSH1Pt7Ucy6s4qs2lZLU+1tc/wCCk8lnJqEWh+ELSBJjtjmvbkvKMAjcyquBnjIHfvXn3xH/AG9PHvjzw7HaRSJpr5ybixJRh9GzuGe/rXyfJp0t2VVG2k9h3q1H4ev7SMggunuef50c8U73MUqjVzp5/iT4jn1eXUW1a8W/lfzWnE7h2brncGzxXrfw9/bS+JHgG1S1GvPq9kFwLTVMzBTu3EhvvZ6jOeB9BXgsUKwW7eYG80ngEYqMj0xuxxmt7RkriUGk3sz9Sv2bP2w/D3xfuINC16OLQ/EJCiBEl/cXDA5YqeCG5JKnqDnJwcfT8ttp73syw7FeRxEUQqQv8Tv0ODjHPrjvX4P6TqV3pN3Hc20xhuI3V45UJDIwOQwI5BB7197/ALI37XUOtQw+DfHmoM90wENlrEmGdwcYjkJ/i4wrH2B5xnOUddxp2VpH3fDYmGOO5huJhEIiuwy7Qsecgg47D1HemwXc0bP56PIxdXCu43EY/dpngZPBx65pu24ktxH9qLlI0dg0aMhbHCcY68d+wqSLM8ZDRLNI2fMhYjDyE4xz1CgcVj01Lt2LEgeYPH88czHczZG7ecY2nuF/kPeorm2dim8xARyBVmjyjM579Oxz/kUx7VUkQwK2FU/vY3Occbm5OOvAGf5U8tG0yxukhtgoZUKbiFI4H/AsY/D3NNeRLJzdGNopnhKx58uFFOQM9XIx7fkfU18Oa9byNrmolp3LG5kyWC5+8evzV9uSGO4mhzvNwX+eIFgQoOduD+H69sV8a6wjnV747if3787D/eNZyS0DU+p/A4SX4ZeGDHJK1wukWZCDngW6HAwOhGf1roxgpFNYxOrL95QDtYH7wPbPbP0rn/h/E1v4G8KTpGoibR7MFuMZMEfI9+B6frWd4+1jXdL1jQk0y/ttI0WeR59V1b7J5/krEY5BFgkCESx/aMyuCq7dow8kZqpS5IczVzpwtB4qqqUWlu7vbRN9E300STbeiOya4Z91/DABEU2uW+8wB64H93n/ACKh1B5bODzo2jNvPkyFFzglcBhzwDzk/SvF/h9d2ngnWNU1RV0Pwv4BtImtL3UNMmFnpt/eb4US6jgZAsO0+dExDtuLRLvl2DZ3Hibx7omj+Ar/AMWadqNlquhQW8jWt4t1G9qJiTH8shcK4DZBGc5yo5OBlRrQqq70f6d9baee3y1PQx+WVcFU5YJzi2kmlrzPaLSckpdeW7dmrpO6XYuEtLrybm6PkTghQJAi7sfMD6ZxkHPXIrMie2Y/YrmVvJuVcK54edAQFXPUYAzgYyMHivKPC3xp1S713RtNv/DMlvY3dqw8tnt47iWURwsSu6QHYrSNsIyXXaRkg161eSX1lY3okjt47mNHu4riWTZkjOCTjGRjB5xg+hrvlRnTlaX6Hz9OtCorxexGluup2v2JVZri1lXfPJuCkLyG567v7v1qK61JLm3WcYiEDKkcCou1CAM/NzkZyAP9n8a8Qufj14gvPDuo3s9nYjUJLRkBQNGkEsdrdSTRsu5jIFeFF3AgHd/smvcppXufJvhIhEkSmWOJcAbSCTyevJGR2rWrQqUmvaKxWHrQrSvAjuMyyNIqzwRgAo0Y3IVIPGSMjJwO3c9Kk+0i5urRJJBCGldSxcHC4XjHAHBIHHFcf8afE134A+E/jjxPYvZz3eiaHf63awXRaSF5YYGeONgpUspZRkKRxkZFfM/j/wDad+IHhkeNfI1ayuD4Z8OQ69b+d8IPEdl9qkf7ZmKXzLr/AEaMfY0/0iX923mPj/UvXLKSTsemmlofXaxn7RFEkvy7j5e9lIJBbnGOM9sk1LNbme2huYRLIryHG4hcbd2QACR2PHHPPNNkbabXyoQjb9wlRRkEnp74Jx0qeGJnt0Ma4UschUYgEjB4BI5OfzFW+5TexK0Ra2R/s3nwsAxlWACMklR90c5PHTP4c0t7qAlDFvJhuZThpbdxID6ZUgbwOuRhhgYrI1nUZ9M8KatfRSLHd6XaT3awzFjvMaM6jAYYGV5ryvwr8aPEuv6/pthcXOmXkMj2sl9HPHBEuybJUo/2hskFcYAJ6AgGtKdCdWLcdkcFatCjLklu9j2GV5ZLGS3jMsizsYxvkJ64BOWw3QnB4ZT1DCrr6kNtvZ310jxLID+7Us8gAJVcAdOM716heoNVNSidE8+WymWdWLgea4V5FHyoN3qcANwQM4rwKx/aC1eXVdNVtKs1Ei3Xmrvd3Lu2YQSiMUIQYbIZXLA9jVUsNOtF8nTzHUxFOjZTe59CXF2fNvJIbgecsJjill2oy4yWWWNsE/w/MBngdOpge0igtri2muIIrVbHyxbxyLIMnOcbgNpJXpyB7Vgz6lDY+GtY1Fryw0c/YpZpNQ1dDJZ2SrCWMkp3xF4EOCULRkKudyg5rirnxl8Q7jx1qvhXT/A3hSe50fRNN1CW8uvGN1AqJeNcIYY9umOWCS2U65bG5PLbClmROSVovlOxSXQ9ct9XsdLmDWyvsS1UI/Ijdy2Ad7cY+Vcc/wAR4oPiCSMxbbGW5e3jLRoAwMj4wWJClRwT0Jxnpwa5X4WeM9N8e/DTwx4vNtDpkniPS7DUHtPO8w2wmt1mdWICg4Dld4Rc4HA6V2v9o2t555+0bBOwaTeCm23TPAB/vHP13H0pO25fnYr2Wo2upWxtZpwqgNc3cko2eb3+UjsMjPfAXjrSWCRabNGlzbSvYOCts03OzJ6bAMAtn68jpnjTbT4NYSWW4wLuQh4j/wAtIFAOzjt6ke9VrgRXdvJFqV7m8XCrGg+6+PldUHLEjnv3AxUXQr9DPSL7LqX9nXJmisb87tsirukJ42uecZ6Ejn7uSM02w/0K4u9Mtcy3UmFV2cYEigcs55KkckcnIPFS3MU2taFOt3dJHd2WQwdFGGwMFs+o7cA4qvfzz31lbarbbdPhjRFWYhcO38LBRnYASQM5+90xVIvV7/12GQvCsq22rzJKwY+Tb2xKsZCBuyDyc5PXCjBOM4IW6uGsLlrXLC4ZpEFvEf3casA67nPUZyDu4wGGOlJc263tkLjTg1qt1tjZUXdc3L5O/G703cluwz8uM1WGqyRQ+VLDA8W4u6S5MKSE4+ZsZldXBGADjIOelUtWP0Fi1pJLQiWIFXAkha2jaIJ0DCBQCzON33uM9OOlXVaxTzvPeRBgnE0m+6mDAEkt0QfKOh7dR0pbOWzlv/LMT294CWwSPOkPIOXHEa7sjaPY968i/aq+IMfwp+D2rXdjqC2+oXY+x2sEL7QGk25KyEZdk/1gHoCOnReRlNqKuz4C/a5+NUvxJ+J1+IXT+zdPLWVqsR+UorHLkdCWYsxYAZGPrXDfCz4USeLg9/NGxgDARgfx8dR+OOK83kkm1bxA8W8YM6rgDoDjjP5191fB7wnDpvh3TVSMKWjGfU9efyrzcXJUtE7jy+l9Ynd+v9fIyfAf7P8AZSjfNa7gq7eF7447f5xWzrn7PUDxuYoBGhPK7e1e5aDpotFLIAin+Hrn0NbTRM6ZKEp644rxViZs+rWFp2Phzxp8BLm3tZWgt23dlA7dOleH654RvNGdreWJ47gZOH9K/UybwvBeW5la3DI3BA5/HFeH/Fv4KQeJI5preNY5eWBXvjtx713UcdOK5TzcRl8H7yZ8AlJLYsk2Qynnd2qay1BrSZJo32gHOVP617XefCpbq4kgvbdre9Q4YnIDeuAK8v8AHHhKXwvfrEQNsgJXA444r1aeI9orHiVcN7OJ+ln7EH7QcvxW8BzaPq80Z13RCkfnsp3PCy7UmJJ+ZvlZcDJ4zwCBX0/Akd9OhgYoTHsMiyEHZ/CpBGSxGCcjOD16V+Nn7KfxVuvhj8a9AuIpGjguZls7tGYBHikIU544AO1sDrtx0zX7IxbJ7BY7Wec5jDoHGCBxjkjIJ/8Ar9K65Kz9Tz4Nte8TCMNviJleEHaqbAySlcbeg6D074PUU5FMxM7vKLhWbDBDtxkjdgjpj+tRMslt5k7eYGUbWbCkRLkfIuO57n/61XFh8lAoMiRjPmshyD7DuAPb6VNyiCw8yW/3xzyNHgD7QEBB5BYnjrxj2AFfHeofZWv7khpHBlb5vXk89K+x9OUKWLeYYjIC2CDuORx9Bjp746Cvky6TdcynDcuT1HrUT1YkfR3w4nV/h/4ZiEUBX+xrTPnNg/6iPrntx19vat6xRLN5opTbD5sAuNx6dM57/wA81g/D6XyvAXhN44yiNo9mzuYT8v7mMHOcZH9cH1rpLy2lkBkbzg8Tbg3lgHHf69OfXtWqZPQ8n8W6X4U+HC+HL3Xbq4j8G+F7eaS3e5jm1C2tZy8Yhd9zPIZEBlETYYIHcZUlAcrT/ANx8T7m88SeK7STQ9LlDy6L4euLYZt5jCIo7++UL+8udioEQkiBURcl/ueyavo9p4r0d7K+08ajYXKAPb3cUTQsM85VhyvTg9gKo6Npt/5+oy3msahqCzSgx21ybdI7IqTwmyJGIzyN5Y9PfPD9XXtE7e7o7LulbXySSsl1+Vvq4ZxP6pJKb9vaScm224SldqOmkpNyc5N3cUkmryUvNovg3qb63ol1c6tp8z6farZ27z6ErSShUjUl3MoYuBGNjnkZJxxXZ66WutGubRflvhuWG6vg08efmUM8ZOGyDgjocn1rC8bfEDVm16w0Hwxo8niC8truJ9dYXUXl2luUYqEeSeNROxaNwo3MqZZl5Td0NpeR6zaRz+ZIJJkV4pb3zI5cMMj924DIeeVYAg8EA16McSq0+X+X+tO9uvZnivLJYSlGpNK1RXtfVLpdbrmWsb/EtVdHkc3wHjn0bUYLW8iW6nt47eG6nsgqQIDKs0jBHG93+1TYzgLlRg4r2K6dGsUuYYxtLL/oynJQKvfPG7pz6HuarqgnjBhAiYHLEyfIFHUYx0OPfp0p8txDcnfvMFxETlElYb4+cYAwAO2T75HSumrWnVa5nsc1OhTov3FY4n4zaZFqHwl8U6c0UyWeo2rW84/sS81jdbynypYza2UiXDhkYrmN1KZ3nhTXy7q37O/izS/Dep63458TX89x4kYadc6LBY+Ldcnhswkgis5Vs9bcvGA0zurmWNJbuZFldGTP2wieYp2iZpGVnKq4AUc4GSOfXPfNK6g2ySiBNxcgR7j6An6jH5Y9c1zOKb1OrlMTwXe6xceCfDkniWzh0fxXNp9tJqdrZSCSG2vGiQzopDPlQ+4LtduAeW6nTSd0jngQK6v9+RB8w5ODnHHTvVhpRa20axna3IkypZW4BHUEd/5UkcsdsQMvEZUKtJjgZbIIAPTp09adtC1roVvE3haPXtK1jSE1NLS4u7aS3jnCb0XehXpu6jPTPcVxE3wgvba30i4stYe21O1iSA3/ANggdJ4AyuF8sKApX+Bsll3NnOTjvpEbJQOlxI0uRKp+ZuFIGcDj8eoomysUEiW7RsqszOnBy2Tnt1GM+ua2p1Z01aLMKmHhVknJXF1C8u7qwuIk1CWGUpKIGaEExMVZVfBPzFck4PGa8xvfgHp2rZe9m/0ZNn2K4isInmguI4lSNn3D540jjXMZwHLOSTwB6rcCyktbe2Nvhgy/vfKB3A5yW4AzzzWrY3FtaWbzebLcSW6kJDIwUHgD5V7Z4HOetTGtOknyaXMquHp1EueN7HMQ3N3pGkXFxY6dJ4lewhZ/Js1it5p2RPlRFkkVUXIKqGYICMbgMmvB9R8Paj490u6t7Xw4mn6dpmhy+HfEejabE+jWmsWBuEK6TYfaIl87yLdZUjvT5UJW6mWDyGunmsfqC70+eWaOae2jcMm157ByjrkYbcpPzqTj8Aaa62uorFNKsd6kn7qFbUbSW6lj02EAcg9CD9K5JNPU2SVrGL4Ul0jxbptrqthbX4tZZ9kaaxp9xYXAVcmQGC4RJUBK4G5RleR8rAnq77UYLCwknh8qc9ERCDvfoBnp171m/ZLPZGLWd45JLhVeKWUhlyQz/KTkMVX8ug5qW/tIUvJGgjgt3KiIOsQwrHDM54/hRf1Gah67s0texJcWJ02G2Nqiy6gXJwox9pzy+4nJC9854wtKLrUHgGo+aqQIN7WYh3uAPvgtwd2Q3AA6Y5rMJjtFF7DG9nAwVZYt4UpET8gBbox4YgEcH1xWjCbuwukgisYoLe5OVRpgAr4+YYAIyQM4yckHmmKzEuraOHWI7xLVLo3UOwdB868qcnpwTz1GOlYdkiWOo3unTxQggNNCDN+6hVh85I4JYY4IGeOgrYK6gumSQCziBsg3lOl0w34GQAQMj5SRz39RUWr2tnLaafJartvVUS2iJy7ggZz16Z5Y9M55oi+jLTaVmYcv2jS4pHjkkuYmQec8gKu0TZxuA5j3HHCjceT2qzBqUZuRBdA21yV2bXZYw0QH3VJOIo+vGNxxzV/Tjb6TfeXqOyO8A8xPKLPGpbqPUycZLEZI6egtatG+rQTBrJYIIwzJc3DBWDLkhlC84yM844PTmqv3Bu+6Mq80u1ltJF2QwRuuzd/qbYH8fmkP3fmHpwa+Rv8AgoB4S1vxD4D8M65bxS3dvYNNBM4ClI8gfOQuAE+THODk19nxQPHYrfXL/Z28rzZAf3kifLkrvfOB7Adq5bx34WfXPhZrul3dtb3RutPm3lWCyOSpbjcpGc+vFEZWZlJ3i0fiN8PNOu7jxY5vk3mS4UxmNSAfug4B/Gvvrw7frp1rawqNzIApI45zXx94A0a5PxRsLWWFozFMYpIXUq6MvJUjqCCCMY7Yr6513UV8OwLeR2/muxwEUZB/D8K8fH1FUqrlPVyyLjBuSO6h+JV7pXlpBoN5eIOGmj27cD68/lXc+HvHUPiGMGWzazdhkwuy5/Svm3VviV4mh1HS7KLTE8m+jWQSqSQgLYYNhCBjHIzXqnw7e5uniuLuMRSfdwOh98/h+teXL3eh7dOHNds9I8VeLrfw9YOscTSypwqL7V4nqPjHxlrV0WsNJWKxBPyyYy/ocgcfrXf/ABLnSXUrXYSI5CAxbpy2M/rXlPxKvPFGnaVczaNII5Em8qO0WHJZN338gjjFXSlfRCrR1u9jH8QaZf3tyLq4g8i5Od6fjXhPx504qlrOQVZVwc9/m/8A116daat4qFxbR6gqXBlXMjIm0xHHTBzn/wCtWd8Z9AF/4LlZQTJFtBwOwySa6KU3Grys4K1OMqTsrHzt8PdPutc8dabY2UXmXkk8UcQyMlywx1xj86/dDSdNaKysVkXyZoLdAzMd3IUBieeOeB6V+S/7FXgq5n+Pnhi+vLcraNc+aFkTIkCxtgD3zgj025r9dkcPJ88odiMsjoeAOgB46HPFfQOXN8j5jkcdZdSu0cs1oZYiIlJHl7mYbx13EHpxnr9e9TyQxx7Xe3GzICR+Uwz6Drg//rNOSyZpWkMayMflG5gQq+3zd+Py+lQIqwEmaApIrbBnaxbIzkHIHcj/AOtTXYzY6GLybtZGQKQy4QRFhnIHY9ew7dT618iXkkq3c4a3+YO2ePf619epCqXcU4kDS7gCpAOBntgnjHH/AOuvkOW4Jlf5D94/w/8A1qJ62IvbQ+nPASJcfDrwspmijb+ybM5WQsR+4QdPxxXQQskqqNqM7A4UQs5BHHr/AIVj/DR5J/hx4VZnkK/2RaYSEY/5YIDknGa2pVNtE0LRBNzFl8yU4bnOeMD681XSweZWt/tFrcS26O8aDDr8i7uc5OScDp/M964H41XviPQvCOo6x4Wvba21e2gaeV7+2W5PlKvzGJA6qJQDlS+VJVUbAbcO6volbMoEeUIDCNWf5SRnBwOcd8/zNZHjbw/P4k8J6voenz/2fc3tq6pciJQImPRyFO7tjORntV8sZ+7J2T7aM0pV5YapGrCKk4tNKSunbo090+p4NZeN9Q0MR+FPAd3o651GO0tdf1PWjd30r3EQnubqWHygJmyzk/vFAYAbQAQJ/AvxAs/DPgfyNG0Sf/hG9M059StLvVb8wXupWisz3F4kbQ7XySz/ADOhLSR7xEkiMe2t/B3jGTX555tQ0NopdWs9Quo7Rpo5ykSKmEI3DkLyCDnJGai8beD/AA7oHhg2fimPTLrwrZOstpFr0MkyW88W6SEyvGMJCqK0I3plwVRmcyEPy4rDqi1OhK1k1q1ZbWW2i76Nuy7H1eUZtDGxnh8woubnOMny8zlN+9zSaveU9bRXNGK5p2SbuUtI+L48SeIkhOg6pZRPp6XcY/s+eWYlpnRd2E27CgVs46swzxXpNs8r3CLHKxlXhGiUFMHk8qORn0r5njt/FUklx8Um8O2dn4at7Jp00l5r1769VC8qTiLY7JG0khZVEka4AeQYAx9VQRIILO4mMtuxKsPOk27eBvCoOmSOh4rpjiaWIX7pNJd+q6NeTPKxuX4rK3GOIlGTkteVp8slbmg7fajdX9V6Ll/HfiWw8AeFNb8V+Mb6DRvD+lQNc3V/d/JGgGAqjALMzMVCoAWZmCqCWArxkftn+D9W+HPw/wDFejeHPFOqz+ODqraN4fsbKGXU50sRL9rfZ5yxfIIsqokaRy6BEY7gv0dPPDHJLBZCeS4kTAZ5y6DJByBk/wAh+tfG2nfsc+MdK/Zd+GHw3vNG8Da/4k8OLrXnTarf6nZII703P+ovbQxzKmJ41ntnjKXCEruQorFTclsed7Rnp1/+1BpcNv4V1Xwx4K8U+OPDniu9h0/QtY0CPTpre/mkhkkZBG94k0QjEVwJTNHGIzDJuKhc11Pwk+NNr8aNFj1zwp4W10+Ebr7T/Z/ii9NrHZ3/AJFwYW8uAXDXKhmjcgywRnauTgkA+c/DH9ln/hVvxH+FlxDqWnar4H+G/g66stMjWSWO4/t67nJvr7bhv3U0JYbHldY2bCIMBqX4K/s6+Ifhj8U9D8SQeFPA3g+0sLbWrO5uPBUclu2vG8vIJoFubee3dreOJYWZUS6kCPtRGWLMZlc7eo/aH0Le3dhodm1/qAMdnCjTSzvEdqwgElsDrgY6e3WvIfB3x6XWdRi02TRGjvbpsgRalbBFgebbFkGTPmYALJjIPavar7S7maC4tftv9n7SJLfyJAjKM5OwkEL3GCCOemK820H4UWWieKFm0jWtWj0z+yxaWkMco85GErySI+YyNh3dckg59q76LpKEudXfzOWtUrc8PZ7ddj1DSdGW5sJo0uFUMQqooyuRg847cj868Btv28fhS/hT4uata3t/q+j/AA7e2jvtYsrVbi1vprlpEiS0YPmQGaIx722RklWDlDvr6J8PITaKxgSNIpCFiVwzALj5WOOoOffpXyZ8ZP2P9c+JI/abkg8Q6Pptj8UF8O/2IxMsjwz6cg3pdIIxsEkqBQYzIQHLFSQFPmycm7HY5tnsngn496F4/wDBPjXxFounatpF34bvb/SdQ0i8jjSa21CzBM8LmJpYm4MZ3ozqVfrkEBPBnxH1PXNe0mxvdKtWuNVsZdSGoWKXKSx7REeRLGocESAYQkHb0rmPhz8OPiE3hDx6viPU9IXXfHHiObVrqS3LSQ6ZYzwRWsVvEwjjM7LbW0SCR44yWJyCRubrNN+GEHhvxZpusaVY2lrptjpU1u0WnzSpdTSs0acknbhAg4z36cV101T5Hz/EzmqOr7SPJt1OX+NP7V3gP4L+Kk0vxRDfX+oQaT/amo6jpdijRaXp8l9DYxXdwHdWYGaYLsgEsg2u3lgbd0GmftM/DjVviNfeFY7XU9PsY9euvC0Pie9tgmkXOswiJ5dPSXzN6zbHPliVESVo38tpCFB4r9o/9l/xb8VvidqGv+C/EumaSuteC28Da42oxOZ7C1bUI7ia4hjETC5eSAzxeUTCVJVhLn7udcfsjzeJf2itM8Za7pfhG00PT9euPFdpd6Tc6lFcXd08MKxNLZ+ebWF1mjWWa4jJa4NpDujjBlDcnvXO2PNsj6Q8ZeLp/BlvYTwWkF1Je6hHY+XfXHlJA8iMSSzZyQihSSDywHqKyvB3i+XXr3WNJudItHvdEW2uJLqyvxPDIsrOFVhgbcIvOAcZzxVj4heE7vxfpulW1jJZQyWmpw3uzUIxIrJGsgMezPztukBI4+bIzxWf4a8KXug+IfEOqX0mmvHqOm2sdtHbW32TY0RkzwpYPnzByeeoOK7Eqfsn/N6vv2ucrdX2yS+H/gf5ndm9axlmt4TBawOVYx2uSo/hI3YAX+HOMnniqEN/LY8eZFGs7DzJtxWRRj5VJOSUJ4BByOBu5yIHVtVw7Nuii4BGF4PDDA6c4wAPzrRt4TM0kZcmBQpd2UlFBztY4PQlT1GRjrXPZI9DSI6SSQWIVJMM7hEAyuZCflA2/KCODlmc8cnmrxSeW/t7W4e7Mkys5Zp1CrGPvcJjB+ZRnnr1+WoYLqJBd38nlC2tF8tllJIlTn94M5POcD15HpTbJfst00gY21/PMwt7Ro8jyc8LjtgklmHQn2rN9jLoW5IZ7e+jtFmlvImQPNFOwdlUMMY4GS3IwfSo5XW8lhitbaQwI264TbtxjO1NrYGc8kDtjrmnwXxsrg2lyyrqc6GXzmA8rAYgDOc4UEcHrk4qrcSS20MdtbvJ9tlB/fLcF8HqXdQORz6dwO1SidT87dd+HUcfxSuvEEUOyE6jfFwOACJGUcD3LflXs+g+GP8AhJLcFk3RkAhQM8f5/lVT4r6I/h/xfqlosUnlfaGkVipUEMS2eevJPPfB+g6j4bavAltHtwGAA25Hv0r5nESlKrqrWPsqNKFKmlF3Ts/wIZvh/CZ449rJt7Akc+mO9a1rpaaVdQQldrhTwDxmu1+22zL5gKnHfvXn/i7xf/wj+rWzJpl5qMk7H5baNW2AnqckDAx+tZONzVLojO8djE0TOPljXnPY9f6VHpekQ+JtMiaQEAJg7jzzn/CsL4l/EC5Ey/Z9Aubn5wH2FFxnvk9eOePetb4ez3PmndG0do+SAf7oHHP4Hmpd1sW433LVx8PtMsbRnRGZgerHJ/OvNPFWgxXcU0MkREToysFH3TgjNez+JdYgFvMy4yTnaDwD9a8c1+7NzlY5AP8Aa6jNaUXaXMYVIpw5Q/Zu0aOL4l+C47eMxyWMxicvkgnZJ+fUc1+gUJDqybl80H58pg+/v+NfG/7K3guW78dpdESOmnIZzJDg4cjaoIPY5b6cfQ/aLIzkqjkM2HO8dP8ACvfw8uaLfdnzGYOPPGK6IqhvOjaSMRzBmCDy5CATnB9h2/X2p4szblQsbxyFiS8b5HrnBx+VRsjiQNLaxywIvzNEfv56deuMetPkQWrl0Nwkj8KjZKn055wOtdx5BNArSSCZZfnBxtPseh4/+vXxVqRZdRug0DbhK+flX1PtX2pHA7uI3eO5jPzbhwSCeQT+PHTpXw3rYRdavwEOBcSf8tP9o+9QxPU+uPh3NLYfDbwu3KwHTLMu+TiMfZ0HBI6Ejk9sn0rdu4wxV18tVQ7xcsdyRt6lmPzdcYHrWJ8OpWk8AeGEk/cgaTZfvTh96mBOmOEJxWy7F4lktSWjQZECsCBx13H5UOOec/hmtES9hzXheUkowaIBt8rAdzyNwxjjqBn6YqqsH2aTfMFhs2bCM43MPl9G5wTntkY6AGpnNuqtNLhJ1VWRWfDpk4B3t64HsMdDVO5uZrFJrq8nzbJEZ2uUHlhEUZbI6kAfMSu3PP4UlfYlu24TyuUU2ySQTSEpEYyGd9x+bcT278DC4yD0rM17wlonibQbnRfFCQT6ZOohlsHdx5nQowYMGJ3KGDKAQQDkFc0umePvDV5LawaPrdrJdXdml9HCV2i5jY4BxjKvkjK9RkZWtPTJv+PS4nR4xtZvtW3f5zEYO5hkKOM4z6c05RbTjJaMqjVlTmqlOTUotNNOzTWzT6NFTV9aXQrLThJDcGznkjtp9QneK0Cs+UjMhO0/NJsTCKTulQAY3Y4HwSZ9L8X+I5bq5kutTtNdubG+hkvHa2eyeOO5tZIYjGdskcU9vGQpQOfNZ2kZYyex1Lxfo3i7SoNPtpIdRs9cX7PEHj8yK6R4XlKlSMBGjVwS3B5GK4XxP4M0i21mx0y9DaV4dvo7/XNfku5plhuJ1a3ihtppC+BEyzOPLz8wt1QDywynjxEalNqdtvPvp2+972v3PpMqqYauqmGl8U09Ur/D72iuru11GOkXLkejVz1USXmo3yhE+yC3bILphtpHoeSG6YGBx61AIbO1e9a7Zr24gLTMg5JGMjgd8cYJ+leTWvjzwp4f07xD4p0Gyg0rwdpelrJdXGmRiO11CRQVjS0fesTSKqeU21fmY26M4MXlr2viH4teA/hjb2V1r/jDw7oVlqm9rNtZ1OGzkn2bd2wysN4XeuVH3dy+taU68Z+7dX8vzODGZfVwlpyjLlel2rO9k2mruzs07XvZq9ndLp4FvVsJCkMNtCwADFd8mwnqQODjPp0GaZd2Fviyt7i5n1NQ/wDqQ27OBwxCkcAgdT3qtrmo2eg6ZfXusasml6HbwyTyzynyktolXczPIxwEADE5IAAPTmtaBYUhiS2hWGWNvlFuu1ccbsgdARnjkitedHmpFW3sQb2cQWUNvtRR/pJ3tnkggDtj35wfSiErtS1/tDymDFjDbwh2TBPQ4JA9z64qxBNpmp3moBdSjvLiydbS7t4ZF/0ZyiTCKULyG2SxvhsHbIpxhhS315Z+GdI1LUry+t9L0u1ja7nubzbFBbRIpZ3dywAVQCxJwAAealzVjRaFcRyNqCTFL5/NGNjAQ/OOQTgrxjg5B7VXuzFZ+diCK22lmlMl6AxbG5WUkE7s9Dnt3FaN1psl7bENM91KAWTHyhTtYZGCOTnHOeGNVtMmsNZ0bTtW0SaymhvLQTWl5bMssEsbhXSRJFO1lKhWDbjkNkZFLmRSM25nwZ0aezCLBk+XJnfuLbwMbcZ4bb/ewRjkU8XCJI5klEkYY+Yysqo2SNx9fmABxkcqykDOTJoDJr+haXqVjrUep2NxGL2OezmVoLhJDvSWN0zvUg7hgkYIwcYqZNLOoXsiu0iRrPveRbhyZAOVJGRtxhcDk5x2zmro0TXUI7UX0UaSuJJkwhDklfMLkOxKkEknB64ArJvz9lhnkeVngcebITGg3A7gHCr1IA4J55Gc44veTaxarHYy6oo1O5gnu4bZpVMrxpJH5kiI3zFUaSEEgYUyLnBfmM3NtpttPcavqEVrDO8VoktzceWu+SQRwxfMcEvJIqKDkszhRkkCldIuMkndsjsrjFvJuhki3jd5LDfk8cAHh8dSOMA56ktVaO5d5Gt1jEDRfLMA2VIbkcZAH3uc8cZ6k1JfeI9G8OC+S/1Wwsm0azGp3vmzRxC0gcSYnmBI2RnyZfnbA/dPz8pwxHt2nj0wXdtDqt8j3MVs1z5bvDC0ayMkK4yqmWJWbBAMign5hmuZFJxTNKC3FnbCL5dzHYqMcBGEvlncMsCnzE/h2zw1bmKKIBVzA2Y7nyvvzBmZkKJ6EZ+b0J64qS00kvaGKWdluQwPnIQ+5gGJJz1JZz6denao7KyjEMZwjlF2qrjHzDqNoxjJz0x1JwKi6uK6b1ZUa/jnht2uAs4hi8qKzjA2kZXDZU5DYB5xtGDjpUsV9LaI1wWmM6qV3MwJMaknADByvoSM9iexq/dWPyRSQoz/AOw3BOOMZ6Z4GcgjjOKpnyizCV1jgWcqAhIJIK7SwU8H73K44Iz6VSasO8WtDTsZp+biS4SN5I1Zi9sdqggkL5gOCFz2/PkUC2lvrp3MkFxLCqAMgC4BG7ODu64zwRUSXBCzFIZFMLBJZwNu1du7cGUAsORkFc9atwiK2TNy3+khDuukxlgxH3cDgZYYGPSo6mbPMfi18LrvxZGLm0RIrhYmR/O2hMYwuCp6gk8kdPoK8C0uzvfDepzaXdKIbq3fZIvX3yPz/Wvsu1SeW0ZZhNIqtmMXJVZDjoxI4HOCO5xk14F8bfD6aZ4uGqB18q6HzDgFZO6nHTjBH4+lePjKSjF1IrXqevgcRJtU5PZaGPaa2yjEg8xfUcEVV1vXLKMRSSzRwqRjdIPWsorBfQNB5uCecoeRXn/inwPa/bUnubq8mWJgw3TYHqMgAAj9K8+mk2fS0rSWp1ev+JdDEILahC7Aggk8D/OKpWXxCsJJgttPEyL2jBXFcLqo0O/gurcxOxnbf8sccbL7AqM44Hf19aPC3hLSbCWNvshjZVKrvIJ9u1aTgl1HUstj0bW9QN5aKYvuuhK8/UVY+EHgKDxz4wt7C+dltSjzuF4LKuOOvGcj8vxHN3mqxwvHCi7yo2hV7f5zX0d+zT4PezsLrX7q38trkCK2LjnyxjJHsTn8geRitMNTvNX1PHxdbkpuz1PTPBfw+0LwEZxpFi1sZiPMkJLMcdMn09v/AK9dRtkCtkpnkAqD+FRhzIxKYU9mI4P1pZ5FjTJwh7OecAn074r2klFJJHy0pSm+aTuyoI0WVZXU2sCjC7fl8xh0LY4xzxnr9OKuN5iNEUdZmYEAN0I4OcjsPp3qGO1k3lUlO0EbiCC5x/Dn/PB60GVLidcblZSdpQgB+OTnoQD256VsZMWKO3F5Eyx/ZJs5ZgeGHpkcHk5/CvgnxGJl8Q6oq3hCi6lAH/Az7V99Qv5SozBHjVh5bIO3rj8+nX0r4A8SNE3iLVCZ1ybqXsf759qVhcx9p/Dzzrf4aeFC22RZNLs8+XnzHzAnHU5/AitYNbyTCEMLaZmBa1C4jA65Knhjx1HX8Kwvh/KF+G3ho+a0cqaVZGLOQFzbxgk5GD3J9j710kkMuDB5MV2hcPK4PzEZzznjPbGfpWiMm+wmolmlAaGOdIVBcsBiPPVgpOCSD/nNcP8AEfw5a6/8MPFGnrdX6xSWUo8gSHzpljQsIycbwrEAYHUNjvXZXJtyBckzWsCISCoyN4Pccg47e+ealsJnncuZLa6E+XzG2SuB0PUHtz/9atItxtJdCZRU04vqfNug+HnHju11a50q6ksWs7cmSPwonEplGUdtobOP+WgySDyeK+hvFN3aP4Z1aBxd/wDHrIrQWZaGcjb0jPHze4NQ+Qba4nWSOa0iRmmmmhO+OTJJUMo9BgnI7AZq5LqVrq+lrH9st4blgpCyjAEnBwyMQeuMj3retWdWUZNbGFKgqcJQT3PmDwh4WutLvfDtrrnh3X7KOyhsormXT2uZHjMcF8rFZk5wWmh+RGKgOBzgmvoLXr9MwW32pnUYkWO6TYRwRySBz6Due4xW5A9xDfEW9r5sJA8028v7sNgYYAnjAGCBngiqmqyx3lvuFtdQ3AKrGXgDB2OQOOQQCSfbk8U6ld1pptDoUVRi0meJftA+CtVvPh742kuNXXULuXTZoPCyxWMFzEL6RZyLe4t3t5YpfMxHbK8iksk/lKBM3mTfEnhHXPif8NdY+ICfD/Tdb0PWZdBtL20s9I8JXFrcEE3xt7e6tF8ONbu6OJF3xi0jkLOfOk58j9MvFfha2+IHhHU/DMmsfZPtlv8AZp7qzsreSYxEgSK0d1FNC6SIGRleNgwduAcEfIFj+xd8FdL8E6j8Sz4lml8P3ukjxBJqMfhjRWg/s1Y5J451tJtLl8pvKkG5Ylj3lR+6UqqL4ro2rX1a1+/z6vsuiXyPr3mCq4KdN2UvdW28U72ikuWCuuab3lLay5k/QviPcjSfiX4kTxFcePPE2leHvCGhzOvh/wAXnQfILzav9qvrjZeWFsdwtYt7cbcDaiqDt5b4VXWl+Hv2aNV8TT+APiJoFvovgiW6u7dvH93DpwubGNXmsbRY9VnubJlmt2iw0SPGkckUmCWjbc122tfG2r6hr8V/rPi3wvM1loV6s8MDyeNUtlkza2ywRJuhgke7uZHRNly008TMtqmE9z/4VX4V8S6f4iSC6u7rwj4ktbyx1PwvBIg06WeVjHdzIVQXEE7sJVkSOVU8wyyNGJnd2qlXp1W1B7fj5ry/4fZpvmxuV4vL4QniI25vvT/ll2drO3TWL96Mox+P9f8AD3iXwL45+KOu6p4Vu7yDw74L07V760tfjP4kWY28curSfJOYA8rEROBFJtjjI3K2ZpMexfGz4i33gfx5o2gW0B8c6PodnaanZ+Gbix15pLLB8u1ur+6gstRN7J5trcPF5vk7GTzGWeVYpYdzx3rnwA8Yrc6x4p+IOjaZp3xE8L6ZDLp2peJF0hrrS1kuZ4JFXfFcIsv2qVHywDKpQqPnDd744+Bnhvxn45vfFWpXHiOG7udMtNLePR/El9pkHk28tzKjFbOWIyMWupOZC4AA2hcuW6NOh5RwX7Kfji/1G71zRZfJ8O6XpkMUsPg2XTNTWfTY52YQPb3N7a2WLQm3ulW2W3kERXCTLGsdvHz37Pl1EU/ZrdpW3J8HbxACD8pH/CPcj9R+FeqaB+zdoWiX2v3ulaz4qt38Q2djY3k1xr93eziC2knk2w3F00k8PmC5mjZo5FKg7ojFJ+8rj7L4x/B/VLzwTrHh/Tdd0qH7JDomgalH4P1mx02K1vprRIYopDapbrHI8NmqOSFGFCsoY5StcD59+HnhfwrrvhXw5rfiLRvDGt3Ph74VeBpbO28T6RDqNveGT+1EayAaKWVGnZokQ2ymTzlg/dz4aCXR+I/gLwTD8JvE/iix8MeBvAcV54i0TSLrTJ/D9lDbaLBHrVg7w6mV8ppvMV4p5V8wW5iEXlM6Yup/ddP/AGU9FjuvC0mi+NvEPh6Pw9oem6JZvBDpd080dit2kE5NzZS7Jdl7cIzR7QyyMCvr0kf7OFvc67NeeIPiHr/iKaW402cLqFrpEDs1jfx39spktrGGQgSxsNu7btnmwAzBg9h30PgzxNoPhnxAvgaym8H6rNDf6dpXhCYav4ZvdVl05LbSVeWHzxZ3IuGhdL2GSHTTpNws8M+/kfaIPqnx3rdvrN7YrrHw78YeIp/E3ht/Dd5JpkunaNaa+lxbrcSJ9kur+O8SSJVuxHFJh4Vlu8btxetf42fsf+HPix4nXxD4k8Uarql/bzu9nFNomgTrbRHzQLcPLpjySQqJ32pK74ba5y6hh7R4T+Fdp4Y1ldauby98R+IhaRWI1LVniLwRCOMSrCsUcaIJZE82QqoLvsBOyKBIlsilotT5X8d+OZ/+FQfGfxfL4K1VbuWGfUprvxBBaahp00djKsUeitDpuoy3Hkr5cqzLI3kCSW+klVI5Hgr5l+NuixzeJPiJ4itfCtlLL4Z0mG2sZYfBPkWMCDRdPnIltJdBvQmxwNqXN5G8EZ8vdChLv+j3xG+CWgeJofFtvJNqVha+LdJudK1eDTn2pdebEIUuSpjdftEcYMaycbl2CQSiGER+deIP2K/hHrVtq95deErC51LWTbsuo3EMFzeWzw8iUSyRN50hm8ySV7gzNcNIVmMsYSNXuUc5+2x4a0G8+Fnja7v/AINx+L9Wg8I37w+MY7LSpDpWIrgoDJcTpcr5RPm/uo2xuym5sium+H+g6Fqng7xfD4H+Deh+BEuyLK4s9VstJXT9aMcssNxZznTp5sbcTQMZVbymmJ8uXa8Z7Hxx+z1F448P6t4atvHfiTwz4Pv9KGlP4Y0Kz0eGyt7Q24gaGIyWDyopXPSTK7vl2gABPCnwRsoNT8S2niTxZ4g8Z6XrIRtQ0/V7bTYLe+mzCWeZrK0gkmylvHEySO0bw5ikR1wAriutbHxd+0V4t8BeIrn4gafbWXwt19v7Nu9PsLi50xb/AMTz2qeEG1G21X+05Ll5JgJkjhEjRsThf3hbmv0A0m0sfD+n2WlaVb6fpVjpwSK1trG0coUiRQI0VAAiLkLtA4CgcDpj/Gv4W6X4++H+veHodSu/C9n4iLHWZdAt7RbnUongFvIkjTQSgkxLGodQJB5MYDgLiuns/tFxexq7+WvmMyvIp8wujdQONrMh+YdDycDkVS2uVG1rk9w4W4iEst1cLdOI5Fij8pd2PlHY9jnk1fjjcQyW0WnJawMCmXcLkdBwuTj3zxxWf5Ilimj1C6nhkt9sh3S/JjcdjgjGclTwee3eqs0sEvlSrp6SxvIscxnO1FOcKwyM89BkDORmna4m7l2K5D2cccmoCW5j+9GGzkKRlWA5OQCPfNVPEnhy08X6FeWE0JWKWP5CRtbd1DfXJ/nVm3jvhuh22trtLAqkZLBc5QhuM8f561HqvjHSPDttvvr+ESHny42DO3TOFHPGamUU00yFLllddD45a4bw9q7W90rBo5GRjwNpBwf1rsbN9MvIw8zCTB/D+VY2sJb+INS1NnACS3DyJgAEAkkZI+oriNX8L65Ao/s652xjgIwLH+dfMODhK0j7CnWUoJwPTLq20NJCIbOMNzgqi5I/KuT8Q6lp1nG7xrtOeCDxXmd7B49gLfuX2AcuI84/Ws6ysdWuEC3rOSOzZXFOUUveuQ5yZ0Kaj9vvmeEkKMsc+ueP5V9+fB8gfDHwwSAP9Cj/AJV8B2VnHYxFQTzgkk17/wDDj9pAeCvDOn6fqlhNqFnDHsWSBgHUBsKuDwRj37D3NduEfvPQ8zHawVj6q84K+Nm4YyX6f56GoAZEbMrfuhz5v3dvPQjP5GuP8MfFjwv4uRGsdWiFwzEpBdOEYnaeMHrxzn/A12CTCaPLcpKvHykjntXsNHg3uMkZt8ptSofI3DJZWx2x0XuM/SpSqSqrSKzkciNsFgefTgfWqhbZNHDh3XaWDTHHQgADPfng4zjFOuCXmSWPyyU3DG7cWX8eM5HH061aRMn2JIJHF9FlhJGSAu0b2jOOm7pg9c+or4W1yEtreoH5ubiQ/eX+8a+74fL82NgkszcLuKEAdPXAHavg/WDew6texwH9wk7rH8o+6GOO/pS3Jdz7H+HUwfwJ4RX7SoRNJtCqvgbj5CZxjGQAT+P0rXWGFUJRGjnkdtsqnK4BIJGPTp09K534c5b4f+FIiEcvpFmvmIGUlRAmRkHGc9CPQ+ldDFAROWigeFo8gmLd9NuDxzwePr3rZKxHNceFCPFbxXwKowfbIgyDn5Rxjrz15qG60+5ZXmmtLWR5vkLwsUdB2II5B7nnrirOmysZ0LySFnIZ0aPBJHU9enar62fmu0nmkebkbdvv6/jUSk4s0jFS1MO8sCIMMLqNRtE0kMgYyADhgGyD8wBqnBqs8L7pJ7mR5WywmtN4EYJ+bK45wfQ88Vr2x8+O4Bx5sPyPzuz7de3rWBcb4pZI2iu4MHEk8b5DKRwiHkBvb8ua0g27pkzSSuh09tuaRYIre6QZuELQsgdmZsgsDngHjp1HXArVRpJ7UW91EJSgBLmRhkjoc4zkevtUWn3Bi05meW4lEbNGqS/eTBPy8DnHT8KmF4PPdVUBvK6Ec5zWc5O9kdEKcXG5xnxT0PW9a+HPiCx0m3nv9avkEOmJBrFzYiGUsPKklnglhmSFHxJL5cm9oxIqhywRvjmbw5e2n7AfhqafQvF1pGfBF7NHqOmeM9TuIY5f7CW6guHiWYKtmyW7RNFKFjgn/dRxSRzmZv0OgEszKIyY1VRnAGM9857Vwfib4GeGvEvw70f4bvaXkPgGxs008adp+s3lmTbRweQttJJDMkk0RjZgySMwbALAkA1m9XqSrwa5XZo+Zvin8OP+EM/aM+BFvD4x8Qx3mzWNO8NaQEtmt9LtY9OHmuBkmR1i89VkZWYmaDeWEBSf5n+DUWoXGkeLbe1n8QeJPE3/AAh9y3jWTSL23s7We4i8QCRF1Jri3lX7QI01NXS5ik8yxjVVRhM0afrbA8i3EzqrfZsloljORISSWLHr36e1eeeKPBfhp/DlroXiPRpvHvh+a9t7e107UtObUpI3aRkEjuQQ0SRuAXcbtiuZHkaQ586VH2Tcoab/AC2/q3otkrfW0sz+vJUsVFSbcb2Wsrc19rK7Vld6r3pJ80puXwl8QfFniHxV8PfiHq1lqnjPWVufhTbrrOp6HeeH7u0vJvtPiATS3rvcXG2F3E7LFp8pMSF41CeXGi+lftNjwHpPx48Ma9aatcwfF/Rda0KV9BR5bXVtcimlNpb2um3V1Mtutn/pNy9xFboUmKFJXhbdIPQ9Y+BXhP4qfEbxvc69qmr6hrhuf7F1/Q9L8SX1rHcabKrfZFMS3UChY7efc2QyOz3wCSM6lfe9GsbTToIrM3901vpqJY2s9xcSTSkKoDGSWQs0r8AMzsxbBJ5JrupzVSN1/X9PQ+exOFnhJKE2m2r6X2eq3S0aakns01Z7pfnz8FH+Nw/b48Q3XiyO50Px74m8E3M1pBrSW2q2Hh7TzqqeTEotryPzoBHB5e5DHJ58zM8RUPK8mgaHJ4f8C6Je6/rfiDwxpmiGHURpOqeA/H1zY6Ra2cizWzTI+qG2xCsULMgDxRspCvIqiRv0SS0h1B7me6YXEMZ8lHc7QQMMx44+9xkf3a5jxR4P8M+O7afSdc+0XlgLreNOtdRniS7XZ88U6ROPOgYu4aCXdEw4ZSMVpY5C3pzXljp+m2d/d293d21vH59xHbmzSSboTHEzOyoSCQpZiAVG5jzU97qlwl99pl/dEnG4Y2o3oc8jP0HSp5rWeOWS8SA2ls6oGi3neAOrsq89MZUN2qTT4oL5fLtJY7yLafNucDbhgRtjUYA78/qTWl7GqstTPm1C5voJFlKxiGQDJO3PTIzg+uemcc4Awa1G1aRYjHalZJYoQ0ZMbyRkjjk9e3X6+mKhigttPtrqyed5LtmdIf4pQrD5SBgY7ZI445NOF6k89tdrqMshkXY21ADGGwRkYIyDwc8jJx6VLsVp2A+IJ430+b7P8tyDsxJuaTIGFCr+IyehFQapcPqbR+QdoRtqgAMrfOEyR3UuxHHZG9aY8JkkktQhlhnOYhJDsafPUMwxhFJL9icike0kQIYbqdVI8xeFOQB5cfbuxJA7AHqeaNEOyRNJ4iu4rRvNijuUaNNk1tGDl2J27lJ6YAPBOM0WGrDTYiqsrTXAEsl55m+2CnuO655wCBn1pP7NuoNQgt4L0ZERlDSRD76gRqDjHy7WOB1zUhS5EhZQ+ilgftM0YR42IwFKg9znrjoMEGjQehLd6jNJCfPtluobdir3FqRwCM8KSM4OM4JqK3lnu5Nv2eZZCsZnygXy51xh8k91IBxk4AFRR2tpHaiCWNrKLAcXlrL+4lO8Yyc4yTjIYcnPapbOW+uL+aa1ubS6tvkR5GBAfGT8pUkcAjnv+FLQh2MrXPFGl6OE1HV9Q+y3EZJhtONy8kMNgyX3DAJP6V5nr3x8aB2g0KxwkamJbi8YklSem0dQOcZPfpXl82TI2eOTUMkCuckc+orp9lpocs3Jr3TV1j4h+I9dY/adWnEeSRFE3lque2Fx+tY+nnyZNzseVKgk8k4OKVrZcfKefenxx7EweeaqNO25zRjNy94faskVyVz87/N+mKtu+25RsjywDkCs66sXkKyhWG0cHkfrVOa4vYo8RgvHnhsbmrycTgfau6dj28NjvYrksbup6jZLp82518z0JHPHpXnErpqF63lDAY569vWtKWcEODBKzeqsKg3ziICFViGOjqM/pXHHLp31Z21My8infWItXKGQAk9GUjpUrwB7DYGI+UEE+vX+dMj0+4vLhXnbc44AArdt9IkAw6lQOwr1aOH9klG55FfEurqzl7e3uAhAcoP7o5rstA8f+LvDUbDTtdurdSAPLd98Yx0AU5A/CojpcY/if9P8KQaanq2frXa1Z+8ef7RPdntHwv8AjjrHijxHY6FqtlayXF20hW9gHllAkZfGO+drZOf4vavoGCV3QNCJEDgNgFEAyBn3NfKXwTsoovidokhiLBTP6n/lhJX1NaKweVWjMe5iVPlAk988n68dO9RUs3oioyuS20aSYjndGYPgq0mByc5x7g+tfIpsEmPmANh/m/OvrZc2+pK6pIWfau4hRxuwRzx7j8a+TbZ5GtojvflAe3p9KwcblXsfR3w+iL/D7wkAADDo9mSxwDu8iPjAOT0OQf51uQLFPGI0QCNc+YW8sH2P1IHX3rI+HSlvhp4Sd02Qro9kWKxKefIXvxx+HpW1bKTG4lDGFGCjaoO5sj5QOv4YH5CtFsS+4ttcst2AJvJVQGbztoyg7j0z/IZ71fFwGyTcho3AIjQ4I9TmsmWN5LmTzVmklCgrFCiqT1IU5yDjGSTxk/SlnhMlwscchluAwJD4APPQcZCjByfw6mlKKZcZuOhpp5Om3L4ZjG3I5LceprmXngN5NPb35hPnsyLISyxsSOccZkbOAvPGO1a1xdTaSj7d00ixNNJvIJAA+/xz97jH+FY09xaCN57iK4EMJErCHLswJAL4jPzSHcM/3VpwVrsJO9kacW6C0js55VVwAHCjG0nJ2k5OTgjJH171eu7JPKUo0UbYxuY9u3/6vpWJpttPf3iytBNbF3YtBec/KDzjDH5c454LEegp0LNeagwvIlZG/eB7cl/k7AKBnPXt0J7kVLgr3TLU2lY0b5f3CQGZ7eaX70gYgBF+8ceuOnuaLg/ZdIhhKH7RIDHFgfOpIzx/tAY/H8alcQa1eKhVXhtSHwy4ZnPQ4PIC/qfpVd7ZV1e3Amk3o+yMSSlz93MjYbPYqM0klswbvqgZ59E0owlQ/BUSJJyCeBgEdAMd+1R3sVvb+Hbu31HT0vYJLVorlJo1ljmRlIZGB+8hyQQRgg0/VLeS7vbO0acvtfzHG0KSpyMn19OMU7xDJMsUEb3EYjllAcGPBUdeu78OnWhxvZMcXKLTT1Ryd5JB4D1CxvdUtbvWLnXZ4bHUdWvrgNFCUhk8gBMBIw8hCKqKis83Uu6q+H8PdSGh6VK934nEj+HzNpfiGe/vGaF5EX7SbsKxdVbEwyquiokrIxbyI1X0XXrCDWdIv7SaKbULSeF4pYpkBhkRhhlZCAHBUkEYPSvKtT0208LaxFfw6rc+E/ClrZXV06+HoIba1W8ZZBLc3bFW8wbGVowUZN8fzjcY1bz6sJUnzw2X4X3/AM2733XXT63A1qeOpzoVG1UaXdqXKnypWTadnyxilyq0Zbxs+/8AC+raV4n0uz1HSLmy1a1eSRku7HF1vbe24hwSi85HU8g1daa6tLh7m32SoTtnRpN+T2xJjG7jG1c444NeR+HNduPDOn6t468XXNn4Z0zW7iCG3sY4ZLV5NpkEUjQF5C91LG0YMS7m2W6biCDHF6bb6/HexXE8N1FPFE8sbtEQGhMRKzINpIQqytz94FSD8wrqo1lViuj7dfJ26XPOx+Alg6suS7p3spbq9k3FSsk3FuzatfeyuTXPiU3QliaJ7ZU4lyThWPUOw5Uey/McnkYNMuppbDyr2D53jjBeJkLHyz0Z1HCAnGEHIxnrmpI5La7XdIVj5YJIoyWAI+SIDl85BLHk7uncGnlrYy2V45gj7QQOWdn7jn5iOhwMg87jXRZdDzUjRtrxTc2sguZbpZ/lM+zbEGI3IF9uo4yMnGc061WEm/0+YnarmTDtjKPzkH0DZHtge1ZdnHd3mkywSXMcU9k+5Y3AJVlbKl2ycDgjHGM+1aluz6zawz/Y7csVxi4O45yCVHBwMjr7Dis2rMTVjOhiGugLI73cnR7p/kUL6xYAB355IzwTmpo7Cea/lSK9TbDIjTSeSNxIUFIyOgAUg8AdR15rT8qPU3t7y3doZlG3J5BXPzIwzjr3+hqhazzwW8a2kccnnyPIXnJVmXPzSt2GSRgehHIApX7Cu3sQ3tvcWk1xdTXJYm3ZnWItGgWNTgdTyWfJPoAOgqpLBqsNx/x9i5jtnQiKUYMspA4PpgkdD+FLcwahqFs91PceSnkGXy4sr+7ByoIHOSQM4btVWfRPs7XCy3qecjID5i7N7nBZg27IwOS3X1J6VaXc006sbPqL2slw9yX0+9difswUGGUdB8meWbGdwz1HPpYk1K4WGBdRtPsFiPmaSxkJQnHC/LjAzk++B15xXltLiB7jy7yC7VslYQykE7fRueAOi4zz901VYrY3UbRTrYzA+Y0buroi4wWI2g5OSOQRk4ODzVqKZTSZ84JiZkYHKvg7l6HPcVfW1iQZ25x3avdZfD2n7w9xo+mrFsxmC3i5Izk4HA7cHkU1PC2hzxuTplkoLBUV7ZCPXJIHatXdnG6EpdbHhF7bRhyY3RccYyOaouVjfa8kan0LgV7xL4R0N5PLGlafKqnG/wCyJhsHGRkVJZeC/DZnSWfQ9KwckyG2jyvGT/D3ya1ulsWqPLuzxaK6g8sKssbjGANwOaqNHFcSsroVB67GAH4V7ung3w+oiaPQdOd2OHxBGdx7cY4+hq6ng7QxayMdB01SVYFRbpxg+uwfl+tZ3SWpCoKOzPnKfw/ZLPtWRVX3Y5AobSLKzB6SuD1DdK+hj4e0pMAaRYBOP+XZDjj6VI3hXRmDqdMsm+YLk2qAHnvxSSfUboyfU+axIDKFjVQPUirY6DnpX0hbeCNAkPlrpGmLPGScm2jUHk98VHH4Y0VoFK6bYmRiTta3j4x7Y60RVndihSklqfOMkYbIYYP6imrEi89frX0Z/wAI/pBG46Rpznrj7LGf/Za1D4V8OxuhOj6a6sn7wLbR/Ie3OK0c7bg6HWx4l8JJBF8QNJcrkAy8dP8Alk4/rX0pdws224BiKqAShYkN3yeenvWRo2g6Pp1wk1vo1hDMWKxXCwJGRkY+8F4zn8a2YzLaXa27iOOGRdy85wccjJArFu7ujKW9gAtnEbxpBubsYycjPIP+I6Yr5h0N2bRdPKzNtNvHjp/dHvX1DbAWEsStOjIZOGRR3I/Idj6cGvmfwzDG/hzSmKHJtIj93/YFZu/QzPePhzG6/DLwhJKh2/2LZKkYl2kkW65bg44Hp298Y3obeYICVaSdkzGWlI8sd2PoeMde2PWsDwHEzfDjwkgQ/aH0qxXcpO1R5EZ28c84/T8+gvU8mFxHEwxtjeRWGHckALg9uec9gRS6DZHEY3SUncyIfmnYjcin/wBmb+o9skdpDHFDdxQjzWAWKAuwOOy59c7ie3XPQVKywyIrtGEy2InkUglucu2D07geg9xURtlghMitJF+7OH3n91FjO7ngM3f/AOsae+iD1K0ly1ntUsBLMz/vZJBtynAyW5KqdxHqaQW9tPpzM/8Ay2yolAzKEB5b/rozHt3I9K4+1+K9te2djqr6TNF4cv8AU30xNRkdViCLlbaQg9IpZBgH/bQnhqz/AInfE+w8BeKNK0eSztWvjZm7S8ur2GzjVt5VlzIOcY3YHIyDW0aU3LkSdzB1oJczeh6F9hu7a2ukDxHzv3IiZOjbSNikYGOef+BHvRpkzW8F1KYH81QQHji3AkjO/I55wox2CqK4P4e/FD/hY9heWtjFbxPpDxLK6Xa3CyRvEWLCRCfnAIBB6FqxNP8A2lNFM11aSaRqMUUl5FbRSJ5JaSdpvJePy9+5UUqqZwSQScCtFh6rbXLdrcX1ikrScrJnq2hXdos7TtcrHtiCFJWwy87iCDz0G4+7NV62jh1LUJrzcrCMeTEUk6/3249/l/4Ca43W/iXa+DNYayuonuJhZ3Oo3ZJCtFbwABpAP4y8ziJVHJ/CrXgnxRda5f3OnS6TLp+p6UFWeC5lBcxzokkcuRk4++pxwGRxkkVhKEknI2jVi2o3N+8hVdct2eGQxkYRlZju9R17YJxx1FGsWXnWiSi2W2VHDOGQOxA6Zx7gHOeDXjMn7SVxLAl/PpNnGBI8K2dtqwN0p88RH92YiSxxnGelegeI/iTd+GfEWk6ANFudRuNTMqQXhmhiQiPBk3IzhshWXkDksMCrlQqxaTWv+W5EcRSkm1I6aK5a6XE6tNKGYCWfKQcHPT6c1Sv9KW+i8weTfQIyuGvF2whlbKhR36AD0KrzXHeDfiNH4vupYjZLYBdOj1GG7vr1ZYXTzXjXIAUjJibgr0U4rr2a8nuIyqtao5DCWaIsVPGdkak7c8cn356ZiUJRk09Dpp1Odc0GfP7yeLNcuvh34w1nxTY2F1JEkMNrPEfKstVYXEbR/ZJLlRIQss1sy7vOWaCIjCtKg7fwveXfhLWLzTDPq/xD8Ru3n6nYW0qfZbF2lllEjefLsj+WXYIRIzGOGMhflZq7F/AHhw+LDq7eHtOuNZKxk6nc2sT6g0iqEUmUruUFNq7QdxA6Dvw3hf4j+EovHPi/wdp2uaNqutw3NzqV5d6brNpL9lUExyC9gMpkhMA225JjZVRYs4JZE8WOHdKSb3vvq+lr9k3bd3ttfY/Qq2bU8fTlTilZR0haMV8TaimvecY3ekXFydpct1K/fabd2esWKavpE3m2k6jGpXMbpIrrkFNjAMu0rtYMAUYFSMgir1xcLcfZLqzZb26R8TT5OA+CV+boASMbRwA1cL4f8S+A/hb8MNK1HUPiNoL+EnvprZNYvdWgW2vbl5JXm/fEhHlMqytsU4VhIMYXC9DffFX4e6d4hHg2+8eeFbHxPeSQWy6Ldatbx3rGUKYVFsZA/mOHQquMneuM5GfSpzbgnLc+QxCp0q84UW3FNpX0dr6XXe25s3iJBe2mrTxRSW06DzwEwob3B6sADgnk4YdcVLdwpY3z3DwXK6bcsDKgYBS2B8xUfNg9CMjOOnQVxXhX4zfC/wAYxavBa/EXwnrJ061k1Od7TXbW4Nlbx7TLcPschIlOCzMABnk81d8N/FzwDrXgrUPEB8eeHZfBemSC1vNbh1iA2kcpKARPPvKJkyR4UsDmRR6ZvmRjzI6y8tZ5Ve6tR9nt7wiJrULhplIxkdlyMduFyetV5NRmY3SzWLxllWAoWwqIP4ATxls85wORyccZreNvDPhXxvpnhWfxLpkeu6hCZ7HRLy/iS+aD590kUG7c4/dOdwUg7G6YNYOn/tJfCG/vLe20/wCJ3g68S3jmuTHD4jspHKxxtJJKwEuQqIHcnsAT0WpumTddjrXur/UWnVLdoNxRSIlKYXjbyw98gd8imSaPKPOlu5olZZo1dnyQ4GCFb06gsQeTxisl/jF4FvPA03ivTPHvhm98MafelNR1+DV7drSCYlfkM2/y1fMsYCsed8f94Z0p9b8J6f4t07wvq/iHTofGGqE6ja6HLqECahJEoch0hLB2UeVIxZQeY25+U0+Zbl8+mgs9qskWorFOsskkih55omOcqNqE4wMdATgg85PQv1Swnt2tTKUs44pSTJNIp3nYQDnORyxG444I3L3rMsfFfgjxLp3i5B490eeTw+8jeIZ7PVYd+mKpfct3tf8AchfJkyX2/wCrf0OCL4ofDrQvDlh4ruviR4Yj8H3INlYare6xbfY55dzBliuC4Vj+5cFVY/cbgbTRz2lYnmRJYbJrqRYQ93EiESzRhdykk4Q8dRj7uSDxtIHFTQadcyAifh9p3lG3ADjg56EjseetP1fxJ4S0uPQdTn8U6XBo3iKSK30q4ku41gvZJgGgS1l3bZfMXLLGC28ZK5qhL8UfAWiWfiG5g+IHhyWPw5cJba5cza5b7tMkZzEkd2xcLGS6sgSTadykDkYrT2i6Bz9ixBDDPMEjdpRvAby0PAyOecfrUcMccbgGUiXLKo2ZzjgYJzkHP4Yrdu9b8Nan4tXw8mu2ieKRYLfppouIzci2DlPPEJO8Rb2K7wAM8ZzWra6LZ3G0lfNlx5bSQAoPc46f/qpqqhKocnFatF5EpkaJZCRkDPGQCcfj/OrEELS7i90sCSg/vCF2sQBke3FdNJpWmtJ9kyZtvymMOTtx+NE+n6VaXLW0cflSY3PMqkspPSj2lw9ocz9gKxjzrmJIWB2tuLhscHAH1FLBYxyl8+ZsBwoOA3UkEg+w+vNbl/pMNpGryBBdSvtBVioBPTaCc8nrz3psUOm3tu0xWWRrcY/eEkkZxxyf0p85LqWMI2sbW3meagdmAEe7Jxwcn3zj86SG3jlVSWK5ODx2wf8A9f0P1rsrGw0+dPtELLuKgbkwAox6H8M0aVpyC4u5ssUeTIaTuwABZfxz+INHtVqHtWtjml0aR4vNT5VG3G9cjJbBB9h/Iircmi7LvyZJFihJOSAMH0X27/lWiEs7K4kt5rmWSKYnYjS5Hum0fmPqfSizFvJ5kMqq7uoZVVS2AAAeR3yBn6ip5nuYyqSZFFa28cbW88u+FvmiKtkSLwRkDqwNS2sKvEYJ4GEw+YMcZYZ4bk9eeR9falaeS6hW0ER+0oQ/nMNgAB+Vx79OB6mpNk+oRqyeXb3MTbSRk4I7fQ1PTUx6lYLPcyG0MaLJGVbc64J9DweeuP1r598GwP8A8IhofL/8eMHYf881/wBmvoi1je6jhvUcm4XAK9BweRj8K8C8FvE3g7Qj5Y5sIO//AEzX3ok2rWJ9T1X4bwCX4feDtjuPL0WzLOhYlW8iPJ/Lgcd+nFdLNdWzsomlRLVEOFfrt45/4FkAe2fWue+FIkn+G3hhVCGNtIsixB2kBbdMLx0z83ft7104YzyyXDb4hCAdoXIYYyo9+cnj1HpQx9NCHUIBcQsCZFd0xtTGFXI2oc55J9vXsKyPFul22s6DfaZqdvd3tlcqVvLeNmjefjIRXQjggcjOMcdzWxceZDdpNhGfdvcZP3iMIDj0w386ZPdva7UJV5Y1baVbcJJGHVuh4GT+PtVRbVmJpO6Pnuw0/wAQS6fc6jf/AA2vL0avcx2eqaRdCAommKDEttbKJs7olIfhcMd44wprY8b/AAym1T4iaXp9hYav/wAI7/YJ0ua8t9UaBIolnImEshYySHy+i4OTjJHWvcbiGzMS20ci5QqqwxylV6g5xn8azptL82ef52VZ5zCGlZ8ogGWOdw43Z4PrXUsVLm5krfeccsJHl5ZO54/4S0fxd4StLnTJbTX3urTSWZtVmuUvbaby3QQrbwyPgO4yWjbbtKY3EEGvOvEPwm8Xy+GIYksb5Un1CMSQJEst95jzrNI8jwsI7VFDOd25jwBx1r6llsZtQjspBqRVGk2ORtCsqZYAkHPJUdCOKgtnhhSMz3VxLbXQd5UAfk5XHPJ6YBAPat4YycJc0Ur9TKWCjJcrbsjyH4h/DWC31+I2XhdNWibSZdORFdzGZozD9l81mYfIpYsSemxmwzCn/D/4PaVpeq68dQ0O8mIS20qG+Mro93EIFE7K6P8AcklXcOh69M169JaRD7Obex85ZJWZGmG5JAQTwCeeOefT0pJJpIrZ4muN8MbkC1iULhVY5G/scDgA54FQ8RNw5b/1c3WFp8/P/W1j598YfCnU/CjMmm27avLqF5I1tBJbzzfYomkXKzT/AGjEaIj4Vipzt9eD0/jr4NS6l4o0a/8ADSW+npZWEUX2jXGluDGsN3DLF5Kliyk+WxLkHOcHqCPV5IzCXKx/Z4p05LuZJRxwfm6ZHdu496rTTzQiMiKU3RQyeYxADAHHHBwSDkFvUY7Gq+tVHbvqT9Tp2aezt+B5V4D+HF/4L+KUVzOJf7Nt9Nkilv4XnaBgWUxRpHLLIwKM07cKAoc4zur1WW6TyniiCWy2zGSOMtiQqc/xc54DA9gBzk4AmFzGkqKIp0DHDEoyncQeCc55APQ7mxjioYJ4TCI3bf5TABEQYPPGOzNtPT7qjk5rCrVdaXNJa7HbQoqjHliDWyBWh2tHGpFyqqSoyeCxOdwDAf7zZ6DpXx1+z78N9S8OQ6L8I2b4hp8O00vX4tc0jxXZPoB0l11KOWzW3v7KAC7eXfMCI7x45Iy7/IuID9kJapbz3TxtHBGMhpGG9cMMMqE/efgnIG0ZPWpDHbCMsyea0EIYq2QsLRtyHz34x6+gFcrV2dcW07xPzWPgzx1/wp39njxJ4y+HniDxJ/Ztv45tdf8AD0OnT29476hDci2tTbwRmW3inClFeOMJErKcoNtdB420++s4PA/wxl+HFxoviLwn4e8N6nrN1p2lM2r+JNTs7BfIFreWqM4t7Py5EluIJDcMf9Hg8tWkkr7w1Tw5BrF9Z3T2M1vf6ZG62U44ERkVoXkCn5CTGw+ZlJAYgcMc87aeBbH4XT/8JBE9xf67rd7Bpt9rV1Mk07Fm8uNZGYqEXfsiCwqAC0f7sDJHnV41Yx5YWiu/ZeS7/glr5H0mXLBzrKvir1Z78j05ptu3NK9+W1m7e/J+6kr85+dV18HJfiX8CfHN7rumeKPDnibS7LZp/hPTfCE2mf2Xoh1NL+8nuD5NvBcM32e8nhs2nMKHCofOYFfSPjp8GNY+K37NPxnew8J+I/Ek2meKLXU/ClzLos2k6tqdzcJpwvrm40q2s7VLhgHugtzJFI5VpgNoTc/2B4Yz4b+PPjPTLa4vV/trSbDxHb/aXU20To0ltJGw4Ks6RwjBDcxOcjaFrd0fWoNB1m18JWfnQaTYeH47m/1iSKK3W2jDmOD5FRY1VxHdH5QqosRG0LtqKElGPK9k2lu3o+r1vda+RvmWDeJre1hrOUI1HZRjF80U3ZJRUVFvktq5PbV2Pj/9qf4Ga343+P3iOy8G3Pivw/e+LtW8M393rv8AwjUV1Y2j2Mc6G/tNUFygsvs8KsWiYLcySqiRMYpzjf8Aif8AC/UP2hvDf7TXinxn4e8RW81xcQeFfCunaZosUmqrpWmTLc/arIzGH7VDczyNOYgwLCHy0kkYR7ftg28Gq3C2LRQvBDhxLGR84GNoX0IPUjpx/eqG5trMG4lhvTLdHKhCw+ZvRAMDd0zj15rusj5ayPgn9pb4e+Jvjf8Asw/Fgz6f408dy+Gtc0//AIQSbV9PutP1a5WRLEXrPpUNpapKsRku0Sd4nba84GwJufZ+JHw08Tp+194tubn4d6vrsXiHxr4C8RaNrcCSpZ2NvpkEwv7t5kBh3qqSwfZ5nR2NyrorEJn7misltJLSHc97NErPFCdoCnjc5bGepwPr0OOIIr8SfbWaR7aa8fyYWI3ICvyHa3TIO4446ClYfLc/LTwF+ztret/B7UPBfiL4beMdO1Pw58PdU0bW9S0m3El3c3n/AAkwv7S1tLe4aOK7WFbeSdntpG81Ljyw4fygeu8C/BnXrX4xz/GnxNrfxG0f7R4x1SSxm8IeCIoRYpJYvFPdy6U/2me2F1IFiSV7aR2W13T4e4jkj/RSa5gg1ExTwiRNPtgsU1mcYzzk9AuAozyR1+lQTq50vTIbxIlS7beLqI7pI1OJGJGMHPfHHOccVfKPkR+dHxm+Ef7QnxL8R/AD4meKtJtNU1G0vPDlraaRY3t2rWDkGe9u9UtvsWy1eSZY/NliwsCxpGUmwrjDX4Yax8LtR00W3hP4k634M8L+Gtf8NP4Ubwa1lqGqrf3l2I9NuNQtZ5PtsX72S5a6hU20SwwGNRPcba/Tu4jln1oTC5i8m3h3x3sSAoXP3fMGcYxjkcc9qrmC9kvow/kgIWWO2QkI5/6ZufutwW2c9sdxQoruJxsj5r/YN+Ges/s/Q+JvAvjrR0fxdbCC/h8Z6bHc3Wn65p6QrBbwm9k6SWuGhFsyw7YwrRowMkh+sofEUKRxALOsUoJNwkY8sHsuQcg/h3rkmnh1KeNGSZRG+64kSMoJADwJVB+XJVl3LwevtWlJcPZ7riH9+wCrt4EhTnG7jZLHgEBuG7ZB4quTZGbVjTsp4p726ZZisjIEWQgKxJyTjnnHH50ujzxw6i8Jk812jZsYO9SCMlwceoxg81Q0yB7ez3ygTuXZ5HZN0O4n7pwN8RGcdPqOabbCG5u7iSF4VtVVQqTS4DyMcsElA6Y24znknpVtbmZp3FzNcXf7i4RZcHC/cOR0BODgdOgzUNjqafbbq3mE0E6opDTqG7dMjGfyFQyWqi9giRpEuGO9kvHG4Ko7OMggk44HWrF/bC3ltUQyWxeYBhMu5CNjH7wxxwO9Ky0M2zVslEcMcO5TGItqIDz1OePxpNHeVZZo542MqS7SxIwqkZU9fT+tZ9/5ME9pLOEAIdXazlxkEDBByCMEfrU0NyqXy/vp445gEJlIDEckMDjI9Ovep5dB31HXLG/VLeP5LhCxYxH5lbBXPHQZPcjjgVaEkk9nBNHbOskQ4Qlfoy9enX8hT4litb+Lymj8udfL+VsncvI/MbvyoeR4b1oYdm2f52cnIjfBzke4AwMjvSb6IXqQeZPcL/aCov7sFQiZLMoPzA9O/wDKn3Sk7bwXBijIAdo8KWQnuTnpmnxpcW9+0LXD7JV8yMhR97+Ic5x6/nSQW9tBcTW8snmJ95Fd8KufvD0znJx70Ji1GyW8VneRS4RojjeDyQePm5/z+deBeC9//CHaFtJ2/YIMdf8Anmte9WKw2k7WrBJMMDGygFiCenHp+nPtXgvg3avhDQ1EkmBYwDkc/wCrX/ZoduoLyPTvhFdR3nw38O2lyvk3unW66ZfKGP7u4tv3EsZP+9GTj+6R6iurhO+Z5f8Al3/1hZX5PAC7v/Qgc9xXLeJPC1/4e1XU/E/ha+s7NrpRJq+mam5isrvYoH2gygEwTLGoUybWVlVQ6nCsvEwftI6XEkqy6JfFDMC0mmS2l3bsNucLKswBHy9x2FYqqktS2uh639qktZFMyO7lWlEbFdxbOFUNnBwDinSMsc8KXUWyNVLyTuwwXb5R9Op6e1eSv+0vpW6KSbw7rjQlwTI0dqNwA4/5b+pzUV1+0NpqqVTwNr7CWQOz+XbIFGR/01/2fzIqvbR6/kyUmesXU9rO9yBLO8UERUhSxXcQe4HYY796r/Y7bzZpInkE0MCnZIozuOc/fBI5Ck/ga8zb9oywaEqfCfiJJLi43nK2wyMjgfvjngDp71VvP2g7LUI7l38HazOWVGEDx27D5Tnr53A4Izg9CMcVSrRtuHK+qPVZLXTo9SlijRrybyACIz5rBs4DY6Kcd/SoYEniu7KIwC0nW3Kgh1Z8LtyxJJwPpk4ryw/tDwTMGHhLXktZIwPLge3hjVQTk5WUluoHUDntTbj496dNEd/hHXyHO0Sf6PGsTdtoE2d2T3bPUe1P20U7NhZvVI9TEcM1uwEkswViFHmFYmbcSCCOX5OOAOtRIWtbeWaARoCgkJHLouOTuJIQYx1OT7V5Xb/tBxLJLIvhvxAJmIjYkWxdnGAVyJflGeNoyR680QfHuBIwv/CK67LCTm2gKWxjPGSMCQEkepJIHIPWr9tBdRWZ6qsNwlkrSRIYN277Tu2KSTw+Pr1Yg+o4o8xiobynZoQZZAoKDkYLbjkdD95sk44A4ryq4/aEe5sYxL4b1za0JG1fs3ltgDDk+Zlj0OegOeCcUH9oeCRIy/hXWPKJBMS+QdzHBDli/wAznPBPA446GpdaHctJo9T+1iW7LCJVITCxo+wMPmOCW5QdSR95vYVC1vDcQvuAublHIEIO1yof6/JGu4jHJ9c8CvM5v2g4nCu3hDWILSPcpLNCxRuDuJL4L8g5bpnPXmkf492LWN2lp4Q1jymYhnaSEmNwo+bduOD6g/Wk60Fsylc9cNrLYT+VdXoPmQFFZY2YscH5Uz0J59+uMVC0K20wZLSPAtPuRnfIAeC7HHBHynoSffFeUN+0REzfbLrwnqVyzoQJi0WxFyDmNQ3Yn1PJzuxxTZ/j35CtDJ4X1O2gWKUSyKYd7RkgncDx90Alj03VPto9WaLQ9Yd7i5zLu+RrYGTfCYwd2AMc5JGF5P6VDqGlHVNJvrLUDHd6beqBNaTBXWbzBghjgDazfKwxyH615aPj7LBaJ5nhnV4bJI2Uyho8sjBSMnoMNnBHOO/rGvx0nnRIJvDOrfvEZVHmqGYY3dgN2CcjpjnOcVLrU3o2axk4u63OoaXwh8C49Z16303UWe/2TXEqJcX93etmKKCITyFiZBJIsSxO4HLEAKjkZfg7wdONP1jWPFU9n4dOrTXOr6tDaXBW2Nv5aokNxcZDSC3jTBZHhiIZzsf7xxoPjdZpM5uPC2rXWzm5aaVS3zZ6gDHDLkEjPJzkgVxvin4watqviGLUdV8O31x4X094ru0stPRlcagrIokuCA7S7WxIiIqLnBcEojHzavso2aWi2WyTe7f9dXvc+swOOqYjmpObVSXxTbcpyUbKNOCtve1rvdRs48uvqnhbxJqkV6ti2kf8I74QnuVt9M+3SG2n08BMACF1QpbzsCsUJJljOBtCMEt/UxpgvhFb3EMVrFAAY4YJcsG7NkAFQO3vyc18oeIPjlqGtfEbQriPw1cfZLB5rnTdLm3SS3kpjMbaleS+WfLt40lcJGql97ElchUrY0L4++IbKOystd0qy1OK9nENtd6Paz28sUoDvJGCzTbwyo+GJTAX7rZ+RUMXBXjd2T3tp/w19lrp5WOnNcpqv2dZKKnON+VSbk7Xu+t5KKvOWicrxV5qSPom2unVJpEuopWnxF5pYG42glU+UcMxySOgy3NSvLHBc2OmEyWcNvGJZJVcYwPlXcR03Ek8148/x5e6ltvtnha7Fvaq3ltDO8RL4wGOI8LtG7oeCCeOlMH7QFzZtqJTw1PJdSYRpLiWQuijhFbEHpk8jkn616fPHe/5Hxd1uesS3E76LeSW5V7a8lMEYZvnA3BAVIBDAgNxj3zTraNJ9aB04tBHYwFmguQwVZG4OF6r8vccc8DPNePwfGlbY2V3ZeGbh4LIHDTXUpjyRtByLfAyG6j16VKfjrdX1rqFwvhS58+UsEljuJwY1wc5Itc5weRyOB6U/arv+IOS/q56ZZJItleXSXRs7u7kLLb7QImjYBflHfHJOOfboadDYjT9MKieK2mMYmksrtiscqgEjYeoxhcEfMpA5ryVvjRqmqQW0EvhoXNjBh90M9xkdcsMWmOgIHPQn6U9fjFPJECvhtm0worpl7gFY1wSyMLXCjLjOBgj61XtI9/xQpST6/gz13zJLGwUPGXvyY443C4eMsBhHXnzEweSuc5OQDVOK0iaXzLm0SJHlZo8I0aSc8MATlSMDBAP3skHGa8qufjTdNqJRvDsQZVzEGkuhLEm09F+x4xksSOB904BzV27+OOo3ljPbSaHtsF/dMTNdEqxIGC5sc9Dx3BPUjFUqiX/AA5k2v6uen/brxJIxp1ytw7qnEo2zhSdoHQiUdW3eg4PIq/a+ZZR/KiiGRiGlt0MtuSM8SRdVI45HoM5rx1PjFN553eFU+YZCLLffLERlWGbHAYjJI6EAnjHEsPx01ZbsmDQy0kseIf318CQCRkj7Ad4yMAkn0B5qvaJ6WMWesaa1vqeoz3KpDb25/cxF08y3lIwXAyB3xzx93p6z6gIrW7tf3KWEskoMjeYJIyo6kDsM4zwvavJrH43avbRyeX4ahiuGlKu8cl+VkkJyQ6/YPmbnrw2O4HNWbT446rb3zzv4PgSdkZyE/tIYXauP+YdnHHfv9Kh1Nb2Jtp/w56zfiJLSS6S1hd0ZALiycEMA4+8PbPQ7qt3l+ZLVjDfQT4IZUlUq+QQRg+v1HevGdT+Nd9qNt5sXhKOBkff58a6mo43LneNO5wcH8BUl38ftSudOlSXw1bTQyAqpkTVBg8cH/iW46HOcDoffCU7pe6w76nsGqRSXEBlbThAYiJvMUqW4BOOgI/XrRcJZrpgltomjKhZEJRvnHB6jqSpP515E/xz1W2s2B8LizgKjI26sUwwOBzpuBn0FR2Px48RQWMUR8N2/lou0EWmsE7AduR/xLvTHbqR7U1JtaJi06ntN01jJB5kbu4jwwKOzFR0Prjjin3slt9nWe1MTeSd3I4x34rx6y+OuspapYt4YSTZHtKi31hjtwME40z3/wA81JF8cNdSL7OfDsMOQQsktlrRCjkcj+zhxn3HWi7X2XoCae36nofjPxfY+GNEm12SN3FjkxxRoQ08jDbHAnHzO7lFAHc+gzWb4S+FFppfhXRrK+dDfW1lDDOd2f3ioA3OfUGsv4eaZYeMbqDX7/xXbeMLvS5DFDZ2KeTZaVNjqICWcTbWI3ysWAY7QgJr0/8Ad+jflUc8WaKLZ5LqOiH4t6rqd9qsX2zwdpN09tp+l7h5V7cQtia6nTpKEkDpHGcr8jOQSU29zfXF9d6EBBapBbtGhyZQCq8Zwig/l71zfwgkvV8JWVqgghT99cEylnba88mSPqcnqeWrq9Ggnjhl05rnm2XZ5YjBGw5x9cj3rRJQXTTUjSbv3HXsputMNwliMlRIjRbXzjn2PTPbvUK6jaXWlLPDPcRNJASEi3ld23kFcEZB9O9P0kXxF3YtcIiWsnlBxFl2DKGB5OOjeh7+lSaMt3HYtaqYD9kkNsEZGHyAjacg91wenWjRbiSvt2INJn1K60u23R2N9E0au6F2RlJ+bBB3DjP6VW03UjpM0yzyS2QMrR5nRnhwGYjEmeDy3t7CpLA7oFs5dNe7ntHaPz4HUeWoY7fmJVgcdhn9ak0q6kWOVZLhrb96wMV3CWUMW6b+M/1696btroNa2ZAYLnVdSuBZzLZW4jHzQNvSQZ67SMYJGOCOAc5p+q3WoWjTO9qHmZWCSWzEq4A/5aIc7uw9e3FQ6NZT2pv2SW4gzcMmbLaYoiADxG2Tg5z369BUvmS6lqBfzftcNpGpZrQBXZtwbG1iem3pkdOlVpzW6IWtvUoi1UQiSUzW0OVgWW3lLIwBHDqeRnHQYPcVLc6itvbSSJMdw4RSxEbkDA2MeCc45yGGec4xVjVbmRoXa0bzZ58QGWBdsyEnB8xCMNgeoB9PWot0UJab7MI1Q4NzbKzxqQOkkZ+ZT7gZ5zmqTvqyeW2iHQJ+5aO+lubZYYgodWAbty2CV56ZHDc5x0qrdpIJ445NkAwsaKzMV2KA7qAAcjGMryABwRioDLHcXKwxzKVbd5Ucj4RmIOWEg7E8AEdiSD1qzb3B0exaO6sxcs5beIl2uH6kkfwjPp7YJp2sONihdXjsWgF6jSgFpVZ1KFpCoQfMcOmG4J+Yd84xVqaC5tx5UdylvftMivbTSnciswUAf89U4wM88HBHSmLZJ9mjubmRDaK+9drL5cjDJLrIVHzbi33hhtoyTUNjp0N6kVwH+22wdp3iEey6gOCoIDZ+RQeUOcHp0xSdmdES9iyOsW9rdSG3ubcq0lv5pCFjuff1GQW2H69asvrNylvqmo21sbnAZIWVwzMe2FyMj5UOMgkVl21jFa6PeX80sepW+zHnMRui3KuZB68jGOoCgDPSrAZVh0qz0+VbtZmMr2YcZAXBcgn7v3gMHjkYxUNJ6G8bdia4sPtdzpVra3UjxITNMZHLxbkxtDJkdweOMYFTLfxvcX93qUZLRL5PlQAyfdOWK4565xkAjNZ1xc/a73WNSSSXTL6FBFHANokk28MSckMCxVcg8dz0qeWxNqNP0y5tkS3h/fz3ERLtIBnkjBYFnxnPXPBzUeRaVtxkN1qGmWBieVo7+/fAa5XHzHAIV92Nqg8bucjvnFOkt3W6j0BTMtuY/MktPMUo6Z4CyHDAkjlcdASMDmmx3AGqXNxJcRXMMUHkJbahJtkUN83Iwc7iNuG+bC1ci0eXS7ApLdxRGdhIWly0kMmOFjPVgoGAD0+hIoehL904mHwpdWXjzXdYsrPU9RF9b2kM179sUNDHCwQ2UcLFVjGJDNldwd/MB2EqH5n4neM7O+8HaXcaZcSaS1pq1nFc3v7lZ9LilnWF1jlIkhWaKSYxMw3bVEwJLZz6/cT/AGC8tn09y1sUEl3dYEiBM8PkH75J5OPuknsK8r8feD28MeE7nwhZSaNY+CtSt7mA3Mk5hnsIJVzcL8yNG/mOZHEzPGEJU7XKYfz60HCnJQ2d/veq/Hd30/FfU5XiaWIxVKeJ1lFwWuqcIrla1bu1FLlio+9trpGWnDDq9x4o1Dw5fwX91pw04X73ZldEgmRkj+yRszZkaREeVnZmddwLNiVQvWHS2hGoWQnuXtvJE8AlkG1yo3qZCACcgAZJ52NkmvM/GGv+CviZZWun3fxC8P8A9nWdwssllpurWsgvliUlY5t24NGVfaRjBJUH0N/4d6aup2Gs6hqH2u2sRqk40htYja3uI4jHEyM6yfOA832kqsnISRAAqhVG1OtHn5E7ryd7f5L57+Rhi8BN4dYipBwkrJpxau9ErN7yeraSXuq7ble/cytpscN9F/aEx0yWA3EC+d+6AGTsH94ZJ+XkdqjjnttO1ea0nbUv7NmjjeCCQnEjAkbcD5ipyoAOOetIy2l9BA6zzXt35D+T5Z3yRlSrRlQBhQFbnOPvEH0qBPs9/Zlx+8uI7Nlmvp5dohkQ4GG/4HnavHzCu9I+btZFmVbnTNZWJ0lnjubUCPTzLuZwhPysVGMhScZyOMcnFU7SCNtO0ly0msXCsodW3SW0IdeQEJ5IKq23qcHAUYFaVjH9v1aCOWBLNJ0aYOAfNuhwQSWyV6N6nAHQE1lxStommxvYxLHFaXfltMoIjKmUjyyn8bjnG3qMZPOKEunUh2toaVndTWdzdabbvct5jK++cH7TPGVUYGfuoCrgu2NowACcVlstumiW0YluLmRYnETIT9nt2TosS9HYEDls4xliOlRx6lHJqM8lxCNQuSqooRtwZi3AkwepBH7lemAPcWjdWSJPcPJI7zriWFNyRjGflkCj5SPm/dKex3E/eFpNMyauTahLDeWKwvdi6usiUwRMTF5oG4huf3rnBypOMAjgdbt1aXF3YGISBriJRI32U5WMgZBduMkgcIuAM+4NN03SIks5Iru9k2uvkC2LjeeePu/MOckKpx65piWuLHbak2SWylkiiKgxEHJDSY+QHBG3JOD9KemyMvUu3lkba1ctKsl0iiTNom2Tbz05wiY9R27mnO1xNFKs4jlt3UK8iybYeTy2WGXPPABI5wKrQ2xtoo0iLSW5k5jkVtrbsjKjJZzyBuIwavWq3CzJBMNl0sYcSySK7sCT0zwvTnANS1prqSQS39xNbyJPDKr+WeHVgoK44jjAGepIJ9R9Kn1JFM9r9oO1ppSM3RDO3ynpGDgcD69OtMNrDdXMaEi4QCQusLGViflG3e3uT0xjFJaxRaa1sPMltod8i7jIpUKGKrl8buMqDknGaWmjQO5WBi0+7WCaf91HLGsM98jHBIJAUEgDoOw7Vdm8udrprgXl5CkZDSkCONAPmbrjj7uOD0FLHJp7RmON43ku5vMIG52KBgc5GT91QevU+1CRx3jtCba4mlNzIztvBVQHPGGYdto6fxUPXUW2gy3d7K1lmnvjZiCGOIRoqKxKqDxnPUtjgdxUlwvlT25imNzcovzwtKw+ZuMjscF8/wD6qdDF9rvpBFLJYkSCUw7AEKJwCcdiwJyD/DUepNM8NneNPMmbgOPKhUOIlRucEH3OP9oCn1F02OW8d+FZbV18T+GrJdO8VaTB5olAVRqUCjBtLnb99XwSCeY2CsOjA97ofiLTNf0XT9Us7w/Y723juYd4wdjqGXPvgisqO6WFcSajunmkzNHMqDYuMFTgAjsvflq8D8Gyyw+ENDjgJhgSxgWONX4RRGuAOOgFc0qeuhoqjjoevfD60ltfBGi6i0r/ACiaGTyQARGZ5D1A55x+OPeut1K3jgu7G8+1yRxSOIpCZSAynkYI9wB9D2rmfhMN/g/TLOdpzE6TPGwkwrjz5Pl45z/n0rcsINPR7zT7phPID5aFmLloiBgAc7SDnOMcitLvr0/ILaepYuP7Pt9Qgw8D2s4aKVQ+7BOSGzn/AHgfrWTrmpaT4bQ3t1dpZaEyLHJL5zAtIu7aicksW4UAZJIAGareMviFpfgnwZqF7rK3Di02wgRQnzJXZsRFQccscdcDIOSMV8za7431v4ueIY9Uu5BYwWirdQRmRWSxTrnKk/vMAlm6kcDC4DcOJxXsLJay/TufU5NkVXNW6jdqcd359kep6t8X9Slup18PWX9h6ayKTc3ZEtySONwgLbUGNuN5JweVBriptW8Z6teXUTa5q2pTXDgQSTubMBwTuxHCyAqBjouSQ3XFeHeJv2irPwvcz2/hu2i1LVDF5E+oyvi2jPAkjRVADoTv/wBnG3GcEnmfCdl8WfjlebtJvLy8tnuVS4ktLiOFLUsQCzIpVgACTkjn1JzXydXNlUqeyjeUvI/aMJwfHB4V4mtGNKmlpKe/9fNX7H094h03xN4L169tdP1bWIJBOZ1ns7yVw8RC4CRyM4baMDJQ57E10Wh/EzxHo121zeSjxNbKiG43bLLUQRkFlKhY3GFwFdYwc9cnJ+YPi34D+J/wT1/WZ7bUdUTwrBOPsmo3N2kkcisAQu2ViWboNuDyuccVZ8E/tRDVnt9P8aWsYj+4urWiFTGS3JdAcAYODtHYdMGtFmqpV3SqJwfnt95jLhJZhgIYrDctaFtXHSW3bv5Xuj7e8M+I7Dx7cNeabqV1PJZRhZrKdFgvLZ3wQjDb1wuRnIIxhiM53NTnmdraBGM93OxjJZfLuI0C5JIB2sMA+xyMV8vW51PTddstf0m8tg85jELggxyrkEwvs6x/N8wHc7lw1e4+APiRYfE62W7tIZtNa3BiuLa7cMYZuCqJMMgKRlg34YB4r6vDYpVrJ7r8T8dzfI55fepT1g932fZ/kdm6j7KQygYH7yVVLKSB1mQ/MvJJ3DkYznHFZS2YubiKVb6aPcm63hZtryJkttjJwGAO3hjk4P3e9y+dne3tPPa4ncH5bkoH2Dn/AFg4Zcgcd/wqTU5NlrMZrKOZWOZkWPGSeBvibnPbehOfcV33a+Z8wktjLvb+6aCW38qO4Mj4maN9sRfgAsCPkcMVJBGDwDyaqa2+nGCKzZ5YmDCInOLmFEU8OBncmQAH6jODwa1Esp4INwunivH/ANZkCUOMYICklZEwOg+cY4rNtZppbhbt7Z7mIARWjWsh8xQvV4N33lBJ/dk7sZ6gcNWvfobLZEUmo+GrzXo9Gt77Tpb+3mjM81vfRkgbVkTzk3ZDFWU4YfMCCDzx5T8MPj3qXjb9pz4yeENfm0TSbDwQtrDpt9Z70nuDMu/5yzlHxggrjPIx0JPknge2tbv/AIKM/Gi8k8Nx61ajw3p8SiSyRbczGO03A+dtCORuHBJyWGDWP+z7Z2D/ALVn7TkS+DYvszSaTHFp81rbYsUaNskbm2AhecDOcZzxWL5na5fM72R9m6T4gs9fsLbT7W70q6e1vCt9It0sn2eXG8owUkxuCyjaxU8jHXjD+O3xft/2cvg7428d36R3J06HbZqZW/0i6JEcETBm3HLsM7T0VjgYrwf9iHwPcaJ8bP2mdYTwvL4esL3xDFDpyajYtbxPb5nYhDjDKvykhcj5hzyK779rv4NX/wAUvgbrFhpWgTeItbg0W5j0aweRD5dw4CmdYzgCVkYqCWOxdwUAkmoldqz3L5rrQ47xZ+0t428E/se+CviHrfhnwwuoavfad9rt5LiY2Rtrn7srOQGEudrtgsqgfePbvvhB+1RpnxY+LGreHvBfhnXPEPhXTYhbW/jnYf7KaYZLxLK3LZ4CuMlsAdMMfmH9pDwFe+KvhV8CfhENNurj4l+ILKwh02PULxmsNMk062j+1RSxeZsUkbslUJwmCTu49J0eL9oJPH/gbw54p1f4V+DdOtbsalJpGkTTR3uq28KndGkLMpKqGDZTG0hCeBioS7fddfqQpPY+uZ7NtCvIvIk8y8uXL8sFUyZO5W/2GzgcHDY7tXhX7XP7SWl/ADwn4XSXwPY+JofFOqf2XPYSTrBHtZNysTsYMhyVZWAHLenPskOsyWcUj3tqJ3uT5Yt51dpEjH3FY45C9Sccgk5ytfGf7dfhZfiT8ePgB8OdJkF9eXd9davcTR7pHt4R5a73GTtTckhGSOQ2eeauSvaLL5nTtJOzR9T6je6v4H8M3uvahqYl0DS9OlvreNkNzekQoJhDLcNIBIVCSIjlQ7KQHcsGaTktN8M6H8KdCn8f+O7+XXfHVxcxKLuziLvI8uGj0/TITztO+RVC4LEM77VBCT/s4fEMfHf4F29295ENYt4TpfiHRL2JZmstQgHlSoVyNqyFC4VgR854+8K3NX8B/D7wJqGk+JPFN5dyxxQSw2+s61fTTpZmRvNJ3E7Iiy/IsnylsKmWZwG4KlK1pxtps29F5+em21tddT6zL8fGpCVCak3UfvKnFc1RJaQurOKcvjdpXunyvlSPGvgV+0TZeLfC19qt1YW+n2dt4g1HS7iXXNYkiS4mWQzNEJVR42Ea3IjQFtzx25baoyq63xn/AGgvEXwP8T/C2FPBej6pF4m1GLw+Y/7ScywOBgOdsIVWG5Djk4UjjOa8e+AXwytNL8OeLYdMsNR8YXh1rUWj+xNFbLZavLEXALMysJoFMJWIco+WfbMPJt4Pgr4THjj4KfD+/wDGXhBPE194H1RmuNfk8VxxwR3St5jzzTGQ+aqRkAANscoMNtZTVUKjTjGTfL03u0lq3/SOXH4R1XOrTV6ibdRJrljKUvdhDq2tmlzbO10mz7YezFx/Z8DiZ5BHJHGTjzJTGf7uR5UeN/OQffNeTftH/F7Wvgf8EvEXi/TbSz1ibRjE1ukxdIiDcxpIE2EFRyfn4OSNpxmvS7GHiNYIQnnKkkyXR3oZV4JKqBywbAiGegJVc5r5U/bSs/Cni/4AePY9E8Pw3/jG+eJ4haWTS3ckxuIjJgom52GH5HyAZGMivWl8LSPmHsdx49/aMvtN8cfAjw+uiaZdx+PS0N95kskUVkuy3lIhAVmIPmOMnDuR/CDmvbPBnjXQPF8M1/o2s6dqVmrvbl7CZWRXU7JYvkY7PmC/u0+Y8bjxXxT8R/Dnh3VPih+zJLaeGp5dO0maSPxHImiXAjt1NtbAC5VYyw+ZZPvksfm+6AMfTvwZ17wHqN34s0nwr4cl8I20Fyq3E11oD6Yl5hfLWS33IokQheNnz4wWYZBMw7NmMnroaXxe+LFp8IfAmua6PCGv+JE0m1kuZ5tJhiiSKJRuBkmkdUUKvBCCRvlPU1578MP2rtXHwv0rx58VPCkXgrQdevoG0W8029a7imiuQ32dZIlBeKTgEvgBgR93Ncr/AMFHPF7eEv2dtSay1DVhruvMuhxWrylkkiA33ZWEoflESPlgePMznpXzBr3i3wNc/s6eEvDtte+JbP4hQHwjLf6ZqV+09jPabVaKe2QMY1AEqjBCuu/Bzk1nOTUrNsSV0fo9F8evCS/FCL4ZHUJbDxbdWP8AatvZy2M8K3MCs4IEroCWHlMMcDjgk8VhftNfHYfAjS/B95aaFa+IbfXPEdpoNxDdTG3EQuFm2yggMcqYl+8DwT3rz7X7t0/4KleHIIYgrn4bvHtml+b/AI/5nJ44BwM4HGO1S/8ABQr7TP4M+DVw7xR+Z8TtEURoCQpC3GCWPXqf4fT6U23y6slLU9Vvv2itI0e4gS41vwfbXjRtbWsFzr5jluXG0tsjMOTjHIGTkjI9PL4f20dRuvid8I/DOgeHbXUNM8W399otxc3bXNlc2rwrCxkVJIlyu194O0hgR905rn/2n7/xF/w1t+zdJe2dsLmLUtauraCG9Z8qtumCSYfl4j4G1icY965Hxb8RNV+KHxz/AGOPFOpX2kau2q61rN1bXehSTNatCRAqLiaJHR02lHUg/MhIxnFRy62bv/XUSfU+8LWa7aWM+WkbWq+QqyJJgkqpbkL7KM88ZqOee31CSWSS0Z5pdkKDySfLJXMjH6ZOf90cVNHqtxp9pIJYIRMm9thmKlzuOCuVAI6d6jjW1cRm3uVM7IttbyRy4fOA0jsM84yDjn071t1vYXZIcthBdSCKzjjMDJ9mETrhSqnLZ4yOcL/nNMcb7uG5igijimlKgJJhZIkBYsRjHLKuOM4HvRHbSRXjxxTT/ZnAUumHIRflYsdpPJGAeOhOTSNc2t/Lm6mT7JHGJEZgY22BgAMcHLEZyOwUdzTIvdFmW6kIBuIpYbm6dUjb721AwIBweD+AyxFfPfhxY08PaWrRwKwtYgQucD5B056V75cxb5tPkeWcySSeZt3q4jwfkBbaeQ3PPH3ic7a8K0Ka4bQ9OLXKljbx5PmN12is5aW1LW7PXPAAs7v4cWEVxObe5zOI5PNYsD5z8jnOOBkf/WroxJ9usbafT7Voby3B2xqoCBiBujPPQ/0rlPALFvCWiXFpYb2t2nDs4AGzz33fw4BHUdyM11t3PcW6vq1rEkqFM3EKs2XUDrjH3hjp6A07WsaJPW54r8fPGA1bVdK0y3SS3gt4Wv7ptuXlO7ZDHtBz8rh3IPdF6CvlL44+NBoekwaNYrGmo6pGLu6uYT88cZzhSynlmDEHI3KARn5jj6G8eWEviD4va1cl/tYgvoY9qybESNLeBmdeCBy5PcnsM18ZfHDWYtY+JutPbSCa0tzHawOOhjjQAY9s7sdeMcnqfz7OsRKEJNaXdl6f1of1DwBl1KpKjSauox55evS/33t5G14P+H/hHWfhRruv6h4ne0162fFnpQhRJJvLUtIke6QB8qyHOBt2HAYnAq/Af4qQfBrxo3ieSK4vpobN47fT4ZjElxI/yqJG/uKMtjByQMDjNeal/kC4z35r1C51H4cv8Eo7eG1uP+E8FxC888LGONlxIAQZA24AHDhNuWKkcA18vQq3aqU7QcF97/zP1jMcHyU6mGxXPXp15pWSXuRelrq1l576ml8fPj0fjtaeHb27tJdN1bT45ILmzilZ7WQEgrNHn7rfeUg89OTVJfh94Uf4JP4m/wCEnK+JxcJIdGMSNKsO5ovuiT7jPsIcjKhfunINN+HOq/Diy8A+IovFFncS680kZ0ybyhNHE5SRQ3ljaWRflZ1ZiCdmBkc+XKAApzziqrV9fb1bTlOP3Pa/qYYHLlCH9n4FToU6M09laaerSb6a279D3/8AZt8fySSy+EL2QFJcGxmkbmM7jujyTtAG7eCwIG0jFfQ3ws8VPp3xC09YpCNO19VsLyKJiNkyFmicPnByEkj45O5Px+Hvh5qj6R450C6imNsUvIl81TgpubbkHBweevavqrU4Lzw9r1reSyRJFBPZ3lrPCR/paxTQ7mRQMAjj5M985Oc19HkuJnOnFv7Lt8j8843yuhGtUitFUi381v8Aoz7Ji0RmuXkgDxRMhJivAZEkdmBOVPPGOxHJHHFR3skMX2Zby3+zztIPKlM7tFGdvLqw+71AGQOWHvUi2062168dwzyq77t7MH45GGHsRxioJLS/jWFkkeNXj8lf3m5stzuwflY8ex59q/QleT1Z/KrSiyprcc1pHIhkgYT/ADqYI8s57kxgH5gOjr3xnjNI0theQRR2zz2tyEzFYPuaOUA4UqOhG7kOpBHXoKfsu9PuYrhdOijMQISRwMN8uCfk+ZcdMHd948jrVG7vLea6hXb5alzLIlsGKs4HBVRyjHJJdCRhfm61duiKRLDbyWNpcRxW4gnQBZTIoZpAWIw6j/WcsSHU56DHWvnT4GeBfEvg/wDbA+PfiDWPD1/pvhTX7rTW07ULllC3QghIJVWO4rkg5xxtA6ivf7i5murm1iikkiWF/tAlaUZTaNq8c9STjPyN/smr8epQaldg3czR3kUYSCW3gYlM8sxBHByMFCM4HTBzTatqzTluWNUjS4iu7z7X9jlchISG2ho2AX94mfmB+Y8gEAcEVl69pug6jcXl/f2MWu30MAVN0O020X8IAYjqxLY6/kKdEhu7eFUEDQXFwJpkLKsMsa5Zdq8mP7oyOmM/UT/ZrQwk6jeQNG12GG997cAAYk6nAVh05I71nyrqWkmtT5h+Mnwnl1X9qH4E6vovgwzeH/Dx1Ntfmt4httfMtwsQl3nliQCCARnp0r2Bfhb4Xmv9H1m48D6Lca3AftdvqM2lhp7bHzbFdlMi4ODlSBzjAya706zaWq3cMEcpeW4Kk8h9owGAL8sx+bkdNy5I4pJPFXnGadYDE8gES3Ck7YE4J6gfNkkgcZ+TGapLl1SFya3sUtd8SXE9jPPZaTNrWtu4trOwFwLVc5ILmRs7BlTvOGOBtAavM/hd8D2+G/xJ1zx142v08WePfEkAsptSjtiltZWi4CWlmCfljA2hy2GkOXOOc+v3dtYalaNd23+hLGqxQPDDiaT0BHDEEgADPUZ6gEU4Wgv7G5stUeddZUMo8wec+3lQFUdQR97+9nJPINCSTuJxufLvir9lb4g+Cf2lD8SPhX44t/A1n4kmD+KtMvLYXEDoFJa48gMElYsGLAMpVnLBxuIH00i6daJJo3iC4t9QtjELa6s7xPOiuSQcN5LluGG0bcn72MnrVmNH1+0ntrl3W5007/JWPbIwzyu/uOChA/2c54zBBerdadHHYW8d5PGdt1IuFUq2xgzsf4yCBjk8seMUlBPcaUoO6dmfD3wL+BXxY+G66h4S8ZeOYvh34Q1TxPqGrQXOlymO+ubrdCiIbgSAIZUYSRxF3YrHKSpYK0cvjTwD8S/CviHx03wph0bxT4T1bWIrS90fUr+O3tr6QpEtwyswCGSSWVbZZI5Y2XbJGAzGPyfuG50xNetZkvpZLu8kT/kGQsfKb5ByQeo6EkkDPA560dQmsrjTZNLmt7LU9NeMpPZgeTbQQSpgqzdQpyyshGCrdBgVxywcZTb/AK2ta99utu59Hh84lSw8aNnzWte60ftOfnSa+P7PM3fl09PPPgSnjef4baRH8TNOi0Txqk08t3aRXKSQIsssh2hYicZBUeUC2AqhjgVyHxz+Gfj74y2uoeCbXVf+FdeBnbzdS1m4YPqmpRZ3fZ7a3jbEUZKkGR2zggCNVyH6jUvGmreEbyz8N+FXXVvE08TtZyahEfL0+0yUJnclnkSOQPskH7yYcNvZWlPVeGr+80DXtG8MX+orrvia80+51W4vLdRDLNCksEKBlDv5YfzM53kFoW+Ybtq6rEx5uW2i0fZPt5v0vbrY4auUV4UlVU0005RWvM4JNudraRVre81d/DzWZy3iP9njUNX+Gen6DpuueJvD+qaXaNDpPiv+27i61m3kIJRpZFZTJFuwGj6bSAAMUv7MDfFnSPh1bp8akhtPF9tfTWK6k90s51G1wPKkaOPjOcgH5TjBIya9R3vojiCKZdOaJmQW8Eb3Mjo+TGpC5AKsQM4JA46Gt61tdPutMjnf9zIxV2mlbMwkBDAF25OPbseOtdTaTTa+48C3S54t+0d8FLb4j/Dr4iapptle+JPG8vhi70rRYJh5TWxnjO8QKwVQ8xCBnPJVFTIxz54P2P4viX+zr8NPCuprYeAfHGnWmivq2pJZRzXzfYo1H2V3Vlz8xyDuYAr0OK+qbRo7/Ur2GW9a5PlqgCfuiw+82CvJA3Lzn1o1HTrOz3htPQxSiOOKSKINIHJYf72QCCD7HmktG0+pm1szxy//AGcf7O/aZ074vHxZe3TWvhmXw+un6kolkeRpmYS+fkbVxKfkCcbSd2CRXNfto/CnxD8VfA3w1s/COnnXJtP8d6fq11vv0hENjEs4Mm6RuANyj5QT8wODX0drFwGaNXSWFAHbzZI8qvGNxGecKW69yKjdLCPT7e18uFRM24wKoyEyW2gD8FoSXKkyHdSbPFdc+Cl14u8YeHvFes6df3mseGjPcaZdt4ox9jMy7XIQWmGZkAyGB7cc15Hrf7NXjTSP2iPgbreh6Bd3OiaJ4g1HVNZmuPEX2yO0a5jiLGOORIzGDsYlIgy5A4Hf7GjsJIdPuBDNIk0kqqoBBDSYGckjkZGCf9g0iXMltDMzFmCRrsudqjG9zuc5x8xIyPXA9aHGJOqa1JWvri5l2vC9puLQQPvVk3Hhn6jOB045555FNmtUZ5GDxLFIu7bNEHWOAcbgc/KWwPXtxwaRXSZpMxOjKir5RXa0PXy41yPvE/MT04Hbqii4ht3Z1iljicefcM+FkccDII+4hxxnHHXrVLTYd7kNvcy+TNFIIpUhIFwu4h9g4WMDaScjnpznGfm4txSXExa8B3Oz7VtZQcNIuVwCOy5IJwRnJ7CopGjRbeZ7TZIoPkvMiv8AMTzKx6854HfIHU8Vltjplq8f2QwyxwjMsEoXyIxjHOR856+/0FU1cjYtWKXEesTNCiS3DuFZvMIRTxufGCOMhccZ6Z614V4cMv8Awj2l/Kf+PWLsP7g/2a9x02NnhJe2ntiHMlzcrIA7YOAoIbOduM56cjGTXh2hRxf2Hp3lxx+X9nj2/KOm0YrKdrmsG7Hqnw2ZbDwdp8hupxA6ysVh42nzpBxjOTlh9ceorZZII7pGaK5m02dNnlyMFVXJ6kZwcjHuMGsf4eNJqXgS1tne5BUzBSYSwXEzlSRnrgjr2BIroLeZWjeyljv7h4gFZVJJAxnDZx7cjr8p7mnfTXcceh82+P7G/wBH8Y+NYHgMGnz6hFfMm1ZHmt2tYtyMOQEASQYP3iNvAJ3fIXx70uWw+KmtmWMqtyy3Ctu3CQFQCwOFyCVPYdDX2z8efBd5cT2WpiGeWXH9nSrPKoUqW3WznPCnc0kef9tPevC/iV8LYvGFj4Wnu0+wXoupFvry3VW2WikebMFwuduFYDBOWPvXweb4OdVShHdO6+Z/TXA+cUMJGliqjSTi4y7qyvtv0/E+WNuO2D3r2zS/2RvGusaTYajHPo9rBeBAqX18sMqyMM+Uyk5D54x1PFer2f7IXw3Xy7uP4nyyQ27BZpYXgwsuAybWxgeuDk/Suo0i20LUtZ1CLU/GZs9ObyZMzB/MkCICpfJHkOXyojOSwXGfXx8LlChf61Z32tJfM+zzbjWWIjF5S2uW7lzU5PskktPU8OH7G3jOKB7i41Tw/HBDIYZvL1BXZHBxsAHVz2XryBxXh19ZS6bfXVpco8VxBI0UscgwyspwQR2PtX3R4hh0WDSYrqy8YmO8vpxPfQvvt0ghMgDKfnYxOoIKoxO4xn3rntT/AGVPBHjC5bXrv4kXUE+outwyT26RlEYhQu1jlCCAvJOMY5NPF5VCaSwq1W95I58p40rUW55tJuL0XLTkmmvS58qfDrTX1jx7oFokTTb72JjGpALKrBm6+ymvsDXL6bxLpj6faYvzdX1pBp7oyMBcNOp3qwUA/fc54O1DwOc8b4R+Amm+B/EXifUtNvJPFVjZW7Lp7RqgM4C/vl7gtkSRqRkE85BFehfA3wjP4n+I76i1vFJHpSfbWndgiSTyKRCoVRhvkZ5COweHGK9HKcHUoL2ct29fTY8Hi3O8JmCeKpP3YQVr6O7123XRep9My3c0st0sJlVGALKnlgBVK/MRnJBVu39KSPw273dok8sW1YIzwpf5kyDt3E4+8OQM8GrWneVp9nBMQIoHUQzRsgXa+SACB05O3H0+tVIHubySyhfekUUkkQJVhtUKdoYhgSdvHHcGv0GLs7R2P5flq7vcdDpcttZpMl47Tg+SqliCWLgZyzEk5A65HoKy9N1BtfhsNQ0u/s/E9jKzxRz2swnVdufMIkGMMGVRwcgjBFa9holrbQWiyeawtrw79xIIYnG4HqByhznHJ9a/NX9hLQLK5+JP7RMVx4a1HX47XXXit2tZ4kS3zPc7g3mTR/eCrnbk/J24zDk+bT8ik7H6HPCYb4C6sprSRkykSB5Ac5LHB6DOOmQTnIyayLfXLdNYvdFgv7RtTihS6ks7abFxHERw/lEFlGQcOVyCTtLAYHhvi/4k/DPwF8SND8Faz4Pvz4k19I/sOm38tuyzo0hjGx1umXcXBG3cDn2FeF3/AMJdTj/4KZeGNbj8Aar4S8L2WnwzXF0kObe3lW1kCyNLFIyE7wgxvzkcj10jJydlr8i1NRPvi2htrmDTYWugsAbOLgMpkk2nDbwcBsk4Yfe64NX7LQ4ppYZft0W2e4lmZ4go8wjP7xlJKkDGAQO/NU5bUxJay39qsVsp2i5t8EkkYVSp4PO0kYHIz16y2Wk2OqvapDf+YJ5mxG7BpPLCkhmJ53cKcjHJPLVT9TX1E0u+8O2l4ttb3VrcXNsjXc1sJllkQSf6kFeSN4bIGOce1bUdwqRD9208lr+8eFVJ826f+HHXjJ/76B7V+dvxNGgW/wDwVY8C/wBsjfoN54cWS5jmRisubO68veqDLYIjx15A9K+pvGvjP9n7wYNPt9audE8Ovfs0EUl9FPbOUA+cRkhST8wGF7tz1rmc+7M3JXaR69eQWOk6xY28F3Yr4llSS6Fk8gWa+jX/AFpRMhmCluwwMgHrTtVmMcVvqVtqgub1B5phiOI5oSeQEGSAAThjnBz3r81v2rrDwVN+378A7Hw/bR2OlyvYLeRWwls/ma+fudpXIxyOK/UGF7izu0jvEtgLxmU+RCygycsQc5ByA3Jx+tOMpbsSlqc/qMQXUdP1qVYZ7K7Ajl8nds2kfLxn5yR7Y+XBFVZQNN1O5WZBp+nXoBmBAEvlMflyOigHcvALYYcA1bOhxJZanpUVm8t2hkFtIFPlxo3zJgnhfvYIXk4NZ0czazpMNyHMl3ERHPc3abo1boYI0H3mPHv3Yn7tbLa5p0K2vX9v4KtftNzexaFpqR7mmuHVZAjuY182R2AjG54xlj1GAQadFqNjq1jBNLbwCznVUgms286JE6fuwvMzBw3z8qODnk18H6/8QPFP7RnjX48/ADxp4mTR/Cmn6wot9Qs9Ha7v/JivUaOBjGwDBViTG4ZyMZ6CtD9o74o6x+yx+zj4ftfhZqel6Zp9nqdvYbrbw3PEZojFIzpLNNI6lnMYLqvJDZyO+ftJLVoy51ex9eW/gfWtG1Lxvrvhy2srvxD4ivYJoFurx4nihitY4lNxMInKlZEmby1xkNgMvbkvDttpmjeEfE2pWfibV9eubjURZ6vrXhzT542LRsB9mi2hpBEpHlq8Bdh58j7shmHpmiW+oL4f0bULqVL2WS3tm1GOC3aO1eR0TcwXcWI3Yxkt35OaxvGfw317xVoDeHl1YxeCt8klzaw2/wDZ032RVXZYpswPJPzqz7Vby1SPDFnkrhq0eW0qa5t9POXXdb3d3q7bWPsMBmkav7vFT5Nad5LdwppJL4ZXsox5Y3jFyS5uaytp+BNeGt6j4l02LTNXttDtryMWs89u6vNMUDTLEXQSeXGwQiWQnc0jhG2ItW9C8QaTouvW+mX15p9rrGrSyfYLXUrxVubnylXcIQ2TJgNHkAnG7A4o0zxPcaFc6XaajqFvDo16kUOn3NkEAinKgfZ5928hnb/VuMKxbyyFfy/O/PXx5Z+Hf2sf287Twp4m1aK18B/D60llvne4WJLq4TM9zH5m4bNzKQzLjCwOQAOR1QkqcHFy2fpu9Pl0R4GLpVMRWU6VPSSTSV5XtH3m31ejc9FZ3dkj9LrAzHWr6V/JVELFnIOEIwG5JGOpP0HPQVetb1r7UoZRLBLa7SsMkIyruV3FgcnjaMZBxkmvi/4O/tM+MviD+0x8QvAui+H7HV/hdok6aXd6zO8kM1qyp5DLvAdZt8iyBVYBiqZLcGm/sF/FzTPCnw+1P4VtHBZ+I/A2qahYzadOmyaWL7S5FyAPvDHyMexUdmFaOXvXeiPETSVj7R1UmTUkVcZEYC5yQSSSVOOg4Vj7DHQ1X1S8tr+X7PGVlWFBJkcOhPy7sdc4IA9S3tS6BqQvLV7+aB47h4klaNfn2K6BwAeucYzn+6O1Mtwt/freyOVSFjIWViCDtwF6jnBGBzwM9X42St8iZO/zMnVNe0vT9Y0/w6+u2S66tsJDpUt5Es8itwCiH5yDtYFv7u7kZrWnuWQJDNBJnZ9pkLBXjJ/vYycqmOFA5IWvl39tn4DeG/2gNH8IaPqPjfR/BHiRNdLaRqOozKZmZkPnWqfMG3DEbcH76KMd66/4sfEvwh8Gf+ESj8ceMvE2m3GvtHp2nyWnm3AuJ4kjTzXRYmILbkPH3mLH6Z8z3unb7ybX8j3SHT/tbFrYFWbDs3mMGCENtORyHbcxz2HHYVFJfzyXQsTFDPa/dWJbgMJWXIaPJUZVTgvnpjBznFfG0fizxLcft56x8I5vHmt2fw/tPDQ1JoWuEhnSUwR8m4EYkXBfIwy49R0r6J+DXwQ8M/ATR9T0zwsmp2uk3s7XU8d/d3F8sTE7v3e9mMbuGBfGMtt6kCnBylulb8ROyO+a2Se6itooYvtG/wA13b/VkjIwuD91SQcZ5OBjk0t8CtgSiKkMsmxXNxkXMnYkkYwcen6U9oIbm6Czww28KIgMK2+coThVK4yM49fQdjUV/EyqskoW2LkblW1KYA5DEE/NxwRzyAOnXdbol7MfNCwgSXyZLaABVht0umAdt2ckcZJGfwOT0rxLw5Kn/CPaX/r4v9Fi/dm4fK/IOPvdq9zltlZVe4t1EzlSsEdmzKmDuwOx6DJP8sV4f4aDTeHNKkYLue0iY/IO6D/ZqW9ENRfQ9J+HDhPDNks1xBjMyIrzyJj985UYGOOwwODn2rfvrY2M9vcJBbyFpVjbBkZVT1LMOmOSe2BjvWX4BdIvBOjS4mWSNpSh84D5fOcFVUHPT24xXQ3TmeLYzx2+erzXzMy85BCj86zvqapaMo+LfBsXibRLywu7S1uLK4haKa2jVj50bDDLknnqSOOoBr4u1VNZ0fxnqtjJe/af7IjTS4byJQxkCuH/AHitkBvmj3dh5ZIOQDX2Zp04bTwk0iusR8l3m85t5A7YIB4xwPevgzx1qcumfEXWbLVbC78O3F1eXNykWqR+SsytK7ho8tnZgjDAdjXz2b3hCLfRn61wFavXq0pNWcVo+990vQt+KvgTo3jLR59Xs2h0jWHkPyQlnhnYYYkgk5JQhhgg+xqt8LP2XrbU1u5/FDfaSZpLa3trW68qNtu0GV5AC6kNuUJtOcEnaBmuv8FeJ5o7K5+1alDaCCY/v5WTMikYIKtnJPJ3YySWAFdVo2u6ZfXNxBcagunadBiSGBl+zGVPlc4mcgA7xyhKllPXjnwKeHw9Saqta9unzP03F5jmeFoVMNCo1FPdatLsnv8A10POPix+zJosXh+71PwoGtNRtT5s9hJcebFNE8gAdZGbgKA5ABYttPIIxVHwl+ztY+HbF9U1yVNU1G3yfsYJEKptyCe5ydoGcDJ4BFeu6y+laD5g07VIry6u5Bay6dF/pkUa8I+9lYlDtGCAy7sAAcEnD13WEtdHf7JcWx+1TpbxPC7CSFljZjuBI3OAQRlRjIPUCqlhsPGp7TlV/wAPuOfC5tmVTDRwzqNpvd726q71tvrcp6rrmq+HNR069t0gkuEvvKjilkMccEbs8AZ2CsWUZgyTk4QbeBz9QfDb4dJ8N9EtdMe4R5iTI96iH57piWdnyc4ByqA8bAFPIr4d13XLrXdR/szTbSXVdevsRi0tNpd2ChQCgbcANo/hOO+K/QGD7V4h0q3lki2yDErWzOoxkfdYEEZwSM9Aw6cCveyy03KXbQ/O+NIywsaNJP4rtpdbWt+u42e4k1V1W3Uo1wudm/anmBfvZ+9jH6EHqK01SBbYoJPLhnIIcjmOcYznnruA49QR3qhbRw6eFMsxdJx0UKHtmUnGOBxyByOD14JqtIJ9YlYySC1RyqE7SESYcq7dgTwuD0PHXBr6Fxvp0R+Upvcs20txr9yoYpDFcRAoqM213ViGBPGTjHbge4r4I/4J4WE09z8adettS0nw8Nd8az2VjJrMIn86WMSzeTH+8T5wJQ3BbIR+OM19r/F7x/8A8K1+HOta3a2cs+oQRmLTtOtU8yaTUnyLeJF53eZIyjoQBuJwMkfm9+1h8Err9n//AIJ7+B/D95fG41STxbb6lf3EB3p/aEtvcmbDr1KBVQE8naSMZrJptNrSxdzv/j5aanL/AMFIfgN/xMtOe+udNDrLaWDokWTcnBjWYliOvDL2/H69g0jxNqfxL8MPb/Fa1dNIdpdV8L2FiiG8hlQhDdB5WkQAY8sgKMndzXJ/2f8As43Wm6Nq09p4SudTtIoWS4kg3T5K4ZQxBYclsgHrnvXzP8N7LwXqv/BV/Xbnw3awXmh2nh37XbCxZo4vOWzhVmIJG4fM4Ibg5z2FQrOyTuCfc/QaWy/siT7VdQ29m6klbiNmNo+cqA6HlDhiMjOOfpUt1Z2LPOLi3kadyZJJLINsiDNgDPGTwTkDPBPHWo42aKGO2S8udPlB8qf7QoaIZGcBjkAkHACsP0pI5Dp2DbLBp8UOUkuYtz2spxgBh2x3bnGMZ7VpqdCPgz4nQywf8Fdvh3/Z1rHrUh8OFo7e5nEaOPsd6MB9pGAOnBzjFUP+Cnj6/YeG/hj44vfDVvZW3h/xKHL22o/aBsZQ0KMAilQ32V/mH+FcH+0r8VLv4df8FK/D/il/AOpawbPRo4LTRtKkzNqfm21xGksJQElTJKeMZIjPGTX074i+G/xD/aw+E+ueGfHfgzSvhtoepRK1laXGoS32qx3KjFvLJtCxQhZELPncxUOuBxWXK763MdNdT0HxHYeKPGGveENe034e+EddlW8WVNV1vU/Nn+wt8z/ZplhLhgWDISQmFbOeDXtE0l7Np0kZs2murCQSAySKrPswyHAB5ZePTOa/MX4Nft0+Jf2XLFfhR8dfDOrJPoUcaaXrdtFmfyEx5UeCVEkJTISVGzgjIPUfX37Iv7Qdj+0j4X13xTb290yS6vd2q6ZcXGDY20XlfZ0Zt3JaNjK5yfmd8ZAqou+li1bc9+nuDfTWcslvdW9pekRMjSBdxwSm5VyQDlh94ds5rmPFoTwnqUlzYadf6gbwbZLbTLV5nhIBGSVz5aHJBI+YcYwDkaE+uSXVjbR+bHH5IKq0RB2Mh2lt7AbsdgvHIJYZAPP+JPiLp3gS3ht9Xe4tHlH7uysra4u7m+YKC7JHErTSEcdlAzhiRirSdrodtz5E+AHgzxF4O/av+PXi3WLDxd4Y8P6/fOdOutL0tXe6X7QWKNE0UjIMFT0U+/Necf8ABULxToEHw10fw7/bfimTxLcatDf/ANk+IrOK3zbLFMpuERIk2/OwXJ65IAwM19V6l4y+MvxS1J7H4beGE+GFi0bwy+KvF0UE92Itw2vb6dCG2kYbaZ2xyQRkV8E/t2/Db4X/AAx8Fixi8Q6/4q+NF7rEV1rGreKLe5hvZYPLnEhVXURiLesWNpY+jEDFZyumraL8/wDIw0vdH07+yL+y98VD41Hxo+KfijULHXPEHkIvhOzIUT2ojGxbpSNsYSNfkRfmXaCWBJFfbOtW0VxHBZiyu47y6kWON5ZWYY+85LBzwFU5B65HWofCsj3lhpqXqva/Y7WGGKVQUBl8tdxDcgELtQgn+9xV22uoZr9576/YwRsY7OaRfKDcfO+5eDzlR04U8c5rVabL7gs7anL/AB31i4tvh7faTbaZDc6nro/suxScRPbrLNlAXMhVMDccByA5KIPmdVPwR+zd4T1D4YftC/tA+GvCks7ay2lm0tzrkiyTaVcyIkj3d66t5RDyKN3kyNyVHAHH6D3c9rr0d+9/L9tiuInt7exuIEMctu3ys0oZSCsmfT5kxgEgivzy8Eauul/tjfHDS7jXo/C1grRWuq+KZbljNZWWzdPLJPKSWkxHFbI75IaRGx5rFn4cRzQ97W3lbf5p/wCSPpMsdCqlh7Lmbd3Jztyvf4JR2Su1ZuWiV9Edf8PPiz4Z+Auh2nwV0zwf/aHiSCee/wBX1y21e2K3UiCUy3E2H85cBCrbl2qAfujOPBfiV4O8SfHX9rfxI/w9sX8FePdKMc11Mt6zQHZGgknaVVykgBGU24YKR975T2XwouPDml/Fbx98R/EFnL4H+Hz2cmjaDqMMFxHcWlnKy/ZJpmCsY2nQPIjyfNl1y214i3S/sCaifGPx7+OHxD09Lh/Cl1dx6fDeXbu0rCWRjEzM7F2bEaM4yWO7JJqMNKbjyT6du68+vrpr0ObPKOGjVVahzJz973rK6lqnypLkvq1G8lytNSas39/+B9J1zRPh/wCHdL1bWk8S6l9miN3qT2qW73A2ZU+WuFByFUDHIQ571uSFf7NRWspW+0szMJMFiu3JAOeM4BJOO564Fclb32osxtbm2kt1gjWykZGR1EahV8w85weT8vJ3LnjFbb3N1dzRzyfa43miWNUXncwJkKEkYAAGGIPUjpXqRa0R8y9bs+GP+Ck3hDQhdfBC4j0yyjbVPFyR3p+xpGbgMId2/C7mUhsYJPAz3q1/wUe1aE/ED4BafHqNo17a+M1kltxKvnxgyWwSSSMgGNSFwoPGF44rR/4KM/DTx/8AFBfg7p3g+D7c8PiFgdR8tvMs7iVIzFcOcELbjy5DuI/gAOSRnzL9rTwJ4a+Ftv8As6aVZ6zZ+JdVPjM3niDXpbxZ7jUbkva+ZNcNuJA4IC5wiqB61Du27mitodrfR+I7v/gqZ4rTwwNPtddk8H7LeXV4ZJoY2MMWJXRDlsHDYOAfavrL4E+HfH/gfwd/ZPxA8Y2HjvVbW6f7FfQ6W1o7AliyyDdtcq3RwBhc9SAa+V9EubKL/gq14mkW8shaN4WXbP8AbI2ji+WHGHPBYeh5z3r6j+E37Rvw/wDjNrniPTPBXiZb248P3H2K6gEfnKT5hHmxcZeJiNokXKk+mRmlyN+Zm7npF5JJA6TTtHdMSOTDt+diNmCWxgAgDn1ODmpPKnZZI9qm7chlZVGEII5HzH5QfUc/Wi4Q3P8AobOhSZdjrJEIgq9znZkE9BzzjPY1LFB5aSM1uZXd9m+3lLDkjA5BI25zjnHzVrdJeZmU7acWzBnt8TtKIlh8oZQEfKuNwx9wH/62DXiXhyVz4e0v+H/RYvl44+Qf7de5xwxxzQkSvb3bybQssahZCcbgEK54AB6dvrXiWiFv7FsPlb/j3j9f7o96UnF9Ckn1PWPhxpsT+BNMci3hBM5MjoXcsJ3wQSQAfzreiluJpDF5kimMYk8lQu7PTb0wvuSeuPeuW+GdwYvDGneYGdd1wkciRY8thcS/LuYYGcZ3D0we1dTcQj7SLhyrSxgAmVg0YUkN87NgMe429PxrCzvqb37GeUNpepOgZYTF5UjTTYSJtw2nKjqeQcH0yfXmvHvw+8O/E/SxY+I7C31OKIGaISCQNC2Mb1IJdTgnuvXp0rq7HzdRRxKFkucbXHljCckcFsgj/dXvmq17dRaPZxxktflWWJbidjsRsgHg8HGCQVB6YpziqnuyVzehXqYeaqUpOLWzWjR4no37Jngf7O9xLFqt0rwrGjXN35P2Rj82YnUiQNgkZIO4MeOTVVP2T9GhtXsx4v8AEsVoyGQR7rYb+CNoLxbhjIAJ6jGcGvatQ06/vpUvY5oVSNDIr3W5o5DjI3AkDGD97aNp554Fa+iXtqXKWdjcGQYRmKBFQcfKDwPf5eOnqK5JYPDtaQR78OIs0Ur+3l83c+fU/ZTs7PypLbxF4jt9NiCtIrTW8R4yPlfys8AknHp3rWf9lPwFJY/2dazatHM5zNcW1680k67QMPJIGXAGMbFGBjnk162L68u9SnfVIrfTbS4Bt7S7WTzmB+YcFgAhJwRwcnjPAp9p4mt01c6fYJv2qItssh2blJTcCevKhSe5IpxwdC1lBCnxFmc5KUq70/rp+pyPw5+Cfh34aW8tt4a0OKG48wLLfXR8y5mGAQZHYD5cMQAB0x36drcPGiyi61ARKoKEQ5OVIOAoUYxgj8QaWGP+0YZri8uJom2mGWMLsXI5OQfTPTvnvnh8ctq+lqtjaqJ5lwsroQFIzg7sdAw4XP4V1QjCEVGCsl2PDr4iti5urWm5N63e7K4aKSNCLO5nnaRkyvyxvgDjryGBPHXA/wBmrpjuGu54vJgsopogzxudyueV3cDGQdvbpg9uIdTmngmtm1C7dLMHLmAeWoI5GWxk+wGDkmqcFw0Eks/2JLpSiFZZ5cbH6mIMxHG3LZ7ZxzVtp6mCJJbWyufs93fuJ5I8xSR7izKwPysh/iK7u2M7uOhFcn8TPh74U+Luj/2J4r8NR+KNLtp0u5I76FlgEqoyJcDBBDqrMDgbSM8dMdNaXDyaU+8Q6cuWk+yeUu+IEbupIDFc8H+8Ku2t5584nSS/vriNSA8CIqPkg7QWABHAOenJOTSv1NE1sWYbOXT2tZ7lYZbQBSwh4S1cDh1HOQckEjpkEcZxycnwy8F6X8VJfGiaBZS+NLyEWjasilriW1YCMwk7tox8gBIGVAGa37SwkeG/gNo5iU5BubgquxgCFypK/KQwwMDgZrMkkl0+K1hjjs7WJl3fZzPuESNlnRgFBwSwIA+6eh6Cs/maJI2YpZTaCV5YIkMcLtufzN21iuWIIHB4br/Wo5oVtraYMDaqJnExhZjAFUjdmIdB04HXPJPOc+F9Ru7PImt4JZN4aJgXLtgqwOSAQ65+bgFkVu5q7Mx2OTcXMZfdITESGZWA7gYDbFxnOQQcdRVFpnNv4b0tfEb+I49G09tTa3GmxanHb7X+yGTf5aSOSYQzSN8vCnJ7ni+IIfKZYofsp3sGieTYFZuqEHIC44LdhG2Acmrcun2cctxK6HzjKwMojDFiGCooQ8EEOq4IPLdsEirJpwto4/tLSXIjUrAmVymAzbF9flJ49hngU7ji10MrxX4S8N+M7aC18V+HrfxHYeYEeLUrG3nQ+Z/y02uWIJOCAcdgADgHM8IeFPC/w20BdG8M6Lpeg2EF1cTPa6ciRwO5YhX8gnIfou7BGQQQ3ArsLxraSCPyLRb8nCNbYVd4O7eSx5xnPJJ39R0yM6KxgvwrQxRS26SFyJnyQ+5slvX5sHgH7zEcGhTfXYnRO9hA6S3sdwNwExDKQpzvzgrxySTyCMck8HvcW+snuJLtcEW0JLBP3bmLIPygxAnn5ccYP1NT3NosG+N7eK3ZFWJnZQdkZZFO3IGNvXaDj5R0yKU6akX2W6Kz3T2xEtrCcbpATnexJ7ADqAcqM5zQ5dUJu5YlkksNOkmkjla/vIjLaOsrFh8gIj9cLnJ6gjcepxXL+Ofgx4O+IN9pl14j8L6P4t1XSy0+m3t/aee1k0rrvYoTtcbhuAP9zp3rpNAhtrK9upbdvMnQbYVC7Y4lbHyBf4fmJJA9u2KTXdTn0LS5Z2RIpWkQOSRwT0LY6f8A1qylNopQUldmlNNDeWC2enLJ9gbMc7oDvReQVAbB3HnnsOepFZOr3M84j0GyYfZ41iWcyxLGEjHPlqOAWKjGOg4z3B5j4r6NZ3nhKWVy03lktAwGzacc7cHODivFLTR9amkmv2haG4LS3ckjqyRPuHzfKM92JAJ/lUqppcwqPkdj6A8QysZ7XRrUyOzyK93PJtKopK4J5AYk+nXB+lcVqPwC+H1tq+oeKrnwXZT69rl15mo3M0QllupUfcrsG+ViCobaFUE84JAI1PBFhL4b8M6DplzcRQXRiEzW8EQ/eIwBXeQP0r0Rrt55bNY2/dSgqQZMLkDJG3vxntS9pfcuMNpX1PMpfhnoGqeAtS8L3nhu3n0bUrc2z6WkHkQtEx8yQCOPHlAuQc5ypPpWl8JPAfhnwd4Ym8KeF9M07RNPkUypa2dn5MW8/e3Mr7pHwPvZBIxn3627nQG5eyt0juYox5kxjGVU8DPqOeR7CvNNctfEOpeJLbw7ZXq6foWqhw/iLQomt7+Big3RFW3+UW+dhckEDAQBZCkhTmqcLRjfpZHRh6DxtdqrUS3k5Sb6at9W3a7tuyxY+J11y41e3QJqkPhmRLG+vUddk8yMS8bIpb5oV8oluR+9I4aMrXRWeqpcWDy3Ooi0mM+UciTfGc/vCxAAKnb2BOTy1cvAkPg6yey+H9hbr4V022+w3UqsZ4LRVXfIzQq3mzyOJUKoq7nY8nLZbA8MeINSudQtLwTJc6LewIyrHLFts2KHlCV/eQuMYZSzqxHLK37rGnUaVp6y6221/NLa/wB/W3RjMHTcnWw3u07e7zP3nypavdRlLWSi3tpG9483rU9/NZyXFxa+dc27QiSJIp1KrCwwC+8kEE5wo4z0A61TvfDmiW8hjl0nT4d6mb/S9JjdXYYzLLtXO0HOASN3GDWolp9psrgwQqTFsg/1q7ygHGCPlDk/dLEjjoDTZrp7JnuJLeYiB4whEW6SQsAH3tjlwQM5OefSu5Ss00eHy30K9n4W0HVISzeHdAlN0rz288VoispIAyflO3OQev54rRstA0vTb4XFrYNpCwfJMLSJDjoVB2j7oG1unpxway4m/wBTcRWttelU3XUtoFV1if8A1cSrwNuTgh8nknFbN08UDGOSee0wrGRiHZC4IKx/MSegUkA4IHTtW3M777mdl2NiG5uRaNLBdQXM0zgYfoDwATjnpg7fU9agKPC8UMlhLHIhMz3EEgldeT8zADJJPPf6YFFvdTvdTRX1lBciSINiIKCVXAO4M2Mktkc8DjtRZZWJLe3nltb9hiYT8hG6cKx5PGFwcY71HfQp9CxZ3jPdLOt5BcFPlEdwDG4TI5H1/wB3nI6dD4Bok3/ElsP3UY/0ePjb/sj/AGa9/wBryGxeTT1uoYCUBgYF1x8oYbsEjAPQnr3rwLRI1/sWwxjH2ePq65+6P9qspW0KuepfDy5az8E6c212d5rpBKAJCi/aZt2EH0HPTnk10FrbsJ4/sJjCS5JRn8xgAOGDDhOcDgYrnfhoJl8IRPBOixRTXUcpkOCf9LnICtjjqPX9K6jT1h8+WRraXTppEX5BnJ9yR8pOWxz6c9ataIrqRXk8KyJaFJIBFy0rtxuPbzCcA9c9+2KhtIJra2jllV7+3iYsnl4VyFGQxLEbumBjA4BxSIZprRxFt1TzVdltyBthBJJ34+VjnIAIB4xx1ovZbUaYrxm4g8yFF2tkgxnAZ9oJXgE+nPfiqtol/X+Yr3d2UftkN+d1s7G0aaKXyW+6WbBxt643YJPCkZ64zVXVNQu4G82/LwxCZQPJkKhyB6HkY2Mc4PUc96v2CzedBdQ7L+OXzPLuFYLLKkjDDNlSDgbTwR9O1S31xs2JbwzR3gb5GyUWMLlPmZCVIAGNvX6dal2b5ehSd1zHNW0Q1yQJqMqfZXWN0Q3CZQsnBXbnBIJXcDjP14z9T1ufwdq0kEPm3C7lcQXETbjs6hpA2XYYHIznIxkDA3rix8qwT/R4SYN+6SKNY3I2jzAo+797PCsCDz16xQ6pPdXlsZ7M3H2Qt5bYMimRRjO4KTwNy9Oqnkc0LV26Ih6a9Rg1SG7vZJ7u3ivJiiFo4yQsR2FtpA6/MxAIzk7uprWi1ufUoGt7e4ge0Vdry42Fc4KqB13YI5HTng7gRnatqWnw2lxPc6LDHcIPNLxssbbtu1SRnJwCuQeRzgVHbQ2Uehm80+G4tGuH8pISGKo/AwcZ242qSeuVA9cpu65mNWTsjQmDR2w/tR3VYsYuriQurDcFYngAdFIPUbwOecl2zX93NMcbJol8qI8yNh9y/KTgEZIzjp16VkW+uN/a8VgtyLlY4vOlh5ZcYynBJ4O5hv59+lbtlc28MAmjXzJPKEm8hnGwfcIBAPzNjtxk9O8vpcqLvcuahYaeLe3WOGX7ST5aIXxMGODnaf4gQDkdOvrmrpd7cQhYnISVEBeSNTIoOAfvkYI+cfN3AOfZPD93HLZOklu0xe4cSw8SA7m2fKDyFGMYxkj2znE1DxBFpV3YNctItjdq8iQqzMQFBypUhRkg8/NyB0BFLW9jW50M00dxCEmt/td3bsfOSRy6ueVUsBztzyML/PJTU4vtEEcMmILVZ0AjtUyduQRjcCGGFOQBnqOtZOia1aa3DPqFgFMUTsyW4dWdGxnIXOVBLDCg9eMcVKbdV8lLgSbnVIcu+ScjavB5Z8HA6Ekt160Fp3Rda2M9mk8XmLcjEYZZQrJ0BQNjsU5BPvjjBgGpGeUJOJGRIlwkTE/u2Vj91j1x17DB44qOOCa4ctK8cksjCELnHzPzjKgnORk5+7zxzVia08q/nUT2tqLfDuyqP3LsSATgfeLN+pPrRsUOjx9ouWE63F0LgKxgH3d6rtkPzH5flU/73Y5xUttfW16jRJeM5imZdygtCcn+InjJyw+XpnA6VVs9NtzO4SORpyuZ544xhVztKgEHBwxOOuMdOtVNS8phbWdo7lojuEkIOD8rfKVAGQxYHaxA4GKe4XN24SNzdytuUsp+chtsbocLtHAwBnj375rDNsjXEawzNG0YVC0hKSTIrL8pVhhhyQCOgYevEula1BNaz2c1u9rfwgN9ndPLaF+2QvAcnDAZ5Bq7p+lHVEtZJH2XMESADy8l8bfmbjuR3OeD9KQDBMba4SWW6bIVNqAMiAFiYyAc/N8xDDryDg4ottKkSGBr64w7lowwYkLheRvyeOX+Y4wQM4q3dW8Lr9g1GMyxx/MkzqCqrkrjOTg9t3fPTrWelle6U7/ZTCbP5nuMMqknd8pIx2J52gA9MDqS+geRd0e5hntpI4YmQqzISF24PGCwxncTnPJ5BPQiovGlhNdaTbwGNZkbaX3Dnlh1x1psNxJevFfyh2mZBNgOFjC4PGeM4JI565zgVj6ve3lzHDJFeLZvLPDCrmTc0YaRQTjGOVdOM9c+lZtalKdlqRfFFLFPDhsLwkLIhMUAyrbl9CPb6V4V8P7u4TTby7aQTzwvcOIZbZtiRBEbZ5bf3ckY78cd69b+JOlbL2we9u21BFtpZERcIMiSNd2Qcnh2GM9u9cf4ZsoYtUs5LOxeH7XbTi4Mh2nGYvm3Pu2jJJDdgc47VKWtjlqy5paF34b3niLxJ4b8MX9pJaXd5AzC4e4kU7YA55AHOMDgdsgV2k17FfzraGC7u/s9wxdYVMbeW+0AiTtyDnGMjjvXmnjHwVN8NLk6jpMgtrfUYysUFq5fbJu2lV5GcErgYIwSSfkrp577xVpegW1+jtfadNCskl5FEQ0DYyyuoGcLggt04PSlyuxpGpy6HYamZYdRlcsHVAgRX3Dy/mHcEZ7Dn1rHnj+2qiuvnWyxO7JIxj8wb9pLgKDj5S2D7Vhabr0txEJbyc3ltcIzxbIdwOAcbTuG5iQO+Bk9SK1otauLnctvdzwoRGjA2II288tkfe5UZGAea0i+xzyaldmVr1lrmkxX1v4Zs9A063vb6Vp9VR5Yms5tqZllTDm6ddzsgMkaqPLT+HNZPhrwzc/DHwvpmn6bpWoaqkZg0+CC2RZJ0Ejhclmkjzgnc5UBQOcKoJHXrBJqDRma9SSOQF1mRRGkfByQq/e4xk8EHnrxWPpNneeA/D3iCe5udZ8QxQzyao0Ny4uJliEYPkWqEDauEwoPGWxkFhjmdFQk5rs9ey30Xm/62PoYY+eLpRoVEn70W463qS+Fc0r7xi2lsld6Xcm7P/CZ6P4Ua4bVpbKysQVWeaZ44ohJvCjzg5IUEkDPVeoPau9s5RcXV1bSS/aEuAGVJfMfbGgztRsBWYf3sgdOTXmniXV47nTdAvp/Dlxd6lcyf6Oglgg1KOdoGPl+XM6IxWL7QsjiTcCOkgLEbPwostc03QNOfXfMkvLmS6uGSO6a5ighlleSGPzSBvCbgDjGNuVGNtXGrzVXBbej8uu3XY5auC9hhI15O0r2tzRu/iV1FO9k42bejbSW132ttYWwH22Ldb24jyhiuP3U7YwD/tN8oyOoIyGNTvc3BQyeXHKUgDmPzPlYPgn5T98qNoJPJDgE0DUTDEiyx4jhRntnkG6S3kBw4xjDYGNp2nvk55Nh7AXhivLdwjx71hk3bvLYjDAZJJb027Rx0GK7F0bPI8kN06eBUuWSa5tCsYKxLt3N8uQuw8A8jainj2zirMpAthb3sPmxBt/lQ4ZmZm4EmfunJGcH8axjLb3iR6dO0NuRGJIoDKsYZWPEkYX5jyMfKBg55OcVtQvLZ28JmUSbR5iWoBDx+hKjJbHPJ546ZrS3Ui/YuxyzQm1htJlZ0IMxk+aJEz/ePOc9Bn8MV86aPMf7JssyZPkJ/A/90V9APEZXhulbdO4DRysQ3nnqAIlzleRyTkDuK8B0RH/saw8yJfM+zx7sMuM7Rn+GspJDTPU/h55DeE4pZ0mhitrq/Xz4B8yn7ZMQeOwGevc11FlPJHIsi30N5K/yRxXHEgQkAAEAE9s8H9K5X4dXUNr4SgijlkguJNT1BjtIcH/Tpskgnpx1A7CusknhvDNNdxQT2sXykKdu07fmZg2CDyAOeg4q1qhvR7/1cS6tnZ38y0KTM2+aa0YsxQ9AOhzxjkYwKpi/i1OGa0iv0jVeFjuF2uoUcNtJHAYFc9DitCS2/wBGLxQ3cbMNm2J8sseR8uM4zgkjuOazJrhJwkaXWy3tj8i3VrwzBSMHGG4x0HJ9+9JJq7FfXQdHNL56XZsd91cRpILq26LGMkBkbAU89AW5PfFTT3KSRxXs09zZyRBlB2MY2JXcdysMsM5+XPGOo5rIvLcX4mlszbLLdBUyrNCYVADDKjB9QT1BYZBAwLdnexKz2qJNbllEKiC7EzZAOCd3JAAIHPOGI9aHG+oJ9BsF3eW07Jbtbm83LcLbRbkZAW2sSuMfdPUAjIbJ4zWHeGOa9t7dlmtpFZZzHFt+/sIG4fLj5s8Y6fUk6NzNLLcSi4MwjE2WkNsrMH5ZB8mG98cE5wfvHFfUtXiuV/fpKJERoGke2Cpb8HPzFueFYLlemSOnM8tncL3WppXEM2s2ESyWqIqgsgnQqqc/OrNgYbrxjHA5zXM2PladFM88aLKjo4LxyRlioIJyCOCVJHU4BwMdHR6nZafI17b6kiRuXeWySYjzEPCvktzgEZZTjLAnkYrLtRPrmqOgMEVtHPtNtASjKSCxXCjIYjn6DnGSaS0umNvZmX8VZptQi0y5jto5RaSEmeBXOyMjpvJzjO0EAEDnoDWtZatdnWdOt/O3mW3kWMgKWYLnAYmPghByp6AnPrWnNoTahdRiKCOS9b5oys7sq/8APPkj7oHBJGCMkDoa6J5rDw7E2nLa3FxOYybiWIh1Td0QknPJwFyD2zS7CitWyjZWVnoPh43uony7U/M0bqeAxAC8KRxuwApHpXJ6TPp3ia+0SygnMUQsntdqx7gkhjPzqNq5YOBnIPQeta3iLUr+6mCaaY0vYot0kV0rPFDEdwyvyHeGJ25IxnHJIxXDtp/2XVreNdJispNNlhgv4BcuMoQuNq9MHI3lDkZwRySYbu3c1vY7w3cPhW8sVFms1pMfKkFtGGRbhUX5853bSvzjvlQRXRyzWlyUMSfakcBbZIZgm89ivQOcqF6jAB+tY3ia5a/NnOJA1vFrTCSJk53bjCnQZwoyfTPsBVjQCkF9qJLeX9nnV0kijDqjYYNu/h4+X/8AXmoXkaI0Ifst5YRzYgn1BlELPK3CktnB45TLc8emMYAE9lDKAkCRvIYtomklcSEy4z1wAwwSM9fm7EVzrXtxI3mQhI551keVGICSpHjHOCVP3TxjJGM8VtWLRPqt2BskMkBLQJnbIC2HIPYZC9fTt1qrXL3A6vGwk+0K3kRTGGeJ8DyskhSq5OAxwBg856U62tvsOnhoJ2vXELSyMESTG3Bzs25U5A45GT7VStbJf7elkkjV7SaJY2t5nILKGXDL3PD/AMOMkHkinxX6W13btA21NyqkLFkwcPllb+P5iq4J9hk8U9imzQXT7HVP+Jk0xjdFId4Jv3flkAtgHgcgYOe4wcGs7UpIIIFNpKLZEclGVmILZz8w6DOCcsecjgCq8yNbXi6hxbxggFlXhHLDO4ZwDhFGF5yTngUs000uqPK0m+VgYzazumx9wC4UgYb5lC5xyVbG4YNSQXrHV4NQgSAnzpJDl2jjCEIoycjHBOcNjPOcdquK0V1bAJMZ2mQOFJVfL3biXYcY+YqQDjPFYOpC1juyGEX2kt5kcSld4HIHkk435xjyyDnGf9msS71q/wDEE+rT/a7cQRRqsolbb5caKWdWVRhg24HJ2kk4XgVQN2QzxdfRJEiWWoxQSaazxJD5nlNczYx8pJA8tc5LFsDJHJAB5LSdc8S2fi7wvaXUsiWF9qKi4juYS7qyh3LZ2hgT5a9DgqemDmuq8S6Udd0RrmwllS7iieSLJCo4eOPaGxwNu1FJz8o3E56VxXh6Ya6DqHnpDqbGNPNMzKrsqgI3mEg42gAsAwIUcHk1k9zBt3PQPjR8+oaWdjzvHaPJ8oHzZkUf0/lXKaVbfb/EcTy2DysizkGbeFADRnd9QBkBhtB68Vvy6JcayimSe4uLyIJGk9yABsDK5C5J3DLMehJHAKgc4ZuNV8P63DOuzVLYElLi2SRHhfjCoSMMMrwWJGVxznFC7ie9z1S60U6v4cezW3tFZomMSvMWVyrHA4wSOdrDPQkdK5PwNqkraddWVxMY9RjLRyQI6yqUwpw43HL4K5POMtnrXouk2kcthbySyeeTukGDwwy3YexB4xzXm2q6euj+NZTZqojmPmxqd5lCsrN8q7duA3mD5u7DPArTrct90UvF3gmx0oza7p1vJ/ZrOHmtGBVIGP3mxnAUNhvQM3SsrSdWuYLlWgu9lrEwkC7AzkMPugkHKkgsCRg9ge3qpuEW5WeY+baMGSZDuIZQMHHb+7jOSckDmvNfEHhp9A1lo/MX+x5cG1uSxKoWJOwkDPLbiVOcHHY8NrXQzatqbXh/U47e38+5lW9YhjLyRuUqGy/PXvgc/L2rWnjGo6Jd2V5O8FrPbyB7uCUwRojqOrqAV3EcGPbtPIYMcVytpcfY54AqLbBmBEUzbll5OMBvvAkHoPWtPSL+a7jvyIdksR+y+WQx2x5DOm45DAk8YXd8vHAotfcSm4tNOzRjP8K4LHxNbeKdQ8WaxqeuWGntFpc2sfZ/s9i0qeUJTDCkCySDeQCXJZTgAMFK5uvWuv8AxH1m+8J6X4gupY4TEdZ1qzmFsmjODmO3svKRJGklyCwkaQQjBcvuCt6S32S8N7pE0RvtPuvKtpoJ4i6zxOCpEm4EFMfLgqobjvmuVutR8L/Anw7oguVmbTbjVl0u0WGCSa4M8spdYyqgZTq5ZiZH2ZbzXbLefUw8IXbdobyd3r019e+/RdGvs8DmmIxLilH2ldWjTioRtHeV1Zacru+VWi3Jyldc0Zdtouiw6VNYWNqZLptPDBWnd3dQy8eYSx3vjC72ZiepPSpLeF7SaWUCaOII0rsVKpFKMBtoHXIDck8jJ5qjYeFm0fWdb8QNq2o3r6sbZ/s17N5tnbIilQlqrKAm/cpbGQWCEY6CpbeNY9Q8c3nhCKzna5g0+PUFu441niCs3l/v2dsxzb/NxGw5WPcGJyi96moJKWl3Zfp96Pmvq067nKg+flipSe1tubfe0na/XfY6HThbXfkPBsUylXiYDc8SjJGAueSefmJJzgjHTS0f7U1kIljlEkfDmRhEmRxk7cu2cE56enSs21SZma0dmBgRIwrMgXaBkKzAYxxjoenXPS1PPBHJaBfs8wChWaWcnPGQMAAdsgD34rpavoedzLcnks4NDubCGR0FpK4Ro1XZmQtlfcr1+X159q+ftFFv/Y9hiRFHkR8bhx8or6Ea3e5R0LrEXyNtrbMQDkYbOOoxn07188aCsn9h6d8sv/HtH1k5+6P9qs5Ri/iYeiPUfhrdNF4fu/3zNImp6gqxlGbj7dPlV9zgdRycdhXTTWxaa3NwiSXDSbirl1GBnjO0DCjaffH0rlfBi+R4fFwsLSyR6xqWMxFtg+3T5bqBjBx25Jwa7EW0sb8IJLl1zt8lmWMHoQQ33c546kn8tF8KaBr3mOuYlXk208nmOcIrsd5I4xweOOvbk1mys8beTPczIkQD/ZWQvukYkgj7pZQccHnLDOMZqxp4jktwq27y3A/d52lkiUHBbg56846k8dBTcCO5C2YklhcbmW5cjOSN8zZYcYOAOOmR0pr3dBPWzG3Uc09rJFLPAqyo7TefCWVe+NxIJPUcY9R2rnr7S7ht0I063urk4keNGKi3XO4BWB5kPY46/hnev7pEtJbmfTXS2gDNh/LIf5gGkb5skryffd9azo1hmllgJNhCn74qzoTGN3zFnzksxycZHb7wPInpdDa1MzXLl0kvleyvpi6GT/RJwuNw2qoI3fOQmN2BgHr1FZEeqhLa1dHeON1acrcYZjEuw4AZcDrwTj1zxiuos1uY762uhIbiEL5M0c4LBST+8AIXLDBHI4GSucCrDa7puq3r219pqeU0a4yAyAbfu7WUY+8SPUc9MVLfcSTMpTc3OmTGVkt5Z7d0DImDGSPkycqcY528YyATnmotF0VtHtnlkiBmMYVYc5ZQSExnqRnJ5wRu2lsnnqY00WK8T7Hp6I6kBRDbYOMjc2SPm5O3H1qxNrsV/fyWUcUivbOPNUHGNw4BOfRlOM5rM1SMvSjb6LZ3Ou6tbzQmVUCB03FQe2BkqWZgCPRF9M1HFBArRXV9KJb+ciSNHUoIdvUA9TzwD0yM4z0k1K8bxHJbQS7IPJmLBQzIdyp8wyR15xu5HJqG71zT11TTLKe8CqVGEljYKxGGG1umCQOo6n3pdfUpCzRxT2ivcahIk6OLphK2DIcKAhDDOOWAAHNeS60JbbV4bm5uC+o3bea0ByXgiAOEY8LhQcZ5xnpXoLafD4k8VahbPJc20BKu0qyneGZn3KDjKrhAeCPwFWtb+Hen3sE9xbfatO8x1Rri2kYEJu+6wcHK5YEgdlA6ZFZ6sdnLYz/FV95Hw3k1KeS3hupb8OLgNsLqZC2RwTzt6c5waxfBXiuJLu5ZNPkv4tyrMYV+WJhyz5xjqBnjqRzmu+1Pwxp93YWEGpXDLpsLjy422QQXEmMKsgU7pBnovHU5zXM6z4ov9FvLOw0iC4u0jbZDtPkpEqgZ3KOAozgA4wQM8HBOty7PuTt4q0XS7+1W+nInjjCEYYgMSVKDPyhhtU+/rTlvYNV02bULS9KWUWXhZMiQjyyQ7bgeHJx+Z5IFYWgWVpa+HVj1Bk1jUo2MxEDB3eRyZGcseEwScuDk+nOK4HSLmWfV3OoX6WulzR5SV496RZGTGnc9c9hnkg0ar1DmZ7z8lrMrWkrxTiQvLLtyAxUK4LMcEjAfJYE7enPKxaZZmS4tbjUWZd3m7VXeIhnA2nHUleSOpYAdK8v1Ow1K2T+zk1K8dLMfuo41JAgDEKOGzlThv8BzXQaX8T7RtKWeV/NW3KsZI4PLl3Mw3kIBgjIPUcEZpXHzdzq72NYdPjjMMo2SFd0Lk+WyYJ3Kw55+Y8DAHFNgVzJM0l8saYaRsQqERlQbjtAwAr7+CQcjjrUVx5WHvI79DAiF47u7YEORj963zYHDEZOCOc9cUthpdzc27XuoQpb6fBHmK0kUvuCYYXMjKxyDtyExk8FiaY35GBqd9e61Bf6elrJc2FzbSmOa2GwwrGCgcggFXbayqoJODnNWNM8NXGq6tcXt6yPEHh220cflhxEgQEtk/wB7dnvtx7U4x3V1cSSyB1mdl8xon2PJHgty5xxjqecEEAdq6HTYruGCdZ7NbmO4CSecny+WjZZRj7wIY5Oe2Pwcbis2U9Ss5b7TNVihurhkWI2+SNjhpHCkH5eNq4J79CcVjeMfDltpmi6QLawdLthb2aXIl/frEvmPtZMgHGSM4yu84IwK19QnjawurOxgbWBbASO+0JN5zSBm3Lgc9TnGOR2ql4mkjv8AU4L9pfJ1S5WSHTob0fuYdqsdzKG6HHODk7h2zSsxSWlznPHUl8tlptjZ3xW6mfbcJJ80gYR5STAAOV2Y+8CcqTyMGdiv2D7Da2Ugvbm0CG6VC8MEhAVQCcEgBRnPBII7VDovgHUtOYaw17Z65qF9L5skhfYsfBPRSRgABQqjC561L4X1K+vby7t7otZrHctAzwlmiCBlCDZnGWAztB+XJxnpRbQzZ1PgO8vLmzj0m7ktpbi0Iki+zuCPlYhweQTg4HAxyvHNUvitZRWcenXMOXuJ5fLWczGNQryKCrY4f75x3GCR3rO07SLzwt8Q7O4XTohHeSyIk1uEAZCgPzdxnvx34HamfF3WHv8AVrO0tbhrUxXEDb3XDgBkmYoMZwcICWx1wvQ076BfTU0vBbNq9i9v5qNtV1LwnKqeWUgEgnBIOeeQDxurob/TotZ0m+0tiv7yINHJIgwyEH5cBuOuG6feY1zPgySCC4lj+3TP8zyRGVg3bBUEnAB3AYGABtA9uo0qCKO7F24tJWHy+YmzAUn5m+8cZ5HB5AJwad+oR2PNLK3+xzSabNdzNdWjcSrGkplU9GAwBuwxDbc5KsOgNa9qZLoXdsYhLfRxBoJYQD5YBBVwWIwf4efUDmpfiVpdnpmpAxx+TE4eI7WZDH5hJJGO2/AwB1mJqnYP9rEEO4ZVsBNwxIwyFPUEHDcbic8D2oW5j5M2o7sanaST7W+3xbJJFEQ2Nc7irD3U4ztGfuj0NbcUf260uh5fmFnFzKscR3XCD7wQlsnB4B45XBxzXO2EymOFl2297bxCFo5Ax3tlm2kKCQCTwQQVIPStgjfLPcBIbdwQJdsu2STGCQzKeXXHUMSwz3GK0W41puc9428Va54evYbDS9ItozfzRwQ6/cENbWMk275p4wQwLYRUUFhJKwjJiJjL7PgvwVpXwp0CXS4XW2sUEl5c6hqDo91cyH55byeRuHc8Fm5wF2jCgAbpFqjwvJBZ262kDmfnsR90KBz93njuODxXDX2iaj4bu/EviGx0a88T61rdzarbwWt+gkjtobYCJHNxJEsCGbzyQm5m81ick7U5JxcKntJa/K9lboktbux9Hh6yxWF+pQtT2b1SVSXMkuZyaUeWLk09lrortl/TtSutF1LQtK8V6zpVx4yuLV7ue30u2WOLyxKqsIlcEiNWkUCRjuYhiABuC9/dJcraeYJZi6ESA/ugU7HhRzgZ7881518J/A9j4R8LW1uln4ftfEMqp/aE2k6PHbpLMCW2gxpEHRQzhQVyFI3ZJLN3OjxSS2qxz7YzsICrZkttzwcnkdxzzxXTQU1TXtFZr5v5vqzzcylQeLmsM7xu9Ukk3feMV8Mey1010vZXLSbzI4xdysZFYCQS3gXBBGThQAR0PTGDXzzoWwaHp3zY/wBHj43f7I/2a960lvsd2LREldkbB2wjhsjplR8uAD7EEV4F4ekZtA0w7ZBm1iPM4z9we9OejOGD01PTvCLxxeGbxIzEJG1fU2Z97K3/AB+z8deTjPToPciuuVIkjMUcsbW8ePMm8xvMkI42DHU5yOOnQVzfguRv7MmgmmMcC63qchYKQVAu5ckEZ9cYPrnsBXQ6qktzbeUJ1ZcBEgEKmSNSQC2MgbsHAGOpHoauGsYozldykRQCPyYXu4LUyZZc7MSTMf4AeflGMHnBC9cdWLZ21+ZZmeBfMBUwsA0cpUNlcf3AOh6EgnB6VchnLzoZZkV5MQuBlfsyn+BM98DJOPfoBS6ki3Vs8Fo6pbMSi4wVeU9l9AOScHnJHrVtgloZ0lzPEoPmq0R+feELbVGFD4ycEgthcZPJIFVZJrGMtHOkK3Em9Gic7VbnHLlflaQgZzweeu2pXvbkxz7kinDSuFkVVIdAceb3AKk8AjHzckk1GJor+WO2j8xPJUeTG4ZZgSSAocHcFcqOWXOOvJC1OysO99SC00toLS4uIL8W9lIpQExAL8qn5sY5UDgHGDt53FsVa0+JLOzku/LExhYD7Q23cSqJwFbLL8w5Azjp2q5cwmySGGG5C2tsuwGQ4WaU/MRjAwo2huPXA7imXrO+j2X2e2mjhzsVEkBkKgn58NjJHfnOenSpfvadxpJalqOQz6dJfXQEx2ttUdd4dsAHPQcDtnrnnFZsMMVop2q8s7SrIx3EJ5pUbieRnapUAHHXjNX7S5gtYorVIHEManaptWSN2bG0HI5ySBx+lWdJ03zAFaKGSGJWRsxAGWUn5m7/AKnvWbVrmq1seI/Fj4p+I/hx4isbuw0axvdD8to3kub4/wBo3k3J8uzto0d3VBEFkYoM+ar5CI7Vynhrxx4l8YWVx4g1HT9H1DVtO02S1t08J3y3Q1HYGeNon4WNWLBQjZOclsDArr/i/wDAtviFr63ieHvCpl8uOC51C+QLcuUAKKG8lyVTaB8rKCJXDDGCIvhx8GNQ8IeE9agYaf4c168E0Kan4Rtkizl3k3r5sfyeWHMcYbdsUA5JBoWraIaucT4f/aE1dNUu54dDubW7stTi0a9tLom4ni8q2DXARVlJkZbmV0+4Bsj3HkV0vjX9q+bQtc1Kyt/DTajHaeG5NajN9MkLXTKyL8oLhljyHUsInORkDaCa50/s/wCu+HNQl8TWuo+H7NrOJ5F8NwWE8tusxg8p7xLkyiWW8kiyryuMHJJUOxYweLPgOniHULvxGTaQ6nqVtHa3j6yC9z5Ec0ChYmbJi3RebEApAzcSHB3czrszRO2x0mifETxB4i066vL+1iW4tL7UtOaC1lAEjW1yIo0WWdlRC4QgbsfMcZGTnJ0T4z+IdV8Q2Ojah4UFktq8kepy2tzbOHuZSHtDGBcuzp9mfzH+9tb5BnZW98PfDGuad4C8Y6ffTaDd6Zc6he32m6XqMDtZyNNO8sqXeQTOuWXaEUcKDnJwtXQv2T7bwt4iXXdM/wCEcutauLuOXXI77QohZ3O3a6NYwxEPYvGvyoUdt+0GQMx30OL6lpNo0r/VNe165UWGhTbkK7okQ5XjcpklB2ksELAemBnkGvG/jp4z1D4UaL4buRHJpLaneizj1m6itHs7T9zJKsI+0ahZeS7LExBeTHyFSMsmfsuW3gs7pU1CSKBmJY26SfO6MyhmOeTyM8e4ya8N/aX0TVdbsPD9l4X8MX2oTW2pvf297pZ8ia0l8mSFDuj1fTZUDx3Eqhllddu8OgypptD5O585fBH9ou48Y/EXwhbprmsXGt6rf3+jzaLod14efTNkZuVW4WJLuW+ijEEJndzLIrPkRtJG8av6nr1z8Q9S0iLxZ4XsfCHh3R7PxXPoK3us61dNPqLLqsml7JYYtMcxedMQVKTEIWRnJUSK3K/s9/Cz4jeEPHvh8eMvBHiW8trPXdTvkMl+9wlt9rkul+0/vPE00SkR3bmRhayyYaQb5ZGMzdDqn7P1v8VNAh0LXPCXh/StWS51jX08Q6nptpqV4v2y+1G7sNPRdrBhbzXMNxOBL5MhiMKm4inmKZ22BxR3nibWvGfws8Lpqfin/hX/AIct7y9eBX1j4gT2NopaFdgjkk0zZJI+2dijx8eWCC+WC8l8If2sPE3xB0/Q/Di6r8MdT1eTVrrTZZdO8ciTVLmG3upYvtQs47ALJmGHztyGNJVIdUgRgidN4c+H+rrL4Lm0jwRoHwyj8NeJJ9V1PQ9Ntbe2tpXk0i6tDdQm3LBona4jUNMkUuyIl0QhVLfD/gzxTp974DGp2mk6fZ6B448S+JLuSS6Z52huptXFqkSIjiQSrfrIWcxlFTlWOQj5Wxpdi7rGuaxrGr+NLXwz4ltdHur2KXwr4RmvLRWgfX1tL67vZVkjidTAgWCNi+4LNp91HsDDElXxl+02+kaJ4L1jRrrwvo1rr9lPcTyeOvFkegvaTwtAHsmTy53knR5Zo5EAxEYnR23FBTn8O/E6LxLq1xpPhHwVY6fp+ky+G/C7WPiKfT30iwl8osUt/wCy50+0O9vC2198Ua28SImBK89TxR4e8SX/AMIP+Ee13wbLpPjvxA7prtx4V1bToNOWWCVI1muGu8ma1uYYIg8Zt7p1tiYpI2YBXrVIDgPgp+1VfeKPD/ga3v7z4ZazqesXViskcPj+GPW9lzKqgy2jWaI9zFHLmWJHTzJEkEaLuWMcJrfi74leKPE3i+9i1XxXdfZtd1fS7R7Kwu5YoraC/uIIoo2i8MXiYCIAdt0+SCWKtlV+j9Jh8eWPxI0vV/FA07xXdWOlLpEmrWExt/7JWVopriOSHykW6aYwW6tdx+WC6xCOzt0EznxOw+AmvXmq6x4u1zw94G1C1ura7ntdI8U+GYfEN/AZNW1XUVhG67toYZWW/ijJErROy8uAis6s3sLyO1+GXxqsvD3wQhufEmt3t54qs9Ru9OupdRtbjSdPtJTMktut9eT2VtFaqtvd2e6V4UMp3eTHNJtjbo/hf8V9BPjiDwsfH+i/FJdRw633hRkvXWZ9qSJdWts8zQwBpf3dy37tUPl3EgkRZbnyzwh8LfFvh34R+EtP0Ow1VTeeJLSeWwm16fQppNOtvDkenbrqfTnmeIvd2cUwhiebhogx4cp0+n2PjfwL4+8D6s+iXFhBbavMmpeT8UNZ177RC1jdpHDJaXyJFzO8DBgS6lVJULvZVZks7LUPiD4k8Oz/ABGa5MWrXuieOtC8N6Pp9wqm3toL0aSJsMm1mfN/M6lywVioIZRtrmfFfxP/AOEZt/iRY6l4istG1oa3b6Dp99qMtug0uCTTtLmn1CVmAR47a4vpJ8TMA7tBbBlaWJar6/aa1q9r4uS7nsdP17xH4u0XxLNaSz749JW0lsCbd50BSSYRaYu7Z+7WSXYJHVfMOppmgeO/DmmfEOPTlt7TXfEXiXzLLWBLDPFp8DaPZRC7dWY72je3kAhKku6oG2ROZVPUm8WzU8FfHLwpq/xuXTrX4haH4n8NXdgIrRNF1G3mOn3q3CLGJCrOwW6+0JEHYpGsltDEGaS6RW8ovvjF8YNb8QeKZ7HVPFyWtp4h1iwto9M0qdoI7aDUJ4Y4kMPha8Q7UjVS32qU5UklWyg9X+EPhq+sPiV4cuNL8K3nhzwn4U0G/wDD1lJqd1FMl1FLNYGFrcpNK2xI7BgfPMb/ALyP5WO/ZyB/Zb8Tavfa54v1Dw34D1mW+tbq5tNB8VeHYNfvYpJdY1fUTbxs17bwwSCPUbdHIldGkQ/MEjV3a7oFa1ju/hf4q1f4ifAFr3V9RfXPFej3t5purzXtlNa3KEsLy1idJrO1LyLbPZgyCBFfcxA5rqLGaJryK2eG2ubXnyZCg2RrtyvUlfphhjA/HA/Z1+FuqfC74K3ttq8Mscd7d6eLe2uHga4WK20rT9M8yUQSzxqXazmfbHNIAkiZIbcq7fhfw8Ld7Cz8mSa3vVinhScsE3MoI3gcYJAIORjkY+bFVuYTS5jp9Mkmvprhr2IW95FlN6uubnkDqu3bjJIGcjIyOa6fT7NYpLhhBDbXJVUllhYxvJtyScYyjYHTGT1Bz1yNN+zzyxadNK5lZZHt51Yea0uMMgU9OMDJyc5xjmtWzgW6FhPJEJb8nyskbhE65wCSM5HOGwB0PrVrYEaFqrSw3WoQEJPM7IYEgK+Zs4JKHLM4/wBoZPTBwKluriWN5bm2vlEU/wA06xxCV1A+VXjUEj1yGB/Aih7yKWSbUYFc27xt58UjKN2zA3spJYMhz90c9+1Kvn2n+lIsCWM0qs7vubByCZCBgEt3YdCc9Mihasb0HXKfYc3trdTy2uAJwA27AH3lOPTHT3z1OG3kkkl3FNBFdzx/dcqVTeWA57A5XAz9KvTwz2TLamZILG5JUNt3bWP8HIxg89fp3qtut9JUWlxdObFlCRHcrjbj7p4+n5jsa1i+trsi19NiOe3w1pdwW0oaR0AdpVIzx82VOeigEdxjuK+e/DlyzeHtLLJHuNrFnGcfcFfQNlbwyXz21wJ7hHkVopAF3E8kHd16Y5B/Wvnrw5CF8PaWF8vaLWID5V/uD2qJtLQai2e0eA4G8nVZd+JotZ1CKGPI+cm6kbkY4AyT+vYV0N1vhv1LzW6yjOLiZcKHyBxk8beMDpk/WsTwPA8trqmyKKV5dX1HbIzDdEounDHbjB5A79SPQY27OSP7MyRRyfZslpmDK4WIZIjHOeeSeO7etEdkN72CGdLgKiyhIkBdJw+SyHIeXnnJ5UdeuRnjBdwvGzTRAR7IWHlDAKxkBUj/AN5ic/gB0FQ3Fqt4z3iwx/KnzxOnEgJ/dxHbzngMeDyw4pzyz6SiK8KTN5oICyllWYrwpLDhRkEfQ1SXYSfdDbm6t/LdppFilj2ySbl2bWHKxgkcKo4zjgkH6UYhazymJpo5XBLSPBOeZCGMpwFxj5NoJ55Y+gO/LepZaZLEGHnKqqWcLtd3bbuyDjG45P5ViWGmJLeW8lo77IC0EXlzOp8pQuTuy2QWHAI5wOnJpW0bL6pEdxCDLO6TmcEsojlY/vIxhSNyg/KTgDjKgMR0ybWpm6trn7TKLd7to9m0sQUJY7SDg/KflYjPG33qtdabcRzPMlyxlj3ToJQCNqMdgx0BLdxjOSTwAKtakDZajFPPdFE2M3l7EQMVKgDcccqWPf5sggfKKfVC76Fi9mC6dF9mkQOHjZfMcKCANxDHn3JI4AI54NN02WeOy2tPbpdXTFygdSWznbuyDwQMkgHgHiqCzqsj288s15LEwVA0ZyA6gYA2g4OSPmHPHIzyTGSK2uHithZ7YQ3mkq5yoOSuMrkHIxgfePSs+V7FqS0ZNcxyTCa2gMxbG83IcHzVJYnqQOmQeOQB0wDVq8sIr5IgimSBFRkjgUBGTkbSxPIPPb0681xvib4reFPAd3DZeJPEmmw3ly8UEVtcX6RMDM2FzEzA4yoPmlflUNnGDWtYeMdB17SGvrDXrLVtMgKQSSaZdQzQwEHgNKGPKkrjk/w4BJot3KTGatDa6L4blsbSfzxKhQuuEJLDvIxwMhQDgg1n6d4R86zhh1KSa7EOY47VZcRONhyZJDySSWOB7A8AVkaR8RfDniXUtLXTLuC6vtSifUdNMWfJNsjJuLbiNrjzFyGCkl8djg1z4v8AgfTPF8+narrtpZaxLDCJYLt9gheRJim4n7p2QyjOMKV4BJBLtoWtTrdMsjaXk77IY7O22xbgo3hgOCiYwq7Mc8E461RtNGl1CcXUFyLYXLxySzxIMuqvtOw54G3cDn+6D2rM0jx/4Zl0a71uPU4L21tEjhu7maOVdjMqPFmIgMNyyxlMKWYMhxg5MOm/GbwFq2qQQaf4mtLvULhhFbsqSgM8sazwLvICIWAyFJBIOMc8zs9DRG7caS8c9zDa3X22TzBcQoSu6JWBITrjaMFlzg8ZG6rU/h8tNbT3V88Nvp4dUs1IO/eSC5c8tzyeB0yDmtrTbtbjUmNmht4nhCjzY+GKud2OePvjr9eledfFT4rH4RvoRtPBHjnxtHqlveyGHwtYx3a2Qt40kMU8jypsZuQiBi0rKyKC20GXpvuUTXcNxqd3C5uCl3bYjMcETAzy5y0hYfdygCg5IADdia2PDmiWwsHu7u78thODFGI9qn5QMKFOW3AEnnP0AxXz54M/bg+FuueL/DVtpQ1S+t9SOl6Yb+0gge0sbzU4p5bawusSFzORE4byVeOJ1CO6kOQum/t/fDK40fxP4id9bsNP0vSZNftLgWAcalZC/bThNaqJCRvu44023Igf94pKhC7KO3QlLW59KDWvsFwiXVo8lx/rZnOMlR8u4lsDZ8qgkHkjpzTzqpuglxIW33EwYysuURUIyo6FVIA+dsj5nIOOvn3h/wDaJ8GeJvCHjC61+C58N6v4RNwPEmi63bA3mlRxRtKWZITJvieFDJFLEZFkXlWZgwHm2m/t8fCC78H+KfGmrjU/D8Hh62siNH1SONr+9W9t/tNkIRFLJG5ljHCeZuj8tzII1DGjTsVse6ahrl4theT2KxJJcukNvH5ZlVsEKzseGIBJA6EnIzzisPVdFvb++W4uJUUzCC2b7TGpQRqTuOG+ZTnPI6jbkCs0/HuyT4TaN8RNG8I+J/FlpcaXZ6wNM8N6et5qBFwE2IYlfAZRMWdVZsBHOeM15v4h/bL8D6Z4L8U+IPE8d/4Mu/CesGyv9C1dYG1l5DF5lt9miWeRZVmEitHJuCSCOV8+XGzUNpbEPyPbBLfNf3rAtGpiVIvItQwtIhu2bycO7s2H2jgKVHpnAub06zaRLBpaXt7JHv8AtNrCWjLN0DFc9Cedw5IUDpxiah8VLfR/ggnxMsPCnijxTpmpabY6jbQWkIn1FobtIVRUtVk2M6rKhbBwPnIJKnPkvin9u7w3pF9PpOo6F4p0zxFpWo3323wZ5FpBeRW1pZG7mu+LjyzD5O5kfzP33WMSAZB5kWZ6jr2o3Gn+ILbTtXMulpsEZksCt00jZb5NgcCPIU/M/wAyll46GsjU75/FEpnttIENqgeSOe9/0i7kfb8u6QfeVQw+WMYXIzk8jz/xd+0/4RuLm2urrwX4qTwPPd6WsHja7sIrPSma/hR4Lmd3kVvKVTteQIRHkAjcUD9R8Df2kfA/xT1vS9GsE1eyg1GGe78P3msRfZ7XWFt7h0nNkyOX/clGZlk2TeW6yNGVzsPUhxdzvU8FS2zyz3UXmLaxxx747vZ0UnbgxknaT32gFgOBVyayt9QcRpE0UMCmIW7RICACRkrwmTyxOP0rgYP2v/h5rXxYl8IhbmztoL6/08+IL0RJpkk2nQRz6hGWRt+IEm3GaRUjZUfa7YBOx8Cfi7oX7RngzU/EXhhrq/0XS9Vn0e4mvY3gW6kiSOXzLdA24RMskZBlCOMnKAinqS422PRfCmnQSTy3VvPIP3iwthGRcA/MB1DHBYnBxgY7gjrbzWI7a0llikJjfbsxPjAD98zjqxyOhx8pxXz/APDD9rDSNW1q30DxT4Z8UfDSSfR7rXopPGlvBp6XEdlJ+/jBM+4yIu6V43VW8lDIcIVJ7n4C/tCeD/2m/Cmuap4MGoy2em6lPpQnvxJA928cUTGeJfMLGM+ahUMFZR1RabtoUk0j0ea3e/0FYt73An8mYAwsSU8wPj7xPGfUjgVz+laXajSbG3aWWRp4lUiUnyMLGpVumWOW4bkEjGcCut1K9MehmaKNMxSbxGxPmLgHJye+M4BwPQ1kQ6fHor6XJIhRokaIjB+dSmAoJC8DjqAPmPpTtdmTEsLa7Wzjfy4vPhuWjY4MflhWGFIACqTnJVeTkEd6ksxI1usqOrhbYyyqV3sUfO4kHlnPGM/3eQetWFWO2u2MTRhFCqJA5cJINpGedu7jpk4yPWrlrNZPfys18k8NziWLy5TvLI3zA45zkrwBxg980/QLdxt7NdRPOHnXZNAEUIDhWBVXfdjOGDqSR3HfFWEge1vYrWcyizmQiNyyqkb4AMR/iIwDgjHcGodEjsrNnt7qWOJUQvHHJKAwVnfhud3APAbOAfXNWXaxltJLbyUlnB8pWiiyWzyrAgcdPzU0JW0DzZFELCUXFrNG91FIpWGdUaQlP7gIB+6R2zng9aCJb2B7F7QGZPnWdlEXAI2tjGeOh47YwatkSX9iIRbyR3Vq4CuAoCOvRgN3QjnHofYVGsl/qSx3gRLWS3YoYV+ZiejqT07cD6eoqk7EvaxLtn1SFo5fLguoc9Qcg/njH+IPpXzH4cnlfw9pbbyc2sR5l5+4K+j9SjJjtdUFyZfLkBkjcKoKdxgDGQe57E89K+cdDB/sXT9pk2/Z48fIB/CKNwdlue3+D7hIdK1pUuNsj6xqTOjnAKi5k+UE8jOMfKT3OOtdJF9iuXIjuFby8S3Bgl4ZjghSoP4/QKO9YHgqaOLQtc3oRHJrepGVwwbCrcuOfTsvfGTXViwlYLayyJP0nmZos59A3POT3x0Woi/dRo78zMpI7mCSaRo7jaH80CJkY+ewzgggcjOOM8ntiprW4ktr2NbiN5ZEDltiqnmyNtyxBbqFPT0NJazyQoIppTGtqDNua3aTJYsVJIPUDHvzViG88u3ufNs3myPPLMm0Et2IcjpgDjgjGK0faxml2K9/cafNb3ZuIorQmEQgTbFOTjdyDjIJXvng1VcWY8iSCS6MKTJDAYxJgKmd53Y5GAw/CrqxSWktvG9lHI0MTzTKHGW3HBbGMcnecZ7dag0qLT4LqwxA3nR228qI3dt5wM8Ajpu56c+9EdFpcHdspXi6VDLK0ZaQSXCFQrBlK7QxZXY8EnP8XrUjwW8lg6RaYGxM0cTTH5M784Ln5gCQR8uevSrq3FwdPsnEdvYFTlBdEOXBzgBV9QeP5VRV4ntpY7m58y4hkLPEQSV+fO4lgFXPUHH41S13C1hlzHcq86vNa2R8xZWSIlnY4XDL36A85HfilmtAVQyCO6tlH+svnLKjL75wAeCQMknHHpJNbxwzQSJGlvHMxjLxqW38ZUbiC0h4YYUDOSM065tbyWeG3SaR5FXdH5jLvU4x82OEXnrksR6mjT0HqfOvx08BeL/E3xf8HS272WrWdnFdvZ6YkLWa27iFQ11NOJUfcfNkjRNwVV3HazOdrfBNvquv/s3eK4tT/tDfPq+oRwfZLKS9m8lLsxxpFGS0kiOF8tWDbwpLK643r9Fvbz2d6BM0KlI1YLF1IyQxyQAp3DqQSdxxzwUlNzbvuCrACN6tICXQk7exyob15Y8461Nk9upSPi7w7ol5ZeOPDd/4m8I3EBF8B4kge0fUNP0K6WeS5tYLZ1VgVmaeEEBjgKhk8tdorR/aA8J+K9d+LWt+LbTRv7U0jT7O10wQq0jvfTeReAYTyv3sga8iXMeY4yyckbin1vNeG00797mJ4yPMZn2si78jOMbE5wedzZ570y00W21HVnNhMtvJHDtFykQUspP3UUEbF+ZTnqdoPPWpcI21N4rSx83+EPCWq+Ffh7470GeSfUli1jToHlsBOUcxW2mxzNHLK7nMbAguCwQo2AAMVyXhDwH4h0P4uaTfX2gXdxFo2r6euoTWunNJFDJFYWcME0UwjVpUAWeKVt/lxsVkZQOB9j6XcrLHaI5SaeAvE29QsNspUleO5IwcDJ5wTSW087C1to4CtoUdY3KAPOpXDKFY4HIHLHkc470rJ9DVQuLbG9u2gkVhZovlrHIUDbCQY8EbvnXK4O7ByQe1eO/tHfCn4n/FOLR/Dfh++0u68IzzTnxTp17qU+lSX1qURo7WK7ht53SGVy6zbVWR0XYrIHkNetpp99L5UL3XltLCxSPdsc7ju+YgckMjEYxgnrzk2pbd5nk864a5mlhxG6/KvPMRwOM5DrnnkjkZqWjS19EfJFn+zD8Qbb4t3mtWep+C/B/hLxJqvhXUtX0XSLlrx7WLQ1cW2nWyG1iEiSvFZOZAITEQyBJFUl8TwV+xL8QvCfw/v/BOuav4L8ReH9C8O6l4Z8N6XrNpcSWepPfap9umvrzy/Kltzst7VFWKWYxSIsqNuQLJ9rT3lnfWUlnJeMJzsltZIvmmOcFAAOrDBXB6jk9TV211S4vNOGoPFE0AYl7dMl4QAQ2ScZZT1XA6dTxWfLYjlZ8keCP2SbnwV4H+KOnXg8M6HdfFKTUoNe1mLXL6/wD7Gikt3hsYojdqz6hM0k00ssrvbMXlcDcFVRl/Dj9kTxzo/wAJPiboOteIvD8mu6x4FtPCuj2GjyyT2sNvbWE8AeWZoY3YzXVxJMV8tjH8oDPwq/YNv/pOpz3cEcU8aMXit3kMZGVx52CMfMQRyOnI5JBiu9POmQG+julhvrxikxjcJBIWBAJz02KCQw5PJ5zina2g7HiVz4U+Kvw5/Z00LwP4Lk8JnxBaeENL0O18TXd1NLCmpAxW0irAtrh4hEZHjkZid6qHh2lifKfGf7D1747+CknhfUoLPwpf6LHqN7pbWviZtXj1/V7yB45tQ1mS50xN8wK5SVB5iiRxGYtkePsm2uZJJ4FWyBis1DxxWkwkVQVIDFm2jpuAUZ7nis66ZNYthLHP5d1e3CrHbNGpKI2Au7I3D5FzkEcnGTTUe4cuh88aV+z38XPAPwI8LeFfBvxXnm8b2miWsSafr9nYvoFtIkKRna6WH2kiIZaLezbmjj8xWUsp88uP2R/Hei6v4O1rwU/gzwn4p8InV44Z9S8S3OpXGp32o2UkMup3dzLpsZe5jmWGUKYpFl3Mm6FYkU/aF5qEQ16dtQRrE2dsqLdQEkBmOcK2MDIC4VuucEd6ozWt8mgWVvexxxS3UpuJbuF23woxDMSAOTggEZIx9KrluhNI+YLf9n/4l+GvEPhCW6s/C3xH8MfDzSNMsPC2kS6xc6U0N9b20ccuoXNqLK5E1zkEQ4k2xKxZF8xt4qfDX9kXWPhr8VLr4kDw94DfW/DFnd2ug6VoutanZW8kt1dSSSTtFJ9oTTUjtpplW0ijmjMtxM24AR7frO/guZ5IElu1eyhAY3tsDkR7TjeAfmHKcjgBie+Qt/Fex3MULCFo5yTLMHBikGAuSMYVyCQCflY4zzzTUVuQ1ofMnw3/AGaPF3gr4uaprieK9Fm+HFr4w1rx4tpHHJFf3d9f2ItYraRRFi3Fusl3iSOVxJvTMK5Gzt/gH8OfG/wQufHwMWk6k3i74jaj4jmD6lPE9vpdwYiTtFswkuUCkmNdqndzKuMV6/q93FDJNFG13FFCwlcxvsuQRkmLaR86leNx6Z6kchun2/2KCQRSB5pMsVkkKo7Dc3yN95GBYnGcHJK7gcC+RWM22j5h0n9mHx/4207xiPi3Jpcus+M7V7LWfGPhXxROL6y01HM0WmadayadsgtmZVSVGmJl82V3aRiFHe/sYfs5a/8As6eHfiDpN/rttc2mteKLnVNMsbRIlht4Gji8tmEdtEEmZQA6pmFRGnlqoLbvbC82oXsT3FrJi22t8jKZSPlILr0bHy9Mjj1NXbrUIobG5nSULgBPMgYmM5OPnjP3WOfx9ahw2RCl1LkGy50e0imhjs4zGoMUnKL0wpJ5POQc9Tj1qvpemrbwuJYniBHl7rZRgBTgDI5PQ9R0OOlSQWrWFpbxtNNaxonMsbK8J4IIZSOPUkAD3qLS7UC1dh58UAlkImtHID477RycnJ49OnSnZJOxLbbV0R26NNoQV7uC8uY1ZQJFG8Sg/L0OclgPwq5c2tzqWnG4ciC4RGeIW7Fir4wRk/Qrgep7imaZZo099sigvYNwAGADtKLwAeOTknOOTSW95a2QntWNzYHJZIlVmKAhSegYdT196HvoSvMuTbPsFre2ahFhCyhNoGYyPmXPY7efqopmoXwj8vUFiZIrdijyOwUGM8Fh14BwRkdAao6K32sz26X6m3gkO2NVBZlLMyq2Rxjpj259Ku6XHcSRXNpJKP8AR3aHDw53IRlDwR/CcfhSatuNO+yC5S4tr1b6G2TMgWGYGXhgThWPH8OfyNRmGfTtREj3JEFz/rAqgKJeOcHO3jH5U6ysZr2yltbi53JBI0O2NcbgD8pY8ngY446VHaWUt9YSQ3V9cGZMpICUADY4ONvtn86rTqLXoMS2gsPEYWd2aKeMEb8BVfcAQcADnPf1Ar5t0S2DaLYGOUbDbx7fn7bRivpHRorG80u2kR4RdAjLFyWLg4xknP8A+selfN/hyE3fh7S54wssctrE6ybR8wKAg9e9TJu9gVlq0ewX8qeDPF+q6RqMn2XTPEk4utI1CVtkC3TY8+zc5+8WUzICBv3yKMlMHs7myM0Aje3mE94xG9LgqwXnHfPCjritbWtD0/xJaT6VqtlBqOm3Ueya1uUDpIPQg18efFXx14j+GHxHufD3hvXdQstHt4mWK2muXudi/JwGlLMB7ZrNTaj6FzS37n1KWmgnmtHCxpJcL87RvKSgRTgnv2X6Ecd6L6S6lW5uIUkuQjoX3RiIFUYPtH8Q5J7HPeviq+/aB+IFjqFmYPEkyE+bn9xEc/XKc/dX8qoH9oT4hXkN6k/iWeVBNIuxoYiuOeMbMd6vnSV7GN9ND7meW5kW/nPmbym1lto8BAoOBuf0JJwB36VUeS7tI7b7JeNct8sPlwneGUDgtIcAHIPAwOa+Hz8efHjyyodfcRtCxaJbeFUPyjqoTB/Krcv7QfxBurtEl8RySRoEZUNtDtB+bnGzHYflVe0Wmn9WJTu3c+0NNvbW3tGRWSJlQecgYQpxwxaQEs30Bomntp2tyJEKBfI2LHtQq2eFiH7w8heW4P418XxftA/EC41NzL4ikk+zyDyt1vCQnyHp8nuaqzftAfEA2ol/4SSfznmKtKIYt5HPG7ZnHyjj2p86Wtgvc+3m0hrNYpZrqe2UHYzySI0keclWYjheQBhSc55JPNSzfabZrdoz9ni5KKXO9yRgsA33ByclvUHtz8V3nxx8bojyJrjRvFsZGS2hUqdyjOQlN/4Xz48NpZznxDKZnG9pDBFuZvUnZzS9o3Zsa8j7PZbqBradYpF8xnYI7rLKxOTuQMeuAPmYgAdAMVLEZ4WR1I+fLRSTqZH3YwSgyC7EFRubGBnHy18T2Hx58eT2tpNL4hlllY72eSCJiSOnJTp7dKIf2gfiDc6xeiXxLcSBUdAGiiIChumNvvz6981Ptbp6bGkHfU+0c2/9m6hLfRmWSAuHcQhkQlQ24sOpO4ZIJA6D1qtqU9zZavZytM9tbTwvbpOUxNKFZSisQcjdnAPB4JOM18bSfH3x9PcbZPEMjJ5I+Q28O3oR02Y6UkHx78fNeSFvEUz7WWFQ8MTAJs5UZTgHuO9HPdXN4zPte3ZptPttmLa8jYvBZ2yK0ihGIO9jkevpzjkmokubm9S0aEsdQS5liXzFKQQyHLc5GW5A4ByR6Hmvi3Tvj54/sYZPs/iSeIP5kjKsUWCxYEnG3Gajs/j/APEGGSYr4mufnEc7ZjjOXIHzcr14FRKaV3Y1VTTY+1Le3uNSe2eGRraWK5eAMzgpEc71AQe6gcmp4rCTUoo0uLiSNQ7QPgMDh8FQQT03ALgDsfrXxHYfH74gCS8P/CTXOWKSHMcZ+bcefu9aii+Ovj2W2Z38S3TPLF87FUy37wH+77fz9TS9rZ2sWpWbPtg3WnaVaYuvKhVXMUkaMWyp+V4weu5Www6fLj0Jp9jENQVjfQPFZbwJwWCC4c4KSzJxwQB07g5GK+LYvjb43i1KeVNelWTzlTcIYuFK8gfLxnv696ik+P3xBurKKOXxNdSI8Co4ZIzvX5eG+Xn7zdfU0c12g5uh9v3nl3FwYzcqtlFKVhncb0E2cmNz/cHIAOOe+VFUbe6treefWNlvY7AFisJOFkUjDOnYM5ACsByAM9ePi67+O/j2OO2jTxJcxqYDCdkcakpjoSFyanuPjT43+0yWh8R3bWsToywttKcEcEEYI56Hjp6ChTT6EuVkfYzWUjaWbeI3VnqmqyN9qSKEmPDfeI7fKg2gqfT14vskeq6sYZttgmmQ4i8j5ZixUg7SR90KO3HzcmviUfHDxzaXyXMHiGeGXyQMRxxqnzOpY7Au3JxycZNTH41eN57OeKTxHdukjyu2dud2TyDjI/Ch1FtYrnPsvfPbeHEhmVpU1KXJuFOWLE5IdTknhOoyMA5wKfPPcnV5jpZSbT7CDzv3mWDPyNinPC8HA9VOMcV8Y2Hxy8dyx6Vv8S3beTDujyE+U4Vcj5euGIz71cPxx8dl7pD4mvNrhgw+Xnhval7a3QhSvufXNra3cNtf3iynS76V1PkCUbApKgsp+7gMW45xjoDS3Vn/AGbbyxhYLC6uCkEcMB3xNCxALKSPmXLEspAxngj7x+Or341eOLq1QyeJb5iitMpDAEPu+9wOtSp8WvGLPk+Ir4FtjfLJjadpbK4+7yxPGOtUquuxDkfYGlzz6Sv21kwgDvFHJciXcG7gknIwFUMpLDncCMVGrrq2pXItlj85B5bW0MXMQJDSfKeCMFehXcRkc5r5APxW8XxC6KeIb5fK27AJOFwG6DoM7Rn15znJqxafF3xpFfSFPEuortkfAExwM7SR9PbpWntbRc7akOz0PsOG7itrVI7e6DSIxAWUsMP1ZhJgbTjPoR91gcirrTzT3Mck9rn7MfMaeNVSYEjAyozuHPUZU47Y4+J5vir4w2JIPEmpLIYmk3LcMDu2Bt2R/Fknnrg46cVYj+LHjIPtXxLqSASKVCXDLtJJzjHTOTnHXvSc1a9iPU+1pNSghQhXKMZNpktAyqe5DIOj4U9M1d06xtGs1a3laGUqPNkgcqd3csCMde5H86+Hrf4neLppYZH8Sao0ibir/an3DOM85z3NMuviT4subPzH8SaqXD53LeSKSdvfB56D8qettP6/AhO7ufbVlbwzXVzL5aX7B1Id2AmBAHQ8DGAOBipILq0t9QvBFfC2n+RniuvTB/vYPryOK+MtO8f+KLiKC2k8Sau8JUOVN9LncX653ZzyeaW08e+Jx5WfEust5oIffqMzbgOBnLe9Uk5X/r9Ab5bJH2P5jL4hV3tRcpd2pz5MqugCMMNhiOofGeelMQImu/vrSe0gltgdpkPzMpPOEJyME8e3SvkeHxPrlsxlh1/WIXcNuMepTrnG7HR6vN4t8QvIjnxJrZZHIU/2pccA4/263VKb7bd2QnZan1fmws9XXbOsUMyhdolKbXA47jnA7+tRSvp415hNIr2k0O/MsjMvmAkHg8fdH+c18wP4n12SJXbxFrZZGypOqXHB2j/b9z+daWmatq2pahBHceINddNiHC6xdLyTz0kHoKXsqittt3/4ApTSk128v+Cez+P/ABdPot+/h3w/tv8AxXrEDLYWkRX/AENTgNeTED93DFuLZbG4lEXLHjrvDfgrRfC/h3S9Gt7JJYNOtYrOOSUjeyxoEBb3IHNM8G+BdB8ErcR6Np0do16TNdzlmknuZAwAaWVyXkIHALMcDgV1Q6CuO7Z1wimrn//Z";
//	servcard = "";
};

/**
 * 获取图片编码
 * 
 * @param imagePath
 *            证件图片绝对路径
 */
function getBase64OfImage(imagePath) {
	var hwUtil = document.getElementById("HWUtilOCX") || document.getElementById("HWUtilOCXS");
	if (hwUtil && imagePath) {
		return hwUtil.Base64EncodePath(imagePath);
	}
	return "";
};
/* <%--双屏时回调函数定义---------end-------- --%> */

//记录读写卡本地文件 c00311908
function writeLocalFile($Page,content)
{
	debugger;
	// 关闭系统参数writeLocalFile  不写本地日志
	if ($Page.receiptRecordLocalFile != "Y")
	{
		return ;
	}
	
	try
	{
		var fso = new ActiveXObject('Scripting.FileSystemObject');
		var tmpPath = "C:\\tmp\\";
		if (!fso.FolderExists(tmpPath))
		{
			fso.CreateFolder(tmpPath);
		}
		
		var tmpFile = "C:\\tmp\\receiptlog.txt";
		var file = null;
		// 1. 文件的绝对路径 
		// 2. 文件的常数 只读=1，只写=2 ，追加=8 等权限。（ForReading 、 ForWriting 或 ForAppending 。）； 
		// 3. 一个布尔值 允许新建则为true 相反为false； 
		file = fso.OpenTextFile(tmpFile, 8, true);
		
		// 在内容前边加上个日期时间
		var myDate = new Date();
		var time = myDate.toLocaleDateString() + " " 
			+ myDate.toLocaleTimeString() + "==>";
		
		file.WriteLine(time + content);
		file.Close();		
	}
	catch(e)
	{
		// 记失败了能咋滴
	}
};

/**
 * 数组去重 c00311908
 */
Array.prototype.distinct = function(){
	 var arr = this,
	  result = [],
	  i,
	  j,
	  len = arr.length;
	 for(i = 0; i < len; i++){
	  for(j = i + 1; j < len; j++){
	   if(arr[i] === arr[j]){
	    j = ++i;
	   }
	  }
	  result.push(arr[i]);
	 }
	 return result;
};
