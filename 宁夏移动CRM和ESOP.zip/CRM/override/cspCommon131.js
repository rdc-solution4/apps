var CSPSC = null;
var chfApi = null;
$Controller("bes.ad.csp.common", {
	/**
	 * 获取号码
	 */
	getServNumber : function()
	{
		var servNumber = this.getServNumberFromUrl();
		if(servNumber == null || servNumber.length != 11)
		{
			servNumber = $.cookie("com.huawei.boss.CURRENT_USER");
		}
		return servNumber;
	},
	
	/**
	 * 从URL里面读取号码
	 */
	getServNumberFromUrl : function(){
		debugger;
		return adutil.getParam("msisdn");
	},
	
	/**
	 * 模拟登陆
	 */
	login : function($Page,$Fire,$Gadget,$UI,servNumber,successCallBack,failCallBack){
		debugger;
		$Fire({
			service : "bes.oc.ocauthenticationservice/loginbyloginidauth",
			params : {
				"req":{
					"loginId" : servNumber,
					"loginIdClass" : "2",
					"authId" : "6010100090003",
					"authType" : "AuthCheckZ",
					"sessionFlag" : 1
				}
			},
			target : "$Page.authResp",
			onafter : function(){
				debugger;
				if($Page.authResp != null)
				{
					if($Page.authResp == true || $Page.authResp == 1)
					{
						if (typeof successCallBack === 'function') 
						{
							successCallBack($Page,$Fire,$Gadget,$UI);
							
						}
						
						//重置密码
						if($Page.cspPassWord)
						{
							$Controller.bes.oc.resetpwd.initpassword($Page, $Gadget, $Fire, $UI);
						}

					}
					else if($Page.authResp == false || $Page.authResp == 0)
					{
						failCallBack($Page,$Fire,$Gadget,$UI);
						$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_noright"));
					}
					else if($Page.authResp == -1)
					{
						failCallBack($Page,$Fire,$Gadget,$UI);
						$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_accounterror"));
					}else if($Page.authResp == 2) {
						failCallBack($Page,$Fire,$Gadget,$UI);
						$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_failobtain"));
					}
				}
			},
			onerror : function(){
				debugger;
				if (typeof failCallBack === 'function') 
				{
					failCallBack($Page,$Fire,$Gadget,$UI);
				}
			}
			
		}, $Gadget);
	},
	
	/**
	 * IVR密码校验
	 * @param $Gadget
	 */
	ivrCheck : function(servNumber, $UI)
	{
		debugger;
		//宁夏新增一个系统参数“是否进行IVR密码校验”，只有系统参数要进行IVR密码校验的时候才触发IVR密码校验
		if($Page.isNeedCheckIVR && $Page.isNeedCheckIVR != 'Y'){
			return true;
		}
		
		if(!servNumber){
			servNumber = this.getServNumber();
		}
		if(this.isCsp() && servNumber && servNumber.length==11)
		{
		   try
		   {
			   if (CSPSC == null || CSPSC == undefined)
               {
                   CSPSC = _ysp_top.publicObject["CSPSC"];
               }
               if (chfApi == null || chfApi == undefined)
               {
                  chfApi = CSPSC.chfApi;
               }
               
              // 判断座席是否已签入
               if (chfApi == null || !chfApi.isSignIn())// 座席未签入
               {
            	   // 未办理签入，不可受理业务
				   $UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_notcheckin"));
                   return false;
               }

			   var retAcceptNo = chfApi.getCheckPassNo();
			   // retAcceptNo是上次IVR成功验证的号码，如果retAcceptNo不是当前的servNumber则表示当前的servNumber没进行过IVR密码验证，则触发IVR密码验证
			   if (retAcceptNo != servNumber)
			   {
				   CSPSC.ccAction.checkPwd();
				   return false;
			   }
			   
			   return true;
		   }
		   catch(e)
		   {
			   $UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_vcontrerror") + e);
		       return false;
		   }
		}
	},
	
	/**
	 * 判断是否是csp系统
	 */
	isCsp : function()
	{
		debugger;
		var isCSP = $.cookie("bsacKF");
		if (null != isCSP && "NGCRM_CSP" == isCSP)
		{
			return true;
		}

		return false;
	},
	
	/**
	 * 判断客服系统呼叫类型
	 * 呼叫类型 0:呼入 1:呼出 
	 */
	getCallingType : function()
	{
		var callingType = null;
		
		if(this.isCsp()){
			
			if (CSPSC == null || CSPSC == undefined)
	        {
	            CSPSC = _ysp_top.publicObject["CSPSC"];
	        }
	        if (CSPSC && CSPSC.callingInfo)
	        {
	        	try{
	        		callingType = CSPSC.callingInfo.getCallType()
	        	}catch(e){
	        	}
	        	
	        }
		}
                
        return callingType;
	},
	
	
	/**
	 * 获取crm端口号
	 * 注意获取的端口号类似":10007"，带有冒号
	 */
	getCrmUrlPort:function(){
		var userCity=null;
		
		try {
			userCity = _ysp_top.publicObject["contactRecordNavigator"].curRecordData["userCity"];
		} catch (e) {
			userCity = _ysp_top.publicObject["ngcrm_current_staff"];
		}
		var cityId = userCity.substr(0, 2);


		var crmUrlPortArray = _ysp_top.publicObject["c_sr_crmUrlPortArray"]||[];
		var crmUrlPort = crmUrlPortArray[cityId] ;

		if(!crmUrlPort){
			return null;
		}
		
		return crmUrlPort;
	},
	/**
     * 获取当前的呼入的号码
     */
    getCurrentCallInNum:function(){
        var callerNo = '';
        try {
            var contactRecordNavigator = _ysp_top.publicObject["contactRecordNavigator"];
            if(contactRecordNavigator && contactRecordNavigator.curRecordData)
            {
                callerNo = _ysp_top.publicObject["contactRecordNavigator"].curRecordData["callerNo"];
            }
        }catch(e){
            debugger;
        }
        return callerNo;
    }
});