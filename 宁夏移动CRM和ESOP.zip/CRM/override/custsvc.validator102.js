jQuery.validator.addMethod("isMobile", isMobile);
jQuery.validator.addMethod("checkBeginNo", checkBeginNo);
//add begin m00195071 2012-10-09
jQuery.validator.addMethod("beforeCmpTime", beforeCmpTime);
jQuery.validator.addMethod("afterCmpTime", afterCmpTime);
jQuery.validator.addMethod("checkCarNum", checkCarNum);
jQuery.validator.addMethod("maxLengthb", maxLengthb);
jQuery.validator.addMethod("minLengthb", minLengthb);
jQuery.validator.addMethod("noComma", noComma);
jQuery.validator.addMethod("beforeSomeDay", beforeSomeDay);
jQuery.validator.addMethod("fileTypeFormat", fileTypeFormat);
jQuery.validator.addMethod("validateServNumber", validateServNumber);
jQuery.validator.addMethod("validateMoney", validateMoney);
//add begin by dWX164638 BUG_JS_201304_139 WLAN失效和开通时间有误及WLAN密码设置存在特殊字符的问题 2013-6-21 
jQuery.validator.addMethod("alphanum", alphanum);
//add begin by dWX164638 BUG_JS_201304_139 WLAN失效和开通时间有误及WLAN密码设置存在特殊字符的问题 2013-6-21 
//add begin lKF16235 2014-10-31 R003C2014L010n01  OR_CHQ_201407_506关于开发部分业务积分标价的需求工单
jQuery.validator.addMethod("checkScoreAttr", checkScoreAttr);
//add end lKF16235 2014-10-31 R003C2014L010n01  OR_CHQ_201407_506关于开发部分业务积分标价的需求工单

//add end m00195071 2012-10-09
jQuery.validator.addMethod("passwordLengthb", passwordLengthb);
////////////////////////////////////////////////////////////////////////////////
//
//                          Public Validator Method
//
////////////////////////////////////////////////////////////////////////////////

/**
 * 校验手机号码
 * 【使用方法】 validator="isMobile"
 * @param value 控件值
 * @param element 控件DOM元素
 * @param param 校验输入参数
 * @return 是否是 手机号码
 */
function isMobile(value, element, param)
{
	var retValue = isMobile(value);
	
	return { 
		result : retValue, 
		parameters : param 
	};
}

/**
 * 校验控件时间时间应早于录入的时间
 * 目前仅支持到最小单位为天的比较
 * 【使用方法】 validator="ctvTimeComparator"
 * @param value 控件值
 * @param element 控件DOM元素
 * @param param 校验输入参数
 *        param[0] 相对于当前时间所差月份 比如：4 大4个月 -4 小4个月       
 * @return 
 * //modify by dWX164638 bug 70203 重庆现场bcv测试环境，办理产品变更业务，订购产品时，附加属性设置出现混乱 2014-7-12
 */
function beforeCmpTime(value, element, param)
{
	var retValue = true;
	if(value.length != 0)
	{		
		var param = String(param);
		var currentDateDif = param.length>0?param:"0";
		//时间格式 yyyyMMdd，传空时默认为yyyyMMdd
		var dateFormat = param.length>1?param[1]:"yyyyMMdd";
		//当前时间
		var cmpDate;
		//传入时间
		var thisDate = new Date();
		try
		{
			cmpDate = new Date();
			cmpDate.setHours(0, 0, 0, 0);
			//parseTime解析yyyyMMdd出现问题，采用写死方法进行处理
			//thisDate = jQuery.datetimepicker.parseTime(dateFormat, value);
			var year = value.substring(0,4);
			var month = parseInt(Number(value.substring(4,6)))-1;
			var date = value.substring(6,8);
			thisDate.setFullYear(year, month, date);
			thisDate.setHours(0, 0, 0, 0);
			cmpDate.setMonth(cmpDate.getMonth() + parseInt(Number(currentDateDif)));	
		}
		catch(e)
		{
			retValue = false;
		}
		//小于当前时间与相对值的和
		if(thisDate-cmpDate > 0 )
		{
			retValue = false;
		}
	}
	
	return { 
		result : retValue, 
		parameters : param 
	};
} 
/**
 * 校验控件时间应晚于录入的时间
 * 目前仅支持到最小单位为天的比较
 * 【使用方法】 validator="ctvTimeComparator"
 * @param value 控件值
 * @param element 控件DOM元素
 * @param param 校验输入参数
 *        param[2] 相对于当前时间所差月份 比如：4 大4个月 -4 小4个月       
 * @return 
 * //modify by dWX164638 bug 70203 重庆现场bcv测试环境，办理产品变更业务，订购产品时，附加属性设置出现混乱 2014-7-12
 */
function afterCmpTime(value, element, param)
{
	var retValue = true;
	if(value.length != 0)
	{		
		var param = String(param);
		//与当前时间的相对值，单位为月，传空时默认为0
		var currentDateDif = param.length>0?param:"0";
		//时间格式 yyyyMMdd，传空时默认为yyyyMMdd
		var dateFormat = param.length>1?param[1]:"yyyyMMdd";
		//当前时间
		var cmpDate;
		//传入时间
		var thisDate = new Date();
		try
		{
			cmpDate = new Date();
			cmpDate.setHours(0, 0, 0, 0);
			//parseTime解析yyyyMMdd出现问题，采用写死方法进行处理
			//thisDate = jQuery.datetimepicker.parseTime(dateFormat, value);
			var year = value.substring(0,4);
			var month = parseInt(Number(value.substring(4,6)))-1;
			var date = value.substring(6,8);
			thisDate.setFullYear(year, month, date);
			thisDate.setHours(0, 0, 0, 0);
			cmpDate.setMonth(cmpDate.getMonth() + parseInt(Number(currentDateDif)));	
		}
		catch(e)
		{
			retValue = false;
		}
		//大于当前时间与相对值的和
		if(thisDate-cmpDate < 0 )
		{
			retValue = false;
		}
	}
	
	return { 
		result : retValue, 
		parameters : param 
	};
}

/**
 * 检查车牌号是否合法
 * 【使用方法】 validator="checkCarNum"
 * @param value 控件值
 * @param element 控件DOM元素
 * @param param 校验输入参数
 * @return 是否是 正确的邮政编码
 */
function checkCarNum(value, element, param)
{
	var retValue = true;
	var carNoReg = /苏[0-9A-Z]{6}$/;
	retValue = carNoReg.test(value);
	
	return { 
		result : retValue, 
		parameters : param 
	};	
}
/**
 * 检查密码输入数据是否存在特殊符号
 * 【使用方法】 validator="alphanum"
 * @param value 控件值
 * @param element 控件DOM元素
 * add begin by dWX164638 BUG_JS_201304_139 WLAN失效和开通时间有误及WLAN密码设置存在特殊字符的问题 2013-6-21 
 */
function alphanum(value, element, param)
{
	var retValue = true;
	if ( ''!=value && !(/^[A-Za-z0-9]+$/.test(value))) 
    {
	    retValue = false;
	}
	return { 
		result : retValue,
        parameters : param
	};	
}

/**
 * 开始序号只能由数字或字母组成
 * @param value
 * @param element
 * @param param
 * @return
 */
function checkBeginNo(value, element, param)
{
    var retValue = true;
    if ( ''!=value && !(/^[A-Za-z0-9]+$/.test(value))) 
    {
	    retValue = false;
	}
    
    return {
          result : retValue,
          parameters : param
    };
}

/**
 * 以字节数判断字符串的长度
 * @param value
 * @param element
 * @param param: length [charset(GBK|UTF8))]
 * @return
 */
function maxLengthb(value, element, param)
{
    var retValue = true;
    if(undefined == value && param && param.length < 1)
    {
    	//没有长度参数时认为校验通过
    	retValue = true;
    }
    else
    {
    	var charset = "GBK";
    	if(param.length > 1)
    	{
    		charset = param[1];
    	}
    	
    	var len = ("UTF8"==charset?utf8Length(value):gbkLength(value));
	    if (len > param[0]) 
	    {
		    retValue = false;
		    //element.focus();		    
		}
    }    
    return {
          result : retValue,
          parameters : param
    };
}

/**
 * 以字节数判断字符串的长度
 * @param value
 * @param element
 * @param param: length [charset(GBK|UTF8))]
 * @return
 */
function minLengthb(value, element, param)
{
    var retValue = true;
    if(undefined == value && param && param.length < 1)
    {
    	//没有长度参数时认为校验通过
    	retValue = true;
    }
    else
    {
    	var charset = "GBK";
    	if(param.length > 1)
    	{
    		charset = param[1];
    	}
    	
    	var len = (("UTF8"==charset)?utf8Length(value):gbkLength(value));
	    if (len < param[0]) 
	    {
		    retValue = false;
		    //element.focus();
		}
    }    
    return {
          result : retValue,
          parameters : param
    };
}

/**
 * 判断输入中没有逗号，中英文均判
 * @param value
 * @param element
 * @param param
 * @return
 */
function noComma(value, element, param)
{
	var retValue = true;
	
	//中文或英文逗号
    var reg = /\uff0c|\u002c/;
    var arr = value.match(reg);
    if(arr!=null && arr.index>=0)
    {
    	retValue = false;
    }
	
	return { 
		result : retValue, 
		parameters : param 
	};
}

/**
 * 校验器日期是否早于输入日期
 * @param value
 * @param element
 * @param param
 * @return
 */
function beforeSomeDay(value, element, param)
{
	try
	{
		var time = value.split('-');
        
        var thisDate = new Date(time[0],time[1],time[2]);
    
        var date = new Date();
        
        var date2 = new Date(date.getYear(),date.getMonth()+1,date.getDate());
	
        var result = date2 - thisDate < (param[0]+1)*24*3600*1000;
	}
	catch(e)
	{
		return {result:false,parameters: param }; 
	}
	return { result: result, parameters: param };
 }
////////////////////////////////////////////////////////////////////////////////
//
//                          Private Method
//
////////////////////////////////////////////////////////////////////////////////
/**
 * 校验手机号码
 * @param str 手机号
 * @return 是否是 手机号码
 */
function isMobile(str)
{
	var patrn = /^\+*(86)*((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})){1}[0-9]{8}$/;
	return patrn.test(str);
};


/*String.prototype.getUTF8Length = */
/**
 * 获取字符串在utf8编码时的字节数
 * */
function utf8Length(str) 
{   
    var totalLength = 0;     
    var charCode;  
    for (var i = 0; i < str.length; i++) {  
        charCode = str.charCodeAt(i);  
        if (charCode < 0x007f)  {     
            totalLength++;     
        } else if ((0x0080 <= charCode) && (charCode <= 0x07ff))  {     
            totalLength += 2;     
        } else if ((0x0800 <= charCode) && (charCode <= 0xffff))  {     
            totalLength += 3;   
        } else{  
            totalLength += 4;   
        }          
    }  
    return totalLength;   
}
/**
 * 获取字符串在gbk编码时的字节数
 * */
function gbkLength(str)
{
	
    var totalLength = 0;     
    var charCode;  
    for (var i = 0; i < str.length; i++) {  
        charCode = str.charCodeAt(i);  
        if (charCode < 0x007f)  {     
            totalLength++;     
        }else{  
            totalLength += 2;   
        }          
    }  
    return totalLength;
}
/**
 * 校验导入文件是否是txt格式或者xls格式
 * @param value 控件值
 * @param element 控件DOM元素
 * @param param 校验输入参数
 */
function fileTypeFormat(value, element, param)
{
	var fileType = value.substring(value.lastIndexOf(".")+1);
	var retValue = false;
	if(fileType != '')
	{
		if(fileType == 'txt' || fileType == 'TXT' ||  fileType == 'xls' || fileType == 'XLS' || fileType == 'xlsx'|| fileType == 'XLSX')
		{
			retValue = true;
		}
		
	}
	return { 
		result : retValue, 
		parameters : param 
	};
}

//金额校验 无入参只支持正数，小数点后两位
//如果入参[0]为 true，则支持负数 小数点后两位
function validateMoney(value, element, param)
{
	var parameters = $.isArray(param) ? param : [];
	
    if('' == value || $.trim(value).length == 0)
    {
    	parameters[2] = '金额不能为空';
    	return { 
			result : false, 
			parameters : parameters  
		};
    }
    
    var plus = /^\d+([.]\d{1,2})?$/;
    var negative = /^-\d+([.]\d{1,2})?$/;
    
    var result = plus.test(value);
    
    //contain -
    if(parameters && ("true" == parameters[0]))
    {
    	result = result || negative.test(value);
    }
    
    //格式校验不过 直接返回
    if(!result)
    {
    	parameters[2] = '金额不合法,请重新输入,最多支持小数点后两位';
        
        return { 
    		result : false, 
    		parameters : parameters  
    	};	
    }
    
    //范围不存在或者为空 不需要校验金额范围
    if(!parameters[1] || '' == parameters[1])
    {
        return { 
    		result : true, 
    		parameters : parameters  
    	};        
    }
    
	var express = /^(\(|\[)(\d+([.]\d{1,2})?)-\s*(\d+([.]\d{1,2})?)(\)|\])$/;	
	if(parameters[1].match(express))
	{
		var curValue = toFen(value);
		var beginRange = RegExp.$1;
		var beginValue = toFen(RegExp.$2);
		var beginErrMsg;
	    var isBeginValid = false;
	    if('(' == beginRange )
	    {
	    	isBeginValid = curValue > beginValue;
	    	beginErrMsg = "大于";
	    }
	    else if('[' == beginRange )
	    {
	    	isBeginValid = curValue >= beginValue;
	    	beginErrMsg = "大于等于";
	    }
	    
	    
	    var endRange = RegExp.$6;
	    var endValue = toFen(RegExp.$4);
	    var endErrMsg;
	    
	    var isEndValid = false;
	    if(')' == endRange )
	    {
	    	isEndValid = curValue < endValue;
	    	endErrMsg = "小于";
	    }
	    else if(']' == endRange )
	    {
	    	isEndValid = curValue <= endValue;
	    	endErrMsg = "小于等于";
	    }
	    
	    if(isBeginValid && isEndValid)
	    {
	    	return { 
	    		result : true, 
	    		parameters : parameters  
	    	};	
	    }
	    
	    parameters[2] = '金额超出范围，应' + beginErrMsg + RegExp.$2 + '元,' + endErrMsg + RegExp.$4 + '元。';
	    return { 
			result : false, 
			parameters : parameters  
		};
	}
	
	parameters[2] = '金额范围格式不正确' + parameters[1];
	return { 
		result : false, 
		parameters : parameters  
	};
}
//[0]:特性参数 ServNumberContainLetter
//[1]:可不传 当成服务号码校验，如果传函数 返回值为acctId，formNum，servNumber
//validator="validateServNumber('${isServNumberContainLetter}', 'getNumType()')"         
function validateServNumber(value, element, param)
{
	//add dongdong 2013-12-15  56520 【山东现场问题】快速充值、个人账单查询菜单输入号码后，如果想修改中间的某一位，光标都会自动跳转到最后一位。不太方便如果有空格，需要去掉空格重新赋值 begin
	if(/\s+$/.test(value))
	{
		value = value.replace(/\s+$/,'');
		element.value = value;
	}
	//add dongdong 2013-12-15  56520 【山东现场问题】快速充值、个人账单查询菜单输入号码后，如果想修改中间的某一位，光标都会自动跳转到最后一位。不太方便如果有空格，需要去掉空格重新赋值 end
	var parameters = $.isArray(param) ? param : [];
	
	var isServNumberContainLetter = false;
	if(parameters && parameters.length>=1)
	{
		isServNumberContainLetter = ("true" == parameters[0]);
	}
	
	var numTypeFunc = "";
	if(parameters && parameters.length>=2)
	{
		numTypeFunc = parameters[1];
	}
	
	if(numTypeFunc != "")
	{
		var numType = eval(numTypeFunc);
		
		if("acctId" == numType)
		{
			return _validateAcctId(value, parameters);
		}
		if("certId" == numType)
		{
			return _validateCertId(value, parameters);
		}
	
		if("formNum" == numType)
		{
			return _validateFormNum(value, parameters);
		}
	}
	
	//[1]不存在或 存在取得的返回值为不为acctId formNum则认为是服务号码
	//判空字符串处理
	if( "" == value )
	{
		parameters[2] = "请输入服务号码！";
		
		return { 
			result : false, 
			parameters : parameters  
		};
	}
		
	if (isServNumberContainLetter)
    {
		//按宽带网帐号校验方式处理
		var reg = /^[0-9a-zA-Z][\w@]{0,24}$/;
		if(!reg.test(value))
		{
			parameters[2] = "请输入合法的服务号码(最长25位的数字、字母、下划线或@符的组合，且首位必须是数字或字母开头)！";
			
			return { 
				result : false, 
				parameters : parameters 
			};
		}
		
		return {result : true};
    }
	
	//校验15位以内的数字
	var reg = /^\d{0,15}$/;
	if(!reg.test(value))
	{
		parameters[2] = "请输入合法的服务号码(最长15位的数字)！";
		
		return { 
			result : false, 
			parameters : parameters 
		};
	}
	
	return { 
		result : true 
	};
}

function _validateAcctId(value, parameters)
{
    if( "" == value)
    {
    	parameters[2] = ["帐号不能为空,请重新输入"];
		
		return { 
			result : false, 
			parameters : parameters  
		};
    }
    
    return {result : true};
}

function _validateCertId(value, parameters)
{
    if( "" == value)
    {
    	parameters[2] = ["证件编码不能为空,请重新输入"];
		
		return { 
			result : false, 
			parameters : parameters  
		};
    }
    
    return {result : true};
}


function _validateFormNum(value, parameters)
{
	if( "" == value)
    {
		parameters[2] = ["流水号不能为空,请重新输入"];
		
		return { 
			result : false, 
			parameters : parameters  
		};
    }
    
    return {result : true};	
}

//元转分 最多支持两位小数 才能保证精度准确
function toFen(yuan)
{
    return Math.round(yuan * 100);	
}

//分转元 ，整数类型-->字符串
function toYuan(fen)
{
	var str = fen.toString();
	if(/^-?\d{1,}$/.test(str))
	{
		alert("入参非整数格式");
		return "0.00";
	}
	
	//负号前缀
    var pre = (str.indexOf('-') != -1) ? '-' : '';
    //去掉负号
    str = str.replace(/-/, '');
        
    //一位数字
    var one = /^(\d)$/;
    if(one.test(str))
    {
        return str.replace(one, pre+"0.0$1");
    }
    
    //两位数字
    var two = /^(\d\d)$/;
    if(two.test(str))
    {
        return str.replace(two, pre+"0.$1");
    }
    
    //大于等于三位数字
    var greatThree = /^(\d{1,})(\d\d)$/;
    if(greatThree.test(str))
    {
        return str.replace(greatThree, pre+"$1.$2");
    }
    
}

/**
 * 判断积分附加属性，输入的值不能大于默认值
 * @param value
 * @param element
 * @param param: length [charset(GBK|UTF8))]
 * @return
 * add begin lKF16235 2014-10-31 R003C2014L010n01  OR_CHQ_201407_506关于开发部分业务积分标价的需求工单
 */
function checkScoreAttr(value, element, param)
{
    var retValue = true;
    var defValue = param[0];
    
    if(!value)
    {
    	//没有长度参数时认为校验通过
    	retValue = true;
    }
    else
    {
    	try
    	{
    		if (parseFloat(value) > parseFloat(defValue))
    		{
    			retValue = false;
    		}
    	}
    	catch(e)
    	{
    		retValue = false;
    	}
    }    
    return {
          result : retValue,
          parameters : param
    };
}

/**
 * 以字节数判断字符串的长度
 * @param value
 * @param element
 * @param param: length [charset(GBK|UTF8))]
 * @return
 */
function passwordLengthb(value, element, param)
{
    var retValue = true;
    if(undefined == value && param && param.length < 1)
    {
    	//没有长度参数时认为校验通过
    	retValue = true;
    }
    else
    {
    	var charset = "GBK";
    	if(param.length > 1)
    	{
    		charset = param[1];
    	}
    	
    	var len = ("UTF8"==charset?utf8Length(value):gbkLength(value));
	    if (len != param[0]) 
	    {
		    retValue = false;
		    //element.focus();		    
		}
    }    
    return {
          result : retValue,
          parameters : param
    };
}