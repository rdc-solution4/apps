//屏蔽鼠标右键、Ctrl+N、Shift+F10、F5刷新、退格键  
//屏蔽F1帮助  
function window.onhelp()  
{  
	return false; 
}

//屏蔽右键
window.document.oncontextmenu = function(){
	try
	{
		var cutomerInfo = _ysp_top.middleFrame.leftFrame.cutomerInfo;
		if (cutomerInfo && cutomerInfo.allowContextmenuForNG35)
		{
			return true;
		}
	}
	catch(e)
	{
	}
    return false;
}

function keydown()  
{  
	//屏蔽 Alt+ 方向键 ← 屏蔽 Alt+ 方向键 →  
	if ((window.event.altKey)&&((window.event.keyCode==37)||(window.event.keyCode==39)))  
	{  
		window.event.returnValue=false;  
	}  
	//屏蔽退格删除键,屏蔽 F5 刷新键,Ctrl + R  
	if ((window.event.keyCode==116)||(window.event.ctrlKey && window.event.keyCode==82)||(window.event.ctrlKey && window.event.keyCode==116))  
	{  
		window.event.keyCode=0;  
		window.event.returnValue=false;  
	}  
	//屏蔽 Ctrl+n  
	if ((window.event.ctrlKey)&&(window.event.keyCode==78))  
	{
		window.event.returnValue=false;  
	}
	//屏蔽 Ctrl+a  
	if ((window.event.ctrlKey)&&(window.event.keyCode==65))  
	{
		window.event.returnValue=false;
	}
	
	//屏蔽 Ctrl+c  
	if ((window.event.ctrlKey)&&(window.event.keyCode==67))  
	{
		window.event.returnValue=false;
	}
	
	//屏蔽 shift+F10  
	if ((window.event.shiftKey)&&(window.event.keyCode==121))  
	{  
		window.event.returnValue=false;  
	}  
    //屏蔽 shift 加鼠标左键新开一网页  
    if (window.event.srcElement.tagName == "A" && window.event.shiftKey)  
    {  
        window.event.returnValue = false;  
    }  
    //屏蔽Alt+F4  
    if ((window.event.altKey)&&(window.event.keyCode==115))  
    {  
        window.showModelessDialog("about:blank","","dialogWidth:1px;dialogheight:1px");  
        return false;  
    }  
    //屏蔽Esc
    if(window.event.keyCode == 27) 
    {
        return false;
    } 
    //屏蔽shift + 空格
    if((window.event.shiftKey)&&(window.event.keyCode==32))  
    {
        return false;
    }  
}  
window.document.attachEvent("onkeydown",keydown);


