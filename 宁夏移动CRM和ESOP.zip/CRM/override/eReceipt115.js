/*创建电子免填单*/
function beforePrintReceipt($Page, $Fire, $scope, $UI) {
	debugger;
	if ($Page.electricorder) {
		return;
	}
	$Page.electricorder = true;

	var orderid = 0;
	if ($("#reserveOrderId")) {
		orderid = $("#reserveOrderId").html();
	} else {
		orderid = $Page.createOrderResult.createOrderResp.orderBaseInfo.refOrderId;
	}
	
	$Fire({
		service : "ucec/v1/common/qrysystemparamlistbykey",
		params : {
			keylist : [ 'ProtocolPath','60107061880414' ]
		},
		target : "$Page.sysElePrintParamsList",
		onafter : function() {
			debugger;
			$Page.agreepath = $Page.sysElePrintParamsList[0];
			$Page.projectVersion = "JIANGSU";
			if ($Page.sysElePrintParamsList.length > 1){
				$Page.projectVersion = $Page.sysElePrintParamsList[1];
			}
			//检查无纸化营业厅配置
			checkHalInputMode($Page, $Fire, $scope, $UI, orderid);
		}
	}, $scope);
};

function checkHalInputMode($Page, $Fire, $scope, $UI, orderid) {
	debugger;
	//$Gadget.showCover = true;
	try {
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
	} catch (e) {
	}
	$Fire({
		service : 'bes.oc.ocprintinfoserviceimpl/getPaperlessHal',
		params : {},
		target : '$Page.isTableMode',
		onafter : function() {
			debugger;
			if ($Page.isTableMode == "1") {
				//判断业务是否是无纸化业务
				checkPaperlessBusiness($Page, $Fire, $scope, $UI, orderid);
			} else {
				$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.ereceipt.message.businesshallwithoutpaperlessofficeconfig'));//该营业厅没有进行无纸化营业厅配置。
				$Page.electricorder = false;
				return false;
			}
		},
		onerror : function() {
			//出错处理
		}
	}, $scope);
}

//判断业务是否是无纸化业务,如果是才继续进行推送
function checkPaperlessBusiness($Page, $Fire, $scope, $UI, orderid) {
	debugger;
	//$Gadget.showCover = true;
	var businessCode = "";
	if ($Page.businessCode) {
		businessCode = $Page.businessCode;
	} else {
		if (window._ysp_top.businessCode) {
			businessCode = window._ysp_top.businessCode;
		} else {
			$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.ereceipt.message.businesscodeisnull'));//BusinessCode is null!
			$Page.electricorder = false;
			return false;
		}
	}
	try {
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
	} catch (e) {
	}
	$Fire({
		service : 'bes.oc.ocprintinfoserviceimpl/getPaperlessBusiness',
		params : {
			businessCode : businessCode
		},
		target : '$Page.isFreeTicket',
		onafter : function() {
			debugger;
			if ($Page.isFreeTicket == "1") {
				// 山东先不签名，先弹证件读取 
				if ($Page.Corporation && $Page.Corporation == 'SHANDONG') {
					doCardRead($Page, $Fire);			
				}
				else {
					toPrintReceipt($Page, $Fire, $scope, $UI, orderid);
				}
			} else {
				$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.ereceipt.message.businessnopaperlessserviceconfiguration'));//该业务没有进行无纸化业务配置。
				$Page.electricorder = false;
				return false;
			}
		},
		onerror : function() {
			//出错处理
		}
	}, $scope);
}

/**
 * 弹出证件读取窗口 山东特有
 * c00311908
 */
function doCardRead($Page, $Fire) {
	$Fire({
		popup:{'title':'证件读取','width' : '800px','height':'600px','modal' : true, 'src':'{{$Webapp}}/bes/ad/ctz/gadget/bes-ad-cardread/bes-ad-cardread-pop.html'}
	});	
}

function toPrintReceipt($Page, $Fire, $scope, $UI, orderid) {
	// 查询电子免填单
	debugger;
	var businessCode = "";
	if ($Page.businessCode) {
		businessCode = $Page.businessCode;
	} else {
		if (window._ysp_top.businessCode) {
			businessCode = window._ysp_top.businessCode;
		} else {
			$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.ereceipt.message.businesscodeisnull')); //BusinessCode is null!
			$Page.electricorder = false;
			return false;
		}
	}

	if ($("#reserveOrderId")) {
		orderid = $("#reserveOrderId").html();
	} else {
		orderid = $Page.createOrderResult.createOrderResp.orderBaseInfo.refOrderId;
	}

	try {
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
	} catch (e) {}
	$Fire({
		service: 'bes.oc.ocprintinfoserviceimpl/getprintdata',
		params: {
			"oid": orderid,
			"protocoltype": "E",
			"businessCode": businessCode
		},
		target: '$Page.eInvoiceInfo',
		onafter: function (/* $Page, $Fire, $scope, $UI */) {
			debugger;
			if (null == $Page.eInvoiceInfo) {
				$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.ereceipt.message.nofillreturndataisempty')); //免填单返回数据为空
				$Page.electricorder = false;
				return false;
			}

			$Page.electricorder = false;

			var eInvInfo = $Page.eInvoiceInfo;
			for (var i = 0; i < eInvInfo.length; i++) {
				if ("P" == eInvInfo[i].protocolType) {
					eInvInfo[i].cellFileName = eInvInfo[i].note || "3.pdf";
				}
			}
			var cardTempFile = null;
			var beid = eInvInfo[0].beId;

			//新增字典组AD.ERECEIPT.IDCARDPDFTEMP，idcard.pdf不在代码中固定写，改从字典中取，
			//使用beid条件作为item_code参数获取字典项定义。beid为空时候取99.6
			$Page.newIdcardList = [];
			debugger;
			$Fire({
				'service': '/common/dictkey',
				'params': {
					"dictkeylist": ['AD.ERECEIPT.IDCARDPDFTEMP']
				},
				'target': '$Page.newIdcardList',
				'onafter': function () {
					debugger;
					var list = [];
					$.each($Page.newIdcardList["AD.ERECEIPT.IDCARDPDFTEMP"] || [], function (i, val) {
						var obj = {
							"key": val.itemCode,
							"value": val.itemName
						};
						list.push(obj);
					});

					$Page.newIdcardList = list;
					if ($Page.newIdcardList && $Page.newIdcardList.length > 0) {

						if (beid == "" || beid == null) {
							beid == "99";
						}
						//cardTempFile = "idcard_" + beid + ".pdf";
						for (var i = 0; i < $Page.newIdcardList.length; i++) {
							if (beid == $Page.newIdcardList[i].key) {
								cardTempFile = $Page.newIdcardList[i].value;
								debugger;
							}
						}
					} else if (beid && "" != beid) {
						cardTempFile = "idcard_" + beid + ".pdf";
					} else {
						cardTempFile = "idcard.pdf";
					}
					
					if ($Page.projectVersion == "JIANGSU"){
						if (!isPrototalFileExists(cardTempFile)) {
							// downProtalFile(cardTempFile, '', 'downloadFile');
							downProtalFile(cardTempFile, '');
						}

						if (!isPrototalFileExists(cardTempFile)) {
							if (beid && "" != beid) {
								cardTempFile = "idcard_" + beid + ".pdf";
							} else {
								cardTempFile = "idcard.pdf";
							}
						}
					}

					window._ysp_top.EinvoiceIdCardInfo = window._ysp_top.EinvoiceIdCardInfo || {};
					$Page.servcard = window._ysp_top.EinvoiceIdCardInfo.besservcard;
					$Page.delegcard = window._ysp_top.EinvoiceIdCardInfo.besdelegcard;
					$Page.usercard = window._ysp_top.EinvoiceIdCardInfo.besusercard;

					$Page.newservcard = window._ysp_top.EinvoiceIdCardInfo.besnewservcard;
					$Page.newdelegcard = window._ysp_top.EinvoiceIdCardInfo.besnewdelegcard;

					var busiInfo = creatBusiInfo(eInvInfo);
					var busiInfoXML = creatBusiInfoXML(eInvInfo, orderid, beid,
							cardTempFile, $Page);
					var pdfinfo = {};
					// 是否读了用户身份证
					pdfinfo.servcard = $Page.servcard;
					// 是否读了代办人身份证
					pdfinfo.delegcard = $Page.delegcard;

					//过户添加
					pdfinfo.newservcard = $Page.newservcard;
					pdfinfo.newdelegcard = $Page.newdelegcard;
					// 是否读取使用者/责任人/监护人身份证
					pdfinfo.usercard = $Page.usercard;

					pdfinfo.serialNum = orderid;
					pdfinfo.formNums = orderid;
					pdfinfo.unitePrint = 1;
					pdfinfo.tempType = eInvInfo[0].cellFileName;
					pdfinfo.busiInfo = busiInfo;
					pdfinfo.busiInfoXML = busiInfoXML;
					pdfinfo.tplFileNames = creatFileNames(eInvInfo);

					if ($Page.eInvoiceSignTitle) {
						$Page.eInvoiceSignTitleTemp = _ysp_top.window.document.title;
						_ysp_top.window.document.title = $Page.eInvoiceSignTitle;
					}

					if (chkLocalPrototalFile(eInvInfo)) {
						//无纸化协议本地文件检查成功
						printReceiptInfo(/* $Page, $Fire, $scope, */ $scope, $UI,
							pdfinfo);
					} else {
						//无纸化协议本地文件检查不能过，下载
						downPrototalFiles(eInvInfo);
						printReceiptInfo(/* $Page, $Fire, $scope, */ $scope, $UI,
							pdfinfo);
					}
				}
			}, $scope);
		}
	}, $scope);
}

function queryeInvoiceSignTitle($scope,$UI, pdfinfo){
	debugger;
	//var $Fire=$(document).scope().$Get('$Fire');
	//var $scope = $(document).scope();
	var $Fire = $scope.$Get('$Fire');
	//var $Fire = $scope.$Inject('$Fire');
	$Fire({
		service : "ucec/v1/common/qrysystemparambykey",
		params : {
			key : "EInvoiceSignTitle"
		},
		target : "$Page.eInvoiceSignTitle",
		onafter : function() {
			debugger;
			if($Page.eInvoiceSignTitle){
				$Page.eInvoiceSignTitleTemp=_ysp_top.window.document.title;
				_ysp_top.window.document.title=$Page.eInvoiceSignTitle;
			} 
			toPrintReceiptInfo($scope, $UI, pdfinfo);
		}
	}, $scope);
}


//=========== 无纸化协议处理逻辑 begin ============//
//检查无纸化协议文件在本地C:\protocol目录下是否都存在,如果存在没有文件的情况则返回false
function chkLocalPrototalFile(eInvoiceInfo) {
	debugger;
	for ( var i = 0; i < eInvoiceInfo.length; i++) {
		//if ("A" == eInvoiceInfo[i].protocolType) {
			if (!isPrototalFileExists(eInvoiceInfo[i].cellFileName,eInvoiceInfo[i].templateId)) {
				return false;
			}
		//}
	}
	return true;
}
//判断C:\protocol目录是否存在协议文件
function isPrototalFileExists(fileName) {
	debugger;
	try {
		var fso = new ActiveXObject('Scripting.FileSystemObject');
		var existFilePath = "C:\\protocol\\" + fileName;
		return fso.FileExists(existFilePath)
	}
	catch (e) {
		return true;
	}
	
}
//先下载无纸化文件，再进行下一步操作
function downPrototalFiles(eInvoiceInfo) {
	debugger;
	for ( var i = 0; i < eInvoiceInfo.length; i++) {
		//if ("A" == eInvoiceInfo[i].protocolType) {
			if (!isPrototalFileExists(eInvoiceInfo[i].cellFileName)) {
				downProtalFile(eInvoiceInfo[i].cellFileName,eInvoiceInfo[i].templateId);
			}
		//}
	}
}
//参照现网实现下载无纸化协议
function downProtalFile(fileName, templateId, action) {
	//servlet URL
	debugger;
	var pathName = document.location.pathname;
	var index = pathName.substr(1).indexOf("/");
	var result = pathName.substr(0, index + 1);
	var downLoadOcxPath = window.location.protocol + "//"
		 + window.location.host + result + "/DownloadServlet/";
	//SM的协议暂时先传输到OC服务该目录，以后可以优化
	//数据库里的值 如/besdata/prototal
	var filePathData = $Page.agreepath;

	// 免填单重新生成页面 需要初始化变量  $Page.agreepath  ，不然后面无法取得这个值
	if (!filePathData || filePathData.length == 0) {
		filePathData = "/besdata/protocol";
	}
	var filePath = "";
	//需要转换一下路径，拆分成 "/besapp" + "/prototal"
	if (filePathData && filePathData.length > 0) {
		filePathData = filePathData.substring(1);
		var pathArray = filePathData.split("/");
		for (var i = 0; i <= pathArray.length - 1; i++) {
			filePath += "/" + pathArray[i];
		}
	}

	var urlParams = "filePath=" + filePath + "&fileName=" + fileName + "&templateId=" + templateId;
	var DownLoadOcxObj = document.createElement("object");
	DownLoadOcxObj.setAttribute("id", "DownLoadOcx");
	DownLoadOcxObj.setAttribute("name", "DownLoadOcx");
	DownLoadOcxObj.setAttribute("width", "0");
	DownLoadOcxObj.setAttribute("height", "0");
	DownLoadOcxObj.setAttribute("hspace", "0");
	DownLoadOcxObj.setAttribute("vspace", "0");
	DownLoadOcxObj.setAttribute("classid",
		"clsid:96A29281-312B-4512-8BF4-D0EE63556AB1");
	DownLoadOcxObj.webPath = downLoadOcxPath;
	action = action || 'pluginXml';
	DownLoadOcxObj.PluginFilesName = action + '?' + urlParams;
	DownLoadOcxObj.alldownload();
}

//=========== 无纸化协议处理逻辑 end ============//

function transCardInfo(srcServcard) {
	debugger;

	if (!srcServcard) {
		return null;
	}
	// 证件号码 |姓名|住址|性别(1.男;0.女)|生效日期(yyyy-mm-dd)|失效日期(yyyy-mm-dd)
	/*try{
	var infor = srcServcard.split('|');
	var gender = "男";
	if ("0" == infor[3]) {
		gender = "女";
	}
	var servcard = null;
	// IdCard|身份证号码|姓名|男女性别|民族|19700101生日|住址|公安局|2009.01.24-2029.01.24有效期
	servcard = "IdCard|" + infor[0] + "|" + infor[1] + "|" + infor[3]
			+ "|||" + infor[2] + "||" + infor[4] + "-" + infor[5];
	}
	catch(e)	{
		;
	}*/
	return srcServcard;
}
function creatBusiInfo(eInvoiceInfo) {
	var busiInfo = "&business=";

	for ( var j = 0; j < eInvoiceInfo[0].printCellInfoList.length; j++) {
		if (j == 0) {
			busiInfo += eInvoiceInfo[0].printCellInfoList[j].itemId + '='
					+ eInvoiceInfo[0].printCellInfoList[j].protocolContent;
		} else {
			busiInfo += "=0;0;@_@"
					+ eInvoiceInfo[0].printCellInfoList[j].itemId + '='
					+ eInvoiceInfo[0].printCellInfoList[j].protocolContent;
		}
	}

	return busiInfo;
}

function creatBusiInfoXML(eInvoiceInfo, serialNum, beid, cardTempFile, $Page) {

	var busiInfoXML = "<?xml version=\"1.0\" encoding=\"utf-8\"?><templateList>";

	for ( var i = 0; i < eInvoiceInfo.length; i++) {
		if( eInvoiceInfo[i].protocolType=="P" || !eInvoiceInfo[i].protocolType)
		{
			busiInfoXML += "<templateBean><templateName>c:\\\\protocol\\\\"
				+ eInvoiceInfo[i].cellFileName + "</templateName><serialNo>"
				+ serialNum + "</serialNo><region>" + beid
				+ "</region><regionName></regionName>";
			for ( var j = 0; j < eInvoiceInfo[i].printCellInfoList.length; j++) {
				busiInfoXML += "<content><col></col><row></row><key>"
					+ eInvoiceInfo[i].printCellInfoList[j].itemId
					+ "</key><value";
				// 通过属性控制样式代码 颜色 大小 下划线 经过验证，只有江苏支持，其它局点加上也没问题
				if (validateValue(eInvoiceInfo[i].printCellInfoList[j].fontSize, false)){
					busiInfoXML += " font-size=\""+eInvoiceInfo[i].printCellInfoList[j].fontSize+"\"";
				}
				if (validateValue(eInvoiceInfo[i].printCellInfoList[j].fontColor, true)){
					busiInfoXML += " font-color=\""+eInvoiceInfo[i].printCellInfoList[j].fontColor+"\"";
				}
				if (validateValue(eInvoiceInfo[i].printCellInfoList[j].fontStyle, false)){
					busiInfoXML += " font-style=\""+eInvoiceInfo[i].printCellInfoList[j].fontStyle+"\"";
				}
						
				// 去回车换行
				var contentStr = eInvoiceInfo[i].printCellInfoList[j].protocolContent;
				try
				{
					contentStr = contentStr.replace(/[\r\n|\n]/g,"");
				}
				catch(e)
				{
					contentStr = eInvoiceInfo[i].printCellInfoList[j].protocolContent;
				}
				busiInfoXML += "><![CDATA["
					+ eInvoiceInfo[i].printCellInfoList[j].protocolContent
					+ "]]></value></content>";
			}
		    busiInfoXML += "</templateBean>";
		}
	}
	if ($Page.projectVersion == "JIANGSU"){
		// 拼装证件页面数据
		busiInfoXML += "<templateBean><templateName>c:\\\\protocol\\\\"
				+ cardTempFile + "</templateName><serialNo>" + serialNum
				+ "</serialNo><region>" + beid
				+ "</region><regionName></regionName>";

		busiInfoXML += "<content><col></col><row></row><key>" + "content1"
				+ "</key><value><![CDATA["+ $UEE.i18n('ad.ereceipt.message.businessflow') + serialNum
				+ "]]></value></content>";
		if ($Page.servcard && "" != $Page.servcard) {
			var cardinfo = $Page.servcard.split("|");
			if (cardinfo.length >= 2) {
				busiInfoXML += "<content><col></col><row></row><key>" + "content2"
						+ "</key><value><![CDATA["+ $UEE.i18n('ad.ereceipt.message.idnumber') + cardinfo[1]
						+ "]]></value></content>";
			}
		}
		if ($Page.delegcard && "" != $Page.delegcard) {
			var cardinfo = $Page.delegcard.split("|");
			if (cardinfo.length >= 2) {
				busiInfoXML += "<content><col></col><row></row><key>" + "content3"
						+ "</key><value><![CDATA["+ $UEE.i18n('ad.ereceipt.message.agentidnumber') + cardinfo[1]
						+ "]]></value></content>";
			}
		}
		debugger;
		try {
			debugger;
			var REC_NUMBER_WITHOUT_AUTH = "00000000000";
			var $Page = $(document).scope().$Page;
			// 是否鉴权调用
			var isAuth = $Page.isReadCardAuth;
			// 调用号码
			var recNumber = "";//$.trim("${#BMEStepAttr.ServNumber}");
			if (!isAuth) {
				var recNumber = "";
			}
			if (recNumber == "") {
				recNumber = REC_NUMBER_WITHOUT_AUTH;
			}
			var CERT_IMAGE_ON_CLIENT_BASE_PATH = "C:\\\\temp\\\\certifications\\\\"+recNumber+"\\\\"+window._ysp_top.certImageDirectory.directory+"\\\\"+window._ysp_top.certImageDirectory.timestamp;
			// 检查证件图片大小  true:证件大小没问题 false:证件大小有问题  默认为没问题
			// 出现一次有问题，则认为有问题，后边就不再校验了，最终给一个提示
			var checkCardPicResult = true;
			if ($Page.servcard && "" != $Page.servcard) {
				//"new" + kind + "card.jpg";
				var idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newservcard.jpg";
				if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
				{
					idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newservcard_"+window._ysp_top.serviceNumberForCardName+".jpg"
					if(!validateCardServiceNumber(idCardPath))
					{
						return ;
					}
				}
				// 校验图片大小
				checkCardPicResult = checkPicSize(checkCardPicResult, idCardPath);
					
				busiInfoXML += "<content><key>servCardBase64Str</key><value type=\"image\"><![CDATA["+idCardPath+"]]></value></content>";
			}
			
			if ($Page.delegcard && "" != $Page.delegcard) {	
				var idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newdelegatecard.jpg";
				if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
				{
					idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newdelegatecard_"+window._ysp_top.serviceNumberForCardName+".jpg"
					if(!validateCardServiceNumber(idCardPath))
					{
						return ;
					}
				}
				// 校验图片大小
				checkCardPicResult = checkPicSize(checkCardPicResult, idCardPath);
				busiInfoXML += "<content><key>delegateCardBase64Str</key><value type=\"image\"><![CDATA["+idCardPath+"]]></value></content>";
			}
			if ($Page.newservcard && "" != $Page.newservcard) {	
				var idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newnewservcard.jpg";
				if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
				{
					idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newnewservcard_"+window._ysp_top.serviceNumberForCardName+".jpg"
					if(!validateCardServiceNumber(idCardPath))
					{
						return ;
					}
				}
				// 校验图片大小
				checkCardPicResult = checkPicSize(checkCardPicResult, idCardPath);
				busiInfoXML += "<content><key>newServCardBase64Str</key><value type=\"image\"><![CDATA["+idCardPath+"]]></value></content>";
			}
			if ($Page.newdelegcard && "" != $Page.newdelegcard) {	
				var idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newnewdelegatecard.jpg";
				if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName != '')
				{
					idCardPath = CERT_IMAGE_ON_CLIENT_BASE_PATH+"newnewdelegatecard_"+window._ysp_top.serviceNumberForCardName+".jpg"
					if(!validateCardServiceNumber(idCardPath))
					{
						return ;
					}
				}
				// 校验图片大小
				checkCardPicResult = checkPicSize(checkCardPicResult, idCardPath);
				busiInfoXML += "<content><key>newDelegateCardBase64Str</key><value type=\"image\"><![CDATA["+idCardPath+"]]></value></content>";
			}
			
			if (!checkCardPicResult){
				// 图片大小校验不通过，在弹出免填单之前给一个提示
				alert('请操作员核实当前用户证件图片是否异常，若有问题请通过电子免填单重新生成菜单补推送办理！');
			}
		} catch (e) {
		}
		busiInfoXML += "</templateBean>";
	}
	
	//协议
	for ( var i = 0; i < eInvoiceInfo.length; i++) {
		if( eInvoiceInfo[i].protocolType=="A")
		{
			busiInfoXML += "<templateBean><templateName>c:\\\\protocol\\\\"
				+ eInvoiceInfo[i].cellFileName + "</templateName><serialNo>"
				+ serialNum + "</serialNo><region>" + beid
				+ "</region><regionName></regionName>";
			for ( var j = 0; j < eInvoiceInfo[i].printCellInfoList.length; j++) {
				busiInfoXML += "<content><col></col><row></row><key>"
						+ eInvoiceInfo[i].printCellInfoList[j].itemId
						+ "</key><value><![CDATA["
						+ eInvoiceInfo[i].printCellInfoList[j].protocolContent
						+ "]]></value></content>";
			}
		    busiInfoXML += "</templateBean>";
		}
	}

	busiInfoXML += "</templateList>";
	return busiInfoXML;
}

/**
 * 校验证件图片大小
 * @param idCardPath
 */
function checkPicSize(checkCardPicResult,idCardPath) {
	debugger;
	// 在配置了系统参数的前提下才校验
	// 在证件图片没有校验出问题之前，校验证件图片大小
	if (checkCardPicResult && $Page.MultiDeviceReadPicSize && $Page.MultiDeviceReadPicSize > 0)
	{
		var fileSize = CreatePDF.getFileSize(idCardPath);
		if (fileSize < $Page.MultiDeviceReadPicSize * 1024)
		{
			checkCardPicResult = false;
		}
	}
	
	return checkCardPicResult;
}

/**
 * 校验证件图片与当前业务办理的号码是否匹配
 * c00311908
 */
function validateCardServiceNumber(picPath)
{
	debugger;
	try{
		// 校验图片是否存在
		var fso = new ActiveXObject('Scripting.FileSystemObject');
		if(fso.FileExists(picPath))
		{
			// 校验名称是否匹配
			if (window._ysp_top.serviceNumberForCardName && window._ysp_top.serviceNumberForCardName!='')
			{
				var picServiceNumber = (picPath.split('_')[1]).split('.')[0];
				if (picServiceNumber == window._ysp_top.serviceNumberForCardName)
				{
					return true;
				}
				else
				{
					alert('系统获取用户身份证图片异常，请通过“电子免填单重新生成”菜单做补推送处理。');
					return false;
				}
			}
		}
		else
		{
			alert('系统获取用户身份证图片异常，请通过“电子免填单重新生成”菜单做补推送处理。');
			return false;
		}
		
	}
	catch(e){
		// 出现检查异常时，是按检查通过还是失败来处理，这是一个问题
		alert('系统获取用户身份证图片异常，请通过“电子免填单重新生成”菜单做补推送处理。');
		return false;
	}
	return true;
}

/**
 * 校验值是否合法
 * 	不可为空 不可为0
 * @param data
 * @param isCanBeZero
 * @returns {Boolean}
 */
function validateValue(data, isColor) {
//	debugger;
	if (data && data != '') {
		if (isColor) {
			// 颜色处理
			if (data == "0"){
				return false;
			}
			// 颜色的话要检查格式是否为 r,g,b 格式
			var colors = data.split(",");
			if (colors.length == 3) {
				return true;
			}
			else {
				alert("Color Config Fail!" + data);
				return false;
			}
		}
		else if (data == "0"){
			// 不是颜色 但值为零
			return false;
		}
		else {
			// 不是颜色 值也不为零
			return true;
		}
	}
	return false;
}

function creatFileNames(eInvoiceInfo) {
	var protFloder = "@c:\\protocol\\";
	var fileNames = "";
	/*
	 * protFloder + eInvInfo[0].cellFileName + "," + protFloder +
	 * eInvInfo[1].cellFileName;
	 */
	for ( var i = 0; i < eInvoiceInfo.length; i++) {
		if (i == 0) {
			fileNames = protFloder + eInvoiceInfo[i].cellFileName;
		} else {
			fileNames += "," + protFloder + eInvoiceInfo[i].cellFileName;
		}

	}

	return fileNames;

}
function printReceiptInfo(/* $Page, $Fire, $scope, */$scope, $UI, pdfinfo) {
	debugger;
	queryeInvoiceSignTitle($scope, $UI, pdfinfo);
};

function toPrintReceiptInfo($scope, $UI, pdfinfo){

	/*-- 1、判断是否需要打印电子免填单 --*/
	if (true/* '${elecPrint }' == 'true' */) {
		debugger;

		CreatePDF
				.init(
						pdfinfo.serialNum,
						pdfinfo.unitePrint,
						pdfinfo.tempType,
						'0',
						pdfinfo.busiInfo,
						pdfinfo.busiInfoXML,
						'0',
						'0',
						'',
						'',
						'[\'null@null\',\'certinfo.pdf@/ftproot/upload/EvmsAgreePDF/13/\',\'2.pdf@/ftproot/upload/EvmsAgreePDF/13/\']',
						'true', pdfinfo.tplFileNames, pdfinfo.servcard,
						pdfinfo.delegcard, pdfinfo.newservcard,
						pdfinfo.newdelegcard, pdfinfo.formNums, pdfinfo.serviceNumber);

		CreatePDF.replaceCertifications('${formNumbers }');
		CreatePDF.pdfAction($scope);
		debugger;
		
		//电子免填单推送时，弹出免填单窗口，此需要将父窗口的标题名更新成“”。 在电子免填单签名保存成功时，将父窗口标题名称恢复。
		if($Page.eInvoiceSignTitleTemp){
			_ysp_top.window.document.title=$Page.eInvoiceSignTitleTemp;
		} 
		// alert("业务流水："+pdfinfo.serialNum+" 电子免填单生成成功，请继续");
		// $UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), "业务流水："+pdfinfo.serialNum+" 电子免填单生成成功，请继续");
		// 调后台服务生产PDF文件
		/*
		 * $Fire({ service : 'bes.oc.einvoiceservice/einvoicecreatepdf',
		 * params : { "parameters" : CreatePDF.parameters }, target :
		 * '$Page.eInvoiceCreatePDFResult', onafter : function() {
		 * 
		 * $UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), "业务流水：XXXX 电子免填单生成成功，请继续"); } }, $scope);
		 */

	} else {
		printNormalReceipt();
	}
};
function printReceipt($Page, $Fire, $scope, $UI) {
	/*-- 1、判断是否需要打印电子免填单 --*/
	if (true/* '${elecPrint }' == 'true' */) {
		debugger;
		/*
		 * CreatePDF.init('${prtFormNum }', '${unitePrint }', '${tempType }',
		 * '${custCert}', '${busiInfo }', '${busiInfoXML }', '${newCustCert}',
		 * '${certContentChk}', '${proTempTypes}', '${luckyTelType}',
		 * '${pdfTplFileStr}', '${hasPad4Sign}', '${tplFileNames}');
		 */

		CreatePDF
				.init(
						'13150406359370272',
						'1',
						'2.pdf',
						'0',
						'&business=year%3D2015',
						'<?xml version=\"1.0\" encoding=\"utf-8\"?><templateList><templateBean><templateName>c:\\\\protocol\\\\2.pdf</templateName><serialNo>13150406359370272</serialNo><region>13</region><regionName>\u5BBF\u8FC1</regionName><content><col></col><row></row><key>regionName</key><value><![CDATA[\u5BBF\u8FC1]]></value></content><content><col></col><row></row><key>year</key><value><![CDATA[2015]]></value></content><content><col></col><row></row><key>recorgid</key><value><![CDATA[]]></value></content><content><col></col><row></row><key>month</key><value><![CDATA[04]]></value></content><content><col></col><row></row><key>day</key><value><![CDATA[06]]></value></content><content><col></col><row></row><key>operator</key><value><![CDATA[6010716]]></value></content><content><col></col><row></row><key>servnumber</key><value><![CDATA[13773902932]]></value></content><content><col></col><row></row><key>custname</key><value><![CDATA[\u6D4B\u8BD5\u5BA2\u6237]]></value></content><content><col></col><row></row><key>content1</key><value><![CDATA[\u4E1A\u52A1\u7C7B\u578B:\u5B9A\u8D2D\u68A6\u7F51\u670D\u52A1 \u53D7\u7406\u6D41\u6C34\u53F7:13150406359370272]]></value></content><content><col></col><row></row><key>content2</key><value><![CDATA[\u53D7\u7406\u65F6\u95F4:2015-04-06 19:23:39(\u670D\u52A1\u5BC6\u7801\u8BA4\u8BC1)]]></value></content><content><col></col><row></row><key>content3</key><value><![CDATA[<\u5B9A\u8D2D\u68A6\u7F51\u4E1A\u52A1>\uFF1A]]></value></content><content><col></col><row></row><key>content4</key><value><![CDATA[\u4E2D\u56FD\u73BB\u7483\u7F51\u4FE1\u606F 1.80 \u5143/\u6708\uFF08\u8D77\u6B62\u65F6\u95F4\uFF1A20150406-);]]></value></content><content><col></col><row></row><key>printdate</key><value><![CDATA[\u6253\u5370\u65F6\u95F4\uFF1A2015\u5E744\u67087\u65E5 3\u65F626\u520626\u79D2]]></value></content><content><col></col><row></row><key>authinfo</key><value><![CDATA[\u9274\u6743\u65B9\u5F0F\uFF1A\u4E0D\u6821\u9A8C\u5BC6\u7801 \u9274\u6743\u65F6\u95F4\uFF1A2015-04-07 03:24:16]]></value></content></templateBean><templateBean><templateName>C:\\\\protocol\\\\certinfo.pdf</templateName><serialNo>13150406359370272</serialNo><region>13</region><regionName>\u5BBF\u8FC1</regionName>CERTIFICATIONSIMAGES<content><col></col><row></row><key>content1</key><value><![CDATA[\u4E1A\u52A1\u6D41\u6C34\uFF1A13150406359370272]]></value></content><content><col></col><row></row><key>content20</key><value><![CDATA[\u672C\u4EBA\u5DF2\u7ECF\u9605\u8BFB\u5E76\u7406\u89E3\u4EE5\u4E0A\u4E1A\u52A1\u53D7\u7406\u5355\u548C\u534F\u8BAE\u76F8\u5173\u5185\u5BB9\uFF0C\u7B7E\u5B57\u540C\u610F\u529E\u7406\u4EE5\u4E0B\u4E1A\u52A1]]></value></content></templateBean></templateList>',
						'0',
						'0',
						'',
						'',
						'[\'null@null\',\'certinfo.pdf@/ftproot/upload/EvmsAgreePDF/13/\',\'2.pdf@/ftproot/upload/EvmsAgreePDF/13/\']',
						'true',
						'@c:\\protocol\\2.pdf,@C:\\protocol\\certinfo.pdf,');
		CreatePDF.replaceCertifications('${formNumbers }');
		CreatePDF.pdfAction();

		try {
			OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
		} catch (e) {
		}
		// 调后台服务生产PDF文件
		$Fire({
			service : 'bes.oc.einvoiceservice/einvoicecreatepdf',
			params : {
				"parameters" : CreatePDF.parameters
			},
			target : '$Page.eInvoiceCreatePDFResult',
			onafter : function() {

				$UI.msgbox.info($UEE.i18n('ad.checkout.label.information'), $UEE.i18n('ad.ereceipt.message.serviceflowissuccessful'));//业务流水：XXXX 电子免填单生成成功，请继续
			}
		}, $scope);

	} else {
		printNormalReceipt();
	}
};

// 是否走桩
function isMock()
{
	return false;
};
