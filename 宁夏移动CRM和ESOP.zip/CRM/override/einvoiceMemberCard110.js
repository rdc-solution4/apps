/**
* 本程序用于电子免填单场景下，成员证件相关操作的JS合集
* @remark create l00227362 2014-05-06 OR_JS_201403_1755 关于优化前台无纸化系统的需求PART2
* 
* 流程：
* -------------------------------------------------------------
* 1.读取：业务侧调用bossShowICCardInfoMember.tag证件读取页面,读入证件
* 		  证件信息缓存到MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH\[taboid]\[servnum].jpg
* 		  Attention：已解耦，业务侧不需要维护成员与证件读取的对应关系
* -------------------------------------------------------------
*  
* -------------------------------------------------------------
* 2.同步：业务侧调用同步方法synCommitMemberInfoBothClientAndServer，传入家庭、亲情组合有效成员
* 		  生成号码与读取证件对应关系,存储到leftcsp.jsp中
* 		  memberCert.[taboid].[cardABCD]=certType#certNo#custName
* -------------------------------------------------------------
* 
* -------------------------------------------------------------
* 3.刷新：场景1：事后打印电子免填单 场景2：小键盘模式，事前打印电子免填单
* 		  本地证件刷新为MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH\[formnum]\[servnum].jpg
* 	      leftcsp.jsp 刷新为memberCert.[formnum].[cardABCD]
* -------------------------------------------------------------
* 
* -------------------------------------------------------------
* 4.客户端推送&确认：(1)生成客户端报文、下载新模板，并验证MD5 @see recinvoice.tag CommonSuccessAction.java、EInvoiceDataUtil.java等
* 					(2)免填单合打情况进行处理 
* 					(3)对证件模板动态替换进行处理 
* 					(4)根据leftcsp数据和客户端本地缓存生成客户端报文
* 					(5)推送给易普森、金格
* ------------------------------------------------------------- 
* 
* -------------------------------------------------------------
* 5.组装服务端报文： 获取图片BASE64等信息，合成到报文中，在服务端继续组装
* 					@see recinvoice.tag CommonSuccessAction.java
* ------------------------------------------------------------- 
* 
* -------------------------------------------------------------
* 6.保存电子免填单： @see ngpdf工程 generatePDF接口
* -------------------------------------------------------------
* 
* -------------------------------------------------------------
* 7.清理：用户退出系统清理本机缓存路径所有文件
* 		  Attention：不能提前清理，会影响合打判断
* -------------------------------------------------------------
* 
*/

// 证件本机缓存路径
var MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH = "C:\\temp\\crmMemberCerts\\";
// 待替换的模板xml(服务器端返回)
var MEMBER_CERT_IMAGE_IN_EINVOICE_TAG = "MEMBERCERTIFICATIONSIMAGES";
// 证件本机缓存文件夹
var MEMBER_CERT_IMAGE_ON_CLIENT_BASE_FOLDER = "C:\\temp\\crmMemberCerts";


/**
 * 建立证件图片在客户端的存储路径
 * @param recNumber 办理号码
 * @return 图片绝对路径
 */
function buildMemberCertImagePathOnClient(tabOid4E ,recNumber)
{
	var authImageFolder = MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\";
	checkAndCreateFolderOnClient(authImageFolder);
	return authImageFolder + recNumber + ".jpg";
}

/**
 * 构造证件对象(用于暂存到leftcsp或业务页面)
 * key certification.[服务号码]
 * value 证件信息
 * @param recNumber 办理号码
 * @param certInfo 证件信息
 * @return 构造的暂存CertString对象
 */
function buildCertObject(recNumber, certInfo)
{
	var certString = new Object();
	certString.key = "crmMemberCerts." + recNumber;
	certString.value = certInfo;
	return certString;
}

/**
 * 检查并创建目录
 * 保证目录格式正确
 * @param path 目录路径
 */
function checkAndCreateFolderOnClient(path)
{
	var paths = path.split("\\");
	if (paths.length < 1)
	{
		return "";
	}
	path = paths[0] + "\\";
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	for (var i = 1; i < paths.length; i ++)
	{
		if (paths[i] == "")
		{
			continue;
		}
		path += paths[i] + "\\";
		if (!fso.FolderExists(path))
	    {
	    	fso.CreateFolder(path);
	    }
	}
	return path;
}

/**
 * 获取图片BASE64编码
 * 调用HWUtilOCX控件获取图片BASE64编码
 * @param imagePath 图片绝对路径
 * @return BASE64
 */
function getBase64OfImage(imagePath)
{
	var hwUtil = document.getElementById("HWUtilOCX");
	if (hwUtil && imagePath)
	{
		return hwUtil.Base64EncodePath(imagePath);
	}
    return "";
}

/**
 * 关闭系统清空证件
 */
function clearAllImagesOnClient()
{
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (fso.FolderExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_FOLDER))
    {
        fso.DeleteFolder(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_FOLDER, true);
    }
}

/**
 * 构建业务存取唯一标识
 * TAB页面对象属性
 * @param date 时间流水
 * @return 唯一标示
 */
function createTabOid4E(date)
{
	var currentTab = getCurTab();
	// 获取不到当前tab时返回空串
	if (null == currentTab)
	{
		return "";
	}
	
	if (currentTab.oid4EI == undefined || currentTab.oid4EI == "")
	{
		currentTab.oid4EI = date;
	}
	return currentTab.oid4EI;
}

/**
 * 获取业务存取唯一标识
 * @param topWindow 顶层窗口
 * @return 唯一标示
 */	
function getTabOid4E(topWindow)
{
	var currentTab = getCurTab(topWindow);
	if (currentTab && currentTab.oid4EI)
	{
		return currentTab.oid4EI;
	}
	return "";
}

/**
 * 刷新JSP和客户端的证件信息
 * @param servNumber 办理号码
 * @param formNumber 业务流水
 * @param topWindow顶层窗口
 * @param tabOid4E 唯一标示
 */
function refreshMemCertOidToFormnuber(tabOid4E, formNumber, topWindow, servNumber)
{
	if (tabOid4E == undefined || tabOid4E == null || tabOid4E == "")
	{
		return;
	}
	if (formNumber == undefined || formNumber == null || formNumber == "")
	{
		return;
	}
	var savingPage = undefined;
	if (topWindow) 
	{
	    savingPage = topWindow.middleFrame.leftFrame.cutomerInfo;
	} 
	else 
	{
	    savingPage = getMemberCertSavingPage();
	}
	if (savingPage == undefined)
	{
		return;
	}
	var certString = new Object();
	var memberCardA = savingPage.document.getElementById("memberCert." + tabOid4E + ".A");
	if(memberCardA)
	{
		certString.key = "memberCert." + formNumber + ".A";
		certString.value = memberCardA.value;
		appendMemberCertInfoToPage(savingPage, certString);
		copyImageOnClient(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\", MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber + "\\", "A.jpg");
	}
	
	var memberCardB = savingPage.document.getElementById("memberCert." + tabOid4E + ".B");
	if(memberCardB)
	{
		certString.key = "memberCert." + formNumber + ".B";
		certString.value = memberCardB.value;
		appendMemberCertInfoToPage(savingPage, certString);
		copyImageOnClient(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\", MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber + "\\", "B.jpg");
	}
	
	var memberCardC = savingPage.document.getElementById("memberCert." + tabOid4E + ".C");
	if(memberCardC)
	{
		certString.key = "memberCert." + formNumber + ".C";
		certString.value = memberCardC.value;
		appendMemberCertInfoToPage(savingPage, certString);
		copyImageOnClient(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\", MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber + "\\", "C.jpg");
	}
	
	var memberCardD = savingPage.document.getElementById("memberCert." + tabOid4E + ".D");
	if(memberCardD)
	{
		certString.key = "memberCert." + formNumber + ".D";
		certString.value = memberCardD.value;
		appendMemberCertInfoToPage(savingPage, certString);
		copyImageOnClient(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\", MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber + "\\", "D.jpg");
	}
	
}


/**
 * 复制图片
 * 从源路径将指定名称图片复制到目标路径
 * @param fromPath 源路径
 * @param toPath 目标路径
 * @param fileName 文件名
 */
function copyImageOnClient(fromPath, toPath, fileName)
{
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (!fso.FolderExists(fromPath) || !fso.FileExists(fromPath + fileName))
    {
        return;
    }
    checkAndCreateFolderOnClient(toPath);
    fso.CopyFile(fromPath + fileName, toPath + fileName, true);
}

/**
 * 获取保存证件信息的页面
 * 即指 leftCsp.jsp
 */
function getMemberCertSavingPage()
{
	var leftJsp;
	
	//本页获取
	if (_ysp_top && _ysp_top.middleFrame && _ysp_top.middleFrame.leftFrame && _ysp_top.middleFrame.leftFrame.cutomerInfo)
	{
		leftJsp = _ysp_top.middleFrame.leftFrame.cutomerInfo;
		return leftJsp;
	}
	
	//iframe获取
	if (window.parent && window.parent._ysp_top && window.parent._ysp_top.middleFrame && window.parent._ysp_top.middleFrame.leftFrame
		&& window.parent._ysp_top.middleFrame.leftFrame.cutomerInfo)
	{
		leftJsp = window.parent._ysp_top.middleFrame.leftFrame.cutomerInfo;
		return leftJsp;
	}
	
	//一般弹出窗口获取
	if (window.opener && window.opener._ysp_top && window.opener._ysp_top.middleFrame && window.opener._ysp_top.middleFrame.leftFrame
		&& window.opener._ysp_top.middleFrame.leftFrame.cutomerInfo)
	{
		leftJsp = window.opener._ysp_top.middleFrame.leftFrame.cutomerInfo;
		return leftJsp;
	}
	
	//模态弹出窗口获取
	if (window.dialogArguments)
    {
        var parentWin = window.dialogArguments;
        if (parentWin.dialogArguments) {
            parentWin = parentWin.dialogArguments;
            if (parentWin.length && parentWin.length > 3) {
                parentWin = parentWin[3];
            }
        }
        
        if (parentWin._ysp_top && parentWin._ysp_top.middleFrame
            && parentWin._ysp_top.middleFrame.leftFrame && parentWin._ysp_top.middleFrame.leftFrame.cutomerInfo)
        {
            leftJsp = parentWin._ysp_top.middleFrame.leftFrame.cutomerInfo;
            return leftJsp;
        }
    }
	
	//异常情况，未获取到
	return leftJsp;
}

/**
 * 清理业务办理过程中的证件
 * 首先清理leftCsp.jsp中certifications.[recNumber]开头的隐藏域
 * 其次清理本机存放读入图片的路径
 * @param tabOid4E 唯一标示
 */
function clearTabOid4EMemberCert(tabOid4E)
{	
	var savingPage = getMemberCertSavingPage();
	if (savingPage == undefined)
	{
		return;
	}
    // 意外情况，使用默认号码
	if (tabOid4E == undefined || tabOid4E == null || tabOid4E == "")
	{
		return;
	}
	// 清理jsp
	var memberCertA = savingPage.document.getElementById("memberCert." + tabOid4E + ".A");
	if (memberCertA)
	{
		removeCertElementFromPage(savingPage, memberCertA);
	}		
	
	var memberCertB = savingPage.document.getElementById("memberCert." + tabOid4E + ".B");
	if (memberCertB)
	{
		removeCertElementFromPage(savingPage, memberCertB);
	}	
	
	var memberCertC = savingPage.document.getElementById("memberCert." + tabOid4E + ".C");
	if (memberCertC)
	{
		removeCertElementFromPage(savingPage, memberCertC);
	}	
	
	var memberCertD = savingPage.document.getElementById("memberCert." + tabOid4E + ".D");
	if (memberCertD)
	{
		removeCertElementFromPage(savingPage, memberCertD);
	}	
	
	// 清理本机
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (fso.FolderExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E))
    {
        fso.DeleteFolder(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E, true);
    }
}

/**
 * 从指定页面删除指定元素
 * @param page 指定页面
 * @param page 表单中的一个元素
 */
function removeCertElementFromPage(page, element)
{
	try
	{
		page.document.forms[0].removeChild(element);
	}
	catch(e)
	{
		alert("删除失败");
	}
}

/**
 * 获取流水号对应的证件图片信息
 * 鉴权证件直接取对应标识
 * 业务证件取与鉴权证件不同的证件（按照循环，应该是取最后两个不同的）
 * @param 业务流水号数组
 * @param leftCsp leftcsp.jsp
 * @return certImages对象，包含四种性质的证件；每种证件都是certImage对象，包含path和hash属性；
 *         path属性是指图片在本地存储路径（不一定存在）；hash是一个由certType#certNo#custName组成的识别串
 */
function getMemberCertFromClient(formNumbers, leftCsp)
{
	if (formNumbers == undefined || formNumbers == null || formNumbers.length <= 0)
	{
		return null;
	}
	
	var certImage = new Object();
	certImage.hash = "";
	certImage.path = "";
	var certImages = new Object();
	certImages.memberCertA = certImage;
	certImages.memberCertB = certImage;
	certImages.memberCertC = certImage;
	certImages.memberCertD = certImage;

	//获取保存页面
	var savingPage = leftCsp;
	if (!leftCsp) {
	    savingPage = getMemberCertSavingPage();
	}
	if (savingPage == undefined)
	{
		//alert("获取不到保存证件信息的页面，此前读取的证件将不能合并到电子免填单中。");
		return certImages;
	}
	var tempCertImage = null;
	for (var i = 0; i < formNumbers.length; i ++)
	{
		if (formNumbers[i] == "")
		{
			continue;
		}
		var memberCertA = savingPage.document.getElementById("memberCert." + formNumbers[i] + ".A");
		if (memberCertA)
		{
			if (certImages.memberCertA.hash != memberCertA.value)
			{
				tempCertImage = new Object();
				tempCertImage.hash = memberCertA.value;
				tempCertImage.path = MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumbers[i] + "\\A.jpg";
				certImages.memberCertA = tempCertImage;
			}
		}
		
		var memberCertB = savingPage.document.getElementById("memberCert." + formNumbers[i] + ".B");
		if (memberCertB)
		{
			if (certImages.memberCertB.hash != memberCertB.value)
			{
				tempCertImage = new Object();
				tempCertImage.hash = memberCertB.value;
				tempCertImage.path = MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumbers[i] + "\\B.jpg";
				certImages.memberCertB = tempCertImage;
			}
		}
		
		var memberCertC = savingPage.document.getElementById("memberCert." + formNumbers[i] + ".C");
		if (memberCertC)
		{
			if (certImages.memberCertC.hash != memberCertC.value)
			{
				tempCertImage = new Object();
				tempCertImage.hash = memberCertC.value;
				tempCertImage.path = MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumbers[i] + "\\C.jpg";
				certImages.memberCertC = tempCertImage;
			}
		}
		
		var memberCertD = savingPage.document.getElementById("memberCert." + formNumbers[i] + ".D");
		if (memberCertD)
		{
			if (certImages.memberCertD.hash != memberCertD.value)
			{
				tempCertImage = new Object();
				tempCertImage.hash = memberCertD.value;
				tempCertImage.path = MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumbers[i] + "\\D.jpg";
				certImages.memberCertD = tempCertImage;
			}
		}
	}
	
	return certImages;
}

/**
 * 向电子免填单推送报文中附加证件图片信息
 * @param noImageXml不带图片的报文
 * @param images 图片，包含四种性质的证件；每种证件都是certImage对象，包含path和hash属性；
 *         path属性是指图片在本地存储路径（不一定存在）；hash是一个由certType#certNo#custName组成的识别串
 * @param memberIdCardTemplate 证件页模板
 */
function appendMemberCertImageToEinvoice(noImageXml, images, memberIdCardTemplate)
{
	if (images == null)
	{
		return noImageXml.replace(MEMBER_CERT_IMAGE_IN_EINVOICE_TAG, "");
	}
	var imageXml = buildMemberCertImageXmlForEinvoice(images.memberCertA.path, "memberACardBase64Str")
		+ buildMemberCertImageXmlForEinvoice(images.memberCertB.path, "memberBCardBase64Str")
		+ buildMemberCertImageXmlForEinvoice(images.memberCertC.path, "memberCCardBase64Str")
		+ buildMemberCertImageXmlForEinvoice(images.memberCertD.path, "memberDCardBase64Str");
	
	//如果不存在证件，则替换服务端返回的报文，不展示memberIdCardTemplate模板
	if(imageXml == "")
	{	
		noImageXml = noImageXml.replace("<templateBean><templateName>C:\\\\protocol\\\\" + memberIdCardTemplate + "</templateName>MEMBERCERTIFICATIONSIMAGES</templateBean>","");
	}
	
	return noImageXml.replace(MEMBER_CERT_IMAGE_IN_EINVOICE_TAG, imageXml);
}

/**
 * 构建图片在电子免填单推送中的报文
 * @param filePath 图片绝对路径
 * @param tagName 在PDF中的域标识
 */
function buildMemberCertImageXmlForEinvoice(filePath, tagName)
{
    if (filePath == undefined || filePath == null || filePath == "")
	{
		return "";
	}
	var fso = new ActiveXObject('Scripting.FileSystemObject');
 	if (!fso.FileExists(filePath))
 	{
    	return "";
 	}
 	var xmlStr = "";
 	xmlStr += "<content>\n";
 	xmlStr += "<key>" + tagName + "</key>\n";
 	xmlStr += "<value type=\"image\"><![CDATA["+ filePath + "]]></value>\n";
 	xmlStr += "</content>\n";
 	return xmlStr;
}

/**
 * 同步成员证件信息，以备电子免填单服务端和客户端生成
 * 业务侧调用，业务操作完成后，提交业务之前
 * @param 需要展示的号码
 */
function synCommitMemberInfoBothClientAndServer(memberServnumA, memberServnumB, memberServnumC, memberServnumD)
{
	cleanSynedCommitMember();
	generateSynDataBothClientAndServer(memberServnumA);
	generateSynDataBothClientAndServer(memberServnumB);
	generateSynDataBothClientAndServer(memberServnumC);
	generateSynDataBothClientAndServer(memberServnumD);
}

/**
 * 同步一个成员信息的具体方法
 * @param memberServnum 服务号码
 * @see synCommitMemberInfoBothClientAndServer
 */
function generateSynDataBothClientAndServer(memberServnum)
{
	if(memberServnum == "" || memberServnum == null || memberServnum == undefined)
	{
		return;
	}
	
	if(isCardImageExistOnClient(memberServnum))
	{
		//拷贝客户端文件
		var tabOid4E = getTabOid4E();
		var memberCardNameString = getMemberCardNameString();
	    var fso = new ActiveXObject('Scripting.FileSystemObject');
		fso.CopyFile(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\" + memberServnum + ".jpg", MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\" + memberCardNameString + ".jpg");
	
		//生成leftcsp数据
		var certObjectInLeftCsp = new Object();
		certObjectInLeftCsp.key = "memberCert." + tabOid4E + "." + memberCardNameString; 
		certObjectInLeftCsp.value = "||";
		var savingPage = getMemberCertSavingPage();
		if (savingPage == undefined)
		{
			alert("获取不到保存证件信息的页面，此次读取的证件将不能合并到电子免填单中。");
			return false;
		}
		
		appendMemberCertInfoToPage(savingPage, certObjectInLeftCsp);
		
	}
}

/**
 * 将键值对附加到指定页面
 * @param page 指定页面
 * @param tagset 键值对：key，键；value，值
 * 如果没有重复的key，则新建；如果有，则覆盖
 * @see generateSynDataBothClientAndServer
 */
function appendMemberCertInfoToPage(page, tagset)
{
	var element = page.document.getElementById(tagset.key);
	if (!element)
	{
		var tempElement = page.document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = tagset.key;
		tempElement.name = "memberCert";
		element = tempElement;
		page.document.forms[0].appendChild(element);
	}
	element.value = tagset.value;
}

/**
 * 获取客户端最后生成的固定文件名
 * @return 文件名
 */
function getMemberCardNameString()
{
	if(!isCardImageExistOnClient("A"))
	{
		return "A";
	}
	else if(!isCardImageExistOnClient("B"))
	{
		return "B";
	}
	else if(!isCardImageExistOnClient("C"))
	{
		return "C";
	}
	else if(!isCardImageExistOnClient("D"))
	{
		return "D";
	}
}

/**
 * 判断是否存在对应号码的证件文件
 * @param memberServnum
 * @return bool 是否存在
 */
function isCardImageExistOnClient(memberServnum)
{
	var tabOid4E = getTabOid4E();
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	return fso.FileExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\" + memberServnum + ".jpg");
}

/**
 * 清空原同步成员数据
 * @see synCommitMemberInfoBothClientAndServer
 */
function cleanSynedCommitMember()
{
	var savingPage = getMemberCertSavingPage();
	if (savingPage == undefined)
	{
		return;
	}
    
	var tabOid4E = getTabOid4E();
	
	// 清理jsp
	var memberCertA = savingPage.document.getElementById("memberCert." + tabOid4E + ".A");
	if (memberCertA)
	{
		removeCertElementFromPage(savingPage, memberCertA);
	}		
	
	var memberCertB = savingPage.document.getElementById("memberCert." + tabOid4E + ".B");
	if (memberCertB)
	{
		removeCertElementFromPage(savingPage, memberCertB);
	}	
	
	var memberCertC = savingPage.document.getElementById("memberCert." + tabOid4E + ".C");
	if (memberCertC)
	{
		removeCertElementFromPage(savingPage, memberCertC);
	}	
	
	var memberCertD = savingPage.document.getElementById("memberCert." + tabOid4E + ".D");
	if (memberCertD)
	{
		removeCertElementFromPage(savingPage, memberCertD);
	}	
	
	// 清理本机
    var fso = new ActiveXObject('Scripting.FileSystemObject');
        
	if(fso.FileExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\A.jpg"))
    {
		fso.DeleteFile(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\A.jpg", true); 
    }
	
	if(fso.FileExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\B.jpg"))
    {
		fso.DeleteFile(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\B.jpg", true); 
    }
	
	if(fso.FileExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\C.jpg"))
    {
		fso.DeleteFile(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\C.jpg", true); 
    }
	
	if(fso.FileExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\D.jpg"))
    {
		fso.DeleteFile(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\D.jpg", true); 
    }
}

/**
 * 获取当前标签页
 * @param topWindow 顶层窗口
 */	
function getCurTab(topWindow)
{
	var topObj = topWindow;
	if (!topObj) {
	    topObj = getMemberTopWindow();
	}
	var tabConfig = null;
	var curTabSet = null;
	var sTabCode = null;
	if (topObj && topObj.publicObject) {
	    var mainTab = topObj.publicObject["mainTab"];
	    curTabSet = mainTab;
	    sTabCode = mainTab.sSelectedTabCode;
	    // 存在二级页签
	    if(sTabCode != mainTab.getSubSelectedTabCode())
	    {
	        curTabSet = topObj.publicObject[sTabCode];
	        sTabCode = curTabSet.sSelectedTabCode;
	    }
	    tabConfig = curTabSet.aTabConfigs[sTabCode];
	}
	
	return tabConfig;
}

/**
 * 获取顶级窗口
 */ 
function getMemberTopWindow() {
    var topObj = null;
    if (window.dialogArguments)
    {
        var parentWin = window.dialogArguments;
        if (parentWin.dialogArguments) {
            parentWin = parentWin.dialogArguments;
            if (parentWin.length && parentWin.length > 3) {
                parentWin = parentWin[3];
            }
        }
        topObj = parentWin._ysp_top;
    }
    else if (window.opener && window.opener._ysp_top)
    {
        topObj = window.opener._ysp_top;
    }
    else if (window.parent && window.parent._ysp_top)
    {
        topObj = window.parent._ysp_top;
    }
    else if (_ysp_top)
    {
        topObj = _ysp_top;
    }
    return topObj;
}

/**
 * 处理简单鉴权证件图片
 * 目前仅删除操作，可扩展
 * @param servnumber 服务号码
 */
function dealSimpleAuthCardImage(servnumber)
{
	 var tabOid4E = getTabOid4E();
	 var fso = new ActiveXObject('Scripting.FileSystemObject');
     
	 if(fso.FileExists(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\" + servnumber +".jpg"))
	 {
		fso.DeleteFile(MEMBER_CERT_IMAGE_ON_CLIENT_BASE_PATH + tabOid4E + "\\" + servnumber +".jpg", true); 
	 }
}

/**
* 输出调试信息
* C盘根目录创建文件memberDebug.debug即打开调试，方便客户端定位问题
* @param Line 输出信息
*/
function onClientDebug(Line)
{

}

