/**
 * 该文件集中定义在电子免填单中打印证件用到的函数
 * 电子免填单中带入证件的业务流程如下
 * ------------------------------------------------------------------------------------------------------------------------
 *    ------------
 *    -    鉴    -    证件信息缓存到leftCsp.jsp中，格式：certifications.[kind]card=certType#certNo#custName#base64
 *    -    权    -    证件图片存放在C:\temp\certifications\[kind]card.jpg
 *    ------------    [kind]--证件性质：serv，本人；delegate，代办
 *         ||
 *         ||
 *         ▽
 *    ------------    证件信息缓存到leftCsp.jsp中，格式：certifications.[servNumber].[kind]card=certType#certNo#custName#base64
 *    -    办    -    证件图片存放在C:\temp\certifications\[servNumber]\new[kind]card.jpg
 *    -    理    -    [servNumber]--当前办理业务的号码
 *    ------------
 *         ||
 *         ||
 *         ▽
 *    ------------    将leftCsp.jsp中的证件信息复制为：certifications.[formNumber].[no]=certType#certNo#custName#base64
 *    -    成    -    将本地图片复制到C:\temp\certifications\[formNumber]\[new][kind]card.jpg
 *    -    功    -    [no]--编号：1， 本人鉴权；2， 代办鉴权；3， 本人业务；4， 代办业务
 *    ------------    [new]--是否业务：new，业务办理；无，鉴权
 *         ||         [formNumber]--业务办理流水
 *         ||
 *         ▽
 *    ------------    根据选中的[fromNumber]，从leftCsp.jsp中选出不重复的4个证件，从本地图片取出4个证件中存在的
 *    -    推    -    将以上图片填充到电子免填单中
 *    -    送    -
 *    ------------
 *         ||
 *         ||
 *         ▽
 *    ------------    根据选中的[fromNumber]，从leftCsp.jsp中选出对应的值，将base64保存到电子免填单，其余内容存入数据库
 *    -    保    -
 *    -    存    -
 *    ------------
 *    
 *    
 *    ------------    业务办理成功时，将certifications.[servNumber].[kind]card内容清理
 *    -    清    -      保存电子免填单完成后，根据[formNumber]删除leftCsp.jsp和本地图片的内容
 *    -    理    -     在leftCsp.jsp中设置隐藏值，标识是否读卡，如果未读卡则鉴权后删除certifications.[kind]card和本地图片的全部内容
 *    ------------   
 * ------------------------------------------------------------------------------------------------------------------------
 * @remark create w00187892 2013-05-27 R003C13LG0501 OR_JS_201305_437
*/

var CERT_IMAGE_ON_CLIENT_BASE_PATH = "C:\\temp\\certifications\\";
var CERT_IMAGE_IN_EINVOICE_TAG = "CERTIFICATIONSIMAGES";
var CERT_IMAGE_ON_CLIENT_BASE_FOLDER = "C:\\temp\\certifications";
var REC_NUMBER_WITHOUT_AUTH = "00000000000";

/**
 * 建立证件图片在客户端的存储路径
 * @param isAuth 是否鉴权
 * @param recNumber 办理号码
 * @param kind 证件性质：serv，本人；delegate：代办
 * @return 图片绝对路径
 */
function buildCertImagePathOnClient(isAuth, recNumber, kind, whoseCert)
{
    //鉴权时优先按服务号码创建子目录，为空时暂放到BASE目录
	if (isAuth)
	{
		var authImageFolder = CERT_IMAGE_ON_CLIENT_BASE_PATH;
		if (recNumber != "") {
			authImageFolder = authImageFolder + recNumber + "\\";
		}
	    checkAndCreateFolder(authImageFolder);
		return authImageFolder + kind + "card.jpg";
	}
	
	//非鉴权时使用默认子目录00000000000
	if (recNumber == "")
	{
		recNumber = REC_NUMBER_WITHOUT_AUTH;
	}
	var recImageFolder = CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber + "\\";
    checkAndCreateFolder(recImageFolder);
	return recImageFolder + (whoseCert ? whoseCert : "new") + kind + "card.jpg";
}

/**
 * 构造证件信息在jsp中的缓存对象
 * key certification.[服务号码].[证件性质]
 * value 证件信息
 */
function buildCertString(isAuth, recNumber, certInfo, kind)
{
	var certString = new Object();
	//子目录为空时，直接放到根目录
	if (recNumber == "")
	{
		certString.key = "certifications." + kind + "card";
	}
	else
	{
		certString.key = "certifications." + recNumber + "." + kind + "card";
	}
	certString.value = certInfo;
	return certString;
}

/**
 * 获取保存证件信息的页面
 * 即指 leftCsp.jsp
 */
function getCertificationSavingPage()
{
	var leftJsp;
	
	//本页获取
	if (_ysp_top && _ysp_top.middleFrame && _ysp_top.middleFrame.leftFrame && _ysp_top.middleFrame.leftFrame.cutomerInfo)
	{
		leftJsp = _ysp_top.middleFrame.leftFrame.cutomerInfo;
		return leftJsp;
	}
	
	//iframe获取
	if (window.parent && window.parent._ysp_top && window.parent._ysp_top.middleFrame && window.parent._ysp_top.middleFrame.leftFrame
		&& window.parent._ysp_top.middleFrame.leftFrame.cutomerInfo)
	{
		leftJsp = window.parent._ysp_top.middleFrame.leftFrame.cutomerInfo;
		return leftJsp;
	}
	
	//一般弹出窗口获取
	if (window.opener && window.opener._ysp_top && window.opener._ysp_top.middleFrame && window.opener._ysp_top.middleFrame.leftFrame
		&& window.opener._ysp_top.middleFrame.leftFrame.cutomerInfo)
	{
		leftJsp = window.opener._ysp_top.middleFrame.leftFrame.cutomerInfo;
		return leftJsp;
	}
	
	//模态弹出窗口获取
	if (window.dialogArguments)
    {
        var parentWin = window.dialogArguments;
        if (parentWin.dialogArguments) {
            parentWin = parentWin.dialogArguments;
            if (parentWin.length && parentWin.length > 3) {
                parentWin = parentWin[3];
            }
        }
        
        if (parentWin._ysp_top && parentWin._ysp_top.middleFrame
            && parentWin._ysp_top.middleFrame.leftFrame && parentWin._ysp_top.middleFrame.leftFrame.cutomerInfo)
        {
            leftJsp = parentWin._ysp_top.middleFrame.leftFrame.cutomerInfo;
            return leftJsp;
        }
    }
	
	//异常情况，未获取到
	return leftJsp;
}

/**
 * 获取图片编码
 * @param imagePath 证件图片绝对路径
 */
function getBase64OfImage(imagePath)
{
	var hwUtil = document.getElementById("HWUtilOCX");
	if (hwUtil && imagePath)
	{
		return hwUtil.Base64EncodePath(imagePath);
	}
    return "";
}
	
/**
 * 将键值对附加到指定页面
 * @param page 指定页面
 * @param tagset 键值对：key，键；value，值
 * 如果没有重复的key，则新建；如果有，则覆盖
 */
function appendTagsetToPage(page, tagset)
{
	var element = page.document.getElementById(tagset.key);
	if (!element)
	{
		var tempElement = page.document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = tagset.key;
		tempElement.name = "certifications";
		element = tempElement;
		page.document.forms[0].appendChild(element);
	}
	element.value = tagset.value;
}

/**
 * 从指定页面删除指定元素
 * @param page 指定页面
 * @element page表单中的一个元素
 * @exception 认为删除一定成功
 */
function removeElementFromPage(page, element)
{
	try
	{
		if (element)
		{
			page.document.forms[0].removeChild(element);
		}
	}
	catch(e)
	{
		alert("删除失败");
	}
}

/**
 * 刷新jsp中的证件信息
 * 将读取的证件拷贝到formNumber对应缓存
 * @param servNumber 办理号码
 * @param formNumber 业务流水
 */
function refreshCertificationsInClient(cardsOid, formNumber, topWindow, servNumber)
{
	// 意外情况，使用特殊号码
	if (cardsOid == undefined || cardsOid == null || cardsOid == "")
	{
		cardsOid = REC_NUMBER_WITHOUT_AUTH;
	}
	if (formNumber == undefined || formNumber == null || formNumber == "")
	{
		return;
	}
	var savingPage = undefined;
	if (topWindow) {
	    savingPage = topWindow.middleFrame.leftFrame.cutomerInfo;
	} else {
	    savingPage = getCertificationSavingPage();
	}
	if (savingPage == undefined)
	{
		return;
	}
	var certString = new Object();
	if (isAuthRec(topWindow))
	{
		var pubCertKey = "certifications.";
		var pubCertPath = CERT_IMAGE_ON_CLIENT_BASE_PATH;
		if (servNumber) {
			pubCertKey = pubCertKey + servNumber + ".";
			pubCertPath = pubCertPath + servNumber + "\\";
		}
		var servCard = savingPage.document.getElementById(pubCertKey+"servcard");
		refreshCertificationsByType(savingPage, formNumber, servCard, "1", pubCertPath, "servcard.jpg");
		var delegateCard = savingPage.document.getElementById(pubCertKey+"delegatecard");
		refreshCertificationsByType(savingPage, formNumber, delegateCard, "2", pubCertPath, "delegatecard.jpg");
	}
	var newServCard = savingPage.document.getElementById("certifications." + cardsOid + ".servcard");
	refreshCertificationsByType(savingPage, formNumber, newServCard, "3", CERT_IMAGE_ON_CLIENT_BASE_PATH + cardsOid + "\\", "newservcard.jpg");
	var newDelegateCard = savingPage.document.getElementById("certifications." + cardsOid + ".delegatecard");
	refreshCertificationsByType(savingPage, formNumber, newDelegateCard, "4", CERT_IMAGE_ON_CLIENT_BASE_PATH + cardsOid + "\\", "newdelegatecard.jpg");
	var userServCard = savingPage.document.getElementById("certifications." + cardsOid + ".userservcard");
	refreshCertificationsByType(savingPage, formNumber, userServCard, "5", CERT_IMAGE_ON_CLIENT_BASE_PATH + cardsOid + "\\", "userservcard.jpg");
	var userDelegateCard = savingPage.document.getElementById("certifications." + cardsOid + ".userdelegatecard");
	refreshCertificationsByType(savingPage, formNumber, userDelegateCard, "6", CERT_IMAGE_ON_CLIENT_BASE_PATH + cardsOid + "\\", "userdelegatecard.jpg");
}
function refreshCertificationsByType(savingPage, formNumber, servCard, inx, certPath, imgname)
{
	if (!servCard)
	{
		return;
	}
	var certString = new Object();
	certString.key = "certifications." + formNumber + "." + inx;
	certString.value = servCard.value;
	appendTagsetToPage(savingPage, certString);
	copyImage(certPath, CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber + "\\", imgname);
}

/**
 * 复制图片
 * 从源路径将指定名称图片复制到目标路径
 * @warnning 本函数只在此业务中使用有效，假定前提CERT_IMAGE_ON_CLIENT_BASE_PATH一定存在
 */
function copyImage(fromPath, toPath, fileName)
{
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (!fso.FolderExists(fromPath) || !fso.FileExists(fromPath + fileName))
    {
        return;
    }
    checkAndCreateFolder(toPath);
    fso.CopyFile(fromPath + fileName, toPath + fileName, true);
}

/**
 * 获取流水号对应的证件图片信息
 * 鉴权证件直接取对应标识
 * 业务证件取与鉴权证件不同的证件（按照循环，应该是取最后两个不同的）
 * @param 业务流水号数组
 * @return certImages对象，包含四种性质的证件；每种证件都是certImage对象，包含path和hash属性；
 *         path属性是指图片在本地存储路径（不一定存在）；hash是一个由certType#certNo#custName组成的识别串
 */
function getCertificationFromClient(formNumbers, leftCsp)
{
	if (formNumbers == undefined || formNumbers == null || formNumbers.length <= 0)
	{
		return null;
	}
	
	var certImage = new Object();
	certImage.hash = "";
	certImage.path = "";
	var certImages = new Object();
	certImages.serv = certImage;
	certImages.delegate = certImage;
	certImages.newserv = certImage;
	certImages.newdelegate = certImage;
	certImages.userserv = certImage;
	certImages.userdelegate = certImage;

	//获取保存页面
	var savingPage = leftCsp;
	if (!leftCsp) {
	    savingPage = getCertificationSavingPage();
	}
	if (savingPage == undefined)
	{
		//alert("获取不到保存证件信息的页面，此前读取的证件将不能合并到电子免填单中。");
		return certImages;
	}
	var tempCertImage = null;
	for (var i = 0; i < formNumbers.length; i++)
	{
		if (formNumbers[i] == "")
		{
			continue;
		}
		certImages.serv = getCertificationByType(savingPage, formNumbers[i], "1", "servcard.jpg", certImages, certImages.serv);
		certImages.delegate = getCertificationByType(savingPage, formNumbers[i], "2", "delegatecard.jpg", certImages, certImages.delegate);
		certImages.newserv = getCertificationByType(savingPage, formNumbers[i], "3", "newservcard.jpg", certImages, certImages.newserv, true);
		certImages.newdelegate = getCertificationByType(savingPage, formNumbers[i], "4", "newdelegatecard.jpg", certImages, certImages.newdelegate, true);
		certImages.userserv = getCertificationByType(savingPage, formNumbers[i], "5", "userservcard.jpg", certImages, certImages.userserv, true);
		certImages.userdelegate = getCertificationByType(savingPage, formNumbers[i], "6", "userdelegatecard.jpg", certImages, certImages.userdelegate, true);
	}
	
	return certImages;
}
function getCertificationByType(savingPage, formNumber, inx, imgName, certImages, certImage, chkSame)
{
	var eserv = savingPage.document.getElementById("certifications." + formNumber + "." + inx);
	if (!eserv)
	{
		return certImage;
	}
	if (certImage.hash == eserv.value)
	{
		return certImage;
	}
	if (chkSame && !(eserv.value && eserv.value.indexOf("Other")==0))
	{
		for (var i in certImages)
		{
			if (certImages[i].hash == eserv.value)
			{
				return certImage;
			}
		}
	}
	var tempCertImage = new Object();
	tempCertImage.hash = eserv.value;
	tempCertImage.path = CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber + "\\" + imgName;
	return tempCertImage;
}

/**
 * 构建图片在电子免填单推送中的报文
 * @param filePath 图片绝对路径
 * @param tagName 在PDF中的域标识
 */
function buildCertImageXmlForEinvoice(filePath, tagName)
{
    if (filePath == undefined || filePath == null || filePath == "")
	{
		return "";
	}
	var fso = new ActiveXObject('Scripting.FileSystemObject');
 	if (!fso.FileExists(filePath))
 	{
    	return "";
 	}
 	var xmlStr = "";
 	xmlStr += "<content>\n";
 	xmlStr += "<key>" + tagName + "</key>\n";
 	xmlStr += "<value type=\"image\"><![CDATA["+ filePath + "]]></value>\n";
 	xmlStr += "</content>\n";
 	return xmlStr;
}

/**
 * 向电子免填单推送报文中附加证件图片信息
 * @param noImageXml不带图片的报文
 * @images 图片，包含四种性质的证件；每种证件都是certImage对象，包含path和hash属性；
 *         path属性是指图片在本地存储路径（不一定存在）；hash是一个由certType#certNo#custName组成的识别串
 */
function appendCertImageToEinvoice(noImageXml, images)
{
	if (images == null)
	{
		return noImageXml.replace(CERT_IMAGE_IN_EINVOICE_TAG, "");
	}
	var imageXml = buildCertImageXmlForEinvoice(images.serv.path, "servCardBase64Str")
		+ buildCertImageXmlForEinvoice(images.delegate.path, "delegateCardBase64Str")
		+ buildCertImageXmlForEinvoice(images.newserv.path, "newServCardBase64Str")
		+ buildCertImageXmlForEinvoice(images.newdelegate.path, "newDelegateCardBase64Str")
		+ buildCertImageXmlForEinvoice(images.userserv.path, "userServCardBase64Str")
		+ buildCertImageXmlForEinvoice(images.userdelegate.path, "userDelegateCardBase64Str");
	return noImageXml.replace(CERT_IMAGE_IN_EINVOICE_TAG, imageXml);
}

/**
 * 鉴权时清空证件
 * 清空标识为leftCsp.jsp中certifications.[kind]flag是否存在，存在表示不清空；默认清空
 * 首先清理leftCsp.jsp中certifications.[kind]card的隐藏域
 * 然后清理本地CERT_IMAGE_ON_CLIENT_BASE_PATH + [kind]card.jpg文件
 * @warnning 在用户切换完成后调用，存在顺序耦合
 */
function clearAuthCertifications(recNumber, forceFlag)
{
	var savingPage = getCertificationSavingPage();
	if (savingPage == undefined)
	{
		return;
	}
	clearKindCertifications(savingPage, "serv", recNumber, forceFlag);
	clearKindCertifications(savingPage, "delegate", recNumber, forceFlag);
}

/**
 * 关闭系统清空证件
 * 清理本地CERT_IMAGE_ON_CLIENT_BASE_PATH + [kind]card.jpg文件
 */
function clearAllImagesInClient()
{
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (fso.FolderExists(CERT_IMAGE_ON_CLIENT_BASE_FOLDER))
    {
        fso.DeleteFolder(CERT_IMAGE_ON_CLIENT_BASE_FOLDER, true);
    }
}

function clearKindCertifications(savingPage, kind, recNumber, forceFlag)
{
	var flag = savingPage.document.getElementById("certifications." + kind + "flag");
	if (flag)
	{
		removeElementFromPage(savingPage, flag);
		//如果强制删除鉴权证件信息则不退出
		if (!forceFlag) {
			return false;
		}
	}
	
	//删除根目录下的鉴权信息
	var card = savingPage.document.getElementById("certifications." + kind + "card");
	if (card)
	{
		removeElementFromPage(savingPage, card);
	}
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (fso.FileExists(CERT_IMAGE_ON_CLIENT_BASE_PATH + kind + "card.jpg"))
    {
        fso.DeleteFile(CERT_IMAGE_ON_CLIENT_BASE_PATH + kind + "card.jpg", true);
    }
	//删除服务号码下的鉴权信息
	if (recNumber) {
		card = savingPage.document.getElementById("certifications." + recNumber + "." + kind + "card");
		if (card) {
			removeElementFromPage(savingPage, card);
		}
		if (fso.FileExists(CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber + "\\" + kind + "card.jpg"))
	    {
	        fso.DeleteFile(CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber + "\\" + kind + "card.jpg", true);
	    }
	}
	
    return true;
}
function setCannotClear(savingPage, kind)
{
	var flag = savingPage.document.getElementById("certifications." + kind + "flag");
	if (flag)
	{
		return;
	}
	var flagStr = new Object();
	flagStr.key = "certifications." + kind + "flag";
	flagStr.value = "true";
	appendTagsetToPage(savingPage, flagStr);
}

/**
 * 清理业务办理过程中的证件
 * 首先清理leftCsp.jsp中certifications.[recNumber]开头的隐藏域
 * 其次清理本机CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber路径
 * @warnning 在业务提交完成后调用，存在顺序耦合
 */
function clearUserCertifications(recNumber)
{
	var savingPage = getCertificationSavingPage();
	if (savingPage == undefined)
	{
		return;
	}
    // 意外情况，使用默认号码
	if (recNumber == undefined || recNumber == null || recNumber == "")
	{
		recNumber = REC_NUMBER_WITHOUT_AUTH;
	}
	// 清理jsp
	removeElementFromPage(savingPage, savingPage.document.getElementById("certifications." + recNumber + ".servcard"));
	removeElementFromPage(savingPage, savingPage.document.getElementById("certifications." + recNumber + ".delegatecard"));
	removeElementFromPage(savingPage, savingPage.document.getElementById("certifications." + recNumber + ".userservcard"));
	removeElementFromPage(savingPage, savingPage.document.getElementById("certifications." + recNumber + ".userdelegatecard"));
	
	// 清理本机
    var fso = new ActiveXObject('Scripting.FileSystemObject');
	if (fso.FolderExists(CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber))
    {
        fso.DeleteFolder(CERT_IMAGE_ON_CLIENT_BASE_PATH + recNumber, true);
    }
}

/**
 * 清理已经打印免填单业务的证件
 * 首先清理leftCsp.jsp中certifications.[formNumber]开头的隐藏域
 * 然后清理本机CERT_IMAGE_ON_CLIENT_BASE_PATH + formNumber路径
 * @warnning 在电子免填单打印完成后调用，存在顺序耦合
 */
function clearRecCertifications(formNumbers)
{
	//暂不清理
	return true;
}

/**
 * 构建本次图片存取唯一标识
 */
function createCardsOid(date)
{
	var currentTab = getCurrentTab();
	// 获取不到当前tab时返回空串
	if (null == currentTab)
	{
		return "";
	}
	
	if (currentTab.oid4EI == undefined || currentTab.oid4EI == "")
	{
		currentTab.oid4EI = date;
	}
	return currentTab.oid4EI;
}

/**
 * 获取本次图片存取唯一标识
 */	
function getCardsOid(topWindow)
{
	var currentTab = getCurrentTab(topWindow);
	if (currentTab && currentTab.oid4EI)
	{
		return currentTab.oid4EI;
	}
	return "";
}
/**
 * 获取顶级窗口
 */ 
function getTopWindow() {
    var topObj = null;
    if (window.dialogArguments)
    {
        var parentWin = window.dialogArguments;
        if (parentWin.dialogArguments) {
            parentWin = parentWin.dialogArguments;
            if (parentWin.length && parentWin.length > 3) {
                parentWin = parentWin[3];
            }
        }
        topObj = parentWin._ysp_top;
    }
    else if (window.opener && window.opener._ysp_top)
    {
        topObj = window.opener._ysp_top;
    }
    else if (window.parent && window.parent._ysp_top)
    {
        topObj = window.parent._ysp_top;
    }
    else if (_ysp_top)
    {
        topObj = _ysp_top;
    }
    return topObj;
}
/**
 * 获取当前标签页
 */	
function getCurrentTab(topWindow)
{
	var topObj = topWindow;
	if (!topObj) {
	    topObj = getTopWindow();
	}
	var tabConfig = null;
	var curTabSet = null;
	var sTabCode = null;
	if (topObj && topObj.publicObject) {
	    var mainTab = topObj.publicObject["mainTab"];
	    curTabSet = mainTab;
	    sTabCode = mainTab.sSelectedTabCode;
	    // 存在二级页签
	    if(sTabCode != mainTab.getSubSelectedTabCode())
	    {
	        curTabSet = topObj.publicObject[sTabCode];
	        sTabCode = curTabSet.sSelectedTabCode;
	    }
	    tabConfig = curTabSet.aTabConfigs[sTabCode];
	}
	
	return tabConfig;
}
/**
 * 判断是否登录办理业务
 */ 
function isAuthRec(topWindow)
{
	var topObj = topWindow;
    if (!topObj) {
        topObj = getTopWindow();
    }
	var mainTab = topObj.publicObject["mainTab"];
	var selTabCode = mainTab.sSelectedTabCode;
    // 存在二级页签
	if(selTabCode != mainTab.getSubSelectedTabCode())
	{
		return true;
	}
	return false;
}

/**
 * 检查并创建目录
 * 保证目录格式正确
 */
function checkAndCreateFolder(path)
{
	var paths = path.split("\\");
	if (paths.length < 1)
	{
		return "";
	}
	path = paths[0] + "\\";
	var fso = new ActiveXObject('Scripting.FileSystemObject');
	for (var i = 1; i < paths.length; i ++)
	{
		if (paths[i] == "")
		{
			continue;
		}
		path += paths[i] + "\\";
		if (!fso.FolderExists(path))
	    {
	    	fso.CreateFolder(path);
	    }
	}
	return path;
}
/**
 * 创建服务号码和流水关系
 * 放入leftcsp中的隐藏域中，供关闭用户时清除图片
 */
function createTelFormnumsRelation(telNum,formnum,topWindow)
{
    var savingPage = undefined;
    if (topWindow) {
        savingPage = topWindow.middleFrame.leftFrame.cutomerInfo;
    } else {
        savingPage = getCertificationSavingPage();
    }
    if (savingPage == undefined)
    {
        return;
    }
    if (!telNum || telNum == "")
    {
        return;
    }
    if (!formnum || formnum == "")
    {
        return;
    }
    var formnums = savingPage.document.getElementById(telNum);
    if (formnums)
    {
        formnums.value = formnums.value + ";" +formnum;
        return;
    }
    
    var tempElement = savingPage.document.createElement("input");
    tempElement.type = "hidden";
    tempElement.id = telNum;
    tempElement.name = telNum;
    tempElement.value = formnum;
    savingPage.document.forms[0].appendChild(tempElement);
}
