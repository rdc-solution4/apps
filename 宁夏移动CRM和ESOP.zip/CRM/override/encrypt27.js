// RSA默认模量，对于一个密钥对，公钥和私钥的模量一致
var static_rsa_modulus = "00B2984A6FCF8BD7D12E9DD6F863502E175A898DBCC8331F47C1B9202EC1980C7C756B2774325CE49C1F084ECD28F660A717A2CE7EEE1948F83A24F28C5297416CAAB6BA2CE803018501354E55D4C783424F82A332EA7E0FE1719E4FBB51ED90627610259927AEAA0292A2BF26AFEF8CFD74443771C7263A80B49785D8B557367D";
// 公钥指数，对于RSA算法，公钥指数固定
var static_publicExponent = "010001";

function init4RSAEncrypt() {
    // 一个1024位密钥将需要1024 * 2 / 16 = 128位数的存储。
    setMaxDigits(130);
}

function encryptWithRSA(text) {
    debugger;
    // 空字符串不做任何处理
    if (text == null || text == undefined) {
        return;
    }

    // HTTPS协议不进行任何加密操作
    if (window.location.protocol.toLocaleLowerCase() == "https:") {
        return "[unencrypted]" + text;
    }

    // HTTP协议进行RSA加密
    // 生成公钥
    var pubKey = new RSAKeyPair(static_publicExponent, '', static_rsa_modulus);
    // 对明文进行编码然后进行加密
    var str = encryptedString(pubKey, encodeURIComponent(text));
    return "[encrypted]" + str;

}


function encryptWithRSAThird(text,rsa_modulus) {
    //提供给第三方平台加密使用，使用系统参数配置的公钥模量
    // 空字符串不做任何处理
    if (text == null || text == undefined) {
        return;
    }

    // HTTPS协议不进行任何加密操作
    if (window.location.protocol.toLocaleLowerCase() == "https:") {
        return text;
    }

    try {
        // 系统参数,当前使用AD的系统参数获取方法
        //DTS:	DTS2016110108028
        //time:2017/1/16
        //这个JS以后要迁移到定制代码
        if ("" == rsa_modulus || null == rsa_modulus) {
			rsa_modulus = static_rsa_modulus;
		}
          
		var pubKey = new RSAKeyPair(static_publicExponent, '', rsa_modulus);
		// 对明文进行编码然后进行加密
		var str = encryptedString(pubKey, encodeURIComponent(text));
		return str;
    } catch (e) {
        //若加密失败直接抛出；异常
         throw new Error("Encrypt ERROR!");
    }
}

// $(function() {....}) 是 jQuery 中的经典用法，等同于 $(document).ready(function()
// {....})，即在页面加载完成后才执行某个函数，如果函数中要操作 DOM，在页面加载完成后再执行会更安全
$(function() {
    init4RSAEncrypt();
});