$(function() {
	debugger;
	var $scope = $(document).scope();
	
	/**
	 * 比较日期大小
	 * nDateTime1 时间戳
	 * nDateTime2 时间戳
	 */
	$scope.comptimeDate = function(nDateTime1, nDateTime2) {
		if(!nDateTime1 || !nDateTime2) {
			return 1;
		}
		var date1 = new Date(nDateTime1);
		var date2 = new Date(nDateTime2);
		date1.setHours(0);
		date1.setMinutes(0);
		date1.setSeconds(0);
		date1.setMilliseconds(0);
		date2.setHours(0);
		date2.setMinutes(0);
		date2.setSeconds(0);
		date2.setMilliseconds(0);
		return date1.getTime() - date2.getTime();
	};
});

$Controller("bes.ad.family.offer2order", {
	transFamilyOrderItem : function(offering) {
		debugger;
		return this.transOrderItemO(offering, offering.members, offering.memberAuth,offering.wangpuAddr);
	},
	
	transOrderItemO : function(offering, members, memberAuth,wangpuAddr) {
		var actionType = this.transActionType(offering.opCode);
		var orderItem = {};
		//组装ordetItem
        orderItem.actionType = actionType;
        orderItem.itemId = offering.offeringId;
        orderItem.itemName = offering.offeringName;
        orderItem.relaOrderItemId = offering.refRelaItemId;
        orderItem.itemType = "O";
        orderItem.effectiveDate = offering.effDate;
        orderItem.expiryDate = offering.expDate;

        var orderItemInfoList = [];
        orderItem.orderItemInfo = orderItemInfoList;
        
        this.setOrderItemTerm(orderItem, offering, actionType);
        
        //如果当前商品是一个包，需要继续组装报文
        if (offering.isBundled)
        {
            var subOfferings = offering.subOfferings || [];
            for (var i=0; i<subOfferings.length; i++)
            {
                var orderIntmInfo = this.transOrderItemO(subOfferings[i], members, memberAuth,wangpuAddr);
                orderItemInfoList.push(orderIntmInfo);
            }
        }
        else
        {
            // 当前不是bundle，下面挂一个P
        	var products = offering.product || [];
        	if(products.length > 0) {
        		var orderIntmInfo = this.transOrderItemP(offering.refRelaItemId, products[0], members, memberAuth);
                orderItemInfoList.push(orderIntmInfo);
        	}
        	//旺铺offer product在ocProductInfoVA 节点
        	var wangpuProd = $(document).scope().isWangPuProd(offering);
        	if(wangpuProd){
        		var productInfoVA = offering.ocProductInfoVA || [];
        		if(productInfoVA.length > 0){
        			var orderIntmInfo = this.transWPOrderItemP(offering.refRelaItemId, productInfoVA[0], members, memberAuth);
        			//在P节点组装地址信息
        			if(wangpuAddr){
        				orderIntmInfo.itemAddrInfo = [];
        				orderIntmInfo.itemAddrInfo.push(wangpuAddr);
        			}
        			orderItemInfoList.push(orderIntmInfo);
        		}
        	}
        }

        return orderItem;
	},
	
	setOrderItemTerm : function(orderItem, offering, actionType) {
		// 生效方式
		if (offering.ocEffectiveMode && offering.ocEffectiveMode.selectedMode){
			orderItem.orderItemTerm = orderItem.orderItemTerm || [];
			offering.ocEffectiveMode.durationUnit = offering.ocEffectiveMode.durationUnit || {};
			
			var selectedType = {};
			$.each(offering.ocEffectiveMode.effectiveTypes||[], function(i, vali){
				if (vali.selected){
					selectedType = vali;
				}
			});
			// 拼om报文时将次日转成特定周期
			var selectedMode = offering.ocEffectiveMode.selectedMode;
			if(selectedMode == "ND") {
				selectedMode = "S";
			}
			orderItem.orderItemTerm.push({
				actionType: actionType,
				termCode: "effectiveMode",
				termContent: JSON.stringify({
					mode: selectedMode,
					durationUnit: offering.ocEffectiveMode.durationUnit.key || "",
					durationValue: offering.ocEffectiveMode.durationValue || 0,
					fixStartDate: offering.ocEffectiveMode.fixStartDate || "",
					primaryOfferingId: selectedType.primaryOfferingId,
					businessCode: selectedType.businessCode,
					isDefault: "Y"
				})
			});
			
			if (offering.ocEffectiveMode.selectedMode == "C") {
				orderItem.effectiveDate = offering.ocEffectiveMode.effectiveDate;
			}
		}
		
		// 失效方式
		if (offering.ocExpireMode && offering.ocExpireMode.selectedMode){
			orderItem.orderItemTerm = orderItem.orderItemTerm || [];
			offering.ocExpireMode.durationUnit = offering.ocExpireMode.durationUnit || {};
			// 拼om报文时将次日转成特定周期
			var selectedMode = offering.ocExpireMode.selectedMode;
			if(selectedMode == "ND") {
				selectedMode = "S";
			}
			orderItem.orderItemTerm.push({
				actionType: actionType,
				termCode: "expireMode",
				termContent: JSON.stringify({
					mode: selectedMode,
					durationUnit: offering.ocExpireMode.durationUnit.key || "",
					durationValue: offering.ocExpireMode.durationValue || 0,
					fixEndDate: offering.ocExpireMode.fixEndDate || "",
					isDefault: "Y"
				})
			});
			
			if (offering.ocExpireMode.selectedMode == "C") {
				orderItem.expiryDate = offering.ocExpireMode.expireDate;
			}
		}
	},
	
	transOrderItemP : function(refRelaItemId, product, members, memberAuth) {
		var orderItemInfo = {};

        orderItemInfo.quantity = 1;
        orderItemInfo.actionType = this.transActionType(product.opCode);
		orderItemInfo.itemId = product.prodId;
		orderItemInfo.itemName = product.prodName;
        orderItemInfo.itemType = "P";
		orderItemInfo.relaOrderItemId = product.refRelaItemId;
		
		if(memberAuth) {
			orderItemInfo.extInfo = {
				extNodeInfo : []
			}
			var memberAuthExtStr = JSON.stringify(memberAuth.authExtInfo);
			orderItemInfo.extInfo.extNodeInfo[0] = {
				"extNodeCode" : "MEMBER_AUTH_INFO",
				"extXmlString" : memberAuthExtStr
			};
		}

        //OrderItemRelation
        var orderItemRelationList = [];
        var orderItemRelation = {};
        orderItemRelation.relationType = "P_O";
		orderItemRelation.refRelaOrderItemId = refRelaItemId;
		orderItemRelationList.push(orderItemRelation);
        //orderItemInfo.orderItemRelation = orderItemRelationList;

        // 设置成员
        if(!jQuery.isEmptyObject(members)) {
        	var orderItemMembers = this.transOrderMemberItem(members);
            orderItemInfo.orderItemMember = orderItemMembers;
        }

        return orderItemInfo;
	},
	
	//旺铺
	transWPOrderItemP : function(refRelaItemId, product, members, memberAuth) {
		var orderItemInfo = {};

        orderItemInfo.quantity = 1;
        orderItemInfo.actionType = this.transActionType(product.opCode);
        if(!orderItemInfo.actionType){
        	orderItemInfo.actionType = 'A';
        }
		orderItemInfo.itemId = product.productId;
		orderItemInfo.itemName = product.productName;
        orderItemInfo.itemType = "P";
		orderItemInfo.relaOrderItemId = adutil.getNextNumber();
		
		if(memberAuth) {
			orderItemInfo.extInfo = {
				extNodeInfo : []
			}
			var memberAuthExtStr = JSON.stringify(memberAuth.authExtInfo);
			orderItemInfo.extInfo.extNodeInfo[0] = {
				"extNodeCode" : "MEMBER_AUTH_INFO",
				"extXmlString" : memberAuthExtStr
			};
		}

        //OrderItemRelation
        var orderItemRelationList = [];
        var orderItemRelation = {};
        orderItemRelation.relationType = "P_O";
		orderItemRelation.refRelaOrderItemId = refRelaItemId;
		orderItemRelationList.push(orderItemRelation);
        //orderItemInfo.orderItemRelation = orderItemRelationList;

        // 设置成员
        if(!jQuery.isEmptyObject(members)) {
        	var orderItemMembers = this.transOrderMemberItem(members);
            orderItemInfo.orderItemMember = orderItemMembers;
        }
        
        return orderItemInfo;
	},
	
	transOrderMemberItem : function(members) {
		var orderItemMembers = [];
		for (var i=0; i<members.length; i++)
        {
			var member = members[i];
            var orderItemMember = {};
            orderItemMember.actionType = member.actionType;
            orderItemMember.confirmType = member.confirmType;
            orderItemMember.doubleConfirm = member.doubleConfirm ? "1" : "0";
            orderItemMember.effDate = member.effDate;
            orderItemMember.effMode = member.effMode;
            orderItemMember.expDate = member.expDate;
            orderItemMember.groupOrderItemId = ""; 
            orderItemMember.groupSubsId = member.groupSubsId;
            orderItemMember.isHousehold = member.isHousehold;
            orderItemMember.memberBeId = member.memberBeId;
            orderItemMember.memberId = member.memberId;
            orderItemMember.memberType = member.memberType.value;
            orderItemMember.shortNo = member.shortNo;
            orderItemMember.subsId = member.subsId;
            orderItemMember.memberServiceNubmer = member.serviceNumber;
            // 设置成员属性
            if(!jQuery.isEmptyObject(member.attributes)) {
            	var orderItemMemberProps = this.transOrderMemberProp(member.attributes, member.actionType);
                orderItemMember.orderItemMemberProp = orderItemMemberProps;
            }

            orderItemMembers.push(orderItemMember);
        }
        return orderItemMembers;
	},
	
	transOrderMemberProp : function(attributes, actionType) {
		var orderItemMemberProps = [];
		for (var i=0; i<attributes.length; i++)
        {
			var attribute = attributes[i];
            var orderItemMemberProp = {};
            orderItemMemberProp.complexFlag = attribute.complex ? "Y" : "N";
            orderItemMemberProp.actionType = actionType;
            orderItemMemberProp.propCode = attribute.attrCode;
            orderItemMemberProp.propId = attribute.attrId;
            orderItemMemberProp.propValueNew = attribute.newValue;
            orderItemMemberProp.propValueOld = attribute.oldValue;
            orderItemMemberProp.propInstId = attribute.attrInstId;

            orderItemMemberProps.push(orderItemMemberProp);
        }
        return orderItemMemberProps;
	},
	
	transActionType : function(opCode) {
		//定义操作码
        var temp = null;
        if ("1" == opCode) {
        	temp = "A";
        }
        else if ("2" == opCode){
        	temp = "M";
        }
        else if ("3" == opCode) {
        	temp = "D";
        }
        else if ("4" == opCode) {
        	temp = "K";
        }
        return temp;
	}
});


$Controller("bes.ad.family.common", {
	getTabIndex : function(prodType) {
		var tabIndexDict = {
			"JTW" : "0",
			"JTVW" : "1",
			"QQZH" : "2"
		};
		return tabIndexDict[prodType];
	},
	
	// 匿名化处理
	anonymousStr : function(str,type) {
		if(!str) {
			return "";
		}
		if("mobile" == type) {
			return str;
			/*if(str.length < 3) {
				return str;
			}
			else if(str.length >3 && str.length < 7) {
				var a = str.substring(0, 3);
				var b = str.substring(3, str.length);
				b = b.replace(/./g,'*');
				return a + b;
			}
			else {
				var a = str.substring(0, 3);
				var b = str.substring(3, 7);
				b = b.replace(/./g,'*');
				var c = str.substring(7, str.length);
				return a + b + c;
			}*/
		} else {
			if(str.length < 2) {
				return str;
			}
			var a = str.substring(0, 1);
			var b = str.substring(1, str.length);
			b = b.replace(/./g,'*');
			return a + b;
		}
	},
	
	/**
	 * 生失效时间,mode为1，次日生效，mode为2，次月生效
	 */
	getModeTime : function(mode){
		var tempDate = new Date();
		tempDate.setHours(0);
		tempDate.setMinutes(0);
		tempDate.setSeconds(0);
		tempDate.setMilliseconds(0);

		if(mode == 1) {	 
			tempDate.setDate(tempDate.getDate() + 1);
		} else if(mode == 2) {
			tempDate.setDate(1);
			tempDate.setMonth(tempDate.getMonth() + 1);
		} else if(mode == 0) {
			tempDate = new Date();
		}
		var tempTime = tempDate.getTime();
		return tempTime
	},
	
	// 订单校验结果处理
	checkBusiValid : function($scope, $UI, busiValidResp, dialogTitle, succFunc, errFunc, isNotShowDialog){
		debugger;
		var succCb=null;
		var errCb=null;
		var fontList=["<font color='blue'>","<font color='blue'>","<font color='blue'>","<font color='red'>"];

		if($scope){
			if(succFunc){
				succCb=function(){         
					$scope.$apply(succFunc());
				};
			}
			if(errFunc){
				errCb=function(){         
					$scope.$apply(errFunc());
				};
			}
		}else{
			succCb=succFunc;
			errCb=errFunc;
		}
		
		if (!busiValidResp) {
			$UI.msgbox.error("业务校验失败", "无响应报文。", errCb);
			return;
		}
		
		dialogTitle=dialogTitle||"提示";
		var messageCount=0;
		var errorCount=0;
		var message=null;
		
		busiValidResp.busiValidResults = busiValidResp.busiValidResults || busiValidResp.busiValidateResult || [];
		for ( var i = 0; i < busiValidResp.busiValidResults.length; i++) {
			var validResp = busiValidResp.busiValidResults[i];
			var promptMessage = validResp.promptMessage;
			if(promptMessage) {
				if(validResp.level==1){
					// 提示信息
					if(messageCount==0){
						message=fontList[validResp.level]+promptMessage+"</font>";
					}else{
						message=message+"<br>"+fontList[validResp.level]+promptMessage+"</font>";
					}
					messageCount++;
				} else {
					errorCount++;
				}
			}
		}

		if("0" != busiValidResp.retCode){  // 出现error级别错误时的弹出框
			if(messageCount ==0 || errorCount > 0) {
				message = message || busiValidResp.retMessage||"校验失败，无校验提示报文。";
				$UI.msgbox.info(dialogTitle, message, errCb);
			} else {
				$UI.msgbox.confirm(dialogTitle, message, succCb, errCb);
			}
		}else{  
			if (messageCount>0 && !isNotShowDialog) {  // 出现info跟warning校验时的info弹出框
				$UI.msgbox.confirm(dialogTitle, message, succCb, errCb);
			} else {
				// 不出现弹出框，返回true
				if (typeof succCb === 'function') {
					succCb();
				} 
			}
		}
	},
	/**
	 * 定义业务编码对象 
	 * 适用于家庭改造业务
	 * 群网类型：PTFamilyGroup 家庭群网 
	 * 业务类型：海外家庭主offer开通 familyInstall 海外家庭主offer成员管理 familyMemberMgr
	 * 业务类型：海外家庭主offer注销 familyDropSubs 添加和变更成员校验 familyMemberVali 海外家庭offer变更 familyChangeProduct
	 * 
	 * @author c00294059
	 */
	getBusinessTypeMap : function() {
		// 业务编码定义对象
		var businessTypeMap = {
			PTFamilyGroup : {
				familyInstall : {
					validate : {
						"businessType" : "FamilyManage",
						"seniorId" : "FamilyInstall",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "FamilyInstall",
						"operationType" : "A",
						"ownerType" : "G",
					}
				},
				familyMemberMgr : {
					validate : {
						"businessType" : "FamilyManage",
						"seniorId" : "FamilyMemberMgr",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "FamilyMemberMgr",
						"operationType" : "M",
						"ownerType" : "S"
					}
				},
				familyDropSubs : {
					validate : {
						"businessType" : "FamilyCancel",
						"seniorId" : "FamilyDropSubs",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "FamilyDropSubs",
						"operationType" : "D",
						"ownerType" : "G",
					}
				},
				familyMemberVali : {
					add : {
						"seniorId" : "FAMILYMGR",
						"eventId" : "OFFER_CHG_FORBID",
						"busiCode" : "FamilyInstall"
					},
					modify : {
						"seniorId" : "FAMILYMGR",
						"eventId" : "OFFER_CHG_FORBID",
						"busiCode" : "FamilyMemberMgr"
					}
				},
				familyChangeProduct : {
					validate : {
						"businessType" : "FamilyManage",
						"seniorId" : "FamilyChangeProduct",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "FamilyChangeProduct",
						"operationType" : "M",
						"ownerType" : "S"
					}
				},
				familyChgMainMem : {
					validate : {
						"businessType" : "FamilyManage",
						"seniorId" : "FamilyChgMainMem",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "FamilyChgMainMem",
						"operationType" : "M",
						"ownerType" : "G"
					}
				},
				familyChgBasicInfo : {
					validate : {
						"businessType" : "FamilyManage",
						"seniorId" : "FamilyChangeBasicInfo",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "FamilyChangeBasicInfo",
						"operationType" : "M",
						"ownerType" : "G"
					}
				}
			},
			WPMP :
				{
					familyChangeProduct : 
					{
						validate:
						{
						"businessType" : "FamilyManage",
						"seniorId" : "CreateVHome",
						"eventId" : "BeforeCreateOrder",
						"busiCode" : "ChangeProduct",
						"businessCode" : "ChangeProduct",
						"operationType" : "M"
						}
					},
					manageProperousStore :
					{
						validate:
						{
							"businessType" : "FamilyManage",
							"seniorId" : "VHomeManageMember",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "VHomeManageMember",
							"businessCode" : "VHomeManageMember",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					changeProperousStore :
					{
						validate:
						{
							"businessType" : "FamilyManage",
							"seniorId" : "VHomeManageMember",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "VHomeManageMember",
							"businessCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					cancalProperousStore :
					{
						validate:
						{
							"businessType" : "FamilyCancel",
							"seniorId" : "DeleteVHome",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeProduct",
							"businessCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					}
				},
				GrpPrdHome4GShare : {
					familyInstall : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyInstall",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyInstall",
							"operationType" : "A",
							"ownerType" : "G",
						}
					},
					familyMemberMgr : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyMemberMgr",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyDropSubs : {
						validate : {
							"businessType" : "FamilyCancel",
							"seniorId" : "FamilyDropSubs",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyDropSubs",
							"operationType" : "D",
							"ownerType" : "G",
						}
					},
					familyMemberVali : {
						add : {
							"seniorId" : "FAMILYMGR",
							"eventId" : "OFFER_CHG_FORBID",
							"busiCode" : "FamilyInstall"
						},
						modify : {
							"seniorId" : "FAMILYMGR",
							"eventId" : "OFFER_CHG_FORBID",
							"busiCode" : "FamilyMemberMgr"
						}
					},
					familyChangeProduct : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeProduct",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyChgMainMem : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChgMainMem",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChgMainMem",
							"operationType" : "M",
							"ownerType" : "G"
						}
					},
					familyChgBasicInfo : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeBasicInfo",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeBasicInfo",
							"operationType" : "M",
							"ownerType" : "G"
						}
					}
				},
				FMC : {
					familyInstall : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyFuseInstall",
							"eventId" : "OldEnter",
							"busiCode" : "FamilyFuseInstall",
							"operationType" : "A",
							"ownerType" : "G",
						}
					},
					familyMemberMgr : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyFuseMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyFuseMemberMgr",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyDropSubs : {
						validate : {
							"businessType" : "FamilyCancel",
							"seniorId" : "FamilyFuseDropSubs",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyFuseDropSubs",
							"operationType" : "D",
							"ownerType" : "G",
						}
					},
					familyMemberVali : {
						add : {
							"seniorId" : "FamilyFuseMemberMgr",
							"eventId" : "MemberEnter",
							"busiCode" : "FamilyFuseMemberMgr"
						},
						modify : {
							"seniorId" : "FamilyFuseMemberMgr",
							"eventId" : "MemberEnter",
							"busiCode" : "FamilyFuseMemberMgr"
						}
					},
					oneStopFamilyMemberVali : {
						add : {
							"seniorId" : "FamilyFuseInstall",
							"eventId" : "OldMemberEnter",
							"busiCode" : "FamilyInstall"
						},
						modify : {
							"seniorId" : "FamilyFuseMemberMgr",
							"eventId" : "MemberEnter",
							"busiCode" : "FamilyFuseMemberMgr"
						}
					},
					familyChangeProduct : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeProduct",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyChgMainMem : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyFuseChgMainMem",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyFuseChgMainMem",
							"operationType" : "M",
							"ownerType" : "G"
						}
					},
					changeAccount : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "ChangeAccount",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeAccount",
							"operationType" : "Transfer",
							"ownerType" : "S"
						}
					}
				},
				Home4GShare : {
					familyInstall : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyAppInstall",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyMemberMgr : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyAppMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyAppMemberMgr",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyDropSubs : {
						validate : {
							"businessType" : "FamilyCancel",
							"seniorId" : "FamilyAppDropSubs",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyMemberVali : {
						add : {
							"seniorId" : "FamilyAppMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyAppMemberMgr "
						},
						modify : {
							"seniorId" : "FamilyAppMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyAppMemberMgr "
						}
					},
					familyChangeProduct : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyAppInstall",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					}					
				},
				GrpPrdHome4GShare : {
					familyInstall : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyInstall",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyInstall",
							"operationType" : "A",
							"ownerType" : "G",
						}
					},
					familyMemberMgr : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyMemberMgr",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyDropSubs : {
						validate : {
							"businessType" : "FamilyCancel",
							"seniorId" : "FamilyDropSubs",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyDropSubs",
							"operationType" : "D",
							"ownerType" : "G",
						}
					},
					familyMemberVali : {
						add : {
							"seniorId" : "FAMILYMGR",
							"eventId" : "OFFER_CHG_FORBID",
							"busiCode" : "FamilyInstall"
						},
						modify : {
							"seniorId" : "FAMILYMGR",
							"eventId" : "OFFER_CHG_FORBID",
							"busiCode" : "FamilyMemberMgr"
						}
					},
					familyChangeProduct : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeProduct",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyChgMainMem : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChgMainMem",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChgMainMem",
							"operationType" : "M",
							"ownerType" : "G"
						}
					},
					familyChgBasicInfo : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeBasicInfo",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeBasicInfo",
							"operationType" : "M",
							"ownerType" : "G"
						}
					}
				},
				FJTVW : {
					familyChangeProduct : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyAppInstall",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyDropSubs : {
						validate : {
							"businessType" : "FamilyCancel",
							"seniorId" : "FamilyAppDropSubs",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "ChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyMemberVali : {
						add : {
							"seniorId": " FamilyAppMemberMgr",
							"eventId": " MemberEnter",
							"busiCode": " FamilyAppMemberMgr "

						},
						del : {
							"seniorId": " FamilyAppMemberMgr",
							"eventId": " MemberEnter",
							"busiCode": " FamilyAppMemberMgr "
							}
						},
					familyMemberMgr : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyAppMemberMgr",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyAppMemberMgr",
							"operationType" : "M",
							"ownerType" : "S"
						}
					}
				},
				KSJTW : {
					familyInstall : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "CreateKSJTW",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyInstall",
							"operationType" : "A",
							"ownerType" : "G",
						}
					},
					familyMemberMgr : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyMemberMgrKSJTW",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "KSFmyMemberMgr",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyDropSubs : {
						validate : {
							"businessType" : "FamilyCancel",
							"seniorId" : "FamilyDropSubsKSJTW",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyDropSubs",
							"operationType" : "D",
							"ownerType" : "G",
						}
					},
					familyMemberVali : {
						add : {
							"seniorId" : "FAMILYMGRKSJTW",
							"eventId" : "OFFER_CHG_FORBID",
							"busiCode" : "KSFmyMemberMgr"
						},
						modify : {
							"seniorId" : "FAMILYMGRKSJTW",
							"eventId" : "OFFER_CHG_FORBID",
							"busiCode" : "KSFmyMemberMgr"
						}
					},
					familyChangeProduct : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeProduct",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeProduct",
							"operationType" : "M",
							"ownerType" : "S"
						}
					},
					familyChgMainMem : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChgMainMem",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChgMainMem",
							"operationType" : "M",
							"ownerType" : "G"
						}
					},
					familyChgBasicInfo : {
						validate : {
							"businessType" : "FamilyManage",
							"seniorId" : "FamilyChangeBasicInfo",
							"eventId" : "BeforeCreateOrder",
							"busiCode" : "FamilyChangeBasicInfo",
							"operationType" : "M",
							"ownerType" : "G"
						}
					}
				}
					
		};
		return businessTypeMap;
	},
	/**
	 * 获取校验业务编码对象 
	 * 适用于家庭改造业务
	 * @author c00294059
	 */
	getValiBusinessTypeObj : function(groupType, businessType, operType) {
		debugger;
		if(!operType) {
			operType = "validate";
		}
		var businessTypeMap = this.getBusinessTypeMap();
		if(!businessTypeMap[groupType]) {
			return {};
		}
		if(businessTypeMap[groupType][businessType]) {
			return businessTypeMap[groupType][businessType][operType];
		}
		return {};
	},
	/**
	 * 获取校验业务编码
	 * 适用于家庭改造业务
	 * @author c00294059
	 */
	getValiBusinessCode : function(groupType, businessType, operType) {
		debugger;
		return this.getValiBusinessTypeObj(groupType, businessType, operType).busiCode;
	},
	/**
	 * 定义操作类型对象
	 * 方便判断是否操作
	 * @author c00294059
	 */
	initActionTypeMap : function() {
		return {"A":"A", "M":"M", "D":"D"};
	},
	/**
	 * 判断主offering是否修改过 true：修改过；false：未修改
	 * @author c00294059
	 */
	isHaveModifyMainOffer : function(offering) {
		debugger;
		if (!offering) {
			return false;
		}
		var actionTypeMap = this.initActionTypeMap();
		// 主offering操作情况
		if (actionTypeMap[offering.actionType]) {
			return true;
		}
		// 子offering操作情况
		if (offering.subOffers && offering.subOffers.length > 0) {
			for ( var i = 0; i < offering.subOffers.length; i++) {
				if (actionTypeMap[offering.subOffers[i].actionType]) {
					return true;
				}
			}
		}
		/*if(this.isHaveModifyAttachedOffer(offering.attachedOffers)) {
			return true;
		}
		if(this.isHavaModifyOfferMember(offering.members)) {
			return true;
		}*/
		return false;
	},
	/**
	 * 判断附属offering是否修改过 true：修改过；false：未修改
	 * @author c00294059
	 */
	isHaveModifyAttachedOffer : function(attachedOffers) {
		debugger;
		if (!attachedOffers || attachedOffers.length == 0) {
			return false;
		}
		var actionTypeMap = this.initActionTypeMap();
		// 附属offering操作齐情况
		for ( var j = 0; j < attachedOffers.length; j++) {
			if (actionTypeMap[attachedOffers[j].actionType]) {
				return true;
			}
			var attachedSubOffers = attachedOffers[j].subOffers;
			if (attachedSubOffers && attachedSubOffers.length > 0) {
				for ( var n = 0; n < attachedSubOffers.length; n++) {
					if (actionTypeMap[attachedSubOffers[n].actionType]) {
						return false;
					}
				}
			}
		}
		return false;
	},
	//获取生效时间
	getTimeByCode :function(key,timeBody,mode)
	{
		debugger;
		var timeDate= {};
		if("effdate" == mode)
		{			
			if(key == "I"){
				timeDate.effDate = $Page.TimeUtil.localNowDate; //生效时间为
				timeDate.effmode = 0;
			}
			else if(key == "N"){
				timeDate.effDate = $Page.TimeUtil.localNextMonthFirstDay; //生效时间为
				timeDate.effmode = 2;
			}
			else if(key == "ND"){
				timeDate.effDate  = $Page.TimeUtil.localNowDateLastSecond+1000; //生效时间为
				timeDate.effmode = 1;
			}
		}
		
		if("expdate" == mode)
		{			
			if(key == "I"){
				timeDate.expDate = $Page.TimeUtil.localNowDate; //生效时间为
				timeDate.expmode = 0;
			}
			else if(key == "N"){
				timeDate.expDate = $Page.TimeUtil.localNextMonthFirstDay; //生效时间为
				timeDate.expmode = 2;
			}
			else if(key == "ND"){
				timeDate.expDate  = $Page.TimeUtil.localNowDateLastSecond+1000; //生效时间为
				timeDate.expmode = 1;
			}
		}
				
		if(key == "C"){
	//		timeDate.effDate = effGadget.body.effectiveDate;
	//		timeDate.expDate = effGadget.body.expirationDate;
			timeDate.effDate = timeBody.effectiveDate;
			timeDate.expDate = timeBody.expirationDate;
		}
		return timeDate;
	},
	/**
	 * 判断附属offering的成员是否修改过 true：修改过；false：未修改
	 */
	isHavaModifyOfferMember : function(members) {
		debugger;
		if (!members || members.length == 0) {
			return false;
		}
		var actionTypeMap = this.initActionTypeMap();
		for(var k=0; k<members.length; k++) {
			if(actionTypeMap[members[k].actionType]) {
				return true;
			}
		}
		return false;
	},
	
	/**
	 * DD-AR-E01786469 [AD]家庭群组开户计算时间支持多账期。订单传参生效时间改为生效模式，组装订单报文中的生失效模式信息
	 */
	createOrderItemTerm : function(actionType, effExpWay, effectiveMode, expireMode, $Gadget)
	{	
        var orderItemTerm = [];
        
        // 只有在生效模式或者失效模式有值的情况下才组装订单报文
        if (!effectiveMode && !expireMode)
        {
        	return orderItemTerm;
        }
        
        // 初始化
        var durationUnit;
        var durationValue = 0;
        var fixStartDate = "";
        var primaryOfferingId = "";
        var businessCode = "";
        var isDefault = "";
        
        // 根据生失效信息重置durationUnit、durationValue、fixStartDate
        if (effExpWay)
        {
        	// 重置durationUnit
        	var durationUnits = effExpWay.durationUnit;
        	if (durationUnits && durationUnits.length > 0)
        	{
        		// 标志是否有默认选中的durationUnit
        		var selectedFlag = false;
        		for (var m = 0; m < durationUnits.length; m++)
        		{
        			if (durationUnits[m].selected)
        			{
        				selectedFlag = true;
        				
        				durationUnit = durationUnits[m].key;
        				
        				break;
        			}
        		}
        		
        		// 因为页面上是没有操作durationUnits的，所以如果没有默认选中的durationUnit，则取第一个值。
        		if (!selectedFlag)
        		{
        			durationUnit = durationUnits[0].key;
        		}
        	}
        	
        	// 重置durationValue
        	durationValue = effExpWay.durationValue;
        	
        	// 重置fixStartDate
        	fixStartDate = effExpWay.fixStartDate;
        	
        	// 重置primaryOfferingId
        	primaryOfferingId = effExpWay.primaryOfferingId;
        	
        	// 重置businessCode
        	businessCode = effExpWay.businessCode;
        	
        	// 重置isDefault
        	isDefault = effExpWay.isDefault;
        }
        
        // 生效模式
        if (effectiveMode)
        {
        	// OcOrderItemInfoPOJO.java的setOrderItemTerm方法有针对effectiveMode的处理，将termContent由json格式转为xml供OM使用
        	orderItemTerm.push({
                actionType: actionType,
                termCode: "effectiveMode",
                termContent: JSON.stringify({
                         mode: effectiveMode,
                         durationUnit: durationUnit,
                         durationValue: durationValue,
                         fixStartDate: fixStartDate,
                         primaryOfferingId: primaryOfferingId,
                         businessCode: businessCode,
                         isDefault: isDefault
                })
        	});
        }
        
        // 失效模式
        if (expireMode)
        {
        	// OcOrderItemInfoPOJO.java的setOrderItemTerm方法没有针对expireMode的处理，由于OM使用的是xml格式，所以此次需要自己组装。与effectiveMode的处理不同
        	var termContent = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ExpireModeXMLVO>\n    <expireDetail>\n        <mode>"
        		+ expireMode + "</mode>\n        ";
        	
        	if (durationUnit)
        	{
        		termContent += ("<durationUnit>" + durationUnit + "</durationUnit>\n    ");
        	}
        	
        	if (durationValue)
        	{
        		termContent += ("<durationValue>" + durationValue + "</durationValue>\n    ");
        	}
        	
        	if (fixStartDate)
        	{
        		termContent += ("<fixEndDate>" + fixStartDate + "</fixEndDate>\n    ");
        	}
        	
        	if (isDefault)
        	{
        		termContent += ("<isDefault>" + isDefault + "</isDefault>\n    ");
        	}
        	
        	termContent += "</expireDetail>\n</ExpireModeXMLVO>\n";
        	
        	orderItemTerm.push({
                actionType: actionType,
                termCode: "expireMode",
                termContent: termContent
        	});
        }
        
        return orderItemTerm;
	},
	/**
	 * 判断附属offering的限额是否修改过 true：修改过；false：未修改
	 */
	isHavaModifyOfferShareLimit : function(limitationlist) {
		debugger;
		if (!limitationlist || limitationlist.length == 0) {
			return false;  //未修改
		}
		var actionTypeMap = this.initActionTypeMap();
		for(var k=0; k<limitationlist.length; k++) {
			if(actionTypeMap[limitationlist[k].actionType]) {
				
				return true;  //已经修改
			}
		}
		return false;
	}
});