$Controller("bes.ad.ict.common", {
	/**
	 * 获取号码
	 */
	getServNumber : function()
	{
		var servNumber = $.cookie("com.huawei.bes.othersys.servnumber");
		if(servNumber && servNumber.indexOf("#")>0){
			servNumber = servNumber.substring(0, servNumber.indexOf("#"));
		}
		return servNumber;
	},
	
	/**
	 * 从URL里面读取号码
	 */
	getServNumberFromUrl : function(){
		debugger;
		return adutil.getParam("serviceNumber");
	},
	
	/**
	 * 模拟登陆
	 */
	login : function($Page,$Fire,$Gadget,$UI,servNumber,successCallBack,failCallBack){
		debugger;
		// 同步用户信息
		$Controller.bes.ad.ict.common.sysCustInfo($Gadget, $Fire, servNumber);
		
		$Fire({
			service : "bes.oc.ocauthenticationservice/loginbyloginidauth",
			params : {
				"req":{
					"loginId" : servNumber,
					"loginIdClass" : "2",
					"authId" : "6010100090003",
					"authType" : "AuthCheckZ",
					"sessionFlag" : 1,
					"chanelType" : "ICT"
				}
			},
			target : "$Page.authResp",
			onafter : function(){
				debugger;
				if($Page.authResp == 1)
				{
					if (typeof successCallBack === 'function') 
					{
						successCallBack($Page,$Fire,$Gadget,$UI);
						
					}
				}
				else if($Page.authResp == 0)
				{
					failCallBack($Page,$Fire,$Gadget,$UI);
					$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_noright"));
				}
				else if($Page.authResp == -1)
				{
					failCallBack($Page,$Fire,$Gadget,$UI);
					$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_accounterror"));
				}else if($Page.authResp == 2) {
					failCallBack($Page,$Fire,$Gadget,$UI);
					$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), $UEE.i18n("ad.marketplan.label.proinfo_failobtain"));
				}
			},
			onerror : function(){
				debugger;
				if (typeof failCallBack === 'function') 
				{
					failCallBack($Page,$Fire,$Gadget,$UI);
				}
			}
			
		}, $Gadget);
	},
	
	/**
	 * 同步用户信息
	 */
	sysCustInfo : function($Gadget, $Fire, servNumber) {
		$Controller.bes.ad.ict.common.sysCustInfoForNGJS(
				"AuthCheckZ",
				null, null,
				null, null,
				adutil.getBeId(), servNumber,
				adutil.getBeId());

		$Controller.bes.ad.ict.common.sysCustInfoForWEBAR(
				"AuthCheckZ",
				null, null,
				null, servNumber,
				null);

		$Controller.bes.ad.ict.common.sysCustInfoForWEBCC(
				"AuthCheckZ",
				null, null,
				null, servNumber,
				null);

		$Controller.bes.ad.ict.common.sysCustInfoForICrm(
				"0",
				"AuthCheckZ",
				null, null,
				null, null,
				null, servNumber,
				null, null);

	},
	
	/**
	 * 同步用户信息（for NGJS）
	 * 
	 * @param authCheckType：鉴权方式，参考字典组：AuthCheck
	 * @param pswd：密码，密码认证时传入，
	 * @param rndPswd：随机码，随机码认证时传入
	 * @param certType：证件类型，参考字典组：IdType
	 * @param certID：证件号码
	 * @param custRegion：地市
	 * @param servNumber：服务号码
	 */
	sysCustInfoForNGJS : function(authCheckType, pswd, rndPswd,
			certType, certID, custRegion, servNumber, login_region) {

		var url = "/ngrecslave/ng_js"
				+ "/custcdr/cdrquery/getReginByLogin.action?noCrmSSO=1";

		$.ajax({
			type : 'POST',
			url : url,
			dataType : "json",
			data : {
				authCheckType : authCheckType,
				pswd : pswd,
				rndPswd : rndPswd,
				certType : certType,
				certID : certID,
				custRegion : custRegion,
				login_msisdn : servNumber,
				login_region : login_region
			},
			success : function() {
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}

		});

	},
	
	/**
	 * 同步用户信息（for WEBAR）
	 * 
	 * @param authCheckType：鉴权方式，参考字典组：AuthCheck
	 * @param pswd：密码，密码认证时传入，
	 * @param certType：证件类型，参考字典组：IdType
	 * @param certID：证件号码
	 * @param region：地市
	 * @param servNumber：服务号码
	 */
	sysCustInfoForWEBAR : function(authCheckType, pswd, certType,
			certID, servNumber, region) {
		var url = "/bssrec/web_ar"
				+ "/business.action?BMEBusiness=rec.syncAuthCheckData&noCrmSSO=1&authType="
				+ authCheckType + "&servNumber=" + servNumber
				+ "&region=" + region + "&certType=" + certType
				+ "&certID=" + certID + "&pwd=" + pswd;

		$.ajax({
			type : 'POST',
			url : url,
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});

	},
	
	/**
	 * 同步用户信息（for WEBCC）
	 * 
	 * @param authCheckType：鉴权方式，参考字典组：AuthCheck
	 * @param pswd：密码，密码认证时传入，
	 * @param certType：证件类型，参考字典组：IdType
	 * @param certID：证件号码
	 * @param region：地市
	 * @param servNumber：服务号码
	 */
	sysCustInfoForWEBCC : function(authCheckType, pswd, certType,
			certID, servNumber, region) {
		var url = "/bssrec/web_cc"
				+ "/business.action?BMEBusiness=rec.syncAuthCheckData&noCrmSSO=1&authType="
				+ authCheckType + "&servNumber=" + servNumber
				+ "&region=" + region + "&certType=" + certType
				+ "&certID=" + certID + "&pwd=" + pswd;

		$.ajax({
			type : 'POST',
			url : url,
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}
		});

	},
	
	/**
	 * 同步用户信息（for iCRM）
	 * 
	 * @param isCert2G:
	 *            是否通过设备读取二代证，1表示是，0表示否
	 * @param authCheckType：鉴权方式，参考字典组：AuthCheck
	 * @param pswd：密码，密码认证时传入，如果hasEncryptPassword为true，此需要加密
	 * @param rndPswd：随机码，随机码认证时传入
	 * @param certType：证件类型，参考字典组：IdType
	 * @param certID：证件号码，确认下江苏有没有启用特性参数IdCardEncrypt，如果有的话需要加密。
	 * @param custRegion：地市，宽带登录时可能会选择地市，只要明确指定地市的就传入
	 * @param servNumber：服务号码
	 * @param
	 *            CustLoginTimeMillis：如果是先打开的菜单后鉴权，传开菜单的时间，System.currentTimeMillis()
	 * @param hasEncryptPassword：是否加密密码，true是，false否
	 */
	sysCustInfoForICrm : function(isCert2G, authCheckType, pswd,
			rndPswd, certType, certID, custRegion, servNumber,
			hasEncryptPassword, custLoginTimeMillis) {

		var ngcustcare = "/ngrecmaster/ngcustcare";

		var url = ngcustcare
				+ "/servlet/custInfoForICrmServ?ONLYLOGIN=onlyLogin&noCrmSSO=1&isCert2G="
				+ isCert2G;

		$.ajax({
			async : false,
			type : 'POST',
			url : url,
			dataType : "json",
			data : {
				authCheckType : authCheckType,
				pswd : pswd,
				rndPswd : rndPswd,
				certType : certType,
				certID : certID,
				custRegion : custRegion,
				servNumber : servNumber,
				hasEncryptPassword : hasEncryptPassword,
				CustLoginTimeMillis : custLoginTimeMillis
			},
			success : function() {
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {
			}

		});

	},
	
	/**
	 * 判断是否是ict系统
	 */
	isIct : function()
	{
		debugger;
		var isIct = $.cookie("fromType");
		if(!isIct){
			isIct = adutil.getParam("fromType");
		}
		if (isIct && "ICT" == isIct)
		{
			return true;
		}

		return false;
	},
	
	/**
	 * 如果是内嵌的页面，打开系统内的TAB页
	 * 如果是直接URL打开的页面，打开顶级TAB页
	 */
	openIctTab : function(key, name, url, contextPath) {
		
			debugger;
	        name = decodeURI(decodeURI(name));

	        if (!contextPath) {
	            contextPath = $UEE.$Webapp;
	        }

	        var urlSM = contextPath + adutil.assureStratWithRoot(url);
	        url = "/" + window.location.pathname.split("/", 2)[1]  + "/" + url;
        
	        var tabSet = _ysp_top.TabSet || {};
	        var portalName = tabSet.portalName || {};
	        var ocActionSource = portalName == "BES" ? "SM" : "ICT";
        
	        if (ocActionSource == "SM") {
	            if (window.location.protocol == "http:") {
	                _ysp_top.window.jCRM.BuziTabMgr.main.showTabItemByConf(key, name,
	                    urlSM, "");
	            } else if (window.location.protocol == "https:") {
	                window.$BES.$Portal.tabpanel.createTabItemByConf(key, name,
	                    urlSM, "");
	            }
	        } else {
	            window.open(url, '_blank');
	        }
		
	},
});