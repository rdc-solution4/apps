/*!
 * BME JavaScript Object: jBME
 * @created by Derek 20100531 Huawei Technologies Co., Ltd
 */
;
(function()
{
    // Define or get our global core object instance, which is quite a simple object used as singleton.
    var jBME = window.jBME = (window.jBME || {});
    
    /**
     * Use jBME.ready(callback) to add function.
     * Use jBME.ready() to run all  
     * @param func
     * @return
     */
    jBME.readyFunc = [];
    jBME.ready = function(func)
    {
        // All scripts have no need to run again after shifting position in DOM-tree. TODO , to be refactor.
        if (jBME.lockReady)
        {
            return;
        }
        if(func == undefined)
        {//run 
            while(jBME.readyFunc.length > 0)
            {
                var f = jBME.readyFunc.shift();
                f();
            }
        }else
        {//save function to run when ready.
            jBME.readyFunc.push(func);
        }
    };

    /**
     * Package: jBME.meta.
     */
    jBME.meta = 
    {
        cbme_clear : "cbme_clear",
        cbme_clear_item : "cbme_clear_item",
        cbme_disabled : "cbme_disabled",
        cbme_region_ignore : "cbme_region_ignore",
        cbme_selector : "cbme_selector"
    };
    
    /**
     * Define package: jBME.dom. Caching some special global DOM(wrapped in jQuery or not) elements for speed.
     */
    jBME.dom = 
    {
        $view : $([]),      //caching for jQuery(".bc_view"), <bme:view>. Initializated when page is loaded and ready.
    };
    
    //Define package: jBME.util .
    jBME.util =
    {
        description : "Define common JavaScript functions in this package.",
        
        /**
         * Return JSON or other Javascript object length.
         */
        objectLength : function(obj)
        {
            var count = 0;
            for ( var i in obj)
            {
                ++count;
            }
            return count;
        },
        /**
         * Just like jQuery.fn.hasClass(), but is static function. 
         * For performance crucial scenes(eg: in loop), static function is faster then jQuery(element)(0.14ms);
         * @param dom, DOM element.
         */
        rclass : /[\n\t]/g,
        hasClass : function(dom, className)
        {//Codes below come form jQuery-1.4.4 jQuery.fn.hasClass().
            var className = " " + className + " ";
            return dom.className && ((" " + dom.className + " ").replace(this.rclass, " ").indexOf( className ) > -1);
        },
        
        /**
         * Return a string describe the object attribute.
         */
        toString : function(object, name, includeFunc)
        {
            //default arguments.
            name = (name || object);
            includeFunc = (includeFunc || false);
            
            //ok, get string.
            var str = name + "{ ";
            for(var attr in object)
            {
                if(typeof object[attr] == "function" && !includeFunc)
                {
                    continue;
                }
                str += attr;
                str += ":";
                str += object[attr];
                str += ", ";
            }
            str += "}";
            return str;
        },
        
        /**
         * Get a valid id that can use as jQuery selector. Using \\ before some characters.
         */
        encodeId : function(id)
        {
            return id.replace("[","\\[").replace("]","\\]").replace(".","\\.");
        },
        
        /**
         * Get valid jQuery selector from id(s) expression.
         * You can use the return string directly as jQuery selector to get object(s).
         * You will get an objects set union all selector results.
         * 
         * @param idExp : "id1, id2,  ,id3"  or  "id1"  or  "" or undefined.
         * @return jQuery selector: "#id1,#id2,noneTagSelector,#id3,"  or  "#id1," or "noneTagSelector"
         */
        getIdSelector : function(idExp)
        {
            var selector = "";
            var ids = jQuery.trim(idExp).split(",");
            for(var i = 0; i < ids.length; )
            {
                var id = jQuery.trim(ids[i]);
                selector += (id ? "#"+id : "noneTagSelector");
                if(++i < ids.length)
                {
                    selector += ",";
                }
            }
            return selector;
        },
        
        /**
         * Get elements order by "selector1,selector2,selectorN"
         * Note: After jQuery 1.3.2 version, the elements returned by jQuery(expression, [context])
         * are order in DOM. So this function provides a way to get elements in order by selector.
         */
        getElementsOrderBySelector : function(selector, context)
        {
            var elements = [];
            var selectors = selector.split(",");
            for ( var j = 0; j < selectors.length; ++j)
            {
                var selectorj = jQuery.trim(selectors[j]);
                if(selectorj != "")
                {
                    jQuery(selectorj, context).each(function()
                    {
                        elements.push(this);
                    });
                }
            }
            return jQuery(elements);
        },
        /**
         * Create a jQuery(div) wrapper from HTML.
         * Note: Only used in fire render mode as render resource which is speed crucial.
         *       For more generic scenes, please use jQuery.clean([html]) instead, which has more special tests.
         * ------------------------------------------------------------------------------------
         * @see jQuery-1.4.4.js/jQuery.clean()
         * @see jQuery-1.4.4.js/IE can't serialize <link> and <script> tags normally
         *      if ( !jQuery.support.htmlSerialize ) {
         *         wrapMap._default = [ 1, "div<div>", "</div>" ];
         *      }
         * @return jQuery(<div>html</div>)
         */
        createWrapDiv : function(html)
        {
            var fragment = document.createDocumentFragment();
            var div = document.createElement("div");
            fragment.appendChild( div );
            div.innerHTML = "div<div>"+html+"</div>";

            // Find and replace the <script> elements created by innerHTML with created by document.createElement()
            // Cause: HTML5: "Note: script elements inserted using innerHTML do not execute when they are inserted."
            if(!jBME.support.evalScriptFromInnerHTML && jBME.support.evalScriptFromAPI)
            {
                var scripts = $.makeArray(div.getElementsByTagName("script"));
                for(var i = 0; i < scripts.length; ++i)
                {
                    var s = scripts[i], script = document.createElement("script");
                    script.text = s.text;

                    // Clone attributes
                    for(var a = 0; a < s.attributes.length; ++a){
                        script.setAttribute(s.attributes[a].nodeName, s.attributes[a].nodeValue);
                    }
           
                    // Replace the <script> element created by innerHTML with created by document.createElement()
                    s.parentNode.replaceChild(script, s);
                    s = null, scripts[i] = null, script = null;
                }
            }
            return div.lastChild;
        },
        /**
         * Replace DOM element. >> !Higher Performance than $.fn.repalceWith()!
         * ------------------------------------------------------------------------------------
         * Note: jQuery.fn.replaceWidth() do three things,  
         *       1.clean data. 2.remove old DOM  3.append new DOM(eval script within it). 
         * However, 'remove' and 'append' will cause browser rendering twice.
         * Here, we use w3c Node.replaceChild(newNode, oldNode) directly to reduce rendering for speed.
         * Of course we will clean data before replacing just as jQuery does.
         */
        replaceElement : function(newElem, oldElem)
        {
            if(oldElem)
            {
                // Replace with empty.
                if(!newElem)
                {
                    $(oldElem).remove();
                    return oldElem;
                }
                
                //1.Clean data of old element.(//1: ELEMENT_NODE)
                if(oldElem.nodeType === 1)  
                {//Codes from jquery-1.4.4/$.fn.remove()
                    jQuery.cleanData(oldElem.getElementsByTagName("*"));
                    jQuery.cleanData([oldElem]);
                }
                
                //2.Replace DOM
                if(oldElem.parentNode)
                {
                    oldElem.parentNode.replaceChild(newElem, oldElem);
                }
                
                //3.evalScript Node(IE,Chrome won't eval <script> within newElem when appending to DOM tree)
                if(!jBME.support.evalScriptFromAPI && jQuery.contains(document, newElem))
                {
                    var scripts = ($.nodeName(newElem, "SCRIPT") ? [ newElem ] : $.makeArray(newElem
                            .getElementsByTagName("script")));
                    for(var i = 0; i < scripts.length; ++i)
                    {//Codes from jquery-1.4.4/function evalScript(). But ignore 'elem.parentNode.removeChild(elem)'.
                        var elem = scripts[i];
                        if ( elem.src ) {
                            jQuery.ajax( {url:elem.src, async:false, dataType:"script"} );
                        } else {
                            jQuery.globalEval( elem.text || elem.textContent || elem.innerHTML || "" );
                        }
                    }
                }
            }
            return oldElem;
        },
        /**
         * Replace element(s) according to the given selector in a context
         *   with the element(s) in another context that have the same id.
         * 
         * In other words, the function will replace ALL the element(s) in jqToContext selected by the selector
         *   by the element(s) with the same id in jqFromContext.
         *
         * Note: replacing order is according to elements order in selector(not in DOM) 
         * @param selector   jQuery selector
         * @param jqFromContext  Resources holder context, 
         *          you may need to wrap your resources within an dummy element(eg:<div>), 
         *          cause the jQuery.find() method will not return the element set itself like jQuery.filter() does. 
         * @param jqToContext Default is current document. 
         * @param callbackoneach 
         */
        replaceElementsById : function(selector, jqFromContext, jqToContext, callbackOneach)
        {
            // Find element by id selector
            var $oldElements = this.getElementsOrderBySelector(selector, (jqToContext || document));
            if($oldElements.length == 0)
            {
                return $oldElements;
            }
            
            // Replace elements by new ones with same id.
            var newElements = [];
            var $subcache = jqFromContext.children();
            $oldElements.each(function(i)
            {
                var oldElem = this;
                var newElem = $subcache.filter(function(){return oldElem.id==this.id;})[0] 
                                || jqFromContext.find("#"+this.id)[0];
                if (oldElem != newElem && (false !== (callbackOneach ? callbackOneach(oldElem):true)))
                {
                    jBME.dom.$view.trigger("beforerender", oldElem.id); //TODO

                    jBME.util.replaceElement(newElem, oldElem);
                    newElements.push(newElem);
                    
                }
            });
            return $(newElements);
        },

        /**
         * Return function name from standard JS function call specification written in string.
         * @param functionExpresion (String)
         *        eg: "a.b.c.func( 123, 'str, 1234')" 
         * @return String
         *        eg: a.b.c.func
         *        
         */
        getNameByFunExp : function(functionExpresion)
        {
            functionExpresion = (functionExpresion || "");
            var iarg = functionExpresion.indexOf("(");
            if(iarg <= 0)
            {
                return jQuery.trim(functionExpresion);
            }
            return jQuery.trim(functionExpresion.substring(0, iarg));
        },
        
        /**
         * Return Arguments using standard JS function call specification written in string.
         * @param functionExpresion
         *        (String), eg: "a.b.c.func( 123, 'str, 1234')" 
         * @return Array
         *        [123]
         *        ['str, 1234']
         */
        getArgsByFunExp : function(functionExpresion, jFire)
        {
            functionExpresion = (functionExpresion || "");
            
            // Replace the function name. eg: getArguments(123, 'str1, 234') 
            var iarg = functionExpresion.indexOf("(");
            if(iarg < 0)
            {
                return [];
            }
            
            function getArguments(){return arguments;}; 
            var callExpression = "getArguments" + functionExpresion.substring(iarg);
            
            // Get arguments array from JavaScript Compiler. 
            var argumentArrayObject = [];
            try { argumentArrayObject = (eval(callExpression) || []); } catch(e){} 
            
            var argumentArray = new Array(argumentArrayObject.length);
            for(var i = 0; i < argumentArrayObject.length; ++i)
            {
                argumentArray[i] = argumentArrayObject[i];
            }
            return argumentArray;
        },
        
        /**
         * Check/set whether a DOM element is disabled within BME context.
         *  (has attribute "disabled" or has css class "cbme_disabled". 
         * @param element DOM element.
         */
        isDisabled : function(element)
        {
            var jq = jQuery(element);
            return element && (jq.hasClass(jBME.meta.cbme_disabled) || jq.is("[disabled]"));
        },
        setDisabled : function(element, disabled)
        {
            if(element)
            {
                jQuery(element).toggleClass(jBME.meta.cbme_disabled, disabled);
            }
        },
        encodeForEval : function(str)
        {
            return str.replace(/[\r]/g,"").replace(/[\n]/g,"");
        }
    };//jBME.util package define.
       
    // Define package: jBME.var
    jBME.vars =
    {
        description : "Save var in this package."
    };
    
    /**
     * BME Preset Initialization.
     * 1)Run all the saved functions you have registered using jBME.read( functionxxx(){} )
     * 2)Other initialization. 
     */
    jQuery(document).ready(function($)
    {
        jBME.ready();

        jBME.dom.$view.triggerHandler("load");
        
        // Fix IE9 vertical scroll caused horizontal scroll when page height growing.
        if($.browser.msie && $.browser.version=="9.0")
        {
            document.body.style.opacity=0.98;
            document.body.style.opacity=1;
        }
    });//page ready.
})();

/**
 * Define Class
 * jBME.Poper
 */
(function()
{
     // 私有函数
     // 返回jqMask
     function getMask()
     {
         var jqMask = $('<div class="bf_mask" style="position:fixed;z-index:199; width:100%;height:100%;left:0px;_ysp_top:0px;"></div>');
         jqMask.appendTo(document.body);
         return jqMask;
     }
    function showMask(poper)
    {
        if (!poper.mask)
        {
            return;
        }
        if (undefined == poper.jqMask)
        {
            // 获取一个新的mask对象
            poper.jqMask = getMask();
        }
        // 显示出来
        poper.jqMask.show();
    }
    function hideMask(poper)
    {
        // 每次都删除mask
        if (undefined == poper.jqMask)
        {
            return;
        }
        poper.jqMask.remove();
        poper.jqMask = undefined;
    }
    function prepareWrapper(poper)
    {
        if (undefined != poper.jqAfterWrap)
        {
            // 当前已经show出来了，不必重新处理
            // 如果需要重新处理，由调用者先hide再show
            return;
        }
        poper.jqAfterWrap = poper.jqPop;
        if (undefined == poper.wrapperFunc)
        {
        	var selector = poper.jqPop.selector;
        	if(selector.indexOf("_time_valuehourSel")==-1 && selector.indexOf("_time_valueminiteSel")==-1 && selector.indexOf("_time_valuesecondSel")==-1){
                if((poper.jqAfterWrap[0].id).search(/_dropdownlist/) < 0 && !poper.jqPop.hasClass("bc_autocomplete_dropdown"))
                {
                    document.body.appendChild(poper.jqAfterWrap[0]);
                }
                poper.jqAfterWrap.css({"z-index":5001 , _ysp_top:0 , left:0});
                return;
        	}else{
            //    $("body", window.parent.document)? $("body", window.parent.document).append(poper.jqAfterWrap[0]) : $("body").append(poper.jqAfterWrap[0]);
                document.body.appendChild(poper.jqAfterWrap[0]);
                // calculate _ysp_top and left, set them to the poper.jqAfterWrap
                var _ysp_top = poper.jqPopFrom.offset()._ysp_top;
                var left = poper.jqPopFrom.offset().left;
                var height = parseInt(poper.jqPopFrom.css("height").replace("px", ""));
                poper.jqAfterWrap.css({"z-index":"5001", "display" : "block", "left":left+"px"});
                poper.jqAfterWrap.css("left", left+" !important").css("_ysp_top", _ysp_top + height);
                return;
        	}
        }
        
        if (undefined == poper.jqWrapper)
        {
            poper.jqWrapper = poper.wrapperFunc();
        }
        
        // 将pop移到wrapper中去

        poper.jqWrapper.jqContent[0].appendChild(poper.jqPop[0]);
        var position = poper.jqPop.css("position");
        if(position !== "static")
        {//Change position for poper. This operation is time costing(31ms), so only run if really need to.
            poper.jqPop.css("position", "static");    
            poper.jqPop.attr("position_popersaved", position);  //Save for recover.
        }
        
        poper.jqPop.show();
        poper.jqAfterWrap = poper.jqWrapper;
    }
    function calcFromInfo(poper)
    {
        if (undefined == poper.jqPopFrom)
        {
            // 说明用户手动注入from信息，不必计算
            return;
        }
        poper.popFromInfo = getDomInfo(poper.jqPopFrom);
    }
    function showWrapper(poper, options)
    {
        options = (options||{});
        
        // 1.准备弹出对象，可能直接使用jqPop,也可能将jqPopWrapper一下，最终的弹出对象为jqAfterWrap
        prepareWrapper(poper);

        // We show before we get the right position/width/height. 
        // Cause IE7 may cause a scroll when getting widht/height when hidden.
        // However, for sync JS code, it's fast engough to update postion and width/height after show first.^)^
        poper.jqAfterWrap.css({"left": 1 + "px", "_ysp_top": 1 + "px"});
        poper.jqAfterWrap.show();

        // 2.计算from信息
        calcFromInfo(poper);

        // 3.取得弹出窗口的大小
        getPopInfo(poper);
        var winInfo = getWinInfo();
        var popInfo = $.extend(true, {}, poper.popFromInfo);
 
        // 4.确定垂直方向的弹出
        setVerticalPopPos(poper, popInfo, winInfo,options);

        // 5.确定水平方向的弹出
        setHorizontalPopPos(poper, popInfo, winInfo);

        // 6. 修改位置并显示, IE may has css update problem, so we have to toggle a class to force the browser rendering.
        // 如果实在弹出页面中弹出，则需要减去父页面的偏移
        var pFromPopwin;
        if(poper.jqPopFrom){
            pFromPopwin = poper.jqPopFrom.parents(".popwin");
            if(pFromPopwin.length != 0){
            	var tempEle = $(pFromPopwin[0]);
            	var fromSelector = poper.jqPop.selector;
                if(fromSelector.indexOf("_valuehourSel")!=-1 || fromSelector.indexOf("_valueminuteSel")!=-1 || fromSelector.indexOf("_valuesecondSel")!=-1){
                //popInfo.left = popInfo.left - tempEle.offset().left;
                } 	else{
                    popInfo.left = popInfo.left - tempEle.offset().left;
                    popInfo._ysp_top = popInfo._ysp_top - tempEle.offset()._ysp_top;
                    // Lack of space in the popup box's right side 
                    if (popInfo.left + poper.popWidth > tempEle.width()){
                        popInfo.left = popInfo.left - poper.popWidth + poper.popFromInfo.width;
                    }
                    // Lack of space in the popup box's right and left side 
                    if (popInfo.left < 0){
                        popInfo.left = 0;
                    }
                    // Lack of space in the popup box's bottom side 
                    if (popInfo._ysp_top + poper.popHeight > tempEle.height()){
                        popInfo._ysp_top = popInfo._ysp_top - poper.popHeight - poper.popFromInfo.height;
                    }
                    // Lack of space in the popup box's _ysp_top and bottom side 
                    if (popInfo._ysp_top < 0){
                        popInfo._ysp_top = 0;
                    }
                }
            }
        }
        poper.jqAfterWrap.css($.extend({"left": popInfo.left + "px", "_ysp_top": popInfo._ysp_top + "px"}, (poper.resultRight ? {} : options.css)));
        poper.jqAfterWrap.toggleClass("tempcssfix");
    }
    function hideWrapper(poper)
    {
        if (undefined == poper.jqAfterWrap)
        {
            return;
        }
        poper.jqAfterWrap.hide();
        poper.jqPop.hide();
        
        var position = poper.jqPop.attr("position_popersaved");
        if(position)
        {//Load back the position setting. This is tiem costing, so only run if really need to.
            poper.jqPop.css("position", position);
            poper.jqPop.removeAttr("position_popersaved");
        }
        
        if (poper.jqPopParent)
        {
            poper.jqPopParent[0].appendChild(poper.jqPop[0]);
        }
        if (poper.jqWrapper)
        {
            poper.jqWrapper.remove();
            poper.jqWrapper = undefined;
        }
        poper.jqAfterWrap = undefined;
    }
    function getEmptyOffset()
    {
        return {"left":0, "_ysp_top":0, "right":0, "bottom":0};
    }
    // 获取弹出窗口的坐标计算信息
    function getEmptyPopInfo()
    {
        return {"left":0, "_ysp_top":0, "width":0, "height":0};
    }
    function getWinInfo()
    {
        var ele = document.documentElement;
        var body = document.body;
        // chrome识别documentElement的scrollTop/scrollLeft有问题，使用body则没有问题
        // 这两个值浏览器总是只返回一个有效的，所以直接相加，避免判断浏览器
        return {"scrollTop":ele.scrollTop + body.scrollTop, "scrollHeight":ele.scrollHeight,
            "scrollLeft":ele.scrollLeft + body.scrollLeft, "scrollWidth":ele.scrollWidth,
            "offsetHeight":$(window).height(), "offsetWidth":ele.offsetWidth};
    }
    // 返回dom的left/right/width/height信息,dom可以是dom，也可以是jq对象
    function getDomInfo(dom)
    {
        jqObj = $(dom);
        var info = getEmptyPopInfo();
        info.left = jqObj.offset().left;
        info._ysp_top = jqObj.offset()._ysp_top;
        info.width = jqObj.outerWidth();
        info.height = jqObj.outerHeight();
        return info;
    }
    function getPopInfo(poper)
    {
        // 不手动设置width，则ie7下无法正确显示;  这个设置一定要在show之后进行(Cause you will get zero-width when hidden)
        if (poper.jqWrapper)
        {
            var jqContent = poper.jqWrapper.jqContent;            
            poper.jqAfterWrap.width( jqContent.outerWidth(true) );
        }
        poper.popWidth = poper.jqAfterWrap.outerWidth();
        poper.popHeight = poper.jqAfterWrap.outerHeight();
    }
    // 垂直
    function setVerticalPopPos(poper, popInfo, winInfo,options)
    {
        var modifedTop = ((poper.jqAfterWrap[0].id).search(/_dropdownlist/)>0 || poper.jqPop.hasClass("bc_autocomplete_dropdown"))? winInfo.scrollTop : 0;

        if (poper.bottomFirst)
        {
            var adjustHeight = options.adjustHeight?options.adjustHeight:0;
            // 向下弹出
            popInfo._ysp_top = poper.popFromInfo._ysp_top + poper.popFromInfo.height + poper.offsetInfo._ysp_top - modifedTop;
            poper.resultBottom = true;
          //兼容声明doctype的情况和不声明doctype的情况
            if((document.doctype && document.doctype.name != "") || window.ActiveXObject)
            {
            	var heightTemp = popInfo._ysp_top - winInfo.scrollTop + modifedTop + poper.popHeight + adjustHeight - poper.offsetInfo.bottom;
            }else{
            	var heightTemp = popInfo._ysp_top + modifedTop + poper.popHeight + adjustHeight - poper.offsetInfo.bottom;
            }
            if (heightTemp > winInfo.offsetHeight)
            {
                // 下方空间不足，向上弹出
                poper.resultBottom = false;
                popInfo._ysp_top = poper.popFromInfo._ysp_top - poper.popHeight + poper.offsetInfo.bottom - modifedTop;
            }
        }
        else
        {
            // 先向上弹出
            popInfo._ysp_top = poper.popFromInfo._ysp_top - poper.popHeight + poper.offsetInfo.bottom - modifedTop;
            poper.resultBottom = false;
            if (popInfo._ysp_top - winInfo.scrollTop + modifedTop - poper.offsetInfo._ysp_top < 0)
            {
                // 上方空间不足，向下弹出
                poper.resultBottom = true;
                popInfo._ysp_top = poper.popFromInfo._ysp_top + poper.popFromInfo.height + poper.offsetInfo._ysp_top - modifedTop;
            }
        }
        //兼容声明doctype的情况和不声明doctype的情况
        if((document.doctype && document.doctype.name != "") || window.ActiveXObject)
        {
        	var heightless = popInfo._ysp_top - winInfo.scrollTop + modifedTop + poper.popHeight - poper.offsetInfo.bottom;
        }else{
        	var heightless = popInfo._ysp_top + modifedTop + poper.popHeight - poper.offsetInfo.bottom;
        }
        // 垂直方向仍然无法显示，则将top置为当前窗口滚动top位置
        if ((popInfo._ysp_top - winInfo.scrollTop + modifedTop - poper.offsetInfo._ysp_top < 0) || 
                (heightless > winInfo.offsetHeight+adjustHeight))
        {
             if(poper.isTips)
             {
                 poper.resultBottom = true;
                 
                 var _ysp_top = poper.popFromInfo._ysp_top + poper.popFromInfo.height + poper.offsetInfo._ysp_top;
                 if(poper.jqPop.css("position") == "fixed")
                 {
                     //如果定位模式是fixed，需要减去页面滚动高度
                     popInfo._ysp_top = _ysp_top - winInfo.scrollTop;
                 }
                 else
                 {
                     popInfo._ysp_top = _ysp_top;
                 }
             }
             else
             {
                 popInfo._ysp_top = winInfo.scrollTop - modifedTop;
             }
        }
            
    }
    // 水平
    function setHorizontalPopPos(poper, popInfo, winInfo)
    {
        var modifedLeft = ((poper.jqAfterWrap[0].id).search(/_dropdownlist/)>0 || poper.jqPop.hasClass("bc_autocomplete_dropdown"))? winInfo.scrollLeft : 0;
        // 向右弹出
        poper.resultRight = true;
        popInfo.left = poper.popFromInfo.left + poper.offsetInfo.left - modifedLeft;
        if (poper.leftFirst==false || popInfo.left  - winInfo.scrollLeft - modifedLeft + poper.popWidth - poper.offsetInfo.right > winInfo.offsetWidth)
        {
            // 空间不足，则向左弹出
            poper.resultRight = false;
            popInfo.left = poper.popFromInfo.left + poper.popFromInfo.width - poper.popWidth + poper.offsetInfo.right - modifedLeft;
        }
        
        // 水平方向仍然无法显示，则将left置为当前窗口滚动left位置
        if (popInfo.left + modifedLeft < winInfo.scrollLeft + poper.offsetInfo.left)
        {
            popInfo.left = winInfo.scrollLeft - modifedLeft;
        }
    }
    /**
     * Define Class and its constructor
     * 1.默认优先向下弹出
     * -----
     * |from|
     * -----
     * -----------
     * |   pop   |
     * -----------
     * 2.下方空间不足，则向上弹出
     * -----------
     * |   pop   |
     * -----------
     * -----
     * |from|
     * -----
     * 3.右方空间不足，则向左弹出
     * -----------
     * |   pop   |
     * -----------
     *       -----
     *       |from|
     *       -----
     * 4.向上或向下校正后，空间仍然不足，将top置为0，向左或向右校正后，空间仍然不足，将left置为0
     * 5.from缩小为一个点时，可以满足环绕鼠标弹出的效果
     * 6.可以设置是否需要wrap，内置阴影wrap，工具栏场景则是使用自定义wrap
     * 7.可以设置是否需要mask(默认mask整个body，将来有需求再改)
     */
    jBME.Poper = function(jqPop)
    {   
        this.setPop(jqPop);
        this.offsetInfo = getEmptyOffset();
        return this;
    };

    /**
     * Define Class members
     */
    jBME.Poper.prototype = 
    {
        jqPopFrom: undefined,
        jqPop: undefined,
        // 根据jqPop计算出来的父对象
        jqPopParent: undefined,

        jqMask: undefined,
        mask : false,
        
        wrapperFunc : undefined, // 用于获取wapper的函数，由调用者设置，本类内置createShadowWrapper
        jqWrapper : undefined,
        
        bottomFirst : true, // 默认优先向下弹出
        leftFirst : undefined,   // 设置向左弹出
        
        // 这里最终体现的是实际弹出方向
        resultBottom : true, 
        resultRight : true,

        // 根据jqPopFrom计算出来的信息，也可以是用户直接注入的信息
        popFromInfo : undefined,
        // jqPop的弹出偏移信息
        offsetInfo : undefined,

        // 下面是内部变量
        // 最终使用这个对象进行弹出显示
        jqAfterWrap : undefined,
        popWidth : undefined,
        popHeight : undefined,
        eventName : undefined,

        //是否为tips
        isTips : undefined,
        
        // 内置shadow wrapper
        createShadowWrapper : function(pFrom)
        {	
            // 创建shadow对象
            var html = 
                ['<div class="bf_shadow" style="z-index:5001;">'
                ,    '<div class="bf_shadow_part head">'
                ,        '<div class="bf_shadow_left"></div>'
                ,        '<div class="bf_shadow_right"></div>'
                ,        '<div class="bf_shadow_center"></div>'
                ,    '</div>'
                ,    '<div class="bf_shadow_middleleft"><div class="bf_shadow_middleright"></div></div>'
                ,    '<div class="bf_shadow_part foot">'
                ,        '<div class="bf_shadow_left"></div>'
                ,        '<div class="bf_shadow_right"></div>'
                ,        '<div class="bf_shadow_center"></div>'
                ,    '</div>'
                ,'</div>'].join("");
            var jqShadow = $(html);
            jqShadow.jqContent =  jqShadow.children(".bf_shadow_middleleft").children();
            
            // if datetime is pop from a popwin, we should not append it to document.body.
            // we should append it to the area where it pop from.
            var pFromPopwin = pFrom.parents(".popwin");
            if(pFromPopwin.length == 0){
                jqShadow.appendTo(document.body);
            }else{
                jqShadow.appendTo($(pFromPopwin[0]));
            }

            return jqShadow;
        },
        setPop : function(jqPop)
        {
            if (undefined == jqPop)
            {
                return;
            }
            this.jqPop = jqPop;
            this.jqPopParent = jqPop.parent();
        },
        defaultWrap : function()
        {
            this.wrapperFunc = this.createShadowWrapper;
        },
        setPopFromInfoByDom : function(dom)
        {
            this.popFromInfo = getDomInfo(dom);
        },
        setPopFromInfoByEvent : function(event)
        {
            this.popFromInfo = getEmptyPopInfo();
            this.popFromInfo.left = mouseX(event);
            this.popFromInfo._ysp_top = mouseY(event);
        },
        toggle : function(jqPopFrom)
        {
            return (this.isShow() ? this.hide() : this.show(jqPopFrom));
        },
        isShow : function()
        {
            return (this.jqAfterWrap && this.jqAfterWrap.is(":visible"));
        },
        // 指定坐标显示，不服从修正原则，指哪打哪
        showIn : function(x, y)
        {
            this.popFromInfo = getEmptyPopInfo();
            this.show();
            // 修改位置            
            this.jqAfterWrap.css({"left": x + "px", "_ysp_top": y + "px"});
        },
        // jqPopFrom可选，如果不指定，则使用调用show之前的jqPopFrom值
        show : function(jqPopFrom, options)
        {
            
            if (undefined != jqPopFrom)
            {
                this.jqPopFrom = jqPopFrom;
            }
            // 1.更新wrapper位置并显示
            showWrapper(this, options);
            
            // 2.显示mask
            showMask(this);

            // 3.监听局部刷新事件，在自己被干掉之前先hide掉，但是如果没有wrapper，则不需要这个处理
            if (undefined == this.jqWrapper)
            {
                return;
            }
            this.eventName = "beforerender." + this.jqPop.attr("id");
            var This = this;
            jBME.dom.$view.unbind(this.eventName).bind(this.eventName, function(event, id)
            {
                if(id && This.isShow() && This.jqPop.closest("#"+id)[0])
                {
                    This.hide();
                }
            });
        },
        hide : function()
        {
            // 1.隐藏wrapper
            hideWrapper(this);
            // 2.隐藏mask
            hideMask(this);
            // 3.取消事件监听
            if(this.eventName){
                jBME.dom.$view.unbind(this.eventName);
            }
        }
    };
})();
