$UEE.$Fire.onerrors[455] = function(data, fire, scope){
	debugger; 
	
	var treasuryResult = data;
	var iWidth=500; //模态窗口宽度
	var iHeight=500;//模态窗口高度
	var iTop=(window.screen.height-iHeight-100)/2;
	var iLeft=(window.screen.width-iWidth)/2;
	
	//var treasuryResultJson = JSON.parse(treasuryResult);
	if ('3' == treasuryResult.messageType && ("CAS000" != treasuryResult.resultCode 
										    && "CAS013" != treasuryResult.resultCode
										    && "CAS031" != treasuryResult.resultCode
										    && "CAS999" != treasuryResult.resultCode))
	{
		alert('金库认证失败。 ' + treasuryResult.resultCode + " " + treasuryResult.resultMessage);
	}
	else
	{
		var rtn = window.showModalDialog(treasuryResult.modeUrl,treasuryResult, "dialogHeight:"+iHeight+"px; dialogWidth:"+iWidth+"px; toolbar:no; menubar:no;  titlebar:no; scrollbars:yes; resizable:no; location:no; status:no;left:"+iLeft+"px;_ysp_top:"+iTop+"px;");
		
		debugger;
		
		//DTS2018011507772修改金库鉴权弹出页面点击"取消"后js报错的问题
		if (rtn == null)
		{
			return;
		}
		
		var result = JSON.parse(rtn);
		
		var treasuryVO = JSON.parse(data.treasuryVOJSON);
		
		//treasuryNingXiaSecondAuthAPI.writeAuthLog(result, scope, treasuryVO);
		
		if("CAS000" != result.resultCode 
				&& "CAS013" != result.resultCode
				&& "CAS031" != result.resultCode
				&& "CAS999" != result.resultCode){
			
			$.cookie("SmSecondAuthToken","",{path : '/'});
			alert("金库授权失败，终止服务");
		}else{
			$.cookie("SmSecondAuthToken",result.token,{path : '/'});
			alert("金库授权成功，请再次提交数据。");
		}
	}
};


/**
 * 二次授权API
 * @returns
 */
function treasuryNingXiaSecondAuthAPI(){
	

	//记录授权日志
	this.writeAuthLog = function(result,$Scope,treasuryVO){
		
		var authStatus = "CAS000" == result.resultCode || "CAS013" == result.resultCode || "CAS031" == result.resultCode || "CAS999" == result.resultCode;
		var authLog = new Object();
	
		authLog["recType"] = treasuryVO.recType;

		authLog["authMethod"] = treasuryVO.serviceUrl;
		authLog["status"] = authStatus?1:2;
		authLog["sessionId"] = $Scope.$Model.sessionId;
		authLog["casMainSwitch"] = 1;
		authLog["casSceneSwitch"] = authStatus?1:2;
		authLog["ipAddr"] = window.location.host;
		
		var $Fire = $Scope.$Inject("$Fire");
		
		$Fire({
			"service" : "/smtreasuryboservice/addauthlog",
			"params" : {"logvo" : authLog}
		},$Scope);
		
 	};
}

function treasuryAPI(){
	this.init = function($Scope){
		
	
	};
}

var treasuryNingXiaSecondAuthAPI = new treasuryNingXiaSecondAuthAPI();