;
/**
 * 支持只有一个密码框的场景和两个密码框的场景: 一个密码框传id1,两个传id1和id2
 */
$Controller("bes.ad.keyboard.readpassword", function ($Gadget, $UI, id1,
    id2, checkOldPwd, checkNewPwd) {
	
    $Gadget.keyboard = {
        id1: "",
        id2: ""
    };
    var num = /\d{6}/;
    $Gadget.keyboard.input1 = id1 || "";
    $Gadget.keyboard.input2 = id2 || "";
    if (!$Gadget.keyboard.input1) {
    	//未指定密码框ID。
        $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.UnspecifiedPasswordID"));
    }
    
    //根据电商统一快捷支付签约对于CVV2的需求，需要小键盘，而不是手动输入,该输入为3位，所以和初始的6位逻辑区别，以input的id：creditCVV2区分
    if($Gadget.keyboard.input1 == "creditCVV2")
    {
    	readPasswordCVV2($Gadget.keyboard.input1, $UI);
    }
    else
    {
    	readPassword($Gadget.keyboard.input1, $Gadget.keyboard.input2, $UI);
    }	
    

    function readPassword(password, repassword) {
        debugger;
        // 重置标识 
        $Page.isPwdPress = false;

        try {
            if ($Gadget.keyboard.input1 && $Gadget.keyboard.input2) 
            {
                var passwordObj = document.getElementById(password);
                var repasswordObj = document.getElementById(repassword);
                // 清空密码
                passwordObj.value = "";
                repasswordObj.value = "";
                var passwordModel = $(passwordObj).attr("ng-Model");
                var repasswordModel = $(repasswordObj).attr("ng-Model");
                if (passwordModel) {
                    $UEE.propertyValue($(passwordObj).scope(), passwordModel, "");
                }
                if (repasswordModel) {
                    $UEE.propertyValue($(repasswordObj).scope(), repasswordModel, "");
                }

                var pwd1 = document.getElementById("KeyCard1").ReadKey1();
                if (pwd1.length != 6 || !num.test(pwd1)) {
                	//长度必须为6位!
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.Length6Digits"));
                    return false;
                }

                var pwd2 = document.getElementById("KeyCard1").ReadKey2();
                if (pwd2.length != 6 || !num.test(pwd1)) {
                	//长度必须为6位!
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.Length6Digits"));
                    return false;
                }
                if (pwd1 != pwd2) {
                	//两次输入不一致
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.DifferentTwoInputs"));
                    return false;
                }
                if (repasswordObj) {
                    repasswordObj.value = pwd1;
                }
                passwordObj.value = pwd1;
                if (checkNewPwd) {
                    $Gadget.$Emit("$Gadget.checkNewPwd");
                }
                passwordObj.focus();
                $(passwordObj).trigger("change");
                $(repasswordObj).trigger("change");
            } 
            else 
            if ($Gadget.keyboard.input1) 
            {
                var passwordObj = document.getElementById(password);
                // 清空密码
                passwordObj.value = "";
                var passwordModel = $(passwordObj).attr("ng-Model");
                if (passwordModel) {
                    $UEE.propertyValue($(passwordObj).scope(), passwordModel, "");
                }
                
                var pwd1 = document.getElementById("KeyCard1").ReadKey1();
                if (pwd1.length != 6 || !num.test(pwd1)) {
                	//长度必须为6位!
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.Length6Digits"));
                    return false;
                }

                passwordObj.value = pwd1;
                if (checkOldPwd) {
                    $Gadget.$Emit("$Gadget.checkOldPwd");
                }
                passwordObj.focus();
                $(passwordObj).trigger("change");
            }
        } catch (e) {
            // $UI.msgbox.info("提示", "小键盘硬件读取异常:" + e + "!");
        	//请连接键盘设备。
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ConnectKeyboard"));
            return false;
        }
    }

    
    function readPasswordCVV2(password) {
    	debugger;
    	try {
                var passwordObj = document.getElementById(password);
                // 清空密码
                passwordObj.value = "";
                var passwordModel = $(passwordObj).attr("ng-Model");
                if (passwordModel) {
                    $UEE.propertyValue($(passwordObj).scope(), passwordModel, "");
                }
                
                var pwd1 = document.getElementById("KeyCard1").ReadKey1();
                if (pwd1.length != 3) {
                	//长度必须为3位!
                    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.Length3Digits"));
                    return false;
                }

                passwordObj.value = pwd1;
                if (checkOldPwd) {
                    $Gadget.$Emit("$Gadget.checkOldPwd");
                }
                passwordObj.focus();
                $(passwordObj).trigger("change");
    	}
    	catch (e) {
            // $UI.msgbox.info("提示", "小键盘硬件读取异常:" + e + "!");
        	//请连接键盘设备。
            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.ConnectKeyboard"));
            return false;
        }
    	
    }
    	
     
    
});

/**
 * 键盘使用辅助类
 */
$Controller("keyboard.helper", {
    /**
     * 小键盘初始化时查询系统参数及令牌
     * @param $Page
     * @param $Fire
     * @param $Gadget
     * @param $UI
     */
    init: function ($Page, $Fire, $Gadget, $UI) {
            debugger;
            var relatedPwdInputIds = $Gadget.$Attrs.relatedpwdinputids;
            if (relatedPwdInputIds) {
                $Gadget.relatedPwdInputIds = relatedPwdInputIds.split(",");
                var len = $Gadget.relatedPwdInputIds.length;
                //没有传密码input id
                if (len == 0) {
                    return;
                }
            } else if(relatedPwdInputIds == "") {
            	return;
            }

            $Controller.keyboard.helper.qryInputPasswordKeybrdLimit($Page, $Fire, $Gadget, $UI);
        },

        /**
         * 查询系统参数
         */
        qryInputPasswordKeybrdLimit: function ($Page, $Fire, $Gadget, $UI) {
            debugger;
            try {
            	//OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
            } catch (e) {
            	debugger;
            }
            //操作员手工输入密码权限
            var inputPasswordKeybrdLimit = "InputPasswordKeybrdLimit";

            //请求初始化数据
            $Gadget.$Get("$Fire")({
                "service": "ucec/v1/common/qrysystemparambykey",
                "params": {
                    key: inputPasswordKeybrdLimit
                },
                "target": "$Gadget.inputPasswordKeybrdLimit",
                onafter: function ($Gadget, $UI) {
                    debugger;

                    //true：开启，false：关闭
                    if ($Gadget.inputPasswordKeybrdLimit == "true") {
                        $Controller.keyboard.helper.qryinputPasswordRight($Page, $Fire, $Gadget, $UI);
                    }
                }
            }, $Gadget);
        },

        /**
         * 查询令牌
         * @param $Page
         * @param $Fire
         * @param $Gadget
         * @param $UI
         */
        qryinputPasswordRight: function ($Page, $Fire, $Gadget, $UI) {
            debugger;
            $Gadget.authResults = [];
            $Gadget.inputPasswordRight = "6013100115082701";

            //判断 操作员有没有”输入密码令牌”（InputPasswordRight）
            //InputPasswordRight: 6013100115082701
            try {
            	//OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextInitFireId());
            } catch (e) {
            	debugger;
            }
            $Fire({
                service: "/ucec/v1/common/smHasAuth",
                params: {
                    body: {
                        "authIds": [$Gadget.inputPasswordRight]
                    }
                },
                target: "$Gadget.Resp",
                onafter: function ($Gadget) {
                    debugger;
                    if (!$Controller.keyboard.helper.success($Gadget.Resp)) {
                        return;
                    }

                    $Controller.keyboard.helper.processReadOnly($Page, $Fire, $Gadget, $UI);
                    //发送Readonly设置完毕消息
                    $Gadget.$Emit("$Gadget.ReadonlyConfirmCallBack");
                }

            }, $Gadget);
        },

        /**
         * 处理是否input只读
         * @param $Page
         * @param $Fire
         * @param $Gadget
         * @param $UI
         */
        processReadOnly: function ($Page, $Fire, $Gadget, $UI) {
            debugger;
            $Gadget.authResults = $Controller.keyboard.helper.parseAuthResult($Gadget.Resp);
            var right = $Gadget.authResults[$Gadget.inputPasswordRight];
            for (var i = 0; i < $Gadget.relatedPwdInputIds.length; i++) {
                var id = "#" + $.trim($Gadget.relatedPwdInputIds[i]);
                var input = $("" + id);
                if (input.length > 0) {
                    //判断操作员是否有手工输入密码，有权限返回true，否则返回false
                    if (right) {
                        input.removeAttr("readonly");
                        //input.removeAttr("disabled");
                        input.attr("style", "background: #ffffff;");
                        
                        $Page.isHaveInputAuth = true;
                    } else {
                        input.attr("readonly", "readonly");
                        //input.attr("disabled", "disabled");
                        input.attr("style", "background: #f8f8f8;");
                        
                        $Page.isHaveInputAuth = false;
                    }
                }
            }
        },

        /**
         * 响应消息是否成功
         * @param returnMessage
         * @returns
         */
        success: function (resp) {
            debugger;
            if (!resp) {
                return false;
            }

            var header = resp.header;
            var body = resp.body;

            if (!header || !body) {
                return false;
            }

            if (0 != header.resultCode) {
                return false;
            }

            //未返回authResults
            if (!body.authResults) {
                return false;
            }

            return true;
        },

        /**
         * 解析结果，放到数组中
         * @param resp
         * @returns {Array}
         */
        parseAuthResult: function (resp) {
            debugger;
            var authResults = [];
            var res = resp.body.authResults;

            if (!res || res.length == 0) {
                return;
            }

            for (var i in res) {
                var obj = res[i];
                if (obj.result == "true") {
                    authResults[obj.authId] = true;
                } else {
                    authResults[obj.authId] = false;
                }
            }

            return authResults;
        }
});