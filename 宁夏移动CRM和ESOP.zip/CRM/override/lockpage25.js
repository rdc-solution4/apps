/*******************************************************************************
 * FileName:lockpage.js
 ******************************************************************************/ 
var lockpage = new SMLockPage();

function SMLockPage()
{
	var i18n = $UEE.i18n;
	
	this.lock = function ()
	{
		var $Scope = $(document).scope();
		var $fire = $Scope.$Get("$Fire");
		var $UI = $Scope.$UI;
		$UI.msgbox.confirm(i18n("SM.LOGIN.MESSAGE.CONFIRM"), i18n("SM.LOGIN.MESSAGE.UNLOCK"), function() {
			$fire(
			{
				service : "/SMLockScreenAction/lockScreen",
			},$Scope).onafter(function(){
				$('#headerDiv').hide();
				$('#ifr_container').hide();
				$("#lockPageDiv").show();
		    });
		});
	};
	
	
	this.unlock = function ()
	{
		debugger;
		var $Scope = $(document).scope();
	    var $Model = $Scope.$Model;
	    
        if ($Model.lockpage_pwd == undefined || $Model.lockpage_pwd == "")
        {
        	$("#lockpage_pwd").focus();
        	return;
        }
        
        $("#unlockpage_btn").attr("disabled", true);
        var loginId= $Model.userInfo.loginId
		var locale = $Model.userInfo.locale;
		
	    var $fire = $Scope.$Get("$Fire");
	    
	    $fire({
		      "service" : "SMLoginAction/getLoginRandomValue",
		      "target" : "$Model.loginRandomValue",
		 },$Scope).onafter(function(){
			 var pwd = encryptWithRSA("[" + $Model.loginRandomValue + "]" + $Model.lockpage_pwd);
			 $fire({
			      	"service" : "SMLockScreenAction/unlockScreen",
			      	"params" :  {'pwd':pwd},
			      	"target" : "$Model.unlockScreenResult"
				 },$Scope).onafter(function(){
			     	  lockpage.porcessUnlockScreenResult($Model.unlockScreenResult)
				 });
		 });
	};
	
	this.porcessUnlockScreenResult = function (result)
	{
        var $Scope = $(document).scope();
		var $Model = $Scope.$Model;
		$Model.lockpage_pwd = "";
		$("#unlockpage_btn").attr("disabled",false);
		 
		if (result.resultCode != "0") 
		{	
			if(result.resultCode == "locked"){
				$(document).scope().$UI.msgbox.error(i18n('SM.LOGIN.TITLE.CHANGEPWD_ERROR'), i18n('SM.LOGIN.MESSAGE.HAVE_LOCK_USER'));
			}else{
				$(document).scope().$UI.msgbox.error(i18n('SM.LOGIN.TITLE.CHANGEPWD_ERROR'), i18n('SM.LOGIN.MESSAGE.UNLOCK_FAILED'));
			}
			return;
		}
		
		$("#lockPageDiv").hide();

		$('#headerDiv').show();
		$('#ifr_container').show();
	};

}

