/***********************************************************
*   FileName:logout.js
************************************************************/ 
var smlogout = new SMLogout();

function SMLogout()
{
	var i18n = $UEE.i18n;
	var count = 0;
	var onloadcount = 0;
	var sum = 1;
	
	this.logout = function ($Scope)
	{
		debugger;
		var $Scope = $(document).scope();
		var $Model = $Scope.$Model;
		var $fire = $Scope.$Get("$Fire");
		var $UI = $Scope.$UI;
		$UI.msgbox.confirm(i18n("SM.LOGIN.MESSAGE.CONFIRM"), i18n("SM.LOGIN.MESSAGE.LOGOUT"), function() {
			$BES.$Portal.tabpanel.closeAllTabItem();
			
			if($Model.emergency != undefined && $Model.emergency.intervalCount != undefined)
			{
				clearInterval($Model.emergency.intervalCount);
			}
			
				debugger;
				//DD-AR-D01886788 退出系统时进行知识库的退出-点击退出
  			  	var onlineKnowledgeLogOut = _ysp_top.$BES.$Portal.tabpanel.onlineKnowledgeLogOut;
          	    var knowledgeBaseStatus = _ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus;
          	    if (knowledgeBaseStatus == true)
          	    {
          			  if (onlineKnowledgeLogOut)
          			  {
          				  //_ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus = false;
          				  //跨域请求
          	              jQuery.ajax({
          	  			  type: "get",
          	  			  url: onlineKnowledgeLogOut, 
          	  			  dataType: "jsonp",
          	  			  success: function (suc) {
          	  				  debugger;
          	  				  _ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus = false;
          	  		      },
          	  		      error: function (err) {
          	  		      	  debugger;
          	  		      }
          	  			  });
          			  }
          	    }
				
				$fire({ service : "/SMLogoutAction/logout",
				    target : "$Model.logoutPOJO"
	              }, $Scope).onafter( function (){
	            	  
	            	  var thirdLogoutUrls = $Model.logoutPOJO.thirdSysLogoutUrls;
	            	  if(thirdLogoutUrls != undefined && thirdLogoutUrls.length > 0){
	            		  
	            		  for(var index = 0 ; index < thirdLogoutUrls.length;index++){
	            			  
	            			  var url = thirdLogoutUrls[index];
	            			  try{
		            			  jQuery.ajax({
		            				  type: "get",
		            				  async: true,
		            				  url: url,
		            				  dataType: "json",
		            				  cache: false,
		            				  success: function (asd) {
		            					  debugger;
		            					  
		            		          },
		            		          error: function (err) {
		            		        	  debugger;
		            		        	  
		            		          }
		            			  });  
		            		  }catch (err) {
		            			  debugger;
		        
		            		  }
	            		  }
	            		  
	            	  }
	            	  debugger;
	            	  if ($Model.logoutPOJO.ssoIsActive)
	            	  {
	            		 // smlogout.logoutByUrl($Model.logoutPOJO.ssoLogouURL + "/logout", $Model.logoutPOJO.loginURL);
	            		 // smlogout.logoutByUrl($Model.logoutPOJO.ssoLogouURL + "/serviceLogin.action", $Model.logoutPOJO.loginURL);
	            		  window.location.href = $Model.logoutPOJO.ssoLogouURL + "/logout" + "?service=" + location.origin + $(document.body).scope().$Webapp + $Model.logoutPOJO.loginURL;
	            	  }
	            	  else
	                  {
	            		  debugger;
	            		  location.replace($(document.body).scope().$Webapp + $Model.logoutPOJO.loginURL);
	                  }
	              });
        });
	};
	
	this.logoutByUrl = function (logoutUrl, loginUrl)
	{
        debugger;
		var theDiv = document.createElement("div");
		theDiv.height = 0;
		theDiv.width = 0;
		theDiv.innerHTML="<iframe id=bes_logout_iframe_"+count+" name=bes_logout_iframe_"+count+" height=0 width=0 />";
		document.body.appendChild(theDiv);
			
		var iframe = document.getElementById("bes_logout_iframe_"+count);
		var theForm = document.createElement("form");
		theDiv.appendChild(theForm);
			
		theForm.method = "get";
		theForm.action = logoutUrl;
		theForm.target = "bes_logout_iframe_"+count;
		theForm.submit();
			
		count++;
		if (iframe.attachEvent)
		{ 
			iframe.attachEvent("onload", function()
			{
		       	onloadcount++;
				if(onloadcount == sum)
				{
					location.replace($(document.body).scope().$Webapp + loginUrl);
				}
			});
		}
		else
		{
		    iframe.onload = function()
			{
				onloadcount++;
				if(onloadcount == sum)
				{
					location.replace($(document.body).scope().$Webapp + loginUrl);
				}
			};
		}
		
		setTimeout("smlogout.timeout(loginUrl)",3000);
	};

	this.timeout = function (loginUrl)
	{
		onloadcount++;
		if(onloadcount == sum)
		{
			location.replace($(document.body).scope().$Webapp + loginUrl);
		}
	}	
}
