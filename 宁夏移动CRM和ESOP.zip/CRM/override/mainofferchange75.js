$Controller("bes.oc.mainofferchange", {
		mainofferchange : function($Page,$Gadget,$Fire,$UI){
			debugger;
			
			try{
				$Fire({
					    'service' : '/ucec/v1/context/contextandsession_query',
				        'params' : {},
			            'target' : '$Gadget.queryedLoginInfo',
			            'onbefore' : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId())",
			            'onafter' : function($Gadget) {
				            debugger;
							if(($Gadget.queryedLoginInfo == null) || ($Gadget.queryedLoginInfo.body == null) 
									|| ($Gadget.queryedLoginInfo.body.subSrvSubscriberInfo == null) ){
								$UI.msgbox.info("提示","用户号码未登录或登录已过期，请重新登录。");
								return ;
							}
							
							$Page.checkoutInfo={
									//需要后台传给前台
									serviceNumber:$Controller.bes.ad.csp.common.getServNumber(),
									businessName:"主商品变更"
							};
							
							//主offer信息先存起来
							$Page.mainOffer=$Page.mainOfferingList[0];
							$Page.mainOfferForMainOfferChange = $Page.mainOfferingList[0];
							
							$Controller.bes.oc.mainofferchange.offerChangeBeforeValidate($Page,$Gadget,$UI,$Page.mainOffer);
		                }
		        }, $Gadget);
			}catch(error){
				debugger;
				$UI.msgbox.info("提示","用户号码未登录或登录已过期，请重新登录。");
			}
		},
		
		/**
		 * 产品变更点击触发的事件
		 * @param $Page
		 * @param $Gadget
		 * @param $UI
		 * @param selectedOffer
		 * @param actionType  
		 */
		offerChangeBeforeValidate:function($Page,$Gadget,$UI,selectedOffer){
			    debugger;
				var req={};
				req.vaildateBaseInfo={
						eventId:"PRI_OFFER_CHG",
						busiCode:'ChangeProduct',
						seniorId:'CHANGE_OFFER',
						subscriberId: $Gadget.queryedLoginInfo.body.subSrvSubscriberInfo.subsId
				};
				var orderReq=this.assembleOrder($Page,selectedOffer, "ChangeProduct", "M","D");     //这两个字段待确认
				req.order=orderReq.order;
				req.productOrderLine=orderReq.productOrderLine;
				req.extInfo = orderReq.extInfo; 
				
				var confirmCallBack=function(){
	                    debugger;
	                    $Gadget.isProdOrder = true;
						//$Gadget.$Emit('$bes.ad.mainPackageSelect',{});
	            		$Gadget.$Get('$Fire')({popup:"{'id':'choosePackagesPop','title' : '选择套餐','width' : '750px','height' : '480px'," +
	            		"'src':'{{$Webapp}}/bes/ad/themes/default/template/bes-ad-selectpackageinfo/bes-ad-choosepkg.html','resizable':false}"});
				};
				
				this.busiValidate($Page,$Gadget,$UI,req,confirmCallBack);
		},
		
		/**
	     * 组装订单报文
	     * @param $Page
	     * @param selectedOffer
	     * @param businessCode
	     * @param operationType
	     * @param actionType
	     * @returns {___anonymous14134_14135}
	     */
	    assembleOrder:function($Page,selectedOffer,businessCode,operationType,actionType){
			  debugger;
			  var req={};
			  req.order ={
					businessCode : businessCode
				};
			  req.productOrderLine =[{
					businessCode : businessCode,                       /**SE待确认**/ 
					operationType : operationType,                    //待确认，同开发给的报文不同
					ownerType : "S",                        
					orderItem : [{
						itemId:selectedOffer.offeringId,
						itemType:"O",
						actionType:actionType
					}]
				}];
			  req.extInfo = {};
			  return req;
		},
		
		/**
	     * 跳转结算页面前的校验
		 * @param $Page
		 * @param $Gadget
		 * @param $UI
		 * @param req 
	     */
		busiValidate:function($Page,$Gadget,$UI,req,confirmCallBack,dialogTitle){
			debugger;
			var $Fire = $Gadget.$Get('$Fire');
			dontTouchDataOfWholePage();
			$Fire(
					{
						'service' : 'bes.oc.ocorderservice/busivalidate',
						'params' : {
							"req" : req
						},
						'target' : '$Page.checkoutValidateResult',
						'onbefore' : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
						'onafter' : function() {
							debugger;
							youCanTouchDataOfWholePage();
							if (adutil.checkBusiValidResp($Gadget,$UI,$Page.checkoutValidateResult.busiValidResp,confirmCallBack)){
								confirmCallBack();
							}
						}
					}, $Gadget);
		},
		
		offerChangeValidate:function($Page,$Gadget,$UI,$Event){
			if(!$Event.$Data){
				return ;
			}
			debugger;
			var offeringId=$Event.$Data.offeringId;

			if(offeringId==$Page.mainOffer.offeringId){
				$UI.msgbox.confirm("提示", "所选套餐与当前套餐相同，是否重新选择？", function() {
					//$("#changeOffer").show();
					$Gadget.$Emit("$bes.ad.mainPackageSelect",{});
				});
			}else{
				$Gadget.isProdOrder = false;
				$Page.isProdOrder = true;
				$Page.selectMainOfferingId = offeringId;
				
				//主商品变更判断
				$Gadget.$Get('$Fire')({targetstep:"personalmainofferchange"});
			}
		},
		
		/**
		 * 主offer变更结算
		 * @param $Gadget
		 * @param $UI
		 * @param offeringList
		 */
		gotocheckout : function($Page,$Gadget,$UI,offeringList)
		{
			debugger;
			
			var tempList = $.extend(true,[],offeringList);
			$Controller.bes.ad.shoppingcart.gerateofferingList(tempList);
			
			//家庭产品begin
			var index = null;
			var famOfferList = [];
			for(var i=0; i<offeringList.length; i++)
			{
				if($(document).scope().isFamilyProd(offeringList[i]))
				{
					index = i;
					var offerFamily = $.extend(true,{},offeringList[i]);
					var famOffer = $Controller.bes.ad.shoppingcart.filterOfferings(offerFamily);
					famOfferList.push(famOffer);
					break;
				}
			}
			if(null != index)
			{
				tempList.splice(index, 1);
			}
			//家庭产品end
			
			debugger;
			$Fire = $Gadget.$Get('$Fire');
			//var $Page = $(document).scope().$Page;
			
			//营销活动begin
			$Page.promInfoList=$Page.promInfoList||[];
			
			//保存营销方案列表
			for(var m=0;m<$Page.promInfoList.length;m++){
				
				for(var n=0; n<tempList.length; n++)
				{
					//判断产品ID是否相同
					if($Page.promInfoList[m].offeringId==tempList[n].offeringId){
						
						//删除营销方案
						tempList.splice(n,1);
						break;
					}
				}
			}
			//营销活动end
			
			$Page.agentFlag = $Page.agentFlag || "";
			//成功后提交校验报文
			dontTouchDataOfWholePage();
			$Fire({
		        service : '/ucec/v1/order/currentorderlist_validate',
		        params:{
		        	header:{},
		            body : {businessType:$Page.agentFlag,offerings:tempList,familyOfferings:famOfferList,promotions:$Page.promInfoList}
		        },
		        target : '$Gadget.validateResult',
		        onbefore : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
		        onafter : function(){
		        	debugger;
		        	var result = ($Gadget.validateResult||{}).body;
		        	youCanTouchDataOfWholePage();
		        	OC.Comm.checkBusiValidResp($Gadget, $UI, result, null, function(){
		        		$Page.changeMainOffer = {};
		        		$Page.changeMainOffer.serialNo = result.serialNo;
		        		dontTouchDataOfWholePage();
		        		$Fire({
		        			service : '/ucec/v1/order/order_calcfee',
		        			params : {
		        				header : null,
		        				body : {
		        					serialNo : $Page.changeMainOffer.serialNo
		        				}
		        			},
		        			target : '$Gadget.validateResult',
		        			onbefore : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
		        			onafter : function($Page,$Gadget) {
		        				debugger;
		        				youCanTouchDataOfWholePage();
		        				if($Gadget.validateResult.body.totalAmount > 0)
		        				{
		        					$UI.msgbox.error("提示", "有业务费用，无法进行办理。");
		        					//按钮恢复
		        	            	$Controller.bes.oc.mainofferchange.enableBtn('#personalmainofferchangesubscribe');
		        				}else
		        				{
		        					$Controller.bes.oc.mainofferchange.mainOfferChangeCalcFee($Page,$Gadget);
		        					/*OC.Comm.checkBusiValidResp($Gadget, $UI, result, null,
	        							$Controller.bes.oc.mainofferchange.mainOfferChangeCalcFee($Page,$Gadget),
			        		            function(){
		        							youCanTouchDataOfWholePage();
		        							//按钮恢复
				        	            	$Controller.bes.oc.mainofferchange.enableBtn('#personalmainofferchangesubscribe');
			        		            }
		        					);*/
		        				}
		        			}
		        		}, $Gadget);
		        		
		            },
		            function(){
		            	youCanTouchDataOfWholePage();
		            	//按钮恢复
    	            	$Controller.bes.oc.mainofferchange.enableBtn('#personalmainofferchangesubscribe');
		            });
		        }
			},$Gadget);
		},
		
		/**
		 * 主商品变更 算费
		 * @param $Page
		 * @param $Gadget
		 */
		mainOfferChangeCalcFee : function($Page,$Gadget)
		{
			debugger;
			dontTouchDataOfWholePage();
	    	$Fire({
	    		service : '/ucec/v1/order/order_submit',
	    		params : {
				      "header" : {},
			      "body" : {
					  "serialNo" : $Page.changeMainOffer.serialNo
			      }
	    		},
	    		target : '$Page.order_resp',
	    		onbefore : "OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId())",
	    		onafter : function($Page){
	    			debugger;
	    			youCanTouchDataOfWholePage();

	    			$Fire({targetstep:'index'});
	    			
	    			$("#productOrderForNewOpen").hide();
					//删除旧的base.css
					$("link[href$='ordercapture/css/base.css']").remove();
					$("link[href$='ordercapture/css/style.css']").remove();
					$Page.paymentFinishStepFlag = true;
					
	    			$("<link>").attr({
			            rel : "stylesheet",
			            type : "text/css",
			            href : window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/checkoutFinish.css"
			        }).appendTo("head");
	    		}
	    	},$Gadget);
		},
		
		enableBtn:function(id){
			$(id).attr('disabled', null);
		},
	}
);