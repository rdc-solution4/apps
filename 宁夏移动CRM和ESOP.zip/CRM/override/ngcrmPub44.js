/*
 * 添加新用户接口
 */
Container_newUser = function(id,custType,name,contentId,city,grade,type,state,cardType,cardNo,servNo,region,
		custname,custlevel,custproduct,certype,certno,linkname,linkphone,linkaddress,email,creditlevel,
		currstatus,custmanager,brandName,balance,loginName,subsAdditionalInfo)
{
	/*alert("servNo"+servNo);
	if(_ysp_top.publicObject)
		{
		alert("publicOjbect");
		alert(_ysp_top.publicObject);
		}*/
    var container = _ysp_top.publicObject["container"];
    //alert("container"+container);
    //先判断该用户是否已经登录，如果已经登陆提示操作员切换到该用户视图
    var tmpArray = container.customers;
   // alert("tmpArray"+tmpArray);
    for(var tmp in tmpArray)
    {
        if(tmpArray[tmp].id == id)
        {
            alert("\u8BE5\u7528\u6237\u5DF2\u7ECF\u767B\u5F55\uFF0C\u8BF7\u5207\u6362\u7528\u6237\u540E\u8FDB\u884C\u64CD\u4F5C");
            var tabCode = "valida";
            var oTab = _ysp_top.publicObject["mainTab"];
            oTab.removeTabByCode(tabCode);
            return false;
        }
    }
    // modify begin by s00227425 2014-08-21 V200R003C14LG0801_EHUB OR_HUB_201404_1329 一线提速- 关键业务增加星级服务判断和显示 
    //新用户登录时，清空购物车数量
    if(typeof(_ysp_top.refreshBuyBus) == 'function')
    {
    	_ysp_top.refreshBuyBus('+',0,true);
    }
    
    container.add(id,name,contentId,city,grade,type,state,cardType,cardNo,servNo,region,custname,custlevel,custproduct,certype,certno,linkname,linkphone,linkaddress,email,creditlevel,currstatus,custmanager,null,custType,loginName);
   // alert(" container.add(id");
    //左角添加用户记录
    WorkArea_addUser(id,name);
   // alert("WorkArea_addUser(id,name);");
    if(typeof(_ysp_top.refreshClientInfo) == 'function')
    {
    	if(subsAdditionalInfo && subsAdditionalInfo instanceof Object)
    	{
    		_ysp_top.refreshClientInfo(1,name,servNo,certno,brandName,balance,subsAdditionalInfo);
    	//	 alert("_ysp_top.refreshClientInfo(1,name,servNo,certno,brandName,balance,subsAdditionalInfo);");
    	}
    	else
    	{
    		_ysp_top.refreshClientInfo(1,name,servNo,certno,brandName,balance);
    		// alert("_ysp_top.refreshClientInfo(1,name,servNo,certno,brandName,balance);");
    	}
    }
    // modify end by 2014-08-21 V200R003C14LG0801_EHUB OR_HUB_201404_1329 一线提速- 关键业务增加星级服务判断和显示 
    
    container.evalAfterNewUserEvent();   
   // alert("_ysp_top.refreshClientInfo(1,name,servNo,certno,brandName,balance);");
    return true;
};
/*
 * 系统添加新的user
 */
WorkArea_addUser = function(id,name)
{
    var workArea = _ysp_top.publicObject["workArea"];
    if(workArea && workArea.add(id,name))
    {
        var customerArea = _ysp_top.publicObject["customerArea"];
        workArea.get(id).htmlObj = customerArea.doAddRowWithInnerHTML("customerArea", "<div align='absmiddle' nowrap style='cursor:hand;width:120;overflow:hidden;'>"+name+"&nbsp;"+id + "</div>",id);
        customerArea.focusUser(id);
    }
};

