var intervalid;
$Controller(

"oc.numbookingresult",
		{

			// 初始化成功提示页面，如果收到的消息是来自选号屏页面的话显示倒计时并自动关闭提示页面
			initPage : function($Event, $Page, $Gadget) {
				debugger;
				$Gadget.name = $Event.$Data.name;
				if($Event.$Data.name == "reserve"){	
					$Gadget.reserveOrderId = $Event.$Data.reserveOrderId;
					/*$Gadget.time = $Controller.oc.numbookingresult
					.reserveTime($Event.$Data.reserveDate,$Event.$Data.reserveSaveTime);*/
					$Gadget.time = $Event.$Data.reserveDate + ($Event.$Data.reserveSaveTime*60*60*1000);
					$Gadget.reservePhone = $Event.$Data.reservePhone;
					$Gadget.reservePrice = $Event.$Data.reservePrice/1000+$UEE.i18n('ad.sr.message.Y'); //  元
//					$("#reserveOrderId").html($Event.$Data.reserveOrderId);
//					$("#reserveDate").html(
//							$Controller.oc.numbookingresult
//							.reserveTime($Event.$Data.reserveDate,$Event.$Data.reserveSaveTime));
//					$("#reservePhone").html($Event.$Data.reservePhone);
//					$("#reservePrice").html($Event.$Data.reservePrice+$UEE.i18n('ad.sr.message.Y')); //  元
				}else if($Event.$Data.name == "modify"){
					$Gadget.reserveOrderId = $Event.$Data.refRecId;
					//$("#reserveOrderId").html($Event.$Data.refRecId);
				}else if($Event.$Data.name == "modifyPwd"){
					$Gadget.reserveOrderId = $Event.$Data.number;
				}else if($Event.$Data.name == "failReason"){
					$Gadget.reserveOrderId = $Event.$Data.number;
				}

				// $Controller.oc.numbookingresult.validateTime();

				if ($Page.numbookingresult == "numPickScreen") {
					var cTime = 5;
					$("#div_countTime").text(cTime);
					$("#div_count").css({
						visibility : "visible"
					});
					cTime--;// 防止初始倒计时时一秒延迟
					intervalid = setInterval(function() {
						if (cTime <= 0) {
							// clearInterval(intervalid);
							$Controller.oc.numbookingresult.closeCurPage();
							cTime = 5;

							return;
						}
						$("#div_countTime").text(cTime);
						cTime--;
					}, 1000);
				}
				
				// 放到$Page变量，免填单打印时候用
				$Page.printEventOid = $Gadget.reserveOrderId;
			},

			// 点击免填单打印按钮，免填单打印
			printevent : function($Emit) {
				debugger;

				$Emit("$OC.printEvent", {});
			},
			// 关闭当前页
			closeCurPage : function() {
				debugger;
				if (intervalid) {
					clearInterval(intervalid);
				}

				// $Page.numbookingresultFlag=false;
				//$("#numbookingresult").hide();
				//$("#mainImpl").show();
				//$("#recommendscreen").show();
				
				window.location.href = window.location.pathname;
					

			},

			// 有效期计算及显示
			validateTime : function() {
				debugger;
				var tomorrowDate = new Date(new Date().getTime() + 24 * 60 * 60
						* 1000);
				var day = tomorrowDate.getDate();
				var month = tomorrowDate.getMonth() + 1;
				var year = tomorrowDate.getFullYear();
				var hour = tomorrowDate.getHours();
				var minute = tomorrowDate.getMinutes();
				$("#validateTime").text(
						year + "-" + month + "-" + day + " " + hour + ":"
								+ minute);
			},

			// 有效期计算及显示
			reserveTime : function(data,count) {
				debugger;
				var tomorrowDate = new Date(data + count * 60 * 60 * 1000);
				var day = tomorrowDate.getDate();
				var month = tomorrowDate.getMonth() + 1;
				var year = tomorrowDate.getFullYear();
				var hour = tomorrowDate.getHours();
				var minute = tomorrowDate.getMinutes();
				return year + "-" + month + "-" + day + " " + hour + ":"
						+ minute;
			},

			// 倒计时结束后关闭提示页面
			countDown : function(cTime) {

				if (cTime <= 0) {
					$Controller.oc.numbookingresult.closeCurPage();
				}

				$("#div_countTime").text(cTime);
				cTime--;

			},

		})
