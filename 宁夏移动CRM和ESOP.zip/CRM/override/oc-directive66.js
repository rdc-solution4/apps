/* jshint strict:false, debug:true */
/* globals angular, $ */
angular.module('uee.ui').filter('mobilePhone', function($q, $Fire) {
    // input:输入
    return function(input, symbol) {
        if (!symbol) {
            symbol = ' ';
        }
        if (input.length === 11) {
            return input.substr(0, 3) + symbol + input.substr(3, 4) + symbol + input.substr(7, 4);
        }
        return input;
    };
});

/**
 * [$filter dictCodeToName，将数据字典code匹配至字典name]
 * @auth {[gWX300509,2016/6/4]}
 * @example <td ng-bind="$item.region|dictCodeToName:'OC.DIFFNET.CITY'"></td>
 * @param  {[service]} $q angular内置Promise服务
 * @param  {[service]} $Fire UEE扩展$http服务
 * @return {[String]} 过滤后的结果 字典项匹配结果
 */
angular.module('uee.ui').filter('dictCodeToName', function($q, $Fire) {
    // 数据字典池
    var dictPool = {};
    // 查询缓存队列
    var catchList = {};
    // 请求数字字典数据
    function getDictHandler(dictKey) {
        // 创建Promise对象
        var deferred = $q.defer();
        $Fire({
            service: '/common/dictkey',
            params: {
                'dictkeylist': [dictKey],
            },
            target: 'data',
        }).onafter(function(data) {
            // 存在表示请求正常返回了
            if (data[dictKey]) {
                // 创建对应字典项
                var dictCode = {};
                // 数据编排
                angular.forEach(data[dictKey], function(item) {
                    dictCode[item.itemCode] = item.itemName;
                });
                // 设置数据字典池
                dictPool[dictKey] = dictCode;
                // 设置deferred状态为完成
                deferred.resolve();
            } else {
                // 设置deferred状态为拒绝
                deferred.reject();
            }
        }).onerror(function() {
            // 设置deferred状态为拒绝
            deferred.reject();
        });
        // 返回Promise对象
        return deferred.promise;
    }
    // 获取字典Name
    function getDictName(dictCode, input) {
        if (dictCode) {
            return dictCode[input] || input;
        } else {
            return input;
        }
    }
    // input:输入的字典值; dictKey:需要匹配的字典项
    return function(input, dictKey) {
        // 没有指定匹配的字典项则返回原始值
        if (!dictKey) {
            console.error('$filter:dictCodeToName can not find dictKey, please check ' + input);
            return input;
        }
        var dictCode = dictPool[dictKey];
        // 字典项在字典池中不存在且不再查询缓存中，则执行查询
        if (!dictCode && !catchList[dictKey]) {
            // 加入缓存
            catchList[dictKey] = true;
            // 执行查询
            return getDictHandler(dictKey).then(function successCallback() {
                // 移除缓存队列中对应字典项
                delete catchList[dictKey];
                // 查询完毕后异步返回结果
                return getDictName(dictCode, input);
            }, function errorCallback() {
                // 直接返回
                return input;
            });
        } else {
            // 此处直接返回，是因为，当触发Angular内部的脏值检查机制后，View层的过滤器，会自动更新
            return getDictName(dictCode, input);
        }
    };
});


angular.module('uee.ui').directive('ocDroplistinput', function($filter) {
    var directive = {
        restrict: 'E',
template: '<div class="form_droplist" ><div class="Droplist" style="z-index: inherit;"><div class="DroplistHeader"><input type="text" class="inputbox" readonly u-validator="{{uValidator}}"><span class="trigger"></span></div><div class="DroplistOption" ng-show="options.length>0" ng-mousedown="$event.stopPropagation();"><ul><li  class="dropItem" ng-class="{selected:$item.selected}" ng-mousedown="clickItemEvent($item)" title="{{$item.value}}" ng-repeat="$item in options track by $item.key"><span ng-bind="$item.value"></span></li></ul></div></div></div>',
        replace: true,
        transclude: false,
        scope: {
            options: '=options',
            select: '=select',
            selectkey: '=selectkey',
            uValidator: '@uValidator',
            change: '=change'
        },
        compile: compile
    };
    // 注册文档事件
    $(document).click(function(event) {
        event.stopPropagation();
        // 点击空白处，隐藏所有下拉菜单
        $('div[id^=DroplistOption_]').hide();
        $('.DroplistHeader').removeClass('down');
    });

    function compile(element, attrs) {
        return link;
    }
    
    
    function setInputValue($scope, element, value) {
        $scope.value = value;
        $(element).find('input').val(value);
    }
    
    function link($scope, element, attrs) {
        setOption(element, attrs);
        setInputValue($scope, element, "");
        
        if (attrs.select) {
            // 选中的对象
            $scope.select = $scope.select || {};
            $scope.$watch('select', function(newValue, oldValue) {
                if (newValue && newValue.value) {
                    setInputValue($scope, element, newValue.value);
                } else {
                    setInputValue($scope, element, "");
                }
            });         
        }

        if (attrs.selectkey) {
            $scope.$watch('selectkey', function(newValue, oldValue) {
                if (newValue) {
                    for  (var i = $scope.options.length - 1; i >= 0; i--) {
                        var item = $scope.options[i];
                        if (item.key == newValue) {
                            setInputValue($scope, element, item.value);
                            if (attrs.select) {
                                $scope.select = item;
                            }
                            break;
                        }
                    }
                } else {
                    setInputValue($scope, element, "");
                }
            });
        }

        if(attrs.readonly && attrs.readonly == 'false'){
        	debugger;
        	$(element).find('input').attr("readonly",false);
        }
        
        if(attrs.placeholder){
        	debugger;
        	$(element).find('input').attr("placeholder",attrs.placeholder);
        }
        
        $scope.$watch('options', function(newValue, oldValue) {
            if (!angular.isArray(newValue) || newValue === oldValue) {
                return true;
            }
            for (var i = newValue.length - 1; i >= 0; i--) {
                if (newValue[i].selected) {
                    chooseEvent(newValue[i]);
                    continue;
                }
                newValue[i].selected = false;
            }
        });

        $scope.clickItemEvent = function($item) {
            debugger;
            // 判断值是否相等
            if ($scope.select && $scope.select.key === $item.key) {
                return true;
            }
            angular.forEach($scope.options, function(option) {
                option.selected = false;
            });
            chooseEvent($item);
        };
        // 选中事件
        function chooseEvent(option) {
            debugger;
            // 设置当前选中状态
            option.selected = true;
            // 外部选中对象
            if (attrs.select) {
                $scope.select = option;
            }
            
            if (attrs.selectkey) {
                $scope.selectkey = option.key;
            }
            // 设置显示的值
            setInputValue($scope, element, option.value);
            // 触发改变事件
            changeEvent(option);
        }
        // 改变事件
        function changeEvent(option) {
            debugger;
            // 判断是否为函数
            if (angular.isFunction($scope.change)) {
                // 触发选择事件 传入3个对象
                $scope.change(option.key, option.value, option);
            }
        }
        
        element.find("input").on("input change propertychange", function(event) {
        	debugger;
            if (event.type == "change" && !event.isTrigger) {
                return;
            }
            var $input = $(event.target);
            //记录当前的value
            var value=$input.val();
            var valueTemp = value;
            if (event.type == "input" || event.type == "propertychange") {
                
            	if ($scope.hisData === value)
                    return;
                if($(element).find('.DroplistOption') && $scope.options && value){
                    
                	var lis = $(element).find('.DroplistOption').find('li');
                	lis.hide();
                	
                	var i = 0; //number of shown droplist item
                    var val = "";
                	$.each($scope.options , function(i,valk){
                		var tempKey = valk.key;
                        var tempValue = valk.value;
                		if(tempValue.indexOf(value) != -1){
                			$(element).find('.DroplistOption').find("li[title='" + valk.value+ "']").show();
                			i++;
                			val = (val === "") && (value === tempValue) ? tempKey : val;
                		}
                	})
                	
                }
                
                //当删除搜索框内容时展示所有选项start
                if(!value && !valueTemp){
                	var lis = $(element).find('.DroplistOption').find('li');
                	lis.hide();
                	
                	var i = 0; //number of shown droplist item
                    var val = "";
                	$.each($scope.options , function(i,valk){
                		var tempKey = valk.key;
                        var tempValue = valk.value;
            			$(element).find('.DroplistOption').find("li[title='" + valk.value+ "']").show();
            			i++;
            			val = (val === "") && (value === tempValue) ? tempKey : val;
                	})
                	
                }
                //当删除搜索框内容时展示所有选项end
                $scope.hisData=value;
                return;
            }
        });
        
        // 下拉输入框失去焦点时判断下当前是否有选中值，如果没有就清空当前输入框
        element.find("input").on("blur", function(event) {
            debugger;
            var $input = $(event.target);
            var inputkey = $input.attr("key");
            
            var lis = $(element).find('.DroplistOption').find('li');
            lis.show();
            
            // DTS2017021800940 下拉选项为空时，清空当前输入框
            var options = $scope.options;
            if(!options)
            {
                $(event.target).val("");
            }

            // DTS2017021800940  输入值是否在下拉选项中(通过value值进行判断）
            for (var i = 0; i < options.length; i++) 
            {
                if($input.val() == options[i].value)
                {
                    return;
                }
            }
            
            if(!inputkey){
                $(event.target).val("");
                $scope.select ={};
            }
        });
        
        
        
    }
    
    function setOption(element, attrs) {
        //debugger;
        // 根据时间创建ID
        var id = 'DroplistOption_' + new Date().getTime();
        var options = $(element).find('.DroplistOption').attr('id', id);
        var header = $(element).find('.DroplistHeader');
        var dropList = $(element).find('.Droplist');
        // 注册当前下拉菜单事件
        $(element).click(function(event) {
            event.stopPropagation();
            // 隐藏除自己外所有的元素
            $('div[id^=DroplistOption_]').not(options).hide();
            $('.DroplistHeader').not(header).removeClass('down');
            // 显示或隐藏自己
            options.toggle();
            // 实时调整位置
            options.css({
                _ysp_top: dropList.height(),
                width: dropList.width() - 4
            });
            header.toggleClass('down');
        });
        return link;
    }
    
    
    return directive;
});

angular.module('uee.ui').directive('ocDroplist', function($filter) {
    var directive = {
        restrict: 'E',
template: '<div class="form_droplist" ><div class="Droplist" style="z-index: inherit;"><div class="DroplistHeader"><input type="text" class="inputbox" unselectable="on" readonly u-validator="{{uValidator}}"><span class="trigger"></span></div><div class="DroplistOption" ng-show="options.length>0" ng-mousedown="$event.stopPropagation();"><ul><li class="dropItem" ng-class="{selected:$item.selected}" ng-mousedown="clickItemEvent($item)" title="{{$item.value}}" ng-repeat="$item in options track by $item.key"><span ng-bind="$item.value"></span></li></ul></div></div></div>',
        replace: true,
        transclude: false,
        scope: {
            options: '=options',
            select: '=select',
            selectkey: '=selectkey',
            uValidator: '@uValidator',
            change: '=change',
            param: '=param'
        },
        compile: compile
    };
    // 注册文档事件
    $(document).click(function(event) {
        event.stopPropagation();
        // 点击空白处，隐藏所有下拉菜单
        $('div[id^=DroplistOption_]').hide();
        $('.DroplistHeader').removeClass('down');
    });

    function compile(element, attrs) {
        return link;
    }
    
    
    function setInputValue($scope, element, value) {
        $scope.value = value;
        $(element).find('input').val(value);
    }
    
    function link($scope, element, attrs) {
        setOption(element, attrs);
        setInputValue($scope, element, "");
        
        if (attrs.select) {
            // 选中的对象
            $scope.select = $scope.select || {};
            $scope.$watch('select', function(newValue, oldValue) {
                if (newValue && newValue.value) {
                    setInputValue($scope, element, newValue.value);
                } else {
                    setInputValue($scope, element, "");
                }
            });         
        }

        if (attrs.selectkey) {
            $scope.$watch('selectkey', function(newValue, oldValue) {
                if (newValue) {
                    for  (var i = $scope.options.length - 1; i >= 0; i--) {
                        var item = $scope.options[i];
                        if (item.key == newValue) {
                            setInputValue($scope, element, item.value);
                            if (attrs.select) {
                                $scope.select = item;
                            }
                            break;
                        }
                    }
                } else {
                    setInputValue($scope, element, "");
                }
            });
        }

        $scope.$watch('options', function(newValue, oldValue) {
            if (!angular.isArray(newValue) || newValue === oldValue) {
                return true;
            }
            for (var i = newValue.length - 1; i >= 0; i--) {
                if (newValue[i].selected) {
                    chooseEvent(newValue[i]);
                    continue;
                }
                newValue[i].selected = false;
            }
        });

        $scope.clickItemEvent = function($item) {
            debugger;
            // 判断值是否相等
            if ($scope.select && $scope.select.key === $item.key) {
                return true;
            }
            angular.forEach($scope.options, function(option) {
                option.selected = false;
            });
            chooseEvent($item);
        };
        // 选中事件
        function chooseEvent(option) {
            debugger;
            // 设置当前选中状态
            option.selected = true;
            // 外部选中对象
            if (attrs.select) {
                $scope.select = option;
            }
            
            if (attrs.selectkey) {
                $scope.selectkey = option.key;
            }
            // 设置显示的值
            setInputValue($scope, element, option.value);
            // 触发改变事件
            changeEvent(option);
        }
        // 改变事件
        function changeEvent(option) {
            debugger;
            // 判断是否为函数
            if (angular.isFunction($scope.change)) {
                // 触发选择事件 传入3个对象
                if ($scope.param) {
                    $scope.change(option.key, option.value, option, $scope.param);
                }
                else {
                    $scope.change(option.key, option.value, option);
                }
            }
        }
    }
    
    function setOption(element, attrs) {
        //debugger;
        // 根据时间创建ID
        var id = 'DroplistOption_' + new Date().getTime();
        var options = $(element).find('.DroplistOption').attr('id', id);
        var header = $(element).find('.DroplistHeader');
        var dropList = $(element).find('.Droplist');
        // 注册当前下拉菜单事件
        $(element).click(function(event) {
            event.stopPropagation();
            // 隐藏除自己外所有的元素
            $('div[id^=DroplistOption_]').not(options).hide();
            $('.DroplistHeader').not(header).removeClass('down');
            // 显示或隐藏自己
            options.toggle();
            // 实时调整位置
            options.css({
                _ysp_top: dropList.height(),
                width: dropList.width() - 4
            });
            header.toggleClass('down');
        });
        return link;
    }
    
    return directive;
});
// gWX300509 单选组件
// <div class="form_control">
//     <oc:radio options="$Gadget.list" select="$Gadget.choosed" change="$Gadget.change"></oc:radio>
// </div>
angular.module('uee.ui').directive('ocRadio', function($filter) {
    var directive = {
        restrict: 'E',
        template: '<label class="radio" ng-repeat="$item in options track by $item.key" ng-class="{checked:$item.selected}" ng-click="clickItemEvent($event, $item)"><ins class="uIcon" ng-click="$event.stopPropagation()"></ins><input type="radio" class="valid"><span class="label" ng-click="$event.stopPropagation()" ng-bind="$item.value"></span></label>',
        replace: true,
        transclude: false,
        scope: {
            options: '=options',
            select: '=select',
            change: '=change'
        },
        link: link
    };

    function link($scope, element, attrs) {
        // 取消所有选中
        angular.forEach($scope.options, function(option) {
            // 找到第一个selected为true的对象
            if (option.selected) {
                // 触发选中事件
                chooseEvent(option);
                return true;
            }
            // 其余对象都设置为fasle，防止出现多个默认值的情况
            option.selected = false;
        });
        $scope.clickItemEvent = function($event, $item) {
            angular.forEach($scope.options, function(option) {
                option.selected = false;
            });
            chooseEvent($item);
            $event.stopPropagation();
        };
        // 选中事件
        function chooseEvent(option) {
            debugger;
            // 设置当前选中状态
            option.selected = true;
            // 内部选中对象
            $scope.selectedItem = option;
            // 外部选中对象
            if (angular.isObject($scope.select)) {
                $scope.select = option;
            }
            // 触发改变事件
            changeEvent($scope.selectedItem);
        }
        // 改变事件
        function changeEvent(option) {
            debugger;
            // 判断是否为函数
            if (angular.isFunction($scope.change)) {
                // 触发选择事件 传入3个对象
                $scope.change(option.key, option.value, option);
            }
        }
    }
    return directive;
});

angular.module('uee.ui').directive('ocSelect', function($UEE, $Fire,$interpolate,$cacheFactory) {
    //全局缓存
    var dictCaches = $cacheFactory.get('uee.ui.filter.dictCodeCaches') || $cacheFactory('uee.ui.filter.dictCodeCaches');
    var checkedDigestFlag = true;
    
    return {
        restrict: 'A',
        link: function(scope, elem, attrs) {
            
            function displayDefaultValue(key,items){
                angular.forEach(items,function(item){
                    if(item.key == key){
                        item.selected = true;
                    }else if(item.selected == true){
                        item.selected=false;
                    }
                })
            }
            // 标记，是否使用数据字典
            var useDictCode = attrs.dictcode && "" !== attrs.dictcode;
            
            var xProperty = $UEE.property(attrs.property || "");
            var xDefaultKey = attrs.defaultKey;
            var obj;
            if (!attrs.items && !useDictCode) {
                obj = new OC_Droplist.Droplist(elem, {});
                return;
            }

            var xItems;
            scope.itemProperty = $UEE.property(attrs.items || "");
            var id = attrs.id ? $interpolate(attrs.id)(scope) : "oc_select" + $.now();
            elem.attr("id", id);
            var isMultiple = (attrs.multiple == "");
            scope.destroyThisWatch = scope.$watch(function() {
                return $UEE.propertyValue(scope, $UEE.property(attrs.items || ""))
            }, function(newV, oldV) {
                if (useDictCode || !newV ) return;
                xItems = $UEE.propertyValue(scope, $UEE.property(attrs.items || "")) || {};
                if(xDefaultKey && "" !== xDefaultKey){
                    displayDefaultValue(xDefaultKey,xItems);
                }
                if (obj) {
                    obj.refreshItem(xItems);
                } else {
                    obj = new OC_Droplist.Droplist(elem, xItems);
                    if (isMultiple) {
                        obj.enableSingle();
                    }
                    obj.init();
                }
            },true);
            
            // 监控下拉框控制信息
            scope.destroyDictcodeWatch = scope.$watch(function() {
                if (attrs.dictcode && "" !== attrs.dictcode) {
                    return attrs.dictcode;
                }
            }, function(newV, oldV) {
                if (!newV) {
                    return;
                }
                if(!dictCaches.get(newV)){
                    // 中转信号位，防止脏值检查时多次触发请求(必须要判断，否则会存在死循环)
                    dictCaches.put(newV, checkedDigestFlag);
                    var dictCodeArry = newV.split(",");
                    
                    // 调用后台服务获取字典
                    $Fire({
                        service: '/common/dictkey2',
                        params: {
                            'dictkeylist': dictCodeArry
                        },
                        target: "data"
                    }).onafter(function(data) {
                        xItems=[];
                        angular.forEach(data, function (dictItem) {
                            xItems=xItems.concat(dictItem);
                        });
                        //通过查询字典的方式，添加清空下拉框的能力
                        xItems.splice(0,0,{
                            'key' : '',
                            'value' : $UEE.i18n("ad.person.option.SelectOption"),
                            "selected" : true
                        })
                        if(xDefaultKey && "" !== xDefaultKey){
                            displayDefaultValue(xDefaultKey,xItems);
                        }
                        
                        if (obj) {
                            obj.refreshItem(xItems);
                        } else {
                            obj = new OC_Droplist.Droplist(elem, xItems);
                            if (isMultiple) {
                                obj.enableSingle();
                            }
                            obj.init();
                        }
                        
                        if(data[newV] && data[newV].length>0){
                            dictCaches.put(newV, data[newV]);
                        }
                    });
                }else{
                    xItems = dictCaches.get(newV) || [];
                    if(xDefaultKey && "" !== xDefaultKey){
                        displayDefaultValue(xDefaultKey,xItems);
                    }
                    if (obj) {
                        obj.refreshItem(xItems);
                    } else {
                        obj = new OC_Droplist.Droplist(elem, xItems);
                        if (isMultiple) {
                         obj.enableSingle();
                        }
                        obj.init();
                 }
                }
                
            });
            
            elem.find("input").on("change", function(event) {
                if (isMultiple) {
                    var value = obj.selectItemKeyArray;
                    if (angular.equals(value, $UEE.propertyValue(scope, xProperty))) {
                        return;
                    }
                    if (attrs.property) {
                        scope.$apply(function() {
                            $UEE.propertyValue(scope, xProperty, value);
                        });
                    }
                } else {
                    var value = $(event.target).attr("key");
                    if (value == $UEE.propertyValue(scope, xProperty)) {
                        return;
                    }
                    debugger;
                    if (attrs.property) {
                        scope.$apply(function() {
                            $UEE.propertyValue(scope, xProperty, value);
                        });
                    }
                }
                // 修改UEE下拉框校验事件bug，原先下拉框选中后，必须在空白处点击才能使红色消失
                $(event.target).valid();
            });
            
            
            if (isMultiple) {
                scope.$watch(xProperty, function(newV, oldV) {
                    if (isMultiple) {
                        // select the options
                        if (newV != undefined && newV != null) {
                            if (angular.equals(newV, obj.selectItemKeyArray)) {
                                return;
                            }
                            obj.selectItem(newV);
                        }

                    }
                });
            } else {
                scope.$watch(xProperty, function(newV, oldV) {
                	debugger;
                	debugger;
                    var inputEle = elem.find("input");
                    if (newV == undefined || newV === "") {
                        inputEle.attr("key", '');
                        inputEle.val("");
                        inputEle = null;
                        return;
                    }
                    if (newV !== inputEle.attr("key") && obj) {
                        obj.selectItem(newV);
                    }
                    inputEle = null;
                });
            }
            
            // on destroy event to clean memory  Joey
            scope.unbindDestroyEvent =  scope.$on("$destroy", function(){
                if(obj){
                    obj.$container = null;
                    obj.$dom = null;
                    obj.$header = null;
                    obj.$input = null;
                    obj.$optionUl = null;
                    obj.$options = null;
                    obj.$trigger = null;
                    obj.data = null;
                    obj.itemsArray = null;
                    if(obj._settings){obj._settings.container = null;}
                    obj = null;
                }
                if(elem){
                    elem.removeData();
                    elem = null;
                }
                if(scope && scope.unbindDestroyEvent)
                {
                    scope.unbindDestroyEvent();
                    scope.unbindDestroyEvent = null;
                }
                
            });
        }
    };
});

/***  可搜索下拉框指令 w00244215/l00278840 20150715  ***/
angular.module('uee.ui').directive('ocSelectInput', function($UEE, $interpolate, $filter) {
    return {
        restrict: 'A',
        link: function(scope, elem, attrs) {
            var xProperty = $UEE.property(attrs.property || "");
            var obj;
            //var obj = new OC_Droplist.Droplist(elem, {});
            if (!attrs.items) {
                obj = new OC_Droplist.Droplist(elem, {});
                return;
            }
            var xItems;
            scope.itemProperty = $UEE.property(attrs.items);
            var id = attrs.id ? $interpolate(attrs.id)(scope) : "oc_select" + $.now();
            elem.attr("id", id);

            scope.$watch(function() {
                return $UEE.propertyValue(scope, $UEE.property(attrs.items))
            }, function(newV, oldV) {
                if (newV) {
                    xItems = $UEE.propertyValue(scope, $UEE.property(attrs.items)) || {};
                    if (obj) {
                        obj.refreshItem(xItems);
                        // 更换选项之后判断当前值是否还在选项列表中，如果不在，就将输入框清空
                        var $input = elem.find("input");
                        var inputkey = $input.attr("key");
                        if (!obj.inItem(inputkey)) {
                            $input.val("");
                        }
                    } else {
                        obj = new OC_Droplist.Droplist(elem, xItems);
                        obj.init();
                    }
                }
            });
            
            
            // 下拉输入框失去焦点时判断下当前是否有选中值，如果没有就清空当前输入框
            elem.find("input").on("blur", function(event) {
                debugger;
                var $input = $(event.target);
                var inputkey = $input.attr("key");
                
                // DTS2017021800940 下拉选项为空时，清空当前输入框
                var objData = obj.data;
                if(!objData)
                {
                    $(event.target).val("");
                }

                // DTS2017021800940  输入值是否在下拉选项中(通过value值进行判断）
                for (var i = 0; i < objData.length; i++) 
                {
                    if($input.val() == objData[i].value)
                    {
                        return;
                    }
                }
                
                //IE 下 搜索功能不可用
//                if(!inputkey){
//                    $(event.target).val("");
//                }
            });
            
            // view to model
            elem.find("input").on("input change propertychange", function(event) {

                if (event.type == "change" && !event.isTrigger) {
                    return;
                }
                var $input = $(event.target);
                
                var inputkey = $input.attr("key");
                var value = obj.inItem(inputkey) ? inputkey : $input.val();
                var valueTemp = value;

                if (event.type == "input" || event.type == "propertychange") {
                    value = $input.val();
                    if (obj.$dom.data("hisData") === value)
                        return;
                    // show options for this combobox
                    if ($.oc_droplists[id] && xItems && value) {
                        var width = $.oc_droplists[id].$dom.outerWidth(true);
                        var left = $.oc_droplists[id].$dom.offset().left;
                        var _ysp_top = $.oc_droplists[id].$dom.offset()._ysp_top + $.oc_droplists[id].$dom.outerHeight(true);
                        $.oc_droplists[id].$options.css({ "left": left, "_ysp_top": _ysp_top, "width": $.oc_droplists[id]._settings.optionClass ? width - 2 : width - 4 }).show();
                        var lis = $.oc_droplists[id].$options.find("li");
                        lis.hide();
                        var i = 0; //number of shown droplist item
                        var val = "";
                        for (var j = 0, jj = xItems.length; j < jj; j++) {
                            var tempKey = xItems[j].key;
                            var tempValue = xItems[j].value;
                            if (tempValue.indexOf(value) != -1) {
                                $.oc_droplists[id].$options.find("li[key=" + tempKey + "]").show();
                                i++;
                                val = (val === "") && (value === tempValue) ? tempKey : val;
                            }
                        }

                        if (value.length > 0 && attrs.property) {
                            value = i == 0 ? "" : val;
                            scope.$apply(function() {
                                $UEE.propertyValue(scope, xProperty, value);
                                $input.attr("key", value);
                            });

                        }
                    }
                    //当删除搜索框内容时展示所有选项start
                    if(!value&&!valueTemp){
                        var width = $.oc_droplists[id].$dom.outerWidth(true);
                        var left = $.oc_droplists[id].$dom.offset().left;
                        var _ysp_top = $.oc_droplists[id].$dom.offset()._ysp_top + $.oc_droplists[id].$dom.outerHeight(true);
                        $.oc_droplists[id].$options.css({ "left": left, "_ysp_top": _ysp_top, "width": $.oc_droplists[id]._settings.optionClass ? width - 2 : width - 4 }).show();
                        var lis = $.oc_droplists[id].$options.find("li");
                        lis.hide();
                        var i = 0; //number of shown droplist item
                        var val = "";
                        for (var j = 0, jj = xItems.length; j < jj; j++) {
                            var tempKey = xItems[j].key;
                            var tempValue = xItems[j].value;
                            $.oc_droplists[id].$options.find("li[key=" + tempKey + "]").show();
                            i++;
                            val = (val === "") && (value === tempValue) ? tempKey : val;
                        }

                        if (value.length > 0 && attrs.property) {
                            value = i == 0 ? "" : val;
                            scope.$apply(function() {
                                $UEE.propertyValue(scope, xProperty, value);
                                $input.attr("key", value);
                            });

                        }
                    }
                    //当删除搜索框内容时展示所有选项end
                    obj.$dom.data("hisData", $input.val());
                    return;
                }
                if (value == $UEE.propertyValue(scope, xProperty)) {
                    return;
                }
                if (attrs.property) {
                    scope.$apply(function() {
                        $UEE.propertyValue(scope, xProperty, value);
                    });
                }
            });

            // model to view
            scope.$watch(xProperty, function(newV, oldV) {
                var inputEle = elem.find("input");
                if (obj.inItem(newV) && newV != inputEle.attr("key")) {
                    obj.selectItem(newV);
                }
                inputEle = null;
            });
        }
    };
});
/***  集团可搜索下拉框指令 支持{'a':'xx'} 或者{"a":"xx"}的key ***/
angular.module('uee.ui').directive('ocSelectGroupInput', function($UEE, $interpolate, $filter) {
    return {
        restrict: 'A',
        link: function(scope, elem, attrs) {
            var xProperty = $UEE.property(attrs.property || "");
            var obj;
            //var obj = new OC_Droplist.Droplist(elem, {});
            if (!attrs.items) {
                obj = new OC_Droplist.Droplist(elem, {});
                return;
            }
            var xItems;
            scope.itemProperty = $UEE.property(attrs.items);
            var id = attrs.id ? $interpolate(attrs.id)(scope) : "oc_select" + $.now();
            elem.attr("id", id);

            scope.$watch(function() {
                return $UEE.propertyValue(scope, $UEE.property(attrs.items))
            }, function(newV, oldV) {
                if (newV) {
                    xItems = $UEE.propertyValue(scope, $UEE.property(attrs.items)) || {};
                    if (obj) {
                        obj.refreshItem(xItems);
                    } else {
                        obj = new OC_Droplist.Droplist(elem, xItems);
                        obj.init();
                    }
                }
            });

            // view to model
            elem.find("input").on("input change propertychange", function(event) {

                if (event.type == "change" && !event.isTrigger) {
                    return;
                }
                var $input = $(event.target);
                
                var inputkey = $input.attr("key");
                var value = obj.inItem(inputkey) ? inputkey : $input.val();

                if (event.type == "input" || event.type == "propertychange") {
                    value = $input.val();
                    if (obj.$dom.data("hisData") === value)
                        return;
                    // show options for this combobox
                    if ($.oc_droplists[id] && xItems && value) {
                        var width = $.oc_droplists[id].$dom.outerWidth(true);
                        var left = $.oc_droplists[id].$dom.offset().left;
                        var _ysp_top = $.oc_droplists[id].$dom.offset()._ysp_top + $.oc_droplists[id].$dom.outerHeight(true);
                        $.oc_droplists[id].$options.css({ "left": left, "_ysp_top": _ysp_top, "width": $.oc_droplists[id]._settings.optionClass ? width - 2 : width - 4 }).show();
                        var lis = $.oc_droplists[id].$options.find("li");
                        lis.hide();
                        var i = 0; //number of shown droplist item
                        var val = "";
                        for (var j = 0, jj = xItems.length; j < jj; j++) {
                            var tempKey = xItems[j].key;
                            var tempValue = xItems[j].value;
                            if (tempValue.indexOf(value) != -1) {
                                if(tempKey.indexOf("'") != -1)
                                {
                                    $.oc_droplists[id].$options.find("li[key=\"" + tempKey + "\"]").show();
                                }
                                else if(tempKey.indexOf("\"") != -1)
                                {
                                    $.oc_droplists[id].$options.find("li[key='" + tempKey + "']").show();
                                }
                                else
                                {
                                    $.oc_droplists[id].$options.find("li[key=" + tempKey + "]").show();
                                }
                                i++;
                                val = (val === "") && (value === tempValue) ? tempKey : val;
                            }
                        }

                        if (value.length > 0 && attrs.property) {
                            value = i == 0 ? "" : val;
                            scope.$apply(function() {
                                $UEE.propertyValue(scope, xProperty, value);
                                $input.attr("key", value);
                            });

                        }
                    }
                    obj.$dom.data("hisData", $input.val());
                    return;
                }
                if (value == $UEE.propertyValue(scope, xProperty)) {
                    return;
                }
                if (attrs.property) {
                    scope.$apply(function() {
                        $UEE.propertyValue(scope, xProperty, value);
                    });
                }
            });

            // model to view
            scope.$watch(xProperty, function(newV, oldV) {
                var inputEle = elem.find("input");
                if (obj.inItem(newV) && newV != inputEle.attr("key")) {
                    obj.selectItem(newV);
                }
                inputEle = null;
            });
        }
    };
});
angular.module("uee.ui").directive("adDrag", ["$timeout", function($timeout) {
    debugger;
    return {

        restrict: "A",
        scope: true,
        link: function(scope, element, attrs) {
                //get options's model value.
                //colResizable provides some customization attributes in order to modify its appearance.
                var options = scope.$eval(attrs.options);
                $timeout(function() {
                    element.colResizable(options);
                }, 0, false);
            } //end link
    } //end return
}]);

angular.module('uee.ui').directive('ocTab', function($UEE, $window) {
    return {
        restrict: 'A',
        transclude: true,
        scope: true,
        template: function(elem, attrs) {
	    	return ['<div class="tab">',
	                   '<div class="tab_nav">',
                           '<ul class="clearfix">',
                               '<li id="uiTabUlLi{{$Item.key}}" ng-repeat="$Item in $uiTab.xItems" ng-show="!$Item.isHide" ',
                                   'ng-click="$uiTab.tabLiClick($Item)"',
                                   'ng-class="{active:$Item.isActive, last:$Item.isLast, disabled: $Item.disabled}">',
                                   '<span ng-bind="$Item.value"></span>',
                               '</li>',
                           '</ul>',
                       '</div>',
                       '<div class="transcluded" ng-transclude></div>',
                   '</div>'].join("");
	    },
        link: function(scope, elem, attrs) {
            $(".tab_content", elem).hide();
            scope.$uiTab = {};

            scope.$watchItems = scope.$watch(attrs.items, function(newV) {
                if (newV) {
                	$(".tab_content", elem).hide();
                    scope.$uiTab.xItems = newV;

                    // 锁定最后的tab
                    var lastItem = null;
                    // 是否有默认选中的tab,如果没有,则默认第一个选中
                    var activeItem = null;
                    // 第一个非灰化的tab
                    var firstActivateItem = null;
                    $.each(scope.$uiTab.xItems, function(i, vali) {
                    	vali.isLast = false;
                        if (!vali.isHide) {
                            lastItem = vali;
                        }
                        if (vali.isActive && !vali.disabled) {
                            activeItem = vali;
                        }
                        if (!vali.isHide && !vali.disabled && !firstActivateItem) {
                            firstActivateItem = vali;
                        }
                    });
                    if (lastItem) {
                        lastItem.isLast = true;
                    }

                    // 设置默认选中的tab
                    if (!activeItem) {
                        activeItem = firstActivateItem || {};
                    }
                    activeItem.isActive = true;
                    $(".tab_content[key='" + activeItem.key + "']", elem).show();
                }
            }, true);

            // 绑定点击事件
            scope.$uiTab.tabLiClick = function($Item) {
                if ($Item.disabled || $Item.isHide || $Item.isActive) {
                    return;
                }

                $.each(scope.$uiTab.xItems || [], function(i, vali) {
                    vali.isActive = false;
                });
                $Item.isActive = true;

                $(".tab_content", elem).hide();
                $(".tab_content[key='" + $Item.key + "']", elem).show();

                var jpageEvent = $.Event("tabClick");
                jpageEvent.$Data = {
            		$Item: $Item
                };
                elem.find(".transcluded").trigger(jpageEvent);
            };
            
            // 清理数据
            /*scope.$on("$destroy", function() {
                elem.remove();
                scope.$uiTab = null;
                if (scope.$watchItems) {scope.$watchItems();scope.$watchItems = null;}
            });*/
        }
    };
});

/*=========================================uiTree start============================================*/
/**
 * ocTree
 * 	是一个树组件
 *  使用样例：
 *  <div oc-tree tree-data="$Page.treeData" item-type="checkbox" all-can-selected="true">
       <uee:fire event="treeItemCheckedChange" script="$Controller.adTree.itemCheckedChange($Page, $Get('$Fire'), jEvent);"></uee:fire>
       <uee:fire event="treeItemExpandChanged" script="$Controller.adTree.itemExpandChanged($Page, $Get('$Fire'), jEvent);"></uee:fire>
   </div>

    其中：
    	tree-data -- 树所使用的json数据，Object类型。必填。
    	具体属性如下：
    	  json类型的数据。样例请参见本章节的“使用数据样例”。
    	  key：选中节点获取的值。String类型。必填。
    	  name：节点显示的名字。String类型。必填。
    	  checked：是否默认选中节点。true：选中；false：不选中。默认不选中。选填。
    	  expand：是否默认展开叶子节点。true：展开；false：不展开。默认不展开。选填。
    	  children：叶子节点信息。选填。
        item-type -- 树中各个节点类型，String。checkbox：复选框类型；radio：单选按钮类型。选填。
        all-can-selected -- 是否所有节点都可选择，boolean。true：所有节点都可选择；false：非叶子节点不可选择。默认非叶子节点不可选择。选填。

        treeItemCheckedChange事件，选中某一节点时发出的事件。
        treeItemExpandChanged事件，单击折叠按钮时发出的事件。
 */
angular.module('uee.ui').directive('ocTree', function($UEE, $window) {
    return {
        restrict: 'A',
        transclude: true,
        templateUrl: $UEE.$Webapp + "/bes/ad/js/directiveview/treeView.html",
        scope: true,
        link: function($scope, elem, attrs) {
            $scope.treeItemUrl = $UEE.$Webapp + "/bes/ad/js/directiveview/treeItem.html";
            $scope.checkChildren = function(item) {
                if ($scope.isLeaf(item)) {
                    return;
                }

                var len = item.children.length;
                for (var i = 0; i < len; i++) {
                    var child = item.children[i];
                    child.checked = item.checked;

                    $scope.checkChildren(child);
                }
                return;
            };
            $scope.resetAllChildren = function(item) {
                item.checked = false;
                if ($scope.isLeaf(item)) {
                    return;
                }

                var len = item.children.length;
                for (var i = 0; i < len; i++) {
                    var child = item.children[i];
                    $scope.resetAllChildren(child);
                }
            };
            $scope.checkParent = function(item) {
                item.children = item.children || [];
                var allAnd = true;
                var allOr = false;

                var len = item.children.length;
                for (var i = 0; i < len; i++) {
                    var child = item.children[i];
                    var childChecked = $scope.checkParent(child);
                    allAnd = allAnd && childChecked;
                    allOr = allOr || childChecked;
                }
                if ($scope.isLeaf(item)) {
                    return item.checked;
                }

                if (allAnd) {
                    item.checked = true;
                } else {
                    item.checked = false;
                }
                return item.checked;
            };

            $scope.$watch(attrs.treeData, function(newV, oldV) {
                if (newV) {
                    $scope.itemType = attrs.itemType;
                    $scope.hideCheck = attrs.hideCheck;
                    var newTreeData = $.extend(true, {},
                    newV);
                    $scope.treeData = [];
                    $scope.treeData.push(newTreeData);
                    $scope.allCanSelected = attrs.allCanSelected == "true";
                    $scope.elem = elem;
                    $scope.showSelection = attrs.showSelection;
                    $scope.cannotShrink = attrs.cannotShrink;
                }
            });

            $scope.itemExpended = function(item, $event, $scope) {
				debugger;
                item.expand = !item.expand;
                $event.stopPropagation();

                var jpageEvent = $.Event("treeItemExpandChanged");
                jpageEvent.$Data = item;
                elem.find(".transcluded").trigger(jpageEvent);
            };

            $scope.itemClicked = function(item, $event, $scope) {
				debugger;
                if (item.disabled) {
                    $event.stopPropagation();
                    return;
                }
				/**
                if (!$scope.isLeaf(item) && (!$scope.allCanSelected || $scope.itemType == "radio") && !$scope.cannotShrink) {
                    $scope.itemExpended(item, $event, $scope);
                    return;
                }
				*/

                if ($scope.itemType == "radio") {
                    $scope.resetAllChildren($scope.treeData[0]);
                }

                item.checked = !item.checked;

                /*if ($scope.itemType == "checkbox" && $scope.allCanSelected) {
                    if (!$scope.isLeaf(item)) {
                        $scope.checkChildren(item);
                    }
                    for (var i = 0; i < $scope.treeData.length; i++) {
                        $scope.checkParent($scope.treeData[i]);
                    }
                }*/

                $event.stopPropagation();
                var jpageEvent = $.Event("treeItemCheckedChange");
                if(item.needparent != undefined && item.needparent){
                	jpageEvent.$ParentDate = $scope.treeData[0];
                }
                jpageEvent.$Data = item;

                elem.find(".transcluded").trigger(jpageEvent);
            },

            $scope.isLeaf = function(item) {
                return !item.children || !item.children.length;
            };
        }
    };
});
/*=========================================uiTree end==============================================*/
