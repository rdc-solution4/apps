var OC_Droplist = OC_Droplist || {Core:jQuery};
/**模拟html select组件，并提供丰富的设置\方式。
 *  包括样式，事件，每个option项的定制。支持多选和单选下拉菜单
 * @id Droplist
 */
function preventScroll(ele){
    var _this = ele;
    if(navigator.userAgent.indexOf("Firefox")>0){
        _this.addEventListener('DOMMouseScroll',function(e){
            _this.scrollTop += e.detail > 0 ? 20 : -20;
            e.preventDefault();
        },false);
    }else{
        _this.onmousewheel = function(e){
            e = e || window.event;
            _this.scrollTop += e.wheelDelta > 0 ? -20 : 20;
            return false;
        };
    }
    return this;
}

(function(ucd,$){
	if(!$.oc_droplists){
		$.oc_droplists = {};
	}
	var COUNT = 0;
	ucd.Droplist = function(container, data, onCreateItem,childItem){
		this._settings = $.extend({
			container:container,
			data: angular.copy(data),
			inputEnable:false,
			isSingle:true,
			onValueChange:null,
			disabled: false,
			onCreateItem:onCreateItem,
			childItem :childItem
		},{});
		
		_initDom(this);
		_initEvent(this);
	}
	//初始化dropList
	function _initDom(self){
		var settings = self._settings;
		var containerId = settings.container.attr("id");
		if(containerId==undefined || containerId == ""){
			containerId = "droplist" + $.now();
		}
		self.hidden = true;
		self.itemsArray = [];
		var uuid = self.uuid = createMarker("udrop");
		self.$container = validateParamType(settings.container);
		self._settings.width = self.$container.width() != 0 ? self.$container.width() : self._settings.width;
//		self.$dom = $("<div class='Droplist' data-uuid='"+uuid+"'/>").appendTo(self.$container);
//		self.$header = $("<div class='DroplistHeader'/>");
		self.$dom = self.$container.children(".Droplist");
		self.$header = self.$dom.children();
/*		if(settings.inpuEnable){
            self.$input = $("<input type='text' class='inputbox ellipsis' />").appendTo(self.$header);
        }else{
            self.$input = $("<input type='text' id='input_"+uuid+"' readonly='readonly' unselectable='on' onfocus='this.blur()' class='inputbox ellipsis' ng-model='$ChildItem.value'/>").appendTo(self.$header);
        }*/
		////self.$input = $("<input type='text' class='inputbox ellipsis' />").appendTo(self.$header);
		self.$input = self.$header.children("input");
 		self.$trigger = $("<span class='trigger' id='ocTrigger"+ containerId + uuid + "'></span>").appendTo(self.$header);
		self.$options = $("<div class='DroplistOption' data-uuid='"+uuid+"'><ul></ul></div>").appendTo(document.body);//下拉选项
		if(self.$container.hasClass("searchDrop")) {
			self.$options.addClass("searchDropOption");
		}
		self.$optionUl = self.$options.children("ul");
		self.$dom.append(self.$header);
		self.setData(settings.data);
		
		preventScroll(self.$options.get(0));
		$.oc_droplists[containerId] = self;
	}
	function _initEvent(self){
		self.$header.find("input").bind("mousedown",function(){this.focus();})  //解决chrome下事件无法透传的问题
		self.$header.bind("click" ,function(){
			//debugger;
			if (self._settings.disabled) {
				return false;
			}
			
			var display = self.$options.css("display");
			if(display == "none"){
				var left = self.$dom.offset().left;
				var _ysp_top = self.$dom.offset()._ysp_top+self.$dom.outerHeight(true);
				var width = self.$dom.outerWidth(true);
                $(".DroplistHeader").removeClass("blueBorder");
                $(".DroplistHeader").removeClass("down");
                $(".DroplistOption").hide();
                self.$header.addClass("down");
				//self.$options.css({"left":left,"_ysp_top":_ysp_top,"width":width-4}).show();
				self.$options.css({"left":left,"_ysp_top":_ysp_top,"width":self._settings.optionClass?width-2:width-4}).show();
				self.$options.find("li").show();//Joey testing code
				var index = self.$options.find("ul li.selected").index()-3;
				//第一次时没有搜索到
				if(index < 0){
					if(self.$dom.find('input').val() && self.$dom.find('input').val() != ''){
						var inputVal = self.$dom.find('input').val();
						var li = self.$options.find("li[title='"+inputVal+"']");
						if(li.length == 1){
							self.$options.find("li").removeClass("selected");
							li.addClass("selected");
							index = li.index();
						}
					}
				}
				//上边框高度为1，需要+1计算高度
                var scrollTop = (self.$options.find("ul li.selected").height()+1)*index;
                self.$options.scrollTop(scrollTop);
                	
				$(this).parent().addClass("blueBorder");
			}else{
				$(this).parent().removeClass("blueBorder");
                self.$header.removeClass("down");
                $(".DroplistHeader").removeClass("blueBorder");
                $(".DroplistHeader").removeClass("down");
                $(".DroplistOption").hide();
				self.$options.hide();
			}
            return false;
		});
		//绑定双击时间触发选中输入内容
		/*self.$header.find("input").bind("dblclick" ,function(){
			debugger;
			self.$header.find("input").select();
            return false;
		});*/
		
		//点选项
		self.$options.delegate(".dropItem","click",function(e){
			//debugger;
			var target = e.target;
			var $target = $(target);
			var index = $(this).index();
			_select(self,index);
            return false;
		});
		var timeStamp=(new Date()).getTime();//Date.valueOf();
		//点文档空白处隐藏
        self.$options.bind("mousedown."+timeStamp,function(e){
            return false;
        });
        
        
        
		$("body").unbind("mousedown."+timeStamp).bind("mousedown."+timeStamp,function(e){
			var $target = $(e.target);
			// 增加判空处理，UCD这个代码应该提供销毁函数，以便于droplist的DOM移除时候清理绑定事件!
			if(self.$dom && self.$options){
				if( $target.closest(".Droplist")[0] != self.$dom[0] && $target.closest(".DroplistOption")[0] != self.$options[0] ){
					$(".DroplistOption").hide();
					$(".DroplistHeader").removeClass("blueBorder");
					$(".DroplistHeader").removeClass("down");
					self.$options.hide();
				}
			}
		});
	}
	
	function _createItem(data,self,index){
		var settings = self._settings;
		var items = {};
		items.params = $.extend({
			key:"title",
			value:"",
			selected:false
		},data || {});
		items.index = index;
		items._title = items.params.value.replace(/</gim,"&lt;").replace(/>/gim,"&gt;");
		var multiple = this.multiple = !settings.isSingle;//多选模式
		var html = multiple ? ("<li class='dropItem' title='"+items._title+"' id='agentdesktop"+self.uuid+items.params.key+"'  key='"+items.params.key+"'><ins></ins><span>"+items._title+"</span></li>") : ("<li class='dropItem' title='"+items._title+"' id='agentdesktop"+self.uuid+items.params.key+"' key='"+items.params.key+"'><span>"+items._title+"</span></li>")
		items.$li = $(html).appendTo(self.$optionUl);
		self.itemsArray.push(items);
		if(items.params.selected){
			_select(self,index);
		}
		if($.isFunction(self._settings.onCreateItem)){
			_callback(self._settings.onCreateItem,self,[items]);
		}
	}
	//选中
	function _select(self,index,isSelectAll){
		var li = self.$options.find("li:eq("+index+")");
		self.selectItemArray = [];
		self.selectItemKeyArray = [];
		if(self._settings.isSingle){   //单选
			self.$header.removeClass("blueBorder");
			self.$options.find("li").removeClass("selected");
			li.addClass("selected");
			self.$input.val(li.text());
            self.$input.attr("key",li.attr("key"));
            self.$input.change();
            if(self._settings.childItem){
            	//self._settings.childItem.value = li.attr("key");
            }
			self.$options.hide();
            self.$header.removeClass("down");
			self.selectItemArray.push(li.text());	
		}else{
			if(isSelectAll == true){
				li.addClass("selected");
			}
			else if(isSelectAll == false){
				li.removeClass("selected");
			}else if(isSelectAll == "modelToView"){
				li.removeClass("selected").addClass("selected");
			}else{
				var selected = li.hasClass("selected");
				if(selected){
					li.removeClass("selected");
				}else{
					li.addClass("selected");
				}
			}
			self.$options.find("li").each(function(){
				if($(this).hasClass("selected")){
					self.selectItemArray.push($(this).text());
					self.selectItemKeyArray.push($(this).attr("key"));					
				}
			});
			self.$input.val(self.selectItemArray.join(","));
			self.$input.attr("key",self.selectItemKeyArray.join(","));
			if(isSelectAll != "modelToView"){
				self.$input.change();
			}
		}
		if($.isFunction(self._settings.onValueChange)){
			_callback(self._settings.onValueChange,self,[self,self.itemsArray[index]]);
		}
	}
	function validateParamType(obj){
		if(!obj) return;
		if(typeof obj=="string"&&obj.indexOf("#")==-1&&obj.indexOf(".")==-1&&obj.indexOf(":")==-1&&$(obj).length == 0){
			obj = $("#"+obj);
		} else {
			obj = $(obj);
		}
		return obj;
	}
	
	//创建一个唯一标识
	function createMarker(pre){
		return pre+("00000000"+(++COUNT)).substr(-5);
	}
	
	ucd.Droplist.prototype = {
		init: function(){
			this.itemsArray = [];//清空子对象
			//清空DOM
			this.$optionUl.html("");
			//添加子对象
			for(var i=0;i<this.data.length;i++){
				this.addItem(this.data[i],i);
			}
		},
		//设置数据
		setData: function(data){
			var settings = this._settings;
			if(!data){
				return;
			}
			this.data = data;
		},
		
		//设置数据
		setDisabled: function(disabled){
			this._settings.disabled = disabled;
		},
		/**
		 * 添加一条数据	
		 * @option:Object, 
		*/
		addItem: function(data,index){
			if(typeof index == "undefined"){
				index = this.data.length;
				this.data.push(data);
			}
			var item = _createItem(data,this,index);
		},
		/**
		 * 更新下拉数据
		 */
		refreshItem : function(data){
			if(angular.isArray(data)){
				this.data.length = 0;
				this.data = data;
				this.itemsArray = [];
				this.$optionUl.children("li").remove();
				for(var i = 0; i <data.length; i++){
					_createItem(data[i],this,i);
				}
			}
		},
		
		/**
		 * 选中项	 根据标题选中对应item项
		 */
		selectItem : function(key){
			var selectSuccess = false;
			if(!this._settings.isSingle){
				var selectItemKeys = angular.isArray(key) ? key : key.split(",");
				this.$options.find("li").removeClass("selected");
				var settings = this._settings;
				if(selectItemKeys.length==0){
					_select(this, 0, false);
					selectSuccess = true;
				}
				for(var i=0;i<this.itemsArray.length;i++){
					for(var j=0;j<selectItemKeys.length;j++){
						if(this.itemsArray[i].params.key==selectItemKeys[j]){
							_select(this,i,"modelToView");
							selectSuccess = true;
						}
					}
				}
			}else{
				var settings = this._settings;
				for(var i=0;i<this.itemsArray.length;i++){
					if(this.itemsArray[i].params.key == key){
						_select(this,i);	
						selectSuccess = true;
					}
				}
			}
			return selectSuccess;
		},
		/**
		 * 输入值是否在下拉选项中
		 */
		inItem : function(key){
			var selectSuccess = false;
			var settings = this._settings;
			for(var i=0;i<this.itemsArray.length;i++){
				if(this.itemsArray[i].params.key == key){
					selectSuccess = true;
				}
			}
			return selectSuccess;
		},
		selectAll: function(flag){
			if(!this._settings.isSingle){
				for(var i=0;i<this.itemsArray.length;i++){
					_select(this,i,flag);	
				}	
			}
		},
		/**
		 * 设置输入框能否支持输入
		 * @isEnable Boolean
		 */
		enableInput: function(flag){
			this._inputEnable = flag;
			if(flag){
				this.$input.removeAttr("readonly");
			}else{
				this.$input.attr("readonly","true");
			}
		},
		enableSingle: function(flag){
			this._settings.isSingle = flag;	
		},
		setOnValueChange: function(fn){
			this._settings.onValueChange = fn;
		}
	}
	function _callback(fn,context,args){
		if(typeof fn == "function"){
			if($.type(args) != "array"){
				return fn.call(context,args);
			}
			var aLen = args.length,a1 = args[0],a2 = args[1],a3 = args[2];
			switch(aLen){
				case 1:
					return fn.call(context,a1);
					break;
				case 2:
					return fn.call(context,a1,a2);
					break;
				case 3:
					return fn.call(context,a1,a2,a3);
					break;
				default:
					return fn.apply(context,args);
					break;
			}
		}
	}

})(OC_Droplist,OC_Droplist.Core);