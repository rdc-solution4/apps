var oldFlag = false;
var newFlag = false;
$Controller(
		"bes.oc.modifypwd",
		{
			init : function($Page, $Gadget, $Fire, $UI) {
				debugger;
				var request = {
					header : {
						loginToken : "",
						loginId : "",
						locale : "",
						serialId : ""
					},
					body : {

					}
				};

				OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId()); 
				$Fire({
					service : 'agentdesktop/v1/person/initmdypwd',
					params : request,
					target : '$Gadget.data',
					onafter : function($Gadget) {
						debugger;
						$Controller.bes.oc.modifypwd.isHaveChgUserPassAuth($Gadget);
						
					}
				}, $Gadget);
				this.menuCheck($Page, $Gadget, $Fire, $UI);

			},
			
			//判断操作员是否有强制修改用户密码令牌
			isHaveChgUserPassAuth : function($Gadget){
				$Fire=$Gadget.$Get('$Fire');
				var req='chguserpass';
				$Fire({
					service : 'ocauthenticationboservice/checkauthbyloginidauth',
					params : {"req": req },
					target : '$Gadget.authInfo',
					onafter : function($Gadget) {
						debugger;
						if($Gadget.authInfo){
							if($Gadget.authInfo){
								var authValue = $Gadget.authInfo.split("^")[1];
								if(authValue){
									$Gadget.HaveChgUserPassAuth=authValue;
								}
							}
						}
					}
				}, $Gadget);
			},
			
			
			menuCheck:function($Page, $Gadget,$Fire,$UI)
			{
				var modifyKey = "BLCS_CurPasswordModify_WEB_ZJ";
				var request = {
						header : {
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body : {
							menuId : modifyKey

						}
					};
				
				OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextInitFireId()); 
				$Fire({
					service : 'agentdesktop/v1/person/menu_check',
					params : request,
					target : '$Gadget.data',
					onafter : function($Gadget) {
						debugger;
						// console.log(12);
						if ($Gadget.data && null != $Gadget.data.body
								&& "0" != $Gadget.data.body.rspCode) {
							var fontList = [ "<font color='blue'>",
									"<font color='blue'>",
									"<font color='blue'>",
									"<font color='red'>" ];
							var messageCount = 0;
							var message = "";
							if ($Gadget.data.body.list) {
								for ( var i = 0; i < $Gadget.data.body.list.length; i++) {
									if ($Gadget.data.body.list[i].promptMessage
											&& !$Gadget.data.body.list[i].validateResult) {
										if (messageCount == 0) {
											message = fontList[$Gadget.data.body.list[i].level]
													+ $Gadget.data.body.list[i].promptMessage
													+ "</font>";
										} else {
											message = message
													+ "<br>"
													+ fontList[$Gadget.data.body.list[i].level]
													+ $Gadget.data.body.list[i].promptMessage
													+ "</font>";
										}
										messageCount++;
									}
								}
								if (message != null) {
									var closeMdyPwd = function(){
									    debugger;
						                // 此时关闭当前页面
									    Close_tabSet();
									 };
									$UI.msgbox
											.info($UEE.i18n("ad.person.message.validatefail"), message,closeMdyPwd);
								}
							}
						}
					}
				}, $Gadget);
			},
			oldPwdOnblur : function($Page, $Gadget, $Fire, $UI) {
				debugger;
				// console.log(123);
				//操作员有强制修改密码令牌可以不校验旧密码
				if($Gadget.HaveChgUserPassAuth && $Gadget.HaveChgUserPassAuth=='Y'){
					return;
				}
				
				if ("" == $("#oldPwd").val()) {
					// 弹窗提示输入密码
					var ismsg = this.ismsgbox();
					if (ismsg == 0) {
						$("#oldPwd").val("").focus();
						oldFlag = false;
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.OldPwdNotEmpty"));//"旧密码不能都为空。"
						return;
					}
				} else if (6 != $("#oldPwd").val().length) {
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.Enter6digitPassword"));// 密码必须为6位
					return;
				} else if ($("#oldPwd").val() == $("#newPwd").val()) {
					$("#newPwd").val("").focus();
					$("#confirmPwd").val("");
					oldFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NewAndOldPassword"));//新密码和旧密码不能相同。
					return;
				} else {
					var oldPwdVal = encryptWithRSA($("#oldPwd").val());
					// debugger;
					// 取客户账户
					var operId = "";
					// 调用后台接口
					var request = {
						header : {
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body : {
							loginId : operId,
							password : oldPwdVal
						}
					};

					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId()); 
					$Fire({
						service : 'agentdesktop/v1/person/check_oldpwd',
						params : request,
						target : '$Gadget.data',
						onafter : function($Gadget) {
							debugger;
							if ($Gadget.data && $Gadget.data.body
									&& $Gadget.data.body.flag) {
								if ($("#oldPwd").val() == $("#newPwd").val()) {
									oldFlag = false;
									$("#newPwd").val("").focus();
									$("#confirmPwd").val("");
									if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
										return;
									}
									$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NewAndOldPassword"));//"新密码和旧密码不能相同。"
									return;
								} else {
									oldFlag = true;
								}
							} else if (!$Gadget.data) {
								$("#oldPwd").val("").focus();
								oldFlag = false;
								if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
									return;
								}
								$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SystemErrorLaterRetry"));
								return;
							} else if($Gadget.data.header){
								$("#oldPwd").val("").focus();
								oldFlag = false;
								var resultMessage ="";
								if($Gadget.data.header.resultCode)
								{
									if($Gadget.data.header.resultCode=="60101020017"){
										resultMessage = $UEE.i18n("ad.person.message.UserIsLocked");//"用户被锁";
									}else if($Gadget.data.header.resultCode=="60101020019")
									{
										resultMessage = $UEE.i18n("ad.person.message.PasswordNotCorrect");//"密码错误";
									}
									else if($Gadget.data.header.resultMessage){
										 resultMessage = $Gadget.data.header.resultMessage;
									}
									else{
										resultMessage = $UEE.i18n("ad.person.message.OtherErrors");//"其他错误";
									}
								}
								if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
									return;
								}
								$UI.msgbox.info($UEE.i18n("ad.person.message.information"), resultMessage);
								return;
							}else {
								$("#oldPwd").val("").focus();
								oldFlag = false;
								if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
									return;
								}
								$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.FailedVerifyOldPassword"));//"旧密码校验失败。"
								return;
							}
						}
					}, $Gadget);

				}
			},

			newPwdOnblur : function($Page, $Gadget, $Fire, $UI) {
				debugger;
				//对旧密码加密
				var oldPwdVal = $("#oldPwd").val();
				//对新密码加密
				var newPwdVal = $("#newPwd").val();
				// 测试用
				$Gadget.returnCode = 0;
				if ("" == newPwdVal) {
					// 弹窗提示输入密码
					var ismsg = this.ismsgbox();
					if (ismsg == 0) {
						$("#newPwd").val("").focus();
						$("#confirmPwd").val("");
						newFlag = false;
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NewPasswordNotAllEmpty"));//"新密码不能都为空。"
						return;
					}

				} else if (6 != newPwdVal.length && this.ismsgbox() == 0) {
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.Enter6digitPassword"));// "密码必须为6位。"
					return;
				} else if (oldPwdVal == newPwdVal) {
					$("#newPwd").val("").focus();
					$("#confirmPwd").val("");
					newFlag = false;
					if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
						return;
					}
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NewAndOldPassword"));//"新密码和旧密码不能相同。"
					return;
				} else {

					// 调用新密码校验后台接口
					var request = {
						header : {
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body : {
							busiCode : "V",
							eventId : "",
							seniorId : "",
							pwdReqBody : {
								businessCode : "V",
								itemType : "",
								itemId : "",
								orderItemActionType : "",
								itemInstanceId : "",
								actionType : "",
								newPassword : encryptWithRSA(newPwdVal),
								oldPassword : encryptWithRSA(oldPwdVal),
								passwordType : "C"
							}
						}
					};

					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId()); 
					$Fire(
							{
								service : 'agentdesktop/v1/person/newpwd_validate',
								params : request,
								target : '$Gadget.data1',
								onafter : function($Gadget) {
									debugger;
									// if ($Gadget.data1 && $Gadget.data1.body
									// && "0" == $Gadget.data1.body.rspCode) {
									// newFlag = true;
									// } else if (!$Gadget.data1) {
									// $("#newPwd").val("").focus();
									// $("#confirmPwd").val("");
									// newFlag = false;
									// $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
									// $UEE.i18n("ad.person.message.SystemErrorLaterRetry"));
									// return;
									// } else {
									// $("#newPwd").val("").focus();
									// $("#confirmPwd").val("");
									// newFlag = false;
									// $UI.msgbox.info($UEE.i18n("ad.person.message.information"),
									// "新密码校验失败。");
									// return;
									// }
									if ($Gadget.data1 && $Gadget.data1.body) {
										if ("0" != $Gadget.data1.body.rspCode) {
											newFlag = false;
											var fontList = [
													"<font color='blue'>",
													"<font color='blue'>",
													"<font color='blue'>",
													"<font color='red'>" ];
											var messageCount = 0;
											var message = "";
											if ($Gadget.data1.body.list) {
												for ( var i = 0; i < $Gadget.data1.body.list.length; i++) {
													if ($Gadget.data1.body.list[i].promptMessage
															&& !$Gadget.data1.body.list[i].validateResult) {
														if (messageCount == 0) {
															message = fontList[$Gadget.data1.body.list[i].level]
																	+ $Gadget.data1.body.list[i].promptMessage
																	+ "</font>";
														} else {
															message = message
																	+ "<br>"
																	+ fontList[$Gadget.data1.body.list[i].level]
																	+ $Gadget.data1.body.list[i].promptMessage
																	+ "</font>";
														}
														messageCount++;
													}
												}
											}
											$("#newPwd").val("").focus();
											$("#confirmPwd").val("");
											if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
												return;
											}
											$UI.msgbox.info($UEE.i18n("ad.person.message.validatefail"),
													message);
											return;
										} else {
											if ($("#newPwd").val() != $("#confirmPwd").val()
													&& "" != $("#confirmPwd").val()) {
												$("#newPwd").val("").focus();
												$("#confirmPwd").val("");
												$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.DifferentTwoInputs"));//"两次密码不一致。"
												return;
											} else {
												newFlag = true;
											}
										}
									} else {
										$("#newPwd").val("").focus();
										$("#confirmPwd").val("");
										newFlag = false;
										if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
											return;
										}
										if($Gadget.data1.body && $Gadget.data1.body.rspCode){
										    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $Gadget.data1.body.rspMsge);
										}
										else{
										    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.newpwdvalidatefail"));
										}
										return;
									}

								}
							}, $Gadget);
				}
			},

			/**
			 * 最终确认对readonly的处理
			 * 
			 * @param $Gadget
			 * @param $Fire
			 * @param $UI
			 */
			readonlyConfirmCallBack : function($Page, $Gadget, $Fire, $UI) {
				debugger;
				var oldPwd = $("#oldPwd");
				if (oldPwd.attr('readonly') != "readonly") {
					oldPwd.blur(function(){
						$Controller.bes.oc.modifypwd.oldPwdOnblur($Page, $Gadget,$Fire,$UI);
					});
				}

				var confirmPwd = $("#confirmPwd");
				if (confirmPwd.attr('readonly') != "readonly") {
				    confirmPwd.blur(function(){
				      $Controller.bes.oc.modifypwd.newPwdOnblur($Page, $Gadget,$Fire,$UI);
				    });
				}
			},
			
			resetOnclick : function() {
				$("#newPwd").val("");
				$("#oldPwd").val("").focus();
				$("#confirmPwd").val("");
			},

			submitOnclick : function($Page, $Gadget, $Fire, $UI) {
				debugger;
				var isNeedCheckOldPwd='Y';
				if($Gadget.HaveChgUserPassAuth && $Gadget.HaveChgUserPassAuth=='Y'){
					isNeedCheckOldPwd='N';
				}
				if("" == $("#oldPwd").val()){
					if(!($Gadget.HaveChgUserPassAuth && $Gadget.HaveChgUserPassAuth=='Y')){
						var ismsg = this.ismsgbox();
						if (ismsg == 0) {
							$("#newPwd").val("");
							$("#confirmPwd").val("");
							/*密码输入不符合规则。*/
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.pwdmissrule"));
						}
						return;
					}else{
						oldFlag=true;
					}
				}
				if($("#newPwd").val() != $("#confirmPwd").val()){
					var ismsg = this.ismsgbox();
					if (ismsg == 0) {
						$("#newPwd").val("");
						$("#confirmPwd").val("");
						/*新密码两次输入不一致，请重新输入。*/
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.DifferentTwoInputs"));
					}
					return;
				}
				
				if ("" == $("#newPwd").val() || "" == $("#confirmPwd").val()
						|| $("#oldPwd").val() == $("#newPwd").val()
						|| !oldFlag) {
					var ismsg = this.ismsgbox();
					if (ismsg == 0) {
						$("#newPwd").val("");
						$("#confirmPwd").val("");
						/*密码输入不符合规则。*/
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.pwdmissrule"));
					}
					return;

				} else {
					//对旧密码加密
					var oldPwdVal = encryptWithRSA($("#oldPwd").val());
					//对新密码加密
					var newPwdVal = encryptWithRSA($("#newPwd").val());
					var request = {
						header : {
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body : {
							busiCode : "M",
							eventId : "",
							seniorId : "",
							pwdReqBody : {
								businessCode : "M",
								itemType : "",
								itemId : "",
								orderItemActionType : "",
								itemInstanceId : "",
								actionType : "",
								newPassword : newPwdVal,
								oldPassword : oldPwdVal,
								passwordType : "C"
							}
						}
					};

					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getNextFireId()); 
					$Fire(
							{
								service : 'agentdesktop/v1/person/newpwd_validate',
								params : request,
								target : '$Gadget.data2',
								onafter : function($Gadget) {
									debugger;
									window._ysp_top.businessCode = 'ChangeSubPassword';
									// $Gadget.data.body.returnCode=1;
									if ($Gadget.data2
											&& $Gadget.data2.body
											&& "0" == $Gadget.data2.body.rspCode) {
										newFlag = true;
									} else if (!$Gadget.data2) {
										$("#newPwd").val("").focus();
										$("#confirmPwd").val("");
										newFlag = false;
										if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
											return;
										}
										/*系统错误*/
										$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SystemErrorLaterRetry"));
										return;
									} else {
										$("#newPwd").val("").focus();
										$("#confirmPwd").val("");
										newFlag = false;
										if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
											return;
										}
										if($Gadget.data2.body && $Gadget.data2.body.rspCode){
										    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $Gadget.data2.body.rspMsge);
										}
										else{
											/*新密码校验失败。*/
										    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.newpwdvalidatefail"));
										}
										return;
									}
									// 订单报文
									var request = {
										header : {
											loginToken : "",
											loginId : "",
											locale : "",
											serialId : ""
										},
										body : {
											businessCode : "M",
											itemType : "",
											itemId : "",
											orderItemActionType : "",
											itemInstanceId : "",
											actionType : "",
											newPassword : newPwdVal,
											oldPassword : oldPwdVal,
											passwordType : "C",
											needCheckOldPwd : isNeedCheckOldPwd
										}
									};

									OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getEndFireId());
									$Fire(
											{
												service : '/ad/v1/ctz/person/modify_pwd',
												params : request,
												target : '$Gadget.data3',
												onafter : function($Gadget) {
													// debugger;
													// 判断是否提交成功
													if ($Gadget.data3) {
														if (0 != $Gadget.data3.body.retCode) {
															// console.log("提交失败");
															$Gadget.modifyPwdFailMsg = {};
															$Gadget.modifyPwdFailMsg.name = "failReason";
															$Gadget.modifyPwdFailMsg.number = $Gadget.data3.body.retMessage;
															if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
																return;
															}
															$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$Gadget.modifyPwdFailMsg.number);
                                                            return;
														}
														if (0 == $Gadget.data3.body.retCode) {															
															//为了调用业务受理结果页面而添加
															$Page.order_resp = {};
															$Page.order_resp.header = {};
															$Page.order_resp.header.resultCode = "0";
															$Page.order_resp.header.resultMessage = "";
															$Page.order_resp.body = {};
															$Page.order_resp.body.retCode = "0";
															$Page.order_resp.body.refOrderId = $Gadget.data3.body.orderId;
															$Page.order_resp.body.phoneNumber = $Page.phonenum;
															debugger;
															$Page.paymentFinishStepFlag=true;
															$("#modifyPwdPage").hide();
															$("#paymentFinishStep").show();
														}
													} else {
														if($Controller.bes.oc.modifypwd.ismsgbox() > 0){
															return;
														}
														$UI.msgbox.info($UEE.i18n("ad.person.message.information"),
																$UEE.i18n("ad.person.message.SystemErrorLaterRetry"));
														return;
													}
												}
											}, $Gadget);
								}
							}, $Gadget);
				}
			},
			// 校验是否已经有弹出窗
			ismsgbox : function() {
				// debugger;
				var msgFlag = $(".popwin");
				return msgFlag.length;
			}

		});
