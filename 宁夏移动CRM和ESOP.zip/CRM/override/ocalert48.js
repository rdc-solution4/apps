 function getTopOfCurrentDomain(){
	// Top is best.
    try{
        if(_ysp_top.location.host==window.location.host && _ysp_top.document.body && !$.nodeName(_ysp_top.document.body, "frameset")){
            return _ysp_top;
        }
    }catch(e){}
    var testTop = window;
    
    // Try to get the _ysp_top in the current domain.
    var currentTop;
    try{
        while((testTop!=_ysp_top && !testTop.document.body) ||(testTop!=_ysp_top && testTop.document.body && !$.nodeName(testTop.document.body, "frameset"))){
            currentTop = testTop;
            if(testTop.parent.location.host != testTop.location.host){
                throw 1;
            }
            testTop = testTop.parent;
        }
    }catch(e){}
    return currentTop||window;
	return window;
}
var documentBody = getTopOfCurrentDomain().document.body;
var topDocument = getTopOfCurrentDomain().document;
var Showbo={};  
//是否为ie浏览器  
Showbo.IsIE=!!topDocument.all;  
//ie浏览器版本  
Showbo.IEVersion=(function(){if(!Showbo.IsIE)return -1;try{return parseFloat(/msie ([\d\.]+)/i.exec(navigator.userAgent)[1]);}catch(e){return -1;}})();  
//按id获取对象  
Showbo.$=function(Id,isFrame){var o;if("string"==typeof(Id))o= topDocument.getElementById(Id);else if("object"==typeof(Id))o= Id;else return null;return isFrame?(Showbo.IsIE?frames[Id]:o.contentWindow):o;}  
//按标签名称获取对象  
//页面的高和宽******************************  
Showbo.isStrict=topDocument.compatMode == "CSS1Compat";  
Showbo.BodyScale={x:0,y:0,tx:0,ty:0};//（x，y）：当前的浏览器容器大小  （tx，ty）：总的页面滚动宽度和高度 
Showbo.getClientHeight=function(){/*if(Showbo.IsIE)*/return Showbo.isStrict ? topDocument.documentElement.clientHeight :documentBody.clientHeight;/*else return self.innerHeight;*/}  
Showbo.getScrollHeight=function(){var h=!Showbo.isStrict?documentBody.scrollHeight:topDocument.documentElement.scrollHeight;return Math.max(h,this.getClientHeight());}  
Showbo.getHeight=function(full){return full?this.getScrollHeight():this.getClientHeight();}  
Showbo.getClientWidth=function(){/*if(Showbo.IsIE)*/return Showbo.isStrict?topDocument.documentElement.clientWidth:documentBody.clientWidth;/*else return self.innerWidth;*/}  
Showbo.getScrollWidth=function(){var w=!Showbo.isStrict?documentBody.scrollWidth:topDocument.documentElement.scrollWidth;return Math.max(w,this.getClientWidth());}  
Showbo.getWidth=function(full){return full?this.getScrollWidth():this.getClientWidth();}  
Showbo.initBodyScale=function(){Showbo.BodyScale.x=Showbo.getWidth(false);Showbo.BodyScale.y=Showbo.getHeight(false);Showbo.BodyScale.tx=Showbo.getWidth(true);Showbo.BodyScale.ty=Showbo.getHeight(true);} 
//页面的高和宽******************************  

// i18n
//when page is loaded,reset $.popwin.i18n setting with i18n get from background
$(function(){
	if($UEE && $UEE.i18n){
		Showbo.BUTTON_OK = $UEE.i18n('UEE.MSGBOX.OK','OK');
	}
})

Showbo.Msg={  
    INFO:'info',  
    ERROR:'error',  
    WARNING:'warning',  
    IsInit:false,  
    timer:null,  
    dvTitle:null,  
    dvCT:null,  
    dvBottom:null,  
    dvBtns:null,  
    lightBox:null,  
    dvMsgBox:null,  
    defaultWidth:400,
    defaultHeight:200,
    moveProcessbar:function(){
      var o=Showbo.$('dvProcessbar'),w=o.style.width;  
      if(w=='')w=20;  
      else{  
        w=parseInt(w)+20;  
        if(w>100)w=0;  
      }  
      o.style.width=w+'%';  
    },  
    InitMsg:function(width){  
      //ie下不按照添加事件的循序来执行，所以要注意在调用alert等方法时要检测是否已经初始化IsInit=true       
      var ifStr='<div src="javascript:false" mce_src="javascript:false" style="position:absolute; visibility:inherit; _ysp_top:0px;left:0px;width:100%; height:100%; z-index:-1;'  
          +'filter=\'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)\';"></div>',  
      html='<div class="_ysp_top"><div class="right"><div class="title" id="dvMsgTitle"></div><div id="dvMsgClose" class="popwin_close uee-popup-close"></div></div></div>'+  
        '<div class="body"><div class="right"><div class="ct" id="dvMsgCT"></div></div></div>'+  
        '<div class="bottom" id="dvMsgBottom"><div class="right"><div class="btn" id="dvMsgBtns"></div></div></div>';  
      this.dvMsgBox=topDocument.createElement("div");  
      this.dvMsgBox.id="dvMsgBox";  
      this.dvMsgBox.innerHTML+=html;        
      documentBody.appendChild(this.dvMsgBox);  
      this.lightBox=topDocument.createElement("div");  
      this.lightBox.id="ShowBolightBox";  
      documentBody.appendChild(this.lightBox); 

      /*
       * append css
       */
      if (topDocument.createStyleSheet){
    	  topDocument.createStyleSheet("resource.root/bes/ad/css/ocalert.css");
	  } else {
		  $('<link href="resource.root/bes/ad/css/ocalert.css" type="text/css" rel="stylesheet" />').appendTo($(documentBody)); 
	  }
	  
      if(Showbo.IsIE&&Showbo.IEVersion<7){//加iframe层修正ie6下无法遮盖住select的问题  
        this.lightBox.innerHTML+=ifStr;  
        this.dvMsgBox.innerHTML+=ifStr;  
      }  
      this.dvBottom=Showbo.$('dvMsgBottom');  
      this.dvBtns=Showbo.$('dvMsgBtns');  
      this.dvCT=Showbo.$('dvMsgCT');  
      this.dvTitle=Showbo.$('dvMsgTitle');  
      this.IsInit=true;  
    },  
    checkDOMLast:function(){//此方法非常关键，要不无法显示弹出窗口。两个对象dvMsgBox和lightBox必须处在body的最后两个节点内  
      if(documentBody.lastChild!=this.lightBox){  
        documentBody.appendChild(this.dvMsgBox);  
        documentBody.appendChild(this.lightBox);  
      }  
    },  
    createBtn:function(p,v,fn){ 
    	var btn=topDocument.createElement("span"); btn.type="button"; 
    	btn.className='btn'; 
    	btn.value=v;
    	btn.innerHTML = $UEE.i18n("ad.person.button.confirm");
    	btn.onclick=function(){ 
    	Showbo.Msg.hide(); 
    	if(fn)fn(p); 
    	} 
    	return btn; 
    	}, 

    closeX:function(){
        getTopOfCurrentDomain().$("#dvMsgClose").on("click",function(){
            Showbo.Msg.hide();
        })
    }
    ,
    alert:function(title, msg){
      this.show({buttons:{yes:Showbo.BUTTON_OK},msg:msg,title:title});  
    },  
    confirm:function(msg,fn){
      //fn为回调函数，参数和show方法的一致  
      this.show({buttons:{yes:Showbo.BUTTON_OK,no:'取消'},msg:msg,title:'提示',fn:fn});  
    },  
    show:function(cfg){
      //cfg:{title:'',msg:'',wait:true,icon:'默认为信息',buttons:{yes:'',no:''},fn:function(btn){回调函数,btn为点击的按钮，可以为yes，no},width:显示层的宽}  
      //如果是等待则wait后面的配置不需要了。。   
      if(!cfg)throw("没有指定配置文件！");  
      //添加窗体大小改变监听  
      if(Showbo.IsIE)window.attachEvent("onresize",this.onResize);  
      else  window.addEventListener("resize",this.onResize,false);  
        
      if(!this.IsInit)this.InitMsg();//初始化dom对象  
      else this.checkDOMLast();//检查是否在最后  
        
      //检查是否要指定宽，默认为300  
      if(cfg.width)this.defaultWidth=cfg.width;  
      this.dvMsgBox.style.width=this.defaultWidth+'px';  
      this.dvMsgBox.style.height=this.defaultHeight+'px';
      //可以直接使用show方法停止为进度条的窗口  
      if(this.timer){clearInterval(this.timer);this.timer=null;}        
      this.dvTitle.innerHTML='';  
      if(cfg.title)this.dvTitle.innerHTML=cfg.title;  
      this.dvCT.innerHTML='';  
      if(cfg.wait){  
        if(cfg.msg)this.dvCT.innerHTML=cfg.msg;  
        this.dvCT.innerHTML+='<div class="pro"><div class="bg" id="dvProcessbar"></div></div>';  
        this.dvBtns.innerHTML='';  
        this.dvBottom.style.height='10px';  
        this.timer=setInterval(function(){Showbo.Msg.moveProcessbar();},1000);  
      }  
      else
      {  
        //if(!cfg.icon)cfg.icon=Showbo.Msg.INFO;  
        if(!cfg.buttons||(!cfg.buttons.yes&&!cfg.buttons.no)){  
          cfg.buttons={yes:'Showbo.BUTTON_OK'};  
        }  
        if(cfg.icon)this.dvCT.innerHTML='<div class="icon '+cfg.icon+'"></div>';  
        if(cfg.msg)this.dvCT.innerHTML+='<span class="infoImg"></span><span class="infoText">'+cfg.msg+'</span>';
        this.dvBottom.style.height='45px';  
        this.dvBtns.innerHTML='<div class="height"></div>';  
        if(cfg.buttons.yes){  
          this.dvBtns.appendChild(this.createBtn('yes',cfg.buttons.yes,cfg.fn));  
          if(cfg.buttons.no)this.dvBtns.appendChild(topDocument.createTextNode('　'));  
        }  
        if(cfg.buttons.no)this.dvBtns.appendChild(this.createBtn('no',cfg.buttons.no,cfg.fn));  
      }  
      Showbo.initBodyScale();  
      this.dvMsgBox.style.display='block';  
      this.lightBox.style.display='block';  
      this.onResize(false);
      this.closeX();
    },  
    hide:function(){
      this.dvMsgBox.style.display='none';  
      this.lightBox.style.display='none';  
      if(this.timer){clearInterval(this.timer);this.timer=null;}  
      if(Showbo.IsIE)window.detachEvent('onresize',this.onResize);  
      else window.removeEventListener('resize',this.onResize,false);  
      $(documentBody).find("#dvMsgBox").remove();
      $(documentBody).find("#ShowBolightBox").remove();
    },  
    onResize:function(isResize){
       if(isResize)Showbo.initBodyScale();  
       Showbo.Msg.lightBox.style.width=Showbo.BodyScale.tx+'px';  
       Showbo.Msg.lightBox.style.height=Showbo.BodyScale.ty+'px';  
       Showbo.Msg.dvMsgBox.style._ysp_top=240+'px';  
       Showbo.Msg.dvMsgBox.style.left=Math.floor((Showbo.BodyScale.x-Showbo.Msg.dvMsgBox.offsetWidth)/2)+'px';  
    }  

};  