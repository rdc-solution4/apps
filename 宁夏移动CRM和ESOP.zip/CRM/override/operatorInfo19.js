/*
 * 初始化个人信息弹框
 */
function initAccountOpt()
{
	$("#bes_sm_portal_userName_input").val($Model.userInfo.userName);
	$("#bes_sm_portal_email_input").val($Model.userInfo.email);
	$("#bes_sm_portal_phone_input").val($Model.userInfo.contactPhone);
	
	$("#bes_sm_portal_welcome_input").val($Model.tipHelperInformation.tipInformation);
	
	if ($Model.userInfo.hasUpdateInfoAuth)
	{
		var i18n = $UEE.i18n;
		var cls ;
		if ($Model.employeeBySource){
			cls = $("#bes_sm_portal_userName_input").attr('class');
			$("#bes_sm_portal_userName_input").attr('class', cls.replace("disableEdit", "beforeEdit"));
			cls = $("#bes_sm_portal_userName_span").attr('class');
			$("#bes_sm_portal_userName_span").attr('class', cls.replace("disableEdit", "beforeEdit"));
			$("#bes_sm_portal_userName_input").removeAttr("readonly");
			$("#bes_sm_portal_userName_span").attr('title', i18n('SM.LOGIN.TIPS.MODIFY'));
		}else{
			cls = $("#bes_sm_portal_userName_span").attr('class');
			$("#bes_sm_portal_userName_span").attr('class', cls.replace("disableEdit", ""));
		}
		
		if ($Model.PartyIndividualBySource){
			cls = $("#bes_sm_portal_email_input").attr('class');
			$("#bes_sm_portal_email_input").attr('class', cls.replace("disableEdit", "beforeEdit"));
			cls = $("#bes_sm_portal_email_span").attr('class');
			$("#bes_sm_portal_email_span").attr('class', cls.replace("disableEdit", "beforeEdit"));
			$("#bes_sm_portal_email_input").removeAttr("readonly");
			$("#bes_sm_portal_email_span").attr('title', i18n('SM.LOGIN.TIPS.MODIFY'));
		
			cls = $("#bes_sm_portal_phone_input").attr('class');
			$("#bes_sm_portal_phone_input").attr('class', cls.replace("disableEdit", "beforeEdit"));
			cls = $("#bes_sm_portal_phone_span").attr('class');
			$("#bes_sm_portal_phone_span").attr('class', cls.replace("disableEdit", "beforeEdit"));
			$("#bes_sm_portal_phone_input").removeAttr("readonly");
			$("#bes_sm_portal_phone_span").attr('title', i18n('SM.LOGIN.TIPS.MODIFY'));
		}else{
			cls = $("#bes_sm_portal_email_span").attr('class');
			$("#bes_sm_portal_email_span").attr('class', cls.replace("disableEdit", ""));
			
			cls = $("#bes_sm_portal_phone_span").attr('class');
			$("#bes_sm_portal_phone_span").attr('class', cls.replace("disableEdit", ""));
		}
		
	}
		var cls = $("#bes_sm_portal_welcome_input").attr('class');
		$("#bes_sm_portal_welcome_input").attr('class', cls.replace("disableEdit", "beforeEdit"));
		cls = $("#bes_sm_portal_welcome_span").attr('class');
		$("#bes_sm_portal_welcome_span").attr('class', cls.replace("disableEdit", "beforeEdit"));
		$("#bes_sm_portal_welcome_input").removeAttr("readonly");
		$("#bes_sm_portal_welcome_span").attr('title', $UEE.i18n('SM.LOGIN.TIPS.MODIFY'));
	
}

function accountOptClick(e)
{
	debugger;
	var isOpen = $(".accountOpt").data("open");
	if (isOpen)
	{
		// 弹出的情况下，只有点击头像区域才会消失
		var clsVal = $(e.target).attr('class');
		// 点击的是头像区域，则关闭
		if (clsVal == 'ao-droplist' || clsVal == 'ao-header')
		{
			closeAccountOpt();
			return;
		}
		
		var id = $(e.target).attr('id');
		if ((clsVal!=undefined && clsVal.indexOf('ao-updatepwd') != -1) || id == 'bes_sm_portal_updatePwd_pic')
		{
			if ($Model.ChangePasswordBySource){
				// 点击修改密码
				var timestamp = new Date().getTime();
				loadPopup("pages/wb_updatePwd.html?t=" + timestamp);
				closeAccountOpt();
				return;
			}
		}
		else if ((clsVal!=undefined && clsVal.indexOf('ao-lock') != -1) || id == 'bes_sm_portal_lock_pic')
		{
			// 点击锁屏
			lockpage.lock();
			closeAccountOpt();
			return;
		}
		else if ((clsVal!=undefined && clsVal.indexOf('ao-exit') != -1) || id == 'bes_sm_portal_exit_pic')
		{
			// 点击退出
			smlogout.logout();
			closeAccountOpt();
			return;
		}
		
		if (clsVal != undefined && ( clsVal.indexOf('disableEdit') != -1 || clsVal.indexOf('afterEdit') != -1 ))
		{
			// 没有权限时，不能编辑
			return;
		}
		
		var i18n = $UEE.i18n;
		if ((id == 'bes_sm_portal_userName_input' || id == 'bes_sm_portal_userName_span') && $Model.employeeBySource)
		{
			// 点击修改操作员姓名区域
			if (clsVal.indexOf('beforeEdit') != -1)
			{
				$("#bes_sm_portal_userName_input").attr('class', $("#bes_sm_portal_userName_input").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_userName_span").attr('class', $("#bes_sm_portal_userName_span").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_userName_span").attr('title', i18n('SM.LOGIN.TIPS.SAVE'));
			}
			else if (id == 'bes_sm_portal_userName_span')
			{
				// 修改操作员姓名
				updateOperatorInfo('1', $("#bes_sm_portal_userName_input").val());
			}
			resetEmailDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetContactPhoneDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetUserWelcomeDiv("onEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY"));
		}
		else if ((id == 'bes_sm_portal_email_input' || id == 'bes_sm_portal_email_span') && $Model.PartyIndividualBySource)
		{
			// 点击修改邮箱区域
			if (clsVal.indexOf('beforeEdit') != -1)
			{
				$("#bes_sm_portal_email_input").attr('class', $("#bes_sm_portal_email_input").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_email_span").attr('class', $("#bes_sm_portal_email_span").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_email_span").attr('title', i18n('SM.LOGIN.TIPS.SAVE'));
			}
			else if (id == 'bes_sm_portal_email_span')
			{
				// 修改邮箱
				updateOperatorInfo('2', $("#bes_sm_portal_email_input").val());
			}
			
			resetUserNameDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetContactPhoneDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetUserWelcomeDiv("onEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY"));
		}
		else if ((id == 'bes_sm_portal_phone_input' || id == 'bes_sm_portal_phone_span') && $Model.PartyIndividualBySource)
		{
			// 点击修改手机号区域
			if (clsVal.indexOf('beforeEdit') != -1)
			{
				$("#bes_sm_portal_phone_input").attr('class', $("#bes_sm_portal_phone_input").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_phone_span").attr('class', $("#bes_sm_portal_phone_span").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_phone_span").attr('title', i18n('SM.LOGIN.TIPS.SAVE'));
			}
			else if (id == 'bes_sm_portal_phone_span')
			{
				// 修改手机号
				updateOperatorInfo('3', $("#bes_sm_portal_phone_input").val());
			}
			
			resetUserNameDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetEmailDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetUserWelcomeDiv("onEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY"));
		}else if(id == 'bes_sm_portal_welcome_input' || id == 'bes_sm_portal_welcome_span'){
			
			
			if (clsVal.indexOf('beforeEdit') != -1)
			{
				$("#bes_sm_portal_welcome_input").attr('class', $("#bes_sm_portal_welcome_input").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_welcome_span").attr('class', $("#bes_sm_portal_welcome_span").attr('class').replace("beforeEdit", "onEdit"));
				$("#bes_sm_portal_welcome_span").attr('title', i18n('SM.LOGIN.TIPS.SAVE'));
			}
			else if (id == 'bes_sm_portal_welcome_span')
			{
				var welcome = $("#bes_sm_portal_welcome_input").val();
				
				var welcomeLen = getUTF8BytesLength(welcome);
				
				if(welcomeLen >100){
					//$("#bes_sm_portal_welcome_input").css({"border":"solid red 1px"})
				}else{
				
					// 修改欢迎语
					updateEmployeeWelcome($("#bes_sm_portal_welcome_input").val());
				}
			}
			
			resetUserNameDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetEmailDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetContactPhoneDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
		}else
		{
			resetUserNameDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetEmailDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetContactPhoneDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
			resetUserWelcomeDiv("onEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY"));
		}
		e.stopPropagation();		
		return;
	}
	
//	$(this).filter('.open').not($(this)).removeClass('open').find(".ao-popup").hide();

	var left = $(".accountOpt").offset().left - 244;

	$(".accountOpt").find(".ao-popup").css("left", left);

	$(".accountOpt").data("open", !isOpen).toggleClass("open").find(".ao-popup").toggle();
	e.stopPropagation();
}

function closeAccountOpt()
{
	var isOpen = $('.accountOpt').data("open");
	if (isOpen)
	{
		$('.accountOpt').data("open", !isOpen).toggleClass("open").find(".ao-popup").toggle();
		
		// 将操作员姓名，电子邮箱，手机号码3个区域设置为取消状态
		resetUserNameDiv('onEdit', 'beforeEdit');
		resetEmailDiv('onEdit', 'beforeEdit');
		var i18n = $UEE.i18n;
		resetContactPhoneDiv('onEdit', 'beforeEdit', i18n('SM.LOGIN.TIPS.MODIFY'));
	}
}

/**
 * 将操作员姓名区域设置为取消状态
 */
function resetUserNameDiv(originCls, targetCls, title)
{
	$("#bes_sm_portal_userName_input").val($Model.userInfo.userName);
	var cls = $("#bes_sm_portal_userName_input").attr('class');
	if (cls.indexOf('disableEdit') != -1)
	{
		return;
	}
	
	$("#bes_sm_portal_userName_input").attr('class', cls.replace(originCls, targetCls));
	cls = $("#bes_sm_portal_userName_span").attr('class');
	$("#bes_sm_portal_userName_span").attr('class', cls.replace(originCls, targetCls));
	$("#bes_sm_portal_userName_span").attr('title', title);
}

/**
 * 将电子邮箱区域设置为取消状态
 */
function resetEmailDiv(originCls, targetCls, title)
{
	$("#bes_sm_portal_email_input").val($Model.userInfo.email);
	var cls = $("#bes_sm_portal_email_input").attr('class');
	if (cls.indexOf('disableEdit') != -1)
	{
		return;
	}
	
	$("#bes_sm_portal_email_input").attr('class', cls.replace(originCls, targetCls));
	cls = $("#bes_sm_portal_email_span").attr('class');
	$("#bes_sm_portal_email_span").attr('class', cls.replace(originCls, targetCls));
	$("#bes_sm_portal_email_span").attr('title', title);
}

/**
 * 将机号码区域设置为取消状态
 */
function resetContactPhoneDiv(originCls, targetCls, title)
{
	$("#bes_sm_portal_phone_input").val($Model.userInfo.contactPhone);
	var cls = $("#bes_sm_portal_phone_input").attr('class');
	if (cls.indexOf('disableEdit') != -1)
	{
		return;
	}
	
	$("#bes_sm_portal_phone_input").attr('class', cls.replace(originCls, targetCls));
	cls = $("#bes_sm_portal_phone_span").attr('class');
	$("#bes_sm_portal_phone_span").attr('class', cls.replace(originCls, targetCls));
	$("#bes_sm_portal_phone_span").attr('title', title);
}

/**
 * 将操作员姓名区域设置为取消状态
 */
function resetUserWelcomeDiv(originCls, targetCls, title)
{
	$("#bes_sm_portal_welcome_input").val($Model.tipHelperInformation.tipInformation);
	var cls = $("#bes_sm_portal_welcome_input").attr('class');
	if (cls.indexOf('disableEdit') != -1)
	{
		return;
	}
	
	$("#bes_sm_portal_welcome_input").attr('class', cls.replace(originCls, targetCls));
	cls = $("#bes_sm_portal_welcome_span").attr('class');
	$("#bes_sm_portal_welcome_span").attr('class', cls.replace(originCls, targetCls));
	$("#bes_sm_portal_welcome_span").attr('title', title);
}

function updateOperatorInfo(type, value)
{
	debugger;
	var $Scope = $(document).scope();
    var $Model = $Scope.$Model;
    var $fire = $Scope.$Get("$Fire");
	var validator = $fire.validate("$Model.userInfo", $Scope);
	if(!validator){
		return;
	}

	$fire({ "service" : "/SMOperatorUpdateService/updatecurrentemployeeinfo",
            "params" : { 'type' : type, 'value' : value }
          }, $Scope).onafter(function ()
    {
           var i18n = $UEE.i18n;
           if (type=='1')
           {
        	   $Model.userInfo.userName = value;
        	   resetUserNameDiv('onEdit', 'afterEdit', i18n('SM.LOGIN.TIPS.MODIFY_SUCCESS'));
        	   $('#bes_sm_portal_userName_span').animate({width: '16'}, 1000);
        	   setTimeout('resetUserNameDiv("afterEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY")); $("#bes_sm_portal_userName_span").removeAttr("style")', 1500);
           }
           else if (type=='2')
           {
        	   $Model.userInfo.email = value;
        	   resetEmailDiv('onEdit', 'afterEdit', i18n('SM.LOGIN.TIPS.MODIFY_SUCCESS'));
        	   $('#bes_sm_portal_email_span').animate({width: '16'}, 1000);
        	   setTimeout('resetEmailDiv("afterEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY")); $("#bes_sm_portal_email_span").removeAttr("style")', 1500);
           }
           else if (type=='3')
           {
        	   $Model.userInfo.contactPhone = value;
        	   resetContactPhoneDiv('onEdit', 'afterEdit', i18n('SM.LOGIN.TIPS.MODIFY_SUCCESS'));
        	   $('#bes_sm_portal_phone_span').animate({width: '16'}, 1000);
        	   setTimeout('resetContactPhoneDiv("afterEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY")); $("#bes_sm_portal_phone_span").removeAttr("style")', 1500);
           }
    });
}

function updateEmployeeWelcome(welcome){
	var $Scope = $(document).scope();
    var $Model = $Scope.$Model;
    var $fire = $Scope.$Get("$Fire");
	$fire({ "service" : "/smtipinformation/updateLoginTip",
            "params" : { 'tips' : welcome }
          }, $Scope).onafter(function(){
        	  $Model.tipHelperInformation.tipInformation = welcome;
        	  
        	  resetUserWelcomeDiv('onEdit', 'afterEdit', $UEE.i18n('SM.LOGIN.TIPS.MODIFY_SUCCESS'));
        	  $('#bes_sm_portal_welcome_span').animate({width: '16'}, 1000);
        	  setTimeout('resetUserWelcomeDiv("afterEdit", "beforeEdit", $UEE.i18n("SM.LOGIN.TIPS.MODIFY")); $("#bes_sm_portal_welcome_span").removeAttr("style")', 1500);
          });
}

function getUTF8BytesLength(value){
	var totalLength = 0;     
    var charCode;  
    for (var i = 0; i < value.length; i++) {  
        charCode = value.charCodeAt(i);  
        if (charCode <= 0x007f)  {     
            totalLength++;     
        } else if ((0x0080 <= charCode) && (charCode <= 0x07ff))  {     
            totalLength += 2;     
        } else if ((0x0800 <= charCode) && (charCode <= 0xffff))  {     
            totalLength += 3;   
        } else{  
            totalLength += 4;   
        }          
    }  
    return totalLength;   
}
