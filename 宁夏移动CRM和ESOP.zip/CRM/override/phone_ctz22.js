var win = window;

/*win.onbeforeunload = function(){
	return "是否确定退出？";
}*/

//DD-AR-D01886788 退出系统时进行知识库的退出
win.onunload = function(){
	exitKnowledgeBase();
}

//DD-AR-D01886788 退出系统时进行知识库的退出-关闭浏览器
function exitKnowledgeBase()
{
	var knowledgeBaseStatus = _ysp_top.$BES.$Portal.tabpanel.knowledgeBaseStatus;
	var onlineKnowledgeLogOut = _ysp_top.$BES.$Portal.tabpanel.onlineKnowledgeLogOut;
	if (knowledgeBaseStatus == true)
	{
		if (onlineKnowledgeLogOut)
		{
			//跨域请求
           	jQuery.ajax({
  		    type: "get",
  			url: onlineKnowledgeLogOut, 
  			dataType: "jsonp",
  			success: function (suc) {
  			    debugger;
  		    },
  		    error: function (err) {
  		        debugger;
  		    }
  		  	});
		}
	}
}

var siteParam = {};
siteParam.siteVersion = "c00";
siteParam.skinPath = "default";
siteParam.ueeVersion = $UEE.version;

$.cookie('bes-site-param', JSON.stringify(siteParam), {
	path : '/'
});

var besSiteVersion = "c00";

var besSkinPath = "default";

var protocolType = "http";

var esMenuMap = {};

var portalGadgetApi = new PortalGadget();

var hoursMap = {
		"0":"00:00:00",
		"1":"01:00:00",
		"2":"02:00:00",
		"3":"03:00:00",
		"4":"04:00:00",
		"5":"05:00:00",
		"6":"06:00:00",
		"7":"07:00:00",
		"8":"08:00:00",
		"9":"09:00:00",
		"10":"10:00:00",
		"11":"11:00:00",
		"12":"12:00:00",
		"13":"13:00:00",
		"14":"14:00:00",
		"15":"15:00:00",
		"16":"16:00:00",
		"17":"17:00:00",
		"18":"18:00:00",
		"19":"19:00:00",
		"20":"20:00:00",
		"21":"21:00:00",
		"22":"22:00:00",
		"23":"23:00:00"};

tabResize();
//屏蔽修改密码的按钮
function hideUpdatePwd(){
	$(".lastLiOpt>.ao-updatepwd").hide();
}
hideUpdatePwd();


var refreshNoteIntval = -1;

function setRefreshNote() {
	$("#noticelistdiv li:not(:first)").css("display","none"); 
	if (refreshNoteIntval != -1) {
		clearInterval(refreshNoteIntval);
	}
	refreshNoteIntval = setInterval(function(){ 
		var B=$("#noticelistdiv li:last"); 
		var C=$("#noticelistdiv li:first"); 
		if(B.is(":visible")){ 
			C.fadeIn(500).addClass("in");B.hide()
		}else{ 
			$("#noticelistdiv li:visible").addClass("in"); 
			$("#noticelistdiv li.in").next().fadeIn(500); 
			$("li.in").hide().removeClass("in");
		} 
	},2000);
}

$(document).ready(function(){ 
	setRefreshNote();
}) 

function initPortalType($Scope) {
	this.sp = $Scope;
	var $Fire = $Scope.$Get('$Fire');
	var $Model = $Scope.$Model;
	$Fire({
		'service' : '/SMPortalAction/isManagePortal',
		'target' : '$Model.isManagePortal'
	}, $Scope);
}

function initBesPortalCookie($Scope) {
	$.cookie("bes_portal_id", "p60131", {
		path : '/'
	});
}

function msgInfo(titleStr, msg, okBack, cancelBack, closeBack) {
	this.sp.$UI.msgbox.info(titleStr, msg, function() {
		okBack();
	}, function() {
		cancelBack();
	}, function() {
		closeBack();
	});
}

function popMenu(title, url, width, height, hasScroll) {
	var timestamp = new Date().getTime();
    var popMenuParam = {
		title:title,
		width:width,
		height:height,
		url:url,
		hasScroll:hasScroll
	};
    popMenuParam = JSON.stringify(popMenuParam);
    _ysp_top.sp.$Page.popMenuParam = popMenuParam;
	
    loadPopup("pages/popMenu.html?t=" + timestamp);
}

function popNoteMenu(title, url, width, height, hasScroll) {
	var timestamp = new Date().getTime();
	var popMenuParam = {
			title:title,
			width:width,
			height:height,
			url:url,
			hasScroll:hasScroll
	};
	popMenuParam = JSON.stringify(popMenuParam);
	_ysp_top.sp.$Page.popMenuParam = popMenuParam;
	
	loadPopNote("pages/popMenu.html?t=" + timestamp);
}

function msgConfirm(titleStr, msg, okBack, cancelBack, closeBack, btnoktext,
		btncanceltext) {
	this.sp.$UI.msgbox.confirm(titleStr, msg, function() {
		okBack();
	}, function() {
		cancelBack();
	}, function() {
		closeBack();
	}, btnoktext, btncanceltext);
}

function tabResize() {
	var height = $(window).height() - 100;
	var width = $(window).width() - 55;

	$('.tabcontainer').css({
		width : width,
		height : height
	});
	
	// 关闭操作员信息右上角弹框
	closeAccountOpt();
}

function clearUserSession($Scope) {
	var besServNum = $.cookie("besServNum");
	if (undefined == besServNum || "" == besServNum) {
		return;
	}
	// 有号码则清空
	try {
		var $Fire = $Scope.$Get('$Fire');
		$Fire({
			'service' : '/agentdesktop/v1/person/subscribersignout',
			'target' : '$Gadget.result',
			'onafter' : function() {
				debugger;
				//如果己经有用户登陆，需要将老用户缓存清掉，将新用户信息临时放在缓存中。等所有tab页面关闭后，再将新用户信息塞到上下文
				$Fire({
					'service' : 'bes.oc.ocauthenticationservice/setusersessionfromcache',
					'params': {
						'servNumber' : window._ysp_top.tmpLoginId
					},
					'onafter': function(){
						debugger;
						//window._ysp_top.setUserSessionFinish用来表示己将新用户信息塞到上下文
						window._ysp_top.setUserSessionFinish = true;
					}
				}, $Scope);
			},
			'onerror' : function() {
			}
		}, $Scope);
	} catch (err) {
	}
}

tabResize();

/* ######### */
if (isIE()) {
	window.attachEvent('onmessage', onBesPortalMessage);
} else {
	window.addEventListener('message', onBesPortalMessage, false);
}
function onBesPortalMessage(e) {
	e = e || window.event;
	var data;
	try
	{
		data = JSON.parse(e.data);
	}
	catch(err)
	{
		data = e.data;
	}
	var operation = data.operation;
	if (undefined == operation) {
		return;
	}

	if ("Tab_Add" == operation) {
		var item = data.item;
		var tabId = item.id;
		var destUrl = item.url;
		var isHttps = item.httpsFlag == true || item.httpsFlag == "true";
		var title = item.title;
		var menuId = item.pageid;
		var openMode = item.openMode;
		var tabType = item.tabType;
		openNewTab(tabId, destUrl, isHttps, title, false, menuId, openMode);
	} else if ("Tab_Close" == operation) {
		var tabId = data.tabId;
		if (undefined == tabId) {
			tabId = tab.selectedItem().attr('innerid');
		}
		closeTab(tabId);
	} else if ("Tab_Show" == operation) {
		var tabId = data.tabId;
		showTab(tabId);
	} else if ("Tab_CloseAll_ExceptOne" == operation) {
		var tabId = data.tabId;
		if (undefined == tabId) {
			tabId = tab.selectedItem().attr('innerid');
		}
		closeAllTabExceptOne(tabId);
	} else if ("Tab_CloseAll" == operation) {
		closeAllTab();
	} else if ("Add_ShortCut" == operation) {
		var workbench = $('.tabcontainer').filter('[innerid=6010100090012]')
				.children()[0].contentWindow;
		workbench.addMenu(data.menuImg, data.menuUrl, data.menuName,
				data.menuId, data.httpsFlag, true, data.visitRule, data.openMode, data.tabType);
	} else if ("unlockScreenResq" == operation) {
		lockpage.porcessUnlockScreenResult(data.params)
	} else if ("Tab_Hide" == operation) {
		var tabId = data.tabId;
		hideTab(tabId);
	} 
};

// 创建Tab对象
function createTab(tabId, title, noClose, menuId) {
	tabId = escapeHtml(tabId);
	title = escapeHtml(title);
	menuId = escapeHtml(menuId);
	
	var tabstr = '';
	if (noClose) {
		tabstr = '<li innerId="'
				+ tabId
				+ '" title="'
				+ title
				+ '">\
									<div class="selector"></div>\
									<div class="tab-title"><span>'
				+ title + '</span></div>\
								  </li>';
		tabstr = $(tabstr);
	} else {
		tabstr = '<li innerId="'
				+ tabId
				+ '" title="'
				+ title
				+ '">\
		                        <div class="selector"></div>\
                                <div class="tab-close"></div>\
		                        <div class="tab-title"><span>'
				+ title + '</span></div>\
	                          </li>';
	}
	tabstr = $(tabstr);
	if (undefined != menuId) {
		tabstr.attr('menuId', menuId);
	}
	return tabstr;
}

// 创建tab内容
function createPage(pageId, destUrl, isHttps) {	
	if (protocolType == "https") {
		isHttps = true;
	}
	destUrl = formatUrl(destUrl, isHttps);

	pageId = escapeHtml(pageId);
	var pagestr = '<div innerId="'
			+ pageId
			+ '" class="tabcontainer">\
				              </div>';
	
	var $iframe = $('<iframe innerid="' + pageId + '" frameborder="no" border="0" width="100%" height="100%"> \
                                   </iframe> ');
	$iframe.attr("src",destUrl);
	var pagestrJquery = $(pagestr);
	
	pagestrJquery.append($iframe);
	
	return pagestrJquery;
}

// 格式化http
function formatUrl(destUrl, isHttps) {
	var resRoot = "resource.root";
	var business_url = destUrl;
	var context = location.pathname.substring(1, location.pathname.indexOf('/',
			1));
	// 格式化url
	if (destUrl && destUrl.indexOf(resRoot) == -1
			&& destUrl.indexOf("http") != 0) {
		if (destUrl.charAt(0) != '/') {
// business_url = "/" + context + "/" + destUrl;
			business_url = destUrl;
		} else {
			context = destUrl.substring(1, destUrl.indexOf('/', 1));
			business_url = destUrl.substring(destUrl.indexOf('/', 1),
					destUrl.length);
		}
	}

	// 检验是不是要用https显示url
	if (destUrl && destUrl.indexOf("https") != 0 && isHttps) {
		httpsPort = $BES.$ContextAccessor.getHttpsPort();
		if (destUrl.indexOf("http") == 0) {
			return "https://"
					+ destUrl.substr(7).replace(/(:\d+)?\//,
							":" + httpsPort + "/");
		} else {
			return "https://" + location.hostname + ":" + httpsPort + "/"
					+ context + (business_url.charAt(0) == "/" ? "" : "/")
					+ business_url;
		}
	}
	else if (destUrl && destUrl.indexOf("http") == 0)
	{
		return destUrl;
	}
	
    return "/" + context + (business_url.charAt(0) == "/" ? "" : "/") + business_url;
}

function getLiById(liid) {
	var li = $('li').filter('[innerid="' + liid + '"]');
	return li;
}

// 根据id获取Tab页内容
function getPageById(pageId) {
	var pages = $('.main-right > div');
	for ( var i = 0; i < pages.length; i++) {
		var page = pages.eq(i);
		if (page.attr("innerId") == pageId) {
			return page;
		}
	}
	return null;
}

$UEE.$Fire.onerrors[491] = function(data, fire, scope) {
	 
	if (undefined == scope.$Model.menu) {
		return;
	}
	openOcPage(scope.$Model.menu.destUrl, scope.$Model.menu.menuId,
			scope.$Model.menu.tabId, scope.$Model.menu.title,
			scope.$Model.menu.noClose, scope.$Model.menu.isHttps, scope.$Model.menu.openMode, scope.$Model.menu.tabType);
};

function openOcPage(destUrl, menuId, tabId, title, noClose, isHttps, openMode, tabType, authtypecheckmsg) {
	// 如果没有，则调用oc鉴权页面
	var index = destUrl.indexOf("?");
	var besUrl;
	var param;
	if (index == -1) {
		besUrl = destUrl;
	} else {
		besUrl = destUrl.substr(0, index);
		param = destUrl.substr(index + 1, destUrl.length);
	}
	destUrl = "bes/ad/html/bes.ad.login.base.business.html?tabId=" + menuId
			+ "&tabName=" + title + "&besUrl=" + besUrl + "&";
            
    if (authtypecheckmsg) {
        destUrl = destUrl + "authtypecheckmsg=" + authtypecheckmsg + "&";
    }
    
    destUrl = destUrl + param;

	tabId = "60131_oclogintemp";
	title = $UEE.i18n('SM.LOGIN.LABEL.CUS_LOGIN_REDIRECT');
	// 登录跳转页面用T打开
	openTabAndPage(destUrl, menuId, tab, tabId, title, noClose, isHttps, "T");
}

function getAccessTimeValue(menuInfo) {
	//  查询不到菜单则忽略
    if (menuInfo.length == 0) {
    	return null;
    }
	var menu = menuInfo[0];
	var accessTimeValue;
	if (menu.smmenuExtAttrVO && menu.smmenuExtAttrVO.length > 0)
	{
		for (var idx = 0; idx < menu.smmenuExtAttrVO.length; idx++)
		{
			var attr = menu.smmenuExtAttrVO[idx];
			if (attr.attrName == "ACCESS_TIME") {
				accessTimeValue = attr.attrValue;
				break;
			}
		}
	}
	
	return accessTimeValue;
}

function validateAccessTimeAndOpenNewTab(tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType, accessTimeValue) {
	 debugger;
	// 如果传入了则校验
	if (accessTimeValue) {
		accessTimeList = JSON.parse(accessTimeValue);
		if (accessTimeList && accessTimeList.length > 0) {
			var hourNow = new Date().getHours();
			var match = false;
			var formatAccessTime = '';
			for (var idx = 0; idx < accessTimeList.length; idx++) {
				accessTime = accessTimeList[idx];
				startTime = accessTime.startTime;
				endTime = accessTime.endTime;
				if (hourNow >= parseInt(startTime) && hourNow < parseInt(endTime)) {
					match = true;
				}
				formatAccessTime = formatAccessTime + hoursMap[startTime] + ' - ' + hoursMap[endTime] + '<br/>';
			}
			formatAccessTime = formatAccessTime.substr(0, formatAccessTime.length - 5);
			
			// 没找到匹配的时间段，不能打开
			if (!match) {
				var title = $UEE.i18n('SM.LOGIN.MESSAGE.SUGGESTION');
				var msg = $UEE.i18n('SM.LOGIN.MESSAGE.MENU_ACCESS_TIME_NOT_MATCH');
				msg = msg + "<br/>" + formatAccessTime;
				this.sp.$UI.msgbox.info(title, msg);
				return;	
			}
		}
	}

	// 设置cookie
	setCookie(tabId, menuId);
	
	// 未传入tabType，则取后台获取；传入则用传入的
	if (undefined == tabType) {
		var $Fire = this.sp.$Get("$Fire");
		$Fire(
				{
					"service" : "/SMPortalAction/queryTabTypeByMenuId",
					"params" : {
						"menuId" : menuId
					},
					"target" : "$Model.tmpTabType"
				}, this.sp)
				.onafter(
						function() {
							tabType = $Model.tmpTabType;
							checkMenuNeedAuthAndOpenTab($Model, tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType);
						});
	} else {
		checkMenuNeedAuthAndOpenTab($Model, tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType);
	}
}

function checkMenuNeedAuthAndOpenTab($Model, tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType) {
	debugger;
	var isMenuNeedAuth = checkMenuNeedAuth(tabType, $Model.portalParams);
	// 如果需要鉴权，则调用oc判断是否已经鉴权接口
	if (isMenuNeedAuth) {
		$Model.menu = {};
		$Model.menu.destUrl = destUrl;
		$Model.menu.tabId = tabId;
		$Model.menu.isHttps = isHttps;
		$Model.menu.title = title;
		$Model.menu.noClose = noClose;
		$Model.menu.menuId = menuId;
		$Model.menu.openMode = openMode;
		$Model.menu.tabType = tabType;
        var $Scope = this.sp;
		try {
			$Fire(
					{
						"service" : "/bes.oc.provide.querysessionserviceboservice/getsubscriberinfo",
						"target" : "$Model.SessionSubscriberInfo"
					}, this.sp)
					.onafter(
							function() {
								debugger;
								// 如果已经鉴权，则设置cookie，并打开tab页
								if ($Model.SessionSubscriberInfo) {
									// setCookie
									$.cookie(
										"com.huawei.boss.CURRENT_USER",
										$Model.SessionSubscriberInfo);
									
									//判断当前鉴权方式是否在菜单属性配置表中                            
                                    var authType = window._ysp_top.loginReq.authType;
                                    $Fire({
                                    	service: "ucec/v1/common/qrysystemparambykey",
                                    	params: {
                                    		"key": "AD.AUTHTYPESBYBUSI.NEW"
                                    	},
                                    	target: "$Model.authTypeByBusiNew"
                                    }, $Scope).onafter(function () {
                                    	debugger;
                                    	if (authType && "Y" == $Model.authTypeByBusiNew) {
                                    		$Fire({
                                    			service: "/ucec/v1/accessAuth",
                                    			params: {
                                    				"tabid": tabId
                                    			},
                                    			target: "$Model.accessAuth"
                                    		}, $Scope).onafter(function () {
                                    			debugger;
                                    			if ($Model.accessAuth) {
                                                    openOcPage(destUrl, menuId, tabId, title, noClose, isHttps, openMode, tabType, 'authTypeCheckMSG_default');
                                                    return;
                                    			}                                                
                                                
                                                // 打开tab页
                                                openTabAndPage(destUrl,
                                                    menuId, tab,
                                                    tabId, title,
                                                    noClose,
                                                    isHttps, openMode, tabType);
                                    		});
                                    	} else {
                                            // 打开tab页
                                            openTabAndPage(destUrl,
                                                    menuId, tab,
                                                    tabId, title,
                                                    noClose,
                                                    isHttps, openMode, tabType);
                                    	}
                                    });									
								} else {
									// 应该走不到这，走的是491错误分支
									openOcPage(destUrl, menuId, tabId, title, noClose, isHttps, openMode, tabType);
								}
							});
		} catch (err) {
			// 调用oc接口挂了，直接打开菜单
			openTabAndPage(destUrl, menuId, tab, tabId,
					title, noClose, isHttps, openMode, tabType);
		}
	} else {
		openTabAndPage(destUrl, menuId, tab, tabId, title,
				noClose, isHttps, openMode, tabType);
	}
}

function checkMenuNeedAuth(tabType, portalParams) {
	if (!tabType || !portalParams || !portalParams.needAuthMenuType) {
		return false;
	}
	var menuNeedAuthType = portalParams.needAuthMenuType;
	var authTypes = menuNeedAuthType.split(',');
	for (var idx = 0; idx < authTypes.length; idx++) {
		if (tabType == authTypes[idx]) {
			return true;
		}
	}
	return false;
}

// 打开或激活一个tab页
function openNewTab(tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType, accessTimeValue) {	
	isHttps = isHttps == true || isHttps == "true";
	if (undefined == destUrl) {
		return;
	}	

	var $Fire = this.sp.$Get("$Fire");
	
	if (accessTimeValue) {	
		validateAccessTimeAndOpenNewTab(tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType, accessTimeValue);
	} else {
		$Fire(
				{
					"service" : "/gadget/common/operator/queryLoginOpenMenuByMenuId",
					"target" : "$Model.tempMenu",
					"params" : {
						'menuId' : menuId
					}
				}, this.sp)
				.onafter(function() {
					accessTimeValue = getAccessTimeValue($Model.tempMenu);		
					if ((!tabType || tabType == 'null') && $Model.tempMenu && $Model.tempMenu.length > 0) {
						tabType = $Model.tempMenu[0].tabType;
					}
					validateAccessTimeAndOpenNewTab(tabId, destUrl, isHttps, title, noClose, menuId, openMode, tabType,accessTimeValue);
					
				});
	}
}

function addParamsToUrl(url)
{
	var createTokenIdx = url.indexOf('isCreateToken');
	if (-1 == createTokenIdx)
	{
		return url;
	}
	var token = this.sp.$Model.userInfo.sessionId;
	var checkUrl = window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp;
	params = "&token=" + token + "&checkUrl=" + checkUrl;
	
	var ssoUrl = "/menuJumpWithSSO?redirectURL=";
	var redirectURL = url + params;
	redirectURL = encodeURIComponent(redirectURL);
	return checkUrl + ssoUrl + redirectURL;
}

var lastIfrLoad;

function getLastIframe() {
	// 获取最近打开的页面
	var length = $('.tabcontainer').length;
	if (0 == length) {
		return null;
	}
	return $('.tabcontainer')[length - 1].children[0];
};


function refreshIframe() {
	// 强制刷新iframe的src，解决oc自动化工具无法打开页面的问题
	if (!lastIfrLoad) {
		var lastIfr = getLastIframe();
		if (!lastIfr) {
			return;
		}
		lastIfr.src = lastIfr.src;
	}
};

// 打开菜单之前回调
function callBackBeforeOpen(tabId, tabType, menuId, destUrl, title, isHttps, tab, funcTest, arguments) {
	var count = 0;
	var postfix = '';
	for (var idx = 0; idx < beforeOpenTabFuncs.length; idx ++) {
		try
		{
			var func = beforeOpenTabFuncs[idx];
			var flag = func.call(this, tabId, tabType, menuId, destUrl, title, isHttps, funcTest, arguments);
			if (flag == false) {
				// 返回false，校验失败，不打开
				return false;
			} else if (flag != undefined) {
				count++;
				postfix = flag;
			}			
		} catch(err) {}
	}
	
	if (postfix != '') {
		tabId = tabId + '_' + postfix;
	}
	
	var allowRepeatOpen = false;
	// 全部返回true，说明允许重复打开，否则，不允许重复打开
	if (count > 0 && count == beforeOpenTabFuncs.length) {
		allowRepeatOpen = true;
	}
	
	
	var li = tab.findLiExist(tabId);
	if (li != null) {
		if (!allowRepeatOpen) {
			li.click();
			return false;			
		}
	}
	return tabId;
}

function openTabAndPage(destUrl, menuId, tab, tabId, title, noClose, isHttps, openMode, tabType) {
	setCookie(tabId, menuId);
	
	// 只给不要跳转SSO的菜单加menuId参数
	if (destUrl != undefined && !(destUrl[0]=='/' || (destUrl.length>5 && destUrl.substring(0, 5) == "http:"))) {
		if (destUrl.indexOf("?") != -1) {
			if (destUrl.indexOf("?menuid=") == -1
					&& destUrl.indexOf("&menuid=") == -1) {
				destUrl = destUrl + "&menuid=" + menuId;
			}
		} else {
			destUrl = destUrl + "?menuid=" + menuId;
		}	
	}

	destUrl = convertSecondaryDomain(destUrl);
	
	// 增加打开菜单的参数
	destUrl = addParamsToUrl(destUrl);
	
	// 增加UEE的版本号
	destUrl = addUEEVersionToUrl(destUrl);
	
	if ("N" == openMode) {
		window.open(destUrl);
		return;
	} else if ("W" == openMode) {
		var height = $(window).height();
		var width = $(window).width();
		window.open(destUrl, "", "fullscreen=yes,width="+width+",height="+height);
		return;
	}	
	
	// 回调打开前的操作，如果返回tabId，则打开，否则，不打开
	var arguments = [tabId, title, noClose, menuId, tab, destUrl, isHttps];
	var result = callBackBeforeOpen(tabId, tabType, menuId, destUrl, title, isHttps, tab, reallyOpenTab, arguments);
	if (result == false) {
		return;
	}

	tabId = result;
	reallyOpenTab(tabId, title, noClose, menuId, tab, destUrl, isHttps);
}

function reallyOpenTab(tabId, title, noClose, menuId, tab, destUrl, isHttps) {	
	var li = createTab(tabId, title, noClose, menuId);
	tab.addItem(li);

	li.data("destUrl", destUrl);

	var page = createPage(tabId, destUrl, isHttps);
	$('.main-right').append(page);
	
	var lastIfr = getLastIframe();
	lastIfrLoad = false;
	lastIfr.onload = function(){lastIfrLoad = true;};
	
	// 创建完菜单之后，统计次数
	countMenu(menuId);

	li.click();
	tabResize();
	
	// 清理变量 begin [Joey]
	li = null;
	page = null;
	// 清理变量 end [Joey]
	
	// setTimeout("refreshIframe()", 1000);

	setTimeout("bandIframeOnclick()",200);
}

function addUEEVersionToUrl(destUrl) {
	if (!destUrl) {
		return destUrl;
	}
	
	// 2016-4-8，mofify by y00171087 现网不能加build参数，会导致sso跳转失败，可能是url超长导致，解决办法是如果是跳转sso的url，不加build参数
	if (destUrl.indexOf("menuJumpWithSSO") != -1) {
		return destUrl;
	}
	
	if (destUrl.indexOf("build=") != -1) {
		return destUrl;
	}
	
	// URL中已经有参数，则追加build参数
	if (destUrl.indexOf("?") != -1) {
		destUrl = destUrl + "&build=" + $UEE.version;
	} else {
		destUrl = destUrl + "?build=" + $UEE.version;
	}
	return destUrl;
}

/**
 * 给url添加二级目录
 * 
 * @return
 * @remark add by wWX212174 2015-5-13 [Bug 90345] New: [江苏实验室]测试营销工作台发现历史问题。
 */
function convertSecondaryDomain(urlSrc)
{
    try
    {
        if(_ysp_top.publicObject["isSecondaryDomain"] == 'Y')
        {
            // 如果启用了二级目录 并且地市配置了业务域开关，则对菜单URL进行特殊处理
            var reg = /^\/(\w+)\/.+$/g;
            var tmpUrl = urlSrc;
            if(reg.test(tmpUrl))
            {
                var oriContext = tmpUrl.replace(reg,"$1");
                var transContext = _ysp_top.getCrmWebContext(oriContext);
                tmpUrl = tmpUrl.replace('/' + oriContext, transContext);
                urlSrc = tmpUrl;
            }
        }
    }
    catch(ex)
    {
    }
    return urlSrc;
}


function countMenu(menuId)
{
	var $Scope = this.sp;
	var $Model = $Scope.$Model;
	if (!$Model.portalParams || !$Model.portalParams.isNeedCountMenu)
	{
		return;
	}

	var $fire = $Scope.$Inject("$Fire");
	$fire({
		"service" : "/gadget/sm/SysParamAction/addCountToMenu",
		params : {
			"menuid" : menuId
		}
	}, $Scope);
}

function bandIframeOnclick(){
	var iframes = window.frames.length;
	try{
		$(window.frames[iframes-1].document).click(function(){
			var showMenuDiv = $(parent.document).find(".searchBuyPanel");
			showMenuDiv.eq(0).slideUp();

			if (!_ysp_top.sp.$Model.isManagePortal) {
			    $('.tool2').attr('style','')
			}
			
			$(parent.document).find(".tc-mask").css({
				'display' : 'none'
			});			

			// 关闭操作员信息右上角弹框
			closeAccountOpt();
			
			//清理变量 begin [Joey]
			showMenuDiv = null;
			//清理变量 end [Joey]
			
		});
	}catch(e){
	}
}

function getCurrentMenuId() {
	return $.cookie("com.huawei.boss.CURRENT_MENUID");
}

function setCookie(tabId, menuId) {
	$.cookie("com.huawei.boss.CURRENT_MENUID", menuId, {
		path : '/'
	});
	$.cookie("com.huawei.boss.CURRENT_TAB", tabId, {
		path : '/'
	});
}

function closeTab(tabId) {
	debugger;
	tab.closeTab(tabId);
}

function closeAllTab() {
	tab.closeAllTab();
}

function closeAllTabExceptOne(tabId) {
	
	tab.closeAllTabExceptOne(tabId);
}

function showTab(tabId) {
	var li = tab.findLiExist(tabId);
	if (li != null) {
		li.show();
		li.click();
	}
}

function hideTab(tabId) {
	debugger;
	var li = tab.findLiExist(tabId);
	if (li != null) {		
		var page = getPageById(tabId);
		li.hide();
		page.hide();
	}
}


// 判断是不是IE浏览器
function isIE() {
	if (navigator.userAgent.indexOf("MSIE") != -1) {
		return true;
	}
	return false;
}

var tab ;
initTabWidth();


function initTabWidth() {
	// ucd要求，中文tab页宽度为正常124，其他语言为177，真正tabwidth=入参宽度-2，因此传入126和179
	var locale = $.cookie()["u-locale"];
	var tabWidth = 179;
	if ("zh_CN" == locale) {
		tabWidth = 126;
	}
	tab = new ucd.Tab($(".tabCon"), tabWidth);
	changeTabCSS(tabWidth);
}

function changeTabCSS(width) {
	$(".navigatorBar .tabCon .tab-popup .scrollbar_container_outer").css({
	    width: width + "px"
	});
}



// 设置tab页激活回调方法
tab.setSecCallBack(function(dom) {
 
	// setCookie
	var tabId = dom.attr("innerId");
	var menuId = dom.attr("menuId");
	setCookie(tabId, menuId);
	
    // 解决问题单DTS2017032109661 
	var $iframe = $('.tabcontainer > iframe').filter('[innerid="' + tabId +'"]');
	
	$iframe.css({'height':'99%'});
	
	var $comScope = $(dom).scope();
	
	$comScope.$Get("$timeout")(function(){refreshHeight($iframe);},100);
	

	// 先show
	var page = getPageById(dom.attr('innerId'));
	$('.main-right > div').hide();
	page.show();

	// 再发消息通知内层
	var msg = {operation : "On_Tab_Show",tabId : tabId};

	msg = JSON.stringify(msg);

	var ifr = page.find("iframe")[0];
	ifr.contentWindow.postMessage(msg, "*");
	
	//变量赋值为null begin [Joey]
	ifr=null;
	page=null;
	//变量赋值为null end [Joey]
});


function refreshHeight($iframe){
	$iframe.css({'height' : "100%"});
};

function getUrlContext(destUrl, isUseSecondContext) {
	debugger;
	if (!destUrl) {
		return;
	}
	
	var idx = 0;
	if (isUseSecondContext) {
		idx = 1;
	}
	
	// 如果有resource.root，取resource.root后面第一个斜杠和resource.root之间的值
	var resRoot = "resource.root";
	if (destUrl.indexOf(resRoot) != -1) {
		var startIdx = destUrl.indexOf(resRoot) + resRoot.length + 1;
		var tmp = destUrl.substring(startIdx);
		var content = tmp.split('/')[idx];		
		return content;
	}
	
	// 如果没有resouce.root，判断是否是http开头的地址
	if (destUrl.indexOf('http') == 0) {
		var startIdx = destUrl.indexOf('//') + 2;
		var nextIdx = destUrl.indexOf('/', startIdx);
		startIdx = nextIdx + 1;
		var tmp = destUrl.substring(startIdx);
		var content = tmp.split('/')[idx];		
		return content;
	}
	
	// 不是以resouce.root开头，也不是http开头，则判断是否是/开头:
	// 如果是/开头，则取/后面紧跟的作为文根；否则，取当前系统的文根
	if (destUrl.indexOf('/') == 0) {
		var startIdx = 1;
		var tmp = destUrl.substring(startIdx);
		var content = tmp.split('/')[idx];		
		return content;
	}
	
	var content = $Scope.$Webapp;
	if (content.indexOf('/') == 0) {
		content = content.substring(1);
	}
	return content;	
}

// 设置tab页关闭回调方法
tab
		.setCloseCallBack(function(dom) {
			// 关闭菜单之前回调
			for (var idx = 0; idx < beforeCloseTabFuncs.length; idx ++) {
				var func = beforeCloseTabFuncs[idx];
				var tabId = dom.attr('innerId');
				var flag = func.call(this, tabId);
				// 只有返回false，才校验失败，不关闭
				if (flag == false) {
					return false;
				}
			}
			
			var page = getPageById(dom.attr('innerId'));
			var ifr = page.find("iframe")[0];
	// 本来是想用上边的关闭之前的回调来做校验的，但无奈不知道怎么在业务页面设置回调方法 只好再写一个调用业务页面的方法来判断
	try {
		if (undefined != ifr.contentWindow.beforeCloseTab) {
			var result = ifr.contentWindow.beforeCloseTab();
			if (result == false)
			{
				// 返回false 校验不通过 不关闭
				return false;
			}
		}
	} catch (err) {
	}

			// 先调用onbeforeunload方法
			try {
				if (undefined != ifr.contentWindow.onBesTabClose) {
					ifr.contentWindow.onBesTabClose();
				}
			} catch (err) {
			}

			// 先清空缓存			 
			var scope = parent.sp;
			var context;
			try {

			context = getUrlContext(dom.data('destUrl'), $Model.isUseSecondContext);
			scope.$Model.crtTabId = dom.attr('innerId');
			var $Fire = scope.$Get("$Fire");

			$Fire(
					{
						"service" : "/com.huawei.bes.sm.base.common.smmenuappboservice/getcontexturl",
						"params" : {
							"context" : context
						},
						"target" : "$Model.clearSessionUrl"
					}, scope).onafter(
					function() {
						 
						if (undefined != $Model.clearSessionUrl
								&& null != $Model.clearSessionUrl
								&& $Model.clearSessionUrl != "") {
							var parentUrl;
							if ($Model.isUseSecondContext) {
								parentUrl = "../../../../";
							} else {
								parentUrl = "../../../";
							}
							 
							$.ajax({
								type : "POST",
								contentType : "application/json",
								url : parentUrl + $Model.clearSessionUrl
										+ "?tabid=" + this.sp.$Model.crtTabId
							});
						}
					});
			} catch (err) {
			}

try {
	// 清理iframe内部 begin
	if(ifr.contentWindow && ifr.contentWindow.angular){
		ifr.contentWindow.angular.element("html").scope().$UI.dialog = null;
		ifr.contentWindow.angular.element("html").scope().$UI.msgbox = null;
		if(ifr.contentWindow.angular.element("html").scope().$Context && ifr.contentWindow.angular.element("html").scope().$Context.$scope){
			for(val in ifr.contentWindow.angular.element("html").scope().$Context.$scope.$$listeners){
				ifr.contentWindow.angular.element("html").scope().$Context.$scope.$$listeners[val]= null
			}
			ifr.contentWindow.angular.element("html").scope().$Context.$scope = null;
			ifr.contentWindow.angular.element("html").scope().$Context = null;
		}
		var caches = ifr.contentWindow.angular.element("html").scope().$Get("$cacheFactory").info();
		for(val in caches){
			ifr.contentWindow.angular.element("html").scope().$Get("$cacheFactory").get(val).removeAll();
			ifr.contentWindow.angular.element("html").scope().$Get("$cacheFactory").get(val).destroy();
		}
		ifr.contentWindow.angular.element("html").scope().$destroy();
		
		// clean $Controller
		if(ifr.contentWindow.$Controller){
			if(ifr.contentWindow.$Controller.bes){
				ifr.contentWindow.$Controller.bes.ad=null;
				ifr.contentWindow.$Controller.bes.agentdesktop=null;
				ifr.contentWindow.$Controller.bes.oc=null;
				ifr.contentWindow.$Controller.bes.besOcQRcode=null;
			}

		}
		ifr.contentWindow.$Controller = null;
	}
	//DTS2017101604053导致ie8一直加载去掉
	try
	{//Try is for sub-window access deny(security problem).
		var iwin = (ifr.self===ifr? ifr : ifr.contentWindow || window.frames[ifr.name]);
		try{
			var idoc = (iwin.document || ifr.contentDocument || ifr.contentWindow.document);
			if($.browser.msie)
			{//IE do need this to prevent memory leak and we do not use 'idoc.close()' after write, because it will trigger onload event which is unuseful.
			 //Just trigger onload event when <iframe onload="func()"/>, it will not trigger window.onload, because the events in document have been cleaned.
				ifr.src = "";
				idoc.write("");
			}else
			{//FireFox will get a history item while chrome won't send unload event by idoc.write("").
			 //And those browsers DONOT have memory problem on iframe remove, so code below is enough.
				iwin.location.replace("about:blank");
			}
			iwin = null, idoc = null;
		}catch(e)
		{//For different domain's page, if denied to access iwin(to get idoc), we should trigger unload by changing frame URL.   
			iwin.location.replace("about:blank");
		}
	}catch(e){}
	
	// for CRM page in iframe
	if ( ifr.contentWindow.jQuery ) {
		//IEMEMLEAK:4MB in IE8 render input
		ifr.contentWindow.jQuery.cache = {};
	}
	if(ifr.contentWindow.document){
		$(ifr.contentWindow.document).unbind("click"); 
	}
	//IEMEMLEAK: NOTEST, LEAK IN CHROME
	ifr.contentWindow.PortItem = null;
	ifr.contentWindow.Portlet = null;
	ifr.contentWindow.Layout = null;
	ifr.contentWindow.Popwin = null;//nocheck
	ifr.contentWindow.jBME = null;//nocheck
	ifr.contentWindow.MsgBox = null;
	ifr.contentWindow.Timer = null;             
	ifr.contentWindow.validator = null;
	if(ifr.contentWindow.$ && ifr.contentWindow.$.validator)
	{
		ifr.contentWindow.$.validator = null;
	}

} catch(e){}

ifr.parentNode.removeChild(ifr); 
try{
	page.remove();
}catch(e){}

	// 变量赋值为null
	ifr=null;
	page = null;
	dom=null;
	
	// 根据条件清空缓存
	clearUserSessionByCond();
	
	if(window.CollectGarbage){
		window.CollectGarbage();
	}
});

function clearUserSessionByCond() {
//	if(window._ysp_top.productPopupFlag == '1')
//    {
//	    window._ysp_top.productPopupFlag = '';
//    }
	// 如果当前打开的页面中，60131开头的菜单个数为0，则清空缓存
	if ($('.main-right').children('[innerid^=60131]').size() == 0
			&& $('.tabCon li').filter('[innerid=60131_oclogintemp]').size() == 0) {
		clearUserSession(this.sp);
	}

	// 清空oc的缓存
	window._ysp_top.readCardType = null;
}

function showNoticeDetail() {
	var noticeList = $('#noticelistdiv').children();
	for (var idx = 0; idx < noticeList.length; idx++) {
		var notice = $(noticeList[idx]);
		if (notice.is(":visible")) {
			var noteId = notice.attr('noteId');
			// 找不到noteId，说明只有一个noteLi，即取第0个即可
			if (!noteId) {
				notice = $(noticeList[0]);
				noteId = notice.attr('noteId');
			}
			_ysp_top.popShowNotice(noteId, true);
			break;
		}
	}
}

function bindOnMenu() {
	menu = $(this);
	if (menu.attr('id') == 'noticetop') {
		debugger;
		$("#popNote").addClass("sm_windowBoxwrap");
		showNoticeDetail();
		return;
	}
	
	if (menu.hasClass('noneedopenwithtab')) {
		return;
	}
	
	if ("div" == menu[0].tagName.toLowerCase()) {
		childrendiv = menu.children()[0];
		menu = $(childrendiv);
	} else if ("a" == menu[0].tagName.toLowerCase()) {
		// a没有设置name属性，div有name属性
		if (undefined == menu.attr('name') || "" == menu.attr('name')) {
			menu.attr('name', menu.html());
		}
	} else if ("li" == menu[0].tagName.toLowerCase()) {
		childrendiv = menu.children()[0];
		menu = $(childrendiv);
	}
	var tabId = menu.attr('innerId');
	var openMode = menu.attr('openMode');
	var tabType = menu.attr('tabType');
	
	var destUrl = menu.data('destUrl');
	if (undefined == destUrl) {
		destUrl = menu.attr('destUrl');
	}
	if (undefined == destUrl) {
		destUrl = menu.parent().data('destUrl');
	}

	isHttps = menu.data('isHttps') == "true" || menu.data('isHttps');
	if (undefined == isHttps) {
		isHttps = menu.attr('isHttps') == 'true';
	}

	title = window.$UEE.i18n(menu.attr('name'));
	
	if (tabId != "sitemap")
	{
		visitRule = menu.data('visitRule');
		
		// 打开的为应急菜单
		if (isOpenEmergencyMenu(visitRule))
		{
			// 判断是否可以打开应急菜单
			if (!hasOpenEmergencyMenu(tabId))
			{
				return;
			}
		}
		// 打开的为非应急菜单
		else
		{
			// 判断是否可以打开非应急菜单
			if (!hasOpenNormalMenu(tabId))
			{
				return;
			}
		}
	}

	if ("showmenudiv" == menu.parent().parent().parent().attr("id")) {
		//var hasClickMenu = $.cookie()["searchclicklist"];
		var hasClickMenu = window.localStorage.getItem("searchclicklist");

		if (undefined == hasClickMenu || "" == hasClickMenu) {
			hasClickMenu = title;
		}

		if (undefined != hasClickMenu) {
			if (hasClickMenu.split('|').length < 10) {
				if (hasClickMenu.indexOf(title) != -1) {
					hasClickMenu = hasClickMenu.replace(title, "").replace(
							"||", "|");
				}

				hasClickMenu = title + "|" + hasClickMenu;
			} else {
				if (hasClickMenu.indexOf(title) != -1) {
					hasClickMenu = hasClickMenu.replace(title, "").replace(
							"||", "|");
				}
				var index = hasClickMenu.lastIndexOf('|');
				hasClickMenu = hasClickMenu.substr(0, index);

				hasClickMenu = title + "|" + hasClickMenu;
			}

			hasClickMenu = hasClickMenu.replace("||", "|");
		}

		//$.cookie("searchclicklist", hasClickMenu);
		window.localStorage.setItem("searchclicklist",hasClickMenu);

	}
	openNewTab(tabId, destUrl, isHttps, title, false, tabId, openMode, tabType);
}
// 给所有a绑定click事件
$(".menu_btn").delegate("a,.openwithtab", "click", bindOnMenu);

$(".toolCon .tc-mask").css({
	width : '0px',
	height : '50px'
});

setTipsHover();

function setTipsHover() {
	$(".toolCon li").hover(function(e) {
		if ($(e.target).attr("id") != "bes.sm.salesworkbench")
		{
			var tcMaskList = $(".tc-mask");
			if (undefined != tcMaskList)
			{
				for (var i=0; i< tcMaskList.length; i++)
				{
					if ($(".tc-mask:eq(" + i + ")").attr("id") == "bes.sm.salesworkbench")
					{
						$(".tc-mask:eq(" + i + ")").css({
							'display' : 'none'
						}).stop().animate({
							width : 0,
							height : 50
						}, 200);
						
						break;
					}
				}
			}

			if (!_ysp_top.sp.$Model.isManagePortal) {
			    $('.tool2').attr('style','')
			}
			
			// 设置变量为null begin [Joey]
			tcMaskList = null;
			// 设置变量为null end [Joey]
		}
		
		var $pop = $(this).children('.tc-mask').children(".tc-popup");
		$(this).children(".tc-mask").css({
			'display' : 'block'
		}).stop().animate({
			width : $pop.width(),
			height : ($pop.height() + 20)
		}, 300);
	}, function(e) {
		var divId = $(e.target).attr("id");
		if (divId == "bes.sm.salesworkbench" || divId == "bes.sm.salesworkbench.popup" || divId == "bes.sm.salesworkbench.title" 
			|| divId == "bes.sm.salesworkbench.content" || divId == "saleConsoleTel" || divId == "saleConsoleBtn" || divId == "bes.sm.salesworkbench.li")
		{
			if (!_ysp_top.sp.$Model.isManagePortal) {
			    $('.tool2').attr('style','background-color: #7A8397;color: #c5ccd5');
			}
		}
		
		$(this).children(".tc-mask:not([id='bes.sm.salesworkbench'])").css({
			'display' : 'none'
		}).stop().animate({
			width : 0,
			height : 50
		}, 200);
	});
}

/* 弹出框关闭 */
$('.windowBox .closeBox').on('click', function() {
	// $('body').css({"overflow":"auto"});
	$('.fullcover').hide();
	$(this).parents('.windowBox').remove();
});

$(".fullcover").bind("mousewheel", function(event) {
	event.stopPropagation();
	event.preventDefault();
	return false;
});

/* 页面最小高度要占满屏幕 */
var mainHeight = $(".mainImpl").height();
var windowHeight = $(window).height();
if (mainHeight < windowHeight) {
	$(".mainImpl").height(windowHeight);
}
$(window).resize(function() {
	var mainHeight = $(".mainImpl").height();
	var windowHeight = $(window).height();
	if (mainHeight < windowHeight) {
		$(".mainImpl").height(windowHeight);
	}
	
	tabResize();
});

// search dropList
$(".pgHeader .searchBar").click(searchFocusIn).find("input").focusin(
		searchFocusIn).focusout(searchFocusOut).parents(".pgHeader").find(
		".droplistIcon").click(function(e) {
	$(".searchPopup").toggle();
}).siblings(".searchPopup").find("li").click(function(e) {

	$(".searchPopup").hide();
	$(".searchPopup li.selected").removeClass("selected");
	$(e.currentTarget).addClass("selected");
	$(".pgHeader .sh-value").text($(e.currentTarget).text());
	$(".pgHeader .sh-value").attr("searchId", $(e.currentTarget).attr("id"));

	fadeShowSearchMenu();
});
function searchFocusIn(e) {
	$(".searchBar").addClass("active");
	e.stopPropagation();
}
function searchFocusOut(e) {
	$(".searchBar").removeClass("active");
	// $(".searchBuyPanel").eq(0).slideUp();
}

// 为菜单的按钮增加打开tab的绑定
$(".searchBuyPanel").find(".tab").delegate("a", "click", bindOnMenu);

// 查询按钮绑定事件
$(".searchButton").bind("click", function() {
	 
	try
	{
	    $(document).find('.tool2').attr('style','');
	    $(document).find(".tc-mask").css({
		    'display' : 'none'
	    }).stop().animate({
		    width : 0,
		    height : 50
	    }, 200);
	}
	catch (ex)
	{
    }
	  
	var $button = $(this);
	var scope = $button.scope();
	var searchId = $(".pgHeader .sh-value").attr("searchId");
	var $Fire = scope.$Get("$Fire");
	var searchValue = $(".sh-inputCon").find("input").val();
	searchValue = filterSpecialChar(searchValue);
	
	if(searchValue == undefined || searchValue.trim() == ""){
		return ;
	}
	
	if ("menuSearch" == searchId || "all-function" == searchId) {
		$Fire({
			"service" : "/smsearch2vsearch/searchMenu",
			"params" : {
				"menuname" : searchValue
			},
			"target" : "$Model.searchMenuList"
		}, scope).onafter(function() {
			 
			var menuList = scope.$Model.searchMenuList;
			showSearchMenus(menuList, searchValue);
		});
	}

});

function filterSpecialChar(value){
	if(value != undefined && value.trim()!=""){
		value = value.trim();
		var result = "";
		var specialCharList = "+-=&|><!(){}[]^\"~*?:\\/";
		var length = value.length;
		var char;
		for(var index =0;index < length;index++){
			char = value[index];
			if(specialCharList.indexOf(char) == -1){
				result += char;
			}
		}
		
		return result;
	}
	
	return value;
}
/** 输入框状态 * */
$("#search_info_text").add('input[type="text"]').each(
		function(index, target) {

			$(target).focusin(
					function(e) {
						try
						{
							if (e.target.id != "saleConsoleTel")
						    {
								$(document).find('.tool2').attr('style','');
								$(document).find(".tc-mask").css({
									'display' : 'none'
								}).stop().animate({
									width : 0,
									height : 50
								}, 200);
						    }
						}
						catch (ex)
						{
					    }
						
						if ($(this).val() == $(this).attr("prompt"))
							$(this).val("");
						
						if(e.target.id == "search_info_text"){
							var searchId = $(".pgHeader .sh-value")
									.attr("searchId");
							$(this).css("color","#333");
							if ("menuSearch" == searchId
									|| "all-function" == searchId) {
								var menuPopupUL = $(".searchBuyPanel").find(".tab")
										.empty();
								showSearchAndClickMenus(menuPopupUL);
							}
						}
					}).change(
					function(e) {

						var t = $(this);

						if (t.val() == t.attr("prompt")
								|| (t.val() == "" && t.attr("prompt"))) {
							t.val(t.attr("prompt")).css("color", "#333");
						} else {
							t.css("color", "#333333");
						}
					}).focusout(function(e) {

				$(this).change();
				// $(".searchBuyPanel").eq(0).slideUp();

			}).change();
		});

/*
 * $(".searchBuyPanel").bind("mouseleave", function() {
 * $(".searchBuyPanel").eq(0).slideUp(); });
 */

var lastTime;
// 词关联
$(document).delegate("#search_info_text","keyup", function(e) {


	
	lastTime = (new Date).getTime();
	
	e.timeStamp = lastTime;
	//console.log("I'm keyup event.");
	//debugger;
	setTimeout(function(){

		//console.log("I'm keyup before event timeout");
		if(lastTime - e.timeStamp == 0){
		//	console.log("I'm keyup event timeout function.");
			if ($("#search_info_text").val()) {

				var $searchInput = $("#search_info_text");
				var scope = $searchInput.scope();
				var searchId = $(".pgHeader .sh-value").attr("searchId");
				var $Fire = scope.$Get("$Fire");
				var searchValue = $(".sh-inputCon").find("input").val();
				
				searchValue = filterSpecialChar(searchValue);
				
				if(searchValue == undefined || searchValue.trim() == ""){
					return ;
				}
				
				if ("menuSearch" == searchId || "all-function" == searchId) {
					$Fire({
						"service" : "/smsearch2vsearch/searchMenu",
						"params" : {
							"menuname" : searchValue
						},
						"target" : "$Model.searchMenuList"
					}, scope).onafter(function() {
						var menuList = scope.$Model.searchMenuList;
						showSearchMenus(menuList, searchValue);
					});
				}
			} else {
				var menuPopupUL = $(".searchBuyPanel").find(".tab").empty();
				showSearchAndClickMenus(menuPopupUL);
			}
		}
	},300);

//console.log("keyup search_info_text input.");
	

});

function showSearchAndClickMenus(menuPopupUL) {
	//var lastClickMenu = $.cookie()["searchclicklist"];
	var lastClickMenu = window.localStorage.getItem("searchclicklist");
	if (undefined == lastClickMenu || "" == lastClickMenu) {
		return;
	}

	var searchClickMenu = lastClickMenu.split('|');

	if (0 == searchClickMenu.length) {
		return;
	}

	for ( var index = 0; index < searchClickMenu.length; index++) {
		var menuName = searchClickMenu[index];
		if ("" != menuName && undefined != menuName) {

			var divContent = $("<div></div>").css({
				"width" : "90%",
				"overflow" : "hidden",
				"text-overflow" : "ellipsis",
				"white-space" : "nowrap",
				"font-size" : "12px",
				"line-height" : "30px",
				"float" : "left"
			});				
			
			divContent.append(menuName);
			divContent.attr("title", menuName);
			
			var historyItem = $("<div class='clickHistoryItem'></div>");
			
			if(index%2 != 0){
				historyItem.addClass("even");
			}
			
			var searchNameDiv = historyItem.append(divContent)
					.append("<div class='icon deleteClickMenu' style='float:right'></div>");

			menuPopupUL.append(searchNameDiv);
		}
	}

	var clearHistory = window.$UEE.i18n('SM.LOGIN.MESSAGE.SEARCH_HISTORY_CLEAR');

	var clearDiv = $("<div class='even text_center clearAllClickMenu' id='clear_opt' style='border-_ysp_top: solid 1px #E2E8EE;'></div>");
	var spanDiv = $("<span class='clear_color'></span>").append(clearHistory);

	clearDiv.append(spanDiv);

	menuPopupUL.append(clearDiv);
	menuPopupUL.parent().slideDown();
}

$(".searchBuyPanel").delegate(".clickHistoryItem,.showMenuDiv>a", "click",
		function(e) {
			// 收缩panel
			$(".searchBuyPanel").eq(0).slideUp();
			var chooseItem = $(this);
			if (typeof(chooseItem.attr("class")) != 'undefined'&&chooseItem.attr("class").indexOf("clickHistoryItem") != -1) {
				var chooseValue = chooseItem.text();
				$("#search_info_text").val(chooseValue);
				
				$(".searchButton").click();
			}
			
		});

/**
 * 删除单条菜单记录
 */
$(".searchBuyPanel").delegate(".deleteClickMenu", "click", function(e) {

	var clickItem = $(this);

	var parent = clickItem.parent();

	var deleteName = parent.text();
	//var hasClickMenu = $.cookie()["searchclicklist"];
	var hasClickMenu = window.localStorage.getItem("searchclicklist");

	if (hasClickMenu.indexOf(deleteName) != -1) {

		hasClickMenu = hasClickMenu.replace(deleteName, "").replace("||", "|");
	}

	hasClickMenu = hasClickMenu.replace("||", "|");

	//$.cookie("searchclicklist", hasClickMenu);
	window.localStorage.setItem("searchclicklist",hasClickMenu);

	var menuPopupUL = $(".searchBuyPanel").find(".tab").empty();
	showSearchAndClickMenus(menuPopupUL);
	
	e.stopPropagation();
	
});

/**
 * 清除所有的点击记录
 */
$(".searchBuyPanel").delegate("#clear_opt", "click", function(e) {
	//$.cookie("searchclicklist", "");
	window.localStorage.removeItem("searchclicklist");

	var menuPopupUL = $(".searchBuyPanel").find(".tab").empty();
	showSearchAndClickMenus(menuPopupUL);
});

function showSearchMenus(menuList, searchValue) {
	// var menuList = scope.$Model.searchMenuList;

	if (menuList.length < 0) {
		return;
	}
	
	menuList.sort(function(a,b){
			    		return a.index - b.index;
			    		});
	
	var menuPopupUL = $(".searchBuyPanel").find(".tab").empty();
	for ( var index = 0; index < menuList.length; index++) {
		// var liNode = $("<li></li>");
		var divHiden = $("<div></div>").css({
			"width" : "95%",
			"overflow" : "hidden",
			"text-overflow" : "ellipsis",
			"white-space" : "nowrap",
			"font-size" : "12px",
			"line-height" : "30px"
		});

		if(index%2 != 0){
			divHiden.addClass("even");
		}
		
		divHiden.addClass("showMenuDiv");
		divHiden.attr("title", menuList[index].menuPath);

		var resultPath = shortMenuPath(menuList[index].menuPath,menuList[index].highLight);
		var aNode = $("<a></a>").attr({
			href : "javascript:;",
			innerId : menuList[index].menuId,
			name : menuList[index].menuName,
			openMode : menuList[index].openModule
		}).append(resultPath);
		aNode.data('destUrl', menuList[index].menuUrl);
		aNode.data('isHttps', menuList[index].httpsFlag);
		aNode.data('visitRule', menuList[index].visitRule);
		aNode.data('openMode',menuList[index].openModule);

		divHiden.append(aNode);

		// var iconDiv = $("<div class=\"icon\"></div>");

		// divHiden.append(iconDiv);

		menuPopupUL.append(divHiden);

	}
	// 记录首次
	//$.cookie("lastmenusearch", searchValue);
	window.localStorage.setItem("lastmenusearch", searchValue);
	$(".searchBuyPanel").eq(0).slideDown();
	fadeShowSearchMenu();
};

function shortMenuPath(menuPath ,highLight) {
	var currentLocale = $.cookie()["u-locale"];
	var resultPath = "";
	switch (currentLocale) {
	case "zh_CN":
		var pathList = menuPath.split(" >> ");
		
		var highLightPath = highLight.split(" >> ");
		
		var maxLength = 45;// contains all charctar

		var menuLength = menuPath.length - pathList.length;
		var diffLength = menuLength - maxLength;

		if (diffLength > 0) {

			for ( var index = 1; index < pathList.length - 1; index++) {
				var curPathMenu = pathList[index];
				
				var curHighLightPath = highLightPath[index];
				
				if (curPathMenu.length >= diffLength) {
					
					// curPathMenu = curPathMenu.substr(0, curPathMenu.length
					// - diffLength - 2);
					// curPathMenu += "...";
					// pathList[index] = curPathMenu;
					
					var stack = [];
					
					var shortCutLength = diffLength ;
					
					var spanStartElement = "<span class=\"font_blue\">";
					
					var spanEndElement = "</span>";
					
					while(shortCutLength > 0){
						
						// 判断是否以"</span>"结尾
						var endSpan = false;
						var spanEndLastIndex = curHighLightPath.lastIndexOf(spanEndElement);
						
						if(-1 != spanEndLastIndex){
							endSpan = spanEndLastIndex == curHighLightPath.length - spanEndElement.length;
						}
						
						
						// var endSpan =
						// curHighLightPath.endsWith(spanEndElement);
						
						// var startSpan =
						// curHighLightPath.endsWith(spanStartElement);
						
						// 判断是否以"<span class=\"font_blue\">"结尾
						
						var startSpan = false;
						
						var spanStartIndex = curHighLightPath.lastIndexOf(spanStartElement);
						
						if(-1 != spanStartIndex){
							startSpan = spanStartIndex == curHighLightPath.length - spanStartElement.length;
						}
						
						if(endSpan){
							curHighLightPath = curHighLightPath.substr(0,curHighLightPath.length - spanEndElement.length );
							stack.push(spanEndElement);
						}
						
						if(startSpan){
							curHighLightPath = curHighLightPath.substr(0,curHighLightPath.length - spanStartElement.length );
							stack.push(spanStartElement);					
						}
						
						if(!endSpan&&!startSpan){
							curHighLightPath = curHighLightPath.substr(0,curHighLightPath.length - 1);
							shortCutLength--;
						}
						
					}
					
					stack.push(curHighLightPath + "...");
					
					var loop = stack.length;
					var showMenuPath = "";
					for(var pop = 0;pop < loop;pop ++){
						showMenuPath += stack.pop();
					}
					
					highLightPath[index] = showMenuPath;
					
					break;
				} else {
					highLightPath[index] = "...";
					diffLength = diffLength - curPathMenu.length ;
				}

			}

			for ( var index = 0; index <= highLightPath.length - 1; index++) {
				if (highLightPath.length - 1 == index) {
					resultPath += highLightPath[index];
				} else {
					resultPath += highLightPath[index] + " >> ";
				}
			}
		} else {
			resultPath = highLight;
		}

		break;
	case "en_US":
		resultPath = menuPath;
		break;
	default:
		resultPath = menuPath;
		break;
	}

	return resultPath;
}


/**
 * 初始化执行 最近查询的记录
 */
fadeShowSearchMenu();
/**
 * 淡化显示当前搜索菜单
 */
function fadeShowSearchMenu() {
	
	var searchId = $(".pgHeader .sh-value").attr("searchId");
	if ("menuSearch" == searchId || "all-function" == searchId) {
		//var lastmenusearch = $.cookie()["lastmenusearch"];
		var lastmenusearch = window.localStorage.getItem("lastmenusearch");
		var tt = $("#search_info_text");
		$("#search_info_text").attr("prompt", lastmenusearch);

		/*
		 * if (tt.val() == tt.attr("prompt") || (tt.val() == "" &&
		 * tt.attr("prompt"))) {  
		 * tt.val(tt.attr("prompt")).css("color", "#adadad"); } else {
		 * tt.css("color", "#333"); }
		 */
		/*if(tt.val() == "" && tt.attr("prompt")){
			tt.val(tt.attr("prompt")).css("color", "#333");
		}else{
			tt.css("color", "#333");
		}*/
		tt.css("color", "#333");
	} else {
		$("#search_info_text").val("");
	}
}

/*
 * $(".accountOpt").data("open",false).click(function(e){ var isOpen =
 * $(this).data("open"); var left = $(this).offset().left-60;
 * 
 * $(this).find(".ao-popup").css("left",left);
 * 
 * 
 * $(this).data("open",!isOpen).toggleClass("open").find(".ao-popup").toggle();
 * e.stopPropagation(); });
 */

$(document).click(function(e) {
	$(".searchPopup").hide();
	searchFocusOut();
	$(".searchBuyPanel").eq(0).slideUp();
	
	// 关闭操作员信息右上角弹框
	closeAccountOpt();
	
	var divId = $(e.target).attr("id");
	if (divId == "bes.sm.salesworkbench" || divId == "bes.sm.salesworkbench.popup" || divId == "bes.sm.salesworkbench.title" 
		|| divId == "bes.sm.salesworkbench.content" || divId == "saleConsoleTel" || divId == "saleConsoleBtn" || divId == "bes.sm.salesworkbench.li")
	{
		return;
	}
	
	if (!_ysp_top.sp.$Model.isManagePortal) {
		$('.tool2').attr('style','')
	}
	
	$(".tc-mask").css({
		'display' : 'none'
	}).stop().animate({
		width : 0,
		height : 50
	}, 200);
	// var popup = $(".accountOpt");
	// if(popup.data("open")) popup.click();

});

function initSecondContext($Scope) {
	_ysp_top.publicObject["isSecondaryDomain"] = 'N';
	this.sp = $Scope;
	var $Model = $Scope.$Model;
	var $fire = $Scope.$Inject("$Fire");
	$fire({
		"service" : "/gadget/sm/SysParamAction/isUseSecondContext",
		"target" : "$Model.isUseSecondContext",
	}, $Scope).onafter(function() {

		if ($Model.isUseSecondContext) {
			_ysp_top.publicObject["isSecondaryDomain"] = 'Y';
			$fire({
				"service" : "/sm/DataDictAction/getDict",
				"param-dictcode" : "SYS.PORTAL_SECOND_CONTEXTPATH",
				"target" : "$Model.secondContext",
			}, $Scope);
		}
	});
}

function getCrmWebContext(webContext) {
	var isUseSecondContext = _ysp_top.sp.$Model.isUseSecondContext;
	var secondContext = _ysp_top.sp.$Model.secondContext;
	var transContext = webContext;
	// 如果没有启用二级目录则原样返回
	if (isUseSecondContext && secondContext) {
		transContext = secondContext[webContext] || transContext;
	}
	// 防止字典中忘记配开头的斜杠
	if (transContext.indexOf("/") != 0) {
		transContext = "/" + transContext;
	}
	return transContext;
}

function openMenu(menuId) {
	var $Scope = this.sp;
	var $fire = $Scope.$Inject("$Fire");
	
	$fire({
		"service" : "/gadget/common/operator/queryLoginOpenMenuByMenuId",
		"target" : "$Model.tempMenu",
		params : {
			'menuId' : menuId
		}
	}, $Scope).onafter(function() {
		if ($Model.tempMenu && $Model.tempMenu.length < 1)
		{
			return;
		}
		var menu = $Model.tempMenu[0];
		var menuId = menu.menuId;
		var destUrl = menu.menuUrl;
		var httpsFlag = false;
		var openMode = menu.openMode;
		var tabType = menu.tabType;

		var accessTimeValue;
		if (menu.smmenuExtAttrVO && menu.smmenuExtAttrVO.length > 0)
		{
			for (var idx = 0; idx < menu.smmenuExtAttrVO.length; idx++)
			{
				var attr = menu.smmenuExtAttrVO[idx];
				if (attr.attrName == "HTTPS") {
					httpsFlag = attr.attrValue == "Y";
				}
				if (attr.attrName == "ACCESS_TIME") {
					accessTimeValue = attr.attrValue;
				}
			}
		}
		
		var title = menu.menuName;
		if (menu.smmenuLangVO && menu.smmenuLangVO.length > 0)
		{
			title = menu.smmenuLangVO[0].menuName;
		}
		
		openNewTab(menuId, destUrl, httpsFlag, title, false, menuId, openMode, tabType, accessTimeValue);
	});
}

function openMenuPublic(menuObject)
{
	var menuId = menuObject.id;
	var destUrl = menuObject.menuUrl;
	var httpsFlag = false;	
	var title = menuObject.menuName;
	
	openNewTab(menuId, destUrl, httpsFlag, title, false, menuId);
}

/**
 * 查询缓存中和表中的系统参数值
 * 
 * @param param
 *            格式 ('模块Id:系统参数id,模块Id:系统参数id,....')
 * @return
 */
function getSystemParam(param)
{
    var gspUrl = this.sp.$Model.contextPath + "/ngportal/getSystemParam.action";
    var params = {'param':param};
    return ajaxPost(params,gspUrl);
}

/**
 * ajax post请求公用方法
 * 
 * @param param
 * @param url
 * @return
 */
function ajaxPost(params,url)
{
  var result = "";
  try
  {
      $.ajax({
          url: url,
          data: params,
          type: "post",
          dataType:"text",
          async:false,
          cache:false,
          success:function(data)
          {
              result = data;
          }
      });
  }
  catch (ex)
  {
      alert(ex.message);
  }
  return result;
}

function initProtocolType($Scope) {
	this.sp = $Scope;
	protocolType = $Scope.$Model.protocolType;

	var $fire = $Scope.$Inject("$Fire");
	$fire({
		"service" : "/gadget/common/operator/initMenu",
		"target" : "$Model.shortMenuList",
	}, $Scope).onafter(function() {
		initShortMenu($Scope);
	});

	$fire({
		"service" : "/SMUserAction/getloginuserinfo",
		"target" : "$Model.userInfo",
	}, $Scope).onafter(function() {
		initUserInfo($Scope);
		initAccountOpt();
	});

	/*$fire({
		"service" : "/sm/login/switchdata/changeBeLogo",
		"target" : "$Model.belogo",
	}, $Scope).onafter(function() {
		setBeLogo($Model.belogo.logo);
	});*/

	/*var loginOpenMenuId = $Scope.$Params.loginOpenMenuId;
	if (loginOpenMenuId == "" || loginOpenMenuId == null) {
		$fire({
			"service" : "/com.huawei.bes.sm.login.smrolequeryappbo/queryloginopenmenuid",
			"target" : "$Model.custMenus",
		}, $Scope).onafter(function() {
			initCustMenu($Scope);
		});
	} else {
		$fire({
			"service" : "/gadget/common/operator/queryLoginOpenMenuByMenuId",
			"target" : "$Model.custMenus",
			params : {
				'menuId' : loginOpenMenuId
			}
		}, $Scope).onafter(function() {
			initCustMenu($Scope);
		});
	}*/	
	$fire({
		"service" : "/gadget/sm/SysParamAction/getContextPath",
		"target" : "$Model.contextPath",
	}, $Scope);
	
	// 初始化框架需要的一些参数
	$fire({
		"service" : "/SMPortalAction/getPortalParams",
		"target" : "$Model.portalParams",
	}, $Scope).onafter(function() {
		//unionCash.initIcon($Scope);
		$(document).attr("title", $Model.portalParams.portalTitle);
		
		var shortcutPath = $Model.portalParams.shortcutPath;
		if (shortcutPath != undefined && shortcutPath != null && shortcutPath != "")
	    {
	        var linkTag = "<link rel=\"shortcut icon\" type=\"image/ico\" href=\"" + shortcutPath + "\" /> "
	        $($('head')[0]).append(linkTag); 
	    }
		
		_ysp_top.publicObject["ngcrm_province"] = $Model.portalParams.currentProvince;
		initEmergency($Scope);
		
		portalGadgetApi.initPortalGadget($Scope);
		
		if($Model.portalParams.locked){
			$("#lockPageDiv").show();
		}
		
		if ($Model.portalParams.custJsPaths) {
			for (var idx = 0; idx < $Model.portalParams.custJsPaths.length; idx++) {
				loadCustJs($Model.portalParams.custJsPaths[idx]);
			}
		}
		
	});
	
	debugger;
	
	$fire({
		"service" : "/meta/dictkey",
		"params" : {"dictkeylist":["FrequenceMenu"]},
		"target" : "$Model.frequenceMenu",
	}, $Scope).onafter(function(){
		debugger;
		
		if ($Model.frequenceMenu && $Model.frequenceMenu["FrequenceMenu"]) {
			
			/*var menuMap = new Map();
			$.each($Model.frequenceMenu, function(i, polyphone){
				menuMap.set(i, polyphone);
			});*/
			
			var menuList = $Model.frequenceMenu["FrequenceMenu"];
			
			for ( var idx = 0; idx < menuList.length; idx++) {
				debugger;
				var newMenu = $('.caiDanLianJie');
				var a = $('<a onclick = openCtzMenu("'+ menuList[idx].key + '","' +  menuList[idx].value + '")>' + menuList[idx].key + '</a></br>');
				
				newMenu.append(a);
				this.loadDomNode(newMenu);
			}	
		}
		
	});;
	
	$fire({
		"service" : "/sm/DataDictAction/getDict",
		"param-dictcode" : "SYS.AGENT_TYPE",
		"target" : "$Model.noteChanTypeMap",
	}, $Scope);
	
	$fire({
		"service" : "/sm/DataDictAction/getDict",
		"param-dictcode" : "SYS.DATA_STATUS",
		"target" : "$Model.noteStatusMap",
	}, $Scope);
	
	$fire({
		"service" : "/sm/DataDictAction/getDict",
		"param-dictcode" : "SYS.NOTE_GRADE",
		"target" : "$Model.noteGradeMap",
	}, $Scope);
	
};

function openCtzMenu(key,value)
{
	debugger;
	
	_ysp_top.$BES.$Portal.tabpanel.createTabItem({

	       title : key,

	       url : value,

	       id :key,

	       pageid : "",

	       httpsFlag : "",

	       openMode : "0",

	       tabType : "",

	       forceRefresh : ""

	    });
	
};

function loadDomNode(newMenu)
{
	debugger;
	domNode = $(newMenu)[0];
	$(document).scope().$Get('$compile')(domNode)($(document).scope());
};

function onLoadPage($Scope) {
	var crtBeId = _ysp_top.$BES.$ContextAccessor.getBeId();
	$('#crt-be').html(crtBeId);
	
	this.sp = $Scope;
	var $fire = $Scope.$Inject("$Fire");
	$Model = $Scope.$Model;

	$fire({
		"service" : "/gadget/sm/SysParamAction/getProtocolType",
		"target" : "$Model.protocolType",
	}, $Scope).onafter(function() {
		initProtocolType($Scope);
	});


	$fire({
	        "service" : "/SMPortalAction/queryBeName",
	        "param-beId" : crtBeId,
	        "target" : "$Model.crtBeName",
	    }, $Scope).onafter(function() {
	    	var crtBeName = $UEE.i18n('SM.LOGIN.TITLE.CURRENT_BE') + ':' + $Model.crtBeName;
	    	$('#crt-be').attr('title', crtBeName);
	    });
    
};

function initShortMenu($Scope) {
	var $Model = $Scope.$Model;

	var menus = $Model.shortMenuList;

	var leftMenuList = [];

	var rightHeadList = [];

	for ( var idx = 0; idx < menus.length; idx++) {

		if (menus[idx].displayPostion == "2") {
			leftMenuList.push(menus[idx]);
		} else {
			rightHeadList.push(menus[idx]);
		}
	}

	var leftMenu = new leftShortMenu();
	leftMenu.init(leftMenuList);

	setTipsHover();

	var rightHeadMenu = new portalRightHeadMenu();
	rightHeadMenu.init(rightHeadList);

	$(".accountOpt").click( function(e) { accountOptClick(e); });
}


function initUserInfo($Scope) {
	var $Model = $Scope.$Model;

	$Model.orgname = $Model.userInfo.orgName;
	$Model.username = $Model.userInfo.userName + " " + $Model.userInfo.loginId;

	$("#li_show_oper_info").attr("title", $Model.orgname + "\n" + $Model.username);
}

/*function setBeLogo(beLogo) {
	debugger;
    if(!beLogo){
    	// beLogo不存在用定制的，定制的不存在，则取默认预置的    	
        beLogo = "img/logo.png";
    } else if(beLogo.length > 100) {
        // 此处大于100用于判断是否是base64编码
    	 beLogo = "data:image/png;base64," + beLogo;
    }

    var imgNode = $("<img></img>").attr("src", beLogo); 
    _ysp_top.window.$("#beslogo").html(imgNode);
}*/

function initCustMenu($Scope) {
	var menuList = $Scope.$Model.custMenus;
	for ( var i = 0; i < menuList.length; i++) {
		var menu = menuList[i];
		var destUrl = menu.menuUrl;
		var isHttps = getHttpsFlag(menu);
		var menuId = menu.menuId;
		var title = getMenuName(menu);
		var openMode = menu.openMode;
		var tabType = menu.tabType;
		if (i == 0) {
			openNewTab(menuId, destUrl, isHttps, title, true, menuId, openMode, tabType);
		} else {
			openNewTab(menuId, destUrl, isHttps, title, false, menuId, openMode, tabType);
		}
	}
}

function getHttpsFlag(menu) {
	var menuAttrs = menu.SMMenuExtAttrVO;
	if (null == menuAttrs || undefined == menuAttrs) {
		menuAttrs = menu.smmenuExtAttrVO;

		if (null == menuAttrs || undefined == menuAttrs) {
			return false;
		}
	}

	for ( var i = 0; i < menuAttrs.length; i++) {
		var menuAttr = menuAttrs[i];
		if ('HTTPS' == menuAttr.attrName && 'Y' == menuAttr.attrValue) {
			return true;
		}
	}
	return false;
}

function getMenuName(menu) {
	var menuLangs = menu.SMMenuLangVO;
	if (menuLangs == null) {
		menuLangs = menu.smmenuLangVO;
	}

	if (menuLangs.length == 0) {
		return menu.menuName;
	}
	return menuLangs[0].menuName;
}

function isIE() {
	if (navigator.userAgent.indexOf("MSIE") > 0) {
		return true;
	}
	return false;
}

// 获取IP地址和Mac
function queryIPMAC() {
	var ipmac = "";
	if (isIE()) {
		var locator = new ActiveXObject("WbemScripting.SWbemLocator");
		var service = locator.ConnectServer(".");
		// 获取当前在用MAC，排除虚拟网卡
		var properties = service
				.ExecQuery("SELECT MACAddress FROM Win32_NetworkAdapter WHERE ((MACAddress Is Not NULL) AND (Manufacturer <> 'Microsoft')) AND (NetConnectionStatus=2 OR NetConnectionStatus=9)");
		var e = new Enumerator(properties);
		var mac = "";

		for (; !e.atEnd(); e.moveNext()) {
			var p = e.item();
			mac = "" + p.MACAddress;
			break;
		}
		if (mac == null) {
			ipmac = "";
			ip = "";
		} else if (mac != "") {
			// 根据MAC获取相应IP，排除本机地址
			properties = service
					.ExecQuery("SELECT IPAddress,MACAddress FROM Win32_NetworkAdapterConfiguration");
			e = new Enumerator(properties);
			for (; !e.atEnd(); e.moveNext()) {
				var p = e.item();
				var ip = "" + p.IPAddress(0);
				var m = "" + p.MACAddress;
				if (ip != "" && ip != "0.0.0.0" && m == mac) {
					ipmac = ip;
					break;
				}
			}
			ipmac = mac.replace(/:/g, "-") + ";" + ipmac;
		}
		e = null;
		properties = null;
	}
	return ipmac;
}

$(".headerMenu .headerMenu0").click(function(e) {
	var space = 0;
	if ($(".recommend").css('display') != 'block') {
		$(".recommend").hide();
		$(".main_outer .wrap > div").animate({
			"margin-right" : $(".currentOrder").width() + 10
		}, 270);
	}
	$(".currentOrder").css({
		right : space - 240,
		'display' : 'block'
	}).animate({
		right : space + 8
	}, 500).show();
});

function closeSelf() {
	window.close();
}

$(".headerMenu").delegate(".header_menu_child", "click", clickOnTopTool);
function clickOnTopTool() {
	if ($(this).hasClass("headerMenu1")) {
		$('.print_block').css(
				{
					'right' : ($(window).width() - $(
							'.pgHeader').width()) / 2
				});
		$('.print_block').css({
			'display' : 'block'
		});
		$('.print_block').find('.print_close').click(
				function() {
					$('.print_block').css({
						'display' : 'none'
					});
					$(".headerMenu1").removeClass('active');
				});
	}

	if ($(this).hasClass("headerMenu2")) {
		var timestamp = new Date().getTime();
		loadPopup("pages/wb_identify.html?t=" + timestamp);
	}

	if ($(this).hasClass("headerMenu4")) {
		var timestamp = new Date().getTime();
		loadPopup("pages/wb_unioncash.html?t=" + timestamp);
//$("#unioncashSwitchDiv").show();
	}

	if ($(this).hasClass("headerMenu5")) {
		var scope = $(document).scope();
		var $Model = scope.$Model;
		scope.$UI.msgbox
				.confirm(
						$UEE.i18n("SM.LOGIN.MESSAGE.CONFIRM"),
						$UEE.i18n("SM.LOGIN.MESSAGE.SWITCH"),
						function() {
							var $Fire = scope.$Get("$Fire");
							$Fire(
									{
										"service" : "SMUserAction/getswitchesopinfo",
										"target" : "$Model.switchMap"
									}, scope)
									.onafter(
											function() {
												var interval = $Model.switchMap["INTERVAL"];
												var module = $Model.switchMap["MODULE"];
												var pubKey = $Model.switchMap["PUB_KEY"];
												var soapurl = $Model.switchMap["SOAP_URL"];
												var sessionId = $Model.switchMap["SESSION_ID"];
												if (interval == null
														|| module == null
														|| pubKey == null
														|| soapurl == null
														|| sessionId == null
														|| interval == ''
														|| module == ''
														|| pubKey == ''
														|| soapurl == ''
														|| sessionId == '') {
													scope.$UI.msgbox
															.error(
																	$UEE
																			.i18n("SM.COMMON.TITLE.ERROR"),
																	$UEE
																			.i18n("SM.LOGIN.MESSAGE.SWITCHERROR"));
													return false;
												}
												var ipmac = queryIPMAC();
												var ip = '';
												if ("" != ipmac) {
													ip = ipmac
															.split(";")[1];
												}
												var encKey = new RSAKeyPair(
														pubKey,
														'',
														module);
												var result = encryptedString(
														encKey,
														ip);
												var fullUrl = soapurl
														+ "?sessionid="
														+ sessionId
														+ "&besInfo="
														+ result;
												window
														.open(fullUrl)
												setTimeout(
														'closeSelf()',
														parseInt(interval) * 1000);
												// window.location.href
												// = fullUrl;
											});
						}, null);
	}	
}

function loadPopup(url) {
	$("#popBox").show();
	$(".windowBoxwrap").load(url);
};

function loadPopNote(url) {
	$(".windowBoxwrapPop").hide();
	$("#popNote").show();
	$("#popNoteBox").load(url);
};

$(".tab_nav li").click(function(e) {
	var innerid = this.getAttribute('innerid');
	showPrint(innerid);
});

function showPrint(innerid) {
	$('.tab_nav > ul > li').removeClass('active');
	$('.tab_nav > ul > li').filter('[innerid=' + innerid + ']').addClass(
			'active');

	$('.print_content > iframe').hide();

	var printMap = {
		"besprint" : "pages/bes_print.html",
		"icrmprint" : "pages/icrm_print.html",
		"crmprint" : "pages/crm_print.html"
	};

	var currentIframe = $('.print_content > iframe').filter(
			'[innerid=' + innerid + ']');
	var timestamp = new Date().getTime();
	currentIframe.attr('src', printMap[innerid] + '?t=' + timestamp);
	currentIframe.show();
};

function updateShoppingcartNumber(number) {
	if (number == '0') {
		$("#shoppingcartPlat").removeClass().addClass("cart_num hide");
	} else {
		$("#shoppingcartPlat").removeClass().addClass("cart_num");
	}

	$("#shoppingcartNumber").text(number);
};

function initEmergency($Scope)
{
	 debugger;
	$Model.emergencyStatus = {};
	$Model.emergency = {};
	$Model.emergency.isOpenBEEmergency = false;
	$Model.emergency.recList = [];
	$Model.emergency.sentNotes = [];
	$Model.emergency.toBeSendNotes = [];
	
	if (!$Model.emergency.sentNotes.indexOf)
	{
		$Model.emergency.sentNotes.indexOf = function(elt /* , from */)
		{
			var len = this.length >>> 0;
			var from = Number(arguments[1]) || 0;
			from = (from < 0)? Math.ceil(from): Math.floor(from);
			if (from < 0)
			{
				from += len;
			}
			for (; from < len; from++)
			{
				if (from in this && this[from] === elt)
				{
					return from;
				}
			}
			return -1;
		};
	}
	
	if (!$Model.portalParams.isEmergencySystem && $Model.portalParams.isOpenEmergency)
	{
		refreshEmergencyStatus();
		$Model.emergency.intervalCount = setInterval("refreshEmergencyStatus()", $Model.portalParams.esNoteRefreshFreq * 1000);
	}
};

function refreshEmergencyStatus()
{
	var $Scope = $(document).scope();
	var $Model = $Scope.$Model;
	var $fire = $Scope.$Get("$Fire");
	$fire({
		"service" : "/SMPortalAction/getSMEmergencyStatus",
		"target" : "$Model.emergencyStatus",
	}, $Scope).onafter(function() {
		if (!$Model.emergencyStatus.isOpenEmergency)
		{
			clearInterval($Model.emergency.intervalCount);
			return;
		}
		
		$Model.emergency.isOpenBEEmergency = $Model.emergencyStatus.isOpenBEEmergency;
		$Model.emergency.recList = $Model.emergencyStatus.recList;
		
		// 无公告信息
		if ($Model.emergencyStatus.noteList == undefined || $Model.emergencyStatus.noteList.length==0)
		{
			popupESNotes();
			return;
		}
		
		var note;
		for (var i=0; i<$Model.emergencyStatus.noteList.length; i++)
		{
			note = $Model.emergencyStatus.noteList[i];
			if($Model.emergency.sentNotes.indexOf(note.id) != -1)
			{
				continue;
			}
			
			$Model.emergency.sentNotes.push(note.id);
			$Model.emergency.toBeSendNotes.push(note);
		}
		
		popupESNotes();
	});
};

function popupESNotes()
{
	// 判断是否有未弹出的公告信息
	if ($Model.emergency.toBeSendNotes == undefined || $Model.emergency.toBeSendNotes.length == 0)
	{
		return;
	}

	// 弹框未关闭，则等待关闭后再弹出
	if ($("#bes_sm_emergency_wb_notes").is(":visible"))
	{
		return;
	}
	
	loadPopup("pages/wb_emergency.html");
};

/**
 * 判断打开的菜单是否应急菜单
 * 
 * @param menuId
 * @param visitRule
 * @returns {Boolean}
 */
function isOpenEmergencyMenu(visitRule)
{
	if (visitRule == undefined || visitRule == "null" || visitRule.length != 4)
	{
		return false;
	}
	
	return visitRule[3]=="1";
};

/**
 * 能否打开应急菜单
 * 
 * @param menuId
 */
function hasOpenEmergencyMenu(menuId)
{
	// 没有开启应急功能，即系统参数值为0，则直接返回false
	if (!$Model.portalParams.isOpenEmergency)
	{
		$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_NOT_OPEN_ES'));
		return false;
	}
	
	// 具有免应急状态验证权限，则可以直接打开
	if ($Model.portalParams.hasOpenESMenuAuth)
	{
		return true;
	}
	
	// 判断地市是否切应急
	if ($Model.emergency.isOpenBEEmergency)
	{
		$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_OPEN_BE_ES'));
		return false;
	}
	
	// 判断当前的菜单是否在应急列表中
	if (esMenuMap[menuId] == 1)
	{
		esMenuMap[menuId] = 0;
		return true;
	}
	
	// 判断应急菜单对应的正常菜单是否进入应急状态
	var recList = $Model.emergency.recList;
	if (recList == undefined)
	{
		$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_NOT_SWITCH_ES'));
		return false;
	}
	
	// 判断当前打开的菜单是否在切应急的菜单范围内
	for (var i=0; i<recList.length; i++)
	{
		if (recList[i].esMenuId == menuId)
		{
			return true;
		}
	}
	
	$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_NOT_SWITCH_ES'));
	return false;
};

/**
 * 能否打开正常菜单（非应急菜单）
 * 
 * @param menuId
 */
function hasOpenNormalMenu(menuId)
{
	// 没有开启应急功能，即系统参数值为0，则直接返回true
	if (!$Model.portalParams.isOpenEmergency)
	{
		return true;
	}
	
	// 具有免应急状态验证权限，则可以直接打开
	if ($Model.portalParams.hasOpenESMenuAuth)
	{
		return true;
	}
	
	// 判断地市是否切应急
	if ($Model.emergency.isOpenBEEmergency)
	{
		var $Scope = $(document).scope()
		var $fire = $Scope.$Get("$Fire");
		$fire({
			"service" : "/gadget/common/operator/queryESMenuInfo",
			"target" : "$Model.toBeOpenedMenu",
			params : {'menuId' : menuId}
		}, $Scope).onafter(function() {
			if ($Model.toBeOpenedMenu == undefined)
			{
				$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_BE_SWITCH_ES'));
				return;
			}
			
			if ($Model.toBeOpenedMenu.esMenuName == undefined || $Model.toBeOpenedMenu.esMenuName == "")
			{
				$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_BE_SWITCH_ES'));
				return;
			}
			
			$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_BE_SWITCH_ES_PREFIX') + '<font color="red">' + $Model.toBeOpenedMenu.esMenuName + '</font>' + $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_BE_SWITCH_ES_SUFFIX'));
		});
		
		return false;
	}
	
	// 获取切应急的菜单列表
	var recList = $Model.emergency.recList;
	if (recList == undefined)
	{
		return true;
	}
	
	// 判断当前打开的菜单是否在切应急的菜单范围内
	var esMenuNameMap;
	for (var i=0; i<recList.length; i++)
	{
		if (recList[i].menuId == menuId)
		{
			esMenuNameMap = recList[i].esMenuNameMap;
			try
			{
				if (esMenuNameMap == undefined || esMenuNameMap[$BES.$ContextAccessor.getLocale()] == undefined || esMenuNameMap[$BES.$ContextAccessor.getLocale()] == "" )
				{
					$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_SWITCH_ES'));
				}
				else
				{
					$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_SWITCH_ES_PREFIX') + '<font color="red">' + esMenuNameMap[$BES.$ContextAccessor.getLocale()] + '</font>' + $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_SWITCH_ES_SUFFIX'));
				}
			}
			catch(err)
			{
				$(document).scope().$UI.msgbox.error($UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED'), $UEE.i18n('SM.LOGIN.LABEL.OPEN_MENU_FAILED_SWITCH_ES'));
			}
				
			return false;
		}
	}
	
	return true;
};

/**
 * 将应急菜单编码加入应急列表
 * 
 * @param esMenuId
 */
function addAutoEsMenu(esMenuId) {
	esMenuMap[esMenuId] = 1;
};

function postHttpsRequest(msg)
{
	if (isIE()) {
		window.frames['bes_sm_portal_https_hidden_frame'].postMessage(msg, '*');
	} else {
		window.frames['bes_sm_portal_https_hidden_frame'].contentWindow.postMessage(msg, '*');
	}
};

/**
 * 特殊字符转义
 * 
 * @param text
 * @returns
 */
function escapeHtml(text) {
	text = '' + text;
	var map = {
	    '&': '&amp;',
	    '<': '&lt;',
	    '>': '&gt;',
	    '"': '&quot;',
	    "'": '&#039;',
	    '/': '/',
	    '(': '&#40;',
	    ')': '&#41;'

	  };

	  return text.replace(/[&<>"'()/]/g, function(m) { return map[m]; });
};

function loadCustJs(src) {
    var oHead = document.getElementsByTagName('HEAD').item(0); 
    var oScript= document.createElement("script"); 
    oScript.type = "text/javascript"; 
    oScript.src=src; 
    oHead.appendChild( oScript); 	
}

/**
 * 初始化操作员退出,清理第三方会话 
 * @remark add by y00146291 2016-9-30
 */
function initUnloadFramework()
{
	try
	{
		debugger;
		var $Scope = $(document).scope();
		var $Model = $Scope.$Model;
		var $fire = $Scope.$Get("$Fire");
		$fire({
			"service" : "/sm/DataDictAction/getDict",
			"param-dictcode" : "SYS.THIRD_SYSTEM_CLEARSESSION_URL",
			"target" : "$Model.thirdSysLogoutUrls",
		}, $Scope).onafter(function(){
			debugger;
			
		});
	}
	catch(e)
	{
		debugger;
		alert(e);
	}
}

initUnloadFramework();

/**
 * 操作员退出,清理第三方会话 
 * @remark add by y00146291 2016-9-30
 */
function unloadFramework()
{
	var thirdLogoutUrls = $Model.thirdSysLogoutUrls;
	for (var thirdSysContext in thirdLogoutUrls)
	{
		var url = thirdLogoutUrls[thirdSysContext];
		try
		{
			jQuery.ajax({
				type: "get",
				async: true,
				url: url,
				dataType: "json",
				cache: false,
				success: function (asd) {
					debugger;
				},
				error: function (err) {
					debugger;
				}
			});  
		}
		catch (err)
		{
			debugger;
		}
	}
}

/**
 * 页面销毁动作
 */
$(window).unload(function() {
	unloadFramework();
});

/**
 * AD需要，临时添加，用于使用新版app.js内容
 * 目前app.js里无这句话，需要在app.js升级之后，将下面句话删除
 */
$(function(){
	angular.element(document.body).scope().$root.$Theme = '/themes/default/skins/default';
	});