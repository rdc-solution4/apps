// 用于接收回调的数组
var beforeOpenTabFuncs = [];
var beforeOpenTabFuncIds = [];
var beforeCloseTabFuncs = [];
var beforeCloseTabFuncIds = [];

function checkIndexOf() {
	if (!Array.prototype.indexOf)
	{
	  Array.prototype.indexOf = function(elt /*, from*/)
	  {
	    var len = this.length >>> 0;
	    var from = Number(arguments[1]) || 0;
	    from = (from < 0)
	         ? Math.ceil(from)
	         : Math.floor(from);
	    if (from < 0)
	      from += len;
	    for (; from < len; from++)
	    {
	      if (from in this &&
	          this[from] === elt)
	        return from;
	    }
	    return -1;
	  };
	}
}

checkIndexOf();

function regOpenTabCallback(funcId, funcName) {
	if (beforeOpenTabFuncIds.indexOf(funcId) == -1) {
		beforeOpenTabFuncIds.push(funcId);
		beforeOpenTabFuncs.push(funcName);
	}
}

function deregOpenTabCallback(funcId) {
	var idx = beforeOpenTabFuncIds.indexOf(funcId);
	if (idx != -1) {
		beforeOpenTabFuncIds.splice(idx, 1);
		beforeOpenTabFuncs.splice(idx, 1);
	}
}

function regCloseTabCallback(funcId, funcName) {
	if (beforeCloseTabFuncIds.indexOf(funcId) == -1) {
		beforeCloseTabFuncIds.push(funcId);
		beforeCloseTabFuncs.push(funcName);
	}
}

function deregCloseTabCallback(funcId) {
	var idx = beforeCloseTabFuncIds.indexOf(funcId);
	if (idx != -1) {
		beforeCloseTabFuncIds.splice(idx, 1);
		beforeCloseTabFuncs.splice(idx, 1);
	}
}