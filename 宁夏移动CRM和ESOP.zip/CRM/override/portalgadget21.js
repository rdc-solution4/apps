var portalGadgetApi = new PortalGadget();

function PortalGadget() {
	this.initPortalGadget = function($Scope) {
		debugger;
		try {
			portalGadgetApi.queryLoadedModule($Scope);
		} catch (err) {
			
		}
	};
	
	this.queryLoadedModule =  function($Scope) {
		$Model = $Scope.$Model;	
		var $Fire = $Scope .$Get("$Fire");
		$Fire({
			"service" : "/gadget/common/operator/queryLoadedPortalModules",
			"target" : "$Model.loadedModule"
		}, $Scope).onafter(function(){
			if (!$Model.loadedModule) {
				return;
			}
			
			portalGadgetApi.loadLayout($Scope);
		});
	};
	
	this.loadLayout = function($Scope) {
		$Model = $Scope.$Model;	
		var $Fire = $Scope .$Get("$Fire");
		$Fire({
			"service" : "/sm/portalweb/layoutuibo/queryLayout",
			"params" : {"siteId" : '6010100001'},
			"target" : "$Model.employeeLayoutList"
		}, $Scope).onafter(function(){
			debugger;
			if (!$Model.employeeLayoutList) {
				return;
			}
			
			// 按照systemId过滤portal
			$Model.employeeLayoutList = portalGadgetApi.filterGadgetBySystemId($Model.loadedModule, $Model.employeeLayoutList);
			
			
			// 过滤出框架中左边的gadget和header上的gadget
			var frmLeftGadget = [];
			var frmHeaderGadget = [];
			
			portalGadgetApi.filterGadgetByPosition($Model.employeeLayoutList, frmLeftGadget, frmHeaderGadget);

			// 逐个添加左侧gadget
			for (var idx = frmLeftGadget.length - 1; idx >= 0; idx--) {
				var domNode = portalGadgetApi.genDomNode(frmLeftGadget[idx]);
				portalGadgetApi.regGadgetToLeft_first(domNode);
			}
			
			// 逐个添加头部gadget
			for (var idx = 0; idx < frmHeaderGadget.length; idx++) {
				var domNode = portalGadgetApi.genDomNode(frmHeaderGadget[idx]);
				portalGadgetApi.regGadgetToHeader(domNode);
			}
		});
	};

	
	this.filterGadgetBySystemId = function(loadedModule, allPortalGadget) {
		var loadedModuleStr = JSON.stringify(loadedModule);
		var result = [];
		for (var idx = 0; idx < $Model.employeeLayoutList.length; idx++) {
			var layout = $Model.employeeLayoutList[idx];
			var pe = layout.SMPortalElement;
			if (!pe) {
				continue;
			}
			var systemId = pe.systemId;
			
			// systemId支持逗号分隔，如60101,60102
			if (!systemId) {
				result.push(layout);
			} else {
				var systemIds = systemId.split(',');
				for (var ii = 0; ii < systemIds.length; ii++) {
					var tmpSystemId = systemIds[ii];
					if (loadedModuleStr.indexOf('"' + tmpSystemId + '"') != -1) {
						result.push(layout);
					}
				}
			}			
		}
		return result;		
	};
	
	this.filterGadgetByPosition = function(allPortalGadget, frmLeftGadget, frmHeaderGadget) {
		for (var idx = 0; idx < allPortalGadget.length; idx++) {
			var layout = allPortalGadget[idx];
			var pe = layout.SMPortalElement;
			if (!pe) {
				continue;
			}
			var elementType = pe.elementType;
			var subType = pe.elementSubType;
			if (!elementType || elementType == 'FRM') {
				if (!subType || subType == 'LEFT') {
					frmLeftGadget.push(layout);
				}
				if (!subType || subType == 'HEADER') {
					frmHeaderGadget.push(layout);
				}				
			}
		}		
	};
	
	this.genDomNode = function (layout) {
		var pe = layout.SMPortalElement;
		if (!pe) {
			return;
		}
		var domNodeStr = '<uee:gadget></uee:gadget>';
		domNodeStr = $(domNodeStr);
		domNodeStr.attr('name', pe.elementName);
		return domNodeStr;
	};
	

	this.reloadDom = function (domNode) {
		domNode = $(domNode)[0];
		$(document).scope().$Get('$compile')(domNode)($(document).scope());
	};

	this.regGadgetToTop = function (domNode) {
		var topGadget = $('#top_gadget');
		topGadget.append(domNode);	
		portalGadgetApi.reloadDom(domNode);
	};

	this.regGadgetToLeft_byPos = function (domNode, pos) {
		domNode = $(domNode)[0];	
		var leftMenu = $('#leftMenu');
		if (leftMenu.children().length == 0) {
			leftMenu.append(domNode);
			// 加载gadget
			portalGadgetApi.reloadDom(domNode);
			return;
		}
		for (var idx = 0; idx < leftMenu.children().length; idx++) {
			if (pos == idx) {
				var beforeNode = leftMenu.children()[idx];
				leftMenu = leftMenu[0];
				leftMenu.insertBefore(domNode, beforeNode);
				// 加载gadget
				portalGadgetApi.reloadDom(domNode);
				break;
			}
		}	
	};


	this.regGadgetToLeft_first = function (domNode) {
		portalGadgetApi.regGadgetToLeft_byPos(domNode, 0);
	}

	this.regGadgetToLeft_last = function (domNode) {
		var leftMenu = $('#leftMenu');
		leftMenu.append(domNode);
		portalGadgetApi.reloadDom(domNode);
	};

	this.regGadgetToHeader = function (domNode) {
		var headerMenu = $('#headerMenu');
		headerMenu.append(domNode);
		portalGadgetApi.reloadDom(domNode);	
	};
}