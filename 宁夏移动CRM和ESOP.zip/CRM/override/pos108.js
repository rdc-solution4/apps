/**
* pos机
* TODO 暂时支持银联POS，改造其他POS机时公用方法可抽象
*/
function POS()
{
    /**
     * 机器号
     */
    this.possn = "";
    
    /**
     * 员工号
     */
    this.posoper = "";
    
    /**
     * 支付方式
     */
    this.payType = "";
    
    /**
     * pos机名
     */
    this.posname = "";
    
    /**
     * 控件
     */
    this.ocx = "";
    
    /**
     * 交易类型
     */
    this.transTypeMap = {"pay" : "消费", "paycancel" : "撤销", "back" : "退货"};
    
    /**
     * 最大刷卡金额
     */
    this.MAX_AMOUNT = 9999999999.99;
    
    /**
     * 本次交易流水
     */
    this.currentOid = "";
    
    /**
     * 银行编码
     * @remark create by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请
     */
    this.bankid = "";
    
    /**
     * 银行帐号
     * @remark create by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请
     */
    this.bankacct = "";
    
    /**
     * 银行交易参考号
     * @remark create by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请
     */
    this.bankformnum = "";
    
    /**
     * 初始化
     * @param possn 机器号
     * @param posoper 员工号
     */
    this.init = function(possn, posoper)
    {
        this.possn = possn;
        this.posoper = posoper;
        this.posname = this.posname + "POS机【机器号：" + this.possn + " 员工号：" + this.posoper + "】";
        this.initOcx();
    };
    
    /**
     * 初始化控件
     */
    this.initOcx = function()
    {
        alert("请指定具体控件类型。");
    }
    
    /*
     * 验证是否为货币型
     * @param value 金额，单位元
     */
    this.validMoney = function(value)
    {
        var reg1 = /^\d{1}$/ ;
        var reg2 = /^\d[.]\d\d?$/;
        var reg3 = /^[1-9]\d*[.]?\d\d?$/;
        return reg1.test(value) || reg2.test(value) || reg3.test(value);
    };
    
    /**
     * 左补齐
     * @param srcStr 源字符串
     * @param bchar 补齐字符
     * @param length 补齐后长度
     */
    this.leftPad = function(srcStr, bchar, length)
    {     
        var xchar = "" + srcStr;
        for (var i = 0; i < length; i++)
        {  
            if (xchar.length >= length)
            {
                break;
            }
            xchar = bchar + xchar;
        }      
        return xchar; 
    };
    
    /**
     * 右补齐
     * @param srcStr 源字符串
     * @param bchar 补齐字符
     * @param length 补齐后长度
     */
    this.rightPad = function(srcStr, bchar, length)
    {     
        var xchar = srcStr + "";
        for (var i = 0; i < length; i++)
        {     
            if (xchar.length >= length)
            {
                break;
            }
            xchar = xchar + bchar;
        }      
        return xchar; 
    };
    
    /**
     * 去掉字符串两端空格
     * @remark create w00187892 2014-10-20 Bug 78412
     */
    this.trimStr = function(str)
    {
        if (str == undefined || str == null)
        {
            return "";
        }
        return str.replace(/(^\s*)|(\s*$)/g, "");
    };
    
    /**
     * 四舍五入
     */
    this.round = function(number, x)
    {
        return Math.round(number * Math.pow(10, x)) / Math.pow(10, x);
    };
    
    /**
     * 刷卡
     * @param amount 金额，单位元
     * @param region 地区
     * @param servNumber 服务号码
     * @param recType 当前业务
     */
    this.charge = function(amount, region, servNumber, recType)
    {	    
        return this.trans("pay", amount, region, servNumber, recType, "", "", "", "");
    };
    
    /**
    * 退款
    * @param amount 金额
    * @param region 地区
    * @param servNumber 服务号码
    * @param recType 业务类型
    * @param time 时间
    * @param refNo 参考号
    * @param formNo 凭证号
    * @param relaOid 关联交易流水 回退时用
    * @param isLastBack 是否最后一次退款 是：1，否：0
    * @remark modify xWX177656 2015-01-22 R005C10LG0101 OR_HEB_201409_63
    */
    this.back = function(amount, region, servNumber, recType, time, refNo, formNo, relaOid, isLastBack)
    {           
        // 根据系统时间决定交易类型，默认退货
	    var transType = "back";
        var sysTime = "";
		var url = obtainWebContextPath("ngcustcare")+"/custsvc/postrans/systime.action";
		var rtnInfo = "调用获取系统时间服务异常。";
		try
		{
		    rtnInfo = execService(url, "");
		    var infos = rtnInfo.split("|");
		    if (infos.length != 2)
		    {
		        alter(rtnInfo)
		        return false;
		    }
		    if ("00" == infos[0])
		    {
		        sysTime = infos[1];
		    }
		    else
		    {
		        alert(infos[1]);
		        return false;
		    }
		}
		catch (e)
		{
		    alert(rtnInfo + e.message);
		    return false;
		}
		// 当日为撤销
		if (sysTime.substring(0, 8) == time.substring(0, 8))
		{
		    transType= "paycancel";
		}
		
		//add begin xWX177656 2015-01-22 R005C10LG0101 OR_HEB_201409_63
		//退货，不再按照时间计算交易类型
		if ("WidthdrawGoods" === recType)
		{
			transType = "back";
		}
		//add end xWX177656 2015-01-22 R005C10LG0101 OR_HEB_201409_63
		
        return this.trans(transType, amount, region, servNumber, recType, time, refNo, formNo, relaOid, isLastBack);
    };
    
    /**
    * 交易
    * @param transType 交易类型
    * @param isLastBack 是否最后一次退款
    * @remark modify xWX177656 2015-03-18 R005C10LG0101 OR_HEB_201409_63
    */
    this.trans = function(transType, amount, region, servNumber, recType, time, refNo, formNo, relaOid, isLastBack)
    {
        // 控件是否可用
        if (this.ocx == null || this.ocx == undefined || this.ocx == "")
        {
            alert("使用" + this.posname + "扣款时异常。\n未正确加载POS机控件。");
            return false;
        }
        
        // 校验金额并转为分
        if (!this.validMoney(amount))
        {
            alert("使用" + this.posname + "扣款时异常。\n错误的金额：" + amount);
            return false;
        }
        if (parseFloat(amount) > this.MAX_AMOUNT)
        {
            alert("使用" + this.posname + "扣款时异常。\n过大的金额：" + amount + "元。");
            return false;
        }
        amount = this.formatAmount(amount);
        
        // 构造交易报文
	    this.buildRequest(this.possn, this.posoper, this.transTypeMap[transType], amount, time, refNo, formNo, "YOU");
	    // 交易
	    var taskOid = this.transaction(transType, region, servNumber, recType, amount, relaOid);
	    // 解析交易应答
	    if (taskOid == undefined || taskOid == null || taskOid == "")
	    {
	        return false;
	    }
	    this.currentOid = taskOid;
		return this.parseResponse(region, taskOid, relaOid, isLastBack);
    };
    
    /**
     * 格式化金额
     * 即元转分
     * @param amount 金额
     */
    this.formatAmount = function(amount)
    {
        if (amount.indexOf(".") < 0)
        {
            amount += "00";
        }
        else
        {
            amountStrs = amount.split(".");
            amount = amountStrs[0] + this.rightPad(amountStrs[1], "0", 2);
        }
        return amount;
    };
    
    
    /**
     * 应答成功
     * @param isLastBack 是否最后一次退款
     * @remark modify xWX177656 2015-03-18 R005C10LG0101 OR_HEB_201409_63
     */
    this.responseSuccess = function(region, taskOid, retCode, bankCode, cardNo, formNo, amount, 
        message, shopNo, termNo, batchId, transDate, transTime, refNo, rightNo, clearDate, lrc, relaOid,
        request, response, isLastBack)
    {
        var url = obtainWebContextPath("ngcustcare")+"/custsvc/postrans/transSuccess.action";
        var rollStatus = "success";
        if (isLastBack == '0')
        {
        	rollStatus = "rebates";
        }
        
		var params = "region=" + region + "&oid=" + taskOid + "&bankstatus=1" 
		    + "&retCode=" + retCode + "&bankCode=" + bankCode + "&cardNo=" + cardNo 
		    + "&formNo=" + formNo + "&amount=" + amount + "&message=" + message 
		    + "&shopNo=" + shopNo + "&termNo=" + termNo + "&batchId=" + batchId
		    + "&transDate=" + transDate + "&transTime=" + transTime + "&refNo=" + refNo 
		    + "&rightNo=" + rightNo + "&clearDate=" + clearDate + "&lrc=" + lrc 
		    + "&requestinfo=" + request + "&responseinfo=" + response 
		    + "&relatetaskoid=" + relaOid + "&rollstatus=" + (relaOid == "" ? "" : rollStatus);	
		var rtnInfo = "调用应答成功服务异常。";
		try
		{
		    rtnInfo = execService(url, params);
		    if (rtnInfo != "")
		    {
		        alert(rtnInfo);
		    }
		}
		catch (e)
		{
		    alert(rtnInfo + e.message);
		}
    };
    
    /**
     * 应答失败
     */
    this.responseFail = function(region, taskOid, relaOid, request, response)
    {
        var url = obtainWebContextPath("ngcustcare")+"/custsvc/postrans/transFail.action";
		var params = "region=" + region + "&oid=" + taskOid + "&bankstatus=9"  
		    + "&requestinfo=" + request + "&responseinfo=" + response 
		    + "&relatetaskoid=" + relaOid + "&rollstatus=" + (relaOid == "" ? "" : "fail");	
		var rtnInfo = "调用应答失败服务异常。";
		try
		{
		    rtnInfo = execService(url, params);
		    if (rtnInfo != "")
		    {
		        alert(rtnInfo);
		    }
		}
		catch (e)
		{
		    alert(rtnInfo + e.message);
		}
    };
}

/**
* 农行pos机
*/
function ABCPOS()
{
    this.possn = "农行pos机";
    this.posoper = "农行员工";
    this.payType = "ABCPayHEB";
    this.posname = "农行支付";
    this.ocx = "JunAct";
    this.transTypeMap = {"pay" : "0", "paycancel" : "5", "back" : "4"};
    this.MAX_AMOUNT = 9999999999.99;
    this.currentOid = "";
    
    // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 begin
    this.bankid = "农行";
    this.bankacct = "";
    this.bankformnum = "";  
    // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 end
    
    /**
     * 初始化控件
     */
    this.initOcx = function()
    {
        var fso = new ActiveXObject('Scripting.FileSystemObject');
	    if (fso && !fso.FileExists("C:\\MISPOS_CONF\\ABC\\EPosForABC.ocx"))
	    {
	        this.ocx = null;
	        alert("请先下载安装农行商务POS刷卡控件。");
	        return;
	    }
        var _tempPlayer = document.getElementById("JunAct");
        if (!_tempPlayer)
        {
	        _tempPlayer = document.createElement("object");
	        _tempPlayer.classid = "CLSID:BAB91EC4-6964-452C-8500-8BA8F1050903";
	        _tempPlayer.id = "JunAct";
	        _tempPlayer.using = false;
        }
        this.ocx = _tempPlayer;
    }
    this.requestMsg = null;
    /**
     * 构造交易报文
     * @param possn 款台号
     * @param posoper 操作员
     * @param operation 交易类型
     * @param amount 交易金额
     * @param lastdate
     * @param lastrefno 上次交易凭证
     * @param lastformno
     * @param lrc
     */
    this.buildRequest = function(possn, posoper, operation, amount, lastdate, lastrefno, lastformno, lrc)
    {
        this.ocx.amount = "" + this.round(amount/100, 2);
        this.ocx.cashierno = posoper;
        this.ocx.counterno = possn;
        this.ocx.billno = "";
        this.ocx.referenceno = lastrefno;
        this.ocx.transtype = operation;
        this.requestMsg = "request: [amout: " + this.ocx.amount;
        this.requestMsg += ", cashierno: " + this.ocx.cashierno;
        this.requestMsg += ", counterno: " + this.ocx.counterno;
        this.requestMsg += ", billno: " + this.ocx.billno;
        this.requestMsg += ", referenceno: " + this.ocx.referenceno;
        this.requestMsg += ", transtype: " + this.ocx.transtype;
        this.requestMsg += "]. ";
    };
    
    this.result = null;
    this.errorMsg = null;
    /**
     * 交易
     */
    this.transaction = function(transType, region, servNumber, recType, amount, relaOid)
    {
        // 插入交易记录
        var taskOid = "";
		var url = obtainWebContextPath("ngcustcare")+"/custsvc/postrans/trans.action";
		var params = "region=" + region + "&servNumber=" + servNumber + "&recType=" + recType + "&amount=" + amount 
		    + "&payType=" + this.payType + "&transType=" + transType;	
		var rtnInfo = "调用发起交易服务异常。";
		try
		{
		    rtnInfo = execService(url, params);
		    var infos = rtnInfo.split("|");
		    if (infos.length != 2)
		    {
		        alert(rtnInfo);
		        return taskOid;
		    }
		    if ("00" == infos[0])
		    {
		        taskOid = infos[1];
		    }
		    else
		    {
		        alert(infos[1]);
		        return taskOid;
		    }
		}
		catch (e)
		{
		    alert(rtnInfo + e.message);
		    return taskOid;
		}
		
		// 调用控件交易 
		try
		{
		    this.result = this.ocx.commit();
		    this.errorMsg = this.ocx.commiterror;
		    if (this.errorMsg != null && this.errorMsg != undefined && this.errorMsg != "")
		    {
		        alert("调用农行交易控件失败：" + this.errorMsg);
		        this.responseFail(region, taskOid, relaOid, this.requestMsg, this.errorMsg + "|" + this.result);
		        return "";
		    }
		}
		catch (e)
		{
		    alert("交易异常：" + e.message);
		    this.responseFail(region, taskOid, relaOid, this.requestMsg, this.errorMsg + "|" + this.result);
		    return "";
		}
		
		// 返回交易流水
        return taskOid;
    };
    
    /**
     * 解析应答
     * @param isLastBack 是否最后一次退款
     * @remark modify xWX177656 2015-03-18 R005C10LG0101 OR_HEB_201409_63
     */
    this.parseResponse = function(region, taskOid, relaOid, isLastBack)
    {
        var response = this.result;
        if (response == undefined || response == null || response == "")
        {
            alert("交易应答为空。");
            this.responseFail(region, taskOid, relaOid, this.requestMsg, this.errorMsg + "|" + this.result);
            return false;
        }
        var results = response.split("|");
        if (results.length < 14)
        {
            alert("交易应答内容不足，不能解析：" + response);
            this.responseFail(region, taskOid, relaOid, this.requestMsg, this.errorMsg + "|" + this.result);
            return false;
        }
        
        var retCode = results[0];
        if ("00" != retCode)
        {
            alert("交易不成功：" + response);
            this.responseFail(region, taskOid, relaOid, this.requestMsg, this.errorMsg + "|" + this.result);
            return false;
        }
        var bankCode = results[13];
        var bankCodeMax = bankCode.length > 16 ? 16 : bankCode.length;
        bankCode = bankCode.substring(0, bankCodeMax);
        var cardNo = results[2];
        var formNo = "";
        var amount = results[3];
        var message = results[8];
        var shopNo = results[9];
        var termNo = results[10];
        var batchId = results[12];
        var transDate = results[6].substring(4);
        var transTime = results[7];
        var refNo = results[4];
        var rightNo = results[1];
        var clearDate = results[5];
        var lrc = "";
        
        // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 begin
        this.bankid = bankCode;
        this.bankacct = cardNo;
        this.bankformnum = refNo;
        // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 end
        
        this.responseSuccess(region, taskOid, retCode, bankCode, cardNo, formNo, amount, 
            message, shopNo, termNo, batchId, transDate, transTime, refNo, rightNo, clearDate, lrc, relaOid,
            this.requestMsg, this.errorMsg + "|" +  this.result, isLastBack);
        return true;
    };
}
ABCPOS.prototype = new POS();

/**
* 银联pos机
*/
function UnionPayPOS()
{
    this.possn = "银联pos机";
    this.posoper = "银联员工";
    this.payType = "UnionPayHEB";
    this.posname = "银联支付";
    this.ocx = "DUmsocx1";
    this.transTypeMap = {"pay" : "00", "paycancel" : "01", "back" : "02"};
    this.MAX_AMOUNT = 9999999999.99;
    this.currentOid = "";
    
    // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 begin
    this.bankid = "银联";
    this.bankacct = "";
    this.bankformnum = ""; 
    // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 end
    
    /**
     * 初始化控件
     */
    this.initOcx = function()
    {
        var fso = new ActiveXObject('Scripting.FileSystemObject');
	    if (fso && !fso.FileExists("C:\\GMC\\umsocx.ocx"))
	    {
	        this.ocx = null;
	        alert("请先下载安装银联商务POS刷卡控件。");
	        return;
	    }
        var _tempPlayer = document.getElementById("DUmsocx1");
        if (!_tempPlayer)
        {
	        _tempPlayer = document.createElement("object");
	        _tempPlayer.setAttribute("classid", "clsid:E083E848-B477-4F16-BCD5-72D74BC1E2AF");
	        _tempPlayer.setAttribute("id", "DUmsocx1");
	        _tempPlayer.setAttribute("using",false);
        }
        this.ocx = _tempPlayer;
    }
    
    /**
     * 构造交易报文
     * 参数校验只做简单格式，具体校验和含义由控件本身确定
     * @param possn 机器号
     * @param posoper 员工号
     * @param operation 交易类型
     * @param lastdate 上次交易日期 退货使用
     * @param lastrefno 上次交易参考号 退货使用
     * @param lastformno 上次交易凭证号 撤销使用
     * @param lrc 三位随机数字 此处用YOU写死
     */
    this.buildRequest = function(possn, posoper, operation, amount, lastdate, lastrefno, lastformno, lrc)
    {
        // viking 此处是为了在旧POS机上做连接测试的，切勿放开
        /*lastdate = this.rightPad(lastdate, "0", 8);
        lastrefno = this.rightPad(lastrefno, "0", 12);
        lastformno = this.rightPad(lastformno, "0", 6);*/
        
        // 校验上次交易日期
        if (lastdate == null || lastdate == "")
        {
            lastdate = "        ";
        }
        else if (lastdate.length >= 8)
        {
            lastdate = lastdate.substring(0, 8);
        }
        else
        {
            alert("incrrect last date: " + lastdate);
            this.ocx.bankrequest = "";
            return;
        }
        
        // 校验上次交易参考号
        if (lastrefno == null || lastrefno == "")
        {
            lastrefno = "            ";
        }
        else if (lastrefno.length < 12)
        {
            lastrefno = this.leftPad(lastrefno, "0", 12);
        }
        else if (lastrefno.length > 12)
        {
            alert("incrrect last ref no: " + lastrefno);
            this.ocx.bankrequest = "";
            return;
        }
        
        // 校验上次交易凭证
        if (lastformno == null || lastformno == "")
        {
            lastformno = "      ";
        }
        else if (lastformno.length < 6)
        {
            lastformno = this.leftPad(lastformno, "0", 6);
        }
        else if (lastformno.length > 6)
        {
            alert("incrrect last form no: " + lastformno);
            this.ocx.bankrequest = "";
            return;
        }
        
        // 拼接
        this.ocx.bankrequest = this.rightPad(possn, " ", 8) + this.rightPad(posoper, " ", 8) + operation + this.leftPad(amount, "0", 12)
            + lastdate + lastrefno + lastformno + lrc;
    };
    
    /**
     * 发起交易
     */
    this.transaction = function(transType, region, servNumber, recType, amount, relaOid)
    {
        if (this.ocx.bankrequest == "")
        {
            return "";
        }
        // 插入交易记录
        var taskOid = "";
		var url = obtainWebContextPath("ngcustcare")+"/custsvc/postrans/trans.action";
		var params = "region=" + region + "&servNumber=" + servNumber + "&recType=" + recType + "&amount=" + amount 
		    + "&payType=" + this.payType + "&transType=" + transType;	
		var rtnInfo = "调用发起交易服务异常。";
		try
		{
		    rtnInfo = execService(url, params);
		    var infos = rtnInfo.split("|");
		    if (infos.length != 2)
		    {
		        alert(rtnInfo);
		        return taskOid;
		    }
		    if ("00" == infos[0])
		    {
		        taskOid = infos[1];
		    }
		    else
		    {
		        alert(infos[1]);
		        return taskOid;
		    }
		}
		catch (e)
		{
		    alert(rtnInfo + e.message);
		    return taskOid;
		}
		
		// 调用控件交易
		try
		{
		    this.ocx.trans();
		}
		catch (e)
		{
		    alert("交易异常：" + e.message);
		    this.responseFail(region, taskOid, relaOid, this.ocx.bankrequest, this.ocx.BankResponse);
		    return "";
		}
		
		// 返回交易流水
        return taskOid;
    };
    
    /**
     * 解析应答
     * @param region 地区
     * @param taskOid 任务
     * @param relaOid 回退任务
     */
    this.parseResponse = function(region, taskOid, relaOid)
    {
        var response = this.ocx.BankResponse;
        if (response == undefined || response == null || response == "")
        {
            alert("交易应答为空。");
            this.responseFail(region, taskOid, relaOid, this.ocx.bankrequest, this.ocx.BankResponse);
            return false;
        }
        
        // viking 此处是为了在旧POS机上做连接测试的，切勿放开
        // response = this.rightPad(response, "0", 148);
        
        /////////////////////////////////////////////////按字节截取报文
        //计算字节长度
		String.prototype.strLen = function() {
		    var len = 0;
		    for (var i = 0; i < this.length; i++) {
		        if (this.charCodeAt(i) > 255 || this.charCodeAt(i) < 0) len += 2; else len ++;
		    }
		    return len;
		}
		//将字符串拆成字符，并存到数组中
		String.prototype.strToChars = function(){
		    var chars = new Array();
		    for (var i = 0; i < this.length; i++){
		        chars[i] = [this.substr(i, 1), this.isCHS(i)];
		    }
		    String.prototype.charsArray = chars;
		    return chars;
		}
		//判断某个字符是否是汉字
		String.prototype.isCHS = function(i){
		    if (this.charCodeAt(i) > 255 || this.charCodeAt(i) < 0) 
		        return true;
		    else
		        return false;
		}
		//截取字符串（从start字节到end字节）
		String.prototype.subCHString = function(start, end){
		    var len = 0;
		    var str = "";
		    this.strToChars();
		    for (var i = 0; i < this.length; i++) {
		        if(this.charsArray[i][1])
		            len += 2;
		        else
		            len++;
		        if (end < len)
		            return str;
		        else if (start < len)
		            str += this.charsArray[i][0];
		    }
		    return str;
		}
		////////////////////////////////////////////////////////////////
		
		if (response.strLen() < 2)
		{
		    alert("交易应答长度不正确：没有返回码。");
		    this.responseFail(region, taskOid, relaOid, this.ocx.bankrequest, this.ocx.BankResponse);
            return false;
		}
		
        var p = 0;
        var retCode = response.subCHString(p, p + 2);p += 2;
        if ("00" != retCode)
        {
            alert("交易不成功：" + response);
            this.responseFail(region, taskOid, relaOid, this.ocx.bankrequest, this.ocx.BankResponse);
            return false;
        }
        
        if (response.strLen() != 148)
        {
            alert("交易应答长度不正确：" + response);
            this.responseFail(region, taskOid, relaOid, this.ocx.bankrequest, this.ocx.BankResponse);
            return false;
        }
        
        var bankCode = this.trimStr(response.subCHString(p, p + 4));p += 4;
        var cardNo = this.trimStr(response.subCHString(p, p + 20));p += 20;
        var formNo = this.trimStr(response.subCHString(p, p + 6));p += 6;
        var amount = this.trimStr(response.subCHString(p, p + 12));p += 12;
        var message = this.trimStr(response.subCHString(p, p + 40));p += 40;
        var shopNo = this.trimStr(response.subCHString(p, p + 15));p += 15;
        var termNo = this.trimStr(response.subCHString(p, p + 8));p += 8;
        var batchId = this.trimStr(response.subCHString(p, p + 6));p += 6;
        var transDate = this.trimStr(response.subCHString(p, p + 4));p += 4;
        var transTime = this.trimStr(response.subCHString(p, p + 6));p += 6;
        var refNo = this.trimStr(response.subCHString(p, p + 12));p += 12;
        var rightNo = this.trimStr(response.subCHString(p, p + 6));p += 6;
        var clearDate = this.trimStr(response.subCHString(p, p + 4));p += 4;
        var lrc = this.trimStr(response.subCHString(p, p + 3));p += 3;
        
        // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 begin
        this.bankid = bankCode;
        this.bankacct = cardNo;
        this.bankformnum = refNo;
        // add by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请 end
        
        this.responseSuccess(region, taskOid, retCode, bankCode, cardNo, formNo, amount, 
            message, shopNo, termNo, batchId, transDate, transTime, refNo, rightNo, clearDate, lrc, relaOid,
            this.ocx.bankrequest, this.ocx.BankResponse);
        return true;
    };
}
UnionPayPOS.prototype = new POS();

/**初始化的pos机实例*/
var INIT_POSES = {"ABCPayHEB" : "ABCPOS", "UnionPayHEB" : "UnionPayPOS"};

/**
* 实例化pos机
* @param payType 付费方式
*/
function getPosObj(payType)
{
	if (!(payType in INIT_POSES))
	{
		return null;
	}
	var posVar = eval("new " + INIT_POSES[payType] + "()");
	return posVar;
}

/**
 * 付费方式是否使用pos机
 */
function posUsable(payType)
{
    var posVar = getPosObj(payType);
    if (posVar == undefined || posVar == null)
    {
        return false;
    }
    return true;
}

/**
* pos机刷卡
* @param payType 付费方式
* @param amount 金额，单位元
* @param region 地区
* @param servNumber 服务号码
* @param recType 当前业务类型
*/
function posCharge(payType, amount, region, servNumber, recType)
{
	var posVar = getPosObj(payType);
    if (posVar == undefined || posVar == null)
    {
        return false;
    }
    if (!initPosObj(posVar))
    {
        return false;
    }
	// 扣款
	if (posVar.charge(amount, region, servNumber, recType))
	{
	    saveTransToPage(posVar, servNumber, amount, payType);
	    return true;
	}
	return false;
}

/**
* pos机退款
* @param payType 付费方式
* @param amount 金额，单位元
* @param region 地区
* @param servNumber 服务号码
* @param recType 当前业务类型
* @param time 上次交易时间
* @param refNo 参考号
* @param formNo 凭证号
* @param relaOid 关联交易流水
* @param isLastBack 是否最后一次回退 是：1，否：0
* @remark modify xWX177656 2015-03-18 R005C10LG0101 OR_HEB_201409_63
*/
function posBack(payType, amount, region, servNumber, recType, time, refNo, formNo, relaOid, isLastBack)
{
    var posVar = getPosObj(payType);
    if (posVar == undefined || posVar == null)
    {
        return false;
    }
    if (!initPosObj(posVar))
    {
        return false;
    }
	// 回退
	if (posVar.back(amount, region, servNumber, recType, time, refNo, formNo, relaOid, isLastBack))
	{
	    saveTransToPage(posVar, servNumber, amount, payType);
	    return true;
	}
	
    // viking 此处是为了在旧POS机上做连接测试的，切勿放开
	// saveTransToPage(posVar, servNumber, amount, payType)
	// return true;
	
	return false;
}

/**
 * 初始化pos机
 */
function initPosObj(posVar)
{
	// 根据paytype找到pos机实例
	var url = obtainWebContextPath("ngcustcare")+"/custsvc/posinfomgr/client/instance.action";
	var params = "paytype=" + posVar.payType;	
	var rtnInfo = "调用实例化pos机服务异常。";
	var posChart = null;
	try
	{
	    rtnInfo = execService(url, params);
	    var infos = rtnInfo.split("|");
	    if (infos.length != 2)
	    {
	        alert(rtnInfo);
	        return false;
	    }
	    if ("00" == infos[0])
	    {
	        posChart = eval("( " + infos[1] + ")");
	    }
	    else
	    {
	        alert(infos[1]);
	        return false;
	    }
	}
	catch (e)
	{
	    alert(rtnInfo + e.message);
	    return false;
	}
	// 初始化实例
	posVar.init(posChart.possn, posChart.posoper);
	return true;
}

/**
 * 将交易信息保存到页面
 * @param posVar pos机
 * @param servNumber 号码
 * @param amount 金额
 * @param payType 支付方式
 * @remark by f00186409 2014-10-14 OR_huawei_201410_401  [省公司]关于优化CRM日志表、结账单有线POS相关内容的申请
 */
function saveTransToPage(posVar, servNumber, amount, payType)
{
	var hebPosDiv = document.getElementById("hebPosDiv");
	if(!hebPosDiv)
	{
		hebPosDiv = document.createElement("div");
		document.body.appendChild(hebPosDiv);
		hebPosDiv.id = "hebPosDiv";
	}
	// 缓存号码
    var element;
    var servNumElementId = "POSSERVNUMBER";
	element = document.getElementById(servNumElementId);
	if (!element)
	{
		var tempElement = document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = servNumElementId;
		tempElement.name = servNumElementId;
		element = tempElement;
		hebPosDiv.appendChild(element);
	}
	element.value = servNumber;
	// 缓存oid
    var taskElementId = "POSTASK." + servNumber + "." + payType;
	element = document.getElementById(taskElementId);
	if (!element)
	{
		var tempElement = document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = taskElementId;
		tempElement.name = taskElementId;
		element = tempElement;
		hebPosDiv.appendChild(element);
	}
	element.value = posVar.currentOid;
	// 缓存金额
    var amountEelementId = "POSAMOUNT." + servNumber + "." + payType;
	element = document.getElementById(amountEelementId);
	if (!element)
	{
		var tempElement = document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = amountEelementId;
		tempElement.name = amountEelementId;
		element = tempElement;
		hebPosDiv.appendChild(element);
	}
	element.value = posVar.formatAmount(amount);
	// 缓存银行编码
    var bankidEelementId = "POSBANKID." + servNumber + "." + payType;
	element = document.getElementById(bankidEelementId);
	if (!element)
	{
		var tempElement = document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = bankidEelementId;
		tempElement.name = bankidEelementId;
		element = tempElement;
		hebPosDiv.appendChild(element);
	}
	element.value = posVar.bankid;
	// 缓存银行帐号
    var bankacctEelementId = "POSBANKACCT." + servNumber + "." + payType;
	element = document.getElementById(bankacctEelementId);
	if (!element)
	{
		var tempElement = document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = bankacctEelementId;
		tempElement.name = bankacctEelementId;
		element = tempElement;
		hebPosDiv.appendChild(element);
	}
	element.value = posVar.bankacct;
	// 缓存参考号
    var formnumEelementId = "POSBANKFORMNUM." + servNumber + "." + payType;
	element = document.getElementById(formnumEelementId);
	if (!element)
	{
		var tempElement = document.createElement("input");
		tempElement.type = "hidden";
		tempElement.id = formnumEelementId;
		tempElement.name = formnumEelementId;
		element = tempElement;
		hebPosDiv.appendChild(element);
	}
	element.value = posVar.bankformnum;
}

/**
 * 是否已用pos机刷卡
 */
function hasCharged(payType, servNumber, amount)
{
	var taskId = "POSTASK." + servNumber + "." + payType;
	var amountId = "POSAMOUNT." + servNumber + "." + payType;
    var taskObj = document.getElementById(taskId);
    var amountObj = document.getElementById(amountId);
	if (taskObj && taskObj.value != "")
	{
		var posVar = getPosObj(payType);
	    if (posVar != undefined && posVar != null)
	    {
	        if (amountObj && posVar.formatAmount(amount) == amountObj.value)
			{
			    return true;
			}
	        alert(posVar.posname + "已付" + amount + "元，请注意手工退款。");
	    }		
	}
	return false;
}

/**
 * 业务回退
 * @param formnum 流水号
 * @param region 地区
 * @param amount 金额
 * @transactions 交易
 * @remark modify xWX177656 2015-01-22 R005C10LG0101 OR_HEB_201409_63 增加入参recType
 */
function dorecback(formnum, region, amount, transactions, recType)
{
    // 获取交易
    if (transactions == undefined || transactions == null || transactions == "")
    {
        transactions = getTransactions(formnum, region);
    }
	if (transactions && transactions.length <= 0)
	{
	    return true;
	}
	
	// 限制退款金额
	var limitAmount = false;
	var fTotalAmt = 0.00;
	if (amount && amount != null && amount != "")
	{
	     limitAmount = true;
	     fTotalAmt = parseFloat(amount);
	}
	
	// 逐个回退
	for (var i = 0; i < transactions.length; i ++)
	{
	    if (limitAmount && fTotalAmt <= 0)
	    {
	        return true;
	    }
	    var transaction = transactions[i];
	    var fCurAmt = parseFloat(transaction.EXCHANGEAMT);
	    if (limitAmount)
	    {
		    if (fCurAmt >= fTotalAmt)
		    {
		        fCurAmt = fTotalAmt;
		    }
		    fTotalAmt = fTotalAmt - fCurAmt;
	    }
	    if (!posBack(transaction.PAYTYPE, "" + fCurAmt, transaction.REGION, transaction.SERVNUMBER, recType, 
                  transaction.TRANSTIME, transaction.REFERENCENUMBER, transaction.BANKOPERATINGOID, transaction.TASKOID))
        {
            return false;
        }
	}
	
	// 全部回退成功视为成功
	return true;
    
}

/**
 * 获取交易
 * @param formnum 业务流水
 * @param region 地区
 */
function getTransactions(formnum, region)
{
    var transactions = {};
	// 根据formnum找到POS任务
	var url = obtainWebContextPath("ngcustcare")+"/custsvc/postrans/backtask.action";
	var params = "query.formnum=" + formnum + "&query.region=" + region;	
	var rtnInfo = "调用查询POS任务服务异常。";
	try
	{
	    rtnInfo = execService(url, params);
	    var infos = rtnInfo.split("|");
	    if (infos.length != 2)
	    {
	        alert(rtnInfo);
	        return transactions;
	    }
	    if ("00" == infos[0])
	    {
	        transactions = eval("(" + infos[1] + ")");
	    }
	    else
	    {
	        alert(infos[1]);
	        return transactions;
	    }
	}
	catch (e)
	{
	    alert(rtnInfo + e.message);
	    return transactions;
	}
	return transactions;
}