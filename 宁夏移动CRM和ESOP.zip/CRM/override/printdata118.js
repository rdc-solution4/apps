$Controller("bes.oc.printdata",{
	init: function($Page, $Gadget) {
		debugger;
		var printCell = document.getElementById('CellWeb');
		printCell.Login("华为技术有限公司","","13100104539","6140-1517-0123-3005");
		
		if (!$Gadget.data.besOcPrintData) {
			$Gadget.$Get('$UI').msgbox.info("提示", "没有打印数据。");
			return false;
		}
		
		this.pagePrint($Page, $Gadget, printCell);
	},
	
	pagePrintReview: function($Page, $Gadget, printCell){
		debugger;
		$Controller.bes.oc.printdata.setDefaultData($Page, $Gadget, printCell);
		printCell.PrintPreview(0,0);
	},
		
	setDefaultData: function($Page, $Gadget, printCell) {
		debugger;
		var printDataArr = $Gadget.data.besOcPrintData;
		
		var cellFileName = printDataArr[0].cellFileName;
		
		printCell.openfile("c:\\" + cellFileName,'');
	
		for (var i = 0; i < printDataArr.length; i++) {
			// 设置每一页总体
			// 1.调整坐标X 调整坐标Y TODO
			//printCell.PrintRange(parseInt(printDataArr[i].adjusty), parseInt(printDataArr[i].adjustx), 0, 0);			
			// 2.模板项排列方式 itemArrange TODO （数据库里为空）			
			// 3.每行最大字数 lineWidth TODO （数据库里为空）			
			// 4.可变区域最大行数  maxChangeareaRow TODO			
			// 5.页面高度paperHeight 6.页面宽度 paperWidth
/*			var paperWidth = printDataArr[i].paperWidth;
			var paperHeight = printDataArr[i].paperHeight;
			printCell.PrintSetCustomPaper (parseInt(paperWidth) ,parseInt(paperHeight) , i);*/
			
			var printCellInfoArr = printDataArr[i].printCellInfoList;
			
			for (var j = 0; j < printCellInfoArr.length; j++) {
				
				// 是否打印标识
				var isprint = printCellInfoArr[j].isPrint;				
				/*if (isprint == "1") {
					// 设置每个单元格打印信息
					var cellarr = printCellInfoArr[j];
					this.setCellInfo(cellarr, i, printCell);
				}*/
                // 设置每个单元格打印信息
				var cellarr = printCellInfoArr[j];
				this.setCellInfo(cellarr, i, printCell);				
			}					
		}
	},
	
	setCellInfo: function (printCellInfo, sheet, printCell) {
		debugger;
		if (!printCellInfo.protocolContent) {
			return;
		}
		var posx = printCellInfo.posx;
		var posy = printCellInfo.posy;
		
		// 10.String protocolContent;	
		printCell.SetCellString(parseInt(posy), parseInt(posx), sheet, printCellInfo.protocolContent);		
		
		// 1.align 排列
		if (printCellInfo.align && printCellInfo.align != 0) {
			printCell.SetCellAlign(parseInt(posy), parseInt(posx), sheet, parseInt(printCellInfo.align));
		}
				
		// 2.字体格式 fontModel TODO 
		
		// 3.字体大小
		if (undefined != printCellInfo.fontSize && null != printCellInfo.fontSize) {
			printCell.SetCellFontSize(parseInt(posy), parseInt(posx), sheet, parseInt(printCellInfo.fontSize));
		}
				
		// 4.字体 fontType  为字体数组的索引号 可用函数FindFontIndex()得到，-1为缺省字体，>=0为字体序号 TODO	
		if (printCellInfo.fontType) {
			var para = printCell.FindFontIndex(printCellInfo.fontType, 1);
			printCell.SetCellFont(parseInt(posy), parseInt(posx), sheet, parseInt(para));
		}		
		
/*		// 5.BigDecimal height; TODO 
		if (printCellInfo.height) {
			printCell.SetRowHeight(0, parseInt(printCellInfo.height), parseInt(posx), sheet);
		}
		

		// 6.BigDecimal width;  TODO
		if (printCellInfo.width) {
			printCell.SetColWidth(0, parseInt(printCellInfo.width), parseInt(posy), sheet);
		}*/
		

	    // 7.字体颜色 String fontColor TODO;
		if (printCellInfo.fontColor) {
			// printCell.SetCellTextColor(parseInt(posy), parseInt(posx), sheet, parseInt(printCellInfo.fontColor));
			printCell.SetCellTextColor(parseInt(posy), parseInt(posx), sheet, printCell.FindColorIndex(this.jsRGB(printCellInfo.fontColor), 1));
		}
			    
		// 8.字体属性 BigDecimal fontStyle TODO  BOLD 加粗   0或者空为普通
		if (printCellInfo.fontStyle) {
			printCell.SetCellFontStyle(parseInt(posy), parseInt(posx), sheet, parseInt(printCellInfo.fontStyle));
		}

		// 9.是否排重 BigDecimal isUnion 不需要关注

		/*	    // 打印区域String printArea;  PrintRangeEx (col1 As Long, row1 As Long, col2 As Long, row2 As Long,sheet As Long)
		printCell.PrintRangeEx(parseInt(posy), parseInt(posx), 0, 0, sheet);*/		
	},

	pagePrint: function($Page, $Gadget, printCell){
		debugger;
		$Controller.bes.oc.printdata.setDefaultData($Page, $Gadget, printCell);
		for (var i = 0 ; i < $Gadget.data.besOcPrintData.length; i++) {
			printCell.PrintSheet(0,i);
		}		
	},
	
	/**
	 * 计算RGB值
	 */
	jsRGB: function(rgb) {
		var colors = rgb.split(",");
		if (colors.length != 3 || rgb == "0")
		{
			// 配置不对 默认为1 黑色
			return 1;
		}
		var r = trimStr(colors[0]);
		var g = trimStr(colors[1]);
		var b = trimStr(colors[2]);
		return b*65536 + g*256 + r;
		
		function trimStr(str){
			return str.replace(/(^\s*)|(\s*$)/g,"");
		}
	}
});
