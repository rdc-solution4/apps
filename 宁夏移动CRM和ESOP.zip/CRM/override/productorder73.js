$Controller(
	"bes.oc.productorder", {
		//查询BOSS预付费或后付费接口是否隔离
		isBossIntfSolated : function($Page,$Gadget){
			debugger;
			if(_ysp_top.TabSet){
				var currMenuId = _ysp_top.TabSet.getTabItem().key
			}
			$Fire = $Gadget.$Get('$Fire');
			$Fire({
		        service : '/isolatebossintfservice/isBossIntfListIsolated_query',
		        params:{
		        	menuId : currMenuId
		        },
		        target : '$Gadget.BossIntfIsolateResp',
		        onafter : function($Gadget,$Page){
					debugger;
					$Gadget.BossIntfIsolateResp = $Gadget.BossIntfIsolateResp || {}
					if($Gadget.BossIntfIsolateResp.bossIntfIsolateList && $Gadget.BossIntfIsolateResp.bossIntfIsolateList.length > 0){
						var isHaveIsolated = false;
						for(var i=0;i<$Gadget.BossIntfIsolateResp.bossIntfIsolateList.length;i++){
							var bossIntfIsolated = $Gadget.BossIntfIsolateResp.bossIntfIsolateList[i];
							if(bossIntfIsolated.isolated == '1'){
								isHaveIsolated = true;
								break;
							}
						}
						if(isHaveIsolated){
							$Gadget.$Get('$UI').msgbox.confirm($UEE.i18n('ad.sr.message.TS'),"因系统问题，目前无法查询用户欠费信息，请确认是否继续办理。",
									function(){
									debugger;
									//确定按钮继续操作业务
									return;
								},
								function(){
									//取消按钮 关闭当前页面
									debugger;
									if (_ysp_top.publicObject) {
										Close_tabSet();
									}
									else{
										window.close();
									}
								});
						}
					}
				}
			},$Gadget);

			//查询用户登陆权限
			$Fire({
		        service : '/ucec/v1/querymenuauthtypes',
		        params:{
		        	menuId : currMenuId
		        },
		        target : '$Gadget.menuAuthCheckList',
		        onafter : function(){
					debugger;

				},
				onerror:function(){

				}
			},$Gadget);
		},
		init: function($Gadget, $Fire, $Page) {
			debugger;
			$Gadget.keyWord=$UEE.i18n('ad.unsubscribe.label.keyword');
			window._ysp_top.productPopupFlag = null;

			// modify by f00186409 US-20180929145310-2031113852 2018-10-12 begin
			// 获取异网开户信息
			$Gadget.outTelNum = adutil.getParam("outTelNumber");
			var outTelNumCateGroryId = adutil.getParam("outTelNumCateGroryId");
			if (outTelNumCateGroryId && outTelNumCateGroryId != 'null'){
				$Gadget.outTelNumCateList = outTelNumCateGroryId.split('-');
			}
			
			// $Fire({
			// 	service : 'ucec/v1/common/qrysystemparambykey',
			// 	params : {
			// 		key : "OC_CHANGEMAINPROD_Flag"
			// 	},
			// 	target : "$Gadget.productOrderNewPageResult",
			// 	onafter : function($Gadget) {
			// 		debugger;
			// 		if ($Gadget.productOrderNewPageResult && $Gadget.productOrderNewPageResult == "Y"){
			// 			$Page.productOrderNewPageFlag = true;
			// 		}
			// 	}
			// }, $Gadget);

			adutil.querySysParams("OC_CHANGEMAINPROD_Flag,OC_OUTTELNUM_CATEGORYID", $Gadget, function(){
				$Gadget.productOrderNewPageResult = $Gadget.sysparamResult["OC_CHANGEMAINPROD_Flag"];
				if ($Gadget.productOrderNewPageResult && $Gadget.productOrderNewPageResult == "Y"){
						$Page.productOrderNewPageFlag = true;
						$Gadget.initSearchFlag = false;
				}
				if (!$Gadget.outTelNumCateList ){
					outTelNumCateGroryId = $Gadget.sysparamResult["OC_OUTTELNUM_CATEGORYID"]
					if (outTelNumCateGroryId){
						$Gadget.outTelNumCateList = outTelNumCateGroryId.split('-');
					}
				}
			});
			// modify by f00186409 US-20180929145310-2031113852 2018-10-12 end

			// 查询数据字典, 多个入参以逗号隔开,查询结果放入$Gadget.dictList
			adutil.queryDataDicts("AD_SMSBOMB_PROT_OFFER", $Gadget);

			// 调用数据字典,获取特殊号段字典表(OM_SPE_TEL_SEG)特定主商品字典表（OM_SPE_OFFERING）
		    $Fire({
		    	service : "/common/dictkey",
		    	params : {
		    		"dictkeylist" : ['OM_SPE_TEL_SEG','OM_SPE_OFFERING']
		    	},
		    	target : "$Gadget.speTelList",
		    	onafter : function() {
		    		debugger;
		    		$Page.speTelSegList = $Gadget.speTelList['OM_SPE_TEL_SEG'] || [];
		    		$Page.speOfferingList = $Gadget.speTelList['OM_SPE_OFFERING'] || [];
		    	}
		    },$Gadget);
			//获取个性化推荐里面的offeringid和offerName
			$Page.offerId = adutil.getParam("offeringId");
			$Page.offerName = decodeURIComponent(adutil.getParam("offerName"));
			//一个判断是否是从个性化推荐跳转到订购页面的标志（isIndividuationRecommend=true /表示是，false表示否）
			$Page.isIndividuationRecommend = decodeURIComponent(adutil.getParam("isIndividuationRecommend"));
			if ($Page.isIndividuationRecommend)
			{
				if($Page.isIndividuationRecommend.indexOf("undefined")==-1)
				{
					if($Page.isIndividuationRecommend.indexOf("#/index")!=-1)
					{
						window._ysp_top.isIndividuationRecommend = $Page.isIndividuationRecommend.substring(0,$Page.isIndividuationRecommend.length-7);
					}
				}
			}
			if($Page.offerId)
			{
				if($Page.offerId.indexOf("undefined")==-1)
				{
					$Page.offerId = $Page.offerId.split("#")[0];
				}
				else
				{
					$Page.offerId = '';
				}
			}
			if($Page.offerName)
			{
				if($Page.offerName.indexOf("undefined")==-1)
				{
					if($Page.offerName.indexOf("#/index")!=-1)
					{
						$Page.offerName = $Page.offerName.substring(0,$Page.offerName.length-7);
					}
					$Gadget.keyWord = $Page.offerName;
				}
			}


			initInpPlaceholder($("#productordermainImpl"));

				$Page.businessCode = "ChangeProduct";
				if(parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0){
				$Page.data = $Page.data ||[];
				$Page.data.carofferingList = window._ysp_top.shoppingcart.carofferingList || [];
				$Page.data.offeringId = window._ysp_top.shoppingcart.offeringId;
				$Page.data.offeringinfo = window._ysp_top.shoppingcart.offeringinfo || {};
				var tempPromList = (window._ysp_top.shoppingcart.$Pagea||{}).promInfoList || [];
				if((window._ysp_top.shoppingcart.$Pagea ||{}).params){
					$Page.params = window._ysp_top.shoppingcart.$Pagea.params;
				}
				if((window._ysp_top.shoppingcart.$Pagea ||{}).pageTracId != null && window._ysp_top.shoppingcart.ShoppingFlag=="Y"){
					$Page.pageTracId = window._ysp_top.shoppingcart.$Pagea.pageTracId;
				}
				window._ysp_top.shoppingcart.$Pagea = $Page;
				window._ysp_top.shoppingcart.$Pagea.promInfoList = tempPromList;
			}
			// 判断是否来自新已开客服商品订购
			if(adutil.getGadgetObj($(".bes-ad-shoppingcart-newopen"))){
				$Page.isNewOpenFlag = true;
			}

			//获取代理商开户标示
	    	if($Page.isAgentCreateSubs){
	    		$Page.isAgentCreateSubs = true;
		    }else{
		    	$Page.isAgentCreateSubs = false;
			}

			// 判断是否是CSP系统调用
			if($Controller.bes.ad && $Controller.bes.ad.csp && $Controller.bes.ad.csp.common)
			{
				$Page.isCsp = $Controller.bes.ad.csp.common.isCsp();

				if ($Page.isCsp)
				{
					// 获取号码
					var servNumber = $Controller.bes.ad.csp.common
                                				.getServNumber();
					if (servNumber && servNumber.length == 11)
					{
					    $Controller.bes.ad.csp.common.login($Page, $Fire,$Gadget, $Gadget.$Get('$UI'),
					    		servNumber,
					            function()
					            {
					            },
					            function()
					            {
					                debugger;
					                $UI.msgbox.error($UEE.i18n("ad.person.message.error"), $UEE.i18n("ad.person.message.CSPFailed"));
					            });
					}
				}
                }

			// 判断是否来自用户预约
			$Controller.bes.oc.productorder.checkIsFromProm($Page,$Gadget);
			// 初始化时显示全部页面
			$Gadget.tabIndex = 0;
			// 二维码销售目录信息获取
			$Gadget.qrcode = $Gadget.qrcode || {};
			$Gadget.qrcode.qrcodeInfo = $Gadget.qrcode.qrcodeInfo || {};
			$Gadget.isShowValidateButton = false;

			// 0-不加校验按钮
			// 1-只在营销活动加校验按钮
			// 2-在所有Offering加校验按钮
			$Controller.bes.oc.productValidate.qryValidateButton($Gadget);

			// 结算页面返回去掉ad的base.css
			var linkFileTemp = $("link") || [];
		     var linkFileLen = linkFileTemp.length;
		     for(var i=0; i < linkFileLen; i++)
		     {
		      if(linkFileTemp.eq(i).attr("href") && linkFileTemp.eq(i).attr("href").indexOf("bes/ad/css/base.css") > 0)
		      {
		       linkFileTemp.eq(i).remove();
		      }
		     }

			// 搜索名称keypress事件
			/*
             * $("#inputquerystring").on("keypress", function(e) { debugger; if (e.keyCode == 13) {
             * $("#productquerybtn").trigger("click"); } });
             */
			$(document).on("keydown", "#inputquerystring", function(e) {
				if (e.keyCode == 13) {
					$("#productquerybtn")
							.trigger("click");
				}
			});
			// 搜索充值卡的keypress事件
			$(document).on("keydown", "#query_card", function(e) {
				debugger;
				if (e.keyCode == 13) {
					$("#query_card_btn").trigger("click");
				}
			});
			// 搜索IMEI的keypress事件
			$("#query_offer").on("keydown", function(e) {
				debugger;
				if (e.keyCode == 13) {
					$("#query_offer_btn").trigger("click");
				}
			});

			$Gadget.data = $Gadget.data || {};
			$Gadget.gocheckout = false;
			// 子catalog
			$Gadget.data.childrenIDs = [];
         //   $Gadget.data.levelCategoryName = ["二级类目：","三级类目：","四级类目：","五级类目：","六级类目：","七级类目：","八级类目：","九级类目：","十级类目："];
        	$Gadget.data.levelCategoryName = [$UEE.i18n("ad.person.label.SecondCategory"),$UEE.i18n("ad.person.label.ThirdCategory"),$UEE.i18n("ad.person.label.ForthCategory"),
			                                  $UEE.i18n("ad.person.label.FifthCategory"),$UEE.i18n("ad.person.label.SixthCategory"),$UEE.i18n("ad.person.label.SeventhCategory"),
			                                  $UEE.i18n("ad.person.label.EighthCategory"),$UEE.i18n("ad.person.label.NinthCategory"),$UEE.i18n("ad.person.label.TenthCategory")];

			$Gadget.data.isclickPageNum = false;
			$Gadget.data.isclickFavoritePageNum = false;

			// 购物车
			$Gadget.data.shoppingitemlist = $Gadget.data.shoppingitemlist || [];

			$Gadget.data.productsearchoffering = {
				pageInfo: {},
				offeringList: []
			};

			$Gadget.data.queryString = "";
			$Gadget.data.searchOfferingCond = {};
			$Gadget.data.searchattribute = [];

			// 构造初始化数据
			$Gadget.data.searchOfferingCond = {
			};
			$Gadget.data.pageInfo = {
				beginRowNumber: 0,
				recordPerPage: 6,
				curPage: 1
			};
			// 收藏Tab页面数据
			$Gadget.data.cpageInfo = {
					beginRowNumber: 0,
					recordPerPage: 6,
					curPage: 1
				};

			// 页码控件
			$Gadget.pages = $("#pages");

			// 裸机销售IMEI搜索框展示标示 add by lwx207718
		    $Gadget.imeiSearch = false;

		    // 裸机销售IMEI搜索框展示标示 add by lwx207718
		    $Gadget.cardSearch = false;

		    // 针对销户用户不能办理售货业务 add by l00289234
		    $Gadget.isCancelAccount = "";

		    // 判断当前操作员可以漫游的区域, 新增 601310020160115001 判断是否有异地漫游的权限
		    var isNeedShowRoamRegion = true;
		    if($Page.data && $Page.data.mnpPromFlag)
		    {
		    	isNeedShowRoamRegion = false;
		    }
		    if (isNeedShowRoamRegion && !$Page.isCsp && !$Page.isNewOpenFlag)
		    {
		    	 $Controller.bes.oc.productorder.queryRoamRegionAuth($Gadget, $Fire);
		    }

            $Gadget.title = $UEE.i18n("ad.person.title.offeringSubscription");

            // 是否为批量SP业务
            $Gadget.isBatchSpBusiness = $Page.isBatchSpBusiness;
            // SP业务隐藏收藏
            if ($Gadget.isBatchSpBusiness) {
                $("#offer").css("border", 0);
                $("#product").css("display", "none");
                $Gadget.title = $UEE.i18n("ad.person.title.SelectSPOffer");
                $Gadget.tabIndex = 0;
                $Page.isBatch=$Gadget.isBatchSpBusiness;
                $("#productordermainImpl").removeClass("hasRecommend");
            }

            // 是否为批量营销活动受理业务
            $Gadget.isBatchRewardActivity = $Page.isBatchRewardActivity;
            // 批量业务隐藏收藏
            if ($Gadget.isBatchRewardActivity) {
                $("#offer").css("border", 0);
                $("#product").css("display", "none");
                $Gadget.title = $UEE.i18n("ad.marketplan.label.batch_imei_select");
                $Gadget.tabIndex = 0;
                $Page.isBatch=$Gadget.isBatchRewardActivity;

            }
            // 定位到单独目录
            if("iCRM_MARKETING_WORKBENCH" != $Gadget.$Params.actionSource){
            	$Gadget.offeringId =  adutil.getParam("offeringid");;
            }
            $Gadget.categoryId =  adutil.getParam("categoryId");;
            $Gadget.data.searchOfferingCond.categoryId = $Gadget.categoryId;

            // IVR订单录入 增加渠道信息
            $Gadget.channelId = adutil.getParam("channelId");
			$Gadget.data.searchOfferingCond.channelId = $Gadget.channelId;

			// IVR订单录入 增加业务类型
            $Gadget.busiType = adutil.getParam("busitype");
            // 两城一号预约营销方案
            $Controller.bes.oc.productorder.mnpPromAppointment($Gadget, $Fire, $Page);

			this.qryQQZHOfferIdList($Gadget, $Fire);

            // 默认为全部
// if($Gadget.offeringId){
        	 $("#offer").css("border", 0);
             $("#product").css("display", "none");
             $Gadget.title = $UEE.i18n("ad.person.title.offeringSubscription");
             $Gadget.tabIndex = 0;
// }

            OC.Callchain.setFireSearch($Page.pageId, "poqmorjs");
            $Fire({
		    	service:"ucec/v1/offering/querysubscribedoffering",
		    	target:"$Gadget.queryMainOfferResp",
		    	onafter:function(){
		    		debugger;
		    		if($Gadget.queryMainOfferResp && $Gadget.queryMainOfferResp.body && ($Gadget.queryMainOfferResp.body.offerings||[]).length>0){
		    			$Page.mainOfferingList = $Gadget.queryMainOfferResp.body.offerings;
		    			$Gadget.offeringListHash = [];

		    			if(($Page.mainOfferingList||[]).length == 2){

		    				$.each($Page.mainOfferingList,function(i,val){
			    				var obj = {};
			    				obj.key = val.offeringId;

			    				if(val.status == '2'){
			    					obj.value =$UEE.i18n("ad.person.label.CurrentMainOffer")+"<b style='padding-left: 10px;color: #333;  font-weight: normal;'>"+val.offeringName+"</b>";
			    					$Gadget.offeringListHash[0] = obj;
			    				}
			    				else {
			    					obj.value ="即将生效主套餐:"+"<b style='padding-left: 10px;color: #333;  font-weight: normal;'>"+val.offeringName+"</b>";
			    					$Gadget.offeringListHash[1] = obj;
			    				}
			    			});

		    				var templist = [];
		    				if($Page.mainOfferingList[0].status == '2'){
		    					templist = $Page.mainOfferingList;
		    				}else{
		    					templist[0] =  $Page.mainOfferingList[1];
		    					templist[1] =  $Page.mainOfferingList[0];
		    				}
		    				$Page.mainOfferingList = templist;
		    			}
		    			else if(($Page.mainOfferingList||[]).length == 1){
		    				var obj = {};
		    				obj.key = $Page.mainOfferingList[0].offeringId;
		    				obj.value =$UEE.i18n("ad.person.label.CurrentMainOffer")+"<b style='padding-left: 10px;color: #333;  font-weight: normal;'>"+$Page.mainOfferingList[0].offeringName+"</b>";
	    					$Gadget.offeringListHash[0] = obj;
		    			}
		    			// 设置初始值
	    				$Page.selectedMainOfferingId = $Page.mainOfferingList[0].offeringId;
	    				$Page.selectedMainOfferingInstId = $Page.mainOfferingList[0].offeringInstId;
	    				$Page.selectedMainOfferingIndex = 0;
		    		}

		    		$Controller.bes.oc.productorder.queryCategories($Gadget, $Fire);
		    	}

		    },$Gadget);
            // $Controller.bes.oc.productorder.queryCategories($Gadget, $Fire);
			this.onMessgaFromPortal($Gadget);

			//360视图
			if (window._ysp_top.mixOfferInfo && $Gadget.offeringId) {
				var offerData = {
						offeringId : $Gadget.offeringId
					};
				$Gadget.$Emit("$bes.oc.selectMixOfferInfo", offerData);
			}

			if ($Gadget.isBatchSpBusiness) {
				this.qryBatchSPBeginFeeDay($Gadget);
			}

			// 查询热词接口
			$Controller.bes.oc.productorder.toGetHotSearchWords($Page,$Gadget);

			// 从cookie获取历史词
			var tempHis = $.cookie("hissearchwords");
			if(tempHis){
				$Page.hissearchwords = eval('('+ tempHis +')');
			}else{
				$Page.hissearchwords = [];
			}

			// 点击历史词框意外区域，则隐藏历史词框
			$(document).bind('click',function(e){
				debugger;
				if($(e.target).attr("id") != 'inputquerystring'){
					$(".searchBuyPanel").hide();
				}
			});
			// add begin wwx230437 2015-09-17 V800R001C30TB100 DTS2015091402454 商品订购页面商品推荐组件
			$Controller.bes.oc.productorder.dealRecommendGadget($Gadget, $Fire, $Page);
			// add end wwx230437 2015-09-17 V800R001C30TB100 DTS2015091402454
			// 营销活动集成
			$Controller.bes.oc.productorder.promotionFromWorkbench($Page, $Gadget, $Fire, $Gadget.$Get('$UI'));
			// 商品订购集成
			$Controller.bes.oc.productorder.productorderFromWorkbench($Page, $Gadget, $Fire, $Gadget.$Get('$UI'));
			// 商品订购sp集成
			$Controller.bes.oc.productorder.productorderSpFromWorkbench($Page, $Gadget, $Fire, $Gadget.$Get('$UI'));
			// 是否需要默认选中库存
			$Controller.bes.oc.productorder.isDefaultFilterStock($Page, $Gadget, $Fire, $Gadget.$Get('$UI'));
			// 是否展示二维码
			$Controller.bes.oc.productorder.isShowQrcode($Page, $Gadget, $Fire);
			//系统参数是否展示预约信息按钮
			$Controller.bes.oc.appointmentinfo.isShowAppointmentBtn($Gadget, $Fire);

		},

		// 是否展示二维码
		isShowQrcode: function($Page, $Gadget, $Fire){
			debugger;
			$Fire({
				service : 'ucec/v1/common/qrysystemparambykey',
				params : {
					key : "OC_SHOW_QRCODE"
				},
				target : "$Gadget.isShowQrcode",
				onafter : function($Gadget) {
					debugger;
					$Page.isShowQrcode = $Gadget.isShowQrcode;
				}
			}, $Gadget);
		},

		/**
         * 商品推荐页面判断用户是否登录展示商品推荐
         *
         * @remark wwx230437 2015-09-17 V800R001C30TB100 DTS2015091402454
         */
		dealRecommendGadget:function($Gadget, $Fire, $Page)
		{
			debugger;
			var $recommendGadget = adutil.getGadgetObj($(".bes-ad-recommendoffer"));
			if ($recommendGadget)
			{
				// 控制用户本月流量展示
				$Page.data.showMonthFlow = false;
				// 控制商品推荐
				$Page.data.showRecommend = false;
				OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
				$Fire(
						{
							'service' : 'bes.oc.subscribeinfoservice/issubscribelogin',
							'params' : {},
							'target' : '$Page.personalInfo',
							'onafter' : function()
							{
								if($Page.personalInfo.loginStatus && $Page.personalInfo.subscriberInfo.serviceNumber)
								{
									var subsInfo = {};
									subsInfo.serviceNumber=$Page.personalInfo.subscriberInfo.serviceNumber;
									var personalInfo ={};
									personalInfo.subsInfo=subsInfo;
									$recommendGadget.$Page.personalInfo= personalInfo;

									$Page.data.showRecommend = true;
									$Page.data.showMonthFlow = true;
									$Gadget.$Emit("$bes.recommendoffer");
								}
							}
						}, $Gadget);
			}
		},


		queryCategories:function($Gadget, $Fire){
			debugger;
			var reqScenariotype = "OrderProduct";
			// 客服系统商品订购使用不同的场景id
			if($Gadget.$Page.isNewOpenFlag == true){
				reqScenariotype = "CustSrvSys";
			}

			// 支持URL中传入场景编码
			var paramScenariotype = adutil.getParam("scenariotype")
			if ("" != paramScenariotype)
			{
				reqScenariotype = paramScenariotype;
			}

			$Page = angular.element(document).scope().$Page;
			OC.Callchain.setFireSearch($Page.pageId, "poBtnqjs");
			// 根据场景和渠道id 获取catagorylist 同时根据第一个查询对应的搜索属性
			$Fire({
				'service': 'bes.oc.occatalogqueryservice/querycategoriesbychannelandscenario',
				'params': {
					scenariotype: reqScenariotype
				},
				'target': '$Gadget.data.categories',
				'onafter': function($Gadget, $Fire) {
					debugger;
					// null
					if (!$Gadget.data.categories) {
						return;
					}
					var familyCatagorys = $Page.dictList['OC_FAMILY_CATAGORY'] || [];
					var homeNumCatagory = "";
					$.each(familyCatagorys, function(i, val) {
						if(val.itemCode =='QQZH'){
							homeNumCatagory = val.dictName;
						}
					});
					if(homeNumCatagory == "") {
						homeNumCatagory = 10034;
					}
					$Gadget.data.categories = $.grep($Gadget.data.categories,function(val,i){
						// 过滤掉亲情组合
						return val.categoryId != homeNumCatagory;
					});

					for (var i = 0; i < $Gadget.data.categories.length; i++) {
						for (var j = 0; j < i; j++) {
							if ($Gadget.data.categories[j].order > $Gadget.data.categories[i].order) {
								var temp = $.extend(true, {}, $Gadget.data.categories[j]);
								$Gadget.data.categories[j] = $Gadget.data.categories[i];
								$Gadget.data.categories[i] = temp;
							}
						}
					}
					$Gadget.data.rootcategories = [];

					// 过滤掉亲情组合
					var cataIdArr = [];
					var isChooseCatagory = false;
					var catagoryValue = null;
					$.each($Gadget.data.categories || [], function(i, value) {
                        if ($Gadget.isBatchSpBusiness) {
                            if (value.categoryName && value.categoryId == 18000) {
                                isChooseCatagory = true;
								catagoryValue = value;
                                $Gadget.data.rootcategories.push(value);
                            }
                            return;
                        }

						if (value.categoryName
								&& $Controller.bes.oc.productorder.inArray(
										value.categoryId,
										cataIdArr,
                                        $Gadget )) {
							// 父节点
							if(!value.parentId){
								$Gadget.data.rootcategories.push(value);
							}
							// 指定目录
							if($Gadget.categoryId==value.categoryId)
							{
								isChooseCatagory = true;
								catagoryValue = value;
								return false;
							}
						}
					});

					if(isChooseCatagory){
						// 指定目录
						$Gadget.data.rootcategories= [];
						$Gadget.data.rootcategories.push(catagoryValue);
					}


					if(!$Gadget.categoryId)
					{
						$Gadget.data.searchOfferingCond.categoryId = null;
					}
					if ($Gadget.isBatchSpBusiness) {
						// 获取宁夏局点参数
						debugger;
				        $Fire({
				            service : "ucec/v1/common/qrysystemparamlistbykey",
				            params : {
				            keylist : ['60107061880414']
				            },
				            target : "$Page.systemParamsList",
				            onafter : function() {
				                debugger;
				                if($Page.systemParamsList == "NINGXIA"){
				                    $Gadget.data.searchOfferingCond.categoryId = 999017;
				                } else {
				                	// SP业务 18000
									$Gadget.data.searchOfferingCond.categoryId = 18000;
				                }
				            }
				         }, $Gadget);
					}
					// url中传入categoryId 时 直接再调用一遍点击目录
					// if (adutil.getParam("orderPersonMark") == "orderPersonMark")
					if ("" != adutil.getParam("categoryId") )
					{
						debugger;

						$.each($Gadget.data.rootcategories || [], function(i, val){
							if (val.categoryId == adutil.getParam("categoryId"))
							{
								$Controller.bes.oc.productorder.clickcatalog($Gadget, $Fire, '', $(document).scope(), $("#productcatagory0"), val, 0);
							}
						});

					}
					// 二维码销售目录信息获取
					$Gadget.qrcode.qrcodeInfo.categoryId = null;
					$Gadget.qrcode.qrcodeInfo.categoryName = null;
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 begin
					// 异网开户场景，初始化查询默认处理
					if (!$Gadget.outTelNum || $Gadget.outTelNum =='null' || !$Gadget.outTelNumCateList){
					$Controller.bes.oc.productorder
						.querysearchattr(
							$Gadget,
							$Fire,
							null);
					}
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 end
					 if($Page.data && $Page.data.mnpPromFlag){
					     $.each($Gadget.data.rootcategories || [], function(i, val){
					         if (val.categoryId == '6009'){
					             $Controller.bes.oc.productorder.clickcatalog($Gadget, $Fire, '', $(document).scope(), $("#productcatagory0"), val, 0);
					         }
					     });
					  }
					  // add by f00186409 US-20180929145310-2031113852 2018-10-12 begin
					  // 异网开户场景，初始化默认查询参数配置的一级目录
					var outTelNumCateIsNotRight = true;
					if ($Gadget.outTelNum && $Gadget.outTelNum !='null' && $Gadget.outTelNumCateList && $Gadget.outTelNumCateList.length > 0){
						 $.each($Gadget.data.rootcategories || [], function(i, val){
					         if (val.categoryId == $Gadget.outTelNumCateList[0]){
					         	$Gadget.outTelNumIndex = i;
					             $Controller.bes.oc.productorder.clickcatalog($Gadget, $Fire, '', $(document).scope(), $("#productcatagory" + i), val, 0);
					             outTelNumCateIsNotRight = true;
					         }
					     });
					}
					// 异网开户场景，配置参数匹配不到一级目录的场景，走正常商品订购查询逻辑
					if (outTelNumCateIsNotRight){
						$Controller.bes.oc.productorder
						.querysearchattr(
							$Gadget,
							$Fire,
							null);
					}
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 end
				}
			}, $Gadget);

		},

		checkRadio:function($Gadget,$index,$Item){
			debugger;
			var $Page = $(document).scope().$Page;
			$Page.selectedMainOfferingId = $Page.mainOfferingList[$index].offeringId;
			$Page.selectedMainOfferingInstId = $Page.mainOfferingList[$index].offeringInstId;
			$Page.selectedMainOfferingIndex = $index;
			$Controller.bes.oc.productorder.clickSearch($Gadget, $Gadget.$Get('$Fire'));
		},
        /**
         * 查询系统参数
         */
        qryBatchSPBeginFeeDay : function($Gadget) {
            debugger;

            $Page = angular.element(document).scope().$Page;
            OC.Callchain.setFireSearch($Page.pageId, "poQBSPjs");
            $UI = $Gadget.$Get('$UI');
            // 请求初始化数据
            $Gadget.$Get("$Fire")({
                'service' : 'ucec/v1/common/qrysystemparambykey',
                'params' : {
                    key : "BatchSPBeginFeeDay"
                },
                'target' : '$Gadget.BatchSPBeginFeeDay',
                onafter : function($Gadget, $UI) {
                    debugger;

                    // 如果值为空，默认给10
                    if (!$Gadget.BatchSPBeginFeeDay || $Gadget.BatchSPBeginFeeDay === "" || $Gadget.BatchSPBeginFeeDay == null) {
                        $Gadget.BatchSPBeginFeeDay = 10;
                    }

                    $Controller.bes.oc.productorder.hint($Gadget);
                }
            }, $Gadget);
        },

        hint : function($Gadget) {
            var day = new Date().getDate();
            if (day >= $Gadget.BatchSPBeginFeeDay) {
            	// 每月10号（含）之后批量开通短信、彩信和WAP类业务可能会导致本月不收取包月费，请确认后操作。
                var msg = $UEE.i18n("ad.productorder.message.MY") + $Gadget.BatchSPBeginFeeDay + $UEE.i18n("ad.productorder.message.DXCXWAP");

                $UI = $Gadget.$Get('$UI');
                $UI.msgbox.info($UEE.i18n("ad.person.label.information"), msg);
            }
        },

        onValueChange : function($Page, $Gadget) {
            debugger;
            if ($Page.batchAction == "1") {
                $Gadget.batchSPBusinessAction = $UEE.i18n("ad.person.button.Subscribe");

                // $Controller.bes.oc.productorder.hint($Gadget);
            } else {
                $Gadget.batchSPBusinessAction = $UEE.i18n("ad.person.button.cancel");
            }

            $Page.selectedAddiProd = [];
            $Controller.bes.oc.productorder.sendData2AddiProd($Gadget, $Page.selectedAddiProd);
        },

		// 查询操作员可以漫游的区域
		queryRoamRegionAuth : function($Gadget, $Fire){
			debugger;

			// roamRegion赋值后，就不再重新初始化
			if($Page.roamRegion){
				return;
			}

			$Page = angular.element(document).scope().$Page;
			OC.Callchain.setFireSearch($Page.pageId, "poQREAjs");
			$Fire({
		    	'service' : 'roamregionproductorderboservice/queryroamregionproduct',
		    	'target' : '$Gadget.data.roamRegionData',
		    	'onafter' : function(){
		    		debugger;

		    		if($Gadget.data.roamRegionData && $Gadget.data.roamRegionData.hasRoamRight)
		    		{
		    			$Gadget.isShowRoamRegion = $Gadget.data.roamRegionData.hasRoamRight;
// //桩
// $Gadget.data.roamRegionData.allRoamRegion = [
// {
// beId : '18',
// regionName : '镇江',
// depId : '18100000',
// isDefault : true
// },
// {
// beId : '19',
// regionName : '无锡',
// depId : '18100000'
// }
// ];

		    			$Gadget.data.roamRegion = $Gadget.data.roamRegion ||[];
						$.each($Gadget.data.roamRegionData.allRoamRegion || [], function(i, val) {
							var item = {
								key : val.beId,
								value : val.regionName
							};
							$Gadget.data.roamRegion.push(item);
							if (val.beId == _ysp_top.$BES.$ContextAccessor.getBeId()){
								$Gadget.data.defaultRoamDept = val.deptId;
								$Gadget.data.selectedRoamRegion = val.beId;
							}
						});

						$Gadget.roamRegionInit = true;
						$Page.roamRegion = $Gadget.data.selectedRoamRegion;
						_ysp_top.$BES.$ContextAccessor.putAttribute("BIZ_BE_ID",$Page.roamRegion);
		    		}
		    		else{
		    		    _ysp_top.$BES.$ContextAccessor.putAttribute("BIZ_BE_ID", _ysp_top.$BES.$ContextAccessor.getAttribute("BE_ID"));
		    		}
		    	}
		    },$Gadget);
		},

		roamRegionChange: function($Gadget, $Fire, $Page)
		{
			debugger;
			if($Gadget.roamRegionInit){
				$Gadget.roamRegionInit = false;
				return;
			}
			$v_div = $("#productcatagory");
			if ($v_div.siblings().hasClass("selected")) {
				$v_div.siblings().removeClass("selected");
			}
			$v_div.addClass("selected");

			$.each($Gadget.data.roamRegionData.allRoamRegion || [], function(i, val) {
				if ($Gadget.data.selectedRoamRegion == val.beId){
					$Gadget.data.defaultRoamDept = val.deptId;
				}
			});

			$Fire({
		    	'service' : 'roamregionproductorderboservice/setroamregionanddept',
		    	'params' : {
		    		selectedroamregion : $Gadget.data.selectedRoamRegion,
		    		defaultroamdept : $Gadget.data.defaultRoamDept
                },
		    	'target' : '$Gadget.data.roamRegionDataSetResult',
		    	'onafter' : function(){
		    		debugger;
		    		if ($Gadget.data.roamRegionDataSetResult){
		    			$Page.roamRegion = $Gadget.data.selectedRoamRegion;
		    			_ysp_top.$BES.$ContextAccessor.putAttribute("BIZ_BE_ID",$Page.roamRegion);
			    		$Controller.bes.oc.productorder.init($Gadget, $Fire, $Page);
		    		}
		    	}
		    },$Gadget);
		},

		querysearchattr: function($Gadget, $Fire, categoryid, $Target) {
			debugger;
			if ($Gadget.isBatchSpBusiness) {
				// SP业务 18000 add by w00316510
				categoryid = 18000;
			}

			// 商品订购的categoryid到Gadget中
			$Gadget.selectCategoryId=categoryid;
			var $Page = $(document).scope().$Page;
			var catagorys = $Page.dictList['OC_FAMILY_CATAGORY'] || [];
			var termtnalCatagory = "";
			$.each(catagorys, function(i, val) {
				if(val.itemCode =='TERMINAL'){
					termtnalCatagory = val.dictName;
				}
			});
			if(termtnalCatagory == "") {
				termtnalCatagory = 9032;
			}
			// 裸机销售IMEI搜索框展示标示 add by lwx207718
			if (termtnalCatagory == categoryid){
				$Gadget.imeiSearch = true;
				$Gadget.isFilterStockDiv = true;
				// 是否需要默认选中库存帅选
				if($Gadget.defaultFilterStock){
					$Gadget.isFilterStock = true;
				}
			}else{
				$Gadget.imeiSearch = false;
				$Gadget.isFilterStockDiv = false;
			}

			$Page = angular.element(document).scope().$Page;
			OC.Callchain.setFireSearch($Page.pageId, "poIMEIjs");
			// 裸机销售IMEI搜索框展示标示 add by lwx207718
			if ("8000" == categoryid)
			{
				$Gadget.cardSearch = true;
			}
			else
			{
				$Gadget.cardSearch = false;
			}
			$Fire({
				'service': 'bes.oc.salescatalogqueryservice/querysearchattributebycategoryid',
				'params': {
					categoryid: categoryid,
					catalogid: ''
				},
				'target': '$Gadget.data.searchattribute',
				'onafter': function($Gadget, $Fire) {
					debugger;
					if (0 == ($Gadget.data.searchattribute || []).length) {

					} else {
						// 销售标签在前台写死，此处不用
// $Controller.bes.oc.productorder.pushSaleTagCon($Gadget, $Fire);
						$Gadget.data.searchOfferingCond.extendCondition = $Gadget.data.searchOfferingCond.extendCondition || [];
						if($Gadget.isBatchRewardActivity){
							$Gadget.data.searchOfferingCond.extendCondition = [];
							$Gadget.data.searchattribute = [];
						}
						for (var i = 0; i < $Gadget.data.searchattribute.length; i++) {

							try
							{
								$Gadget.data.searchattribute[i].name = $
								.parseJSON($Gadget.data.searchattribute[i].name || "{}")[adutil.getLocale()];
							}
							catch(e)
							{

							}
							$Gadget.data.searchattribute[i].options = $
								.parseJSON($Gadget.data.searchattribute[i].options || "{}");

							if ($Gadget.data.searchattribute[i].code == "C_O_BRAND") {
	                            // 保存原始品牌属性，用于查询offer
	                            $Gadget.data.topBrandAttr = $Gadget.data.searchattribute[i];
	                            $Gadget.data.topBrandAttr.index = i;

	                            $Gadget.data.topBrandAttr.name = $UEE.i18n("ad.person.title.Brand");
	                            $Gadget.data.topBrandAttr.options = [];
	                            $Gadget.data.topBrandAttr.isTopBrand = true;

	                            $Controller.bes.oc.productorder.queryBrand($Gadget, $Fire);
	                        }

						}

					}
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 begin
					// 异网开户菜单跳转商品订购特殊处理
					if ($Gadget.outTelNum && $Gadget.outTelNum != "null" && !$Gadget.isAlredyLoad && $Gadget.outTelNumCateList && $Gadget.outTelNumCateList.length > 0){
						// 异网开户商品订购筛选条件系统参数设置（拆分后列表）
						$.each($Gadget.outTelNumCateList, function(x,cateId){
							// 循环一级目录下各个子目录（根据系统参数配置，配置为***-***循环到二级目录，配置为***-***-***为循环到三级目录，以此类推）
							$.each($Gadget.data.childrenIDs,function(i, value) {
									$.each(value,function(j, val) {
										if (val.categoryId == cateId){
											// categoryid与参数配置相同，查询本目录下的子目录，当到底最下层目录，查询对应的商品列表
											$Controller.bes.oc.productorder.clickcatalog($Gadget, $Fire, '', $(document).scope(), $("#productcatagorychilds" + j), val, j+1);
											if (x == $Gadget.outTelNumCateList.length -1){
												$Gadget.isAlredyLoad = true;
											}
										}
									});
										
								});
						});		
					}
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 end
					if (adutil.getParam("orderPersonMark") == "orderPersonMark")
					{
						debugger;
						$.each($Gadget.data.searchattribute || [], function(j, valj){
							var titem = null;
							$.each(valj.options || [],function(k, valk){
								if (valk.VALUE == "rtPerson")
								{
									titem = valk;
								}
							});
							if (titem)
							{
								$Gadget.promShow = true;
								$Page.isMoreShowing = true;
								$Gadget.data.searchattribute[j].options = new Array();
								$Gadget.data.searchattribute[j].options.push(titem);
								$Controller.bes.oc.productorder.clickattr($Gadget, $Fire, titem, $(document).scope(), $("#productattr"+valj.id+"0"), valj);
							}
						});
					}
					// 充值卡把他的价格搜索过滤掉
					if("8000" == categoryid){
						for (var k = 0; k < $Gadget.data.searchattribute.length; k++) {
							if($Gadget.data.searchattribute[k].code == "C_O_PRICE_SEARCH"){
								$Gadget.data.searchattribute.splice(k, 1);
								k--;
							}
						}
					}
					$Gadget.data.pageInfo = {
						beginRowNumber: 0,
						recordPerPage: 12,
						curPage: 1
					};
					$Gadget.data.cpageInfo = {
							beginRowNumber: 0,
							recordPerPage: 12,
							curPage: 1
						};
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 begin
					// 异网开户场景，设置查询标识，防止重复查询
					if ($Gadget.outTelNum && $Gadget.outTelNum != "null"){
						if (!$Gadget.isAlredySearch && $Gadget.outTelNumCateList && $Gadget.outTelNumCateList.length > 0 && categoryid == $Gadget.outTelNumCateList[$Gadget.outTelNumCateList.length -1]){
							$Gadget.isAlredySearch = true;
						}
					}
					$Controller.bes.oc.productorder.clickSearch($Gadget, $Fire);
					// add by f00186409 US-20180929145310-2031113852 2018-10-12 end
				}
			}, $Gadget);
		},
		  // 查询大品牌及其小品牌
        queryBrand: function ($Gadget, $Fire) {
            debugger;

            OC.Callchain.setFireSearch($Page.pageId, "poQB01js");
            $Fire({
                'service': 'ucec/v1/pcBrandQuery/queryAllTopAndChildBrands',
                'target': '$Gadget.data.allTopAndChildBrandsRes',
                'onafter': function ($Gadget, $Fire) {
                    debugger;
                    if (!$Gadget.data.allTopAndChildBrandsRes || !$Gadget.data.allTopAndChildBrandsRes.body || !$Gadget.data.allTopAndChildBrandsRes.body.brandPOJOs) {
                        return;
                    }

                    $Gadget.allOptions = [];
                    $Gadget.data.allTopAndChildBrands = $Gadget.data.allTopAndChildBrandsRes.body.brandPOJOs;
                    for (var i = 0; i < $Gadget.data.allTopAndChildBrands.length; i++) {
                        var item = {};
                        item.childBrands = [];
                        item.LABEL = $Gadget.data.allTopAndChildBrands[i].topBrand.brandName;
                        item.VALUE = $Gadget.data.allTopAndChildBrands[i].topBrand.brandId;
                        item.isTopBrand = true;
                        $Gadget.data.topBrandAttr.options.push(item);
                        var childBrands = $Gadget.data.allTopAndChildBrands[i].childBrands;
                        if (childBrands && childBrands.length > 0) {
                            for (var j = 0; j < childBrands.length; j++) {
                                var chldItem = {};
                                chldItem.LABEL = childBrands[j].brandName;
                                chldItem.brandId = childBrands[j].brandId;
                                chldItem.isTopBrand = false;
                                item.childBrands.push(chldItem);
                                $Gadget.allOptions.push(chldItem);
                            }
                        }

                    }

                    $Gadget.data.chldBrandAttr = $.extend(true, {}, $Gadget.data.topBrandAttr);
                    $Gadget.data.chldBrandAttr.$$hashKey = "000XX";// jquery拷贝出来对象hashKey相同，angularjs报错
                    $Gadget.data.chldBrandAttr.id = "chldBrandAttr";
                    $Gadget.data.chldBrandAttr.name = $UEE.i18n("ad.person.label.SubBrand");
                    $Gadget.data.chldBrandAttr.isTopBrand = false;
                    $Gadget.data.chldBrandAttr.options = $Gadget.allOptions;
                    $Gadget.data.searchattribute.push($Gadget.data.chldBrandAttr);

                    for (var k = 0;k < $Gadget.data.searchattribute.length; k++) {
                        if ($Gadget.data.searchattribute[k].$$hashKey == "000XX") {
                            $Gadget.data.chldBrandAttr.index = k;
                        }
                    }
                }
            }, $Gadget);


        },
		pushSaleTagCon : function($Gadget, $Fire)
		{
			debugger;
			var isneedpush = true;
			for (var i = 0; i < $Gadget.data.searchattribute.length; i++)
			{
				if ("C_O_SALE_TAGS" == $Gadget.data.searchattribute[i].code)
				{
					isneedpush = false;
					break;
				}
			}
			if (isneedpush)
			{
				$Gadget.data.searchattribute.push
				({
					id: "99999999",
			        code: "C_O_SALE_TAGS",
			        name: "{\"zh_CN\":\"销售标签\",\"en_US\":\"销售标签\"}",
			        order: $Gadget.data.searchattribute.length + 1,
			        inputType: "SINGLE_SEL",
			        isMulti: "N",
			        options: "[{\"LABEL\":\"主推\",\"VALUE\":\"3\"},{\"LABEL\":\"热销\",\"VALUE\":\"1\"},{\"LABEL\":\"最新\",\"VALUE\":\"2\"}]"
				});
			}
		},

		AssemblySearchCondition:function($Gadget,$Fire){

		},
		clickSearch: function($Gadget, $Fire) {
			debugger;

			if($Gadget.isBatchRewardActivity){
				$Gadget.data.searchOfferingCond.extendCondition = [{conditionId: "PM_PROM_TYPE", conditionValue: ["rtPerson"]}];
			}


			// 默认为全部
// if($Gadget.offeringId){
	 		$("#offer").css("border", 0);
     		$("#product").css("display", "none");
    		$Gadget.title = $UEE.i18n("ad.person.title.offeringSubscription");
// }

			$Gadget.data.clickSearchFlag = false;
			/*
             * if ($.trim($("#inputquerystring").val()).length == 0) { return false; }
             */
			// $Gadget.data.searchOfferingCond.queryType =
			// 'searchAppendOffering';

			// 0-不加校验按钮
			// 1-只在营销活动加校验按钮
			// 2-除了主产品以外所有Offering加校验按钮
			var $Page = $(document).scope().$Page;
			if($Gadget.validateButton == 1){
				var catagorys = $Page.dictList['OC_FAMILY_CATAGORY'] || [];
				var promCatagory = "";
				$.each(catagorys, function(i, val) {
					if(val.itemCode =='PROM'){
						promCatagory = val.dictName;
					}
				});
				if(promCatagory == "") {
					promCatagory = 6009;
				}
				// 只在营销活动加校验按钮
				if($Gadget.selectCategoryId == promCatagory){
					$Gadget.isShowValidateButton = true;
				}else{
					$Gadget.isShowValidateButton = false;
				}
			}else if($Gadget.validateButton == 2){
				// 除了主产品以外的offer都展示
				//0331 数据整改，不区分主offer,全部展示
				$Gadget.isShowValidateButton = true;
			}else{
				$Gadget.isShowValidateButton = false;
			}

			$Gadget.offerCondition = "";
			$Gadget.data.searchOfferingCond.queryType = 'searchAvaliableOfferList';
			$Gadget.data.searchOfferingCond.keyWord = $.trim($Gadget.keyWord || "");

			// 默认去掉placeholder
			if($UEE.i18n('ad.unsubscribe.label.keyword')  == $Gadget.data.searchOfferingCond.keyWord){
				$Gadget.data.searchOfferingCond.keyWord = "";
			}


			if (!$Gadget.data.isclickPageNum) {
				var sortItems = $Gadget.data.pageInfo.sortItems;
				$Gadget.data.pageInfo = {
					beginRowNumber: 0,
					recordPerPage: 12,
					curPage: 1
				};
				 $Gadget.data.pageInfo.sortItems = sortItems;
				// 收藏Tab页码数据
				$Gadget.data.cpageInfo = {
						beginRowNumber: 0,
						recordPerPage: 12,
						curPage: 1
					};
			}

			// 添加关键字到搜索历史
			if($Gadget.data.searchOfferingCond.keyWord != ""){
				this.addWordToHis($Gadget, $Gadget.data.searchOfferingCond.keyWord);
			}

			if ($Gadget.data && $Gadget.data.searchOfferingCond) {
				$Gadget.data.searchOfferingCond.pcHighlightFiledCondTRSVO = {
					highLightFileds: ["offerName"]
				};
			    // 主销售品不传主offter,0331销售目录整改，主offer可挂在任一目录下
		       $Gadget.data.searchOfferingCond.mainOfferingId = $(document).scope().$Page.selectedMainOfferingId;
		       $Gadget.data.searchOfferingCond.recType = "ChangeProduct";
			}

			// add by f00186409 US-20180929145310-2031113852 2018-10-18 begin
			if ($Gadget.outTelNum && $Gadget.outTelNum != "null"){
				$Gadget.data.searchOfferingCond.recType = "HighvalueOutNetCreateSubs";
			}
			// add by f00186409 US-20180929145310-2031113852 2018-10-18 end

			$Gadget.data.productsearchoffering = $Gadget.data.productsearchoffering ||{};
			$Gadget.data.productsearchoffering.offeringList = [];
			// 指定offeringId

			$Gadget.offeringId = $Page.offerId;
			if($Gadget.offeringId)
			{
				$Gadget.data.productsearchoffering.offeringList.push($Gadget.offeringId);
            			$Gadget.data.searchOfferingCond.offeringIdList=$Gadget.data.productsearchoffering.offeringList;
			}

			// add begin wwx230437 2015-10-16 C30LJS001TB100 DTS2015101100821 对于未发布商品层级的奖品进行“全部”条件查询时过滤
			$Gadget.data.searchOfferingCond.catalogId = undefined;
			if (null == $Gadget.data.searchOfferingCond.categoryId
					 || undefined == $Gadget.data.searchOfferingCond.categoryId
					 || "" == $Gadget.data.searchOfferingCond.categoryId)
			{
				$Gadget.data.searchOfferingCond.catalogId = "7001";
			}
			// add end wwx230437 2015-10-16 C30LJS001TB100 DTS2015101100821

			if($Gadget.tabIndex == 1)
			{

				$Controller.bes.oc.productorder.queryFavoriteInfo($Gadget,$Fire,0,true);
				return;
			}
			// 是否库存过滤
			if($Gadget.isFilterStockDiv && $Gadget.isFilterStock){
				$Gadget.data.searchOfferingCond.isFilterInvVolume = "Y";
			}else{
				$Gadget.data.searchOfferingCond.isFilterInvVolume = "N";
			}

			$Page = angular.element(document).scope().$Page;

			// 设置名字和价格升序排序
			if(($Gadget.data.pageInfo.sortItems||[]).length == 0){
				$Gadget.data.pageInfo.sortItems =  [
				        							{
				        								'sortDir' : 'ASC',
				        								'sortField' : 'offer_type_sort_order'
				        							},
				        			                {
				        			                	'sortDir' : 'ASC',
				        			                	'sortField' : 'sale_tag.sale_tag_sort_order'
				        			                },
				        							{
				        								'sortDir' : 'ASC',
				        								'sortField' : 'offer_name_length'
				        							}
				        	                ];
			}

			// MODIFY 2015-10-20 by l00289267 DTS2015092110255 start
			$Gadget.data.searchOfferingCond.opreTypeList = ['O'];
			// MODIFY 2015-10-20 by l00289267 DTS2015092110255 end

			// 使搜索框获取焦点
			if ($Gadget.cardSearch) {
				$("#query_card").focus();
			}
			if ($Gadget.imeiSearch) {
				$("#query_offer").focus();
			}

			//清空二维码的入参
			$Gadget.data.searchOfferingCond.queryCodeContent = null;
			//销售目录整改，主offer可挂在任一目录下
			$Gadget.data.searchOfferingCond.queryType = "searchMainAndAppendOffering";

			OC.Callchain.setFireSearch($Page.pageId, "poBntSjs");
			$Fire({
				'service': 'bes.oc.pcsearchex4telecomqueryservice/queryfilterofferlist',
				'params': {
					'searchofferingcond': $Gadget.data.searchOfferingCond,
					'pageinfo': $Gadget.data.pageInfo
				},
				'target': '$Gadget.data.productsearchoffering',
				'onafter': function($Gadget, $Fire) {
					debugger;
					//站内搜索埋点 add by p00354016
					var currentPage = $Gadget.data.pageInfo.beginRowNumber / $Gadget.data.pageInfo.recordPerPage + 1;
					var searchResult;

					if (!$Gadget.data.productsearchoffering || !$Gadget.data.productsearchoffering.offeringList
							|| $Gadget.data.productsearchoffering.offeringList.length<=0) {
						searchResult = 0;
						currentPage = 0;
					}
					else {
						searchResult = 1;
					}
					var keyWord = $Gadget.data.searchOfferingCond.keyWord;
					if (keyWord!=undefined && keyWord !=null && keyWord != ""){
						$BuriedPoinStat.searchstat(keyWord, "product", searchResult, currentPage);
					}
					//站内搜索埋点 end

					if (null == $Gadget.data.productsearchoffering) {
						$Gadget.data.productsearchoffering = $Gadget.data.productsearchoffering || {};
					}
					// $("#inputquerystring").focus();
					$Gadget.data.productsearchoffering = $Gadget.data.productsearchoffering || {};

					//排序US-20170906181553-2031034600商品展现顺序优化
					$Gadget.data.productsearchoffering.offeringList = $Controller.bes.oc.productorder.sortsearchofferinglist($Gadget.data.productsearchoffering.offeringList);

					// 高亮显示的时候 offeringname里面存在<em> title显示的时候有问题
					$.each($Gadget.data.productsearchoffering.offeringList ||[],function(i,val){
						val.offeringNameTitle = val.offeringName;
						val.offeringNameTitle = val.offeringNameTitle.replace(new RegExp("<em>",'gm'),'');
						val.offeringNameTitle = val.offeringNameTitle.replace(new RegExp("</em>",'gm'),'');

						// 子offer排序
						if((val.pcHitChildOfferingList ||[]).length > 0 ){
							$.each(val.pcHitChildOfferingList ,function(j,valj){
								if(null == valj.memberOrder){
									valj.memberOrder = 9999;
								}
							});
							val.pcHitChildOfferingList = $Controller.bes.oc.productorder.sortsearchofferinglist(val.pcHitChildOfferingList);
						}
					});

					if (!$Gadget.data.isclickPageNum) {
						$("#pages").empty();
						if ($Gadget.data.productsearchoffering.offeringList && $Gadget.data.productsearchoffering.offeringList.length > 0) {
                                $Gadget.data.pages = new UCD.Pages(
                                        $("#pages"),
                                        $Gadget.data.productsearchoffering.pageInfo.totalRecord,
                                        $Gadget.data.pageInfo.recordPerPage,
                                        [ 6, 12 ], 1);

							// add by lwx207718 2015-05-29 修改高亮显示问题单 begin
							// 高亮展示
							$Controller.bes.oc.productorder.highlight($Gadget);
							// add by lwx207718 2015-05-29 修改高亮显示问题单 end

						} else {
							$Gadget.data.pages = null;
						}
						$Gadget.data.isclickPageNum = false;

					} else {
						if ($Gadget.data.productsearchoffering.pageInfo) {
							$Gadget.data.pages
								.setTotal($Gadget.data.productsearchoffering.pageInfo.totalRecord);

							// add by lwx207718 2015-05-29 修改高亮显示问题单 begin
							$Controller.bes.oc.productorder.highlight($Gadget);
							// add by lwx207718 2015-05-29 修改高亮显示问题单 end

						} else {
							$Gadget.data.pages.setTotal(0);
						}
						$Gadget.data.isclickPageNum = false;

					}

					// add by f00186409 US-20180929145310-2031113852 2018-10-18 begin

					// 构造页面链接按钮显示
					$Controller.bes.oc.productorder.convertOffering($Gadget);

					$Gadget.data.clickSearchFlag = true;
					$Gadget.data.isClickSearch = true;
					//第一次查询完后吧offeringId设为空，避免一直查询出某个固定的商品
					$Gadget.data.searchOfferingCond.offeringIdList = [];
					$Page.offerId = '';
					$Page.offerName = '';
					//校验之前加控参
					debugger;
					if($Gadget.validateFlag == "Y") {
						window._ysp_top.showOfferingLists = $Gadget.data.productsearchoffering;
						window._ysp_top.serviceNum = $Page.serviceNum;
                		$Controller.bes.oc.productorder.ordervalidate($Gadget,$Page);
	                }
				}
			}, $Gadget);

			// todo:接口调通后删除
			$Gadget.data.isClickSearch = true;
		},
		/**
		 * 排序US-20170906181553-2031034600商品展现顺序优化
		 * 排序函数，入参：排序商品数组，普通商品或营销档次
		 */
		sortsearchofferinglist: function(list){
			debugger;
			if((list || []).length == 0)
				return null;
			//排序
			list.sort(function(a,b){
				if(a.memberOrder && b.memberOrder && a.memberOrder != b.memberOrder){
					//有memberOrder属性的，用memberOrder排序
					return a.memberOrder - b.memberOrder;
				}
				//名称排序，取名称的char数组 商品、商品子offer、营销活动档次
				var stringA = (a.offeringName || a.childOfferingName || (a.levelBaseInfo||{}).offeringName || '');
				var charListA = stringA.split('');
				var stringB = (b.offeringName || b.childOfferingName || (b.levelBaseInfo||{}).offeringName || '');
				var charListB = stringB.split('');
				var length = charListA.length > charListB.length ? charListB.length : charListA.length;//对比的长度取小的
				for ( var i = 0; i < length; i++) {
					if(/[0-9]/.test(charListA[i]) && /[0-9]/.test(charListB[i])){
						var numCompareResult = sortNumSubStrFromStr(stringA.substring(i,stringA.length),stringB.substring(i,stringB.length));
						if(numCompareResult != 0){
							return numCompareResult;
						}
					}else if(/[a-zA-Z]/.test(charListA[i]) && !/[0-9a-zA-Z]/.test(charListB[i])){
							return -1;//字母放中文前面
					}else if(!/[0-9a-zA-Z]/.test(charListA[i]) && /[a-zA-Z]/.test(charListB[i])){
							return 1;//字母放中文前面
					}else{
						//其他情况
						if(charListA[i].localeCompare(charListB[i]) != 0)
							return charListA[i].localeCompare(charListB[i]);
					}
				}
				return charListA.length - charListB.length;
			});
			//排序结束
			return list;
			//数字排序函数
			function sortNumSubStrFromStr(strA,strB){
				var numA = /\D/.test(strA) ? strA.substring(0,strA.replace(/\D/,'___').indexOf('___')) : strA;//获取数字字符串
				var numB = /\D/.test(strB) ? strB.substring(0,strB.replace(/\D/,'___').indexOf('___')) : strB;
				if(numA != numB)
					return numA - numB;//不相等，直接结束检查，排序完成
				if(numA == numB && strA.length != strB.length && (numA == strA.length || numB == strB.length))
					return strA.length - strB.length;//A是B的子字符串或相反，直接结束检查，排序完成
				return 0;
			}
		},

		clickPageNum: function($Gadget, $Fire) {
			if($Gadget.tabIndex == 0){
				setTimeout(
					function() {
						debugger;
						if ($Gadget.data.pages) {
							var selection = $Gadget.data.pages
							.getSelection() > 0 ? $Gadget.data.pages
							.getSelection() - 1 : 0;

						$Gadget.data.pageInfo.selection = selection;
						$Gadget.data.pageInfo.beginRowNumber = selection * $Gadget.data.pageInfo.recordPerPage;

						$Gadget.data.isclickPageNum = true;
						$Controller.bes.oc.productorder.clickSearch(
							$Gadget, $Fire);
					}
				}, 0);
			}else{
				// 收藏页面时
				setTimeout(
					function() {
						debugger;
						if ($Gadget.data.pages) {
							var selection = $Gadget.data.pages
							.getSelection() > 0 ? $Gadget.data.pages
							.getSelection() - 1 : 0;

							$Gadget.data.cpageInfo.selection = selection;
							$Gadget.data.cpageInfo.beginRowNumber = selection * $Gadget.data.cpageInfo.recordPerPage;
							$Gadget.data.isclickFavoritePageNum = true;
							$Controller.bes.oc.productorder.queryFavoriteInfo(
									$Gadget, $Fire,selection);
					}
				}, 0);

			}
		},

		getBlur: function($Gadget, $Fire) {
			debugger;
			$Gadget.isScanCardCode = !$Gadget.isScanCardCode;
			if ($Gadget.cardSearch) {
				if ($Gadget.isScanCardCode) {
					$("#query_card").focus();
				}
			}
			if ($Gadget.imeiSearch) {
				if ($Gadget.isScanCardCode) {
					$("#query_offer").focus();
				}
			}
		},
		// 是否过滤库存
		filterByStock : function($Gadget, $Fire){
			debugger;
			$Gadget.isFilterStock = !$Gadget.isFilterStock;
			$Controller.bes.oc.productorder.clickSearch($Gadget, $Fire);
		},

		scanCard: function($Gadget, $UI) {
			debugger;
			var $Fire = $Gadget.$Get('$Fire');
			// 去掉写死的长度判断
			if ($Gadget.cardSearch) {
				$Controller.bes.oc.productorder.queryCardByIMEI($Fire, $Gadget, $UI);
			}
			//
			if ($Gadget.imeiSearch) {
				$Controller.bes.oc.productorder.queryOfferByIMEI($Fire, $Gadget, $UI);
			}
		},

		clickcatalog: function($Gadget, $Fire, $Attr, scope, $Target, $Item, level) {
			debugger;
			// 初始化热销标签
// delete $Gadget.data.searchOfferingCond.saleTagList;


			var $v_div = $Target;
			$Item = $Item || {};
			// add by f00186409 US-20180929145310-2031113852 2018-10-12 begin
			// 追加当前选中的是异网用户特定套餐标识
			var outTelNumCateId = "";
			$Gadget.isOutTelCate = false;
			if ($Gadget.outTelNumCateList && $Gadget.outTelNumCateList.length > 0){
				outTelNumCateId = $Gadget.outTelNumCateList[$Gadget.outTelNumCateList.length -1];
				if ($Gadget.outTelNum && $Gadget.outTelNum != "null"){
					if ($Item.categoryId == outTelNumCateId){
						$Gadget.isOutTelCate = true;
					}
				}
			}
			// add by f00186409 US-20180929145310-2031113852 2018-10-12 end
			// DTS2015120704662
			if ("18000" == $Item.categoryId)
			{
				$Gadget.is_Sp_Search = true;
			}else{
				$Gadget.is_Sp_Search = false;
			}
			/*
             * if ($v_div.hasClass("selected")) { return false; }
             */
			if ($v_div.siblings().hasClass("selected")) {
				$v_div.siblings().removeClass("selected");
			}
			$v_div.addClass("selected");
			// TODO：查询catagory对应搜索属性

			$Gadget.offerCondition = "";
			var $Page = $(document).scope().$Page;
			var catagorys = $Page.dictList['OC_FAMILY_CATAGORY'] || [];
			var promCatagory = "";
			var terminalCatagory = "";
			$.each(catagorys, function(i, val) {
				if(val.itemCode =='PROM'){
					promCatagory = val.dictName;
				}else if(val.itemCode =='TERMINAL'){
					terminalCatagory = val.dictName;
				}
			});
			if(promCatagory == "") {
				promCatagory = 6009;
			}
			if(terminalCatagory == ""){
				terminalCatagory = 9032;
			}
			// 裸机销售IMEI搜索框展示标示 add by lwx207718
			if (terminalCatagory == $Item.categoryId)
			{
				$Gadget.imeiSearch = true;
			}
			else
			{
				$Gadget.imeiSearch = false;
			}
			// 初始化营销星级过滤
			if (promCatagory == $Item.categoryId)
			{
				$Gadget.promSearch = true;
				$Page.isMoreShowing=false;
			    	$Gadget.promShow=false;
				$Controller.bes.oc.productorder.initPromStar($Gadget, $Fire);
			}
			else
			{
				$Gadget.promSearch = false;
			}
			// 二维码销售目录信息获取
			$Gadget.qrcode.qrcodeInfo.categoryId = $Item.categoryId;
			$Gadget.qrcode.qrcodeInfo.categoryName = $Item.categoryName;

			if("9033" == $Item.categoryId || "8000" == $Item.categoryId ){
				$Page = angular.element(document).scope().$Page;
				OC.Callchain.setFireSearch($Page.pageId, "poCC01js");
				$Fire(
						{
							'service' : 'bes.oc.subscribeinfoservice/issubscribelogin',
							'params' : {},
							'target' : '$Gadget.subscriber',
							'onafter' : function($Page, $Gadget) {
								debugger;
								// 判断用户是否销户,匿名设置为默认用户正常 2
								if($Gadget.subscriber.loginStatus == true){
									$Gadget.isCancelAccount = $Gadget.subscriber.subscriberInfo.status;
								}
							}

						}, $Gadget);
			}

			// var index = 0;

			$Gadget.data.searchOfferingCond.categoryId = $Item.categoryId;
			$Gadget.data.searchOfferingCond.extendCondition = [];
			$Gadget.data.searchOfferingCond.mainBrandIdList = [];
			this.querysearchattr($Gadget, $Fire, $Item.categoryId, $Target);

			// 生成子层级

			var length = $Gadget.data.childrenIDs.length;
			if (length > level) {
				if (0 == level) {
					$Gadget.data.childrenIDs = [];
				} else {
					$Gadget.data.childrenIDs.splice(level, length - level);
				}
			}

			$.each(
					$Gadget.data.categories,
					function(i, value) {
						if (value.parentId && (value.parentId == $Item.categoryId)) {
							if (outTelNumCateId != value.categoryId){
								$Gadget.data.childrenIDs[level] = $Gadget.data.childrenIDs[level] || [];
								$Gadget.data.childrenIDs[level].index = level;
								$Gadget.data.childrenIDs[level].push(value);
	                            $Gadget.data.childrenIDs[level].levelCategoryName = $Gadget.data.levelCategoryName[level];
							}else{
								if ($Gadget.outTelNum && $Gadget.outTelNum != "null"){
									$Gadget.data.childrenIDs[level] = $Gadget.data.childrenIDs[level] || [];
									$Gadget.data.childrenIDs[level].index = level;
									$Gadget.data.childrenIDs[level].push(value);
		                            $Gadget.data.childrenIDs[level].levelCategoryName = $Gadget.data.levelCategoryName[level];
								}
							}
						}
					});
		},
		clickattrDanXuan : function($Gadget, $Fire, $Attr, scope, $Target, $Item) {
			var $v_div = $Target;
			/*
             * if ($v_div.hasClass("selected")) { return false; }
             */
			if ($v_div.siblings().hasClass("selected")) {
				$v_div.siblings().removeClass("selected");
			}
			$v_div.addClass("selected");

			// todo:将选择的内容加入到searchattr
			$Gadget.data.searchOfferingCond.extendCondition = $Gadget.data.searchOfferingCond.extendCondition || [];

			var isExist = false;

			// var index = 0;
			for (var i = 0; i < $Gadget.data.searchOfferingCond.extendCondition.length; i++) {
				if ($Item.id == $Gadget.data.searchOfferingCond.extendCondition[i].conditionId) {
					isExist = true;
					// index = i;
					if ($Attr == '') {
						$Gadget.data.searchOfferingCond.extendCondition
							.splice(i, 1);
					} else {
						$Gadget.data.searchOfferingCond.extendCondition[i].conditionValue = [$Attr.VALUE];
					}
					break;
				}
			}
			if (!isExist) {
				if ($Attr != '' && "C_O_SALE_TAGS" != $Item.code && $Item.code != "C_O_BRAND") {
					$Gadget.data.searchOfferingCond.extendCondition.push({
						conditionId: $Item.id,
						conditionValue: [$Attr.VALUE]
					});
				}

			}

			if ( ($Attr != '') && ("C_O_SALE_TAGS" == $Item.code))
			{
				$Gadget.data.searchOfferingCond.saleTagList = [];
				$Gadget.data.searchOfferingCond.saleTagList.push($Attr.VALUE);
			}else if (($Attr == '') && ("C_O_SALE_TAGS" == $Item.code)){
				$Gadget.data.searchOfferingCond.saleTagList = null;
			}
		},
		/*
         * clickattrFuXuan : function($Gadget, $Fire, $Attr, scope, $Target, $Item) { var $v_div = $Target; var $v_attr =
         * $Attr; var isDelClass = false;
         *
         * if ($v_attr == '') { if ($v_div.siblings().hasClass("selected")) { $v_div.siblings().removeClass("selected"); }
         * $v_div.addClass("selected"); } else { if ($("#productattrall" + $Item.id).hasClass("selected")) {
         * $("#productattrall" + $Item.id).removeClass("selected"); $v_div.addClass("selected"); } else if
         * ($v_div.hasClass("selected")) { isDelClass = true; $v_div.removeClass("selected"); } else {
         * $v_div.addClass("selected"); } }
         *  // todo:将选择的内容加入到searchattr $Gadget.data.searchOfferingCond.extendCondition =
         * $Gadget.data.searchOfferingCond.extendCondition || [];
         *
         * var isExist = false;
         *  // var index = 0; for ( var i = 0; i < $Gadget.data.searchOfferingCond.extendCondition.length; i++) { if
         * ($Item.id == $Gadget.data.searchOfferingCond.extendCondition[i].conditionId) { isExist = true; // index = i;
         * if ($Attr == '') { $Gadget.data.searchOfferingCond.extendCondition .splice(i, 1); break; }
         *
         * else { // MODIFY 2015-10-21 by l00289267 DTS2015102104484 start
         * $Gadget.data.searchOfferingCond.extendCondition .push({ conditionId : $Item.id, conditionValue : [
         * $Attr.VALUE ] }); $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue =
         * $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue || [];
         * $Gadget.data.searchOfferingCond.extendCondition[i].conditionValue.push($Attr.VALUE); break; } } }
         *
         * if (!isExist) { if ($Attr != '' && "C_O_SALE_TAGS" != $Item.code) {
         * $Gadget.data.searchOfferingCond.extendCondition.push({ conditionId : $Item.id, conditionValue : [ $Attr.VALUE ]
         * }); }
         *  }
         *
         * if (($Attr != '') && ("C_O_SALE_TAGS" == $Item.code)) { $Gadget.data.searchOfferingCond.saleTagList = [];
         * $Gadget.data.searchOfferingCond.saleTagList .push($Attr.VALUE); } else if (($Attr == '') && ("C_O_SALE_TAGS" ==
         * $Item.code)) { $Gadget.data.searchOfferingCond.saleTagList = null; }
         *
         * if (isDelClass) { for ( var j = 0; j < $Gadget.data.searchOfferingCond.extendCondition.length; j++) {
         * $Gadget.data.searchOfferingCond.extendCondition[j].conditionValue =
         * $Gadget.data.searchOfferingCond.extendCondition[j].conditionValue || []; for (var k = 0 ; k <
         * $Gadget.data.searchOfferingCond.extendCondition[j].conditionValue.length; k++) { if ($Attr != '' &&
         * $Attr.VALUE == $Gadget.data.searchOfferingCond.extendCondition[j].conditionValue[k]) {
         * $Gadget.data.searchOfferingCond.extendCondition[j].conditionValue.splice(k, 1); k--; } } if
         * ($Gadget.data.searchOfferingCond.extendCondition[j].conditionValue.length == 0) {
         * $Gadget.data.searchOfferingCond.extendCondition.splice(j,1); } } // MODIFY 2015-10-21 by l00289267
         * DTS2015102104484 end } },
         */
		clickattr : function($Gadget, $Fire, $Attr, scope, $Target, $Item) {
			debugger;
			var mainBrandIdList = [];
			if($Item.code == "C_O_BRAND"){
				// 品牌大类
                if ($Item.isTopBrand) {
                    // ALL
                    if (!$Attr) {
                        $Gadget.data.chldBrandAttr.options = $Gadget.allOptions;
                        for (var i = 0; i < $Item.options.length; i++) {
                        	mainBrandIdList.push($Item.options[i].VALUE);
                        }
                    } else {
                        // 具体大品牌
                        $Gadget.data.chldBrandAttr.options = $Attr.childBrands;
                        mainBrandIdList.push($Attr.VALUE);
                    }
                    // 设置搜索品牌为所有小品牌
                    for (var i = 0; i < $Gadget.data.chldBrandAttr.options.length; i++) {
                        mainBrandIdList.push($Gadget.data.chldBrandAttr.options[i].brandId);
                    }
                } else {
                    // 品牌小类
                    // ALL
                    if (!$Attr) {
                        // 设置搜索品牌为所有小品牌
                        /*
                         * 注释掉这段逻辑，当选择全部时传空的数组 20160118 by q00284089 for (var i = 0; i <
                         * $Gadget.data.chldBrandAttr.options.length; i++) {
                         * mainBrandIdList.push($Gadget.data.chldBrandAttr.options[i].brandId); }
                         */
                    } else { // 具体小品牌
                        // 设置搜索品牌为具体小品牌
                        mainBrandIdList.push($Attr.brandId);
                    }
                }
                $Gadget.data.searchOfferingCond.mainBrandIdList = mainBrandIdList;
				$Controller.bes.oc.productorder.clickattrDanXuan($Gadget, $Fire, $Attr, scope, $Target, $Item);
			}
			else{
				// MODIFY 2015-11-06 by l00289267 DTS2015110507706 start
				// 复选改为单选。此为中级结论，如有另外提单，请参考此次修改的单号。
				// $Controller.bes.oc.productorder.clickattrFuXuan($Gadget, $Fire, $Attr, scope, $Target, $Item);
				$Controller.bes.oc.productorder.clickattrDanXuan($Gadget, $Fire, $Attr, scope, $Target, $Item);
				// MODIFY 2015-11-06 by l00289267 DTS2015110507706 start
			}

				$Gadget.data.pageInfo = {
					beginRowNumber : 0,
					recordPerPage : 12,
					curPage : 1
				};
				this.clickSearch($Gadget, $Fire);

			},

		addtocar: function($Page, $Gadget, $Fire, $Item, $UI, $index) {
			debugger;
			// modify by f00186409 US-20180929145310-2031113852 2018-10-16 begin
			if ($Gadget.isOutTelCate){
				//校验异网号码是否可以进行异网开户
				$Fire({
					 service : "/ucec/v1/ctz/qryAndChkOutTel",
		             params : {
		                "serverNumber" :$Gadget.outTelNum
		            },
						target : "$Gadget.result",
						onafter : function ($Gadget)
						{
							debugger;
							if(!$Gadget.result || $Gadget.result.retcode != "0")
							{
								$UI.msgbox.error($UEE.i18n("ad.person.message.error"), $Gadget.result.errmsg);
							}else{
		                        $Controller.bes.oc.productorder.addtocarnext($Page, $Gadget, $Fire, $Item, $UI, $index);
		                    }
						}
				},$Gadget);
			}else{
				$Controller.bes.oc.productorder.addtocarnext($Page, $Gadget, $Fire, $Item, $UI, $index);
			}
			// modify by f00186409 US-20180929145310-2031113852 2018-10-16 end
		},	

		addtocarnext: function($Page, $Gadget, $Fire, $Item, $UI, $index) {
			debugger;
			//开户特殊商品号段校验US-20180201150646-2031068988
			if($Page.speOfferingList && $Page.speOfferingList.length > 0
					&& $Page.speTelSegList && $Page.speTelSegList.length > 0
					&&　$Item.offeringId
					&& $Page.serviceNumber
					&& $Gadget.$Page.menuId == "60131003799"){
				var offerName = $Item.offeringShortName || $Item.offeringName;
				var speTelNum = $Page.serviceNumber.substr(0, 3);
				var pass = true;
				$.each($Page.speOfferingList|| [] ,function(i,val){
					if(val.itemCode == $Item.offeringId){
						var isExit = false;
						var allowNum = "";
						$.each($Page.speTelSegList|| [] ,function(j,valj){
							if(j==0){
								allowNum = allowNum + valj.itemCode;
							}else{
								allowNum = allowNum + "、" +valj.itemCode;
							}
							if(speTelNum == valj.itemCode){
								isExit = true;
							}
						});
						if(!isExit && offerName && allowNum){
							pass = false;
							$Gadget.$Get('$UI').msgbox.info($UEE.i18n("ad.person.message.information"),
									"该商品【"+offerName+"】只允许"+allowNum+"号段号码使用！");
							return;
						}

					}
				});
				if(!pass){
					return false;
				}
			}

			// 判断是否家庭 产品
			$Page.productFlag = "ADD";
			/*
             * $("#recommend").hide(); $("#shoppingcar").show();
             */

			if($Gadget.isCancelAccount == "9"){
				$UI.msgbox.info($UEE.i18n("ad.person.label.information"), "该用户已销户，不予受理。");
				return;
			}


			// todo:根据offeringid查询
			/*
             * for (var i = 0; i < (($Page.data||{}).carofferingList || []).length; i++) { if ($Item.offeringId ==
             * $Page.data.carofferingList[i].offeringId) { $UI.msgbox.error("提示", "购物车中已存在。"); return false; }
             *  }
             */

			// 定义来源于购物车
			$Gadget.callfrom = "car";
			$Gadget.$Item = $Item;

			//
			if ($Page.isClickBtn) {
				return;
			}
			$Page.isClickBtn = true;
			$Controller.bes.oc.productorder.queryofferinginfo($Page,
				$Gadget, $Fire, $UI, $index);
			this.buryPointQuery($Gadget,$Page,$Fire,$Item);

		},

	/*
	*埋点前准备
	*/
	buryPointQuery : function($Gadget,$Page,$Fire,$Item) {
		debugger;

		if(!window._ysp_top.shoppingcarBuryPoint)
		{
			window._ysp_top.shoppingcarBuryPoint=[];
		}
		window._ysp_top.shoppingcarBuryPoint.push($Item);
		var ecommerceItems=[];
		var totalamount=0;
		for(var indexoffer=0;indexoffer<window._ysp_top.shoppingcarBuryPoint.length;indexoffer++)
		{
		totalamount=totalamount+window._ysp_top.shoppingcarBuryPoint[indexoffer].priceValue;
		var ecommerceItem={productSKU:window._ysp_top.shoppingcarBuryPoint[indexoffer].offeringCode,productName:window._ysp_top.shoppingcarBuryPoint[indexoffer].offeringName,productCategory:window._ysp_top.shoppingcarBuryPoint[indexoffer].classificationId,brand:"",variant:"",price:window._ysp_top.shoppingcarBuryPoint[indexoffer].priceValue,quantity:1}
		ecommerceItems.push(ecommerceItem);
		}
		$BuriedPoinStat.addEcommerceItem(ecommerceItems,totalamount);

	},


		queryofferinginfo: function($Page, $Gadget, $Fire, $UI, $index) {
			debugger;
			$Gadget.index = $index;
			if(parent.$ && parent.$(".bes-ad-staticshoppingcar") && parent.$(".bes-ad-staticshoppingcar").length > 0){
				window._ysp_top.shoppingcart.offeringinfo = {};
			}
			$Page.data = $Page.data || {};
			$Page.data.offeringinfo = {};
			$Page.data.offeringId = null;
			$Page.data.childOfferingList = $Gadget.$Item.childOfferingList;
			// 发送请求查询该产品的详细信息.
			var queryReq = {
					'offerid': $Gadget.$Item.offeringId,
					'condition': {'searchBundleOffer':'Y',
						businessCode:'ChangeProduct'
					}
			};
			var isProm = $Gadget.$Item.offerClassCode && $Gadget.$Item.offerClassCode.indexOf("PROM_")==0;
			// 营销活动不调detail接口
			if(isProm){
				$Gadget.data.offeringinfo = $Gadget.data.offeringinfo || {};
				$Controller.bes.oc.productorder.offerDetailProcess($Page, $Gadget);
			}else{
			debugger;
			OC.Callchain.setFireSearch($Page.pageId, "poQOInfo");
			$Fire({
				'service': 'bes.oc.queryofferdetailservice/queryofferdetail',
				'params': queryReq,
				'target': '$Gadget.data.offeringinfo',
				'onafter': function() {
					debugger;
					// todo:更新购物车信息
					if (null == $Gadget.data.offeringinfo) {
						$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.FoundOfferDetail"));
						$Page.isClickBtn = false;
						return false;
					}

					//swx370678
	    			for(var i=0;i<($Gadget.data.offeringinfo.ocOfferingAttrPOJO||[]).length;i++){
	    				if ($Gadget.data.offeringinfo.ocOfferingAttrPOJO[i].attributeId == '20921000050') {
	    					$Gadget.FMC_propvalue=JSON.parse($Gadget.data.offeringinfo.ocOfferingAttrPOJO[i].value || "{}").VALUE;
	    				}
	    			}
					$Page.ocOfferInfoVA = $Gadget.data.offeringinfo.ocOfferInfoVA;
	    			//若是宽带或者魔百合商品，打印收据默认置灰选中。begin swx389632
	    			window._ysp_top.selectedPrintBtn = false;
	    			if ("WBNetTV" == $Gadget.data.offeringinfo.offerSubType) {
	    				window._ysp_top.selectedPrintBtn = true;
    				}else{
    					$.each($Gadget.data.offeringinfo.ocProductInfoVA||[],function(prodi,valprodi){
    	    				$.each(valprodi.ocPcProductIdentityTRSVO||[],function(prodj,valprodj){
    		    				if(valprodj.idenTypeCode == adutil.idenTypeCode.BroadBandAccountId){
    		    					window._ysp_top.selectedPrintBtn = true;
    		    				}
    		    			});
    	    			});
    				}
	    			//若是宽带或者魔百合商品，打印收据默认置灰选中。end
					// 检查操作员是否有订购互联网电视的令牌权限（因现网产品还未上线，此处判断逻辑是反的,仅供测试用）- z00316474,周绍华
					var changeinfoname = '60131001407';
// $Gadget.CVTVAuth = true;
					if( ($Gadget.data.offeringinfo.offerName == "CNTVoffering") && ($Gadget.CVTVAuth == true)){
						OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
						$Fire({
							service : "/ucec/v1/offering/check_accountinfo_byname",
							params : {
								"header" : null,
								"body" : {
								 "chargeInfoName" : changeinfoname
								}
							},
							target : "$Gadget.querypermission",
							onafter : function() {
								debugger;
								if(!$Gadget.querypermission || ($Gadget.querypermission.body.checkFlag != true)){
									$Controller.bes.oc.productorder.offerDetailProcess($Page, $Gadget);
								}else{
									$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.person.message.HasNoPermissionSubscribeInternetTV"));
									return false;
								}
							}
						}, $Gadget);
					}else{
						$Controller.bes.oc.productorder.offerDetailProcess($Page, $Gadget);
					}

				}
			}, $Gadget);
			}
		},

		// 增值业务订购预校验
		beforeGetOfferingInfoDetail : function($Page, $Gadget, $Fire, $UI){
			debugger;
            this.preCheck($Page, $Gadget, $Gadget.$Item, function() {
    			// 预校验放到商品款选的地方校验 详情页面也有对应的校验 所有校验都放在商品即将购入购物车之前 modified by h00308289
    			$Controller.bes.oc.productorder.getOfferingInfoDetail($Page, $Gadget, $Fire, $UI);
            });
		},

	    preCheck : function($Page, $Gadget, offering, callBack) {
	        // 如果商品是亲情组合商品，判断当前号码是否能订购亲情组合商品
	        if (this.isQQZHOffer($Page, $Gadget, offering)) {
		        var validateOfferReq = {
					'validationMode' : 'D',
					'scenarioType' : 'P',
					'validationContext' : {
						'busiType' : 'ChangeProduct',
						'customer' : {
							'customerVO' : {
								'custId' : $Page.subscriber.subscriberInfo.ownerPartyRoleId
							}
						},
						'beId' : $Page.displayPriceInfo.beId
		            },
		            'subscriptionInfo' : {
		                'offeringInfo' : [ {
		                    'actionType' : 'A',
		                    'offeringId' : offering.offeringId
		                } ],
		                'subscriberInfo' : $Page.subscriber.subscriberInfo
		            }
		        };

		        $Fire(
		            {
		                service : "bes.agentdesktop.validateoffering.validateofferingservice/validateofferingsellable",
		                params : {
			                offeringrequest : validateOfferReq
		                },
		                target : "$Gadget.data.checkResp",
		                onafter : function() {
			                debugger;
			                if ($Gadget.data.checkResp
			                    && $Gadget.data.checkResp.executeFlag) {
			                	callBack($Page, $Gadget, offering);
			                } else {
				                $Gadget.$Get('$UI').msgbox.error("提示",
				                    $Gadget.data.checkResp.executeErrMsg);
			                }
		                }
		            }, $Gadget);
	        } else {
            	callBack($Page, $Gadget, offering);
	        }
	    },

	    isQQZHOffer : function($Page, $Gadget, offering) {
			var offerIdList = null;

			if (!$Gadget.QQZHOfferIdList || $Gadget.QQZHOfferIdList.length == 0) {
		    	//商品编码为2000001332-动感地带亲情号码、2000001840-国内亲情号码、2000002155-国内亲情号码2012版；
				offerIdList = [ 2000001332, 2000001840, 2000002155 ];
			} else {
				offerIdList = $Gadget.QQZHOfferIdList;
			}

	        return $.inArray(offering.offeringId, offerIdList) != -1;
	    },

		getOfferingInfoDetail: function($Page, $Gadget, $Fire, $UI) {
			debugger;
			window._ysp_top.serviceNumber = $Page.serviceNumber;
			// 营销活动不走快选流程
			var isProm = $Gadget.$Item.offerClassCode && $Gadget.$Item.offerClassCode.indexOf("PROM_")==0;
			//对于4G飞享共享包不走短流程
			var goShortProcess = true;
			if($Gadget.data.offeringinfo){
		        var product = $Gadget.data.offeringinfo.ocProductInfoVA ;
	            product = product || [];
	            if (product && product.length > 0) {
	                if (product[0].prodType == "JTGX") {
	                     goShortProcess = false;
	                }
	            }
			}
			// 产品快速订购 没有属性和子offer直接加入购物车
			var ismain=null;
			var idenTypeCode=null;
			var arrIdTypeCode = null;
			var idTypeCode = null;
			if($Gadget.data.offeringinfo && ($Gadget.data.offeringinfo.ocProductInfoVA ||[]).length > 0
					&& ($Gadget.data.offeringinfo.ocProductInfoVA[0].ocPcProductIdentityTRSVO||[]).length > 0){
				ismain = $Gadget.data.offeringinfo.ocProductInfoVA[0].ocPcProductIdentityTRSVO[0].isMain;
				idenTypeCode = $Gadget.data.offeringinfo.ocProductInfoVA[0].ocPcProductIdentityTRSVO[0].idenTypeCode;

				if(idenTypeCode){
					arrIdTypeCode=idenTypeCode.split(".");

				}
				if((arrIdTypeCode||[]).length > 0){
					idTypeCode=arrIdTypeCode[0];
				}
			}

			var ocOfferingAttrTemp = [];
			$.each($Gadget.data.offeringinfo.ocOfferingAttrPOJO||[], function(m, valm){
				// MODIFY 2015-11-5 by l00289267 DTS2015110501942 start
				/*
                 * if(valm.isInstantiable == "Y"){ ocOfferingAttrTemp.push(valm); }
                 */
				var isAttrNeedToShowAndModifyAndTransToUser = $Controller.bes.oc.productorder.isAttrNeedToShowAndModifyAndTransToUser(valm);
				if (isAttrNeedToShowAndModifyAndTransToUser) {
					ocOfferingAttrTemp.push(valm);
				}
				// MODIFY 2015-11-5 by l00289267 DTS2015110501942 end
			});
			$Gadget.data.offeringinfo.ocOfferingAttrPOJO = ocOfferingAttrTemp;

			if(!isProm && ($Gadget.data.offeringinfo.ocOfferingAttrPOJO||[]).length ==0
					&& ($Gadget.data.offeringinfo.ocOfferInfoVA||[]).length == 0
					&& $Gadget.data.offeringinfo.isbindOffer != "Y"
					&& ($Page.mainOfferingList||[]).length != 2 && ismain!="N" && idTypeCode !="rsclT"
					&& goShortProcess){
				// 加入购物车逻辑
				$Controller.bes.oc.prodDispachUrl.directAddtoShoppincar($Page, $Gadget);
				$Page.isClickBtn = false;
				return true;
			}

			$Page.canModifyAddiOfferEffTime = null;
			if(($Page.mainOfferingList||[]).length == 2){
				// 查询当前套餐的发布关系 是否在两个里面都发布了
				var 	otherMainofferingId = null;
				if($Page.selectedMainOfferingIndex == 1){
					otherMainofferingId = $Gadget.offeringListHash[0].key;
				}
				else{
					otherMainofferingId = $Gadget.offeringListHash[1].key;
				}

				OC.Callchain.setFireSearch($Page.pageId, "poQBO1js");
				$Fire({
					service:"ucec/v1/offering/querybelongedoffering",
					params:{
						header:{},
						body:{
							offeringId: $Gadget.$Item.offeringId,
							mainofferingId : otherMainofferingId
						}
					},
					target:"$Gadget.queryBelognedResp",
					onafter:function(){
						debugger;
						if((($Gadget.queryBelognedResp||{}).body||{}).flag  == 'N'){
							$Page.canModifyAddiOfferEffTime = 'N';
						}

						$Page.data = $Page.data||{};
						$Page.data.offeringId = $Gadget.$Item.offeringId;
						$Page.data.offeringinfo = {};
						// 营销活动
						if (isProm) {

							$Controller.bes.oc.productorder.queryOverlayOffering($Page,$Gadget, $Fire, $UI);
						}else{
							window._ysp_top.productPopupFlag='1';
							var obj = "productaddtocar"+$Gadget.$Item.offeringId;
							$Controller.bes.oc.productorder.showPartShade($("#"+obj),"../../ad/usl/bes-ad-goofferingdetail.uslx");
						}
						$Page.isClickBtn = false;
						$Page.callfrom = $Gadget.callfrom ;
					}

				},$Gadget);
			}
			else {
				$Page.data = $Page.data||{};
				$Page.data.offeringId = $Gadget.$Item.offeringId;
				$Page.data.offeringinfo = {};
				/*
                 * var height = adutil.pageHeight()-20; var width = adutil.pageWidth()-20;
                 */
				// 营销活动
			if ($Gadget.$Item.offerClassCode && $Gadget.$Item.offerClassCode.indexOf("PROM_")==0) {
				$Controller.bes.oc.productorder.queryOverlayOffering($Page,$Gadget, $Fire, $UI);
			}else{

				window._ysp_top.productPopupFlag='1';
				var obj = "productaddtocar"+$Gadget.$Item.offeringId;
				// parent.$Controller.bes.ad.staticshoppingcar.showPartShade($("#"+obj),"../../ad/usl/bes-ad-goofferingdetail.uslx");
				$Controller.bes.oc.productorder.showPartShade($("#"+obj),"../../ad/usl/bes-ad-goofferingdetail.uslx");
				// $Fire({targetstep:'displayofferingdetail'});
			}

			/*
             * $Fire({popup:{'id':'displayofferingdetail','title' : '商品详情','width' : width+'px','height' : height+'px',
             * 'src':'resource.root'+'bes/ad/html/bes-ad-goofferingdetail.html',resizable:true}});
             */
			$Page.isClickBtn = false;
			$Page.callfrom = $Gadget.callfrom ;

			}
		},

		// 最低消费叠加校验接口
		queryOverlayOffering : function($Page,$Gadget, $Fire, $UI) {
			debugger;
			// 等待大菊花开始
			dontTouchDataOfWholePage();
			OC.Callchain.setFireSearch($Page.pageId, "poQOO1js");
			$Fire({
						'service' : 'bes.agentdesktop.promotionservice/queryOverlayOffering',
						'params' : {
							"offeringId" :$Page.params.levelId
						},
						'target' : '$Page.overlayOffering',
						'onafter' : function($Page,$Gadget, $Fire,$UI) {
							debugger;
							youCanTouchDataOfWholePage();
							$Page.overlayOffering = $Page.overlayOffering || {};
							var msg;
							// 可叠加标识：0 : 不可订购、1 : 可订购叠加、2 : 可订购不存在叠加
							if("1" == $Page.overlayOffering.overlayFlag){
								msg = "您办理的营销案"+$Page.params.levelName+"，与已经生效的营销案"+$Page.overlayOffering.offeringName+"最低消费叠加，请确认是否继续办理。";
								$UI.msgbox.confirm($UEE.i18n("ad.person.label.information"),
										msg,
										function() {
											$Controller.bes.oc.productorder.levelValidate($Page,$Gadget, $Fire, $UI);
										}
									);

							}else{
								$Controller.bes.oc.productorder.levelValidate($Page,$Gadget, $Fire, $UI);
							}
						},
                        'onerror' : function() {
                            debugger;
                            // 关闭大菊花结束
                            youCanTouchDataOfWholePage();
                        }
					}, $Gadget);
		},
		// 判断是否有购买产品的权限
		levelValidate : function($Page,$Gadget, $Fire, $UI) {
			debugger;
			OC.Callchain.setFireSearch($Page.pageId, "poLValjs");

			var businessFlag = "";
			if($Page.data && $Page.data.mnpPromFlag){
			    businessFlag = "TransSubsPreReward";
			}
			if($Page.ivrServNumber && "" != $Page.ivrServNumber){
				 businessFlag = "IVR_ORDER_CREATE";
			}
			dontTouchDataOfWholePage();
			$Fire(
					{
						'service' : 'bes.agentdesktop.promotionservice/doauthentication',
						'params' : {
							"offeringid" :$Page.params.offeringId,
							"levelid" : $Page.params.levelId,
							"promvalidatereq" : $Page.params.promValidateReq,
							"businessFlag": businessFlag
						},
						'target' : '$Gadget.promotionInfo',
						'onafter' : function($Gadget, $UI) {
							debugger;
							if (!$Gadget.promotionInfo.auth) {
	                            // 关闭大菊花结束
	                            youCanTouchDataOfWholePage();
								if($Gadget.promotionInfo.retCode == '60108031014'){
									$Page.promofferList = $Gadget.promotionInfo.returnOffering;
									$Gadget.$Get("$Fire")({
							            "popup":{'id':'promselectdiag',
							            		'title' : '营销案重叠校验',
							            		'width' : '650px',
							            		'height' : '300px',
							            		'src':'{{$Webapp}}/bes/ad/person/marketplan/bes-ad-mp-promselectdiag/bes-ad-mp-promselectdiag.uslx'}
							         },$Gadget);
									 $Gadget.promotionInfo.auth = true;
								}
								else{
									$UI.msgbox.info($UEE.i18n("ad.person.label.information"),$Gadget.promotionInfo.retMessage);
								}
							} else {
								if($Gadget.promotionInfo.retMessage){
									youCanTouchDataOfWholePage();
							     	$UI.msgbox.warning($UEE.i18n("ad.person.label.information"), $Gadget.promotionInfo.retMessage, function(){
							     		$Controller.bes.oc.productorder.promotionHandler($Page, $Gadget, $Fire, $UI);
							     	});
							     }else{
								 $Controller.bes.oc.productorder.promotionHandler($Page, $Gadget, $Fire, $UI);
								 }
							}
						},
                        'onerror' : function() {
                            debugger;
                            // 关闭大菊花结束
                            youCanTouchDataOfWholePage();
                        }
					}, $Gadget);
		},

		promotionHandler : function($Page, $Gadget, $Fire, $UI){
		    debugger;
		    $Page.params.promValidateReq = {};
		    $Controller.bes.oc.productorder.checkIsExistSameOrderForIVR($Gadget,$UI);
			/*
             * if($Gadget.promotionInfo.retMessage && $Gadget.promotionInfo.retMessage != "") {
             * $UI.msgbox.info("提示",$Gadget.promotionInfo.retMessage); }
             */
	   		 $Page.useNewUI = "N";
			 $Controller.bes.oc.productorder.popupPromotionPage($Page, $Gadget, $Fire, $UI);
			// 查询PM属性，判断走新老界面
			// 首先判断OC系统参数，看是否全部走新界面
//			var sysParamId = "OC_PROM_NEW_UI";
//			$Fire({
//			     service : 'ucec/v1/common/qrysystemparambykey',
//			     params : {
//			    	 key : sysParamId
//			     },
//			     target : "$Page.allUseNewUI",
//			     onafter : function(){
//			    	 debugger;
//			    	 if($Page.allUseNewUI == "Y")
//			         {
//			    		 $Page.useNewUI = "Y";
//
//			    		 $Controller.bes.oc.productorder.popupPromotionPage($Page, $Gadget, $Fire, $UI);
//			         }
//			    	 else
//			    	 {
//			    		 // 若不是全部使用新UI，需查询PM参数判断走新老界面
//			    		 $Fire({
//						     service : 'ucec/v1/offering/offeringattributes_query',
//						     params : {
//						    	 "body":{
//						    		 "offeringId":$Page.params.offeringId
//						    		 }
//						     },
//						     target : "$Page.promotionDetailInfo",
//						     onafter : function(){
//						    	 debugger;
//						    	 // 将PM配置的参数赋给前台
//						    	 var attrList = (($Page.promotionDetailInfo||{}).body||{}).attributeGroups || [];
//
//						    	 var pmParam = null;
//						    	 $.each(attrList, function(i, val){
//										$.each(val.attributes || [],function(k, valk){
//											if (valk.attrCode == "PM_PROM_NEW_UI")
//											{
//												pmParam = valk.newValue;
//												return;
//											}
//										});
//									});
//
//						    	 // 脚本刷上的活动，判断classificationId
//						    	 if(null == pmParam)
//						    	 {
//						    		 // classificationId 为 20000,表示为普通活动;否则为商品化活动
//						    		 $Page.classificationId == "20000" ? $Page.useNewUI = "N" : $Page.useNewUI = "Y";
//						    	 }
//						    	 else
//						    	 {
//						    		 $Page.useNewUI = pmParam;
//						    	 }
//
//						    	 $Controller.bes.oc.productorder.popupPromotionPage($Page, $Gadget, $Fire, $UI);
//
//						     },
//		                     'onerror' : function() {
//		                         debugger;
//		                         // 关闭大菊花结束
//		                         youCanTouchDataOfWholePage();
//		                     }
//			    		 },$Gadget);
//			    	 }
//	             },
//                 'onerror' : function() {
//                     debugger;
//                     // 关闭大菊花结束
//                     youCanTouchDataOfWholePage();
//                 }
//			 }, $Gadget);
		},

        batchSPBusinessAction: function($Page, $Gadget, $Fire, $Item, $UI, $index) {
            debugger;

            var $offeringId = $Gadget.data.productsearchoffering.offeringList[$index].offeringId;
            $Gadget.$Target = {};
            $Gadget.$Target.data = {};
            this.bookProd($Page, $Gadget, $Fire, $offeringId, $Gadget.$Target);


        },

        bookProd : function($Page, $Gadget, $Fire, $offeringId, $Target) {
				debugger;
                // 判断是否正在订购
				if ($Target.data.isBooking) {
					return;
				}

				// 设置订购中的状态
				$Target.data.isBooking = true;

				var needAddFlag = true;
				$.each($Page.selectedAddiProd || [], function(i, val) {
                    debugger;
					if (val.offerId == $offeringId) {
						needAddFlag = false;
						return false;
					}
				});

				if (!needAddFlag) {
                    return;
                }

				OC.Callchain.setFireSearch($Page.pageId, "QODetail");
                $Fire(
                        {
                            service : 'bes.oc.queryofferdetailservice/queryofferdetail',
                            params : {
                                "offerid" : $offeringId,
                                "condition" : {'searchBundleOffer':'N'}
                            },
                            target : '$Gadget.data.offerInfoPOJO',
                            onafter : function($Page) {
                                debugger;
                                if ($Gadget.data.offerInfoPOJO) {
                                	// 批量SP业务--- "1" : 批量订购； "2" : 批量取消
                                	if ($Page.batchAction == "1") {
                                		delete $Gadget.data.offerInfoPOJO.ocExpireMode;
                                	} else if ($Page.batchAction == "2") {
                                		delete $Gadget.data.offerInfoPOJO.ocEffectiveMode;
                                	}

                                	if ($Page.isBatchSpBusiness) {
                                		$Controller.bes.oc.productorder.setOfferEffExpModeInfo($Gadget.data.offerInfoPOJO, "ALL");
									} else {
										$Controller.bes.oc.productorder.setOfferEffExpModeInfo($Gadget.data.offerInfoPOJO);
									}

                                    $Gadget.data.offerInfoPOJO.ocEffectiveMode = $Gadget.data.offerInfoPOJO.ocEffectiveMode || {};
                                    $Gadget.data.offerInfoPOJO.ocExpireMode = $Gadget.data.offerInfoPOJO.ocExpireMode || {};
                                    $Gadget.data.offerInfoPOJO.ocEffectiveMode.effModeDisabled = $Gadget.data.offerInfoPOJO.ocEffectiveMode.effModeDisabled || false;
                                    $Gadget.data.offerInfoPOJO.ocExpireMode.expireModeDisabled = $Gadget.data.offerInfoPOJO.ocExpireMode.expireModeDisabled || false;

                                    $Gadget.data.offerInfoPOJO.ocExpireMode = $Gadget.data.offerInfoPOJO.ocExpireMode || {};
                                    // adutil.setOfferEffExpModeDisplay($Gadget.data.offerInfoPOJO);

                                    // 批量SP业务--- "1" : 批量订购； "2" : 批量取消
                                	if ($Page.batchAction == "1") {
                                		$Controller.bes.oc.productorder.setOfferEffectiveModeDisplay($Gadget.data.offerInfoPOJO);
                                	} else if ($Page.batchAction == "2") {
                                		$Controller.bes.oc.productorder.setOfferExpireModeDisplay($Gadget.data.offerInfoPOJO);
                                	}

                                    // 如果是家庭网则产品互斥
                                    var selectedAddiProd = $Page.selectedAddiProd;
                                    // 克隆数组
                                    var cloneSelectedAddiProd = $.extend(true,[],selectedAddiProd);
                                    var offerInfoPOJO = $Gadget.data.offerInfoPOJO;

                                    cloneSelectedAddiProd.push(offerInfoPOJO);
                                    $Page.selectedAddiProd = cloneSelectedAddiProd;
                                    $Controller.bes.oc.productorder.sendData2AddiProd($Gadget, $Page.selectedAddiProd);
                                } else {
                                    // 如果返回为空则取消订购中的状态
                                    $Target.data.isBooking = false;

                                    $UI = $Gadget.$Get('$UI');
                                    $UI.msgbox.info($UEE.i18n("ad.person.label.information"), "无法查询此商品详情，请稍后重试。");
                                }
                            }
                        }, $Gadget);

        },

    	// 设置Offer的生失效方式信息
    	setOfferEffExpModeInfo: function(offer, primaryOfferingId, businessCode){
    		debugger;
    		// 用户可选的生效模式过滤（公共函数（ businessCode， primaryOfferingId ） ）
    		// a) businessCode， primaryOfferingId 都有
    		// 1.用businessCode和primaryOfferingId 同时去做过滤，如果能过滤到数据，则认为找到生效模式
    		// 2.如果1找不到，用ALL，primaryOfferingId去做过滤，如果能过滤到数据，则认为找到生效模式
    		// 3.如果2找不到，用businessCode，ALL去做过滤，如果能过滤到数据，则认为找到生效模式
    		// 4.如果3找不到，则用ALL，ALL去做过滤，找到生效模式
    		// 5.如果4找不到，则认为没有可选的生效模式
    		// b) 只有businessCode
    		// businessCode，ALL
    		// c) 只有primaryOfferingId
    		// ALL，primaryOfferingId
    		// d) businessCode， primaryOfferingId 都没有
    		// ALL，ALL
    		// 用户可选的生效模式，只过滤出I，N，C。S，F不给展示和选择，通常情况下如果有S和F，只会配置一条。

    		// 生效模式
    		if (offer.ocEffectiveMode){
    			var effectiveTypes = [];
    			$.each(offer.ocEffectiveMode.effectiveTypes || [], function(i, val){
    				if (val.businessCode == businessCode && val.primaryOfferingId == primaryOfferingId) {
    					effectiveTypes.push(val);
    				}
    			});

    			if (effectiveTypes.length == 0) {
    				$.each(offer.ocEffectiveMode.effectiveTypes || [], function(i, val) {
    					if (val.businessCode == "ALL" && val.primaryOfferingId == primaryOfferingId) {
    						effectiveTypes.push(val);
    					}
    				});
    			}
    			if (effectiveTypes.length == 0) {
    				$.each(offer.ocEffectiveMode.effectiveTypes || [], function(i, val) {
    					if (val.businessCode == businessCode && val.primaryOfferingId == "ALL") {
    						effectiveTypes.push(val);
    					}
    				});
    			}
    			if (effectiveTypes.length == 0) {
    				$.each(offer.ocEffectiveMode.effectiveTypes || [], function(i, val) {
    					if (val.businessCode == "ALL" && val.primaryOfferingId == "ALL") {
    						effectiveTypes.push(val);
    					}
    				});
    			}

    			offer.ocEffectiveMode.effectiveTypes = effectiveTypes;
    			$.each(offer.ocEffectiveMode.effectiveTypes||[], function(j, valj){
    				if (valj.selected){
    					offer.ocEffectiveMode.selectedMode = valj.key;
    				}
    			});
    			offer.ocEffectiveMode.effectiveDate = offer.ocEffectiveMode.effectiveDate || new Date().getTime();
    		}

    		// 失效方式
    		if (offer.ocExpireMode) {
    			var expireTypes = [];
    			$.each(offer.ocExpireMode.expireTypes || [], function(i, val){
    				if (val.businessCode == businessCode ) {
    					expireTypes.push(val);
    				}
    			});

    			if (expireTypes.length == 0) {
    				$.each(offer.ocExpireMode.expireTypes || [], function(i, val) {
    					if (val.businessCode == "ALL" || !val.businessCode ) {
    						expireTypes.push(val);
    					}
    				});
    			}
    			offer.ocExpireMode.expireTypes = expireTypes;
    			$.each(offer.ocExpireMode.expireTypes||[], function(j, valj){
    				if (valj.selected){
    					offer.ocExpireMode.selectedMode = valj.key;
    				}
    			});
    			offer.ocExpireMode.expireDate = offer.ocExpireMode.expireDate || new Date().getTime();
    		}

    		if (offer.isbindOffer == "Y") {
    			$.each(offer.ocOfferInfoVA || [], function(i, vali){
    				adutil.setOfferEffExpModeInfo(vali, primaryOfferingId, businessCode);
    			});
    		}
    	},

    	/**
         * 失效模式
         *
         * @param offer
         */
    	setOfferExpireModeDisplay: function (offer) {
            debugger;
            var expireModeData = [];
            offer.expireModeDetail = offer.ocExpireMode.expireTypes;
            if (!offer.expireModeDetail) {
            	return;
            }

            var len = offer.expireModeDetail.length;
            for(var i = 0; i < len; i++) {
            	 var val = offer.expireModeDetail[i];
            	 if (val.key == 'I') {
                     expireModeData.push({
                         key: val.key,
                         value: "立即失效"
                     });
                 }
                 if (val.key == 'N') {
                     expireModeData.push({
                         key: val.key,
                         value: "次月失效"
                     });
                 }
                 if (val.key == 'C') {
                     expireModeData.push({
                         key: val.key,
                         value: "选择日期"
                     });
                 }
            }

            offer.selectedEffExpDetail = offer.selectedEffExpDetail || {};
            offer.selectedEffExpDetail.selectedExpMode = offer.selectedEffExpDetail.selectedExpMode || "I";
            offer.selectedEffExpDetail.expModeDisabled = offer.selectedEffExpDetail.expModeDisabled || false;

            // 失效模式的默认方式取值逻辑修改 20150808----- by 00283015
            $.each(offer.expireModeDetail || [], function (k, valk) {
                if (valk.selected) {
                    offer.selectedEffExpDetail.selectedExpMode = valk.key;
                }
            });

            offer.expTypeHash = {
                data: expireModeData,
                selectedKey: offer.selectedEffExpDetail.selectedExpMode,
                disabled: offer.selectedEffExpDetail.expModeDisabled,
                onValueChange: function (self) {
                    debugger;
                    $.each(offer.expireModeDetail || [], function (m, valm) {
                        if (valm.key == self.$input.attr("key")) {
                            offer.selectedEffExpDetail.expireXmlString = JSON.stringify(valm);
                        }
                    });
                    var $scope = $(document).scope();
                    $scope.$safeApply($scope, function () {
                        offer.selectedEffExpDetail.selectedExpMode = self.$input.attr("key");
                        if (self.$input.attr("key") == "C") {
                            offer.showExpDateFlag = true;
                        } else {
                            offer.showExpDateFlag = false;
                        }
                    });
                }
            };

            offer.selectedEffExpDetail.expireDate = offer.selectedEffExpDetail.expireDate || new Date().getTime();
            offer.expDateHash = {
                options: {
                    dateFormat: "YYYY-MM-DD"
                },
                onChanged: function () {
                        debugger;
                        var expireDate = new Date(new Date(this.getValue().replace(/-/g, "/")).getTime() + (3600 * 24 - 1) * 1000).getTime();
                        if (expireDate < new Date().getTime()) {
                            $(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.label.information"), "失效日期不能小于当前日期。");
                            this.setValue(new Date().Format("yyyy-MM-dd"));
                        } else {
                            offer.selectedEffExpDetail.expireDate = new Date(this.getValue().replace(/-/g, "/")).getTime();
                        }
                    },
                    defaultValue: new Date(offer.selectedEffExpDetail.expireDate).Format("yyyy-MM-dd")
            };
        },

        /**
         * 生效模式
         *
         * @param offer
         */
        setOfferEffectiveModeDisplay: function (offer) {
        	debugger;
            var effectModeData = [];
            offer.effectModeDetail = offer.ocEffectiveMode.effectiveTypes;
            if (!offer.effectModeDetail) {
            	return;
            }

            $.each(offer.effectModeDetail, function (i, val) {
                if (val.key == 'I') {
                    effectModeData.push({
                        key: val.key,
                        value: "立即生效"
                    });
                }
                if (val.key == 'N') {
                    effectModeData.push({
                        key: val.key,
                        value: "次月生效"
                    });
                }
                if (val.key == 'C') {
                    effectModeData.push({
                        key: val.key,
                        value: "选择日期"
                    });
                }
            });

            offer.selectedEffExpDetail = offer.selectedEffExpDetail || {};
            offer.selectedEffExpDetail.selectedEffMode = offer.selectedEffExpDetail.selectedEffMode || "I";
            offer.selectedEffExpDetail.effModeDisabled = offer.selectedEffExpDetail.effModeDisabled || false;
            // 生效模式的默认方式取值逻辑修改 20150808----- by 00283015
            $.each(offer.effectModeDetail || [], function (k, valk) {
                if (valk.selected) {
                    offer.selectedEffExpDetail.selectedEffMode = valk.key;
                }
            });
            offer.effTypeHash = {
                data: effectModeData,
                selectedKey: offer.selectedEffExpDetail.selectedEffMode,
                disabled: offer.selectedEffExpDetail.effModeDisabled,
                onValueChange: function (self) {
                    debugger;
                    $.each(offer.effectModeDetail || [], function (m, valm) {
                        if (valm.key == self.$input.attr("key")) {
                            offer.selectedEffExpDetail.effectiveXmlString = JSON.stringify(valm);
                        }
                    });
                    var $scope = $(document).scope();
                    $scope.$safeApply($scope, function () {
                        offer.selectedEffExpDetail.selectedEffMode = self.$input.attr("key");
                        if (self.$input.attr("key") == "C") {
                            offer.showEffDateFlag = true;
                        } else {
                            offer.showEffDateFlag = false;
                        }
                    });
                }
            };

            offer.selectedEffExpDetail.effectiveDate = offer.selectedEffExpDetail.effectiveDate || new Date().getTime();
            offer.effDateHash = {
                options: {
                    dateFormat: "YYYY-MM-DD"
                },
                onChanged: function () {
                        debugger;
                        var effectiveDate = new Date(new Date(this.getValue().replace(/-/g, "/")).getTime() + (3600 * 24 - 1) * 1000).getTime();
                        if (effectiveDate < new Date().getTime()) {
                            $(document).scope().$UI.msgbox.info($UEE.i18n("ad.person.label.information"), "生效日期不能小于当前日期。");
                            this.setValue(new Date().Format("yyyy-MM-dd"));
                        } else {
                            offer.selectedEffExpDetail.effectiveDate = new Date(this.getValue().replace(/-/g, "/")).getTime();
                        }
                    },
                    defaultValue: new Date(offer.selectedEffExpDetail.effectiveDate).Format("yyyy-MM-dd")
            };
        },

        sendData2AddiProd: function($Gadget, $data)
        {
            $Gadget.$Emit('$bes.oc.addiProdSelected', $data);
        },

		purchasenow: function($Page, $Gadget, $Fire, $Item, $UI, $index) {
			debugger;
			if($Item.offerStatus == "LEVELINFO"){

				$Page.classificationId = $Item.classificationId || "";
				// 营销准入校验
				var promValidateReq = $Controller.bes.oc.productorder.generatePromValidateReq();
				// 添加批次ID、档次ID、商品订购MODE
				$Page.params={
						"offeringId":$Item.offeringCode,
						"levelId": $Item.offeringId,
						"levelName":$Item.offeringName,
						"mode":"ChangeProduct",
						"promValidateReq":promValidateReq,
						"promType":($Item.attributeMap||{})["PM_PROM_TYPE"]||""
				};

				// 添加档次信息(用于判断跳转)
				$Gadget.$Promotion={levelBaseInfo : {offeringId : $Item.offeringId}};

				var Item = {offeringId : $Item.offeringCode,
							offerClassCode : "PROM_"};

				// 添加购物车信息
				this.addtocar($Page, $Gadget, $Fire, Item, $UI, 0);
				return;
			}


			$Gadget.callfrom = "purchasenow";
			$Gadget.$Item = $Item;

			if ($Page.isClickBtn) {
				return;
			}
			$Page.isClickBtn = true;

			$Controller.bes.oc.productorder.queryofferinginfo($Page,
				$Gadget, $Fire, $UI, $index);

		},

		// 未登录用户
		queryControlTypes: function($Page, $Gadget, $Fire, $UI,
			ocProductInfo) {
			OC.Callchain.setFireSearch($Page.pageId, "poQCT0js");
			$Fire({
				'service': 'bes.oc.ocpcclassificatioinqueryservice/querycontroltypes',
				'params': {
					'classificationid': $Gadget.$Item.classificationId
				},
				'target': '$Gadget.data.controlSetting',
				'onafter': function($Page, $Gadget, $Fire, $UI) {
					debugger;
					var isControl = false;
					$.each($Gadget.data.controlSetting || [],
						function(i, value) {
							if (value.controlType == 'ANO') {
								isControl = true;
								return;
							}
						});
					if (isControl) {

					} else {
						$Page.isOperatTab = null;
						// 登陆逻辑
						/*
                         * $UI.msgbox.warning("提示", "此商品需要登录才能购买,确认登录？", function() { //增加业务类型 $Page.businessCode =
                         * 'ChangeProduct'; window._ysp_top.businessCode = 'ChangeProduct';
                         *
                         * $("#recommend").hide(); $("#shoppingcar").hide(); $("#productordermainImpl") .hide();
                         * $("#orderauthentication") .show(); $Page.isOperatTab = '1'; }, function() { $Page.isClickBtn =
                         * false; });
                         */

						// 增加业务类型
						$Page.businessCode = 'ChangeProduct';
						window._ysp_top.businessCode = 'ChangeProduct';

						$Page.isClickBtn = false;
						$Page.isOperatTab = '1';

						if(_ysp_top.TabSet){
							var currMenuId = _ysp_top.TabSet.getTabItem().key
						}
						$Gadget.$Get('$Fire')({popup:{'id':'productorderloginpopup','title' : $UEE.i18n('ad.unsubscribe.label.loginpopup'),'width' : '550px','height' :'410px',
							'src':'resource.root/bes/ad/popup/bes-ad-productorderlogin.html?tabid='+currMenuId,resizable:false}},$Gadget);
					}
				}
			}, $Gadget);
		},
			// 黑名单校验
// isBlackChecklist:function($Gadget,$Fire,$UI, confirmCallBack){
// debugger;
// $Page = angular.element(document).scope().$Page;
// OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
// $Fire({
// service : "bes.oc.doublenumberservice/querycustomerinfobycontext",
// params : {},
// target : "$Gadget.data.certificatetype",
// onafter: function() {
// debugger;
// var custId = ((($Gadget.data.certificatetype || {}).CustomerExVO || [])[0] || {}).custId;
// if (custId) {
// var req = {};
// req.vaildateBaseInfo={
// seniorId: "CHANGE_OFFER",
// eventId: "OFFER_CHG_COMM_FORBID",
// busiCode: "ChangeProduct"
// };
// req.order ={
// businessCode : "ChangeProduct",
// partyRoleId: custId,
// partyRoleType: "C"
// };
// var warningCallBack = function(){
// };
//
// var errorCallBack = function(){
// };
//
// OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
// $Fire({
// service: 'bes.oc.ocorderservice/busivalidate',
// params : {
// "req" : req
// },
// target : '$Gadget.checkoutValidateResult',
// onafter : function() {
// debugger;
// if
// (adutil.checkBusiValidResp($Gadget,$UI,$Gadget.checkoutValidateResult.busiValidResp,warningCallBack,warningCallBack,errorCallBack)){
// confirmCallBack();
// }
// }
// }, $Gadget);
// } else {
// return true;
// }
// }
// }, $Gadget);
// },
		subloginSuccess: function($Gadget, $Fire, $Page, $UI) {
			debugger;
			// $("#shoppingcar").show();
			/*
             * $("#productordermainImpl").show(); $("#orderauthentication").hide();
             */
			$Fire({popin:""},$Gadget);
			if (($Page.data||{}).carofferingList) {
				$("#shoppingcar").show();
				$("#recommend").hide();
			} else {
				$("#shoppingcar").hide();
				$("#recommend").show();
			}

			var internal = setInterval(
					function() {
						debugger;

						if (_ysp_top.window.tab && _ysp_top.window.tab.findLiExist("60131006")) {
							if(_ysp_top.window.tab.findLiExist("60131201610226001")) {
									_ysp_top.window.$BES.$Portal.tabpanel.showTabItem("60131201610226001");
									_ysp_top.window.$BES.$Portal.tabpanel.closeTabItem("60131006");
							}
							_ysp_top.window.$BES.$Portal.tabpanel.showTabItem("60131004");
							clearInterval(internal);
						}
					}, 100);

			// var confirmCallBack = function(){
			// 登录成功之后查看用户当前主套餐 如果有两个主套餐的话 则在当前页面选择在哪个套餐下办理
			OC.Callchain.setFireSearch($Page.pageId, "poQSO0js");
			$Fire({
		    	service:"ucec/v1/offering/querysubscribedoffering",
		    	target:"$Gadget.queryMainOfferResp",
		    	onafter:function(){
		    		debugger;
		    		if($Gadget.queryMainOfferResp && $Gadget.queryMainOfferResp.body && ($Gadget.queryMainOfferResp.body.offerings||[]).length>0){
		    			$Page.mainOfferingList = $Gadget.queryMainOfferResp.body.offerings;
		    			$Gadget.offeringListHash = [];

		    			if(($Page.mainOfferingList||[]).length == 2){

		    				$.each($Page.mainOfferingList,function(i,val){
			    				var obj = {};
			    				obj.key = val.offeringId;

			    				if(val.status == '2'){
			    					obj.value ="当前主套餐:"+"<b style='padding-left: 10px;color: #333;  font-weight: normal;'>"+val.offeringName+"</b>";
			    					$Gadget.offeringListHash[0] = obj;
			    				}
			    				else {
			    					obj.value ="即将生效主套餐:"+"<b style='padding-left: 10px;color: #333;  font-weight: normal;'>"+val.offeringName+"</b>";
			    					$Gadget.offeringListHash[1] = obj;
			    				}
			    			});

		    				var templist = [];
		    				if($Page.mainOfferingList[0].status == '2'){
		    					templist = $Page.mainOfferingList;
		    				}else{
		    					templist[0] =  $Page.mainOfferingList[1];
		    					templist[1] =  $Page.mainOfferingList[0];
		    				}
		    				$Page.mainOfferingList = templist;
		    			}
		    			else if(($Page.mainOfferingList||[]).length == 1){
		    				var obj = {};
		    				obj.key = $Page.mainOfferingList[0].offeringId;
		    				obj.value ="当前主套餐:"+"<b style='padding-left: 10px;color: #333;'>"+$Page.mainOfferingList[0].offeringName+"</b>";
	    					$Gadget.offeringListHash[0] = obj;
		    			}
		    			// 设置初始值
	    				$Page.selectedMainOfferingId = $Page.mainOfferingList[0].offeringId;
	    				$Page.selectedMainOfferingInstId = $Page.mainOfferingList[0].offeringInstId;
		    		}

		    		if($Gadget.offeringListHash
		    				&&$Gadget.offeringListHash.length == 1){
		    			// $Gadget.issublogin = true;
		    			// 判断登陆状态
		    			OC.Callchain.setFireSearch($Page.pageId, "poIsSLjs");
		    			$Fire({
		    				'service': 'bes.oc.subscribeinfoservice/issubscribelogin',
		    				'params': {},
		    				'target': '$Page.subscriber',
		    				'onafter': function($Page, $Gadget, $Fire, $UI) {
		    					debugger;
		    					$Gadget.busiValid = false;
		    					$Gadget.issublogin = $Page.subscriber.loginStatus;
		    					if ($Gadget.issublogin) {
		    						$Page.serviceNumber = $Page.subscriber.subscriberInfo.serviceNumber;
		    						//DTS2017030610944, 商品订购菜单里，用户鉴权成功后把服务号码放到window._ysp_top.serviceNumber里
		    						window._ysp_top.serviceNumber = $Page.serviceNumber;
		    						// 商品快选触发的登陆
		    						if($Page.isFromQuickPick){
		    							debugger;
		    							$Controller.bes.oc.productValidate.promotionBundle($Page, $Gadget, $Fire, null, $UI)
		    						}
		    						// TODO:加入生效方式
		    						$Controller.bes.oc.productorder.beforeGetOfferingInfoDetail($Page, $Gadget, $Fire, $UI);
		    					}
		    				}

		    			}, $Gadget);
		    		}
		    		else {
		    			$UI.msgbox.warning($UEE.i18n("ad.person.label.information"), "请选择主套餐。");
		    		}
		    	}

		    },$Gadget);
				// }

				// $Controller.bes.oc.productorder.isBlackChecklist($Gadget, $Fire, $UI, confirmCallBack);

		},

		removeshoppingcatitem: function($Gadget, $Event) {
			debugger;
			$("#recommend").show();
			$("#shoppingcar").hide();
		},


		showStep1: function($Page, $Gadget) {
			// $("#recommend").show();
			if (($Page.data||{}).carofferingList) {
				$("#shoppingcar").show();
				$("#recommend").hide();
			} else {
				$("#shoppingcar").hide();
				$("#recommend").show();
			}
			// 返回之前的页面删除该样式
			// 删除结算页面样式
			 var linkFileTemp = $("link") || [];
		     var linkFileLen = linkFileTemp.length;
		     for(var i=0; i < linkFileLen; i++)
		     {
		      if(linkFileTemp.eq(i).attr("href") && linkFileTemp.eq(i).attr("href").indexOf("bes/ad/css/base.css") > 0)
		      {
		       linkFileTemp.eq(i).remove();
		      }
		     }

			$("#productordermainImpl")
				.show();
			$("#paymentContent").hide();
			$Gadget.gocheckout = false;

		},

		//360视图
		addMixOfferInfoToCar: function($Page, $Gadget, $Fire, data, $UI) {
			debugger;
			if(!$Gadget.$Item){
				$Gadget.$Item = {};
			}
			$Gadget.$Item.offeringId = data.offeringId;
			$Controller.bes.oc.productorder.addtocar($Page, $Gadget, $Fire,
				data, $UI);
		},

		addMWToCar: function($Page, $Gadget, $Fire, data, $UI) {
			debugger;
			if(!$Gadget.$Item){
				$Gadget.$Item = {};
			}
			$Gadget.$Item.offeringId = data.offeringId;
			$Controller.bes.oc.productorder.addtocar($Page, $Gadget, $Fire,
				data, $UI);
		},
		offeringNameClick: function($Page, $Gadget, $Fire, $Item, $UI,
			$index) {
			debugger;
			if($Item.disableFlag)
			{
				return;
			}
			//用于判断在商品详情弹出框是否显示订购和取消按钮，营销活动的不显示
			$Gadget.isShowConfirmCancelBtn = true;
			if($Item.offerClassCode && ($Item.offerClassCode.indexOf("PROM_") == 0)){
			    $Gadget.isShowConfirmCancelBtn = false;
			}
			else{
			    var offeringListLength = $Gadget.data.productsearchoffering.offeringList.length;
			    for(var i = 0;i < offeringListLength;i++){
			        var currentOffering = $Gadget.data.productsearchoffering.offeringList[i];
			        //营销活动
			        if(currentOffering.offerClassCode && (currentOffering.offerClassCode.indexOf("PROM_") == 0)){
			            //档次列表
			            var promotionList = currentOffering.PromotionList;
			            if(promotionList){
			                for(var j = 0;j<promotionList.length;j++){
			                    var currentPromotion = promotionList[j];
			                    if(currentPromotion.levelBaseInfo && (currentPromotion.levelBaseInfo.offeringId == $Item.offeringId)){
			                        $Gadget.isShowConfirmCancelBtn = false;
			                    }
			                }
			            }
			        }
			    }
			}

			var shoppingCarClose = $("#staticshoppingcar_close");
			if(shoppingCarClose.length == 0){
				shoppingCarClose = _ysp_top.$("#staticshoppingcar_close");
			}
			shoppingCarClose.click();
			$Page.data = $Page.data || {};
			$Page.data.offeringId = $Item.offeringId;

			$Page.data.classificationId = $Item.classificationId || "";

			$Page.data.offeringInfo = {};
			$Page.promOfferingInfoForRemainAmount = {
				offerClassCode : $Item.offerClassCode || "",
				offerName : $Item.offeringShortName || "",
			};
			$Page.validateFunction = {};
			$Gadget.offeringNamePopup = {item:$Item,index:$index};
			$Gadget.isPopup = true;
			$Fire({popup:{'id':'productorderofferingdetailpopup','title' : $UEE.i18n("ad.person.title.OfferingDetails"),'width' : '750px','height' :'410px',
				'src':'resource.root/bes/ad/popup/bes-ad-productorderofferingdetail.html',resizable:false}},$Gadget);

		},
		namePopupConfrim:function($Page,$Gadget,$Fire,$UI){
			debugger;
			$Fire({popin:""},$Gadget);
			var $Item = $Gadget.offeringNamePopup.item;
			var $index =  $Gadget.offeringNamePopup.index;
			if($Item.purchaseBtn){
				$Controller.bes.oc.productorder.purchasenow($Page,$Gadget,$Fire,$Item,$UI,$index)
			}
			if($Item.addtocarBtn){
				$Controller.bes.oc.productorder.addtocar($Page,$Gadget,$Fire,$Item,$UI,$index)
			}
		},
		namePopupCancel:function($Page,$Gadget,$Fire,$UI){
			debugger;
			$Fire({popin:""},$Gadget);

		},
		checkActivityLevel: function($Page, $Gadget, $Fire, $Item, $Index,
			$UI) {
			debugger;
			$Item.pcHitChildOfferingList = null;
			$Gadget.data.index = $Index;
			if ($("#productactivity" + $Item.offeringId).hasClass("bt-DownIcon")) {
				$("#productactivity" + $Item.offeringId).removeClass("bt-DownIcon");
				$("#productactivity" + $Item.offeringId).addClass("bt-UpIcon");
				$Item.showLevelInfoButton = $UEE.i18n("ad.person.button.Level");//"档次";
				$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].showLevel = true;

			} else {
				$("#productactivity" + $Item.offeringId).removeClass("bt-UpIcon");
				$("#productactivity" + $Item.offeringId).addClass("bt-DownIcon");
				$Item.showLevelInfoButton = $UEE.i18n("ad.person.button.Level");//"档次";
				$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].showLevel = false;
				$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].noLevelInfo = false;
				return;
			}
			if (null != $Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].PromotionList && "Y" != $Gadget.promStarFlag) {
				return;
			}

			OC.Callchain.setFireSearch($Page.pageId, "poCAL0js");
			$Fire({
				service: 'bes.agentdesktop.promotionservice/querylevelbaseinfobyofferingid',
				params: {
					"offeringid": $Item.offeringId,
					"searchOfferingCond":$Gadget.data.levelQryCondition
				},
				target: '$Gadget.data.PromotionList',
				onafter: function($Page, $Gadget, $UI) {
					debugger;
					if (null == $Gadget.data.PromotionList) {
						if("Y" == $Gadget.promStarFlag){
							$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].PromotionList = [];
						}
						/* $UI.msgbox.warning("提示", "该活动没有档次信息。"); */
						$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].noLevelInfo = true;
						return;
					}
					var promotionList = $.extend(true, [],
						$Gadget.data.PromotionList);

					//排序US-20170906181553-2031034600商品展现顺序优化
					promotionList = $Controller.bes.oc.productorder.sortsearchofferinglist(promotionList);

					$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].showLevel = true;
					$Gadget.data.productsearchoffering.offeringList[$Gadget.data.index].PromotionList = promotionList;
				}
			}, $Gadget);
		},
		checkLevelDetail: function($Page,$Item, $Promotion,$Gadget,$Fire,$UI,$index) {

			// 之前的业务
			debugger;

			$Page.classificationId = $Item.classificationId || "";

			if($Gadget.isBatchRewardActivity){
				$Page.selectedAddiProd = [];
				$Promotion.levelBaseInfo=$Promotion.levelBaseInfo || {offeringId:$Promotion.childOfferingId,offeringName:$Promotion.childOfferingName};
				$Promotion.offerId = $Item.offeringId
				+ ""
				+ $Promotion.levelBaseInfo.offeringId;

				$Promotion.offerName = $Promotion.levelBaseInfo.offeringName
						+ "(" + $Item.offeringName + ")";
				// 去掉高亮显示
				$Promotion.offerName = $Promotion.offerName.replace(new RegExp("<em>", 'gm'),'');
				$Promotion.offerName = $Promotion.offerName.replace(new RegExp("</em>", 'gm'),'');
				$Promotion.offerClassCode ="PROM_TYPE";
				// 档次所属活动名称
				$Promotion.offeringName = $Item.offeringName;
				// 档次所属活动ID
				$Promotion.offeringId = $Item.offeringId;
				$Promotion.includeLevel = true;
				$Promotion.attributeMap = $Item.attributeMap;

				$Page.selectedAddiProd.push($Promotion);
	            $Controller.bes.oc.productorder.sendData2AddiProd($Gadget, $Page.selectedAddiProd);
				return ;
			}


			// 营销准入校验
			var promValidateReq = $Controller.bes.oc.productorder.generatePromValidateReq();
			if(!$Promotion.levelBaseInfo){
				$Promotion.levelBaseInfo = {offeringId:$Promotion.childOfferingId,offeringName:$Promotion.childOfferingName}
			}
			// 添加批次ID、档次ID、商品订购MODE、活动类型
			$Page.params={
					"offeringId":$Item.offeringId,
					"levelId":$Promotion.levelBaseInfo.offeringId,
					"levelName":$Promotion.levelBaseInfo.offeringName,
					"mode":"ChangeProduct",
					"promotionType":($Item.attributeMap||{})["PM_PROM_SUB_TYPE"]||"",
					"promValidateReq":promValidateReq,
					"promType":($Item.attributeMap||{})["PM_PROM_TYPE"]|| $Item.offerSubType ||"",
					"couponOfferingInstId":$Promotion.levelBaseInfo.couponOfferingInstId
			};

			// 添加档次信息(用于判断跳转)
			$Gadget.$Promotion=$Promotion;

			// 添加购物车信息
			this.addtocar($Page, $Gadget, $Fire, $Item, $UI, $index);
		},
		// 组装营销准入校验订单节点
		generatePromValidateReq : function() {
			debugger;
			var $Page = $(document).scope().$Page;
			var tempList = $.extend(true,[],($Page.data||{}).carofferingList);
			// 不是客服系统接入 走购物车
			if(!$Page.isNewOpenFlag){
				$Page = window._ysp_top.shoppingcart.$Pagea || {};
				tempList = $.extend(true,[],window._ysp_top.shoppingcart.carofferingList);
			}
			this.gerateofferingList(tempList);

			// 家庭产品begin
			var index = null;
			var famOfferList = [];
			for(var i=0; i<(tempList||[]).length; i++)
			{
				if($(document).scope().isFamilyProd(tempList[i]))
				{
					var offerFamily = $.extend(true,{},tempList[i]);
					var famOffer = $Controller.bes.ad.shoppingcart.filterOfferings(offerFamily);
					famOfferList.push(famOffer);
					break;
				}
			}
			tempList = $.grep(tempList,function(val,i){
				return !$(document).scope().isFamilyProd(val);
			});
			// 家庭产品end

			// 营销活动begin
			$Page.promInfoList=$Page.promInfoList||[];

			// 保存营销方案列表
			for(var m=0;m<$Page.promInfoList.length;m++){

				for(var n=0; n<tempList.length; n++)
				{
					// 判断产品ID是否相同
					if($Controller.bes.oc.productorder.isSameOffer($Page.promInfoList[m], tempList[n])){

						// 删除营销方案
						tempList.splice(n,1);
						break;
					}
				}
			}
			// 营销活动end
			$Page.agentFlag = $Page.agentFlag || "";
			var validateReq = {businessType:$Page.agentFlag,offerings:tempList,familyOfferings:famOfferList,promotions:$Page.promInfoList};

			return validateReq;

		},
		checkIsFromProm:function($Page,$Gadget){
			debugger;
			if(!$Page.isChanged){
				var offeringid = adutil.getParam("offeringid");
				var levelid = adutil.getParam("levelid");
				var levelName = adutil.getParam("levelName");
				var rewardId = adutil.getParam("rewardId");
				var packageId = adutil.getParam("packageId");
				$Page.isChanged = true;
				if(offeringid && levelid){
				// 添加批次ID、档次ID、商品订购MODE
				$Page.params={
						"offeringId":offeringid,
						"levelId":levelid,
						"levelName":levelName,
						"mode":"ChangeProduct",
						"rewardId":rewardId,
						"packageId":packageId
				};
				$Fire = $Gadget.$Get("$Fire");
				$Fire({targetstep:'promotionsetting'});
				}
				return;
			}
		},
		checkShoppingItemList: function(data, list) {
			for (var i = 0; i < (list || []).length; i++) {
				if (data.offerId == list[i].offerId) {
					return false;
				}
			}
			return true;
		},

		// 切换显示模式 add by lwx207718
		turnDisplayMode : function ($Gadget, flag)
		{
			debugger;

			if ("CARD" == flag)
			{
				// 卡片显示模式
				$Gadget.layoutType = true;
			}
			else if ("LIST" == flag)
			{
				// 列表显示模式
				$Gadget.layoutType = false;
			}
			else
			{
				return;
			}
		},

		// 根据手机IMEI查询充值卡 add by Z00318723
		queryCardByIMEI : function ($Fire, $Gadget, $UI)
		{
			debugger;
			if($Gadget.hasQryCardByIMEI){
				return;
			}
			$("#pages").empty();

			$("#inputquerystring").val("");

			if (null == $Gadget.offerCondition
					|| "" == $.trim($Gadget.offerCondition))
			{
			    //请填写充值卡序号
				$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.entervochercardnumber"));
				return;
			}

			// 不为空查询(bug 修改)
			$Gadget.data.productsearchoffering.offeringList = [];
			$Gadget.hasQryCardByIMEI = true;
			$Fire
			({
				 	service : 'ucec/v1/goodssale/querycardsbyimei',
				 	params :
				 	{
				 		 header : {"loginToken":"","loginId":"","locale":"","serialId":""},
				 		 body : {"imei" : $Gadget.offerCondition}
				 	},
				 	target : '$Gadget.cardResult',
				 	onafter : function ($Gadget,$UI)
				 	{
				 		debugger;
				 		$Gadget.hasQryCardByIMEI =false;
				 		if (null == $Gadget.cardResult)
				 		{
				 			$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.searchWrong"));
				 			return;
				 		}
				 		else if (null != $Gadget.cardResult.header
				 				          && "0" != $Gadget.cardResult.header.resultCode)
				 		{
				 			$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.searchWrongReason") + $Gadget.cardResult.header.resultMessage);
				 			return;
				 		}
				 		else if (null != $Gadget.cardResult.body
				 				          && null != $Gadget.cardResult.body.offering
				 				          && $Gadget.cardResult.body.offering.length > 0)
				 		{
				 			var offeringList = $Gadget.cardResult.body.offering;
				 			for (var i = 0; i < offeringList.length; i++)
				 			{
				 				var offeringTemp = {};
				 				offeringTemp = offeringList[i];
				 				offeringTemp.attachmentUrl = offeringList[i].imgUrl;
				 				offeringTemp.purchaseBtn = true;
				 				offeringTemp.addtocarBtn = false;

				 				$Gadget.data.productsearchoffering.offeringList.push(offeringTemp);
				 			}
				 		}
				 		else
				 		{
				 			$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.searchisEmpty"));
				 			return;
				 		}

				 	},
				 	onerror: function($Gadget){
				 		$Gadget.hasQryCardByIMEI =false;
				 	}

			},$Gadget);
		},
		// 根据手机IMEI查询产品信息 add by lwx207718
		queryOfferByIMEI : function ($Fire, $Gadget, $UI)
		{
			debugger;
			if($Gadget.hasQryOfferByIMEI){
				return;
			}
			$("#pages").empty();

// $("#inputquerystring").val("");
			$Gadget.keyWord = "";

			if (null == $Gadget.offerCondition
					|| "" == $.trim($Gadget.offerCondition))
			{
				//请填写IMEI号
				$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.enteranimei"));
				return;
			}

			// 不为空查询(bug 修改)
			$Gadget.data.productsearchoffering.offeringList = [];

			$Page = angular.element(document).scope().$Page;
			$Gadget.hasQryOfferByIMEI = true;
			OC.Callchain.setFireSearch($Page.pageId, "QOByIMEI");
			$Fire
			({
				 	service : 'ucec/v1/seller/query_offerlistbyimei',
				 	params :
				 	{
				 		 header : {"loginToken":"","loginId":"","locale":"","serialId":""},
				 		 body : {"imei" : $Gadget.offerCondition}
				 	},
				 	target : '$Gadget.imeiResult',
				 	onafter : function ($Gadget,$UI)
				 	{
				 		debugger;
				 		$Gadget.hasQryOfferByIMEI = false;
				 		if (null == $Gadget.imeiResult)
				 		{
				 			$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.searchWrong"));
				 			//终端预约取货的场景下如果通过预约IMEI没查到数据，选择的预约信息置空
				 			$Gadget.selectedAppointmentInfo = null;
				 			return;
				 		}
				 		else if (null != $Gadget.imeiResult.header
				 				          && "0" != $Gadget.imeiResult.header.resultCode)
				 		{
				 			$UI.msgbox.error($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.searchWrongReason") + $Gadget.imeiResult.header.resultMessage);
				 			//终端预约取货的场景下如果通过预约IMEI没查到数据，选择的预约信息置空
				 			$Gadget.selectedAppointmentInfo = null;
				 			return;
				 		}
				 		else if (null != $Gadget.imeiResult.body
				 				          && null != $Gadget.imeiResult.body.offering
				 				          && $Gadget.imeiResult.body.offering.length > 0)
				 		{
				 			var offeringList = $Gadget.imeiResult.body.offering;
				 			for (var i = 0; i < offeringList.length; i++)
				 			{
				 				var offeringTemp = {};
				 				offeringTemp = offeringList[i];
				 				offeringTemp.attachmentUrl = offeringList[i].imgUrl;
				 				offeringTemp.purchaseBtn = true;
				 				offeringTemp.addtocarBtn = false;

				 				$Gadget.data.productsearchoffering.offeringList.push(offeringTemp);
				 			}
				 		}
				 		else
				 		{
				 			$UI.msgbox.info($UEE.i18n("ad.person.label.information"), $UEE.i18n("ad.marketplan.message.searchisEmpty"));
				 			//终端预约取货的场景下如果通过预约IMEI没查到数据，选择的预约信息置空
				 			$Gadget.selectedAppointmentInfo = null;
				 			return;
				 		}

				 	},
				 	onerror: function($Gadget){
				 		$Gadget.hasQryOfferByIMEI = false;
				 	}

			},$Gadget);
		},

		// 收藏或取消收藏
		mainTainFavorite : function($Gadget, offeringId, promotionOfferId, $Fire, favoriteType,
				$UI, $index) {
			debugger;
			$Gadget.params = {
				sceneCode : "SCENE_FAVORITE_GOODS_ORDER",
				offeringId : offeringId,
				// 如果收藏的为档次，则promotionOfferId为活动的offerID,如果不是档次，则与offeringid相同
				promotionOfferingId : promotionOfferId,
				maintainType : favoriteType
			};

			var realIndex = $index;
			if (favoriteType == 'UNFAVORITE') {
				$Gadget.params.relId = $Gadget.favoriteList.body.relIdList[realIndex];
			}

			OC.Callchain.setFireSearch($Page.pageId, "poMTF0js");
			$Fire({
				'service' : 'favoriteservice/maintainfavorite',
				'params' : {
					'body' : $Gadget.params
				},
				'target' : '$Gadget.favorite',
				'onafter' : function($Gadget) {
					debugger;
					if ($Gadget.favorite.body.retCode == 0) {
						if (favoriteType == 'FAVORITE') {
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.AddedSuccessfully"));
						} else {
							$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RemovedSuccessfully"));
							$Gadget.data.productsearchoffering.offeringList.splice($index,1);
							$Gadget.favoriteList.body.relIdList.splice(realIndex,1);
							//$Gadget.favoriteList.body.offerInfoList.splice(realIndex,1);

						}
					} else if ($Gadget.favorite.body.retCode == 1) {
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.OfferingHasAdded"));
					} else if ($Gadget.favorite.body.retCode == 2) {
						if (favoriteType == 'FAVORITE') {
							$UI.msgbox.error($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.AddedFailed"));
						} else {
							$UI.msgbox.error($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.RemovedFailed"));
						}
					}
				}

			}, $Gadget);
		},


		// 查询已收藏的活动
		queryFavoriteInfo : function($Gadget, $Fire, selectedPage, isClickSearch) {
			debugger;
			$Gadget.favoriteSelectedPage = selectedPage;
			$Gadget.data.productsearchoffering = {offeringList : []};
// var favoriteCond = $Gadget.data.searchOfferingCond;
// favoriteCond.extendCondition = $.extend(true, [], ($Gadget.data.levelQryCondition||{}).extendCondition);

			$Gadget.params = {
				sceneCode : "SCENE_FAVORITE_GOODS_ORDER",
				searchOfferingCond: $Gadget.data.searchOfferingCond,
				pageInfo:$Gadget.data.cpageInfo
				// 分页改为前台分页，每次固定查询出1000条数据
				// startNum : selectedPage * 6,
				// pageSize : 6
			};
			$Controller.bes.oc.productorder.queryFavoriteInfoByFire($Gadget, $Fire, selectedPage);
			/*
             * if(isClickSearch || $Gadget.favoriteList == undefined || $Gadget.favoriteList.body == undefined ){ //
             * 切换到收藏页面时进行查询 if (!$Gadget.isBatchSpBusiness ) {
             *  }
             *
             * }else{ var $Scope=$(document).scope(); $Scope.$safeApply($Scope,function(){
             * $Gadget.data.productsearchoffering ={offeringList : []}; if(selectedPage * 6 >=
             * $Gadget.favoriteList.body.offerInfoList.length){ selectedPage = selectedPage - 1; }
             *
             * for(var i = selectedPage * 6; i < $Gadget.favoriteList.body.offerInfoList.length; i ++){
             *
             * if(i >= selectedPage * 6 + 6){ break; }
             *
             * $Gadget.data.productsearchoffering.offeringList.push($Gadget.favoriteList.body.offerInfoList[i]); }
             * $Controller.bes.oc.productorder.convertOffering($Gadget);
             *
             * //高亮展示 $Controller.bes.oc.productorder.highlight($Gadget);
             *
             * $("#pages").empty(); $Gadget.data.pages = new UCD.Pages( $("#pages"),
             * $Gadget.favoriteList.body.offerInfoList.length, 6, [ 6, 12 ], 1);
             * $Gadget.data.pages.setSelection(selectedPage + 1); });
             *  }
             */


			$Gadget.data.isclickFavoritePageNum = false;
		},

		queryFavoriteInfoByFire : function($Gadget, $Fire, selectedPage) {
			$Gadget.data.clickSearchFlag = false;
			$Page = angular.element(document).scope().$Page;
			OC.Callchain.setFireSearch($Page.pageId, "QFBeFire");
			$Fire(
			{
				'service' : 'favoriteservice/queryfilterfavoritelist',
				'params' : {
					'body' : $Gadget.params
				},
				'target' : '$Gadget.favoriteList',
				'onafter' : function($Gadget) {
					debugger;
					//站内搜索埋点 add by p00354016
					var currentPage = $Gadget.params.pageInfo.beginRowNumber / $Gadget.params.pageInfo.recordPerPage + 1;
					var searchResult;

					if (!$Gadget.favoriteList|| !$Gadget.favoriteList.body
							|| !$Gadget.favoriteList.body.offerInfoList
							|| $Gadget.favoriteList.body.offerInfoList.length<=0) {
						searchResult = 0;
						currentPage = 0;
					}
					else {
						searchResult = 1;
					}
					var keyWord = $Gadget.params.searchOfferingCond.keyWord;
					if (keyWord!=undefined && keyWord !=null && keyWord != ""){
						$BuriedPoinStat.searchstat(keyWord, "product", searchResult, currentPage);
					}
					//站内搜索埋点 end

					$Gadget.data.productsearchoffering = {offeringList : []};

					if (adutil.getParam("orderPersonMark") == "orderPersonMark")
					{
						$.each($Gadget.data.searchattribute || [], function(i, val){
							$.each(val.options || [],function(k, valk){
								if (valk.VALUE == "rtPerson")
								{
									$("#productattr"+val.id+"0").addClass("selected");
								}
							});
						});

					}
					// 返回空值校验
					$Gadget.favoriteList = $Gadget.favoriteList || {};
					$Gadget.favoriteList.body = $Gadget.favoriteList.body || {};
					$Gadget.favoriteList.body.offerInfoList = $Gadget.favoriteList.body.offerInfoList || [];
					$Gadget.data.productsearchoffering.offeringList = $Gadget.favoriteList.body.offerInfoList;
					/*
                     * var i = selectedPage * 6;
                     *
                     * if(i >= $Gadget.favoriteList.body.offerInfoList.length && selectedPage > 0 ){ i = i - 6;
                     * $Gadget.favoriteSelectedPage = selectedPage - 1; }
                     *
                     * for(; i < $Gadget.favoriteList.body.offerInfoList.length; i ++){
                     *
                     * if(i >= selectedPage * 6 + 6){ break; }
                     * $Gadget.data.productsearchoffering.offeringList.push($Gadget.favoriteList.body.offerInfoList[i]); }
                     */
					var totalSize = $Gadget.favoriteList.body.totalSize;
					if(!$Gadget.params.pageInfo.selection && $Gadget.params.pageInfo.recordPerPage > $Gadget.data.productsearchoffering.offeringList.length){
						totalSize = $Gadget.data.productsearchoffering.offeringList.length;

					}
					$Gadget.data.productsearchoffering.pageInfo = {
						totalRecord : totalSize
					};

					// 高亮展示
					$Controller.bes.oc.productorder.highlight($Gadget);

					$("#pages").empty();
					if ($Gadget.data.productsearchoffering.offeringList
							&& $Gadget.data.productsearchoffering.offeringList.length > 0) {
                                $Gadget.data.pages = new UCD.Pages(
                                        $("#pages"),
                                        $Gadget.data.productsearchoffering.pageInfo.totalRecord,
                                        $Gadget.data.pageInfo.recordPerPage,
                                        [ 6, 12 ], 1);
						$Gadget.data.pages.setSelection(selectedPage + 1);

					} else {
						$Gadget.data.pages = null;
					}

					$Controller.bes.oc.productorder.convertOffering($Gadget);
					$Gadget.data.clickSearchFlag = true;
				}

			}, $Gadget);

		},
		// 收藏或全部
		changeTab : function($Gadget, $Fire, clickTab) {
			debugger;
			if($Gadget.tabIndex == clickTab ){
				return;
			}
			$Gadget.tabIndex = clickTab;
			// 切换到收藏页面，直接保存全部页面的数据
			if($Gadget.tabIndex == 1){
				$Gadget.data.totalproductsearchoffering = $Gadget.data.productsearchoffering;
				$Gadget.data.totalpages = $Gadget.data.pages;
					// $("#product").css({"font-weight":"bold"});
					$("#offer_product").css({"font-weight":"400"});
					$("#product_product").addClass("active");
					$("#offer_product").removeClass("active");
				$Controller.bes.oc.productorder.queryFavoriteInfo($Gadget,$Fire,0,true);

			} else {
					// $("#offer").css({"font-weight":"bold"});
				    $("#offer_product").addClass("active");
				    $("#product_product").removeClass("active");
				    $("#product_product").css({"font-weight":"400"});
				$Controller.bes.oc.productorder.clickSearch($Gadget,$Fire);
			}

		},
		convertOffering : function($Gadget){
			// 构造页面链接按钮显示
		$
			.each(
				$Gadget.data.productsearchoffering.offeringList || [],
				function(i, val) {
					val.showLevelInfoButton = $UEE.i18n("ad.person.button.Level");
					val.linkPage = null; // 'PTSP'
					// 'ACTIVITY'
					val.purchaseBtn = false;
					val.addtocarBtn = true;
					val.viewActivityBtn = false;

					if(val.offerStatus == "LEVELINFO"){
						val.addtocarBtn = false;
						val.purchaseBtn = true;
					}

					if (val.salesTagList && val.salesTagList[0].salesTagId == '1') {
						val.addedclass = 'tag_hot';
					}
					if (val.salesTagList && val.salesTagList[0].salesTagId == '2') {
						val.addedclass = 'tag_new';
					}
					if (val.salesTagList && val.salesTagList[0].salesTagId == '3') {
						val.addedclass = 'tag_sale';
					}
					if (val.salesTagList && val.salesTagList[0].salesTagId == '9') {
						val.addedclass = 'tag_test';
					}

					if (val.attributeMap && val.attributeMap.C_O_EXPERIENCE == 'Y') {
						val.offeringName = "<b>【体验】</b>" + val.offeringName;
					}

					/*
                     * //生成是时间 if (val.attributeMap && val.attributeMap.C_O_MONTHLY_FEE) {
                     *
                     * val.priceValue = adutil.getDisplayPrice(val.attributeMap.C_O_MONTHLY_FEE ) + "/月"; } else {
                     * val.priceValue = adutil.getDisplayPrice(val.minPriceValue,val.maxPriceValue); }
                     */
					// 资费信息pc直接返回
					if (val.attributeMap) {
						val.priceValue = val.attributeMap.C_O_TARIFF_DESC||"";
					}else{
						val.priceValue="";
					}

					// 如果未定义价格或者价格为0则不展示价格 需要UCD提供样式 代码暂时回退
					/*
                     * var temPriceValue = val.priceValue.substring(1); if ("0.00" == temPriceValue ||"0/月" ==
                     * temPriceValue || "0" == temPriceValue || "0-0" == temPriceValue) { val.priceValue = ""; }
                     */
					var prodType = null;
					$.each(val.prodTypeList || [], function(j,
						value) {
						if (value == 'PTSP') {
							prodType = 'PTSP';
						}
					});
					if (prodType == 'PTSP') {
						val.linkPage = 'PTSP';
					}

					// 营销活动

					if (val.offerClassCode) {
						var start = val.offerClassCode
							.indexOf("PROM_");
						if (start == 0) {
							val.linkPage = 'ACTIVITY';
							val.purchaseBtn = false;
							val.addtocarBtn = false;
							val.viewActivityBtn = true;
						}

					}

// if (val.canImmediatelyBuy == 'N') {
// val.purchaseBtn = false;
// }
					var $Page = $(document).scope().$Page;
					var catagorys = $Page.dictList['OC_FAMILY_CATAGORY'] || [];
					var termtnalCatagory = "";
					$.each(catagorys, function(i, val) {
						if(val.itemCode =='TERMINAL'){
							termtnalCatagory = val.dictName;
						}
					});
					if(termtnalCatagory == "") {
						termtnalCatagory = 9032;
					}
					// 添加裸机销售不展示添加购物车按钮
					if (termtnalCatagory == $Gadget.selectCategoryId)
					{
						val.purchaseBtn = true;
						val.addtocarBtn = false;
					}

			});
		},
		// 定义一个判断函数,判断某元素是否在数组中
		inArray : function(item, arr, $Gadget) {
            debugger;

            // 批量SP业务,只添加SP业务类型18000
            if ($Gadget.isBatchSpBusiness)
            {
                // 只添加SP业务
                var SP_ID = 18000;
                for ( var i = 0; i < arr.length; i++) {
                    if (item == SP_ID) {
                        return true;
                    }
                }

                return false;
            }

            // 批量营销活动业务,只添加营销活动业务类型18000
            if ($Gadget.isBatchRewardActivity)
            {
            	var $Page = $(document).scope().$Page;
            	var catagorys = $Page.dictList['OC_FAMILY_CATAGORY'] || [];
				var promCatagory = "";
				$.each(catagorys, function(i, val) {
					if(val.itemCode =='PROM'){
						promCatagory = val.dictName;
					}
				});
				if(promCatagory == "") {
					promCatagory = 6009;
				}
                // 只添加营销活动
                for ( var i = 0; i < arr.length; i++) {
                    if (item == promCatagory) {
                        return true;
                    }
                }

                return false;
            }


			// 遍历是否在数组中
			for ( var i = 0; i < arr.length; i++) {
				if (item == arr[i]) {
					return false;
				}
			}
			// 如果不在数组中就会返回false
			return true;
		},

		// 点击销售标签时动作
		clicksaletag : function($Gadget, $Target, saleTag){
			debugger;
			$Fire = $Gadget.$Get("$Fire");

			var $v_div = $Target;
			if ($v_div.siblings().hasClass("selected")) {
				$v_div.siblings().removeClass("selected");
			}
			$v_div.addClass("selected");

			if(saleTag == null){
				$Gadget.data.searchOfferingCond.saleTagList = null;
			}else {
				$Gadget.data.searchOfferingCond.saleTagList = [];
				$Gadget.data.searchOfferingCond.saleTagList.push(saleTag);
			}

			this.clickSearch($Gadget, $Fire);
		},

		addMainOffering: function($Page, $Gadget, $Fire, data, $UI) {
			debugger;
			if(!$Gadget.$Item){
				$Gadget.$Item = {};
			}
			$Gadget.$Item.offeringId = data.offeringId;
			$Controller.bes.oc.productorder.addtocar($Page, $Gadget, $Fire,
				data, $UI);
		},

		onMessgaFromPortal: function($Gadget)
		{
			window.onmessage = function(e) {
				//标记添加
				debugger;
	        	if (window._ysp_top.refreshShowFlag){
	        		$Gadget.$apply(function(){
	        			if(window._ysp_top.showOfferingLists){
	        				$Gadget.data.productsearchoffering.offeringList = window._ysp_top.showOfferingLists.offeringList;
	        			}
					});
	        		window._ysp_top.refreshShowFlag = false;
	        		return;
	        	}
				e = e || window.event;
				var data;
				if (navigator.userAgent.indexOf("MSIE") != -1) {
					data = JSON.parse(e.data);
				} else {
					data = e.data;
				}

				var operation = data.operation;
				if (undefined == operation) {
					return;
				}

				if ("prodorderfromportal" == operation) {
					var offerData = {
							offeringId : data.offeringid
						};
					$Gadget.$Emit("$bes.oc.selectCommodity", offerData);
				}

				if ("dayConvertPop" == operation){
					$Gadget.dayConvertOfferInfo = {
						offerName: data.offeringinfo.offeringName,
						offerCode: data.offeringinfo.offeringCode
					};
					if(!$Gadget.dayConvertOfferInfo.offerName && _ysp_top.window.shoppingcart && _ysp_top.window.shoppingcart.currOfferingInfo)
					{
						$Gadget.dayConvertOfferInfo.offerName = _ysp_top.window.shoppingcart.currOfferingInfo.offeringName ;
						$Gadget.dayConvertOfferInfo.offerCode = _ysp_top.window.shoppingcart.currOfferingInfo.offeringCode ;
					}
					$Page = angular.element(document).scope().$Page;
					OC.Callchain.setFireSearch($Page.pageId, "poDayPop");
					$Gadget.$Get("$Fire")({popin: ""});
					$Gadget.$Get("$Fire")({
						"popup" : {
							"id":"dayConvertPop",
							"title" : "按天计费信息查询",
							"width" : "900px",
							"height" : "480px",
							"src":"{{$Webapp}}/bes/ad/themes/default/template/bes-ad-shoppingcart/bes-ad-dayconvertpop.html",
							"resizable":false
						}
					}, $Gadget);
				}

				if ("prodorderfromportaldetail" == operation) {
					// window._ysp_top.offeringinfo = data.offeringinfo;
					// $(document).scope().$Page.data.offeringinfo = data.offeringinfo;
					// $(document).scope().$Page.data.offeringId = data.offeringinfo.offeringId;
					window._ysp_top.offeringinfo = window._ysp_top.shoppingcart.offeringinfo;
					$(document).scope().$Page.data.offeringinfo = window._ysp_top.shoppingcart.offeringinfo;
					$(document).scope().$Page.data.offeringId = window._ysp_top.shoppingcart.offeringId;

					if(window._ysp_top.shoppingcart.offeringinfo.levelBaseInfo){
						// 营销活动修改
						// 商品化待修改-------
						// $(document).scope().$Get('$Fire')({targetstep:'promotionsetting'});

			    		 //$Controller.bes.oc.productorder.popupPromotionPage($Page,$Gadget, $Fire, $UI);
						 try {
							$Controller.bes.oc.productorder.popupPromotionPage($Page,$Gadget, $Fire, $UI);
						 }catch (e){
							 $Controller.bes.oc.productorder.popupPromotionPage($Page,$Gadget, $Fire, $Gadget.$Get('$UI'));
						 }
						// 待修改
						$Page.classificationId = data.offeringinfo.classificationId;
						$(document).scope().$apply();

						return;
					}

					if(window._ysp_top.shoppingcart.offeringinfo.goodType == "goodSale"){
						if(window._ysp_top.shoppingcart.offeringinfo.agentFlag == "AGENT_SALE"){
							$Gadget.$Get('$Fire')({targetstep:'agentproductsale'});
						}
						else{
							// $Gadget.$Get('$Fire')({targetstep:'personalsale'});
							$Controller.bes.oc.prodDispachUrl.showsalecardPage($Gadget, $(document).scope().$Page.data.offeringId);
						}
						return;
					}

					if(window._ysp_top.productPopupFlag == '1'){
						var $PartShade = $('.partShade:eq(0)');
						$PartShade.animate({
							left:$("#groupproduct_btn_cancel").offset().left,
							_ysp_top:$("#groupproduct_btn_cancel").offset()._ysp_top,
							width:0,
							height:0
							},300);
						window._ysp_top.productPopupFlag ="";
						$(document).scope().$Emit("$bes.oc.modifyorderinit", offerData);
						$(document).scope().$Emit("$bes.oc.modifyorder", data.offeringinfo);
					}

					else{

						setTimeout(function(){
							$(document).scope().$Emit("$bes.oc.modifyorder", data.offeringinfo);

						},1000);
					}
				}

				// 营销包快选消息
				if("promotionBundle" == operation){

					$(document).scope().$Page.promotionBundle = data;
					$(document).scope().$Emit("$bes.oc.promotionBundle");

				}



			};
		},

		curTabIsCreateSubs : function()
		{
			var curtabid = parent.tab.selectedItem().attr("innerid");
			var createsubsTab =[{tabid:"cporder"},
			                    {tabid:"broadbandopen"},
			                    {tabid:"openvicecardaccount"},
			                    {tabid:"goventtelephone"},
			                    {tabid:"differentnetwork"},
			                    {tabid:"imstelephone"},
			                    {tabid:"wiredTelephone"},
			                    {tabid:"specialpersonalproduct"}];

			for(var i = 0, ii = createsubsTab.length; i < ii; i++)
			{
				if (createsubsTab[i].tabid == curtabid) {
					return true;
				}
			}

			return false;
		},

		createSubsTabAddProd : function(offeringid)
		{
			var msg = {
					operation : "prodorderfromportal",
					offeringid : offeringid
			};
			var curtabid = parent.tab.selectedItem().attr("innerid");
			parent.getPageById(curtabid).find("iframe")[0].contentWindow.postMessage(msg, "*");
		},

		portalClickProdProcess : function(offeringid,isaddprod) {
			debugger;
			// isaddprod 是否为增值offer
			if (isaddprod && this.curTabIsCreateSubs())
			{
				this.createSubsTabAddProd(offeringid);
				return;
			}

			var item = {
				title : $UEE.i18n("ad.person.title.offeringSubscription"),
				url : "bes/ordercapture/html/bes.oc.index.productorder.base.business.html#/index",
				id : "60131004",
				pageid : "resource.root/bes/ordercapture/html/bes.oc.index.productorder.base.business.html#/index",
				httpsFlag : ""
			};
			window.$BES.$Portal.tabpanel.createTabItem(item);

			setTimeout(function(){
				if (parent.getPageById("60131004")
					&& parent.getPageById("60131004").find("iframe")
					&& parent.getPageById("60131004").find("iframe")[0].contentWindow.document.readyState == "complete")
					{
						var msg = {
								operation : "prodorderfromportal",
								offeringid : offeringid
						};
						parent.getPageById("60131004").find("iframe")[0].contentWindow.postMessage(msg, "*");
					}

			},2000);
		},
		highlight : function($Gadget) {
			if (null != $Gadget.data.productsearchoffering.offeringList
				&& $Gadget.data.productsearchoffering.offeringList.length > 0) {
				if (null != $Gadget.data.searchOfferingCond.keyWord
							&& undefined != $Gadget.data.searchOfferingCond.keyWord
							&& "" != $Gadget.data.searchOfferingCond.keyWord) {
					for (var i = 0; i < $Gadget.data.productsearchoffering.offeringList.length; i++) {
						if (null == $Gadget.data.productsearchoffering.offeringList[i].highlightFieldsMap
								|| undefined == $Gadget.data.productsearchoffering.offeringList[i].highlightFieldsMap)
						{
							continue;
						}
						$Gadget.data.productsearchoffering.offeringList[i].offeringName =
							$Gadget.data.productsearchoffering.offeringList[i].highlightFieldsMap.offerName || "";
					}
				}
			}
		},
		// 根据二维码查询营销活动的结果
		queryQRCode: function($Page, $Gadget, $Fire, data, $UI) {
			debugger;
			$Gadget.data.productsearchoffering = data;
			var searchoffer = $Gadget.data.productsearchoffering.offeringList[0];
			if (searchoffer.offerClassCode && searchoffer.offerClassCode.indexOf("PROM_") == 0) {
				// $Controller.bes.oc.productorder.offerListProcess($Gadget, $Fire);
			}else {
				$Gadget.$Item = $Gadget.$Item || {};
				$Gadget.$Item.offeringId = searchoffer.offeringId;
				$Controller.bes.oc.productorder.addtocar($Page, $Gadget, $Fire,
						searchoffer, $UI, 0);
			}
		},
		gerateofferingList:function(offeringList){
			debugger;

			$.each(offeringList||[],function(i,val){

				val.relaItemId = adutil.getNextNumber();
				if(val.product && val.product.length > 0){
					$.each(val.product||[],function(j,valj){
						valj.relaItemId = adutil.getNextNumber();
						valj.opCode = val.opCode;

						// 去除掉无用的产品
						if(!valj.prodId){
							valj = null;
						}
					});

				}
				// 去除无用的有线业务信息
				if(val.wiredProdAttr && val.wiredProdAttr.newCardInfo && (!val.wiredProdAttr.newCardInfo.skuId)){
					val.wiredProdAttr.newCardInfo = null;
				}

				if(val.isBundled && val.subOfferings){

					// 去除无效的子offer
					var list = [];
					$.each(val.subOfferings||[],function(j,valj){
						if(valj.opCode == '1' || valj.opCode == '2' || valj.opCode == '3'){
							list.push(valj);
						}
					});
					val.subOfferings = list;

					// 处理子offer生失效方式
					$.each(val.subOfferings||[],function(k,valk){

						valk.relaItemId = adutil.getNextNumber();
						if(valk.product && valk.product.length > 0){
							/*
                             * valk.product[0].relaItemId = adutil.getNextNumber(); valk.product[0].opCode =
                             * valk.opCode;
                             */
							$.each(valk.product||[],function(j,valj){
								valj.relaItemId = adutil.getNextNumber();
								valj.opCode = val.opCode;

								// 去除掉无用的产品
								if(!valj.prodId){
									valj = null;
								}
							});
						}
						// 去除无用的有线业务信息
						if(valk.wiredProdAttr && valk.wiredProdAttr.newCardInfo && (!valk.wiredProdAttr.newCardInfo.skuId)){
							valk.wiredProdAttr.newCardInfo = null;
						}

						if(valk.effectiveWay){

							var effectiveTypes = [];
							$.each(valk.effectiveWay.effectiveTypes||[],function(l,vall){
								if(vall.key == valk.effectiveWay.selectedKey){
									vall.selected = true;
									effectiveTypes.push(vall);
									return false;
								}

							});
							valk.effectiveWay.effectiveTypes = 	effectiveTypes;
						}

						if(valk.expirationWay){
								var expirationTypes = [];
								$.each(valk.expirationWay.expirationTypes||[],function(l,vall){
									if(vall.key == valk.expirationWay.selectedKey){
										vall.selected = true;
										expirationTypes.push(vall);
										return false;
									}

								});
								valk.expirationWay.expirationTypes = 	expirationTypes;
							}
					});
				}

			});
		},

		// 局部窗口
		showPartShade : function(obj,url,fu1,fu2){
			debugger;
			obj = obj || $("#productordermainImpl");
			setTimeout(function(){
				var scope = $(document).scope();
				scope.$apply(function(){
					if(window._ysp_top.productPopupFlag != '1'){
						window._ysp_top.productPopupFlag = '1';
					}
				},scope);

			},1);
			var $PartShade = $('.partShade:eq(0)');
			var ShadeLeft=$('#productordermainImpl').offset().left+10;
			var newWidth = $('#productordermainImpl').width()-30;
			try{
			    $PartShade.css({
			        'display':'block',
			        'left':obj.offset().left,
			        '_ysp_top':obj.offset()._ysp_top+3
			    });
			}
			catch(e){
			    $PartShade.css({
                    'display':'block',
                    'left':ShadeLeft,
                    '_ysp_top':3
                });
			}
			$PartShade.animate({
				left:ShadeLeft,
				_ysp_top:3,
				bottom:0,
				height:$("body:eq(0)").height()-10,
				width:newWidth+10
				},300,function(){
					// $(this).css("height","100%");
					// shadeScrollbar.refreshScroll();//刷新滚动条

					});

			/* 窗口改变大小时，弹窗收起 */
			$(window).resize(function () {

				var width = $('#productordermainImpl').width()-20;
				$(".fix_btns").css("width",width);
				var newWidth = $('#productordermainImpl').width()-40;
				$PartShade.css({
					'height':$("body:eq(0)").height()-40,
					'width':newWidth+10
					});
			});

			},

			// 初始化营销星级 这个方法
			initPromStar : function($Gadget, $Fire){
				var itemId = "60103316";
				$Gadget.data.starCategorys = [];
				debugger;
				$Fire({
				     service : 'ucec/v1/common/qrysystemparambykey',
				     params : {
				    	 key : itemId
				     },
				     target : "$Gadget.promStarFlag",
				     onafter : function(){
			                   debugger;
			                   if("Y" == $Gadget.promStarFlag){
			                	   $Page = angular.element(document).scope().$Page;
			                	   OC.Callchain.setFireSearch($Page.pageId, "poStarjs");
			                	   // 初始化星级
			                	   $Fire({
												'service' : '/common/dictkey',
												'params' :  {
													"dictkeylist" : ['PM_OFFER_CUSTOM_STARLEVEL']
												},
												'target' : '$Gadget.promStarDict',
												'onafter': function(){
													debugger;
													var promStarDict = $Gadget.promStarDict["PM_OFFER_CUSTOM_STARLEVEL"]||[];
													$.each(promStarDict, function(i, val) {
														var obj = {
															"key" : val.itemCode,
															"value" : val.itemName
														};
														$Gadget.data.starCategorys.push(obj);
													});
													}
												},$Gadget);
			                   }
				         	}
				     	}, $Gadget);

				},
				// 点击星级标签时动作 这个方法
				clickstartag : function($Gadget, $Target, starLevel){
					debugger;
					$Fire = $Gadget.$Get("$Fire");

					var $v_div = $Target;
					$Gadget.data.levelQryCondition = $Gadget.data.levelQryCondition || {};
					$Gadget.data.levelQryCondition.extendCondition = $Gadget.data.levelQryCondition.extendCondition || [];
					var starLevelCondition ;

					for(var j=0;j<$Gadget.data.levelQryCondition.extendCondition.length;j++){
						if("customStarLevel" == $Gadget.data.levelQryCondition.extendCondition[j].conditionId){
							starLevelCondition = $Gadget.data.levelQryCondition.extendCondition[j];
							$Gadget.data.levelQryCondition.extendCondition.splice(j, 1);
							break;
						}
					}
					starLevelCondition = starLevelCondition || {"conditionId":"customStarLevel","conditionValue" : []};
					// 全部的场景
					if (null == starLevel) {
						if($v_div.siblings().hasClass("selected")){
							$v_div.siblings().removeClass("selected");
							}
						$v_div.addClass("selected");

					// 多选场景
					}else {
						starLevelCondition.conditionValue = starLevelCondition.conditionValue||[];
						if($v_div.hasClass("selected")){
							$v_div.removeClass("selected");
							if(!$v_div.siblings().hasClass("selected")){
							$("#starTagAll").addClass("selected");
							}
							for(var i=0; i<starLevelCondition.conditionValue.length ;i++){
								if(starLevelCondition.conditionValue[i] == starLevel){
									starLevelCondition.conditionValue.splice(i,1);
								}
							}

						}else{
							$v_div.addClass("selected");
							$("#starTagAll").removeClass("selected");
							starLevelCondition.conditionValue.push(starLevel);

						}
						if(starLevelCondition.conditionValue.length > 0){

						$Gadget.data.levelQryCondition.extendCondition.push(starLevelCondition);

						}

					}
// if($Gadget.tabIndex == 1)
// {
//
// $Controller.bes.oc.productorder.queryFavoriteInfo($Gadget,$Fire,0,true);
// }
// this.clickSearch($Gadget, $Fire);
				},

				offerDetailProcess : function($Page, $Gadget){
					$Fire = $Gadget.$Get("$Fire");
					$UI = $Gadget.$Get("$UI");
					debugger;
					// 体验业务的商品
					var mapKey = null;
					if ($Gadget.index)
					{
						mapKey = ($Gadget.data.productsearchoffering.offeringList[$Gadget.index]||{}).attributeMap;
					}

					if (mapKey && mapKey.C_O_EXPERIENCE == 'Y') {
						$Gadget.data.offeringinfo.attributeMap = mapKey;
					}

					/*
                     * if ("car" == $Gadget.callfrom) { for (var i = 0; i < ($Gadget.data.shoppingitemlist ||
                     * []).length; i++) { if ($Gadget.data.offeringinfo.offerId ==
                     * $Gadget.data.shoppingitemlist[i].offerId) { $UI.msgbox.error("提示", "购物车中已存在。"); $Page.isClickBtn =
                     * false; return false; }
                     *  } }
                     */

					// 判断是否家庭 产品
					$Page.isShowJTW = false;
					$Page.jtwProduct = null;
					var jtwProduct = $(document).scope().isFamilyProd($Gadget.data.offeringinfo);
					if(jtwProduct) {
						$Page.isShowJTW = true;
						jtwProduct.opCode="1";
						jtwProduct.relaItemId = adutil.getNextNumber();
						$Page.jtwProduct = jtwProduct;
						$Page.jtwProduct.prodId=$Page.jtwProduct.productId;
					}

					$Page.offeringId = $Gadget.data.offeringinfo.offerId;

					$Controller.bes.oc.prodDispachUrl
						.distributePages($Page, $Gadget, $Fire,
							$UI);

				},
				moreShow:function ($Gadget, $Page)
			    {
					$("#more-cont").toggle();
				    $Page.isMoreShowing=!$Page.isMoreShowing;
				    $Gadget.promShow=!$Gadget.promShow;
			    },

				// 初始化时查询搜索热词
				toGetHotSearchWords : function($Page, $Gadget){
					$Fire = $Gadget.$Get("$Fire");
					$Gadget.hotsearchwords = ["Ihone 6s", "华为", "4G", "HTC","宽带"];
					debugger;
					OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
					$Fire({
						  'service' : '/queryofferhotwordservice/queryofferhotword',
							'target' : '$Gadget.hotsearchwords',
							'onafter' : function($Gadget) {
										debugger;
							     }
						}, $Gadget);
				},

				// 点击热词时调用搜索接口
				clickHotWordSearch : function($Page, $Gadget, $item){
					$Fire = $Gadget.$Get("$Fire");
					$UI = $Gadget.$Get("$UI");
					debugger;
					$Gadget.keyWord = $item;
					$Controller.bes.oc.productorder.clickSearch($Gadget,$Fire);
				},

				addWordToHis : function($Gadget, keyword){
					debugger;
					// 将搜索词加入搜索历史中， 若已在列表中，则不处理,
					$Gadget.$Page.hissearchwords = $Gadget.$Page.hissearchwords || [];
					var existFlag = false;
					var tempindex = null;
					$.each($Gadget.$Page.hissearchwords, function(i, val){
						if(val == keyword){
							existFlag = true;
							tempindex = i;
						}
					});

					// 已存在则移动到首位，不存在则直接添加
					if(!existFlag){
						$Gadget.$Page.hissearchwords.unshift(keyword);
					}else{
						$Page.hissearchwords.splice(tempindex,1);
						$Page.hissearchwords.unshift(keyword);
					}

					// 最多保留5条记录
					if($Gadget.$Page.hissearchwords.length > 5){
						$Gadget.$Page.hissearchwords.pop();
					}

					var tempcookie = JSON.stringify($Gadget.$Page.hissearchwords);
					$.cookie('hissearchwords', tempcookie);
				},

				// 删除搜索词记录
				deleteHisSearchWord : function($Page, $Gadget, $index){
					debugger;
					// event.stopPropagation();
					// 全部删除
					if($index == "ALL"){
						$Page.hissearchwords=[];
					}else{
						$Page.hissearchwords.splice($index, 1);
					}
					var tempcookie = JSON.stringify($Page.hissearchwords);
					$.cookie('hissearchwords', tempcookie);
				},

				// 点击热词时调用搜索接口
				clickHisSearchWord : function($Page, $Gadget, $item, $index){
					$Fire = $Gadget.$Get("$Fire");
					$UI = $Gadget.$Get("$UI");
					debugger;
					$Gadget.keyWord = $item;
					$Controller.bes.oc.productorder.clickSearch($Gadget,$Fire);
					// 添加到历史记录，将点击词移动到首位
					this.addWordToHis($Gadget, $item);
				},

				// 获取联想词
				getAssociatedWords : function($Page, $Gadget){
					$Fire = $Gadget.$Get("$Fire");
					$UI = $Gadget.$Get("$UI");
					debugger;

					if( ($Gadget.keyWord != null) && ($Gadget.keyWord != "")){
						/* $Gadget.associateWords = ["zhou", "hhhhh", "sss"]; */
						this.showAssociateWords($Page, $Gadget);
						OC.Callchain.setFireSearch($Page.pageId, "assoWord");
						$Fire({
								'service' : '/queryofferassociatewordservice/queryofferassociate',
								'params' : {
										associateword : $Gadget.keyWord
									},
								'target' : '$Gadget.associateWords',
								'onafter' : function($Gadget) {
										debugger;
										if($Gadget.associateWords == null || $Gadget.associateWords.length == 0)
										{
											$(".searchBuyPanel").hide();
										}
								}
							}, $Gadget);
					}else{
						this.showHisSearchWords($Page, $Gadget);
						return;
					}
				},

				// 展示搜索历史词
				showHisSearchWords : function($Page, $Gadget){
					debugger;
					$Gadget.showAssociateWords = false;
					$Gadget.showHisSearchWords = true;
/*					if($Page.hissearchwords == null || $Page.hissearchwords.length == 0)
					{
						$(".searchBuyPanel").hide();
					}*/
				},

				// 展示联想词 $Gadget.showAssociateWords
				showAssociateWords : function($Page, $Gadget){
					debugger;
					$Gadget.showHisSearchWords = false;
					$Gadget.showAssociateWords = true;
				},

				// 搜索输入框框获取焦点时,无关键字则展示历史词，有关键词则展示联想词
				focusOnSearchInput : function($Page, $Gadget){
					debugger;
					$Gadget.showWords = true;
					$(".searchBuyPanel").show();

					try{
						event.stopPropagation();
					}
					catch(e){

					}
					if(($Gadget.keyWord == "") || ($Gadget.keyWord == null) || $Gadget.keyWord==$UEE.i18n('ad.unsubscribe.label.keyword')){
						this.showHisSearchWords($Page, $Gadget);
					}else{
						this.showAssociateWords($Page, $Gadget);
						this.getAssociatedWords($Page, $Gadget);
					}

				},
				blurOnSearchInput : function($Page, $Gadget,jEvent){
				    debugger;
				    if(jEvent.currentTarget.value=='') {
				        var markWord= $UEE.i18n('ad.unsubscribe.label.keyword');
				        jEvent.currentTarget.value=markWord;
				        jEvent.currentTarget.style.color='gray';
				        $Gadget.keyWord = markWord;
				    }

				},


			 searchAttrMore : function($Target) {
				 debugger;
				 $Target.siblings(".item_hide").removeClass("item_hide");
				 $Target.hide().next().show();
			},
			searchAttrLess : function($Target) {
				debugger;
				$Target.hide().prev().show();
				$Target.siblings(".attr_item_gt_14").addClass("item_hide");
			},
			// 短流程判断时调用，判断商品的属性是否同时满足三个条件：
			// 1：属性需要体现在用户身上（用能力控制项配置INS判断）2：属性需要展示（用能力控制项没有配置SIV判断）3：属性可以修改（用INSTANTIABLE='Y'判断）
			isAttrNeedToShowAndModifyAndTransToUser : function(ocOfferingAttrPOJO) {
				// 如果没有配置能力项，则直接返回false
				if (!ocOfferingAttrPOJO || !ocOfferingAttrPOJO.ocPcOfferingAttributeEnableVA || ocOfferingAttrPOJO.ocPcOfferingAttributeEnableVA.length == 0) {
					return false;
				}
				// 属性需要体现在用户身上，初始为false
				var isNeedTransToUser = false;
				// 属性需要展示，初始true
				var isNeedToShow = true;
				$.each(ocOfferingAttrPOJO.ocPcOfferingAttributeEnableVA, function(i, val) {
					if (val.enableType == 'INS') {
						isNeedTransToUser = true;
					}
					if (val.enableType == 'SIV') {
						isNeedToShow = false;
					}
				});
				// 需要体现给用户 并且 需要展示 并且可以修改
				if (isNeedTransToUser && isNeedToShow && ocOfferingAttrPOJO.isInstantiable == 'Y') {
					return true;
				}
				return false;
			},

			complexOrder:function($Gadget,$Fire,$Target){
				debugger;
				if ($Target.siblings().hasClass("selected")) {
					$Target.siblings().removeClass("selected");
				}
				$Target.addClass("selected");

				$Gadget.data.pageInfo.sortItems =  [
				        							{
				        								'sortDir' : 'ASC',
				        								'sortField' : 'offer_type_sort_order'
				        							},
				        			                {
				        			                	'sortDir' : 'ASC',
				        			                	'sortField' : 'sale_tag.sale_tag_sort_order'
				        			                },
				        							{
				        								'sortDir' : 'ASC',
				        								'sortField' : 'offer_name_length'
				        							}
				        	                ];
				this.clickSearch($Gadget, $Fire);
			},
			salesOrder:function($Gadget,$Fire,$Target){
				debugger;
				if ($Target.siblings().hasClass("selected")) {
					$Target.siblings().removeClass("selected");
				}
				$Target.addClass("selected");
				$Gadget.data.pageInfo.sortItems =	[
				        							{
				        								'sortDir' : 'ASC',
				        								'sortField' : 'offer_type_sort_order'
				        							},
				        			                {
				        			                	'sortDir' : 'DESC',
				        			                	'sortField' : 'sales_volume.total_sales_volume'
				        			                }
				        	                ];
				this.clickSearch($Gadget, $Fire);
			},
			queryOfferingIdByCode:function($Page, $Gadget, $Fire, $UI,offeringCode,callBack){
				debugger;
				OC.Callchain.setFireSearch($Page.pageId, "qryByCod");
				$Fire({
					service:"ucec/v1/offering/queryofferidbycode",
					params:{
						offeringCode:offeringCode
					},
					target:"$Gadget.data.qryIdByCodeResp",
					onafter:function(){
						callBack();
					}

				},$Gadget);
			},
			productorderFromWorkbench:function($Page, $Gadget, $Fire, $UI){

				var offeringId =  null;

				$Page.data = $Page.data ||{};
				$Page.data.recommendOid =  $Gadget.$Params.recommendOid;

				if($Gadget.$Params.bundOfferingId){
					offeringId = $Gadget.$Params.bundOfferingId;
				}else{
					offeringId =  $Gadget.$Params.offeringId;
				}
				if(!offeringId){
					return false;
				}
				$Gadget.$Item = {};

				var callBack = function(){
					debugger;
					$Page.data.icrmMarketingOfferingId = $Gadget.data.qryIdByCodeResp.body.offeringId;
					$Gadget.$Item.offeringId = $Gadget.data.qryIdByCodeResp.body.offeringId;
					$Controller.bes.oc.productorder.queryofferinginfo($Page, $Gadget, $Fire, $UI, null);
				}

				if("iCRM_MARKETING_WORKBENCH" == $Gadget.$Params.actionSource){
					$Controller.bes.oc.productorder.queryOfferingIdByCode($Page, $Gadget, $Fire, $UI,offeringId,callBack);
				}
				else{
					$Gadget.$Item.offeringId = offeringId;
					$Page.data.icrmMarketingOfferingId = offeringId
				}

			},
			productorderSpFromWorkbench:function($Page, $Gadget, $Fire, $UI){

				var offeringId =  null;

				$Page.data = $Page.data ||{};
				$Page.data.recommendOid =  $Gadget.$Params.recommendOid;

				var spId = $Gadget.$Params.spId;
				var spBizCode = $Gadget.$Params.spBizCode;

				if(!spId && !spBizCode ){
					return false;
				}
				$Gadget.$Item = {};

				if("iCRM_MARKETING_WORKBENCH" == $Gadget.$Params.actionSource){
					$Fire({
						service:"ucec/v1/offering/queryofferidbyspidandbizcode",
						params:{
							spId:spId,
							spBizCode:spBizCode
						},
						target:"$Gadget.data.qryIdByCodeResp",
						onafter:function(){

							$Page.data.icrmMarketingOfferingId = $Gadget.data.qryIdByCodeResp.body.offeringId;
							$Gadget.$Item.offeringId = $Gadget.data.qryIdByCodeResp.body.offeringId;
							$Controller.bes.oc.productorder.queryofferinginfo($Page, $Gadget, $Fire, $UI, null);
						}

					},$Gadget);
				}

			},
			promotionFromWorkbench:function($Page, $Gadget, $Fire, $UI){
				debugger;
				// 营销优惠券——start
				// 营销优惠券实例Id
				$Gadget.couponOfferingInstId = $Gadget.$Params.couponOfferingInstId;
				if($Gadget.couponOfferingInstId){
					var couponCallBack = function(){
						debugger;
						// 设置档次活动信息
						$Gadget.data.qryTicketDetailResp = $Gadget.data.qryTicketDetailResp || {};
						$Gadget.data.qryTicketDetailResp.body = $Gadget.data.qryTicketDetailResp.body || {};
						$Gadget.offeringId = $Gadget.data.qryTicketDetailResp.body.relaPromId;
						$Gadget.rankOfferingId = $Gadget.data.qryTicketDetailResp.body.relaRankId;
						$Gadget.ticketId = $Gadget.data.qryTicketDetailResp.body.offeringInst;//此处为优惠券id
						$Controller.bes.oc.productorder.promotionRankClick($Page, $Gadget,$Fire,$UI);
					}
					$Controller.bes.oc.productorder.qryTicketDetailByInstId($Page, $Gadget, $Fire, $UI,couponCallBack);
				}
				// 营销优惠券——end
				else{
					$Gadget.offeringId =  $Gadget.$Params.offeringId;
					if(!$Gadget.offeringId){
						return false;
					}
					$Page.data = $Page.data ||{};
					$Page.data.recommendOid =  $Gadget.$Params.recommendOid;
					var callBackAct = function(){
						debugger;
						$Gadget.offeringId = $Gadget.data.qryIdByCodeResp.body.offeringId;
					}
					var callBackRank = function(){
						debugger;
						$Gadget.rankOfferingId = $Gadget.data.qryIdByCodeResp.body.offeringId;
						$Controller.bes.oc.productorder.promotionRankClick($Page, $Gadget,$Fire,$UI);
					}
					$Gadget.rankOfferingId =  $Gadget.$Params.rankOfferingId;
					if("iCRM_MARKETING_WORKBENCH" == $Gadget.$Params.actionSource){
						$Controller.bes.oc.productorder.queryOfferingIdByCode($Page, $Gadget, $Fire, $UI,$Gadget.offeringId,callBackAct);
						if($Gadget.rankOfferingId){
							$Gadget.data.qryIdByCodeResp = {};
							$Controller.bes.oc.productorder.queryOfferingIdByCode($Page, $Gadget, $Fire, $UI,$Gadget.rankOfferingId,callBackRank);
						}
					}
					$Controller.bes.oc.productorder.promotionRankClick($Page, $Gadget,$Fire,$UI);
				}

			},
			promotionRankClick : function($Page, $Gadget,$Fire,$UI){
				if($Gadget.rankOfferingId){
					// 添加批次ID、档次ID、商品订购MODE
					$Item = {
						"offeringId":$Gadget.offeringId,
						"classificationId":20000,
						"offerClassCode":"PROM_TYPE"
					};
					$Promotion = {
						"levelBaseInfo":{
							"offeringId":$Gadget.rankOfferingId,
							"couponOfferingInstId":$Gadget.ticketId
						}
					};
					$Controller.bes.oc.productorder.checkLevelDetail($Page,$Item, $Promotion,$Gadget,$Fire,$UI,0);
				}
			},
			qryTicketDetailByInstId:function($Page, $Gadget, $Fire, $UI,callBack){
				debugger;
				$Fire({
					service:"ucec/v1/marketplan/qryticketdetailbyinstid",
					params:{
						body:{
							offerInstId:$Gadget.couponOfferingInstId
						}
					},
					target:"$Gadget.data.qryTicketDetailResp",
					onafter:function(){
						callBack();
					}

				},$Gadget);
			},
			clearInput:function($Gadget){
				$('#inputquerystring').val('');
				$(this).hide();
				$Gadget.keyWord='';
			},
			// 终端售货 是否需要默认过滤库存
			isDefaultFilterStock:function($Page, $Gadget,$Fire,$UI){
				$Fire({
					service:"ucec/v1/barestock/isdefautfilterstock",
					target:"$Gadget.data.isdefautfilterstockResp",
					onafter:function(){
						debugger;
						// 默认过滤库存
						if($Gadget.data.isdefautfilterstockResp){
							$Gadget.defaultFilterStock = true;
						}else{
							$Gadget.defaultFilterStock = false;
						}
					}
				},$Gadget);
			},
			// 两城一号预约营销方案
			mnpPromAppointment : function($Gadget, $Fire, $Page) {
			    // 两城一号预约营销方案
			    if($Page.data && $Page.data.mnpPromFlag){
			    	$Gadget.data.searchOfferingCond.beId = $Page.data.mnpBeId;
			    	// 指定商品分类为营销
			    	$Gadget.categoryId =  '6009';
			    	$Gadget.data.searchOfferingCond.categoryId = $Gadget.categoryId;

			    	// 在携出地，需要清空departmentId，并且禁止领取实物奖品
			    	if($Page.data.mnpBeId != _ysp_top.$BES.$ContextAccessor.getBeId()){
			    		$Gadget.data.searchOfferingCond.departmentId = "";
			    		// 在非携入地禁止领取实物类奖品
			    		$Page.data.mnpPromForbidPracticality = true;
			    	}
			    }

			},

			// 营销方案页
			popupPromotionPage : function($Page, $Gadget, $Fire, $UI) {
				debugger;

				// 业务类型为ivrorderadd时，复用营销方案详情页面,不再展示商品订购下的营销方案详情页
				if ($Gadget.channelId && "606" == $Gadget.channelId
						&& $Gadget.busiType && "ivrorderadd" == $Gadget.busiType) {

					if("rtPerson" != $Page.params.promType && "rtBroadband" != $Page.params.promType)
					{
						$UI.msgbox.error($UEE.i18n("ad.person.label.information"), "请选择订购个人活动或者宽带活动。");
						return;
					}
					$Page.params.subType = 'IVROrder';
					// 营销方案详情页 展示
					$Page.ivr_promotionsettingpopshow = true;
					// 原有营销方案详情不展示
					$Page.promotionsettingpopshow = false;
					// 商品订购 页面不展示
					$Page.mpivrprodordershow = false;
					return;
				}

	    		 $Page.promotionsettingpopshow = true;
				 scroll(0, 0);
			},
			checkIsExistSameOrderForIVR : function($Gadget,$UI){
				debugger;
				if($Gadget.promotionInfo && $Gadget.promotionInfo.retMessage && $Gadget.promotionInfo.retMessage.indexOf("60107251027") != -1){
					$UI.msgbox.confirm($UEE.i18n("ad.person.label.information"), "该用户存在未完成的订单，请向用户确认是否删除未完成订单；删除请点击是，不删除点击否", function() {
						debugger;
						$Page.params.isDeleteOldOrder="TRUE";
					},
					function() {
						debugger;
						$Page.params.isDeleteOldOrder="FALSE";
					});
				}
			},

		    qryQQZHOfferIdList : function($Gadget, $Fire) {
				var offerIdList = [];
				$Fire(
					{
						service : "bes.agentdesktop.group.common.groupcommonservice/querydictitembydictcode",
						params : {
							mockid : "isQQZHOfferDict",
							dictcode : "OC_QQZH_OFFER",
							locale : adutil.getLocale()
						},

						target : "$Gadget.dictItem",
						onafter : function() {
							debugger;
							for ( var i = 0; i < $Gadget.dictItem.length; i++) {
								offerIdList.push($Gadget.dictItem[i].itemCode);
							}

							$Gadget.QQZHOfferIdList = offerIdList;
						}
					}, $Gadget);
		    },

		    /**
			 * 判断是否同商品（兼容营销方案）
			 */
		    isSameOffer : function(offer, offerCompare) {
		    	if (offer && offerCompare){
		    		// 默认是批次编码相同即可。
		    		if (offer.offeringId == offerCompare.offeringId) {
		    			// 如果存在档次，需要判断档次是否相同
		    			if (offer.levelBaseInfo && offerCompare.levelBaseInfo){
		    				if (offer.levelBaseInfo.offeringId == offerCompare.levelBaseInfo.offeringId){
		    					return true;
		    				}
		    			} else {
		    				return true;
		    			}
		    		}
		    	}
		    	return false;
		    },


		    /**
		     * 查询子商品
		     */
		    queryChildOffer : function($Gadget){
		    	debugger;

		    	$Page = $Gadget.$Page;

		    	$Gadget.$Get('$Fire')({
					service:"/recrollbackboservice/queryOfferingBaseInfoByIdList",
					params:{
						offeringIdList : $Gadget.childList
					},
					target:"$Gadget.childOfferList",
					onafter:function($Gadget,$Page){
						debugger;
						var carofferlist = window._ysp_top.shoppingcart.carofferingList;
				    	//将购物车中的商品传过来
						var newCarOfferList = [];
						for (var i = 0; i < carofferlist.length; i++){
							newCarOfferList.push(carofferlist[i]);
						}
				    	for (var i = 0; i < carofferlist.length; i++){
				    		var subOfferings = carofferlist[i].subOfferings;
				    		if (subOfferings != null && subOfferings.length > 0){
				    			for (var j = 0; j < subOfferings.length; j++){
				    				if (subOfferings[j].checked == true){
				    					newCarOfferList.push(subOfferings[j]);
				    				}
				    			}
				    		}
				    	}
				    	debugger;

						var newOfferList = $Gadget.newOfferList;

				    	if ($Gadget.childOfferList && $Gadget.childOfferList != null){
				    		for (var i = 0; i < $Gadget.childOfferList.length; i++){
				    			newOfferList.push($Gadget.childOfferList[i]);
				    		}
				    	}

				    	debugger;

						if(newCarOfferList.length == 0 && newOfferList.length == 0){
						     return;
						}
						debugger;
						//添加大菊花
				    	dontTouchDataOfWholePage();

				    	$Page.checkoutValidateBody = {businessType: "ChangeProduct",
								needCacheBusiValidate: 'N',
								createOrderReq:{
									order:{
										orderPayment:[]
									}
								},
							mixturePOJO:{
								offerings: newOfferList,
								packageFee:'N',
								seniorId:'CHANGE_OFFER',
								eventId:'AddOfferPreCheck'
							}
						};

				    	debugger;
				    	$Gadget.$Get('$Fire')(
							{
							'service': '/validatebeforeorderservice/validatebeforeorder',
								'params' : {
									'carOfferList' : newCarOfferList,
									'header' : {},
									'checkOutBody' : $Page.checkoutValidateBody
								},
								'target' : '$Page.ValidateResultInfoPOJO',
								'onafter' : function($Gadget,$Page) {
									debugger;
									var showofferlist = $Gadget.data.productsearchoffering;
									var offerList = showofferlist.offeringList;
									if ($Page.ValidateResultInfoPOJO != null){
										if($Page.ValidateResultInfoPOJO.length > 0){
											for(var i = 0;i < $Page.ValidateResultInfoPOJO.length;i++) {

												var validateResultInfo = $Page.ValidateResultInfoPOJO[i];

												for(var f = 0;f < offerList.length;f++) {
													if(validateResultInfo.isPackage == "Y"){
														if ($Gadget.data.searchOfferingCond.keyWord != ""){
															var pcHitChildOfferingList = offerList[f].pcHitChildOfferingList;
															if (offerList[f].offeringId == validateResultInfo.packOfferId){
																if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
																	for (var j = 0; j < pcHitChildOfferingList.length; j++){
																		if (pcHitChildOfferingList[j].childOfferingId == validateResultInfo.srcOfferId){
																			if(validateResultInfo.item == "E" || validateResultInfo.item == "UE") {
																				pcHitChildOfferingList[j].disableFlag = true;
																				if (validateResultInfo.destOfferNameList.length == 1){
																					pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"互斥";
																				}else{
																					pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"等互斥";
																				}
																			}else if (validateResultInfo.item == "D" || validateResultInfo.item == "UD"){
																				pcHitChildOfferingList[j].disableFlag = true;
																				if (validateResultInfo.destOfferNameList.length == 1){
																					pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0];
																				}else{
																					pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0]+"等";
																				}
																			}
																		}
																	}
																}
															}else if (validateResultInfo.packOfferId == null || !validateResultInfo.packOfferId){
																if (offerList[f].offeringId == validateResultInfo.srcOfferId) {
																	for (var j = 0; j < pcHitChildOfferingList.length; j++){
																		if(validateResultInfo.item == "E" || validateResultInfo.item == "UE") {
																			pcHitChildOfferingList[j].disableFlag = true;
																			if (validateResultInfo.destOfferNameList.length == 1){
																				pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"互斥";
																			}else{
																				pcHitChildOfferingList[j].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"等互斥";
																			}
																		}else if (validateResultInfo.item == "D" || validateResultInfo.item == "UD"){
																			pcHitChildOfferingList[j].disableFlag = true;
																			if (validateResultInfo.destOfferNameList.length == 1){
																				pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0];
																			}else{
																				pcHitChildOfferingList[j].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0]+"等";
																			}
																		}
																	}
																}
															}
														}
													}else{
														if(offerList[f].offeringId == validateResultInfo.srcOfferId) {
															if(validateResultInfo.item == "E" || validateResultInfo.item == "UE") {
																offerList[f].disableFlag = true;
																if (validateResultInfo.destOfferNameList.length == 1){
																	offerList[f].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"互斥";
																}else{
																	offerList[f].score = "与已购商品"+validateResultInfo.destOfferNameList[0]+"等互斥";
																}
															} else if(validateResultInfo.item == "D" || validateResultInfo.item == "UD") {
																offerList[f].disableFlag = true;
																if (validateResultInfo.destOfferNameList.length == 1){
																	offerList[f].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0];
																}else{
																	offerList[f].score = "尚未订购依赖的商品"+validateResultInfo.destOfferNameList[0]+"等";
																}
															}
														}
													}
												}
											}
											$Gadget.$apply(function(){
												$Gadget.data.productsearchoffering.offeringList = offerList;
											});
										}
									}
									//关闭大菊花
									youCanTouchDataOfWholePage();
								},
								'onerror' : function() {
									//关闭大菊花
									youCanTouchDataOfWholePage();
								}
							}, $Gadget);
					}
				},$Gadget);
		    },

			/**
		     * 判断该商品是否可以订购
		     * */
		    ordervalidate : function($Gadget,$Page) {
		    	debugger;
		    	window._ysp_top.keyWord4NX = $Gadget.data.searchOfferingCond.keyWord;

		    	if (null == $Page.serviceNum || "" == $Page.serviceNum || $Page.serviceNum.length < 10){
		    		return;
		    	}

		    	var showofferlist = $Gadget.data.productsearchoffering;
		    	var offeringList = showofferlist.offeringList;
		    	if (!offeringList){
		    		return;
		    	}
		    	//新建一个集合存放
				debugger;
		    	var newOfferList = [];
		    	var childList = [];
		    	for (var i = 0; i < offeringList.length; i++){
		    		if (offeringList[i].isBundle == "N" && offeringList[i].isMainOffer == "N"){
		    			newOfferList.push(offeringList[i]);
		    		}
		    		if ($Gadget.data.searchOfferingCond.keyWord != ""){
		    			if (offeringList[i].isBundle == "Y" && offeringList[i].offerType != "3"){
		    				newOfferList.push(offeringList[i]);
		    				var pcHitChildOfferingList = offeringList[i].pcHitChildOfferingList;
		    				if (pcHitChildOfferingList != null && pcHitChildOfferingList.length > 0){
		    					for (var j = 0; j < pcHitChildOfferingList.length; j++){
		    						childList.push(pcHitChildOfferingList[j].childOfferingId);
		    					}
		    				}
		    			}
		    		}
		    	}

		    	$Gadget.newOfferList = newOfferList;
		    	$Gadget.childList = childList;
		    	if ($Gadget.childList && $Gadget.childList != null){
		    		$Gadget.$Emit('$bes.haveChild');
		    	}

		    }
	});
