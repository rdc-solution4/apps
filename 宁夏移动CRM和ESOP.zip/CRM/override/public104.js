var timer = null;
var intavle = 30000;

//定时扫描是否发生数据库故障
function doCheck()
{
    timer = window.setTimeout("checkFaultMode()",intavle);
}

function checkFault()
{
    if(_ysp_top.mif.faultFlag === true && _ysp_top.mif.faultMode === 0)
    {
        onFault();//这个函数需要在各个模块中内容实现
        _ysp_top.mif.faultMode = 1;
    }
    
    if(_ysp_top.mif.faultFlag === false && _ysp_top.mif.faultMode !== 0)
    {
        onRescue();//这个函数需要在各个模块中内容实现
        _ysp_top.mif.faultMode = 0;
    }
}

//设置关闭窗口Tab页签调用
function setTabCloseFlag(flag,sTabCode){
    if(sTabCode == null || sTabCode.length ===0)
    {
        var oTabCode = window.frameElement.sTabCode;
        if(oTabCode == null)
        {
            oTabCode = parent.frameElement.sTabCode;
        }
    }
    else
    {
        var oTabCode = sTabCode;
    }
    if(oTabCode == null || oTabCode.length ===0)
    {
        return;
    }
    var oTab = _ysp_top.publicObject["mainTab"];
    if(oTab)
    {
        oTab.setTabCloseFlag(oTabCode,flag,window.document.title);
    }
}

//注册关闭Tab页签时的执行事件
function addCloseEvent(func,sTabCode){
    if(sTabCode == null || sTabCode.length ===0)
    {
        var oTabCode = window.frameElement.sTabCode;
    }
    else
    {
        var oTabCode = sTabCode;
    }
    if(oTabCode == null || oTabCode.length ===0)
    {
        return;
    }
    var oTab = _ysp_top.publicObject["mainTab"];
    if(oTab)
    {
        oTab.addCloseEvent(oTabCode,func);
    }
}

/*
 * 合并objRegister.js
 */

//注册公共对象
function regObject(objId,obj)
{
    //当窗体加载时，对公共对象进行注册
    /*
    if(typeof window.onload!=="function")
    {
        window.onload = function(){
            _ysp_top.mif.registerObject(objId,obj);
        }
    }
    else
    {
        window.attachEvent("onload",mif.registerObject(objId,obj));
    };
    */
    if(_ysp_top.mif)
    {
    	_ysp_top.mif.registerObject(objId,obj);
    }
    //20100122鲁展合入C02 不知是否存在问题，未验证
    //当窗体关闭时，对公共对象进行释放
    window.onunload = function(){
            if(_ysp_top.mif)
            {
            	_ysp_top.mif.removeObject(objId);
            }
    }
}

//添加系统切换时必须进行提交的窗体
function addActWindow(handle)
{
    _ysp_top.mif.addActiveWindow(handle);
}

//删除系统切换时必须进行提交的窗体
function removeActWindow(handle)
{
    _ysp_top.mif.removeActiveWindow(handle);
}

//添加IE新打开窗体的句柄
function addNewWindow(handle)
{
    _ysp_top.mif.addNewWindow(handle);
}

//删除IE新打开的窗体句柄
function removeNewWindow(handle)
{
    _ysp_top.mif.removeNewWindow(handle);
}

function menuChangeDisabled(menuId,oFlag)
{
    var menus = _ysp_top.publicObject["menu"];
    var callBarItems = _ysp_top.publicObject["callBarItems"];
    var menuItems = _ysp_top.publicObject["menuItems"];
    
    for(var i=0;i<menus.length;i++)
    {
        if(menus[i].id == menuId)
        {
            menus[i].disabled = oFlag;
        }
    }
    
    for(i=0;i<callBarItems.length;i++)
    {
        if(callBarItems[i].id == menuId)
        {
            callBarItems[i].disabled = oFlag;
        }
    }   
    
    for(i=0;i<menuItems.length;i++)
    {
        if(menuItems[i].id == menuId)
        {
            menuItems[i].disabled = oFlag;
        }
    } 
}

//在字符串相加时使用stringBuffer进行处理
//示例代码
/*
    var buffer = new stringBuffer();
    buffer.append("aaa");
    buffer.append("bbb");
    return buffer.toResult();
*/
function stringBuffer()
{
    this.strings = new Array();
}

stringBuffer.prototype.append = function(str)
{
    this.strings.push(str);
}

stringBuffer.prototype.toResult = function()
{
    return this.strings.join("");
}

//客户端菜单鉴权接口 id:菜单ID checkFlag:过滤标志，1-过滤掉接续菜单、父菜单和执行js事件的菜单 其他-不过滤
function checkAuthMenuById(id,checkFlag)
{
    var tmpMenu = _ysp_top.publicObject["menu"];
    var oFlag = false;
    
    if(tmpMenu != null)
    {
        var count = tmpMenu.length;
        for(var i=0;i<count;i++)
        {
            if(checkFlag==1)
            {
                if(tmpMenu[i].id == id && tmpMenu[i].menuUrl != "null" && tmpMenu[i].menuUrl != null && tmpMenu[i].menuUrl.length !==0
                   && tmpMenu[i].isCallBarItem != "2" && tmpMenu[i].isCallBarItem != "1")
                {
                    oFlag = true;
                    i = count;
                }
            }
            else
            {
                if(tmpMenu[i].id == id)
                {
                    oFlag = true;
                    i = count;
                }
            }
        }
    }
    tmpMenu = null;
    return oFlag;
}

//查询菜单执行事件
function doMenuEvent(id)
{
    var tmpMenu = _ysp_top.publicObject["menu"];
    if(tmpMenu != null)
    {
        var count = tmpMenu.length;
        for(var i=0;i<count;i++)
        {
            if(tmpMenu[i].id == id)
            {
                var oTabSet = _ysp_top.publicObject["mainTab"];
                if(oTabSet != null)
                {
                     oTabSet.appendTab(tmpMenu[i].id,tmpMenu[i].menuName,tmpMenu[i].menuUrl,tmpMenu[i].imageUrl);
                     return;
                }
            }
        }
    }
}

//保存公共对象
var publicObject = new Array();
//保存切换系统时必须完成提交操作的窗体句柄
var activeWindow = new Array();
//保存IE新打开窗体的句柄
var subWindow = new Array();
//保存故障消息
var troubleMessage = new Array();
//定时器
var timer;

var mif = new Object();

//故障状态标志位
mif.faultFlag = false;
mif.faultMode = 0; //0－正常模式  其他－故障模式

//标识当前操作区域属于那个系统
publicObject["currentMenuId"] = "default";

//注册公共对象
mif.registerObject = function(objId,obj){
    /*
    if(publicObject[objId] != null)
    {
        return false;
    };
    */
    publicObject[objId] = obj;
    return true;
}

//返回公共对象
mif.getObject = function(objId){
    if(publicObject[objId] == null)
    {
        return null;
    }
    return publicObject[objId];
}

//根据对象编号删除公共对象
mif.removeObject = function(objId){
    if(publicObject[objId] == null)
    {
        return false;
    }
    publicObject[objId] = null;
}

//添加切换系统时必须完成提交操作的窗体句柄
mif.addActiveWindow = function(handle){
    if(handle in activeWindow)
    {
        return;
    }
    activeWindow[handle] = handle;
}

//删除切换系统时必须完成提交操作的窗体句柄
mif.removeActiveWidow = function(handle){
    if(handle in activeWindow)
    {
        delete activeWindow[handle];
        return true;
    }
    return false;
}

//添加IE新打开窗体的句柄
mif.addNewWindow = function(key,handle){
    if(handle in subWindow)
    {
        return;
    }
    subWindow[key] = handle;
}

//删除IE新打开窗体的句柄
mif.removeNewWindow = function(key,handle){
    if(key in subWindow)
    {
        delete subWindow[key];
        return true;
    }
    return false;
}

/*
 * 合并windowRegister.js
 */
//添加系统切换时必须进行提交的窗体
function addActWindow(key,handle)
{
    _ysp_top.mif.addActiveWindow(key,handle);
}

//删除系统切换时必须进行提交的窗体
function removeActWindow(key,handle)
{
    _ysp_top.mif.removeActiveWindow(key,handle);
}

//添加IE新打开窗体的句柄
function addNewWindow(handle)
{
    _ysp_top.mif.addNewWindow(handle);
}

//删除IE新打开的窗体句柄
function removeNewWindow(handle)
{
    _ysp_top.mif.removeNewWindow(handle);
}
/*
 * 合并mainframe.js
 */
//保存快捷键执行事件需要的参数
var oEvent = new Array();
//保存按键keyCode
var keyCode = new Array();

var CSP_CALLCONF = "431118103101";   //呼叫适配菜单ID
var CSP_CALLBAR = "CSPSC";           //接续事件前缀
var CSP_SERVICECONFIG = "431";       //业务配置菜单ID
var CSP_BSF_SYSMENUID = "00";        //系统菜单ID
var CSP_SERVICE = "201";             //服务请求系统菜单
var CSP_BSF_CALLBARID = "101";       //标识是否是接续菜单

keyCode["A"] = "0X65";
keyCode["B"] = "0X66";
keyCode["C"] = "0X67";
keyCode["D"] = "0X68";
keyCode["E"] = "0X69";
keyCode["F"] = "0X70";
keyCode["G"] = "0X71";
keyCode["H"] = "0X72";
keyCode["I"] = "0X73";
keyCode["J"] = "0X74";
keyCode["K"] = "0X75";
keyCode["L"] = "0X76";
keyCode["M"] = "0X77";
keyCode["N"] = "0X78";
keyCode["O"] = "0X79";
keyCode["P"] = "0X80";
keyCode["Q"] = "0X81";
keyCode["R"] = "0X82";
keyCode["S"] = "0X83";
keyCode["T"] = "0X84";
keyCode["U"] = "0X85";
keyCode["V"] = "0X86";
keyCode["W"] = "0X87";
keyCode["X"] = "0X88";
keyCode["Y"] = "0X89";
keyCode["Z"] = "0X90";
keyCode["1"] = "0X49";
keyCode["2"] = "0X50";
keyCode["3"] = "0X51";
keyCode["4"] = "0X52";
keyCode["5"] = "0X53";
keyCode["6"] = "0X54";
keyCode["7"] = "0X55";
keyCode["8"] = "0X56";
keyCode["9"] = "0X57";
keyCode["0"] = "0X48";
keyCode["ENTER"] = "0XD";

//菜单快捷
function menuFastKey(){
    var topMenu = publicObject["_ysp_top"];
    topMenu.document.getElementById("topMenu").firstChild.click();
}

//工具栏快捷键
function toolFastKey(){
    var topMenu = publicObject["_ysp_top"];
    topMenu.document.getElementById("topTool").firstChild.click();
}

function fastKeyParam(ctrlKey,shiftKey,altKey,key,func,isPublic,id){
    this.ctrlKey = ctrlKey;
    this.shiftKey = shiftKey;
    this.altKey = altKey;
    this.key = key;
    this.func = func;
    this.isPublic = isPublic;
    this.id = id;
}

function initFastKey(id,configStr,func,isPublic){
    if(configStr == null || configStr.length ===0)
    {
        return;
    }

    var ctrlKey = false;
    var shiftKey = false;
    var altKey = false;
        	  
    if(configStr.indexOf("ctrl") != -1)
    {
     	ctrlKey = true;
    }
    if(configStr.indexOf("shift") != -1)
    {
     	shiftKey = true;
    }
    if(configStr.indexOf("alt") != -1)
    {
      	altKey = true;
    }
    var oStringArray = configStr.split("+");
    var tmpStr = oStringArray[oStringArray.length-1].toUpperCase();

    var oMenuEvent = new menuFastEvent(id,func,configStr);
    
    var obj = new fastKeyParam(ctrlKey,shiftKey,altKey,tmpStr,oMenuEvent,isPublic,id);
    oEvent.push(obj);
}

function menuFastEvent(id,func,configStr,param){
    this.id = id;
    this.eventer = func;
    this.param = param;
    this.configStr = configStr;
}

menuFastEvent.prototype.doEvent = function(){
    if(this.eventer==null || this.eventer=="null")
    {   
        var tmpMenu = publicObject["menu"];
        if(tmpMenu)
        {
            for(var i=0;i<tmpMenu.length;i++)
            {
                if(tmpMenu[i].fastKey == this.id)
                {
                    this.menuEvent(tmpMenu[i]);
                    return;
                }
            }
        }
    }
    else
    {
        eval(this.eventer+"("+this.param+")");      
    }
}

menuFastEvent.prototype.menuEvent = function(menuObj){
    //接续菜单处理事件,剔除呼叫适配菜单
    if(menuObj.moduleId == CSP_BSF_CALLBARID && menuObj.parentId != CSP_CALLCONF)
    {
        var oAction = publicObject[CSP_CALLBAR];
        if(oAction != null && menuObj.menuUrl != "null")
        {
            oAction.eval(menuObj.menuUrl);
        }
    }
    //需要执行js事件的菜单
    else if(menuObj.isCallBarItem == "2")
    {
        if(menuObj.menuUrl != null)
        {
            eval(menuObj.menuUrl);
        }
        //如果是上下班,需要特殊处理菜单事件
    }
    //打开系统的菜单
    else if(menuObj.parentId == CSP_SERVICECONFIG || menuObj.parentId == CSP_BSF_SYSMENUID)
    {
        //根据选择的系统自动收缩分割条
        var oSclipWindow = _ysp_top.publicObject["sclipWindow"];
        if(menuObj.id  == CSP_SERVICE && oSclipWindow != null)
        {
            oSclipWindow.leftShow();
        }
        else if(oSclipWindow != null)
        {
            oSclipWindow.leftHide();
        }
        //添加子系统菜单
        var oWin = _ysp_top.publicObject["rightWindow"];
        oWin.appendMenuImage(menuObj);
        
        //添加子系统默认的Tab页签
        var oTabSet = _ysp_top.publicObject["mainTab"];
        
        //通过menuUrl找到需要添加的子菜单对象
        var tmpMenu = _ysp_top.publicObject["menu"];
        if(tmpMenu)
        {
            for(var i=0;i<tmpMenu.length;i++)
            {
                if(tmpMenu[i].menuUrl == menuObj.menuUrl && tmpMenu[i] != menuObj)
                {
                     if(oTabSet != null)
                     {
                         oTabSet.appendTab(tmpMenu[i].id,tmpMenu[i].menuName,tmpMenu[i].menuUrl,tmpMenu[i].imageUrl);
                         //将打开的Tab页签添加到工作区管理列表
                         _ysp_top.addOpenTab(menuObj);
                     }
                     break;
                }
            }
        }   
    }
    //其他菜单添加Tab页签操作
    else
    {
        //添加子系统默认的Tab页签
        var oTabSet = _ysp_top.publicObject["mainTab"];
        if(oTabSet != null)
        {
            oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl);
            //将打开的Tab页签添加到工作区管理列表
            _ysp_top.addOpenTab(menuObj);
        }
    }
}

//更改当前选中Tab页面的链接
function setCurrentTabUrl(url)
{
    var oTabSet = _ysp_top.publicObject["mainTab"];
    if(oTabSet)
    {
        oTabSet.refreshCurrentTab(url);
    }
}


//关闭当前选中的Tab页签接口
function closeCurrentTab()
{
    var oTabSet = _ysp_top.publicObject["mainTab"];
    if(oTabSet)
    {
        oTabSet.closeCurrentTab();
    }
}


//关闭工作区时调用，删除列表中的树节点
function clearTree()
{
    var iFrame = document.getElementById("menuSelectFrame");
    iFrame.contentWindow.clearTree();
}

//删除Tab页签时删除打开的工作区列表
function removeTreeNode(name)
{
     var iFrame = document.getElementById("menuSelectFrame");
     iFrame.contentWindow.removeTreeNode(name);
}

//将打开的Tab页签添加到工作区管理列表
function addOpenTab(Obj)
{
    var iFrame = document.getElementById("menuSelectFrame");
    iFrame.contentWindow.addOpenedTab(Obj);
}

//显示菜单选择界面
function showMenuSelect(left,_ysp_top,menus)
{
        var oDiv = document.getElementById("menuSelect");
        if(oDiv)
        {
            oDiv.style.display = "block";
            oDiv.style.left = left;
            oDiv.style._ysp_top = _ysp_top;
        }
        
        //initTree(menus);       
}

//调整菜单选择界面菜单项
function initTree(menus,oCurrentMenu)
{
    var iFrame = document.getElementById("menuSelectFrame");
    iFrame.contentWindow.initTree(menus,oCurrentMenu);
}

//根据默认的菜单顺序进行排序
function menuDefaultOrder(menu)
{
    var temp; //冒泡用临时变量
    var flag = 0; //优化标志
    for(var j=0;j<menu.length;j++)
    {
        for(var i=menu.length-1-j;i>0;i--)
        {
            //体重轻的向上跑
            if( menu[i]["displayNo"] < menu[i-1]["displayNo"])
            {
                temp = menu[i];
                menu[i] = menu[i-1];
                menu[i-1] = temp;
                flag = 1; 
            }
        }
        //当前是否已经完成排序
        if(flag == 0)
        {
            return menu;
        }
    }    
    return menu;
}
        function aLoad(path)
        {    
            var oTop = document.getElementById("topFrame");
            var oMiddle = document.getElementById("middleFrame");
            var oBottom = document.getElementById("bottomFrame");
            var oFlag = 0;
            
            //oTop.src = path + "/mif/mainFrameConfig.action";
            //oBottom.src = path + "/mif/bottomFrame.action";
            //oMiddle.src = path + "/mif/middleFrame.action";  

            oTop.onreadystatechange = function(){           
            /*
            if(oTop.readyState == "uninitialized")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "正在加载接续条......";
            }
            */
            if(oTop.readyState == "loading")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "系统初始化......";
            }
            if(oTop.readyState == "loaded")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "菜单加载完毕";
            }
            
            if(oTop.readyState == "complete")
            {
                showMainFrame();
                oTop.onreadystatechange = null;
            }
            }
            
            oMiddle.onreadystatechange = function(){           
            /*
            if(oMiddle.readyState == "uninitialized")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "工作区初始化......";
            }
            
            if(oMiddle.readyState == "loading")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "正在加载工作区......";
            }
            
            if(oMiddle.readyState == "loaded")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "正在工作区对象......";
            }
            
            if(oMiddle.readyState == "interactive")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "主框架加载完毕.";
            }
            */
            /*
            if(oMiddle.readyState == "complete")
            {
                var CSPSC = publicObject[CSP_CALLBAR];
                //如果选择了签入呼叫中心，则自动执行签入操作
                if (CSPSC&&CSPSC.staffLogin&&CSPSC.staffLogin.signCti) 
                {           
                    try
                    {
                        CSPSC.ccInitService.signIn();
                    }
                    catch(e)
                    {
                    } 
                }                                                
            }
            */
            }
            
            /*
            oBottom.onreadystatechange = function(){           
            
            if(oBottom.readyState == "uninitialized")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "消息状态区初始化......";
            }
            
            if(oBottom.readyState == "loading")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "正在加载消息状态区......";
            }
            
            if(oBottom.readyState == "loaded")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "正在消息状态区公共对象......";
            }
            
            if(oBottom.readyState == "interactive")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "状态栏加载完毕.";
            }
            
            if(oBottom.readyState == "complete")
            {          
            }
            }
            */
            
        }
        
        function showMainFrame()
        {
            //顺序刷新仅在登录是有效，执行过后消除函数痕迹
            document.getElementById("loading").style.width = "0";
            document.getElementById("loading").style.height = "0";
            document.getElementById("loading").style.display = "none";
            document.getElementById("workPlace").style.visibility = "visible";
        }
        

function topReadyState(){           
            /*
            if(oTop.readyState == "uninitialized")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "正在加载接续条......";
            }
            */
            var oTop = document.getElementById("topFrame");
            var oMiddle = document.getElementById("middleFrame");
            var oBottom = document.getElementById("bottomFrame");
            
            if(oTop.readyState == "loading")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "系统初始化......";
            }
            if(oTop.readyState == "loaded")
            {
                document.getElementById("loadContent").firstChild.nodeValue = "菜单加载完毕";
            }
            
            if(oTop.readyState == "complete")
            {
                showMainFrame();
                oTop.onreadystatechange = null;
            }
}

function middleReadyState(){       
            var oMiddle = document.getElementById("middleFrame");    
            if(oMiddle.readyState == "complete")
            {
                var CSPSC = publicObject[CSP_CALLBAR];
                //如果选择了签入呼叫中心，则自动执行签入操作
                if (CSPSC&&CSPSC.staffLogin&&CSPSC.staffLogin.signCti) 
                {           
                    try
                    {
                        CSPSC.ccInitService.signIn();
                    }
                    catch(e)
                    {
                    } 
                }                                                
            }
}

function initTopCallBar()
{
    var callBarFrame = document.getElementById("callBarFrame");    
            if(callBarFrame.readyState == "complete")
            {
                var CSPSC = publicObject[CSP_CALLBAR];
                //如果选择了签入呼叫中心，则自动执行签入操作
                if (CSPSC&&CSPSC.staffLogin&&CSPSC.staffLogin.signCti) 
                {           
                    try
                    {
                        CSPSC.ccInitService.signIn();
                    }
                    catch(e)
                    {
                    } 
                }                                                
            }
} 

/*
 * 合并common.js
 */

function defined(object)
{
  return typeof(object) != "undefined";
}

String.prototype.dynamic = function()
{
  var matchs = this.match(/\{\d\}/g);
  var i18nMessage = this;
  for(var i = 0; i < matchs.length; i++)
  {
    var str = matchs[i];
    if (defined(str))
      if (defined(arguments[i]))
        i18nMessage = i18nMessage.replace(str, arguments[i])
  }
  return i18nMessage;
}

function readClientIp(fileName) 
{
	try 
	{
		var fso = new ActiveXObject("Scripting.FileSystemObject");		
		if (fso.FileExists(fileName)) 
		{	
			var file = fso.OpenTextFile(fileName, 1);
			var clientIp = file.ReadLine();
			file.Close();
			
			if(clientIp != null && clientIp != 'undefined' && clientIp != undefined)
			{
				var tmpArray = clientIp.split("=");
				if(tmpArray != null && tmpArray.length > 1)
				{
					clientIp = tmpArray[1];
				}
			}
			return clientIp;
		}
	}
	catch (ex) 
	{
		return null;
	}
}

function writeClientIp(clientIp, fileName) 
{
	try 
	{
		var fso = new ActiveXObject("Scripting.FileSystemObject");
		
		if (fso.FileExists(fileName)) 
		{	
			var file = fso.GetFile(fileName);
			file.Delete();
		}

		var createHandle = fso.CreateTextFile(fileName);
		createHandle.Close();
			
		var openHandle = fso.OpenTextFile(fileName, 8);
		var clientIpString = "cspClientIp=" + clientIp;
		openHandle.WriteLine(clientIpString);
		openHandle.Close();
	}
	catch (ex) 
	{
		//return null;
	}
}

function isRealIp(clientIp, ips)
{
	var rsltArray = ips.split(";");
     		
    for(var ipTmp in rsltArray)
    {
    	if(clientIp == rsltArray[ipTmp])
    	{
    		return true;
    	}
    }
    
    return false;
}

function getLocalIPAddress()
{	
    var obj = null;
    var rslt = "";
    var fileName = "C:\\cspClientIp.txt";
    try
    {
    	rslt = _ysp_top.CLIENT_IP_STRING;
    	if(rslt != null && rslt != 'undefined' && rslt != undefined && rslt != "")
    	{
    		return rslt;
    	}
    		
        obj = new ActiveXObject("rcbdyctl.Setting");        
        rslt = obj.GetIPAddress;
        
        //if exists many ips:
        if(rslt.indexOf(";") > 0)
        {
        	//read from file:
        	var clientIp = readClientIp(fileName); 
        	if(clientIp != null)
        	{
        		 //somebody changed the ip in the file, but not the same with the real ip:
        		var isRealIpFlag = isRealIp(clientIp, rslt);
        		if(isRealIpFlag)
        		{
        			rslt = clientIp;
        		}
        		else
        		{
        			var rsltArray = rslt.split(";");
        			alert("位于" + fileName + "的文件被修改，获取的IP: " + clientIp + "和您的实际IP: " + rslt + "不一致! 请重新选择:");
        			//rslt = rsltArray[0];
		        	var url = "/" +window.location.pathname.split('/')[1]+ "/ngportal/clientIp.action?clientIps=" + rslt;
		        	var features = "dialogWidth=400px;dialogHeight=150px;status=no;scroll=no";
	        	    var rtnVal = window.showModalDialog(url,null,features);
	        	     //select one ip:
	        	    if(rtnVal != null && rtnVal != undefined && rtnVal != 'undefined')
	        	    {
		        	    rslt = rtnVal;
		        	    //write ip to file:
		        	    writeClientIp(rslt, fileName);
		        	    alert("您选择了IP: " + rslt + ", 此IP将保存在" + fileName + "中");
	    	        }
	    	        //select no ip, default: the first one:
	    	        else
	    	        {
	    	    	    var rsltArray = rslt.split(";");
	    	    	    rslt = rsltArray[0];
	    	    	    alert("系统检测到您有多个IP，但是您没有选择IP用来访问CSP系统，将默认使用IP: " + rsltArray[0]);
	    	        }
        		}
        	}
        	//no file, or no correct ip:
        	else
        	{
        		//open select ip page:
	        	var url = "/" +window.location.pathname.split('/')[1]+ "/ngportal/clientIp.action?clientIps=" + rslt;
	        	var features = "dialogWidth=400px;dialogHeight=150px;status=no;scroll=no";
	        	var rtnVal = window.showModalDialog(url,null,features);
	        	
	        	//select one ip:
	        	if(rtnVal != null && rtnVal != undefined && rtnVal != 'undefined')
	        	{
		        	rslt = rtnVal;
		        	//write ip to file:
		        	writeClientIp(rslt, fileName);
		        	alert("您选择了IP: " + rslt + ", 此IP将保存在" + fileName + "中");
	    	    }
	    	    //select no ip, default: the first one:
	    	    else
	    	    {
	    	    	var rsltArray = rslt.split(";");
	    	    	rslt = rsltArray[0];
	    	    	alert("系统检测到您有多个IP，但是您没有选择IP用来访问CSP系统，将默认使用IP: " + rslt);
	    	    }
    	    }
    	 }
        
        _ysp_top.CLIENT_IP_STRING = rslt;
        
        obj = null;
    }
    catch(e)
    {
        //exception
    }
    
    //alert("final: " + rslt);
    return rslt;
}

//just for baseline:
/*
function checkphone(phoneNumber)
{
  var validMobiles = new Array("134","135","136","137","138","139","150","158","159");
  if(phoneNumber.length != 11)
  {
   alert("您输入的手机号码长度不是11！");
   return false;
  }
  if(!isMatch(phoneNumber, "^[0-9-]+$"))
  {
   alert("请输入数字！");
   return false;
  }
  var isMobile = false;
  for(i=0; i<validMobiles.length; i++)
  {
   if(phoneNumber.indexOf(validMobiles[i])==0)
   {
    isMobile = true;
    break;
   }
  }
  if(!isMobile){
   alert("不是移动的号码！");
  }
  return isMobile;
 }
*/
//for customization:
function checkphone(phoneNumber)
{
  var patrn = /^\+*(86)*((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1})){1}[0-9]{8}$/;
  var isMobile =  patrn.test(phoneNumber);
  if(!isMobile){
   alert("不是移动的号码！");
  }
  return isMobile;
 }
  
 //判断一个字符串是否匹配一个正则表达式
 //   ^\w+[@]\w+[.]\w+$       E-Mail地址
 //   ^[0-9-]+$               数字
 function isMatch(Str, Patrn)
 {
   var re = new RegExp(Patrn,"gim");
   return re.test(Str);
 }
 
 /*
  * 合并pub_func.js
  */
/**
 * 设置form表单对象所有名为name的chekcbox元素全部被选中或全部不被选中
 * @param form 表单对象
 * @param checked true(选中)/false(不选中)
 * @param name checkbox元素的名字,字符串类型
 */
 function setBoxChecked(form, checked, name)
 {
    if(form == null)
    {
       return;
    }
    //获取form中的元素数
    var count = form.elements.length;
    if(count!=0)
    {        
       for(var i=0; i<count; i++)
       {
          var e =form.elements[i]; 
          if(e.type=="checkbox" && e.name==name)
          {
            if(e.disabled != true)
            {
               e.checked = checked;
            }
          }
       }
    }
 }
 
 /**
 * 去除字符串str头尾的空格
 * @param str 字符串
 * @return str去除头尾空格后的字符串。
 */
 /*
function trim(str)
{
    if(str == null) return "" ;

    // 去除前面所有的空格
    while( str.charAt(0)  == ' ' )
    {
        str = str.substring(1,str.length);
    }
    
    // 去除后面的空格
    while( str.charAt(str.length-1)  == ' ' )
    {
        str = str.substring(0,str.length-1);
    }
    return str ;
}
*/

function trim( value ) {
	
	var re = /\s*((\s*\S+)*)\s*/;
	return value.replace(re, "$1");
	
}

/**
 * checkbox
 */
var isChecked = false;
function setBoxChecked(contentId)
{
	var content = document.getElementById("contentId");
	if(!content)
	{
		content = document;
	}
	var checkeBoxs = content.getElementsByTagName("input");
	if(isChecked)
	{
		for(var i=0; i<checkeBoxs.length;i++)
		{
			if(checkeBoxs[i].type=="checkbox")
			{
				checkeBoxs[i].checked = false;
			}
		}
		isChecked = false;
	}
	else
	{
		for(var i=0; i<checkeBoxs.length;i++)
		{
			if(checkeBoxs[i].type=="checkbox")
			{
				checkeBoxs[i].checked = true;
			}
		}
		isChecked = true;
	}	
}
 
 
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
} 

function checkInteger(obj)
{
	var object = obj;
	var value = object.value;
	//alert(value);
	if(!(/\d*$/.test(value)))
	{
		alert ("the input must be integer.");
		return ;	
	}
}

function checkIntegerLength(obj,length)
{
	
}
//选择用户
function chooseStaffID(actionUrl,controlObject)
{
   var returnValue = window.showModalDialog(actionUrl,"", "dialogWidth:700px;dialogHeight:410px;center:yes");
   if (returnValue)
   {
   /*
		var name = controlObjectName.value;			
		if(name!='')
		{
			var ss = name.substr(name.length-1,name.length);
			if(ss!=",")
			{
				controlObjectName.value = controlObjectName.value + ",";
			}
		}
		var id = controlObject.value;			
		if(id!='')
		{
			var ss = id.substr(id.length-1,id.length);
			if(ss!=",")
			{
				controlObject.value = controlObject.value + ",";
			}
		}
		*/
		if(controlObject.value.length>1)
		{
			var ss = controlObject.value.charAt(controlObject.value.length-1);	
			if(ss!=',')
			{
				controlObject.value = controlObject.value+",";
			}
		}
		var value;
   		for(var i=0;i<returnValue.length;i++){
   		/*
   				var opt = new Option();
   				opt.value = returnValue[i].id
				opt.text = returnValue[i].name;
				receSelect.add(opt);
		*/	
			value = returnValue[i].name
			if(controlObject.value.indexOf(value)<0)
	   		{
	   			controlObject.value += value + ",";
	   		}
	   	}
   }
};
 //选择用户修改密码
function chooseUserId(contextpath,controlObject,controlObjectName)
{
   var returnValue = window.showModalDialog(contextpath + "/ucp/stfPublicQueryPopup.action?checkType=redio","", "dialogWidth:700px;dialogHeight:360px;center:yes");
   if (returnValue)
	{
	   	controlObject.value = returnValue[0].id;
	   	controlObjectName.value = returnValue[0].name ;
   }
 };
 //选择工作组
function chooseGroupID(actionUrl,controlObject)
{
	
   var returnValue = window.showModalDialog(actionUrl,"", "dialogWidth:300px;dialogHeight:500px;center:yes");
   if(returnValue){
  		/*
		var name = controlObjectName.value;			
		if(name!='')
		{
			var ss = name.substr(name.length-1,name.length);
			if(ss!=",")
			{
				controlObjectName.value = controlObjectName.value + ",";
			}
		}
		var id = controlObject.value;			
		if(id!='')
		{
			var ss = id.substr(id.length-1,id.length);
			if(ss!=",")
			{
				controlObject.value = controlObject.value + ",";
			}
		}
		*/
		if(controlObject.value.length>1)
		{
			var ss = controlObject.value.charAt(controlObject.value.length-1);	
			if(ss!=',')
			{
				controlObject.value = controlObject.value+",";
			}
		}
		var value;
	   	for(var i=0;i<returnValue.length;i++){
	   		/*
	   		var opt = new Option();
   			opt.value = returnValue[i].id
			opt.text = returnValue[i].name;
			receGroupSelect.add(opt);
	   		*/
	   		value = returnValue[i].id+"("+returnValue[i].name+")";
	   		if(controlObject.value.indexOf(value)<0)
	   		{
	   			controlObject.value += value + ",";
	   		}
	   	}
   }
   
 };
function first(thisform)
{
	thisform.pageNum.value = 1;
	thisform.action = thisform.actionUrl.value;
	thisform.target = "_self";
	thisform.submit();
}
function prep(thisform)
{
	if(thisform.pageNum.value=="")
	{
		thisform.pageNum.value = 1;
	}
	var num = parseInt(thisform.pageNum.value,10);
	thisform.pageNum.value = num-1;
	thisform.action = thisform.actionUrl.value;
	thisform.target = "_self";
	thisform.submit();
};
function next(thisform)
{
	if(thisform.pageNum.value=="")
	{
		thisform.pageNum.value = 1;
	}
	var num = parseInt(thisform.pageNum.value,10);
	thisform.pageNum.value = num+1;
	thisform.action = thisform.actionUrl.value;
	thisform.target = "_self";
	thisform.submit();
};
function last(thisform)
{
	thisform.pageNum.value = thisform.totalPageNum.value;
	thisform.action = thisform.actionUrl.value;
	thisform.target = "_self";
	thisform.submit();
};
function showPageButton(thisform)
{
	var pagenum = parseInt(thisform.pageNum.value,10);
	var totalpagenum = parseInt(thisform.totalPageNum.value,10);
	if(pagenum==1)
	{
		thisform.firstButton.disabled = true;
		thisform.prepButton.disabled = true;
		if(totalpagenum<=1){
			thisform.nextButton.disabled = true;
			thisform.lastButton.disabled = true;
		}else{
			thisform.nextButton.disabled = false;
			thisform.lastButton.disabled = false;
		}
	}else if(pagenum==totalpagenum)
	{
		if(totalpagenum==1)
		{
			thisform.firstButton.disabled = true;
			thisform.prepButton.disabled = true;
		}else{
			thisform.firstButton.disabled = false;
			thisform.prepButton.disabled = false;
		}
		thisform.nextButton.disabled = true;
		thisform.lastButton.disabled = true;
	}else{
		thisform.firstButton.disabled = false;
		thisform.prepButton.disabled = false;
		thisform.nextButton.disabled = false;
		thisform.lastButton.disabled = false;
	}
};
function turnPage(thisform){
	if(thisform.toPage.value=='')
	{
		alert("请输入查询的页数");
		return;
	}
	if(isNaN(thisform.toPage.value))
	{	
		alert("请输入数字");
		return;
	}
	var num = parseInt(thisform.toPage.value,10);
	var pagenum = parseInt(thisform.pageNum.value,10);
	var totalpagenum = parseInt(thisform.totalPageNum.value,10);
	if(num<1||num>totalpagenum){
		alert("请输入[1,"+totalpagenum+"]范围内的数字");
		return;
	}
	thisform.target = "_self";
	thisform.pageNum.value = num;
	thisform.submit();
};
function exportChangeRadio(thisform,type)
{
	if(type=='false')
	{
		thisform.startPage.disabled = true;
		thisform.endPage.disabled = true;
	}else{
		thisform.startPage.disabled = false;
		thisform.endPage.disabled = false;
	}
};
function getStrLen(sData) {
	var nCount = 0;
	var nLenByte = sData.length;
	for (nPos = 0; nPos < nLenByte; nPos++) {
		if (sData.charCodeAt(nPos) > 256) {
			nCount = nCount + 2;
		} else {
			nCount = nCount + 1;
		}
	}
	return nCount;
};
function compareDate(date1,date2)
{
	if(date2==""){
		return -1;
	}
	var yyyy = date2.substring(0,4);
	var MM = parseInt(date2.substring(5,7),10)-1;
	var dd = date2.substring(8,10);
	var hh = date2.substring(11,13);
	var mm = date2.substring(14,16);
	var ss = date2.substring(17,19);
	var d2 = new Date(yyyy,MM,dd,hh,mm,ss).getTime();
	//alert(yyyy+"-"+MM+"-"+dd+" "+hh+":"+mm+":"+ss);
	//alert(d2);
	var d1 = date1.getTime();
	//alert(d1);
	if(d1==d2){
		return 0;
	}else if(d1>d2){
		return -1;
	}else{
		return 1;
	}
};
function compareDate2(date1,date2)
{
	
	if(date2==""||date1==""){
		return -1;
	}
	
	var yyyy1 = date1.substring(0,4);
	var MM1 = parseInt(date1.substring(5,7),10)-1;
	var dd1 = date1.substring(8,10);
	var hh1 = date1.substring(11,13);
	var mm1 = date1.substring(14,16);
	var ss1 = date1.substring(17,19);
	var d1 = new Date(yyyy1,MM1,dd1,hh1,mm1,ss1).getTime();
	//alert(yyyy1+"-"+MM1+"-"+dd1+" "+hh1+":"+mm1+":"+ss1);
	
	var yyyy2 = date2.substring(0,4);
	var MM2 = parseInt(date2.substring(5,7),10)-1;
	var dd2 = date2.substring(8,10);
	var hh2 = date2.substring(11,13);
	var mm2 = date2.substring(14,16);
	var ss2 = date2.substring(17,19);
	var d2 = new Date(yyyy2,MM2,dd2,hh2,mm2,ss2).getTime();
	//alert(yyyy2+"-"+MM2+"-"+dd2+" "+hh2+":"+mm2+":"+ss2);
	
	if(d1==d2){
		return 0;
	}else if(d1>d2){
		return -1;
	}else{
		return 1;
	}
};
//屏蔽表单重复提交
function setSubmitButtonStatus(btnName, btnStatus) {
	if (btnStatus == true) {
		document.all(btnName).disabled = true;
	} else {
		document.all(btnName).disabled = false;
	}
};
//全选	
function selectAllCheckBox(selectAllObj,checkBoxName)
{
	var nodes = document.getElementsByName(checkBoxName);
		
	if(nodes=="undifined") return;	
	var ojbSelected=selectAllObj.checked;	
	if(nodes.length=="undifined")
	{
		nodes.checked = ojbSelected;
	}
	else
	{
		for(i=0; i<nodes.length; i++)
		{
			if(!nodes[i].disabled){
				nodes[i].checked = ojbSelected;
			}
		}
	}
	onCheckBoxChange(checkBoxName);
};
function onCheckBoxChange(itemId)
{
	var count=getCheckedCount(itemId);
	switch(count)
	{
		case 0:
			if($("deleteBtn"))
			{
				$("deleteBtn").disabled=true;
			}
			if($("exportBtn"))
			{
				$("exportBtn").disabled=true;
			}
			if($("monitorBtn"))
			{
				$("monitorBtn").disabled=true;
			}
			if($("printBtn"))
			{
				$("printBtn").disabled=true;
			}
			if($("resumeBtn"))
			{
				$("resumeBtn").disabled=true;
			}
			break;
		case 1:
			if($("deleteBtn"))
			{
				$("deleteBtn").disabled=false;
			}
			if($("exportBtn"))
			{
				$("exportBtn").disabled=false;
			}
			if($("monitorBtn"))
			{
				$("monitorBtn").disabled=false;
			}
			if($("printBtn")){
				$("printBtn").disabled=false;
			}
			if($("resumeBtn"))
			{
				$("resumeBtn").disabled=false;
			}
			break;
		default:
			if($("deleteBtn"))
			{
				$("deleteBtn").disabled=false;
			}
			if($("exportBtn"))
			{
				$("exportBtn").disabled=false;
			}
			if($("monitorBtn"))
			{
				$("monitorBtn").disabled=false;
			}
			if($("printBtn"))
			{
				$("printBtn").disabled=false;
			}
			if($("resumeBtn"))
			{
				$("resumeBtn").disabled=false;
			}
	}	
}
function getCheckedCount(checkBoxName)
{
    var nodes = document.getElementsByName(checkBoxName);
	
	if(nodes=="undifined") return 0;
	

	if(nodes.length=="undifined")
	{
		if(nodes.checked) return 1;
		else return 0;
	}
	
	var count=0;
	for(i=0; i<nodes.length; i++)
	{
		if(nodes[i].checked) count++;
	}
	return count;
}
function sortLoad()
{
	var orderFieldName=$("order.propertyName").value;
	if(orderFieldName!="")
	{
		var imgObj=$(orderFieldName).childNodes[1];
		if($("order.ascending").value=="true")
		{
			imgObj.src="<isap:resource src='images/sortAsc.gif'></isap:resource>";
		}
		else
		{
			imgObj.src="<isap:resource src='images/sortDesc.gif'></isap:resource>";
		}
	}
};
function returnBack(thisform,actionUrl)
{
	thisform.action = actionUrl;
	thisform.target = "_self";
	thisform.submit();
};
function openNewWindow(actionUrl)
{
	var spec = "resizable=yes,toolbar=no,scrollbars=yes,status=no,left=100,_ysp_top=100,width=840px,height=600px" ;
	window.open(actionUrl,"_blank",spec);
	
};
/**
 * 打开消息、便笺中的连接
 * @param tabcode	tab编号
 * @param tabname   tab名词
 * @param url		连接地址
 * @param img       图片
 */
function showurl(tabcode,tabname,url,img)
{
      try
      {
        var tabset = _ysp_top.publicObject["mainTab"];
        tabset.appendTab(tabcode,tabname,url,img);
      }
      catch(e)
      {
      	window.open(url);
      }
}
/**
 *从ftp上下载文件
 *@param downloadform	form表单
 *@param filePath	文件路径
 *@param fileName	文件名
 */
function download(downloadform,filePath,fileName)
{
	/*
	downloadform.filePath.value = filePath;
	downloadform.fileName.value= fileName;
	downloadform.target = "_blank";
	if(downloadform.formAction){
		downloadform.action = downloadform.formAction.value;
	}
	downloadform.submit();*/
	var openParam = "directories=no,toolbar=no,location=no,resizable=1,scrollbars=yes,left=200,_ysp_top=100,width=600,height=400";
	var winTitle ="";
	var theUrl = downloadform.action+"?filePath="+encode(filePath)+"&fileName="+encode(fileName);
	var WinT = window.open(theUrl, winTitle, openParam);
	WinT.focus();
}
/**
 * 取消操作，关闭当前tab页，回到上一个tab页
 */
function cancelAction()
{
	var mainWorkSpace = _ysp_top.publicObject[$("tableset_id").value];
	var oName = mainWorkSpace.sSelectedTabCode;
	mainWorkSpace.removeTabByCode(oName);
};
function openNewActionInSelf(thisform,url){
	thisform.action = url;
	thisform.target = "_self";
	thisform.submit();
};
function omitLength(str1,length)
{
	if(str1==null)
		return "";
	if(str1.length>length)
		return str1.substring(0,length)+"...";
	else
		return str1;
};
/**
 * 包装接续写客户端日志接口
**/
function wClientLog(log)
{
    var oChfApi = null;
	if(_ysp_top != null && _ysp_top.publicObject != null && _ysp_top.publicObject["CSPSC"] != null)
	{
	    oChfApi = _ysp_top.publicObject["CSPSC"].chfApi;
	}
	if(oChfApi != null)
	{
	    try
	    {
	        oChfApi.writeLogToFile("c:\\ccslogs\\bsf_mif.log",log);
	    }
	    catch(e)
	    {}
	}
	oChfApi=null;
}
function showKnowledgeByUrl(urlType, Id, param)
{
	var openUrl = "";
	try
	{
		urlType = parseInt(urlType);
	}
	catch(e)
	{
		
	}
	var context = location.href;
	var pos = context.indexOf("//");
	if(pos>0){
		context = context.substring(pos+2);
	}
	pos = context.indexOf("/");
	if(pos>0)
	{
		context = context.substring(pos+1);
	}
	pos = context.indexOf("/");
	if(pos>0)
	{
		context = context.substring(0,context.indexOf("/"));
	}
	openUrl =  "/"+context+"/kbs/showKng.action?kngId="+ Id + "&kngTblFlag=0&buttonFlag=true&articleFlag=true&showType=1";
	
	var screenLeft = 180;
	var width = parseInt(window.screen.availWidth) - 20 - screenLeft;
	var height = parseInt(window.screen.availHeight)-60;
	var spec = "";
	var isIEType = true;
	if(openWindow(isIEType))
	{
		spec = "location=no,titlebar=no,toolbar=no,menubar=no,scrollbars=no,resizable=yes,status=no,left=" + screenLeft 
			 	+ ",_ysp_top=0,width=" + width + ",height=" + height;
	}
	else
	{
		spec = "location=no,titlebar=no,toolbar=no,menubar=no,scrollbars=no,resizable=yes,status=no,left=" + screenLeft
		        + ",_ysp_top=0,width=" + width + ",height=" + height;
	}
	
	var WinT = window.open(openUrl, Id, spec);
	WinT.focus();	
	openUrl = null;
}
/**
 *判断浏览器是否IE7  是：true 否：false
 */
function openWindow(isIEType)
{
   //判断是否IE7，需要兼容IE6打开是提供前进回退按钮 
   if(navigator.appName == "Microsoft Internet Explorer") 
   { 
     if(navigator.appVersion.match(/7./i)!='7.') 
   	 { 
       isIEType = false;
     }   	
   }   
   return isIEType; 
}
/*
 * 合并logon.js
 */

/**
 * logon js is deal with logon page event.
 */
function logon(passwordMinLength, passwordMaxLength, passwordRegulation, userNameLength) {
	this.object = {};
	this.passwordMinLength = passwordMinLength;
	this.passwordMaxLength = passwordMaxLength;
	this.passwordRegulation = passwordRegulation;
	this.userNameLength = userNameLength;
	/*
	 * checkValue function is to check user input.
	 */
}
logon.prototype.checkValue = function () {
	var userName = document.getElementById("staffNo");
	var password = document.getElementById("password");
		
		//if userName is not input, to notice user input userName.
	if (userName.value.length === 0 || userName.value.length > this.userNameLength) {
		window.alert("\u7528\u6237\u540d\u4e0d\u80fd\u4e3a\u7a7a\u3002\u8BF7\u91CD\u65B0\u8F93\u5165\u3002");
		userName.focus();
		return false;
	}
		
		//if pasword is not input, to notice user input password.
	if (password.value.length === 0) {
		window.alert("\u5BC6\u7801\u4E0D\u80FD\u4E3A\u7A7A\u3002\u8BF7\u91CD\u65B0\u8F93\u5165\u3002");
		password.focus();
		return false;
	}
	/*
	if (password.value.length < this.passwordMinLength || password.value.length > this.passwordMaxLength) {
		window.alert("\u5bc6\u7801\u5fc5\u987b\u5728" + this.passwordMinLength + "\u4f4d\u548c" + this.passwordMaxLength + "\u4f4d\u4e4b\u95f4\u3002\u8bf7\u4ece\u65b0\u8f93\u5165\u3002");
		password.focus();
		return false;
	}
	*/
	return true;
};
logon.prototype.checkPhone = function () {
	var cellphone = document.getElementById("cellphone");
	var value = cellphone.value;
	if (!(/\d*$/.test(value))) {
		alert("\u7535\u8bdd\u53f7\u7801\u5fc5\u987b\u4e3a\u6570\u5b57\u3002");
		cellphone.focus();
		return false;
	}
	if (value.length > 20 ) {
		alert("\u7535\u8bdd\u53f7\u7801\u6700\u5927\u957f\u5ea6\u4e0d\u80fd\u8d85\u8fc720\u4f4d\uff01");
		cellphone.focus();
		return false;
	}
	return true;
};
var vLogon = new logon(7, 20, "regulation.xml", 20);
function changeAdvance() {
	var loginType = document.getElementById("loginType");
	var loginStatus = document.getElementById("loginStatus");
	var loginPhone = document.getElementById("loginPhone");
	var checkArea = document.getElementById("checkArea");
	var advance = document.getElementById("login_advance");
	if (advance.value == "\u9ad8\u7ea7\u2193") {
		changeLoginType();
		loginType.style.display = "block";
		loginStatus.style.display = "block";
		checkArea.style.display = "block";
		advance.value = "\u9ad8\u7ea7\u2191";
	} else {
		loginPhone.style.display = "none";
		loginType.style.display = "none";
		loginStatus.style.display = "none";
		checkArea.style.display = "none";
		advance.value = "\u9ad8\u7ea7\u2193";
	}
}
function changeLoginType() {
	var loginTypeSelect = document.getElementById("loginTypeSelect");
	var loginPhone = document.getElementById("loginPhone");
	var openEyeAccount = document.getElementById("openEyeA");
	var openEyePassword = document.getElementById("openEyeP");
	if (loginTypeSelect.value == "4") {
		loginPhone.style.display = "block";
	} else {
		loginPhone.style.display = "none";
	}
	
	if(loginTypeSelect.value == "6")
	{
	    openEyeAccount.style.display = "block";
	    openEyePassword.style.display = "block";
	}
	else
	{
	   openEyeAccount.style.display = "none";
	   openEyePassword.style.display = "none";
	}
}
function onsignAcd() {
	var signAcd = document.getElementById("signAcd");
	var signCti = document.getElementById("signCti");
	var callCenter = document.getElementById("callCenter");
	var vdnNo = document.getElementById("vdnNo");
	var select_cc = document.getElementById("select_cc");
	var select_vdn = document.getElementById("select_vdn");
	
	if (signAcd.checked == true) {
		signCti.checked = true;
		if(select_vdn.options.length>1 || select_cc.options.length>1)
		{
		    callCenter.style.display = "block";
	        vdnNo.style.display = "block";
	    }
	}
}
function onunsignCti() {
	var signAcd = document.getElementById("signAcd");
	var signCti = document.getElementById("signCti");
	var callCenter = document.getElementById("callCenter");
	var vdnNo = document.getElementById("vdnNo");
	var select_cc = document.getElementById("select_cc");
	var select_vdn = document.getElementById("select_vdn");
	
	if (signCti.checked == false) {
		signAcd.checked = false;
		callCenter.style.display = "none";
		vdnNo.style.display = "none";
	}
	else
	{
	    if(select_vdn.options.length>1 || select_cc.options.length>1)
		{
		    callCenter.style.display = "block";
	        vdnNo.style.display = "block";
	    }
	}
}

 /**
 * 去除字符串str头尾的空格
 * @param str 字符串
 * @return str去除头尾空格后的字符串。
 */
function trim(str)
{
    if(str == null) return "" ;

    // 去除前面所有的空格
    while( str.charAt(0)  == ' ' )
    {
        str = str.substring(1,str.length);
    }
    
    // 去除后面的空格
    while( str.charAt(str.length-1)  == ' ' )
    {
        str = str.substring(0,str.length-1);
    }
    return str ;
}

function login() {
	if (!vLogon.checkValue()) {
		return;
	}
	//var signCti = document.getElementById("signCti");
	//var loginPhone = document.getElementById("loginTypeSelect").value;
	/*
	if (signCti.checked == true && loginPhone == 4) {
		if (!vLogon.checkPhone()) {
			return;
		}
	}
	*/
	var div = document.createElement("div");
	div.setAttribute("id", "changeduty_modleDiv");
	div.setAttribute("align", "center");
	div.style.zIndex = 9999;
	div.style.position = "absolute";
	div.style._ysp_top = 0;
	div.style.left = 0;
	div.style.width = "100%";
	div.style.height = "100%";
	div.style.filter.progid = "DXImageTransform.Microsoft.Alpha(opacity=0)";
	var table = "<table id='modleTable' style='position:absolute;_ysp_top:0;right:0' bgColor='#e7eff2' width='150' height='10'>";
	table += "<tr height=0>";
	table += "<td align='right'>";
	table += "\u767B\u5F55\u4E2D......";
	table += "</td>";
	table += "</tr>";
	table += "</table>";
	div.innerHTML = table;
	document.body.appendChild(div);
	//alert(1);
	//alert(window == _ysp_top);
	var login_submit = document.getElementById("login_submit");
	var login_reset = document.getElementById("login_reset");
	var login_cance = document.getElementById("login_cance");
	//var login_advance = document.getElementById("login_advance");
	//alert(login_submit+":"+login_reset+":"+login_advance);
	login_submit.disabled = true;
	login_reset.disabled = true;
	if(login_cance!=null)
	{
		login_cance.disabled = true;
	}
	//login_advance.disabled = true;	
	//alert(111111111);
	//alert(document.loginForm.action);
	
	var staffNoObj = document.getElementById("staffNo");
	if(staffNoObj != null)
	{
		var staffNo = staffNoObj.value;
		staffNoObj.value = trim(staffNo);
	}
	document.loginForm.submit();
}

/*
 * 合并xmlextras.js
 */
//<script>
//////////////////
// Helper Stuff //
//////////////////

// used to find the Automation server name
function getDomDocumentPrefix() {
	if (getDomDocumentPrefix.prefix)
		return getDomDocumentPrefix.prefix;
	
	var prefixes = ["MSXML2", "Microsoft", "MSXML", "MSXML3"];
	var o;
	for (var i = 0; i < prefixes.length; i++) {
		try {
			// try to create the objects
			o = new ActiveXObject(prefixes[i] + ".DomDocument");
			return getDomDocumentPrefix.prefix = prefixes[i];
		}
		catch (ex) {};
	}
	
	throw new Error("Could not find an installed XML parser");
}

function getXmlHttpPrefix() {
	if (getXmlHttpPrefix.prefix)
		return getXmlHttpPrefix.prefix;
	
	var prefixes = ["MSXML2", "Microsoft", "MSXML", "MSXML3"];
	var o;
	for (var i = 0; i < prefixes.length; i++) {
		try {
			// try to create the objects
			o = new ActiveXObject(prefixes[i] + ".XmlHttp");
			return getXmlHttpPrefix.prefix = prefixes[i];
		}
		catch (ex) {};
	}
	
	throw new Error("Could not find an installed XML parser");
}

//////////////////////////
// Start the Real stuff //
//////////////////////////


// XmlHttp factory
function XmlHttp() {}

XmlHttp.create = function () {
	try {
		if (window.XMLHttpRequest) {
			var req = new XMLHttpRequest();
			
			// some versions of Moz do not support the readyState property
			// and the onreadystate event so we patch it!
			if (req.readyState == null) {
				req.readyState = 1;
				req.addEventListener("load", function () {
					req.readyState = 4;
					if (typeof req.onreadystatechange == "function")
						req.onreadystatechange();
				}, false);
			}
			
			return req;
		}
		if (window.ActiveXObject) {
			return new ActiveXObject(getXmlHttpPrefix() + ".XmlHttp");
		}
	}
	catch (ex) {}
	// fell through
	throw new Error("Your browser does not support XmlHttp objects");
};

// XmlDocument factory
function XmlDocument() {}

XmlDocument.create = function () {
	try {
		// DOM2
		if (document.implementation && document.implementation.createDocument) {
			var doc = document.implementation.createDocument("", "", null);
			
			// some versions of Moz do not support the readyState property
			// and the onreadystate event so we patch it!
			if (doc.readyState == null) {
				doc.readyState = 1;
				doc.addEventListener("load", function () {
					doc.readyState = 4;
					if (typeof doc.onreadystatechange == "function")
						doc.onreadystatechange();
				}, false);
			}
			
			return doc;
		}
		if (window.ActiveXObject)
			return new ActiveXObject(getDomDocumentPrefix() + ".DomDocument");
	}
	catch (ex) {}
	throw new Error("Your browser does not support XmlDocument objects");
};

// Create the loadXML method and xml getter for Mozilla
if (window.DOMParser &&
	window.XMLSerializer &&
	window.Node && Node.prototype && Node.prototype.__defineGetter__) {

	// XMLDocument did not extend the Document interface in some versions
	// of Mozilla. Extend both!
	XMLDocument.prototype.loadXML = 
	Document.prototype.loadXML = function (s) {
		
		// parse the string to a new doc	
		var doc2 = (new DOMParser()).parseFromString(s, "text/xml");
		
		// remove all initial children
		while (this.hasChildNodes())
			this.removeChild(this.lastChild);
			
		// insert and import nodes
		for (var i = 0; i < doc2.childNodes.length; i++) {
			this.appendChild(this.importNode(doc2.childNodes[i], true));
		}
	};
	
	
	/*
	 * xml getter
	 *
	 * This serializes the DOM tree to an XML String
	 *
	 * Usage: var sXml = oNode.xml
	 *
	 */
	// XMLDocument did not extend the Document interface in some versions
	// of Mozilla. Extend both!
	XMLDocument.prototype.__defineGetter__("xml", function () {
		return (new XMLSerializer()).serializeToString(this);
	});
	Document.prototype.__defineGetter__("xml", function () {
		return (new XMLSerializer()).serializeToString(this);
	});
}
/*
 * 合并pubError.js
 */
var WINDOW = window;
if(WINDOW._ysp_top)
{
	WINDOW = window._ysp_top;
}

var SHOW_ERROR_MESSAGE_FLAG = false;

var DEFAULT_TIME_OUT = 0;
function Exception(errorCode,cause,values)
{
	this.errorCode = errorCode;
	this.cause = cause;
	this.values = values;

}

Exception.prototype.showError = function()
{

};

function hiddenError()
{
	window.clearTimeout(DEFAULT_TIME_OUT);
	var error = WINDOW.document.getElementById("ERROR_MESSAGE_WINDOW_DIV_ID");
	WINDOW.document.body.removeChild(error);
}

function handleError(params)
{	
	if(WINDOW.document.getElementById("ERROR_MESSAGE_WINDOW_DIV_ID")!=null||WINDOW.document.getElementById("ERROR_MESSAGE_WINDOW_DIV_ID")!=undefined)
	{	
		hiddenError();
	}
	
	this.errors = arguments;
	if(SHOW_ERROR_MESSAGE_FLAG)
	{	
		this.popWindowDoc = WINDOW.document;
		this.popWindowBody = WINDOW.document.body;
		this.popWindowDivId = "ERROR_MESSAGE_WINDOW_DIV_ID";
		this.style = "position:absolute;z-index:9999;_ysp_top:35%;left:35%;width:30%;height:30%;border:solid black 1px;backgroundColor:lightyellow;";
		this.popWindowDiv = WINDOW.document.createElement("DIV");
		this.popWindowDiv.setAttribute("id",this.popWindowDivId);
		this.popWindowDiv.setAttribute("align","center");
		this.popWindowDiv.setAttribute("style",this.style);		
			
		this.popWindowDiv.style.setAttribute("position","absolute");
		this.popWindowDiv.style.setAttribute("zIndex","9999");
		this.popWindowDiv.style.setAttribute("_ysp_top","30%");
		this.popWindowDiv.style.setAttribute("left","30%");
		this.popWindowDiv.style.setAttribute("width","40%");
		this.popWindowDiv.style.setAttribute("height","40%");
		this.popWindowDiv.style.setAttribute("border","solid lightblue 2px");
		this.popWindowDiv.style.setAttribute("borderColor","lightblue");
		this.popWindowDiv.style.setAttribute("backgroundColor","lightyellow");	
		this.popWindowDiv.style.setAttribute("display","block");
		this.popWindowBody.appendChild(this.popWindowDiv);
		var message = "";		
		message += "<table width='99%' border='0' style='cursor:auto;text-overflow:ellipsis;overflow:hidden;' align='center' cellpadding='0' cellspacing='0'>";
		message += "<tr>";
		message += "<td width='90%' height='25'>&nbsp;</td>";
	    message += "<td width='10%' align='right' class='basic_arrow' ><img style='cursor:hand' onclick='hiddenError();' id='image1' src='resources/default/images/common/icon_close02_on.gif'  width='17' height='16' border='0' /></td>";
	    message += "</tr>";	
		message += "<tr>";
		message += "<td width='90%' colspan='2' height='90%'>";
		message += "<b>An error was thrown and caught.</b><p>";
		message += "Error: " + this.errors[0] + "<br>";
		message += "URL: " + this.errors[1] + "<br>";
		message += "Line: " + this.errors[2] + "<br>";	
		message += "</td>";
	    message += "</tr>";
		message += "</table>";      
		DEFAULT_TIME_OUT = window.setTimeout(hiddenError,2000);	
		this.popWindowDiv.innerHTML = message;	
	}
	
	var msg = {
				messageId:	"DIV_000000",
				operateTime:	"",
				operateContext:	"Error: " + this.errors[0]+ "URL: " + this.errors[1] + "Line: " + this.errors[2]
			};
	//_ysp_top.addMessage(msg);		
	return true;
}

window.onerror = handleError;
//设置DWR错误处理句柄
if (typeof DWREngine != "undefined"
    && DWREngine != null)
{
    DWREngine.setErrorHandler(function(message, ex){}); 
}    
 
function errorTest()
{
	throw new Exception("params must be array, but not array");	
}


//alert, success, errror etc suggest
function commonMessage()
{
	this.func = null;
	this.times = 10;
	this.timeoutid = null;
	this.obj = null;
	this.currentPageDiv = document.all.SUCCESS_POP_DIV_DEFAULTID_TEST;
	this.messageTitle = document.frames("messageFrame").document.all.messageTitle;
	this.messageContext = document.frames("messageFrame").document.all.messageContext;
	this.messageButton = document.frames("messageFrame").document.all.messageButton;
	
	//add by 60004887 use for confirm
	this.submitButton = document.frames("messageFrame").document.all.yes;
	this.cancelButton = document.frames("messageFrame").document.all.no;
	this.confirmTimeFlag = false;
	//this.messageButton.onclick = this.hidden;
}

commonMessage.prototype.setObject = function(obj)
{
	this.obj = obj;
}
	
commonMessage.prototype.alertMessage = function(arguments)
{
	this.currentPageDiv.style.display="none";
	this.messageTitle.innerText="提示";
	this.messageContext.innerText="&nbsp";
	this.messageButton.innerText="确定";	
	this.messageButton.style.display = "block";
	
	//add by 60004887 use for confirm
	this.submitButton.style.display = "none";
	this.cancelButton.style.display = "none";
	
	this.func = null;
	this.times = 10;
	this.currentWindow = null;

	this.currentPageDiv.style.left = window.screen.availWidth/2-150;	//div window 距离左边位置
	this.currentPageDiv.style._ysp_top = window.screen.availHeight/2-150;		//div window 距离顶部位置	
	
	if(arguments.length>=3)
	{
		this.currentWindow = arguments[3];
		this.messageContext.innerText=arguments[0];
		this.messageTitle.innerText=arguments[1];		
		//this.func=arguments[2];
		this.times=arguments[2];
		this.messageButton.value="确定"+this.times+"";
		this.autoClose();
	}
	
	else if(arguments.length==3)
	{
		this.messageContext.innerText=arguments[0];
		this.messageTitle.innerText=arguments[1];		
		//this.func=arguments[2];
		this.times = arguments[2];
	}
	
	else if(arguments.length==2)
	{
		this.messageContext.innerText=arguments[0];
		this.messageTitle.innerText=arguments[1];	
	}
	else
	{
		this.messageContext.innerText = arguments[0];		
	}
	
	this.currentPageDiv.style.display="block";	
};


commonMessage.prototype.autoClose = function()
{
	if(this.times==0&&this.timeoutid!=null)
	{
		this.messageButton.onclick();
		clearTimeout(this.timeoutid);
		return ;
	}
	this.times = this.times-1;
	this.messageButton.value="确定"+this.times+"";		
	this.timeoutid = setTimeout("comMessage.autoClose();",1000);
};

commonMessage.prototype.hidden = function()
{
	if(this.timeoutid!=null)
	{
		clearTimeout(this.timeoutid);
		this.timeoutid = null;
	}
	this.currentPageDiv.style.display="none";
	if(this.func!=null)
	{
		this.currentWindow.eval(this.func);
	}	
	return;
};

commonMessage.prototype.confirm = function(message) {
    this.currentPageDiv.style.display="none";
	this.messageTitle.innerText="提示";
	this.messageContext.innerText=message;
	this.messageButton.innerText="确定";	
	this.messageButton.style.display = "none";
	
	//add by 60004887 use for confirm
	this.submitButton.style.display = "block";
	this.cancelButton.style.display = "block";
	
	this.currentPageDiv.style.display="block";
	return this.confirmClick();
}

commonMessage.prototype.confirmClick = function () {
    var oFlag = true;
    this.confirmTimeFlag = window.setTimeout("",10000);
    this.submitButton.onclick = function() {
        window.clearTimeout(this.confirmTimeFlag);
        oFlag = true;
    }
    this.cancelButton.onclick = function() {
        window.clearTimeout(this.confirmTimeFlag);
        oFlag = false;
    }
    
    return oFlag;
}


function initCommonMessage()
{
	_ysp_top.comMessage = new commonMessage();	
}
/*
 * 合并contextMenu.js
 */
//注册页面右键事件

window.document.attachEvent("oncontextmenu",showContextMenu);

function showContextMenu()
{
    var obj=event.srcElement;
	if(obj && obj.tagName!="INPUT" && obj.tagName!="TEXTAREA" && document.selection.type=="None")
	{
	    event.returnValue=false;
		return false;
    }
          
}

//注册页面刷新时间
window.document.attachEvent("onkeydown",refreshPage);
function refreshPage(){
	if(event.keyCode==117)
	{
		event.keyCode=0;
		event.returnValue = false;
		//window.alert("当前设置不允许使用F6");
		return false;
	}else if(event.keyCode==116){
	   event.keyCode=0;
	   event.returnValue=false;
	   //window.alert("当前设置不允许使用F5刷新键");
	   return false;
	}
}

/*
 * 合并_AjaxEngine.js
 */ 
var ajaxEngine = new Object();

ajaxEngine.loadHTML = function(sUrl,target) {
	var xmlHttp = XmlHttp.create();
	xmlHttp.open("post",sUrl,true);
	xmlHttp.onreadystatechange = function() {
		if(xmlHttp.readyState == 4 && xmlHttp.status == 200)
		{
			if(typeof target == "object")
			{
				target.innerHTML = xmlHttp.responseText;
			}
			else
			{
				var oTarget = document.getElementById(target);
			    oTarget.innerHTML = xmlHttp.responseText;
			}
		}
	}
	xmlHttp.send(null);
}
/*
 * 合并_Collention.js
 */
//----------------------------------------------------------------
//  List
//----------------------------------------------------------------
function List() 
{
	this.elements = new Array();
}

List.prototype.contains = function(e) {
	for(var i = 0; i < this.elements.length; i++)
	{
		var element = this.elements[i];
		if(element == e)
		{
			return true;
		}
	}
	return false;
}

List.prototype.get = function(i)  {
	return this.elements[i];
}

List.prototype.indexOf = function(e) {
	for(var i = 0; i < this.elements.length; i++)
	{
		var element = this.elements[i];
		if(element == e)
		{
			return i;
		}
	}
	return -1;
}

List.prototype.add = function(e) {
	return this.addLast(e);
}

List.prototype.addLast = function(e) {
	this.elements.push(e);
}

List.prototype.addFirst = function(e) {
	this.elements.unshift(e);
}

List.prototype.remove = function(e) {
	for(var i = 0; i < this.elements.length; i++)
	{
		var element = this.elements[i];
		if(element == e)
		{
			for(var j = i; j < this.elements.length - 1; j++)
			{
				this.elements[j] = this.elements[j + 1];
			}
			this.elements.pop();
			break;
		}
	}
	return e;
}

List.prototype.removeFirst = function() {
	return this.elements.shift();
}

List.prototype.removeLast = function() {
	return this.elements.pop();
}

List.prototype.clear = function() {
	var len = this.elements.length;
	for(var i = len - 1; i > 0; i--)
	{
		this.elements[i] = null;
		this.elements.pop();
	}
}

List.prototype.size = function() {
	return this.elements.length;
}

List.prototype.toArray = function() {
	return this.elements;
}

//----------------------------------------------------------------
//  Set
//----------------------------------------------------------------
function Set() 
{
	this.elements = new Array();
}

Set.prototype.contains = function(e) {
	for(var i = 0; i < this.elements.length; i++)
	{
		var element = this.elements[i];
		if(element == e)
		{
			return true;
		}
	}
	return false;
}

Set.prototype.add = function(e) {
	return this.addLast(e);
}

Set.prototype.addLast = function(e) {
    if(!this.contains(e))
    {
		this.elements.push(e);
		return true;
    }
    return false;
}

Set.prototype.addFirst = function(e) {
	if(!this.contains(e))
    {
		this.elements.unshift(e);
		return true;
    }
    return false;
}

Set.prototype.remove = function(e) {
	for(var i = 0; i < this.elements.length; i++)
	{
		var element = this.elements[i];
		if(element == e)
		{
			for(var j = i; j < this.elements.length - 1; j++)
			{
				this.elements[j] = this.elements[j + 1];
			}
			this.elements.pop();
			break;
		}
	}
	return e;
}

Set.prototype.removeFirst = function() {
	return this.elements.shift();
}

Set.prototype.removeLast = function() {
	return this.elements.pop();
}

Set.prototype.clear = function() {
	var len = this.elements.length;
	for(var i = len - 1; i > 0; i--)
	{
		this.elements[i] = null;
		this.elements.pop();
	}
}
/*
 * 合并message.js
 */
/**
 * 根据消息生成Html
 */
function operateToHtml(doc,obj,msg)
{
	var tmpTr = doc.createElement("TR");
	tmpTr.setAttribute("class","list_tr_default");
	tmpTr.setAttribute("id","TR_"+msg.messageId);
	
	var tmpHtml = "";
	var tmpTd = doc.createElement("TD");
	tmpTd.setAttribute("width","20%");
	tmpTd.setAttribute("height","25");
	tmpTd.setAttribute("align","left");
	//mod by 60004887 更改字体样式与界面风格协调
	tmpHtml = "<span style='font-size:10pt'>" + msg.operateTime + "</span>";
	tmpTd.innerHTML = tmpHtml;
	tmpTr.appendChild(tmpTd);
		
	tmpTd = doc.createElement("TD");
	tmpTd.setAttribute("width","80%");
	tmpTd.setAttribute("height","25");
	tmpTd.setAttribute("align","left");
	tmpHtml =  msg.operateContext;
	//mod by 60004887 更改字体样式与界面风格协调
	tmpTd.innerHTML = "<span style='font-size:10pt'>" + tmpHtml + "</span>";
	tmpTr.appendChild(tmpTd);
	
	return tmpTr;
}
/**
 * 根据消息生成Html
 */
function msgToHtml(doc,obj,msg)
{
	var tmpTr = doc.createElement("TR");
	tmpTr.setAttribute("class","list_tr_default");
	tmpTr.setAttribute("id","TR_"+msg.messageId);
	
	var tmpHtml = "";
	var tmpTd = doc.createElement("TD");

	tmpTd.setAttribute("width","40%");
	tmpTd.setAttribute("height","25");
	
	tmpHtml = "<font color='#"+msg.displayColor+"' style='font-size:10pt'>";
	var width = 900;//parseInt(window.screen.availWidth)-100;
    var height = 480;//parseInt(window.screen.availHeight)-300;
    var spec = "resizable=yes,toolbar=no,scrollbars=yes,status=no,left=200,_ysp_top=100,width=" + width + ",height=" + height;
    
	var openUrl = obj.basePath+"/memo/bulletinContentForOut.action?bulletinId="+msg.messageId;
	tmpHtml += "<a id='A_"+msg.messageId+"' href='javascript:void(0)' onclick='_ysp_top.open(\""+openUrl+"\",\"_blank\",\""+spec+"\")' style='cursor:hand;color:"+msg.displayColor+"'>";
	if(msg.messageTitle==null)
	{
		tmpHtml += msg.messageContent;
	}
	else
	{
		tmpHtml += msg.messageTitle;
	}			
	tmpHtml += "</a></font>";
	tmpTd.innerHTML = tmpHtml;
	//alert(msg.messageTitle);
	tmpTr.appendChild(tmpTd);
	
	tmpTd = doc.createElement("TD");
	tmpTd.setAttribute("width","20%");
	tmpTd.setAttribute("height","25");
	tmpTd.setAttribute("norwarp",true);
	tmpHtml = "<font style='font-size:10pt'>";
	if(msg.typeName==null)
	{
		tmpHtml += "&nbsp;&nbsp;";
	}
	else
	{
		tmpHtml += msg.typeName;
	}		
	tmpHtml += "</font>";
	tmpTd.innerHTML = tmpHtml;	
	tmpTr.appendChild(tmpTd);	
	
	tmpTd = doc.createElement("TD");
	tmpTd.setAttribute("width","30%");
	tmpTd.setAttribute("height","25");
	tmpTd.setAttribute("norwarp",true);
	tmpHtml = "<font style='font-size:10pt'>";
	if(msg.sendTime==null)
	{
		tmpHtml += "&nbsp;&nbsp;";
	}
	else
	{
		tmpHtml += msg.sendTime;
	}		
	tmpHtml += "</font>";
	tmpTd.innerHTML = tmpHtml;	
	tmpTr.appendChild(tmpTd);	

	tmpTd = doc.createElement("TD");
	tmpTd.setAttribute("width","10%");
	tmpTd.setAttribute("height","25");
	tmpHtml = "<font style='font-size:10pt'>";
	if(msg.sendUser==null)
	{
		tmpHtml += "&nbsp;&nbsp;";
	}
	else
	{
		tmpHtml += msg.sendUser;
	}	
	tmpHtml += "</font>";	
	tmpTd.innerHTML = tmpHtml;	
	tmpTr.appendChild(tmpTd);
	
	return tmpTr;		
}

//<!--scroll window start-->
function ScrollWindow()
{
	this.doc = document;
	this.object = {};
	this.messageTagId = "DIV_DEFAULT_SCROLL_WINDOW";
	this.marqueeId = "MARQUEE_DEFAULT_SCROLL_WINDOW";
	this.imagePath = "/";
	this.basePath = "/";
	this.target = "_blank";
	this.messages = new Array();
	this.allMsg = new Array();
	
	this.scrollUpShowMsgNum = 2;
	this.msgShowNum = 0;
	
	this.msgTimer = 180000;
}

ScrollWindow.prototype.setBasePath = function(basePath)
{
	this.basePath = basePath;
};

ScrollWindow.getObject = function()
{
	if(this.object==null||!this.object)
	{
		this.object = scrollWindow;
	}
	return this.object;
};

ScrollWindow.prototype.setDoc = function(doc)
{
	this.doc = doc;
};

ScrollWindow.prototype.setObject = function(object)
{
	this.object = object;
};

ScrollWindow.prototype.setMessageTagId = function(messageTagId)
{
	this.messageTagId = messageTagId;
};

ScrollWindow.prototype.setMarqueeId = function(marqueeId)
{
	this.marqueeId = marqueeId;
};

ScrollWindow.prototype.setImagePath = function(imagePath)
{
	this.imagePath = imagePath;
};

ScrollWindow.prototype.setScrollUpShowMsgNum = function(scrollUpShowMsgNum)
{
	this.scrollUpShowMsgNum = scrollUpShowMsgNum;
};

ScrollWindow.prototype.onMouseEnter = function()
{
	if(this.doc==null||!this.doc)
	{
		this.doc = document;
	}
	var marquee = this.doc.getElementById(this.marqueeId);
	marquee.stop();
};

ScrollWindow.prototype.onMouseLeave = function()
{
	if(this.doc==null||!this.doc)
	{
		this.doc = document;
	}
	var marquee = this.doc.getElementById(this.marqueeId);
	marquee.start();
};

ScrollWindow.prototype.appendChildren = function(child)
{
	var marquee = this.doc.getElementById(this.marqueeId);
	marquee.appendChild(child);
};

ScrollWindow.prototype.onClick = function(child)
{
	var ahref = event.srcElement;
	if(ahref.tagName!="A")
	{
		return false;
	}

    var width = 900;//parseInt(window.screen.availWidth)-100;
    var height = 480;//parseInt(window.screen.availHeight)-100;
    var spec = "resizable=yes,toolbar=no,scrollbars=yes,status=no,left=200,_ysp_top=100,width=" + width + ",height=" + height;

	var ahrefid = ahref.id;
	ahrefid = ahrefid.substring(ahrefid.indexOf("_")+1);
	var url = this.basePath+"/memo/bulletinContentForOut.action?bulletinId="+ahrefid;	
	
	window.open(url,"_blank",spec);
	return ;
};

ScrollWindow.prototype.removeChildren = function(child)
{
	var marquee = this.doc.getElementById(this.marqueeId);
	marquee.removeChild(child);
};

ScrollWindow.prototype.createHTML = function(message)
{
	var obj = document.createElement("FONT");
	obj.setAttribute("id","FONT_"+message.messageId+"_3");
	var innerHtml = " <a ID=\"A_"+message.messageId+"\" onmouseenter=\"scrollWindow.onMouseEnter()\"";
	innerHtml += " onmouseleave=\"scrollWindow.onMouseLeave();\"";
	innerHtml += " href=\"javascript:void(0)\" style=\"cursor:hand;color:#"+message.displayColor+"\"";
	innerHtml += " onclick=\"scrollWindow.onClick();\">"; 
	innerHtml += "-";

	if(message.messageTitle!=null){
		innerHtml += message.messageTitle;
	}
	else{
		innerHtml += message.messageContent;
	}	
	innerHtml += "</A>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
	obj.innerHTML =innerHtml;
	return obj;
};

ScrollWindow.prototype.addMessage = function(message)
{
	var child = this.createHTML(message);
	
	var scrollType = this.doc.getElementById(this.marqueeId).direction;
	if(scrollType == 'up' && this.msgShowNum !=0 && (this.msgShowNum % this.scrollUpShowMsgNum == 0))
	{
		var aBr = document.createElement("br");
		this.appendChildren(aBr);
	}
	this.appendChildren(child);
	
//	alert(this.doc.getElementById(this.marqueeId).innerHTML);
};

ScrollWindow.prototype.addMessages = function(messages)
{
	if(typeof(messages)==Array)
	{
		for(var message in messages)
		{
			this.addMessage(message);
		}
		return;
	}
	throw new Error("params must be array, but not array");
};

ScrollWindow.prototype.initMsg = function ()
{
	
	var object = this.object;
	try{
		var sUrl = this.basePath+"/ngportal/initMessage.action";
		asyncSend(sUrl,params,"json",function(re){
			object.initMsgs(re);
		});
	}catch(ex)
	{
		object.initMsgs();
	}
	/*
	messageService.initMessage(function(re){
		object.initMsgs(re);
	});	*/
};


ScrollWindow.prototype.initMsgs = function (msgs)
{
/*
	if(msgs===null||!msgs)
	{
		return ;
	}
	for(var i=0;i<msgs.length;i++)
	{
		this.messages[msgs[i].messageId] = msgs[i];
		this.allMsg[i] = msgs[i].messageId;
	}	
*/	

	this.refreshMsgs(msgs);
};

ScrollWindow.prototype.refreshMsg = function ()
{
	var object = ScrollWindow.getObject();
	
	var msgObj = _ysp_top.publicObject["MESSAGE_DWR_ALLCOUNTANDBULLETIN"];
	object.refreshMsgs(msgObj.messages);
//	messageService.refreshMessage(function(re){
//		object.refreshMsgs(re);
//		});	
};

ScrollWindow.prototype.refreshMsgs = function (msgs)
{
	if(this.marqueeId===null||!this.marqueeId)
	{
		return ;
	}
	
	var marquee = this.doc.getElementById(this.marqueeId);	
	if(msgs===null||!msgs)
	{
		marquee.innerHTML = "";
		return ;
	}
	var messageTag = this.doc.getElementById(this.marqueeId);
	var hasMessage = false;
	//先删除多余的消息
	for(var i=0;i<this.allMsg.length;i++)
	{
		
		for(var j=0;j<msgs.length;j++)
		{
			if(this.allMsg[i]==msgs[j].messageId)
			{
				hasMessage = true;
				break ;
			}			
		}	
		if(hasMessage==false)
		{
			//删除"-"
			var tmpChild = this.doc.getElementById("FONT_"+this.allMsg[i]+"_1");
			if(tmpChild){
				messageTag.removeChild(tmpChild);
			}
			//删除"!"
			tmpChild = this.doc.getElementById("FONT_"+this.allMsg[i]+"_2");
			if(tmpChild){
				messageTag.removeChild(tmpChild);
			}
			//删除滚动条中的公告
			tmpChild = this.doc.getElementById("FONT_"+this.allMsg[i]+"_3");
			if(tmpChild){
				messageTag.removeChild(tmpChild);
			}
			this.messages[this.allMsg[i]] = null;	
		}	

		hasMessage = false;		
	}
	
	this.allMsg = null;
	this.allMsg = new Array(msgs.length);

	//增加新增的消息
	for(var i=0;i<msgs.length;i++)
	{
		//如果此消息为新增消息，则将消息放到消息列表中，同时在界面生成消息Html
		if(this.messages[msgs[i].messageId]===undefined||this.messages[msgs[i].messageId]===null||!this.messages[msgs[i].messageId])
		{				
			this.messages[msgs[i].messageId] = msgs[i];
			this.addMessage(msgs[i]);
			this.msgShowNum ++;
		}
		this.allMsg[i] = msgs[i].messageId;
	}
	
	this.msgShowNum = 0;
};

ScrollWindow.prototype.setMsgTimer = function (msgTimer)
{
	if(typeof msgTimer == "number" && msgTimer > 0)
	{
		this.msgTimer = msgTimer;
	}
};

ScrollWindow.prototype.timer = function ()
{
	window.setInterval(this.object.refreshMsg, this.msgTimer);
};


//<!--Start List window-->
function ListWindow()
{
	this.contextPath = "";					//context 路径
	this.basePath = "";
	this.trStyle = "display:none;";			//生成tr 的样式
	this.popWindow = window.createPopup();
	this.popWindowDoc = this.popWindow.document;
	this.popWindowBody = this.popWindow.document.body;
	this.popWindowDivId = "LIST_POP_WINDOW_DIV_ID";
	this.popWindowTable = this.popWindowDoc.createElement("table");
	this.popWindowTbody = this.popWindowDoc.createElement("tbody");	
	this.style = "position:absolute;z-index:5000;_ysp_top:0px;left:0px;border:solid black 2px;backgroundColor:lightyellow;overflow-y:auto;";
	this.popWindowDiv = this.popWindow.document.createElement("DIV");
	this.popWindowDiv.setAttribute("id",this.popWindowDivId);
	this.popWindowDiv.setAttribute("align","left");
	this.popWindowDiv.setAttribute("style",this.style);
	this.relateObjectId = null;
	this.relateObject = null;
	this.relateDoc = null;
	this.relateBody = null;
	this.tableBodyId = null;
	this.tableBody = null;
	this.heightPx = 200;	//Pop window 高度
	this.widthPx = 400;	//Pop window 宽度
	//alert("window.screen.availWidth="+window.screen.availWidth+",window.screenLeft="+window.screenLeft);
	this.leftPx = window.screen.availWidth-window.screenLeft-50;	//Pop window 距离左边位置
	//alert("leftPx="+this.leftPx);
	//alert("window.screen.availHeight="+window.screen.availHeight+",window.screenTop="+window.screenTop);
	this.topPx = window.screen.availHeight-window.screenTop-100;		//Pop window 距离顶部位置	
	//alert("topPx="+this.topPx);
	this.initFlag = false;
	this.srcollRelationFlag = false;
	this.object = {};
	this.messageIds = new Array();
	this.maxNum = 100;
	this.messageIdCount = 0;
}

ListWindow.getObject = function()
{
	if(this.object==null||!this.object)
	{
		this.object = listWindow;
	}
	return this.object;
}

ListWindow.prototype.setObject = function(object)
{
	this.object = object;
};

ListWindow.prototype.setMaxNum = function(maxNum)
{
	this.maxNum = maxNum;
};

ListWindow.prototype.setBasePath = function (basePath)
{
	this.basePath = basePath;
};

ListWindow.prototype.setContextPath = function (contextPath)
{
	this.contextPath = contextPath;
};

ListWindow.prototype.setSrcollRelationFlag = function (srcollRelationFlag)
{
	if(srcollRelationFlag!=null)
	{
		this.srcollRelationFlag = true;
	}
};

ListWindow.prototype.setTableBodyId = function (tableBodyId)
{
	this.tableBodyId = tableBodyId;
	this.tableBody = this.popWindowDoc.getElementById(this.tableBodyId);
};

ListWindow.prototype.setRelateObjectId = function (relateObjectId)
{
	this.relateObjectId = relateObjectId;
	if(this.relateDoc==null)
	{
		this.relateDoc = document;		
	}
	this.relateObject = this.relateDoc.getElementById(this.relateObjectId);
	//alert(this.relateObject.innerHTML);
	this.topPx = this.relateObject.offsetTop - this.heightPx;
	//alert(this.relateObject.offsetTop+";"+this.heightPx+";"+this.topPx);
	this.leftPx = this.relateObject.offsetLeft;
	//alert(this.relateObject.offsetLeft+";"+this.relateObject.offsetWidth+";"+this.widthPx+";"+this.leftPx);	
};

ListWindow.prototype.setRelateObject = function (relateObject)
{

	this.relateObject = relateObject;
	this.topPx = this.relateObject.offsetTop-this.heightPx;
	this.leftPx = this.relateObject.offsetLeft+this.relateObject.offsetWidth-this.widthPx;
	//alert(this.relateObject.offsetLeft+";"+this.relateObject.offsetWidth+";"+this.widthPx);
};

ListWindow.prototype.setRelateDoc = function (relateDoc)
{
	this.relateDoc = relateDoc;
	this.relateBody = this.relateDoc.body;
};

ListWindow.prototype.removeMessage = function (messageId)
{
	this.messageIds[messageId] = null;
	var obj = this.popWindowDoc.getElementById("TR_"+messageId);
	if(obj){
		this.popWindowTbody.removeChild(obj);
	}
};

ListWindow.prototype.addMessages = function (messages)
{
	for(var i=0;i<messages.length;i++)
	{
		this.addMessage(messages[i]);
	}
	return;
	//throw new Error("params must be array, but not array");
};

ListWindow.prototype.addMessage = function (message)
{
	//alert(message);
	if(this.messageIds[message.messageId]!==null&&this.messageIds[message.messageId]!==undefined)
	{
		return ;
	}

	this.messageIds[message.messageId] = message.messageId;
	var obj = this.messageToHtmlObject(message);
	
	if(this.popWindowTbody.children(0))
	{
		this.popWindowTbody.children(0).insertAdjacentElement("beforeBegin",obj);
	}else
	{
		this.popWindowTbody.appendChild(obj);
	}
};

ListWindow.prototype.onClick = function(id)
{
	var obj = this.relateDoc.getElementById("A_"+id);
	window.open(obj,"_blank");
}

ListWindow.prototype.messageToHtmlObject = function (message)
{
	if(this.srcollRelationFlag)
	{
		return msgToHtml(this.popWindowDoc,this,message);
	}
	else
	{
		return operateToHtml(this.popWindowDoc,this,message);
	}	
};

ListWindow.prototype.initPopDiv = function (message)
{
	this.popWindowDiv.setAttribute("class","list_div_default");
	this.popWindowDiv.style.setAttribute("position","absolute");
	this.popWindowDiv.style.setAttribute("_ysp_top","0px");
	this.popWindowDiv.style.setAttribute("left","0px");
	this.popWindowDiv.style.setAttribute("width","100%");
	this.popWindowDiv.style.setAttribute("height","100%");
	//mod by 60004887 修改边框样式
	//this.popWindowDiv.style.setAttribute("border","solid lightblue 2px");
	this.popWindowDiv.style.setAttribute("border","solid #505050 1px");
	//this.popWindowDiv.style.setAttribute("borderColor","#505050");
	
	this.popWindowDiv.style.setAttribute("backgroundColor","lightyellow");
	this.popWindowDiv.style.setAttribute("overflowY","auto");
	this.popWindowDiv.style.setAttribute("scrollbar3dLightColor","blue");
	this.popWindowDiv.style.setAttribute("scrollbarDarkShadowColor","blue");
	this.popWindowDiv.style.setAttribute("scrollbarBaseColor","lightblue");
	this.popWindowTable.setAttribute("width","100%");
	this.popWindowTable.setAttribute("height","100%");
	this.popWindowTable.setAttribute("class","bottom_bg");	
	this.popWindowTable.appendChild(this.popWindowTbody);
	this.popWindowDiv.appendChild(this.popWindowTable);
	this.popWindowBody.appendChild(this.popWindowDiv);

};

ListWindow.prototype.hide = function (message)
{
	this.popWindow.hide();
};

ListWindow.prototype.show = function (message, firstShow)
{
	if(firstShow)
	{

	}
	else
	{
		this.popWindow.hide();
		//alert(this.leftPx+"--"+this.topPx+"--"+this.widthPx+"-"+this.heightPx);
		this.popWindow.show(this.leftPx,this.topPx,this.widthPx,this.heightPx,this.relateBody);
	}
};

/**
 * 刷新消息列表
 */
ListWindow.prototype.refreshMsg = function ()
{
	var object = ListWindow.getObject();
	var msgObj = _ysp_top.publicObject["MESSAGE_DWR_ALLCOUNTANDBULLETIN"];
	object.refreshMsgs(msgObj.messages);
//	messageService.getMessages(function(re){
//		object.refreshMsgs(re);
//		});		
		
};

/**
 * 刷新消息列表
 */
ListWindow.prototype.refreshMsgs = function (messages)
{
	
    if(messages==null)
	{
		return ;
	}

	var hasFlag = false;
	for(var messageId in this.messageIds)
	{		
		for(var i=0; i<messages.length;i++)
		{
			if(messageId == messages[i].messageId)
			{
				hasFlag = true;
				break;
			}
		}
		if(!hasFlag)
		{
			this.removeMessage(messageId);
		}
		hasFlag = false;
	}

	this.addMessages(messages);
};

ListWindow.prototype.initMsg = function ()
{
	var object = this.object;
	var msgObj = _ysp_top.publicObject["MESSAGE_DWR_ALLCOUNTANDBULLETIN"];
	if(msgObj)
	{
		object.initMsgs(msgObject.messages);
	}	
	//messageService.getMessages(function(re){
	//	object.initMsgs(re);
	//});	
};

/**
 * 初始化消息列表
 */
ListWindow.prototype.initMsgs = function (msgs)
{
    if(msgs==null)
	{
		return ;
	}
	this.addMessages(msgs);
};

/*
ListWindow.prototype.timer = function ()
{
	window.setInterval(this.object.refreshMsg, 180000);
};*/

/*
 * 菜单公共处理函数
 */
var TABLOGIN1 = "21"             //对应boss tabType=21
var TABLOGIN2 = "22"             //对应boss tabType=22
var TABLOGIN3 = "23"             //对应boss tabType=23
var TABLOGIN4 = "24";			 //对应boss tabType=24
var TABNOLOGIN1 = "31";          //对应boss tabType=31
var TABNOLOGIN2 = "32";          //对应boss tabType=32
var TABNOLOGIN3 = "33";          //对应boss tabType=33
var TABNOLOGIN4 = "34";			 //对应boss tabType=34
var OTHER = 4;                   //对应boss tabType=4 

function valMenuPublic(tabType,menuObj)
{
	
    var mTabSet = _ysp_top.publicObject["mainTab"];
   
    if(mTabSet != null) 
    {
        if( tabType==TABLOGIN3 || tabType==TABNOLOGIN3 )
        {
            var openedArea = "非个人客户业务";
		    for(var i=0;i<mTabSet.lOpenedTabs.size();i++)
		    {
		    	var tmpTabId = mTabSet.lOpenedTabs.get(i);
		    	if(tmpTabId.indexOf("^")>-1)
		    	{
		    		var type = tmpTabId.split("^")[0];
		    		if(type != "BOSS" && type != "CSP")
		    		{
		    			continue;
		    		}
		    		var oTabSet = _ysp_top.publicObject[tmpTabId];
		    		for(var j=0;j<oTabSet.lOpenedTabs.size();j++)
		    		{
		    			var tmp = mTabSet.getMenuObj(getMenuId(oTabSet.lOpenedTabs.get(j)));
			    	
				        if(oTabSet.lOpenedTabs.get(j).split("~")[1] != null)
				        {
				            openedArea = oTabSet.lOpenedTabs.get(j).split("~")[1];
				        }
				        if(tmp == null)
		        		{
		            		continue;
		        		}
		        		if(tmp.id == menuObj.id)
		        		{
                    		return "菜单" + tmp.menuName + "已经在" + openedArea + "打开，请关闭对应用户中的菜单之后再返回当前用户操作该业务";
		        		}
			        }
		    	}else{
		    		var tmp = mTabSet.getMenuObj(getMenuId(tmpTabId));
			        if(tmpTabId.split("~")[1] != null)
			        {
			            openedArea = tmpTabId.split("~")[1];
			        }
			         if(tmp == null)
			        {
			            continue;
			        }
			        if(tmp.id == menuObj.id)
			        {
	                    return "菜单" + tmp.menuName + "已经在" + openedArea + "打开，请关闭对应用户中的菜单之后再返回当前用户操作该业务";
		        	}
		        }
    	  	}
        }
        else if (tabType==TABLOGIN4 || tabType==TABNOLOGIN4) // 24 34全局互斥，24和21、31同一用户互斥，34和21、31同一用户互斥，同时24 34全局范围互斥
        {
        	// 先判断和21、31在同一用户下的互斥关系        
        	var customer = _ysp_top.publicObject["container"].getFocus();
		    var staffFlag = _ysp_top.publicObject["workType"];
		    var tmpTabId = null;
		    
			if(customer)
			{
				
				//个人用户区
				if(staffFlag == "BOSS")
				{
					tmpTabId = "BOSS^"+customer.id;
				}

				var oTabSet = _ysp_top.publicObject[tmpTabId];
			
			   	if(oTabSet)
			   	{
			        for(var j=0;j<oTabSet.lOpenedTabs.size();j++)
			        {
			     
			            var tmp = oTabSet.getMenuObj(getMenuId(oTabSet.lOpenedTabs.get(j)));
			         
			            if(tmp == null)
			            {
			                continue;
			            }
			            if(tmp.id == menuObj.id)
			            {
			                return "菜单" + tmp.menuName + "已经打开";
			            }
			            
			            if((tmp!=null && tmp.tabType==TABLOGIN1) || (tmp!=null && tmp.tabType==TABNOLOGIN1) || (tmp!=null && tmp.tabType==TABLOGIN4) || (tmp!=null && tmp.tabType==TABNOLOGIN4))
			            {
			                return "与菜单"+tmp.menuName+"互斥，请关闭后再开";
			            }
			        }
			    }
			}
			else
			{
				//非个人用户区
		        for(var j=0;j<mTabSet.lOpenedTabs.size();j++)
		        {
		        	tmpTabId = mTabSet.lOpenedTabs.get(j);
		        	
		        	if(tmpTabId.indexOf("^")< 0)
		        	{
		        		var tmp = mTabSet.getMenuObj(getMenuId(tmpTabId));
			            
			            if(tmp == null)
			            {
			                continue;
			            }
			            if(tmp.id == menuObj.id)
			            {
			                return "菜单" + tmp.menuName + "已经打开";
			            }
			            
			            if((tmp!=null && tmp.tabType==TABLOGIN1) || (tmp!=null && tmp.tabType==TABNOLOGIN1) || (tmp!=null && tmp.tabType==TABLOGIN4) || (tmp!=null && tmp.tabType==TABNOLOGIN4))
			            {
			                return "与菜单"+tmp.menuName+"互斥，请关闭后再开";
			            }
		            }
		        }       
			}
			
			// 再判断全局下24和34的互斥关系
			var openedArea = "非个人客户业务";
		    for(var i=0;i<mTabSet.lOpenedTabs.size();i++)
		    {
		    	tmpTabId = mTabSet.lOpenedTabs.get(i);
		    	if(tmpTabId.indexOf("^")>-1)
		    	{
		    		var type = tmpTabId.split("^")[0];
		    		if(type != "BOSS" && type != "CSP")
		    		{
		    			continue;
		    		}
		    		var oTabSet = _ysp_top.publicObject[tmpTabId];
		    		for(var j=0;j<oTabSet.lOpenedTabs.size();j++)
		    		{
		    			var tmp = mTabSet.getMenuObj(getMenuId(oTabSet.lOpenedTabs.get(j)));
			    	
				        if(oTabSet.lOpenedTabs.get(j).split("~")[1] != null)
				        {
				            openedArea = oTabSet.lOpenedTabs.get(j).split("~")[1];
				        }
				        if(tmp == null)
		        		{
		            		continue;
		        		}
		        		if((tmp!=null && tabType==TABLOGIN4 && tmp.tabType==TABNOLOGIN4) || (tmp!=null && tabType==TABNOLOGIN4 && tmp.tabType==TABLOGIN4))
		        		{
                    		return "菜单" + menuObj.menuName + "和在" + openedArea + "中打开的菜单" + tmp.menuName + "互斥，请关闭对应用户中的菜单之后再返回当前用户操作该业务";
		        		}
			        }
		    	}else{
		    		var tmp = mTabSet.getMenuObj(getMenuId(tmpTabId));
			        if(tmpTabId.split("~")[1] != null)
			        {
			            openedArea = tmpTabId.split("~")[1];
			        }
			         if(tmp == null)
			        {
			            continue;
			        }
			        if((tmp!=null && tabType==TABLOGIN4 && tmp.tabType==TABNOLOGIN4) || (tmp!=null && tabType==TABNOLOGIN4 && tmp.tabType==TABLOGIN4))
			        {
	                    return "菜单" + menuObj.menuName + "和在" + openedArea + "中打开的菜单" + tmp.menuName + "互斥，请关闭对应用户中的菜单之后再返回当前用户操作该业务";
		        	}
		        }
    	  	}
			
        }         
        else
        {
        	var customer = _ysp_top.publicObject["container"].getFocus();
		    var staffFlag = _ysp_top.publicObject["workType"];
		    var tmpTabId = null;
		   
			if(customer)
			{
				
				//个人用户区
				if(staffFlag == "BOSS")
				{
					tmpTabId = "BOSS^"+customer.id;
				}
				var oTabSet = _ysp_top.publicObject[tmpTabId];
			   	if(oTabSet)
			   	{
			        for(var j=0;j<oTabSet.lOpenedTabs.size();j++)
			        {
			            var tmp = oTabSet.getMenuObj(getMenuId(oTabSet.lOpenedTabs.get(j)));
			            
			            if(tmp == null)
			            {
			                continue;
			            }
			            if(tmp.id == menuObj.id)
			            {
			                return "菜单" + tmp.menuName + "已经打开";
			            }
			            
			            if((tmp!=null && tmp.tabType==TABLOGIN1) || (tmp!=null && tmp.tabType==TABNOLOGIN1) || (tmp!=null && tmp.tabType==TABLOGIN4) || (tmp!=null && tmp.tabType==TABNOLOGIN4))
			            {
			                return "与菜单"+tmp.menuName+"互斥，请关闭后再开";
			            }
			        }
			    }
			}
			else
			{
				//非个人用户区
		        for(var j=0;j<mTabSet.lOpenedTabs.size();j++)
		        {
		        	tmpTabId = mTabSet.lOpenedTabs.get(j);
		        	
		        	if(tmpTabId.indexOf("^")< 0)
		        	{
		        		var tmp = mTabSet.getMenuObj(getMenuId(tmpTabId));
			            
			            if(tmp == null)
			            {
			                continue;
			            }
			            if(tmp.id == menuObj.id)
			            {
			                return "菜单" + tmp.menuName + "已经打开";
			            }
			            
			            if((tmp!=null && tmp.tabType==TABLOGIN1) || (tmp!=null && tmp.tabType==TABNOLOGIN1) || (tmp!=null && tmp.tabType==TABLOGIN4) || (tmp!=null && tmp.tabType==TABNOLOGIN4))
			            {
			                return "与菜单"+tmp.menuName+"互斥，请关闭后再开";
			            }
		            }
		        }       
			}
		}  	
    }
    return "true";
}



function focusEventForNG(sTabCode)
{
	var tab = _ysp_top.publicObject["mainTab"];
	var cspCustomer = _ysp_top.publicObject["cspCustomer"];
	if(cspCustomer == null)
	{
	    return;
	}
	
	var hasIVRAuth = false;
    if(_ysp_top.publicObject["haveRoleNoCheck"] != null)
    {
        hasIVRAuth = _ysp_top.publicObject["haveRoleNoCheck"] == "true"? true:false;
    }
	//如果需要验证密码，则提示进行密码验证
	if(hasIVRAuth==false && (tab.aTabConfigs[sTabCode].needAuth==true && cspCustomer.verfiy != true))
	{
	    //tab.removeTabByCode(sTabCode);
	    myCheckPassword();
	    return;
	}
	var oFrame = _ysp_top.publicObject["rightWindow"].document.getElementById('iframe_' + sTabCode + '_' + tab.oOwner.id);
	if(oFrame != null && tab.aTabConfigs[sTabCode].phoneNo!=cspCustomer.phoneNo)
	{
	    tab.aTabConfigs[sTabCode].phoneNo = cspCustomer.phoneNo;
		oFrame.src = tab.aTabConfigs[sTabCode].sTabSrc;
	}
}

function getMenuId(tabId)
{
	if(tabId==null||tabId=="")
	{
		return "";
	}
	if(tabId.indexOf("^")>-1)
	{
		var ar = tabId.split("^");
		if(ar.length == 3)
		{
			var tmp = ar[2];
			if(tmp.indexOf("~")>-1)
			{
				return tmp.split("~")[0];
			}
		}
	}else
	{
		if(tabId.indexOf("~")>-1)
		{
			return tmp.split("~")[0];
		}
	}
	return tabId;
}

var _xmlHttp;
//获得客服路由地址前缀
function getCrmUrlByRegion()
{
	if(_xmlHttp == null)
	{
		try 
		  {
		    if (window.XMLHttpRequest) 
		    {
		      _xmlHttp = new XMLHttpRequest();
		      
		      if (_xmlHttp.readyState == null) 
		      {
		        _xmlHttp.readyState = 1;
		        _xmlHttp.addEventListener("load", function () 
		        {
		          _xmlHttp.readyState = 4;
		          if (typeof _xmlHttp.onreadystatechange == "function")
		            _xmlHttp.onreadystatechange();
		        }, false);
		      }
		    }
		    else if (window.ActiveXObject) 
		    {
		      var prefixes = ["MSXML2", "Microsoft", "MSXML", "MSXML3"];
		      var _length = 0;
		      while(null == _xmlHttp && _length < prefixes.length)
		      {
		      	 try 
			    {
			      _xmlHttp = new ActiveXObject(prefixes[_length] + ".XmlHttp");
			      _length++;
			    }
			    catch (ex) 
			    {
			      alert("Your browser does not support XmlHttp objects");
			    };
		      }
		    }
		  }
		  catch (ex) 
		  {
		  	alert("Get XmlHttp objects Error !");
		  }
	}
	var url = contextPath + "/ngportal/fetchRegionAndCrmUrl.action";
	   _xmlHttp.open("POST", url, false);
	   _xmlHttp.onreadystatechange = function()
	   {
	     if (_xmlHttp.readyState == 4 && _xmlHttp.status == 200) 
	     {
	     	//得到所有区域对应路由地址，保存到Top里面
	         var resultData = _xmlHttp.responseText;
	         if (resultData)
	         {
	         	var urlStr = resultData.split('@_@');
	         	var regionAndUrls = new Array();
	         	for(var i = 0; i < urlStr.length ; i++)
	         	{
	         		var region = null == urlStr[i].split('^_^')[0]?"":urlStr[i].split('^_^')[0];
	         		regionAndUrls[region] = null == urlStr[i].split('^_^')[1]?"":urlStr[i].split('^_^')[1];
	         	}
	         	_ysp_top.mif.registerObject("regionAndCrmUrls",regionAndUrls);
	         }
	     }
	   };
	   _xmlHttp.send(null);
}

//add by tKf25646  2011-01-27
//传入的字符串strSeq是否以指定的前缀(之一)开头
function isStartsWithSpePrefixs(strSeq,prefixs)
{
	if(null != strSeq && null != prefixs)
	{
		for(i = 0 ; i <= prefixs.length; i++)
		{
			if(strSeq.indexOf(prefixs[i]) == "0") return true;
		}
	}
	return false;
}

function openMenuPublic(menuObj)
{
	//add begin by jKF17881 2012-06-05 R003C12L08n01 OR_JS_201207_647  关于优化CRM与客服融合后打开功能菜单功能的需求 
	var region=_ysp_top.publicObject["ngcrm_current_staff"];
    try
    {
	    if (menuObj.displayType=='99' && (region=='99' || region=='999'))
	    {
	       alert("该菜单不开放给省客服话务员使用，请联系系统管理员确认");
	       return ;
	    }
	    if (menuObj.displayType=='98')
	    {
	       alert("该菜单不开放给客服CSP系统使用，请联系系统管理员确认");  
	       return 
	    }
    }
    catch(e)
    {}
    //add end by jKF17881 2012-06-05 R003C12L08n01 OR_JS_201207_647  关于优化CRM与客服融合后打开功能菜单功能的需求 
	//---新增判断客服签入电话归属区域将菜单URL添加路由地址(端口) 
	//---    Modify by TXF  2010.03.14 
	//保留菜单的原URL，执行完本方法后，将URL还原，以免影响全局缓存中原菜单的URL
	var ogzMenuUrl = menuObj.menuUrl;
	
	var staffFlag = _ysp_top.publicObject["workType"];
	var deployServerType = _ysp_top.publicObject["deployServerType"];
	var crmMenuUrlPrefixs = new Array("/ngcrm");
	crmMenuUrlPrefixs.push(obtainWebContextPath("ngcustcare"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("custcare"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("ngmarket"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("ngorder"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("ng_js"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("unimkt"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("channel"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("nginventory"));
	crmMenuUrlPrefixs.push(obtainWebContextPath("ngjsreport"));
	
	var province = _ysp_top.publicObject["ngcrm_province"];
	//如果服务器为客服服务器，则采用路由方式打开菜单
	if(null != deployServerType && "0" == deployServerType && "jiangsu" == province)
	{
		
		//获取当前F5地址
		var f5Host = window.location.host;
	    var f5Port = window.location.port;
	    var f5Url = ""; 
	
	    if(""!=f5Port){
	        f5Url = f5Host.substr(0,f5Host.indexOf(":"));
	    }
	    else{
	        f5Url = f5Host;
	    }
	    
	    //各地市对应的路由端口
	    var bossCityId = new Array();
	    bossCityId["11"] = ":10010";
	    bossCityId["12"] = ":10008";
	    bossCityId["13"] = ":10011";
	    bossCityId["14"] = ":10009";
	    bossCityId["15"] = ":10012";
	    bossCityId["16"] = ":10013";
	    bossCityId["17"] = ":10005";
	    bossCityId["18"] = ":10007";
	    bossCityId["19"] = ":10006";
	    bossCityId["20"] = ":10001";
	    bossCityId["21"] = ":10002";
	    bossCityId["22"] = ":10003";
	    bossCityId["23"] = ":10004";
	    bossCityId["99"] = ":10014";
	    
		try
		{
			var userCity =  _ysp_top.publicObject["contactRecordNavigator"].curRecordData["userCity"];
		}catch(e){
			userCity = _ysp_top.publicObject["ngcrm_current_staff"];
		}
		try
		{
		//2011-01-24 客服整合修改签入号码归属区域为授理号码的归属区域，
			if(null == userCity || "" == userCity)
			{
				userCity = _ysp_top.publicObject["ngcrm_current_staff"];
			}
			if(null != staffFlag && "CSP"==staffFlag && menuObj.menuUrl.indexOf("/") == "0")
			{
				var region = userCity.substr(0,2);
				if(region != 0 && null != bossCityId[region] && "" != bossCityId[region])
				{
					if(null != userCity && isStartsWithSpePrefixs(menuObj.menuUrl,crmMenuUrlPrefixs))
					{
						menuObj.menuUrl = "http://" + f5Url + bossCityId[region] + menuObj.menuUrl;
					}
					else if(isStartsWithSpePrefixs(menuObj.menuUrl,crmMenuUrlPrefixs))
					{
						menuObj.menuUrl = "http://" + f5Url + bossCityId["99"] + menuObj.menuUrl;
					}
				}
			}
		}catch(e){}
	}
	var emergencyId = menuObj.emergencyId;
	if(emergencyId==null||emergencyId=="null"||emergencyId==""||emergencyId=='undefined')
	{
		emergencyId = "1111";
	}
	/*客服人工台没有应急切换，此处暂时注释
	var status = _ysp_top.emergencyStatus(emergencyId);

	if(status==false)
	{
		var isEmergency = _ysp_top.publicObject["ngcrm_isEmergency"];
		if(isEmergency == "0")
		{
			//生产系统
			alert("业务对应地市已经进入应急状态，非应急菜单，不能使用\n或者业务系统已恢复，应急菜单不能再使用");
		}else if(isEmergency == "1")
		{
			//应急系统
			alert("非应急菜单，不能使用");
		}
		return false;
	*/
	try
	{
		//获取接入电话的区号
		var areaCode = getCurrentAreaCode();
		
		//根据区号获取Region
		var areaMap = _ysp_top.publicObject["ngcrm_areaMap"];
		
		var region = areaMap.get(areaCode);
				
		//判断菜单对应应急状态
		var status = getMenuStatus(emergencyId, region);
				
		if(status == 3)
		{
			alert("当前地市已经应急,非应急菜单不能使用,请使用应急菜单");
			return;
		}
		else if(status == 2)
		{
			alert("当前地市未应急，应急菜单不能使用");
			return;
		}
		
		
	}
	catch(e)
	{
	}
	
	/*--新增菜单点击日志记录 modify by t00149371 20110705--*/
	try
	{
		var isMenuLog = _ysp_top.publicObject["isMenuLog"];
		if(isMenuLog == '1' && menuObj.isLogClick == 1)
		{
			//bsf_MenuTypeService.addMenuClickLogNew(menuObj.id);
			addMenuClickLogNew(menuObj.id, menuObj.menuName);
		}
	}
	catch(e)
	{
	}
    var oTabSet = _ysp_top.publicObject["mainTab"];

    var customer = _ysp_top.publicObject["container"].getFocus();

    var cspCustomer = _ysp_top.publicObject["cspCustomer"];
    var CSPSC = _ysp_top.publicObject["CSPSC"];
	
    
    var result = true;
    var hasIVRAuth = false;
    if(_ysp_top.publicObject["haveRoleNoCheck"] != null)
    {
        hasIVRAuth = _ysp_top.publicObject["haveRoleNoCheck"] == "true"? true:false;
        
    }
    
    if(staffFlag == null)
    {
        staffFlag = "CSP";
    }

    if(oTabSet != null)
    {
        if((menuObj.tabType==null || menuObj.tabType=="null" || menuObj.tabType=="") && staffFlag!="BOSS")
        {
            oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null);
        }
        else
        {
        	
        	switch(menuObj.tabType)
	        {
	        	
	            case TABLOGIN1:

	            	var tmp = _ysp_top.valMenuPublic(TABLOGIN1,menuObj)

	                if(tmp != "true")
	                {
	                    alert(tmp);
	                    result = false;
	                    break;
	                }
	                if(staffFlag=="BOSS" && (customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1)))
	                {
	                	
	                    var tmpUrl = obtainWebContextPath("ngcustcare")+"/custLogin.action?redirectUrl="+escape(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                    var tmpId = "valida";
	                    oTabSet.appendTab(tmpId,"身份验证",tmpUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet._showArea("oper");
	                }
	                else if(staffFlag == "CSP")
	                {
	                    if(cspCustomer==null)
	                    {
	                        alert("当前没有办理业务的用户");
	                        return;
	                    }
	                    else if(hasIVRAuth || cspCustomer.verfiy==true)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                        
		                   	oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,cspCustomer.phoneNo,true);
		                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
		                    oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                        
	                    }
	                    else
	                    {
	                        myCheckPassword();
	                        return;
	                    }
	                }
	                else
	                {
	                	var tmpTabId = "BOSS^"+customer.id;

	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];

	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    }
	                   
	                }
	                break;
	            case TABLOGIN2:
	                if(staffFlag=="BOSS" && (customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1)))
	                {
	                    var tmpUrl = obtainWebContextPath("ngcustcare")+"/custLogin.action?redirectUrl="+escape(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                    var tmpId = "valida";
	                    oTabSet.appendTab(tmpId,"身份验证",tmpUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet._showArea("oper");
	                }
	                else if(staffFlag == "CSP")
	                {
	                    if(cspCustomer==null)
	                    {
	                        alert("当前没有办理业务的用户");
	                        return;
	                    }
	                    else if(hasIVRAuth || cspCustomer.verfiy==true)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                        
	                       	oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,cspCustomer.phoneNo,true);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                       
	                    }
	                    else
	                    {
	                        myCheckPassword();
	                        return;
	                    }
	                    
	                }
	                else
	                {
	                	var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    }
	                }
	                break;
	            case TABLOGIN3:
	            	
	                var tmp = _ysp_top.valMenuPublic(TABLOGIN3,menuObj)
	                
	                if(tmp != "true")
	                {
	                    alert(tmp);
	                    break;
	                }
	  
	                if(staffFlag=="BOSS" && (customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1)))
	                {
	                    var tmpUrl = obtainWebContextPath("ngcustcare")+"/custLogin.action?redirectUrl="+escape(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                    var tmpId = "valida";
	                    oTabSet.appendTab(tmpId,"身份验证",tmpUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet._showArea("oper");
	                }
	                else if(staffFlag == "CSP")
	                {
	                    if(cspCustomer==null)
	                    {
	                        alert("当前没有办理业务的用户");
	                        return;
	                    }
	                    else if(hasIVRAuth || cspCustomer.verfiy==true)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                       	oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,cspCustomer.phoneNo,true);
	                       	oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                        
	                    }
	                    else
	                    {
	                        myCheckPassword();
	                        return;
	                    }
	                }
	                else
	                {
	                	var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    }
	                    	
	                }
	                break;
	            case TABLOGIN4:
	            	var tmp = _ysp_top.valMenuPublic(TABLOGIN4,menuObj)
	                
	                if(tmp != "true")
	                {
	                    alert(tmp);
	                    break;
	                }
	  
	                if(staffFlag=="BOSS" && (customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1)))
	                {
	                    var tmpUrl = obtainWebContextPath("ngcustcare")+"/custLogin.action?redirectUrl="+escape(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                    var tmpId = "valida";
	                    oTabSet.appendTab(tmpId,"身份验证",tmpUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet._showArea("oper");
	                }
	                else if(staffFlag == "CSP")
	                {
	                    if(cspCustomer==null)
	                    {
	                        alert("当前没有办理业务的用户");
	                        return;
	                    }
	                    else if(hasIVRAuth || cspCustomer.verfiy==true)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                       	oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,cspCustomer.phoneNo,true);
	                       	oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                        
	                    }
	                    else
	                    {
	                        myCheckPassword();
	                        return;
	                    }
	                }
	                else
	                {
	                	var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    }
	                    	
	                }
	            	break;
	            case TABNOLOGIN1:
	                var tmp = _ysp_top.valMenuPublic(TABNOLOGIN1,menuObj)
	                if(tmp != "true")
	                {
	                    alert(tmp);
	                    break;
	                }
	                if(menuObj.moduleId == "GroupCustBuss_WEB")
	                {
	                    if(menuObj.menuUrl.indexOf("?") > -1)
	                    {
	                        var tmpUrl = menuObj.menuUrl + "&redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    else
	                    {
	                        var tmpUrl = menuObj.menuUrl + "?redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    break;
	                }
	                if(staffFlag == "CSP")
	                {
	                    var tmpNo = null;
	                    if(cspCustomer != null)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                        tmpNo = cspCustomer.phoneNo;
	                    }
	                    else
	                    {
	                        initParams(null);
	                    }
	                    

	                   	oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,tmpNo);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                    oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                   
	                }
	                else if(customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1))
	                {
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                
	                    oTabSet._showArea("oper");
	                } 
	                else
	                {
	                    var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
	                    	oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    }
	                }
	                break;
	            case TABNOLOGIN2:
	            	if(menuObj.moduleId == "GroupCustBuss_WEB")
	                {
	                    if(menuObj.menuUrl.indexOf("?") > -1)
	                    {
	                        var tmpUrl = menuObj.menuUrl + "&redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    else
	                    {
	                        var tmpUrl = menuObj.menuUrl + "?redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    break;
	                }
	                if(staffFlag == "CSP")
	                {
	                    var tmpNo = null;
	                    if(cspCustomer != null)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                        tmpNo = cspCustomer.phoneNo;
	                    }
	                    else
	                    {
	                        initParams(null);
	                    }
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,tmpNo);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                    oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                    
	                }
	                else if(customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1))
	                {
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                
	                    oTabSet._showArea("oper");
	                }
	                else
	                {
	                    var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
		                    
	                    }
	                }
	                break;
	            case TABNOLOGIN3:
	                var tmp = _ysp_top.valMenuPublic(TABNOLOGIN3,menuObj)
	                if(tmp != "true")
	                {
	                    alert(tmp);
	                    break;
	                }
	                if(menuObj.moduleId == "GroupCustBuss_WEB")
	                {
	                    if(menuObj.menuUrl.indexOf("?") > -1)
	                    {
	                        var tmpUrl = menuObj.menuUrl + "&redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    else
	                    {
	                        var tmpUrl = menuObj.menuUrl + "?redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    break;
	                }
	                if(staffFlag == "CSP")
	                {
	                    var tmpNo = null;
	                    if(cspCustomer != null)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                        tmpNo = cspCustomer.phoneNo;
	                    }
	                    else
	                    {
	                        initParams(null);
	                    }
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,tmpNo);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                    oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                     
	                }
	                else if(customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1))
	                {
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                
	                    oTabSet._showArea("oper");
	                }
	                else
	                {
	                	var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet._appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
		                    
	                    }
	                }
	                break;    
	            case TABNOLOGIN4:
	            	var tmp = _ysp_top.valMenuPublic(TABNOLOGIN4,menuObj)
	                if(tmp != "true")
	                {
	                    alert(tmp);
	                    break;
	                }
	                if(menuObj.moduleId == "GroupCustBuss_WEB")
	                {
	                    if(menuObj.menuUrl.indexOf("?") > -1)
	                    {
	                        var tmpUrl = menuObj.menuUrl + "&redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    else
	                    {
	                        var tmpUrl = menuObj.menuUrl + "?redirectUrl=" +encodeURI(menuObj.menuUrl)+"&tabid="+encodeURI(menuObj.id)+"&tabname="+encodeURI(encodeURI(menuObj.menuName));
	                        oTabSet.appendTab(menuObj.id,menuObj.menuName,tmpUrl,menuObj.imageUrl,null,null,null);
	                        oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                        
	                        oTabSet._showArea("oper");
	                    }
	                    break;
	                }
	                if(staffFlag == "CSP")
	                {
	                    var tmpNo = null;
	                    if(cspCustomer != null)
	                    {
	                        initParams(cspCustomer.phoneNo);
	                        tmpNo = cspCustomer.phoneNo;
	                    }
	                    else
	                    {
	                        initParams(null);
	                    }
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null,tmpNo);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                    oTabSet.addFocusEvent(menuObj.id,focusEventForNG);
	                     
	                }
	                else if(customer == null || (menuObj.dyfield1 != null && menuObj.dyfield1 != 'null' && menuObj.dyfield1 != '' && customer.custtype != null && customer.custtype != menuObj.dyfield1))
	                {
	                    oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null);
	                    oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                
	                    oTabSet._showArea("oper");
	                }
	                else
	                {
	                	var tmpTabId = "BOSS^"+customer.id;
	                    var tmpTabset = _ysp_top.publicObject[tmpTabId];
	                    if(tmpTabset)
	                    {
	                      	tmpTabset._appendTab(tmpTabId + "^" + menuObj.id + "~" +customer.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
	                    	tmpTabset.addCloseEvent(tmpTabId + "^" + menuObj.id + "~" +customer.id,removeTabForNGCRM);
	                    	oTabSet.focusTab(tmpTabId);
	                    }else
	                    {
		                    oTabSet._appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,customer.id);
		                    
	                    }
	                }
	            	break;        
	            default :
	                oTabSet.appendTab(menuObj.id,menuObj.menuName,menuObj.menuUrl,menuObj.imageUrl,null,null,null);
	                oTabSet.addCloseEvent(menuObj.id,removeTabForNGCRM);
	                if(menuObj.id != '001001')
	                {
	                	oTabSet._showArea("oper");
	                }
	                break;
	        } 
        } 
        _ysp_top.CUR_OPERATION = menuObj.id;
    }
    else
    {
        result = false;
    } 
    //还原原菜单的URL
    menuObj.menuUrl = ogzMenuUrl;
    return result;
}
function initParams(phoneNo)
{
    if(phoneNo == null)
    {
        _ysp_top.setCookieNoCode("com.huawei.boss.CURRENT_USER","com.huawei.boss.NO_CURRENT_USER");
    }
    else
    {
        _ysp_top.setCookieNoCode("com.huawei.boss.CURRENT_USER",phoneNo);
    }
}

function myCheckPassword()
{
    var oAction = _ysp_top.publicObject[CSP_CALLBAR];
    if(oAction!= null && oAction.chfApi != null && oAction.chfApi.isSignIn())
    {
        try
        {
            oAction.eval("ccAction.checkPwd()"); 
        }
        catch(e)
        {
            //
        }
    }
    else
    {
        alert("请先进行密码验证操作");
    }
}

//获取接入电话的区号
function getCurrentAreaCode()
{
	var areaCode = null;
    var oChfApi = null;
	if(_ysp_top != null && _ysp_top.publicObject != null && _ysp_top.publicObject["CSPSC"] != null)
	{
	    oChfApi = _ysp_top.publicObject["CSPSC"].chfApi;
	}
	if(oChfApi != null)
	{
	    try
	    {
	        areaCode = ochfApi.getCallingInfo().getUserAreaCode();
	    }
	    catch(e)
	    {
	    	
	    }
	}
	oChfApi=null;
	
	return areaCode;
}

/**
	根据菜单应急状态和目前系统应急状态判断是否可以打开菜单
	1:正常
	2:地市未应急，不能打开应急菜单
	3:地市已应急，不能打开正常菜单
	
*/
var NGCRM_SYSTEM_NORMAL = 0;//正常状态
var NGCRM_SYSTEM_EMER = 1;//应急状态

function getMenuStatus(emergencyId,region)
{
	var status = 1;
	var emerObj;
	//获取应急地市信息
	var ngcrm_emergency = _ysp_top.publicObject["ngcrm_emergency"];
	
	if(ngcrm_emergency)
	{
		for(i=0;i<ngcrm_emergency.length;i++)
		{
			if(ngcrm_emergency[i].cityId == region)
			{
				emerObj = ngcrm_emergency[i];
				
				break;
			}
		}
	}
	//如果应急缓存里有地市信息
	if(emerObj)
	{
		//如果地市未应急，则判断菜单能否在正常情况下使用
		if(emerObj.crmStatus==NGCRM_SYSTEM_NORMAL && emerObj.bossStatus == NGCRM_SYSTEM_NORMAL && emerObj.resStatus == NGCRM_SYSTEM_NORMAL)
		{
			status = (emergencyId.charAt(0)=="1") ? 1 : 2;
		}
		else
		{//一旦地市应急，则看是否在应急状态下能否打开菜单
			var crmUsable=true;
			var bossUsable=true;
			var resUsable=true;
			if(emerObj.crmStatus == NGCRM_SYSTEM_EMER)
			{	
				crmUsable=(emergencyId.charAt(3)=="1");
			}			
			if(emerObj.bossStatus == NGCRM_SYSTEM_EMER)
			{
				bossUsable=(emergencyId.charAt(2)=="1");
			}
			if(emerObj.resStatus == NGCRM_SYSTEM_EMER)
			{
				resUsable=(emergencyId.charAt(1)=="1");
			}	
			status = (crmUsable && bossUsable && resUsable) ? 1 : 3;		
		}
				
	}
	else
	{//如果应急缓存里没有地市信息，则认为地市不应急
		status = (emergencyId.charAt(0)=="1") ? 1 : 2;
	}
	
	return status;
}

/*
 * 获取当前打开的所有菜单列表
*/
function getCurrentOpenMenus()
{
	var menuArray = new Array();
	var mTabSet = _ysp_top.publicObject["mainTab"];
	if(mTabSet != null) 
    {
		for(var i=0;i<mTabSet.lOpenedTabs.size();i++)
		{
		    var tmpTabId = mTabSet.lOpenedTabs.get(i);
		    if(tmpTabId.indexOf("^")>-1)
		    {
		    	var oTabSet = _ysp_top.publicObject[tmpTabId];
		    	for(var j=0;j<oTabSet.lOpenedTabs.size();j++)
		    	{
		    		var tabCode = oTabSet.lOpenedTabs.get(j);
		    		
		    		var tmp = mTabSet.getMenuObj(getMenuId(tabCode));
		    		if(tmp != null)
		    		{
		    			if(tabCode.split("~")[1] != null)
		    			{
		    				tmp.operateArea = tabCode.split("~")[1];
		    			}
				   	 	menuArray.push(tmp);
				   	}
			     }
			 }
			 else
			 {
			 	var tmp = mTabSet.getMenuObj(getMenuId(tmpTabId));
			 	if(tmp != null)
			 	{	
			 		tmp.operateArea = "NO_CURRENT_USER";
			 		menuArray.push(tmp);
			 	}
			 }
		}
	}
	
	return menuArray;
}

function addMenuClickLogNew(menuId,menuName)
{
        var sUrl = contextPath + "/ngportal/logMenuClick.action";
        
        try
        {
            $.ajax({
                url: sUrl,
                data: {"menuId":menuId,"menuName":menuName},
                type: "post",
                success:function(data)
                {}
            });
        }
        catch (ex)
        {
            alert(ex.message);
        }
}

//html 解码
function htmlDecode(str)
{   
	var s = "";   
	if (str.length == 0) return "";
	s = str.replace(/&amp;/g, "&");
	s = s.replace(/&lt;/g, "<");
	s = s.replace(/&gt;/g, ">"); 
	s = s.replace(/&#39;/g, "\"");   
	s = s.replace(/&quot;/g, "\""); 
	return s;   
}

// HTML 编码
function htmlEncode(str) 
{
	 var s = "";
	 if (str.length == 0) return "";
	 s = str.replace(/&/g, "&amp;");
	 s = s.replace(/</g, "&lt;");
	 s = s.replace(/>/g, "&gt;");  
	 s = s.replace(/\"/g, "&#39;");
	 s = s.replace(/\"/g, "&quot;");
	 return s;
}
/**--验证控件值是否为日期时间格式 --*/
function validateDateTime(value) 
{
  var reg = /^[1-2]\d{3}[-][0-1]\d[-][0-3]\d\s[0-2]\d[:][0-5]\d[:][0-5]\d$/;
  return reg.test(value);
} 
/**--验证控件值是否为日期时间格式 --*/
function validateDate(value) 
{
  var reg = /^[1-2]\d{3}[-][0-1]\d[-][0-3]\d$/;
  return reg.test(value);
}
