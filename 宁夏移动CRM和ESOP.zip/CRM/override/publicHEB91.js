/**
 t69548
  xmlDataUrl :url
  targetSelect:select
  optionsLeft:要保留select的个数
**/
function doFreshSpecially(xmlDataUrl, targetSelect, optionsLeft){
	var ob = new ActiveXObject("Microsoft.XMLDOM"); 
	ob.async = false;  
	ob.load(xmlDataUrl); 
	if(ob.documentElement==null) return;
	if(optionsLeft!="undefined"){
		if(targetSelect.options.length>optionsLeft){
			targetSelect.length = optionsLeft;
		}
	}else{
		targetSelect.length = 0;
	}

	var rootName = ob.documentElement.tagName;
	if(rootName=="ERROR"){
		alert(ob.documentElement.text);
		return;
	}else if(rootName=="root"){
		for(var i=0; i<ob.documentElement.childNodes.length; i++){
			node = ob.documentElement.childNodes[i];
			o = document.createElement("OPTION");
			o.text = node.childNodes[1].text + "(" + node.childNodes[0].text + ")";
			o.value = node.childNodes[0].text;
			targetSelect.options[targetSelect.options.length] = o;
		}
	}
  }
  /**
  t69548 打印初始化
  style:标题列宽
  title:表格名称
  table:所要打印的表格
  start:打印开始列数
  index:0:直接导出 1:空一列
  **/
   function initPrintHEB(style, title, table, start,index)
	{		
		var rows = table.rows;	
		var arrayValue = new Array();
		
		cell_Rows = rows.length;
		cell_Cols = rows[0].cells.length;
		Cell.PrintSetOrient(1);
		
		for(var i = 0; i < rows.length; i++)
		{
			var cells = rows[i].cells;
			var dataCells = new Array();
	
			for(var m = start; m < cells.length; m++)
			{
				dataCells.push(cells[m].innerText == "&nbsp;"? "" : cells[m].innerText);
			}			
			arrayValue.push(dataCells);			
		}
		Cell.SetRows(5 + cell_Rows, 0);
		Cell.SetCols(cell_Cols + 1 + index, 0);
		Cell.PrintSetPaper(9);   
		Cell.PrintSetScale(1.0); 
		Cell.PrintSetMargin(160, 50, 200, 50); 
		Cell.DrawGridLine(1 + index, 5, cell_Cols + (1 - start), cell_Rows + 4, 0, 2, -1);
		 for(var i = 0; i < style.length; i++)
		 {
			Cell.SetColWidth(0, style[i], i + 1 + index, 0);
		 }
	
		Cell.MergeCells(1, 1, cell_Cols, 4);
		Cell.SetCellAlign(1, 1, 0, 32+4);
		Cell.SetCellString(1, 1, 0, title);
		Cell.SetCellFontStyle(1, 1, 0, 2);
		Cell.SetCellFontSize(1, 1, 0, 20);		
		for(i = 0; i < cell_Rows; i++)
		{
			for(var j = 0; j < cell_Cols; j++)
			{		    
			    Cell.SetCellString (j + 1 + index, 5 + i, 0, arrayValue[i][j]);			
	            Cell.SetCellAlign(j + 1 + index, 5 + i, 0, 32 + 4);
			}
		}
	}

   function showWindow(wintype, url, args, style)
   {
   	if(arguments.length==3)
   	{
   		style = arguments[2];
   		args = arguments[1];
   		url = arguments[0];
   		wintype = "0";
   	}

   	var sUrl = url;
   	var param = "?ngcrm_rnd="+Math.random()+"&ngcrm_reserved1=1";
   	var idx = url.indexOf("?");
   	if(idx >= 0)
   	{
   		sUrl = url.substring(0, idx);
   		param = param + "&" + url.substring(idx+1);
   	}
   	sUrl = sUrl + param;

   	if("0"==wintype || "modal"==wintype)
   	{
   		return window.showModalDialog(sUrl, args, style);
   	}else if("1"==wintype || "modeless"==wintype)
   	{
   		//return window.showModelessDialog(sUrl, args, style);
   		return window.showModalDialog(sUrl, args, style);
   	}else
   	{
   		_ysp_top.win = window.open(sUrl, args, style);
   		return _ysp_top.win;
   	}
   }
   
   function openTopWin(url, name, style)
   {
       _ysp_top.win=showWindow("2",url,name,style);
       return _ysp_top.win;
   }
   function openTopWin(url, name)
   {
   	_ysp_top.win=showWindow("2",url,name,"");
   	return _ysp_top.win;
   }

   function openTopWin(url)
   {
   	_ysp_top.win=showWindow("2",url,"_blank","");
   	return _ysp_top.win;
   }

   /**
    * 校验是否是数值。
    * @param s
    * @returns {Boolean}
    */
   function isDigit(s) { 
		var patrn=/^[0-9]{1,20}$/;
		if (!patrn.exec(s))
			return false;
		else
			return true;
	} 
   
   /**
    * 去除val字符串中的空格。
    * @param val
    * @returns
    * @author 张纪锋
    */
   function trim(val){
	   var result;
	   result = val.replace(/(^\s*)|(\s*$)/g, "");
	   return result;
   }
   /**
    * 通过ID，获取对象。
    * @param id
    * @returns
    * @author 张纪锋
    */
	function getObj(id) {
		  var  obj = null;
		  obj = document.getElementById(id);
		  return obj;
	}
	/**
	 * 校验ID对象的值是否为空。
	 * @param id
	 * @param altMsg
	 */
	function checkNvl(id,altMsg){
		var obj = getObj(id);
		var val = '';
		  if(obj != null)
			  val = trim(obj.value);
		if(val == ''){
		  tips.autoHidden(altMsg,id,"../../../skins/ng35",3000,"bottom",200);
		  return false;
		}else{
		  return true;
		}
	}
	
	/**
     * 防止sql注入过滤特殊字符
     * @param string
	 * @author gexiaoxing 20150505
	 * @return
	 */
	function valiteParamToSqlKey(paramStr,noValiteKey){
		//var str=new Array("'", "<", ">", "%", "\"\"", ",", ".", ">=", "=<", "<>", "--", "_", ";", "||", "[", "]", "&", "/", "-", "|", " ", "select", "update", "insert", "delete", "declare", "@", "exec", "dbcc", "alter", "drop", "create", "backup", "if", "else", "end", "and", "or", "add", "set", "open", "close", "use", "begin", "retun", "as", "go", "exists");
		var str=new Array("select", "update", "insert", "delete", "declare", "@", "exec", "dbcc", "alter", "drop", "create", "backup", "if", "else", "end", "and", "or", "add", "set", "open", "close", "use", "begin", "retun", "as", "go", "exists");
		if(null!=paramStr&&""!=paramStr){
			
    		paramStr=paramStr.toLocaleLowerCase();		//转换为小写
    		for(var i=0;i<str.length;i++){
    			var key = str[i];
    			if (paramStr.indexOf(key)>=0) {        
    					//排除不需要过滤的特殊字符
        			if(noValiteKey==key){
        				continue;
        			}
    			  return key;       
    			}
    		}
    	}
    	return null;
	}
	
	
	