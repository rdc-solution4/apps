// 保存公共对象
var publicObject = new Array();

// 注册公共对象
function registerObject(objId,obj){
    publicObject[objId] = obj;
    return true;
}

// 返回公共对象
function getObject (objId){
    if(publicObject[objId] == null)
    {
        return null;
    }
    return publicObject[objId];
}

// 根据对象编号删除公共对象
function removeObject (objId){
    if(publicObject[objId] == null)
    {
        return false;
    }
    publicObject[objId] = null;
}

function defined(object)
{
  return typeof(object) != "undefined";
}

function checkphone(phoneNumber)
{
	//z46522 移动号码可以使用13、15、18开头
	var patrn = /^\+*(86)*((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})){1}[0-9]{8}$/;
   	var isMobile = patrn.test(phoneNumber);
   	if(!isMobile){
     	alert("不是移动的号码！");
   	}
   	return  isMobile;
 }
  
 //判断一个字符串是否匹配一个正则表达式
 //   ^\w+[@]\w+[.]\w+$       E-Mail地址
 //   ^[0-9-]+$               数字
 function isMatch(Str, Patrn)
 {
   var re = new RegExp(Patrn,"gim");
   return re.test(Str);
 }
 
// Map定义
function NullKey()
{
}
new NullKey();
function CRMMap()
{
    var keys = new Array();
    this.contains = function(key){
       var entry = findEntry(key);
       return !(entry == null || entry instanceof NullKey);
    }
    this.get = function(key) {
     var entry = findEntry(key);
     if ( !(entry == null || entry instanceof NullKey) )
        return entry.value;
      else
        return null;
    };
    this.put = function(key, value) {
      var entry = findEntry(key);
      if (entry){
        entry.value = value;
      } else {
        addNewEntry(key, value);
      }
    };
    this.remove = function (key){
      for (var i=0;i<keys.length;i++){
        var entry = keys[i];
        if (entry instanceof NullKey) continue;
        if (entry.key == key){
            keys[i] = NullKey;
        }
      }
    };
    this.size = function() {
    	return keys.length;
    };
    this.getKeys = function() {
    	return keys;
    };
    function findEntry(key){
      for (var i=0;i<keys.length;i++){
        var entry = keys[i];
        if (entry instanceof NullKey) continue;
        if (entry.key == key){
            return entry
        }
      }
      return null;
    };
    function addNewEntry(key, value){
        var entry = new Object();
        entry.key = key;
        entry.value = value;
        keys[keys.length] = entry;
    }
}

	function isEmptyString(str)
	{
	 	if(str == null)
		{
			return true;
		}
	
		str=trim(str); 
	 	if (str.length==0 )
	 	 {
	      return true;
	  	 }
	 	  else 
	  	 { 
	  		 return false;
	    }
	
	}
	
	function trim(str)
	{
		 return str.replace(/(^\s*)|(\s*$)/g, ""); 
	}


	//验证照片名称后缀是否是有效的格式
	function isValidPhotoName(inputName){
			
			inputName=trim(inputName);	
			if(inputName == ""){
				return false;
			}
			var s = inputName.lastIndexOf(".");
			inputName = inputName.substring(s+1,inputName.length);
		    var v = new RegExp();
		    v.compile("jpg|gif|bmp|JPG|GIF|BMP|PNG|png|cgm|CGM");
		    if (!v.test(inputName)){ 
		        return false; 
		    }
		    return true;
		}
/**
 * 同步的ajax调用
 * @param goUrl
 * @param params
 * @param dataType
 * @param errorMsg
 * @return
 */
function ajaxSend(goUrl,params,dataType,errorMsg)
{
	var rtnData;
	if(dataType==null)
	{
		dataType = "text";
	}
	try
	{
		jQuery.ajax({
			async: false,
			url:goUrl,
			data:params,
			cache:false,
			type:"post",
			dataType:dataType,
			success:function(data,textStatus)
					{
						if (data == null)
					   	{
							if(errorMsg){
								alert(errorMsg);
							}
					   	}else
					   	{
					   		rtnData = data;
					   	}
					}
		});
		
	}
	catch (ex)
	{
		alert(ex);
	}
	
    return rtnData;
}
/**
 * 异步ajax调用
 * @param goUrl
 * @param params
 * @param dataType
 * @param successFun
 * @return
 */
function asyncSend(goUrl,params,dataType,successFun,errorFun)
{
	if(dataType==null)
	{
		dataType = "text";
	}
	$.ajax({
			url:goUrl,
			data:params,
			cache:false,
			type:"post",
			dataType:dataType,
			success:successFun,
			error:errorFun
		});
}

//判断字符串是否包含特殊字符
function isSpecialString(str)
{
	var compare = "\"|~`!#$%^&*=+\'/?><";
	for (var i=0;i<str.length;i++)
	{
		if (compare.indexOf(str.charAt(i))!=-1)
		{
			return true;
		}
	}
	return false;
}

function getXmlHttpObj()
{
  try 
  {
    if (window.XMLHttpRequest) 
    {
      var req = new XMLHttpRequest();
      
      // some versions of Moz do not support the readyState property
      // and the onreadystate event so we patch it!
      
      if (req.readyState == null) 
      {
        req.readyState = 1;
        req.addEventListener("load", function () 
        {
          req.readyState = 4;
          if (typeof req.onreadystatechange == "function")
            req.onreadystatechange();
        }, false);
      }
      
      return req;
    }
    if (window.ActiveXObject) 
    {
      return new ActiveXObject(getXmlHttpPrefix() + ".XmlHttp");
    }
  }
  catch (ex) 
  {
    alert("Your browser does not support XmlHttp objects");
    return null;
  }
}
function getXmlHttpPrefix() 
{
  if (getXmlHttpPrefix.prefix)
    return getXmlHttpPrefix.prefix;
  
  var prefixes = ["MSXML2", "Microsoft", "MSXML", "MSXML3"];
  var o;
  for (var i = 0; i < prefixes.length; i++) 
  {
    try 
    {
      // try to create the objects
      o = new ActiveXObject(prefixes[i] + ".XmlHttp");
      return getXmlHttpPrefix.prefix = prefixes[i];
    }
    catch (ex) 
    {
      alert("Could not find an installed XML parser");
    };
  }
}


//给业务侧使用的打开作台函数
function openSalesConsole()
{
	debugger;
	var saleConsoleTel = document.getElementById("saleConsoleTel").value;
	if (checkSalesConsoleTel(saleConsoleTel)) {
		var salesConsoleStr = "营销工作台(iCRM)";

		if (_ysp_top.publicObject["ngcrm_province"] == "shandong") {
			salesConsoleStr = "营销助手(iCRM)";
		}

		var $Scope = _ysp_top.sp;
		var $Model = $Scope.$Model;
		var $fire = $Scope.$Inject("$Fire");
		$fire({
			"service" : "/gadget/common/operator/queryLoginOpenMenuByMenuId",
			"target" : "$Model.tempMenu",
			params : {
				'menuId' : "SalesConsole_WEB"
			}
		}, $Scope).onafter(function() {
			var orignalMenuObj = undefined;
			if ($Model.tempMenu && $Model.tempMenu.length >= 1)
			{
				orignalMenuObj = $Model.tempMenu[0];
			}
			var newMenuUrl;
			if (orignalMenuObj) {
				var orignalMenuUrl = orignalMenuObj.menuUrl;
				if (orignalMenuUrl.indexOf("?") > -1) {
					newMenuUrl = orignalMenuUrl + "&telNumHigh=" + saleConsoleTel
							+ "&noCrmSSO=1";
				} else {
					newMenuUrl = orignalMenuUrl + "?telNumHigh=" + saleConsoleTel
							+ "&noCrmSSO=1";
				}
				if (_ysp_top.publicObject["SalesConsole_telNum"]) {
					newMenuUrl = newMenuUrl + "&telNum="
							+ _ysp_top.publicObject["SalesConsole_telNum"];
				}

				if (_ysp_top.publicObject["ngcrm_province"] == "shandong") {
					// 营销助手入口较多, 增加场景标识, 方便后续统计
					newMenuUrl = newMenuUrl + "&scene=loginCRM";
				}

				try {
					/*
					 * 说明：BES不支持用户页签，暂时屏蔽 var customer =
					 * _ysp_top.publicObject["container"].getFocus();
					 * 
					 * if(customer) { var salesConsoleInSubPage = "BOSS^" +
					 * customer.id + "^SalesConsole_WEB~" + customer.id; var
					 * tmpTabSet = _ysp_top.publicObject["BOSS^" + customer.id];
					 * if(tmpTabSet && tmpTabSet.hasTab(salesConsoleInSubPage)) {
					 * tmpTabSet.refrechTabConfig(salesConsoleInSubPage,
					 * newMenuUrl); tmpTabSet.focusTab(salesConsoleInSubPage); }
					 * else { _ysp_top.publicObject["openMenu"]("SalesConsole_WEB",
					 * salesConsoleStr, newMenuUrl); } } else {
					 */
					var tmpTabSet = _ysp_top.publicObject["mainTab"];
					if (tmpTabSet && tmpTabSet.hasTab("SalesConsole_WEB")) // 如果页签已打开
					{
						tmpTabSet.refreshCurrentTab(newMenuUrl); // 刷新页签内的URL
						_ysp_top.TabSet.showTabItem("SalesConsole_WEB");
					} else {
						_ysp_top.publicObject["openMenu"]("SalesConsole_WEB",
								salesConsoleStr, newMenuUrl);
					}
					// }
				} catch (e) {
				}
			} else {
				_ysp_top.openMenu("SalesConsole_WEB");
			}
			// 清空营销工作台左侧号码输入框
			document.getElementById("saleConsoleTel").value = "";
		});
	}
}

// 如果营销工作台已经打开,则先关闭
function closeSalesConsoleIfHasOpened()
{
  var salesConsoleInSubPage;
  try
  {
	  var customer = _ysp_top.publicObject["container"].getFocus();
      salesConsoleInSubPage = "BOSS^" + customer.id + "^SalesConsole_WEB~" + customer.id;
  }
  catch (e)
  {}
  var salesConsoleInMainPage = "SalesConsole_WEB";
  var tabSet = _ysp_top.publicObject["mainTab"];
  
  
  try
  {
      tabSet.removeTabByCode(salesConsoleInMainPage, false);
  }
  catch (e){}
  try
  {
      tabSet.removeTabByCode(salesConsoleInSubPage, false);
  }
  catch (e){}
}

// 检查营销工作台中的号码输入
function checkSalesConsoleTel(inputSalesConsoleTel)
{
  var reg = /^[0-9]{11}$/g;
  
  var salesConsoleTel = $.trim(inputSalesConsoleTel);
  
  if(salesConsoleTel != '')
  {
      if (!reg.test(salesConsoleTel))
      {
          alert("必须输入11位手机号码");
          return false;
      }
      else 
      {
          if (!isUserStatusNormal(salesConsoleTel))
          {
              alert("用户状态不正常!");
              return false;
          }
          else
          {
        	  return true;         
          }
      }
  }
  else
  {
      if (_ysp_top.publicObject["SalesConsole_telNum"] == '' && !isUserHasLogin())
      {
          if(_ysp_top.publicObject["ngcrm_province"] == "shandong")
          {
              alert("请先登录用户");
          }
          else
          {
              alert("请输入号码!");
          }
          return false;
      }
      else 
      {
          return true;
      }
  }
}

//用户是否已登录
function isUserHasLogin()
{
  var isUserHasLogin = true;
	//todo：这里调用之前提供的检查用户是否已登录的JS
  return isUserHasLogin;
}

//用户是否正常，暂时直接返回true
function isUserStatusNormal(salesConsoleTel)
{
  return true;
}


sparkIntervalObj = undefined;

/**
* @isSpark boolean值 ture为闪烁，false为停止闪烁
* @customizeNoteFlag 可以无此参数，可以为空，默认为"！"，非空则在 营销工作台 后动态加入改值
*/
function toggleSalesConsoleSpark(isSpark, customizeNoteFlag, telNum, menuId)
{
	debugger;
  var salesConsoleStr = "查询";
  
  if(_ysp_top.publicObject["ngcrm_province"] == "shandong")
  {
      salesConsoleStr = "营销助手";
  }
  if (telNum != undefined) 
  {
      if (telNum != _ysp_top.publicObject["SalesConsole_telNum"] && !isSpark)
      {
          var tabSet = _ysp_top.publicObject["mainTab"];
          try
          {
              tabSet.removeTabByCode("SalesConsole_WEB", false); //已打开营销工作台则先关闭
          }
          catch (e) {}
      }
      _ysp_top.publicObject["SalesConsole_telNum"] = telNum;
  }
  
  var target = document.getElementById("saleConsoleBtn");
  var targetName = $(target).html();
  // 防止重复触发
  try
  {
      if (target.style.color == "" && isSpark && sparkIntervalObj == undefined)
      {
          // 开始闪动
          sparkIntervalObj = window.setInterval(spark, 500);
          $(target).html(salesConsoleStr + (undefined == customizeNoteFlag ? "!" : customizeNoteFlag));
          if (undefined != menuId && "" != menuId && null != menuId)
          {
        	  _ysp_top.publicObject["triggerSalesConsoleSparkMenuId"] = menuId;
          }
      }
      else if (!isSpark && sparkIntervalObj != undefined)
      {
          window.clearInterval(sparkIntervalObj);
          sparkIntervalObj = undefined;
          // 还原
          target.style.color="";
          $(target).html(salesConsoleStr);

          _ysp_top.publicObject["triggerSalesConsoleSparkMenuId"] = "";
      }
  }
  catch (e)
  {
  }
  target = null;
  targetName = null;
}

function spark()
{
  var target = document.getElementById("saleConsoleBtn");
  target.style.color = (target.style.color != "red" ? "red" : "orange");
  target = null;
}

//营销助手服务号码编辑框焦点事件
function saleConsoleTelFocus()
{
	var telValue = document.getElementById("saleConsoleTel").value;
  if (telValue == "请输入手机号码")
  {
  	document.getElementById("saleConsoleTel").value = "";
  	document.getElementById("saleConsoleTel").style.color = "#000000";
  }
}

//营销助手服务号码编辑框失去焦点事件
function saleConsoleTelBlur()
{
  var telValue = document.getElementById("saleConsoleTel").value;
  if (telValue == "")
  {
      document.getElementById("saleConsoleTel").value = "请输入手机号码";
      document.getElementById("saleConsoleTel").style.color = "#888888";
  }
}