/**
 * 重置密码类型选中值
 */
var pwdResetType = null;

/**
 * 密码重置方式选中值
 */
var itemVal = null;

/**
 * 新密码校验结果
 */
var newFlag = false;

/**
 * 是否是CSP系统
 */
var isCspFlag = false;

/**
 * 是否是ICT系统
 */
var isIctFlag = false;
/**
 * 用户号码
 */
var servNumber = "";

/**
 * 密码重置方式下拉列表
 */
var resetType = null;


$Controller(
		"bes.oc.resetpwd",
		{
			initDict : function($Page, $Gadget, $Fire, $UI)
			{
				var page = this;
				//初始化默认密码未被输入过
				$Page.isPwdPress = false;
				$Gadget.resetMethods =
					[
					 {
						 key : "C",value : $UEE.i18n("ad.person.option.EnteredByCustomer")//客户输入密码
					 },
					 {
						 key : "R",value : $UEE.i18n("ad.person.option.ResetToRandom")//系统随机密码
					 },
					 {
						 key : "I",value : $UEE.i18n("ad.person.option.ResetToInitial")//重置为初始密码
					 }
					 ];

				var params = {
						"dictkeylist" : ["OC_NET_TYPE"]
				};

				//取数据字典
				$Fire
				({
					service : "common/dictkey",
					params : params,
					target : "$Gadget.dataDict",
					onafter : function ($Gadget, $UI)
					{
						debugger;

						//用户类型
						$Gadget.netTypeDictList = $Gadget.dataDict["OC_NET_TYPE"];

						//获取ims重置密码模板信息


					//通过电话号码获取用户信息
					$Fire({
						service : '/bes.oc.ocquerysubscriptionbaseservice/querysubscriber',
							'params' : {
								"request" : {
									"serviceNumber":(window._ysp_top.loginReq || {}).loginId,
								}
						},
						target : '$Gadget.subsinfotosearch',
						onafter : function($Gadget) {
							debugger;
							//判断mainoffer是否为 1310001445
							if( $Page.projectVersion=="NINGXIA" &&$Gadget.subsinfotosearch && $Gadget.subsinfotosearch.subscriberInfo &&
							$Gadget.subsinfotosearch.subscriberInfo[0].offeringId == '1310001445' ){

								var queryReq = {
												'offerid': 1310001445
										};
								$Fire({
									'service': 'bes.oc.queryofferdetailservice/queryofferdetail',
									'params': queryReq,
									'target': '$Gadget.offeringInfo',
									'onafter': function() {
										debugger;

										//1获取模板项，2判断isnullable的值   N或者Y，3提示IMS商品密码设置
										if($Gadget.offeringInfo && $Gadget.offeringInfo.ocOfferingTempTRSVO){
											$.each($Gadget.offeringInfo.ocOfferingTempTRSVO || [], function(i, valj) {
													if(valj.templateItemId && valj.templateItemId == 130){
														var templateItemInst = valj.templateItemInst;
														//创建文档对象
														//DTS2018040209580 修改IE不兼容问题  by fwx431274
														/*var parser=new DOMParser();
														var xmlDoc=parser.parseFromString(templateItemInst,"text/xml");*/
														var xmlDoc = adutil.loadXML(templateItemInst);

														//提取数据
														if (!window.DOMParser && window.ActiveXObject){
															$Gadget.PWDCHECK = xmlDoc.getElementsByTagName('PWDCHECK')[0].text;
															$Gadget.ATTRCODE = xmlDoc.getElementsByTagName('ATTRCODE')[0].text;
															$Gadget.PWDTYPE = xmlDoc.getElementsByTagName('PWDTYPE')[0].text;
															$Gadget.RESETMETHOD = xmlDoc.getElementsByTagName('RESETMETHOD')[0].text;
														}else if(window.DOMParser && document.implementation && document.implementation.createDocument){
															 $Gadget.PWDCHECK = xmlDoc.getElementsByTagName('PWDCHECK')[0].textContent;
																$Gadget.ATTRCODE = xmlDoc.getElementsByTagName('ATTRCODE')[0].textContent;
																$Gadget.PWDTYPE = xmlDoc.getElementsByTagName('PWDTYPE')[0].textContent;
																$Gadget.RESETMETHOD = xmlDoc.getElementsByTagName('RESETMETHOD')[0].textContent;
														}


														//var imsService = {key : "1310001445",value : $Gadget.PWDTYPE};//"IMS鉴权密码"  key offerid
														//tempList.push(imsService);

														return false;
													}
												});
										}
										page.init($Page, $Gadget, $Fire, $UI);

									}
								}, $Gadget);
							}else{
								page.init($Page, $Gadget, $Fire, $UI);
							}
						}
					}, $Gadget);



					}
				},$Gadget);
				
			},


			init : function($Page, $Gadget, $Fire, $UI)
			{
			
				 /**
	 			* 新增IVR二次确认需求
	 			*/
	 			debugger;
	 			//window._ysp_top.publicObject["is_secondConfirm"] = "1";
				//window._ysp_top.publicObject["secondMsisdn"] = "17823001283";
				//window._ysp_top.publicObject["secondMsisdn"] = null;
	 			isCspFlag = $Controller.bes.ad.csp.common.isCsp();
	 			servNumber = $Controller.bes.ad.csp.common.getServNumber();
				var isSecondConfirm = window._ysp_top.publicObject["is_secondConfirm"];  
				var secondMsisdn = window._ysp_top.publicObject["secondMsisdn"];

				if(isSecondConfirm && isCspFlag)
				{
					if(isCspFlag == true && (isSecondConfirm == 1 || isSecondConfirm == "1"))
					{
						debugger;
						if (!secondMsisdn) 
						{
							debugger;
							$UI.msgbox.error("提示","当前业务需要先做二次确认鉴权才允许办理", function(){
							//关闭当前页面
							debugger;
	                        Close_tabSet();
							},null,function(){Close_tabSet();});
						}else{
							if (secondMsisdn != servNumber) 
							{
								debugger;
								$UI.msgbox.error("提示","二次鉴权结果与业务号码不一致，请检查", function(){
								//关闭当前页面
								debugger;
	                        	Close_tabSet();
								},null,function(){debugger;Close_tabSet();});
							}
						}


					}
				}

				 
				//新增系统参数
				debugger;
				$Fire({
					service : "ucec/v1/common/qrysystemparambykey",
					params : {
						key: "OM_BUSINESS_RESETPWD_NOTIFY"
					},
					target : "$Page.restPwd",
					onafter: function() {
						debugger;

					}
				}, $Gadget);

				$Fire({
					service : "ucec/v1/common/qrysystemparamlistbykey",
					params : {
						keylist : ['60107061880414']
					},
					target : "$Page.systemParamsList",
					onafter : function() {
						debugger;
						//60107061880414  用于判断局点，如NINGXIA、JIANGSU、POLAND
						if($Page.systemParamsList){
							$Page.projectVersion = $Page.systemParamsList[0];
							debugger;
						}
					},

				}, $Gadget);

				var page = this;

				//$Controller.bes.oc.resetpwd.querySystemParams5Version($Page, $Fire);

				$Gadget.initFlag = true;

				$Page.isPreviewEvent = false;

				// 页面为嵌入CSP系统时，不需要登录
				isCspFlag = $Controller.bes.ad.csp.common.isCsp();

				//csp系统嵌入走免订单逻辑需要进行防重复点击处理
				$Page.cspPepeatSubmit = false;

				isIctFlag = $Controller.bes.ad.ict.common.isIct();
				if (isCspFlag) {
					$Page.page = page;
					// CSP系统，从cookie中获取用户号码，并设置用户信息
					servNumber = $Controller.bes.ad.csp.common.getServNumber();
					if (servNumber && servNumber.length == 11)
					{
						$Page.cspPassWord=true;

						$Controller.bes.ad.csp.common.login($Page, $Fire, $Gadget, $UI, servNumber,
								null, this.logingFail);
					}
					else
					{
						//错误，获取用户号码失败!
						$UI.msgbox.error($UEE.i18n("ad.person.message.error"), $UEE.i18n("ad.person.message.FailedObtainNumber"));
						return;
					}
				}
				else if (isIctFlag) {
					$Page.page = page;
					// ICT系统，从cookie中获取用户号码，并设置用户信息
					servNumber = $Controller.bes.ad.ict.common.getServNumber();
					if (servNumber && servNumber.length == 11)
					{
						$Controller.bes.ad.ict.common.login($Page, $Fire, $Gadget, $UI, servNumber,
								this.initpassword($Page, $Gadget, $Fire, $UI), this.logingFail);
					}
					else
					{
						//错误，获取用户号码失败!
						$UI.msgbox.error($UEE.i18n("ad.person.message.error"), $UEE.i18n("ad.person.message.FailedObtainNumber"));
						return;
					}
				}
				else
				{
					$Controller.bes.oc.resetpwd.initpassword($Page, $Gadget, $Fire, $UI);
				}

			

			},


			initpassword : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;
				var page = this;
				// 获取用户网络类型，初始化密码重置类型、密码重置方式等页面元素
				var request =
				{
						header :
						{
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body :
						{
							loginTokenTest : ""
						}
				};

				$Fire({
					service : 'agentdesktop/v1/person/queryrest_pwdtype',
					params : request,
					target : '$Gadget.data',
					onafter : function($Gadget, $UI)
					{
						debugger;
						if ($Gadget.data && $Gadget.data.bodys)
						{
							var authType = $Gadget.data.bodys.authType;
							$Page.netType=$Gadget.data.bodys.netType;

							// 判断是否是身份证登录
							if (!isCspFlag &&"AuthCheckE" != authType)
							{
								debugger;
								page.loginByIDCardTip($UI);
							}

							// 获取密码重置类型下拉列表数据

							var tempList = page.getDataForPwdResetType($Gadget.data.bodys.phnBdPwdDatadict,$Gadget,$Page);

							//初始化重置密码类型下拉列表
							page.initPwdResetType($Gadget, tempList);
						}
						if (!$Gadget.data)
						{
							page.systemErrTip($UI);
							return;
						}
						if ($Gadget.data && !$Gadget.data.bodys)
						{
							page.loginByIDCardTip($UI);
							return;
						}
					}
				}
				, $Gadget);
				this.menuCheck($Page, $Gadget, $Fire, $UI);

			},

			menuCheck:function($Page, $Gadget,$Fire,$UI)
			{
				var modifyKey = "BLCS_CurPasswordReset_WEB";
				var request = {
						header : {
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body : {
							menuId : modifyKey

						}
				};

				$Page=$(document).scope().$Page;
				$Fire({
					service : 'agentdesktop/v1/person/menu_check',
					params : request,
					target : '$Gadget.data',
					onafter : function($Gadget) {
						debugger;
						// console.log(12);
						if (null != $Gadget.data.body
								&& "0" != $Gadget.data.body.rspCode) {
							var fontList = [ "<font color='blue'>",
							                 "<font color='blue'>",
							                 "<font color='blue'>",
							                 "<font color='red'>" ];
							var messageCount = 0;
							var message = "";
							if ($Gadget.data.body.list) {
								for ( var i = 0; i < $Gadget.data.body.list.length; i++) {
									if ($Gadget.data.body.list[i].promptMessage
											&& !$Gadget.data.body.list[i].validateResult) {
										if (messageCount == 0) {
											message = fontList[$Gadget.data.body.list[i].level]
											+ $Gadget.data.body.list[i].promptMessage
											+ "</font>";
										} else {
											message = message
											+ "<br>"
											+ fontList[$Gadget.data.body.list[i].level]
											+ $Gadget.data.body.list[i].promptMessage
											+ "</font>";
										}
										messageCount++;
									}
								}
								if (message != null) {
									var closeResetPwd = function(){
										debugger;
										// 此时关闭当前页面
										Close_tabSet();
									};
									$UI.msgbox
									.info($UEE.i18n("ad.person.message.VerificationFailedNoInfo"), message,closeResetPwd);//"校验失败"
								}
							}
						}
					}
				}, $Gadget);
			},

			/**
			 * 当前用户是不是身份证号登录时的处理
			 */
			loginByIDCardTip : function($UI)
			{
				debugger;


				$UI.msgbox.confirm
				(
						$UEE.i18n("ad.person.message.information"),//"提示"
						$UEE.i18n("ad.person.message.ContinueBusiness"),//"此业务需身份证证件认证，点击“是”继续业务办理，点击“否”取消业务办理。"
						function()
						{
							//window.location.href = 'bes.agentdesktop.login.base.business.html?&tabId=resetPassword_ZJ&tabName=重置密码[镇江]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html&actionSource=iCRM#/index';
							//var data = "/oc/bes/ad/html/bes.ad.login.html?tabId=60131417&tabName=重置密码[镇江]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html";
							//adutil.openAuthTab(data);
							//return false;
							return true;
						},
						function()
						{
							//window.location.href = 'bes.agentdesktop.login.base.business.html?&tabId=resetPassword_ZJ&tabName=重置密码[镇江]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html&actionSource=iCRM#/index';
							var data = "/oc/bes/ad/html/bes.ad.login.html"+getVersionUrlStr(1)+"&tabId=60131417&tabName=$UEE.i18n('ad.person.title.ResetPassword')[$UEE.i18n('ad.person.message.Zhenjiang')]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html";
							adutil.openAuthTab(data);
							return false;
						},
						function()
						{
							//window.location.href = 'bes.agentdesktop.login.base.business.html?&tabId=resetPassword_ZJ&tabName=重置密码[镇江]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html&actionSource=iCRM#/index';
							//重置密码
							var data = "/oc/bes/ad/html/bes.ad.login.html"+getVersionUrlStr(1)+"&tabId=60131417&tabName=$UEE.i18n('ad.person.title.ResetPassword')[$UEE.i18n('ad.person.message.Zhenjiang')]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html";
							adutil.openAuthTab(data);
							return false;
						}
				);
				return;
			},

			/**
			 * 错误处理
			 */
			systemErrTip : function($UI)
			{
				debugger;
				$UI.msgbox.info
				(
						$UEE.i18n("ad.person.message.information"),
						$UEE.i18n("ad.person.message.SystemErrorLaterRetry"),//"系统错误，请稍后重试!",
						function()
						{
							var data = "/oc/bes/ad/html/bes.ad.login.html"+getVersionUrlStr(1)+"&tabId=60131417&tabName=$UEE.i18n('ad.person.title.ResetPassword')[$UEE.i18n('ad.person.message.Zhenjiang')]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html";
							adutil.openAuthTab(data);
							return false;
						},
						null,
						function()
						{
							var data = "/oc/bes/ad/html/bes.ad.login.html"+getVersionUrlStr(1)+"&tabId=60131417&tabName=$UEE.i18n('ad.person.title.ResetPassword')[$UEE.i18n('ad.person.message.Zhenjiang')]&besUrl=/oc/bes/ordercapture/html/bes-oc-resetPwd.html";
							adutil.openAuthTab(data);
							return false;

						}
				);
				return;
			},

			/**
			 * 封装密码重置类型，下拉列表数据
			 * @param phnBdPwdDatadict 密码重置类型下拉列表数据字典值
			 * @return tempList 组装后的下拉列表数据
			 */
			getDataForPwdResetType : function(phnBdPwdDatadict,$Gadget,$Page)
			{
				debugger;
					var tempList = [];

					//因任何用户皆可重置“用户服务密码”，故数据字典中未进行配置，需将重置用户服务密码选项拼到下拉列表数据中
					var userService = {key : "699211",value : $UEE.i18n("ad.person.title.ServicePassword")};//"用户服务密码"
					tempList.push(userService);
					//宁夏IMS密码获取
					if($Gadget.PWDTYPE){
						var imsService = {key : "1310001445",value : $Gadget.PWDTYPE};//"IMS鉴权密码"  key offerid
						tempList.push(imsService);
					}
					//将从数据字典中取得的数据封装到下拉列表项中
					if(phnBdPwdDatadict)
					{
						for(var i = 0; i < phnBdPwdDatadict.length; i++)
						{
							tempList.push(phnBdPwdDatadict[i]);
						}
					}
					return tempList;

			},

			/**
			 * 初始化密码重置类型下拉列表
			 * @param tempList 下拉列表数据
			 */
			initPwdResetType : function($Gadget, tempList)
			{
				debugger;
				var page = this;
				if(tempList.length > 0)
				{
					tempList[0].selected = true;
					pwdResetType = tempList[0].key;
					//添加标志 swx552312
					$Page.pwdResetType = pwdResetType;
				}
				var resetPwdType = new UCD.Droplist($("#pwdResetType"), tempList);
				resetPwdType.init();
				//初始化密码重置方式下拉列表
				var identifyTypeList = page.getIdentifyTypeList($Gadget, pwdResetType);
				page.initIdentifyType(identifyTypeList, $Gadget);

				resetPwdType.setOnValueChange
				(
						function()
						{
							debugger;
							pwdResetType = resetPwdType.$input.attr('key');
							//添加标志 swx552312
							$Page.pwdResetType = pwdResetType;
							identifyTypeList = page.getIdentifyTypeList($Gadget, pwdResetType);
							//初始化密码重置方式下拉列表
							page.initIdentifyType(identifyTypeList, $Gadget);
						}
				);
			},

			/**
			 * 获取密码重置方式下拉列表数据
			 * @param pwdResetType
			 * @return identifyTypeList 下拉列表数据
			 */
			getIdentifyTypeList : function($Gadget, pwdResetType)
			{
				debugger;
				var page = this;
				$Gadget.isNXIMS = false;

				//密码重置方式列表
				var identifyTypeList = null;

				// 重置服务密码
				if ("699211" == pwdResetType)
				{
					page.userServiceVisible();
					identifyTypeList = page.uerService($Gadget);
				}

				//重置手机宽带密码
				if("303800" == pwdResetType || "20001" == pwdResetType || "2413000001" == pwdResetType||"2413000001&8101000001&8101000002&8101000003&8101000004&8101000005&8101000006" == pwdResetType)
				{
					page.phoneBroadBandVisible();
					identifyTypeList = page.phoneBroadBand();
				}

				//重置互联网电视密码
				if("internettv-of&2413000019&2413000020&2413000021" == pwdResetType
						|| "2413000004&2413000008&2413000021&2413000010&2413000011&2413000012&2413000019&2413000020&2413000009&2413000025&2413000026" == pwdResetType)
				{
					page.internetTVVisible();
					identifyTypeList = page.internetTV();
				}

				//重置IMS固话密码
				if("imsbroadband-of" == pwdResetType || '2413000005' == pwdResetType)
				{
					page.IMSPhoneVisible();
					identifyTypeList = page.IMSPhone();
				}

				//重置宁夏IMS商品密码
				if('1310001445' == pwdResetType)
				{
					page.nxIMSVisible();
					identifyTypeList = page.NXIMSPhone($Gadget);
				}

				//重置小区宽带密码 swx552312
				if('1300000002' == pwdResetType)
				{
					page.LANVisible();
					identifyTypeList = page.LAN();
				}
				return identifyTypeList;
			},

			/**
			 * 初始化密码重置方式下拉列表
			 * @param identifyTypeList 下拉列表数据
			 */
			initIdentifyType : function(identifyTypeList, $Gadget)
			{
				debugger;
				if (identifyTypeList.length > 0)
				{
					identifyTypeList[0].selected = true;
					if(!resetType || $Gadget.initFlag == true)
					{
						resetType = new UCD.Droplist($("#identifyType"), identifyTypeList);
						$Gadget.initFlag = false;
					}
					resetType.setData(identifyTypeList);
					resetType.init();
					itemVal = resetType.$input.attr('key');
					if ("C" == itemVal) {
						$("#newPwdDiv").show();
						$("#confirmPwdDiv").show();
					} else {
						$("#newPwdDiv").hide();
						$("#confirmPwdDiv").hide();
					}

					resetType.setOnValueChange(function()
							{
						debugger;
						itemVal = resetType.$input.attr('key');
						if ("C" == itemVal) {
							$("#newPwdDiv").show();
							$("#confirmPwdDiv").show();
						} else {
							$("#newPwdDiv").hide();
							$("#confirmPwdDiv").hide();
						}
							});
				}
			},

			/**
			 * 用户服务密码重置，支持客户输入、系统随机、初始密码
			 */
			uerService : function($Gadget)
			{
				debugger;
				var page = this;
				var identifyTypeList = [];
				$Page=$(document).scope().$Page;

				for(var i = 0; i < $Gadget.netTypeDictList.length; i++)
				{
					var netTypeDict = $Gadget.netTypeDictList[i].itemName;
					var netTypeDictList = netTypeDict.split(";");
					var netType = netTypeDictList[0];
					var len = netTypeDictList.length;
					if(netType == $Page.netType)
					{
						for(var j = 1; j < len; j++)
						{
							var key = netTypeDictList[j];
							var value = page.getResetMethod($Gadget, key);
							var identifyType = {};
							identifyType.key = key;
							identifyType.value = value;
							identifyTypeList.push(identifyType);
						}
						break;
					}
				}
				//过滤重置密码类型下拉框，若用户订购了2413000025,2413000026这两个商品。重置密码类型只能为系统随机密码
				$Controller.bes.oc.resetpwd.filtRestPassWordType($Gadget,identifyTypeList);
				return identifyTypeList;
			},

			filtRestPassWordType : function($Gadget,identifyTypeList){
				debugger;
				$Gadget.$Get("$Fire")({
					service : "personalunifiedviewservice/qryofferinstinfo",
					params : {
						"servicenumber" : $Gadget.$Page.serviceNum
					},
					target : "$Gadget.userOfferInstForFilt",
					onafter : function() {
						debugger;
						var ifNeedFilt = false;
						if($Gadget.userOfferInstForFilt && $Gadget.userOfferInstForFilt.length>0){
							$.each($Gadget.userOfferInstForFilt||[],function(k,offeringInst){
								if(("2413000025" == offeringInst.offeringId) || ("2413000026" == offeringInst.offeringId)){
									ifNeedFilt = true;
								}
							});
							debugger;
							if(ifNeedFilt && identifyTypeList && identifyTypeList.length>0){
								var tempIdentifyTypeList = [];
								$.each(identifyTypeList||[],function(j,valj){
									if(valj.key == "R"){
										debugger;
										tempIdentifyTypeList.push(valj);
									}
								});
								identifyTypeList = tempIdentifyTypeList;
							}
						}
					}
				}, $Gadget);
			},
			/**
			 * 根据密码重置方式key获取value
			 * @param $Gadget
			 * @param key
			 * @returns
			 */
			getResetMethod : function($Gadget, key)
			{
				debugger;
				var len = $Gadget.resetMethods.length;
				for (var i = 0; i < len; i++)
				{
					if(key == $Gadget.resetMethods[i].key)
					{
						return $Gadget.resetMethods[i].value;
					}
				}
			},
			/**
			 * 重置手机宽带密码，支持客户输入、系统随机、初始密码
			 */
			phoneBroadBand : function()
			{
				debugger;
				var identifyTypeList =
					[
					 {
						 key : "C",value : $UEE.i18n("ad.person.option.EnteredByCustomer")//"客户输入密码"
					 },
					 {
						 key : "R",value : $UEE.i18n("ad.person.option.ResetToRandom")//"系统随机密码"
					 },
					 {
						 key : "I",value : $UEE.i18n("ad.person.option.ResetToInitial")//"重置为初始密码"
					 }
					 ];
				return identifyTypeList;
			},

			/**
			 * 互联网电视密码重置，支持系统随机、初始密码
			 */
			internetTV : function()
			{
				debugger;
				var identifyTypeList =
					[
					 {
						 key : "R",value : $UEE.i18n("ad.person.option.ResetToRandom")//"系统随机密码"
					 }

					 //关于互联网电视密码设置和校验规则优化需求,将互联网电视密码的“重置为初始密码”下线 swx552312
					 /*,
					 {
						 key : "I",value : $UEE.i18n("ad.person.option.ResetToInitial")//"重置为初始密码"
					 }*/
					 ];
				return identifyTypeList;
			},

			/**
			 * IMS固话密码重置，支持重置为初始密码
			 */
			IMSPhone : function()
			{
				debugger;
				$Page=$(document).scope().$Page;
				if ($Page.restPwd == "1"  && $Page.projectVersion == "JIANGSU"){
					var identifyTypeList =
						[
						 {
							 key : "R",value : $UEE.i18n("ad.person.option.ResetToRandom")//"系统随机密码"
						 }
						 ];
				}else{
					var identifyTypeList =
						[
						 {
							 key : "I",value : $UEE.i18n("ad.person.option.ResetToInitial")//"重置为初始密码"
						 }
						 ];
				}

				return identifyTypeList;
			},

			/**
			 * 宁夏IMS商品密码重置
			 */
			NXIMSPhone : function($Gadget)
			{
				debugger;
				$Gadget.isNXIMS = true;
				$Page=$(document).scope().$Page;
				if ($Page.projectVersion == "NINGXIA"){
					//提取数据
					var identifyTypeList =
						[
						 {
							 key : "C",value : $Gadget.RESETMETHOD//"客户输入密码"
						 }
						 ];
				}
				return identifyTypeList;
			},

			/**
			 * 小区宽带密码重置，支持客户输入 swx552312
			 */
			LAN : function()
			{
				debugger;
				var identifyTypeList =
					[
					 {
						 key : "C",value : $UEE.i18n("ad.person.option.EnteredByCustomer")//"客户输入密码"
					 }
					 ];
				return identifyTypeList;
			},
			/**
			 * 重置用户服务密码，页面元素显隐控制
			 */
			userServiceVisible : function()
			{
				debugger;
				//清空密码输入框内容
				$("#newPwd").val("");
				$("#confirmPwd").val("");

				//设置页面元素显隐
				$("#newPwdDiv").show();
				$("#confirmPwdDiv").show();
				$("#commitUserServiceDiv").show();
				$("#commitValueAddedDiv").hide();
			},

			/**
			 * 重置小区宽带密码，页面元素显隐控制 swx552312
			 */
			LANVisible : function()
			{
				debugger;
				//清空密码输入框内容
				$("#newPwd").val("");
				$("#confirmPwd").val("");

				//设置页面元素显隐
				$("#newPwdDiv").show();
				$("#confirmPwdDiv").show();
				$("#commitUserServiceDiv").hide();
				$("#commitValueAddedDiv").show();
			},
			/**
			 * 重置宁夏IMS商品密码，页面元素显隐控制
			 */
			nxIMSVisible : function()
			{
				debugger;
				//清空密码输入框内容
				$("#newPwd").val("");
				$("#confirmPwd").val("");

				//设置页面元素显隐
				$("#newPwdDiv").show();
				$("#confirmPwdDiv").show();
				$("#commitUserServiceDiv").show();
				$("#commitValueAddedDiv").hide();
			},

			/**
			 * 重置手机宽带密码，页面元素显隐控制
			 */
			phoneBroadBandVisible : function()
			{
				debugger;
				//清空密码输入框内容
				$("#newPwd").val("");
				$("#confirmPwd").val("");

				//设置页面元素显隐
				$("#newPwdDiv").show();
				$("#confirmPwdDiv").show();
				$("#commitUserServiceDiv").hide();
				$("#commitValueAddedDiv").show();
			},

			/**
			 * 重置互联网电视密码，页面元素显隐控制
			 */
			internetTVVisible : function()
			{
				debugger;
				$("#newPwdDiv").hide();
				$("#confirmPwdDiv").hide();
				$("#commitUserServiceDiv").hide();
				$("#commitValueAddedDiv").show();
			},

			/**
			 * 重置IMS固话密码，页面元素显隐控制
			 */
			IMSPhoneVisible : function()
			{
				debugger;
				$("#newPwdDiv").hide();
				$("#confirmPwdDiv").hide();
				$("#commitUserServiceDiv").hide();
				$("#commitValueAddedDiv").show();
			},

			/**
			 * 密码输入框不是readonly属性时焦点离开时的处理
			 * @param $Gadget
			 * @param $Fire
			 * @param $UI
			 */
			unReadonlyValidate : function($Page, $Gadget, $Fire, $UI) {
				debugger;
				var pageScope = this;
				var newPwd = $("#newPwd");
				if (newPwd.attr('readonly') != "readonly") {
					pageScope.newPwdOnblur($Page, $Gadget, $Fire, $UI);
				}
			},

			/**
			 * 新密码失去焦点
			 * @param $Gadget
			 * @param $Fire
			 * @param $UI
			 */
			newPwdOnblur : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;
				//添加宁夏ims商品密码校验
			if($Gadget.isNXIMS){
				var pageScope = this;
				if ("" == $("#newPwd").val())
				{
					newFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NewPasswordNotEmpty"));//"新密码不能为空。"
					$("#newPwd").val("");
					return;
				}
				else if(!pageScope.imspasswordcheck($("#newPwd").val())){
					newFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"),"密码不符合校验规则");
					$("#newPwd").val("");
					return;
				}
				newFlag = true;
			}else{


				if ("" == $("#newPwd").val())
				{
					newFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NewPasswordNotEmpty"));//"新密码不能为空。"
					$("#newPwd").val("");
					return;
				}
				else if($("#newPwd").val().length != 6){
					newFlag = false;
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.pssixlength"));
					$("#newPwd").val("");
					return;
				}
				else
				{
					// 调用新密码检验接口
					debugger;
					var newPwdVal = encryptWithRSA($("#newPwd").val());
					var request = {
							header : {
								loginToken : "",
								loginId : "",
								locale : "",
								serialId : ""
							},
							body : {
								busiCode : "V",
								eventId : "",
								seniorId : "",
								pwdReqBody : {
									businessCode : "V",
									itemType : "",
									itemId : "",
									orderItemActionType : "",
									itemInstanceId : "",
									actionType : "",
									newPassword : newPwdVal,
									oldPassword : "",
									passwordType : "C"
								}
							}
					};

					$Page=$(document).scope().$Page;
					$Fire(
							{
								service : 'agentdesktop/v1/person/newpwd_validate',
								params : request,
								target : '$Gadget.data1',
								onafter : function($Gadget)
								{
									debugger;
									if ($Gadget.data1 && $Gadget.data1.body)
									{
										if ("0" != $Gadget.data1.body.rspCode)
										{
											newFlag = false;
											var fontList = [
											                "<font color='blue'>",
											                "<font color='blue'>",
											                "<font color='blue'>",
											                "<font color='red'>" ];
											var messageCount = 0;
											var message = "";
											if ($Gadget.data1.body.list)
											{
												for ( var i = 0; i < $Gadget.data1.body.list.length; i++)
												{
													if ($Gadget.data1.body.list[i].promptMessage
															&& !$Gadget.data1.body.list[i].validateResult)
													{
														if (messageCount == 0)
														{
															message = fontList[$Gadget.data1.body.list[i].level]
															+ $Gadget.data1.body.list[i].promptMessage
															+ "</font>";
														}
														else
														{
															message = message
															+ "<br>"
															+ fontList[$Gadget.data1.body.list[i].level]
															+ $Gadget.data1.body.list[i].promptMessage
															+ "</font>";
														}
														messageCount++;
													}
												}
											}
											$("#newPwd").val("").focus();
											$("#confirmPwd").val("");
											$UI.msgbox.info($UEE.i18n("ad.person.message.VerificationFailedNoInfo"), message);//校验失败
											return;
										}
										else
										{
											if ($("#newPwd").val() != $("#confirmPwd").val() && ("" != $("#confirmPwd").val() && $("#confirmPwd").val().length == 6) )
											{
												$("#newPwd").val("").focus();
												$("#confirmPwd").val("");
												$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.twopsdiffer"));
												return;
											}
											else
											{
												newFlag = true;
											}
										}
									}
									else
									{
										$("#newPwd").val("").focus();
										$("#confirmPwd").val("");
										newFlag = false;
										$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.psvalfailed"));
										return;
									}
								}
							}, $Gadget);
				}

				}
			},

			/**
			 * 确认密码失去焦点
			 * @param $Gadget
			 * @param $Fire
			 * @param $UI
			 */
			confirmPwdOnblur : function($Gadget, $Fire, $UI)
			{
				debugger;
				if ("" == $("#confirmPwd").val())
				{
					// 弹窗提示输入密码
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.psnoempty"));
				}
				else
				{
					if ($("#newPwd").val() != $("#confirmPwd").val()
							&& "" != $("#newPwd").val())
					{
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.twopsdiffer"));
						$("#confirmPwd").val("");
					}
				}
			},

			submitPhnBdPwd : function($Page, $Gadget, $Fire, $UI)
			{
				if ($Controller.bes.ad.csp.common.isCsp())
				{
					if (!$Page.isPreviewEvent)
					{
						dontTouchDataOfWholePage();
					}
					//先判断操作员是否具有110911令牌 有就不需要进行ivr验证
					$Fire({
						service : "/ucec/v1/offering/check_accountinfo_byname",
						params : {
							"header" : null,
							"body" : {
								"chargeInfoName" : "60131001527"
							}
						},
						target : "$Gadget.querypermission",
						onafter : function() {
							debugger;
							if($Gadget.querypermission && $Gadget.querypermission.body && $Gadget.querypermission.body.checkFlag ){
								$Controller.bes.oc.resetpwd.realsubmitPhnBdPwd($Page, $Gadget, $Fire, $UI);
							}else{

								var callerNo = $Controller.bes.ad.csp.common.getCurrentCallInNum();
								var  servNumber = $Controller.bes.ad.csp.common.getServNumber();
								if( callerNo == servNumber){
									$Controller.bes.oc.resetpwd.realsubmitPhnBdPwd($Page, $Gadget, $Fire, $UI);
								}
								else if($Controller.bes.ad.csp.common.ivrCheck($Controller.bes.ad.csp.common.getServNumber(), $Gadget.$Get('$UI')))
								{
									$Controller.bes.oc.resetpwd.realsubmitPhnBdPwd($Page, $Gadget, $Fire, $UI);
								}else{
									youCanTouchDataOfWholePage();
									return false;
								}
							}
						}
					}, $Gadget);
				}else
				{
					$Controller.bes.oc.resetpwd.realsubmitPhnBdPwd($Page, $Gadget, $Fire, $UI);
				}
			},

			/**
			 * 提交手机宽带密码
			 * @param $Gadget
			 * @param $Fire
			 * @param $UI
			 */
			realsubmitPhnBdPwd : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;

				var page = this;
				var newPhnBdPwd = $("#newPwd").val();
				var confirmPhnBdPwd = $("#confirmPwd").val();

				if(!page.validateBeforeCommit(newPhnBdPwd, confirmPhnBdPwd, $UI))
				{
					youCanTouchDataOfWholePage();
					return;
				}
				else
				{
					var request =
					{
							header :
							{
								loginToken : "",
								loginId : "",
								locale : "",
								serialId : ""
							},
							body :
							{
								newPassword : newPhnBdPwd && encryptWithRSA(newPhnBdPwd),
								businessCode : "R",
								phoneBdPwdType : pwdResetType,
								passwordType : itemVal,
								//authenticateType : $Gadget.data.bodys.authType
							}
					};

					if ($Page.isPreviewEvent)
					{
						page.assemblePreviewEventReq($Page, request, $Fire, $Gadget, $UI);
					}
					else
					{
						//调用修改密码接口
						page.callModifyPwdService($Page, request, $Fire, $Gadget, $UI);
					}
				}
			},


			/**
			 * 免填单预览
			 */
			previewEventPhn : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;

				$Page.isPreviewEvent = true;
				this.submitPhnBdPwd($Page, $Gadget, $Fire, $UI);
			},

			/**
			 * 免填单预览
			 */
			previewEventUser : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;

				$Page.isPreviewEvent = true;
				this.submitOnclick($Page, $Gadget, $Fire, $UI);
			},

			/**
			 * 提交修改前对密码做简单校验
			 * @param newPhnBdPwd 新密码
			 * @param confirmPhnBdPwd 确认密码
			 * @param $UI
			 * @returns {Boolean} 校验结果
			 */
			validateBeforeCommit : function(newPhnBdPwd, confirmPhnBdPwd, $UI)
			{
				if ("" != newPhnBdPwd && -1 != newPhnBdPwd.indexOf(" "))
				{
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.psnospace"));
					return false;
				}
				else if (newPhnBdPwd != confirmPhnBdPwd)
				{
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.twopsdiffer"));
					return false;
				}
				return true;
			},
			// 当密码输入时，记录一个变量，用来标记密码被输入过
	        passwordKeyPress: function($Page) {
	        	debugger;
	        	$Page.isPwdPress = true;
	        },
			submitOnclick : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;
				// DTS2017051506637  如果是操作员有没有权限输入密码，如果没有又输入了，则不让提交
				if ($Page.isHaveInputAuth == false) {
					// 当前操作员没有输入密码的权限
					if ($Page.isPwdPress == true) {
						// 当前操作操作员输入了密码
						$UI.msgbox.info($UEE.i18n("ad.checkout.label.information")/*提示*/, '当前操作员不可输入用户密码！');
						return ;
					}
				}
				if ($Controller.bes.ad.csp.common.isCsp())
				{
					if (!$Page.isPreviewEvent)
					{
						dontTouchDataOfWholePage();
					}
					//先判断操作员是否具有110911令牌 有就不需要进行ivr验证
					$Fire({
						service : "/ucec/v1/offering/check_accountinfo_byname",
						params : {
							"header" : null,
							"body" : {
								"chargeInfoName" : "60131001527"
							}
						},
						target : "$Gadget.querypermission",
						onafter : function() {
							debugger;
							if($Gadget.querypermission && $Gadget.querypermission.body && $Gadget.querypermission.body.checkFlag ){
								$Controller.bes.oc.resetpwd.realsubmitOnclick($Page, $Gadget, $Fire, $UI);
							}else{
								//DTS2016041310066 用户密码重置需要进行ivr认证
								if($Controller.bes.ad.csp.common.ivrCheck($Controller.bes.ad.csp.common.getServNumber(), $Gadget.$Get('$UI')))
								{
									$Controller.bes.oc.resetpwd.realsubmitOnclick($Page, $Gadget, $Fire, $UI);
								}else{
									youCanTouchDataOfWholePage();
									return false;
								}
							}
						}
					}, $Gadget);
				}else
				{
					$Controller.bes.oc.resetpwd.realsubmitOnclick($Page, $Gadget, $Fire, $UI);
				}
			},

			/**
			 * 用户服务密码重置提交
			 * @param $Gadget
			 * @param $Fire
			 * @param $UI
			 */
			realsubmitOnclick : function($Page, $Gadget, $Fire, $UI)
			{
				debugger;
				var page = this;

				//增加业务类型
				$Page.businessCode = 'ChangeSubPassword';

				//用户输入密码
				if (itemVal == "C")
				{
					var confirmVal = $("#confirmPwd").val();
					var newPwdVal = $("#newPwd").val();
					if ("" == newPwdVal
							|| "" == confirmVal
							|| newPwdVal != confirmVal
							|| !newFlag)
					{
						$("#newPwd").val("");
						$("#confirmPwd").val("");
						youCanTouchDataOfWholePage();
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.psrules"));
						return;
					}
					else
					{
						var request =
						{
								header :
								{
									loginToken : "",
									loginId : "",
									locale : "",
									serialId : ""
								},
								body :
								{
									busiCode : "R",
									eventId : "",
									seniorId : "",
									pwdReqBody :
									{
										businessCode : "R",
										itemType : "",
										itemId : "",
										orderItemActionType : "",
										itemInstanceId : "",
										actionType : "",
										newPassword : newPwdVal && encryptWithRSA(newPwdVal),
										oldPassword : "",
										passwordType : "C"
									}
								}
						};

						$Page=$(document).scope().$Page;
						$Fire(
								{
									service : 'agentdesktop/v1/person/newpwd_validate',
									params : request,
									target : '$Gadget.data2',
									onafter : function($Gadget)
									{
										debugger;
										if ($Gadget.data2 && $Gadget.data2.body && "0" == $Gadget.data2.body.rspCode)
										{
											newFlag = true;
										}
										else if (!$Gadget.data2)
										{
											$("#newPwd").val("").focus();
											$("#confirmPwd").val("");
											newFlag = false;
											youCanTouchDataOfWholePage();
											$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SystemErrorLaterRetry"));//"系统错误，请稍后重试。"
											return;
										}
										else
										{
											$("#newPwd").val("").focus();
											$("#confirmPwd").val("");
											newFlag = false;
											youCanTouchDataOfWholePage();
											if($Gadget.data2.body && $Gadget.data2.body.rspCode){
												$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $Gadget.data2.body.rspMsge);
											}
											else{
												/*新密码校验失败。*/
												$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.newpwdvalidatefail"));
											}

											return;
										}

										if (newFlag)
										{
											//订单报文
											var request = page.paramsForModifyPwd(newPwdVal, itemVal);

											if ($Page.isPreviewEvent)
											{
												page.assemblePreviewEventReq($Page, request, $Fire, $Gadget, $UI);
											}
											else
											{
												//调用修改密码接口
												page.callModifyPwdService($Page, request, $Fire, $Gadget, $UI);
											}
										}
										else
										{
											$("#newPwd").val("").focus();
											$("#confirmPwd").val("");
											newFlag = false;
											youCanTouchDataOfWholePage();
											$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.psrules"));
										}
									}
								}, $Gadget);
					}

				}
				//重置为随机密码、初始密码
				else if (itemVal == "R" || itemVal == "I")
				{
					// 订单报文
					var request = page.paramsForModifyPwd("", itemVal);

					if ($Page.isPreviewEvent)
					{
						page.assemblePreviewEventReq($Page, request, $Fire, $Gadget, $UI);
					}
					else
					{
						//调用修改密码接口
						page.callModifyPwdService($Page, request, $Fire, $Gadget, $UI);
					}
				}
				else
				{
					youCanTouchDataOfWholePage();
					return;
				}
			},

			/**
			 * 封装重置密码接口需要的参数
			 * @param newPassword 新密码
			 * @param passwordType 密码重置方式
			 */
			paramsForModifyPwd : function(newPassword, passwordType)
			{
				debugger;
				var request =
				{
						header :
						{
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body :
						{
							businessCode : "R",
							itemType : "P",
							itemId : "",
							orderItemActionType : "M",
							itemInstanceId : "",
							actionType : "R",
							newPassword : newPassword && encryptWithRSA(newPassword),
							passwordType : passwordType
						}
				};

				return request;
			},

			/**
			 * 重置密码走结算流程
			 * @param reqParams 接口参数
			 * @param $Gadget
			 * @param $UI
			 */
			busiValidate : function($Page, reqParams, $Fire, $Gadget, $UI)
			{
				debugger;
				var page = this;
				var extInfo = {
						busiCode : "M",
						eventId : "",
						seniorId : "",
						pwdReqBody : reqParams.body
				};
				//如果是宁夏ims商品修改密码
				if($Page.projectVersion=="NINGXIA" && $Gadget.isNXIMS){
					//1.密码 2.方式
					extInfo.pwdReqBody.newPassword = $("#newPwd").val();
					extInfo.pwdReqBody.passwordType = "IMSAuthentication"+($("#newPwd").val());
				}
				var extInfoJson = JSON.stringify(extInfo);

				$Page.checkoutValidateBody = {
						businessType: "ChangeSubPassword",
						createOrderReq:{
							order:{
								orderPayment:[]
							}
						},
						extInfoJson : extInfoJson
				};
				$Fire(
						{
							service : 'bes.agentdesktop.checkoutboservice/busivalidate',
							params:{
								header:{},
								"checkoutbody": $Page.checkoutValidateBody
							},
							target : '$Page.checkoutValidateResult',
							onafter : function() {
								debugger;
								youCanTouchDataOfWholePage();

								if (adutil.checkUcecResp($Page.checkoutValidateResult.header, $UI)) {
									var returnMessage = $Page.checkoutValidateResult.body.checkOutResp.returnMessage;

									// 成功
									if (returnMessage.retCode == "0") {
										var busiValidCheck = adutil.checkBusiValidResp(null,$UI,$Page.checkoutValidateResult.body.checkOutResp, function(){
											page.submitOrder($Gadget, $Fire, $Page, $UI);
										});
										// 成功
										if (busiValidCheck) {
											page.submitOrder($Gadget, $Fire, $Page, $UI);
										}
									} else {
										$UI.msgbox.error($UEE.i18n("ad.marketplan.message.tips"), returnMessage.retMessage);
									}
								}

							}
						}, $Gadget);
			},

			submitOrder : function($Gadget, $Fire, $Page, $UI) {
				debugger;
				$Page.checkoutInfo = $Page.checkoutInfo || {};
				$Page.checkoutInfo.serviceNumber = $Page.serviceNum;

				$Page.backStep = "index";
				$Gadget.$Get('$Fire')({targetstep:'checkout'});

				// 跳到结算页面引入样式
				$("<link>").attr({
					rel: "stylesheet",
					type: "text/css",
					href: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/base.css"
				}).appendTo("head");
			},

			/**
			 * 调用重置密码接口
			 * @param reqParams 接口参数
			 * @param $Gadget
			 * @param $UI
			 */
			callModifyPwdService : function($Page, reqParams, $Fire, $Gadget, $UI)
			{
				debugger;
				if (!isCspFlag)
				{
					this.busiValidate($Page, reqParams, $Fire, $Gadget, $UI);
					return ;
				}
				if ($Page.cspPepeatSubmit)
				{
					youCanTouchDataOfWholePage();
					return;
				}
				$Page.cspPepeatSubmit = true;
				$Page=$(document).scope().$Page;
				$Fire(
						{
							service : "agentdesktop/v1/person/modify_pwd",
							params : reqParams,
							target : '$Gadget.targetData',
							onafter : function($Gadget)
							{
								debugger;
								if ($Gadget.targetData && $Gadget.targetData.body)
								{
									if (isCspFlag)
									{
										youCanTouchDataOfWholePage();
										$Page.cspPepeatSubmit = false;
										// 重新构造createorder，用于业务受理结束页面
										$Page.order_resp = {};
										if ($Gadget.targetData && $Gadget.targetData.header)
										{
											$Page.order_resp.header = $Gadget.targetData.header;
										}
										else
										{
											$Page.order_resp.header = null;
										}
										$Page.order_resp.body = {};
										if ($Gadget.targetData
												&& $Gadget.targetData.body)
										{
											$Page.order_resp.body.retCode = $Gadget.targetData.body.retCode;
											$Page.order_resp.body.retMessage = $Gadget.targetData.body.retMessage;
											$Page.order_resp.body.refOrderId = $Gadget.targetData.body.orderId;
										}
										else
										{
											$Page.order_resp.body.retCode = null;
											$Page.order_resp.body.retMessage = null;
											$Page.order_resp.body.refOrderId = null;
										}
										$Page.notNeedGoOn = true;

										$Fire({targetstep:'service'});
										$("<link>").attr({
											rel : "stylesheet",
											type : "text/css",
											href : window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ordercapture/css/checkoutFinish.css"
										}).appendTo("head");
									}
									else
									{
										if ($Gadget.targetData.header.resultCode && 0 != $Gadget.targetData.header.resultCode)
										{
											$Gadget.modifyPwdFailMsg = {};
											$Gadget.modifyPwdFailMsg.name = "failReason";
											$Gadget.modifyPwdFailMsg.number = $Gadget.targetData.header.resultMessage;
											$Gadget.$Emit("$Page.showbookingsubmit", $Gadget.modifyPwdFailMsg);
											$("#resetPwdPage").hide();
											$("#modifyPwdresult").show();
											return;
										}
										if ($Gadget.targetData.body.retCode && 0 != $Gadget.targetData.body.retCode)
										{
											$Gadget.modifyPwdFailMsg = {};
											$Gadget.modifyPwdFailMsg.name = "failReason";
											$Gadget.modifyPwdFailMsg.number = $Gadget.targetData.body.retMessage;
											$Gadget.$Emit("$Page.showbookingsubmit", $Gadget.modifyPwdFailMsg);
											$("#resetPwdPage").hide();
											$("#modifyPwdresult").show();
										}
										else
										{
											$Gadget.modifyPwdSuccessMsg = {};
											$Gadget.modifyPwdSuccessMsg.name = "modifyPwd";
											$Gadget.modifyPwdSuccessMsg.noOrderFlag = $Gadget.targetData.body.noOrderFlag;
											$Gadget.modifyPwdSuccessMsg.number = $Gadget.targetData.body.orderId;
											$Gadget.$Emit("$Page.showbookingsubmit", $Gadget.modifyPwdSuccessMsg);
											$("#resetPwdPage").hide();
											$("#modifyPwdresult").show();
										}
									}
								}
								else
								{
									$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SystemErrorLaterRetry"));//"系统错误，请稍后重试。"
									return;
								}
							},
							onerror: function()
							{
								youCanTouchDataOfWholePage();
								$Page.cspPepeatSubmit = false;
							}
						}, $Gadget);
			},

			/**
			 * 免填单预览，获取创建订单报文
			 */
			assemblePreviewEventReq : function($Page, reqParams, $Fire, $Gadget, $UI)
			{
				debugger;

				$Page.isPreviewEvent = false;
				$Fire(
						{
							service : 'agentdesktop/v1/person/mdypwd_previewreceiptdata',
							params : reqParams,
							target : '$Gadget.previewReceiptData',
							onafter : function($Gadget, $Emit)
							{
								debugger;

								if ($Gadget.previewReceiptData && $Gadget.previewReceiptData.body) {
									$Page.previewOrderReq = $.extend(true, {}, $Gadget.previewReceiptData.body.orderRequest);
									$Emit("$OC.eReceiptPreviewEventAll", {});
								} else {
									$UI.msgbox.error($UEE.i18n("ad.person.message.information"), "获取免填单报文失败。");
									return false;
								}
							}
						}, $Gadget);
			},

			// CSP系统，设置用户登录信息
			loginSuccess : function($Page,$Fire,$Gadget,$UI)
			{
				debugger;
				var page = $Page.page;

				// 获取用户网络类型，初始化密码重置类型、密码重置方式等页面元素
				var request =
				{
						header :
						{
							loginToken : "",
							loginId : "",
							locale : "",
							serialId : ""
						},
						body :
						{
							loginTokenTest : ""
						}
				};
				$Fire({
					service : 'agentdesktop/v1/person/queryrest_pwdtype',
					params : request,
					target : '$Gadget.data',
					onafter : function($Gadget, $UI)
					{
						debugger;
						if ($Gadget.data && $Gadget.data.bodys)
						{
							var authType = $Gadget.data.bodys.authType;
							// 判断是否是身份证登录
							if (!isCspFlag &&"AuthCheckE" != authType)
							{
								debugger;
								page.loginByIDCardTip($UI);
							}

							// 获取密码重置类型下拉列表数据
							var tempList = page.getDataForPwdResetType($Gadget.data.bodys.phnBdPwdDatadict,$Gadget,$Page);

							//初始化重置密码类型下拉列表
							page.initPwdResetType($Gadget, tempList);
						}
						if (!$Gadget.data)
						{
							page.systemErrTip($UI);
							return;
						}
						if ($Gadget.data && !$Gadget.data.bodys)
						{
							page.loginByIDCardTip($UI);
							return;
						}
					}
				}, $Gadget);
				$Controller.bes.oc.resetpwd.menuCheck($Page,$Gadget, $Fire, $UI);
				return true;
			},

			logingFail : function($Page,$Fire,$Gadget,$UI)
			{
				return false;
			},

			imspasswordcheck : function(value)
			{
				debugger;
				var check = RegExp('^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*([.!~/@#$%^&*,:;""-]|[\/\|\{\}‘’“” <>()\?\'_=+])).{8,14}$');
				if(check.test($.trim(value)))
				{
					return true;
				}
				return false;
			}
		});
