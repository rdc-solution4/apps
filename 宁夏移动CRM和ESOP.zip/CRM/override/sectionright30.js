function initIframeSrc($Model) {
	var timestamp = new Date().getTime();
	var ocloginsrc = $Model.sectionrightParam.sectionrightLoginUrl + "?t=" + timestamp;
	//var ocrechargesrc = $Model.sectionrightParam.rechargeUrl + "&t="
			+ timestamp;
	$('#oclogin').attr('src', ocloginsrc);
	//$('#ocrecharge').attr('src', ocrechargesrc);
};

/**
 * 初始化参数
 * added by taoyue 00380120
 */
function initPortalConfigurationItem($Scope) {
	var $Fire = $Scope.$Get('$Fire');
	
	var $Model = $Scope.$Model;
	$Fire({
		'service' : '/oc/login/controlparam/sectionright',
		'target' : '$Model.sectionrightParam'
	}, $Scope).onafter(function() {
		debugger;
		initIframeSrc($Model);
	});
};
