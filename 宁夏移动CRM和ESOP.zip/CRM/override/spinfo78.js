$Controller("bes.oc.spinfo.cancelorder", function($Gadget, $scope) {
	debugger;
	if($Page.tabIndexFlag==0||$Page.tabIndexFlag==1||$Page.tabIndexFlag==2){
		$("#offeringNameDetail" + $Page.tabIndexFlag).hide();
		$("#offeringNameDetailPop" + $Page.tabIndexFlag).hide();
	}
	else{
		$("#offeringNameDetail").hide();
		$("#offeringNameDetailPop").hide();
	}
});

$Controller(
		"bes.oc.spinfo.order",
		function($Gadget, $scope) {
			debugger;
			// 将商品加入购物车
			$Gadget.chooseCommodity = {};
			$Gadget.chooseCommodity.selectItem = {};
			if ($Gadget.data && $Gadget.data.spproductdetail) {
				$Gadget.chooseCommodity.selectItem.offeringId = $Gadget.data.spproductdetail.offeringId;
			}
			$Gadget.$Emit("$bes.oc.selectCommodity",
					$Gadget.chooseCommodity.selectItem);
			if($Page.tabIndexFlag==0||$Page.tabIndexFlag==1||$Page.tabIndexFlag==2){
				$("#offeringNameDetail" + $Page.tabIndexFlag).hide();
				$("#offeringNameDetailPop" + $Page.tabIndexFlag).hide();
			}
			else{
				$("#offeringNameDetail").hide();
				$("#offeringNameDetailPop").hide();
			}
		});

$Controller(
		"bes.oc.spinfo.init",
		function($Event, $Gadget, $scope, $Fire, $UI) {
			debugger;
			var input = {};
			if ($Event && $Event.$Data) {
				input = $Event.$Data.input;
			}

			$Fire(
					{
						'service' : 'bes.oc.productdetailservice/getproductdetail',
						'params' : {
							'input' : input,
						},
						'target' : '$Gadget.data.spproductdetail',
						'onafter' : function($Gadget, $Fire, $UI) {
							debugger;
							/*$Gadget.data.spproductdetail.businessType = $
									.parseJSON($Gadget.data.spproductdetail.businessType);*/
							if ($Gadget.data.spproductdetail.pcOfferingAttributeTRSVOs) {
								$
										.each(
												$Gadget.data.spproductdetail.pcOfferingAttributeTRSVOs,
												function(i, v) {
													// 计费类型
													if (v.attributeCode
															&& v.attributeCode == "C_O_PAYMENT_MODE") {
														$Gadget.data.spproductdetail.priceType = JSON
																.parse(v.value).LABEL;
													}
													// 价格
													if (v.attributeCode
															&& v.attributeCode == "C_O_MONTHLY_FEE") {
														$Gadget.data.spproductdetail.price = JSON
																.parse(v.value);
													}
												});
							}

							if ($Gadget.data.spproductdetail.pcOfferingAttributeTRSVOs) {
								for ( var i = 0; i < $Gadget.data.spproductdetail.pcOfferingAttributeTRSVOs.length; i++) {
									if ($Gadget.data.spproductdetail.pcOfferingAttributeTRSVOs[i].attributeId == 1426489070769194977) {
										$Gadget.data.spproductdetail.price = $
												.parseJSON($Gadget.data.spproductdetail.pcOfferingAttributeTRSVOs[i].value).VALUE;
									}
								}
							}
							if (null == $Gadget.data.spproductdetail) {
								$UI.msgbox.error("提示", "未查询到此商品详细信息。");
								return false;
							}
							$Gadget.data.spproductdetail.price = adutil
									.getDisplayPrice($Gadget.data.spproductdetail.price);
							$Gadget.offeringNameDetail = true;
							if($Page.tabIndexFlag==0||$Page.tabIndexFlag==1||$Page.tabIndexFlag==2){
								$("#offeringNameDetail" + $Page.tabIndexFlag).show();
								$("#offeringNameDetailPop" + $Page.tabIndexFlag).show();
							}
							else{
								$("#offeringNameDetail").show();
								$("#offeringNameDetailPop").show();
							}
						},
						'onerror' : function() {
							$UI.msgbox.error("提示", "未查询到此商品详细信息。");
						}
					}, $Gadget);
		});
