$Controller("bes.oc.supplycard", {
	beforeInif:function($Gadget,$UI,$Page){
		debugger;
		// 获取系统参数
		// 是否记录本地日志文件 Y:记录 N:不记录
        $Page.writeLocalFile = "N";

        adutil.querySysParams("writeLocalFile", $Gadget, function(){
			debugger;
			$Page.writeLocalFile = $Gadget.sysparamResult["writeLocalFile"] || "N";
        });

		//判断是否是以往用户业务
		var diffLocated = adutil.getParam("difflocated");
		if(diffLocated){
			$Page.diffLocated = 'Y';
			OC.Callchain.setFireSearch($Page.pageId, "supycard");
			//调用后台接口，判断当前用户是否登陆
			//1.如果登陆 判断用户归属地和操作员归属地是否相同，相同则需要重新登陆. 不相同则可以办理该业务直接走
			//2.如果未登录 直接走else逻辑。
			$Gadget.$Get('$Fire')({
				service:'agentdesktop/v1/person/judgeuserloginandisdiff',
				target:'$Gadget.data.diffLocatedResp',
				onafter:function(){
					var resp =$Gadget.data.diffLocatedResp;
					var body = (resp||{}).body||{};
					// MODIFY 2015-10-27 by l00289267 DTS2015102601183 start
					if('Y' != body.loginStatus || ('Y' == body.loginStatus && 'Y' != body.diffLocated)){
						//说明本地市用户登陆 ，需要重新登陆
						$("#orderauthentication").show();
						$("#userOrderInfoCon").hide();
					}
					else{
						OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
						$Gadget.$Get('$Fire')({
							service:'bes.oc.ocsupplyservice/queryinfo',
							target:'$Gadget.data.info',
							onafter:function(){
								$Controller.bes.oc.supplycard.queryMobileParam($Gadget,$UI,$Page);
							}
						},$Gadget);
					}
					// MODIFY 2015-10-27 by l00289267 DTS2015102601183 end
				}

			},$Gadget);
		}
		else{
			$Gadget.$Get('$Fire')({
				service:'bes.oc.ocsupplyservice/queryinfo',
				target:'$Gadget.data.info',
				onafter:function(){
					$Controller.bes.oc.supplycard.queryMobileParam($Gadget,$UI,$Page);
				}
			},$Gadget);
		}

		var requestBody = {
			    seniorId : "ADD_SIMCARD",
			    eventId : "ADD_SIM_COMM",
			    busiCode : "ChangeSIMCard"
			};
		var menuId = _ysp_top.TabSet.getTabItem().key;
		if ("601312018011001" == menuId || "601312018011002" == menuId) {
			if ("AuthCheckA" != window._ysp_top.loginReq.authType) {
				$UI.msgbox.error(
					$UEE.i18n("ad.person.message.information"),
					'只允许\“短信验证码\“方式登录用户办理换卡业务！',
					function okBack() {
						_ysp_top.TabSet.closeTabItem(_ysp_top.TabSet.getTabItem().key);
					},
					null,
					function closeBack() {
						_ysp_top.TabSet.closeTabItem(_ysp_top.TabSet.getTabItem().key);
					}
				);
			}
		}else{
			//查询出补卡用户能够进行补卡的鉴权字典数据
			//$Controller.bes.oc.supplycard.getDictData($Gadget,$UI);
			//补卡页面只允许用身份证登录或者证件+密码方式登录来操作。
			//$Controller.bes.oc.supplycard.hasSupplyCardAuth($Gadget,$UI);
		}
	},

	hasSupplyCardAuth : function($Gadget,$UI){
		debugger;
		var cerType = window._ysp_top.loginReq.authType;
		//如果补卡允许的鉴权方式的字典为空
		if ($Gadget.data.code.length == 0)
		{
			$UI.msgbox.error(
					$UEE.i18n("ad.person.message.information"),
					'请联系管理员配置补卡允许的鉴权方式！',
					function okBack() {
						//window._ysp_top.loginReq.authType = "";
						_ysp_top.TabSet.closeTabItem(_ysp_top.TabSet.getTabItem().key);
					},
					null,
					function closeBack() {
						//window._ysp_top.loginReq.authType = "";
						_ysp_top.TabSet.closeTabItem(_ysp_top.TabSet.getTabItem().key);
					}
				);
			return;
		}
		//补卡允许的鉴权方式
		if (!($Gadget.data.code|| []).contain(cerType))
		{
			$UI.msgbox.error(
					$UEE.i18n("ad.person.message.information"),
					'只允许'+$Gadget.data.name.toString().replace(/,/g,"、")+'方式登录用户办理补卡业务！',
					function okBack() {
						//window._ysp_top.loginReq.authType = "";
						_ysp_top.TabSet.closeTabItem(_ysp_top.TabSet.getTabItem().key);
					},
					null,
					function closeBack() {
						//window._ysp_top.loginReq.authType = "";
						_ysp_top.TabSet.closeTabItem(_ysp_top.TabSet.getTabItem().key);
					}
				);
			return;
		}
	},

	//查询BOSS预付费或后付费接口是否隔离
	isBossIntfSolated : function($Page,$Gadget){
		debugger;
		var currMenuId = null;
		if(_ysp_top.TabSet){
			currMenuId = _ysp_top.TabSet.getTabItem().key
		}
		$Fire = $Gadget.$Get('$Fire');
		$Fire({
	        service : '/isolatebossintfservice/isBossIntfListIsolated_query',
	        params:{
	        	menuId : currMenuId
	        },
	        target : '$Gadget.BossIntfIsolateResp',
	        onafter : function($Gadget,$Page){
				debugger;
				$Gadget.BossIntfIsolateResp = $Gadget.BossIntfIsolateResp || {}
				if($Gadget.BossIntfIsolateResp.bossIntfIsolateList && $Gadget.BossIntfIsolateResp.bossIntfIsolateList.length > 0){
					var isHaveIsolated = false;
					for(var i=0;i<$Gadget.BossIntfIsolateResp.bossIntfIsolateList.length;i++){
						var bossIntfIsolated = $Gadget.BossIntfIsolateResp.bossIntfIsolateList[i];
						if(bossIntfIsolated.isolated == '1'){
							isHaveIsolated = true;
							break;
						}
					}
					if(isHaveIsolated){
						$Gadget.$Get('$UI').msgbox.confirm($UEE.i18n('ad.sr.message.TS'),"因系统问题，目前无法查询用户欠费信息，请确认是否继续办理。",
								function(){
								debugger;
								//确定按钮继续操作业务
								return;
							},
							function(){
								//取消按钮 关闭当前页面
								debugger;
								if (_ysp_top.publicObject) {
									Close_tabSet();
								}
								else{
									window.close();
								}
							});
					}
				}
			}
		},$Gadget);
	},
	queryMobileParam:function($Gadget,$UI,$Page){
		// 获取系统参数，存放的是手机代付费无线宽带的prodId
		debugger;
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
		$Fire = $Gadget.$Get('$Fire');
		$Fire({
			service : 'ucec/v1/common/qrysystemparambykey',
			params : {
				key : "MobileWirelessBandProdId"
			},
			target : "$Gadget.mobileWirelessBandProdId",
			onafter:function(){
				debugger
				OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
				// 获取系统参数，存放的是手机代付费宽带的prodId
				$Fire({
					service : 'ucec/v1/common/qrysystemparambykey',
					params : {
						key : "MobileBandProdId"
					},
					target : "$Gadget.mobileBandProdId",
					onafter:function(){
						debugger;
						$Controller.bes.oc.supplycard.init($Gadget,$UI,$Page);
					}
				}, $Gadget);

			}
		}, $Gadget);


	},

	//初始化数据
	init : function($Gadget,$UI,$Page) {
		debugger;
		//号卡校验可点击
		$Gadget.$Page.simcardValidateFlag = true;
		//设置卡号未校验
		$Gadget.$Page.checkSimAndTelNumResult = false;
		$Gadget.data.newCardInfo = null;
		$Gadget.data.changeImsi = null;
		$Gadget.data.prodInstId = null;
		$Gadget.data.cardNo = null;
		$Page.offeringList = [];
		$Gadget.data.info = $Gadget.data.info || [];
		$Gadget.data.cardInfo = $.extend(true, {}, $Gadget.data.info.cardInfoPojo) || [];
		$Gadget.data.cardInfoshow = $.extend(true, {}, $Gadget.data.info.cardInfoPojo) || [];
		$Gadget.data.oldNumber = null;
		if($Gadget.data.info){
			$Page.telNumber = [$Gadget.data.info.telNumber];
		}


		if($Gadget.data.info.prodInst.length > 0){
			for(var i = 0;i < $Gadget.data.info.prodInst.length;i++){
				if($Gadget.data.info.prodInst[i].imsi){
					$Gadget.data.addServiceTime = $Gadget.data.info.prodInst[i].exField1;
				}
				//$Gadget.mobileWirelessBandProdId手机代付费无线宽带的prodId
				if($Gadget.data.info.prodInst[i].prodId == $Gadget.mobileWirelessBandProdId){
					$Gadget.data.info.prodInst.splice(i,1);
					//$Controller.bes.oc.supplycard.removeElement(i,$Gadget.data.info.prodInst);
				}
			}
		}
		//从统一视图传过来手机代付费宽带的offerid
		$Page.mobileBandOfferId = $Gadget.$Params.mobileBandOfferId;
		//标识是否选择了手机代付费宽带增值补卡，$Gadget.mobileBandProdId唯一代表手机代付费宽带的prodid
		if($Page.mobileBandOfferId && $Page.mobileBandOfferId !='undefined' ){
			$Page.mobileBandFlag = true;
		}

		//增值业务类型
		$Gadget.data.prodInst = null;
		if(null != $Gadget.data.prodInst && $Gadget.data.info.prodInst.length > 0){
			for(var i = 0;i < $Gadget.data.info.prodInst.length;i++){
				var type = {};
				type.key = $Gadget.data.info.prodInst[i].typeCode;
				type.value = $Gadget.data.info.prodInst[i].typeName;
				if($Gadget.data.info.prodInst[0].prodId == $Gadget.mobileBandProdId){
					$Page.mobileBand = true;
				}
				if(i == 0){
					type.selected = true;
				}else{
					type.selected = false;
				}
				$Gadget.data.prodInst.push(type);
			}
		}else{
			//$Gadget.data.prodInst = [{}];
			$Gadget.data.prodInst = null;
		}

		if(null != $Gadget.data.prodInst)
		{
			var addServiceList = new UCD.Droplist($("#addServiceList"),$Gadget.data.prodInst);
			addServiceList.enableInput(false);
			addServiceList.init();


			//业务类型改变
			addServiceList.setOnValueChange(function(){
				$Page.mobileBand = false;
				var key = addServiceList.$input.attr('key');
				if(null != $Gadget.data.prodInst)
				{
					for(var i = 0;i < $Gadget.data.prodInst.length;i++){
						if(key != $Gadget.data.prodInst[i].key){
							$Gadget.data.prodInst[i].selected = false;
						}else{
							$Gadget.data.prodInst[i].selected = true;
							$Page.telNumber = [$Gadget.data.info.prodInst[i].telNum];
							$Gadget.data.oldNumber = $Gadget.data.info.prodInst[i].telNum;
							$Gadget.data.subProdId = $Gadget.data.info.prodInst[i].prodId;
							$Controller.bes.oc.supplycard.getOldInfo($Gadget,$Gadget.data.info.prodInst[i].imsi,$Gadget.data.info.prodInst[i].prodInstId);
							if($Gadget.data.prodInst[i].prodId == $Gadget.mobileBandProdId){
								$Page.mobileBand = true;
							}
						}
					}
				}

			});
		}


		//补卡原因
		$Gadget.data.reasonList = [];
		if($Gadget.data.info.reasonList){
			for(var i = 0;i < $Gadget.data.info.reasonList.length;i++){
				var reason = {};
				reason.key = $Gadget.data.info.reasonList[i].itemCode;
				reason.value = $Gadget.data.info.reasonList[i].itemName;
				if(i == 0){
					reason.selected = true;
				}else{
					reason.selected = false;
				}
				$Gadget.data.reasonList.push(reason);
			}

			var reasonList =  new UCD.Droplist($("#reasons"),$Gadget.data.reasonList);
			reasonList.enableInput(false);
			reasonList.init();

			//补卡原因改变
			reasonList.setOnValueChange(function(){
				debugger;
				var key = reasonList.$input.attr('key');
				for(var i = 0;i < $Gadget.data.reasonList.length;i++){
					if(key != $Gadget.data.reasonList[i].key){
						$Gadget.data.reasonList[i].selected = false;
					}else{
						$Gadget.data.reasonList[i].selected = true;
					}
				}
			});
		}

		//初始化控件
		var commonCardR = new UCD.Radio($("#commonCardR"),$UEE.i18n("ad.person.message.CommonCard"),"supplyType", function(obj,$dom,status){
			//$(".cover").show();
			$Gadget.data.supplyCardTime = "commonCardTime";
			$('#addServiceList').hide();
			if(status){
				debugger;
				$Gadget.$safeApply($Gadget,function(){
					$Gadget.data.cardInfoshow = $Gadget.data.cardInfo;
					$Page.telNumber = [$Gadget.data.info.telNumber];
					$Gadget.data.oldNumber = $Gadget.data.info.telNumber;
					});
			}else if($Gadget.data.info.prodInst.length > 0){
				debugger;
				if (null != $Gadget.data.prodInst)
				{
					for(var i = 0;i < $Gadget.data.prodInst.length;i++){
						if($Gadget.data.prodInst[i].selected == true){
							$Page.telNumber = [$Gadget.data.info.prodInst[i].telNum];
							$Gadget.data.oldNumber = $Gadget.data.info.prodInst[i].telNum;
							$Gadget.data.subProdId = $Gadget.data.info.prodInst[i].prodId;
							$Controller.bes.oc.supplycard.getOldInfo($Gadget,$Gadget.data.info.prodInst[i].imsi,$Gadget.data.info.prodInst[i].prodInstId);
							break;
						}
					}
				}

			}
		}).check();
		//增值业务卡
		if(!$Page.diffLocated ){
			var addServiceCardR = new UCD.Radio($("#addServiceCardR"),$UEE.i18n("ad.person.message.VAddedCard"),"supplyType", function(){
				//$(".cover").hide();
				$Gadget.data.supplyCardTime = "addServiceCardTime";
				$('#addServiceList').show();
			});
		}

			if($Gadget.data.info.prodInst.length == 0){
				addServiceCardR.enable(false);
			}
			//金库鉴权需要此号码鉴定是否是吉祥号码
			$('#phone_field').val($Page.serviceNum);
			$Gadget.data.oldNumber = $Gadget.data.info.telNumber;
	},

	//根据选择类型显示对应的旧卡信息
	getOldInfo : function($Gadget,imsi,prodInstId){
		debugger;
		$Gadget.data.changeImsi = imsi;
		$Gadget.data.prodInstId = prodInstId;
		$Gadget.$Emit('$bes.oc.supplycard.getoldinfo');
	},

	//验证现象说明的字数限制
	validatetext : function($Gadget,$UI){
		debugger;
		var desc = $("#desc").val();
		if($Controller.bes.oc.supplycard.checkInputdata(desc)){
			if(this.len($.trim(desc)) > 192){
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.DescriptionTooLong"));//'提示','现象说明描述过长。'
				return false;
			}else{
				return true;
			}
		}else{
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.SymptomDescriptionContainsInvalidChars"));//'提示','您输入的现象说明含非法字段。'
			return false;
		}
	},

	//验证免费补卡原因的字数限制
	validatereason : function($Gadget,$UI){
		debugger;
		var reason = $("#freeReasons").val();
		if($Controller.bes.oc.supplycard.checkInputdata(reason)){
			if(this.len($.trim(reason)) > 30){
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.ReasonForCardReissuingFeeTooLong"));//'提示','免费补卡原因描述过长。'
				return false;
			}else{
				return true;
			}
		}else{
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.FreeCardReissuingReasonContainsInvalidFields"));//'提示','您输入的免费补卡原因含非法字段。'
			return false;
		}
	},

	// 当输入字符为中文时，长度为3个字节
	len : function(str) {
		debugger;
		return str.replace(/[^\x00-\xff]/g, "xxx").length;
	},

	// JS注入校验
	checkInputdata : function(param) {
		debugger;
		var chechdata = param.toUpperCase();
		if (chechdata.indexOf("<") >= 0 || chechdata.indexOf(">") >= 0
				|| chechdata.indexOf("/") >= 0
				|| chechdata.indexOf("SCRIPT") >= 0) {
			return false;
		}
		return true;
	},

	//输入新卡号码时，号卡校验按钮灰掉
	keyUp : function($Gadget){
		debugger;
		$("#validateCard").attr("disabled","disabled");
	},

	//校验新卡类型,无类型则报错
	validateCardType : function($Gadget,$UI){
		debugger;
		$("#validateCard").removeAttr("disabled");

		if(!$Gadget.data.newCardInfo || !$Gadget.data.newCardInfo.typeName){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.NewCardNumberInvalidPLSReEnter"));//'提示','您录入的新卡号无效，请重新录入。'
			$Gadget.data.newCardInfo = null;
			return false;
		}

		// DTS2016052407193 begin
		if($Gadget.data.cardInfoshow.iccidValue == $Gadget.data.newCardInfo.iccidValue){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.NewCardNoAsOldNumber"));//'提示','您录入的新卡号和原卡号相同，请重新录入。'
			$Gadget.data.newCardInfo = null;
			return false;
		}

		if($Gadget.data.newCardInfo.isAvailable == 0){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.NewCardUnsalableReEnterNumber"));//'提示','您录入的新卡号不可售，请重新录入。'
			$Gadget.data.newCardInfo = null;
			return false;
		}

		//end

		if($Gadget.$Page.checkSimAndTelNumResult)
		{
			//如果是写卡 成功后，则加载补卡原因
			$Controller.bes.oc.supplycard.getFreeSupplyUserInfo($Gadget,$Gadget.$Get('$Fire'));
		}

		$Page = angular.element(document).scope().$Page;
		OC.Callchain.setFireSearch($Page.pageId, "scCard01");
	        	    	if ($Gadget.data.newCardInfo.is4GSimCard == "N") {
					if ($Gadget.data.newCardInfo.hasLTE == "Y") {
						$UI.msgbox.info('提示', '开通4G功能的用户不允许更换非4G－USIM卡');
						$Gadget.data.newCardInfo = null;
						return false;
					}
			}
		//
		return true;
	},

	//根据卡号返回卡号的状态
	getStatus : function($Gadget,$UI){
		debugger;
		if(!$Gadget.data.oldNumber){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n('ad.person.message.OldCardInforIncorrectCanNotBeRessued'));//'提示','旧卡信息有误，不能补卡。'
			return false;
		}
		if(!$Gadget.data.flag){
			if($Gadget.data.newCardInfo == null){
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.FailToVerfyNewCardandNumberReEnter"));//'提示','号卡校验失败，您输入的新卡号无效，请重新输入。'
				return false;
			}else{
				if(!$Gadget.data.newCardInfo.typeName || $Gadget.data.newCardInfo.typeName==null || $Gadget.data.newCardInfo.typeName == "")
				{
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.Invalid CardWriteCardForEmptyCard"));//'提示','不是有效的实体卡，如果是空白卡请先写卡。'
					return false ;
				}
				else{
					return true;
				}
			}
		}else{
			return true;
		}
	},

	//卡号状态
	cardStatus : function($Gadget,$UI){
		debugger;
		// 记录号卡校验结果
		writeLocalFile($Gadget.$Page, "号卡校验结果：" + $Gadget.data.flag);

		if($Gadget.data.flag){
			//设置号卡校验校验
			$Gadget.$Page.checkSimAndTelNumResult = true;
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.CardAvaliable"));//'提示','该卡可用，请及时购买。'

			//校验成功后加载补卡原因
			$Controller.bes.oc.supplycard.getFreeSupplyUserInfo($Gadget,$Gadget.$Get('$Fire'));
			return true;
		}else{
			//设置号卡校验未校验
			$Gadget.$Page.checkSimAndTelNumResult = false;
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.CardUnavaiableReEnter"));//'提示','该卡不可用，请重新录入新卡号码。'
			return false;
		}
	},

	// 校验SIM卡类型同OFFER的对应关系
	checkcardtype: function($Gadget, $Fire, $UI, $Page)
	{
		debugger;
		if(!$Page.mobileBandOfferId){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),  $UEE.i18n("ad.person.message.FailedtoObtainOfferingID"));//"提示", "获取商品Id失败。"
			$Gadget.checkoffercardtypeLoading = false;
			return false;
		}
		if(!$Gadget.data.newCardInfo.skuCode){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.FailedtoObtainCardInforAboutOffering"));//"提示", "获取商品卡信息失败。"
			$Gadget.checkoffercardtypeLoading = false;
			return false;
		}

		OC.Callchain.setFireSearch($Page.pageId, "cardType");
		$Fire({
			service:'bes.oc.ocsupplyservice/checkoffercardtype',
			params : {
				offerid : $Page.mobileBandOfferId,
				skucode : $Gadget.data.newCardInfo.skuCode || ""
			},
			target: '$Gadget.data.checkoffercardtypeValue',
			onafter: function() {
				if (!$Gadget.data.checkoffercardtypeValue)
				{
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CurrentSIMCardNotMatchProductType"));//"提示", "当前SIM卡类型同产品类型不匹配。"
					$Gadget.checkoffercardtypeLoading = false;
					return false;
				}
				else
				{
					$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.VerificationSuccessful"));//"提示", "校验通过。"
					$Gadget.checkoffercardtypeLoading = true;
				}
			},
			onerror: function(){
			    $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SIMCardVerficationFailed"));//"提示", "校验SIM卡类型失败。"
			    $Gadget.checkoffercardtypeLoading = false;
			}
		}, $Gadget);

	},

	//提交补卡信息
	submit : function($Gadget,$UI,$Fire,$Page){
		debugger;
		// MODIFY 2015-12-1 modify reason:规避金库鉴权导致$Gadget变量被覆盖。
		var $Gadget = adutil.getGadgetObj($('.bes-ad-supplycard'));
		/*if(!$Controller.bes.oc.supplycard.validatereason($Gadget,$UI)
				|| !$Controller.bes.oc.supplycard.validatetext($Gadget,$UI)){
			return false;
		}*/
		
		//DTS2018021102425 空白卡补卡，读卡未完成不允许提交
		if(!$Gadget.simcardReadFlag && $Gadget.isUseBlankCard){
			return false;
		}
		//提交前校验是否进行了卡类型校验，没有则进行提示
		if($Page.mobileBandFlag)
		{
			if (!$Gadget.checkoffercardtypeLoading)
			{
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.PleaseverifyCardType"));//"提示", "请对卡类型进行校验。"
				return false;
			}
		}

		if(!$Gadget.data.cardInfoshow.iccidValue || !$Gadget.data.oldNumber){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.OldCardInforinCorrectCannotBeReissued"));//'提示','旧卡信息有误，不能补卡。'
			return false;
		}

		if(!$Gadget.data.newCardInfo){
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.NewCardUnavailableReEnterNumber"));//'提示','您录入的新卡不可用，请重新录入新卡号码。'
			return false;
		}

		if (!$Gadget.$Page.checkSimAndTelNumResult) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.CardNumbernotCheckorCheckFailed"));//"提示", "号卡未校验或校验失败。"
			return false;
		}

		$Gadget.checkoutValidateReq = {};

		var offerings = [];
		var offering = {};
		var opCode = "1";
		var isFreeChgSim = ($Gadget.data.freeSupplyCard.body || {}).isFreeChgSim;
		var freeReasonKey = $("#freeReasons .inputbox").attr("key");
		var reasonKey = $("#reasons .inputbox").attr("key");
		var descKey = $Gadget.data.desc;
		offering.offeringId = $Gadget.data.newCardInfo.offeringId;
		offering.offeringName = $Gadget.data.newCardInfo.typeName;
		offering.relaItemId = adutil.getNextNumber();
		offering.opCode = opCode;
		offerings.push(offering);

		// 免费补卡：正常补卡
		if ("1" == isFreeChgSim && "5" == freeReasonKey) {
			isFreeChgSim = "0";
		}

		var product = {};
		if($("#commonCardR .radio").hasClass("checked")){
			product.prodId = $Gadget.data.info.mainProductId;
			product.prodInstId = $Gadget.data.info.mainProdInstId;
		}
		else{
			product.prodId = $Gadget.data.subProdId;
			product.prodInstId = $Gadget.data.cardInfoshow.prodInstId;
		}
		product.relaItemId = adutil.getNextNumber();
		var oldCardInfo = $Gadget.data.info.cardInfoPojo;
		var newCardInfo = $Gadget.data.newCardInfo;
		var blankcard=$Page.blankCardNo;
		OC.Callchain.setFireSearch($Page.pageId, "sc1Btn01");

		if($Page.diffLocated =='Y'){
    		$Page.backStep = "index";
    		$Page.supplycardbody = {offerings:offerings,oldCardInfo:oldCardInfo,newCardInfo:newCardInfo,product:product,blankCard : blankcard,isFreeChgSim:isFreeChgSim,freeReason:freeReasonKey,reason:reasonKey,desc:descKey};
    		$Gadget.$Get('$Fire')({targetstep:'checkoutold'});

    		// 跳到结算页面引入样式
			 $("<link>").attr({
						rel: "stylesheet",
				type: "text/css",
				href: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/base.css"
			 	}).appendTo("head");
			return ;
		}


		$Page.checkoutInfo = {
				businessName:$UEE.i18n("ad.person.message.ReissueCard"),//补卡
				serviceNumber:adutil.getParam("servnum")
		};

		$Page.checkoutValidateBody = {businessType: "ChangeSIMCard",
				createOrderReq:{
					order:{
						orderPayment:[]
					}
				},
			mixturePOJO:{
				supplyCardBody:{offerings:offerings,oldCardInfo:oldCardInfo,
						newCardInfo:newCardInfo,product:product,blankCard : blankcard,isFreeChgSim:isFreeChgSim,freeReason:freeReasonKey,reason:reasonKey,desc:descKey}
			}
		}

		OC.Callchain.setFireSearch($Page.pageId, "submit");
		$Fire({
			service : 'bes.agentdesktop.checkoutboservice/busivalidate?OperType=BES032',
			params:{
	        	header:{},
	        	checkoutbody: $Page.checkoutValidateBody
			},
	        target : '$Page.checkoutValidateResult',
	        onafter : function(){
	        	debugger;
	        	var $Page = $(document).scope().$Page;

	        	if (adutil.checkUcecResp($Page.checkoutValidateResult.header, $UI)) {
	        		var busiValidCheck = adutil.checkBusiValidResp(null,$UI,$Page.checkoutValidateResult.body.checkOutResp, function(){
						// 点击确认按钮表示继续执行，到结算页面
						debugger;
						$Page.backStep = "index";
		        		$Gadget.$Get('$Fire')({targetstep:'checkout'});

		        		// 跳到结算页面引入样式
						 $("<link>").attr({
	 							rel: "stylesheet",
	       					type: "text/css",
	       					href: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/base.css"
	   				 	}).appendTo("head");

					});
					if(busiValidCheck){
						debugger;
						$Page.backStep = "index";
		        		$Gadget.$Get('$Fire')({targetstep:'checkout'});

		        		// 跳到结算页面引入样式
						 $("<link>").attr({
	 							rel: "stylesheet",
	       					type: "text/css",
	       					href: window.location.protocol + "//" + window.location.host + $(document).scope().$Webapp + "/bes/ad/css/base.css"
	   				 	}).appendTo("head");

					}
				}
	        }
		}, $Gadget);
	},

	goToSupplyCard : function($Gadget, $UI, $Fire, $Page) {
		debugger;
		// 删除结算页面样式
		var linkFileTemp = $("link") || [];
		var linkFileLen = linkFileTemp.length;
		for ( var i = 0; i < linkFileLen; i++) {
			if (linkFileTemp.eq(i).attr("href").indexOf(
					"bes/ad/css/base.css") > 0) {
				linkFileTemp.eq(i).remove();
			}
		}
		$(".supply_card").show();
		$("#paymentContent").hide();
		$("#paymentFinishStep").hide();
	},

	getFreeSupplyUserInfo : function($Gadget, $Fire) {
		debugger;
        $Page = angular.element(document).scope().$Page;
        OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);

		$Fire({
			service : 'ucec/v1/customer/freechgsim_check',
			params : {
				"header" : null,
				"body" : {"subsId":$Gadget.data.info.subsId,
						  "newCardType":$Gadget.data.newCardInfo.skuCode
					}
			},
			target:'$Gadget.data.freeSupplyCard',
			onafter:function(){
				debugger;
				if(($Gadget.data.freeSupplyCard.body||{}).lastChgSimTime){
					$Gadget.data.freeSupplyCard.lastTimeDesc = (new Date($Gadget.data.freeSupplyCard.body.lastChgSimTime)).Format("yyyy-MM-dd hh:mm:ss");
				}
				else{
					$Gadget.data.freeSupplyCard.lastTimeDesc = $UEE.i18n("ad.person.message.None");//无
				}

				// 免费补卡原因
				if($Gadget.data.freeSupplyCard.body.freeChgSimReasonList){
					if ($Gadget.data.freeSupplyCard.body.freeChgSimReasonList[0]){
						$Gadget.data.freeSupplyCard.body.freeChgSimReasonList[0].selected=true;
					}
					$("#freeReasons").html("");
					var reasonList =  new UCD.Droplist($("#freeReasons"),$Gadget.data.freeSupplyCard.body.freeChgSimReasonList);
					reasonList.enableInput(false);
					reasonList.init();
				}
			}

		}, $Gadget);
	},

	/**
	 * 金库鉴权
	 */
	treasuryinit:function($Scope){
		debugger;
		try{
			$Page = angular.element(document).scope().$Page;
			OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
			treasury.init($Scope);
		}catch(e){

		}
	},
	subloginSuccess:function($Gadget,$Fire,$Page,$UI){
		debugger;
		$("#orderauthentication").hide();
		$("#userOrderInfoCon").show();
		OC.Callchain.setFireSearch($Page.pageId, $Page.fireId);
		$Gadget.$Get('$Fire')({
			service:'bes.oc.ocsupplyservice/queryinfo',
			target:'$Gadget.data.info',
			onafter:function(){

				$Controller.bes.oc.supplycard.init($Gadget,$UI,$Page);
			}
		},$Gadget);
	},
	/**
	 * 查询字典信息
	 */
	getDictData : function($Gadget,$UI){
		debugger;
		$Gadget.data = $Gadget.data || {};
		$Gadget.data.code = [];
		$Gadget.data.name = [];
		$Gadget.$Get('$Fire')({
				service : "/common/dictkey2",
				params : {
						dictkeylist : [ 'BKLOGIN']
					},
				target : "$Gadget.dataDictResp",
				onafter : function() {
				debugger;
				var tempData = $Gadget.dataDictResp["BKLOGIN"]||[];
				$.each(tempData, function(i, val) {
						$Gadget.data.code.push(val.key);
						$Gadget.data.name.push(val.value);
					});
				//补卡页面只允许用身份证登录或者证件+密码方式登录来操作。
				$Controller.bes.oc.supplycard.hasSupplyCardAuth($Gadget,$UI);
				}
			}, $Gadget);
	}

});

//补卡结算需要金库鉴权   原有js方法过长超出表子弹  所以需要重新改造原有的方法
var beforeSubmit = function($Gadget,$Page){
	debugger;
	// 增加业务类型
	$Page.businessCode = 'PreChangeSIMCard';
	window._ysp_top.businessCode = 'PreChangeSIMCard';

	$UI = $Gadget.$Get('$UI');
	$Fire = $Gadget.$Get('$Fire');
	//增加金库鉴权后 SM调用原有逻辑直接eval 所以就不会触发region这个校验规则了  所以提交前必须再次调用region进行校验
	$Fire({"region" : "$Gadget.data",
		"script" : "$Controller.bes.oc.supplycard.submit($Gadget,$UI,$Fire,$Page)"
	},$Gadget);

};

