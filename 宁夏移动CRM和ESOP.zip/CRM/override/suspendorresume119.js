$Controller(
		"bes.oc.suspendorresume",
		{
			initReqServnum : function($Gadget,$Page)
			{
				debugger;
				$Page.pageId = 'StopOp';
				$Page.functype ='BLCS_StopOpenPT';
                $Page.isCsp = $Controller.bes.ad.csp.common.isCsp();
				if ($Controller.bes.ad.csp.common.isCsp())
				{
					$Page.phonenum = $Controller.bes.ad.csp.common.getServNumber();
				}
				else
				{
					$Page.phonenum = OC.Callchain.getServNum();
					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
				}
				$Gadget.servNumber = $Page.phonenum;
				$Gadget.ReservedTimeFlag=false;
				$Gadget.stopOpenReservedEndTimeFlag=false;
				$Gadget.$Get('$Fire')({											
					'service' : '/common/dictkey',
					'params' :  {
						"dictkeylist" : ['OC.SUSPEND.RESUME.TYPE','SMS_NETTYPE']
					},
					'target' : '$Gadget.stopOpenDict',
					'onafter': function(){
						debugger;
						$Gadget.SusResumeDict= $Gadget.stopOpenDict["OC.SUSPEND.RESUME.TYPE"]||[];
						$Page.smsNetTypeList = $Gadget.stopOpenDict["SMS_NETTYPE"];
						
						}
					},$Gadget);
				return true;				
			},
			//初始化渠道
			channelInit : function ($Gadget,$Page,$UI)
			{
				debugger;
				$Controller.bes.oc.suspendorresume.initReqServnum($Gadget,$Page);
				//客服渠道
				if ($Controller.bes.ad.csp.common.isCsp())
				{
					$Controller.bes.oc.suspendorresume.checkAuthenticationStatus($Gadget,$Page,$UI);
				}
				//营业厅渠道
				else
				{
					$Controller.bes.oc.suspendorresume.suspendinit($Page,$Gadget);
				}
			},			
			
			suspendinit:function($Page,$Gadget){
				debugger;
				//判断是否是以往用户业务
				OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
				$Gadget.$Emit("$OC.Suspendorresume");
			},

			
			// 初始化是否发送短信的单选框
			initCheckBox : function($Page) {
				debugger;				
				if ($Page.firstQueryStatusFlag == 'true') {
					
					$Page.firstQueryStatusFlag = 'false';
				} else {
					return false;
				}
			},
			//判断是否已登录
			checkAuthenticationStatus : function($Gadget,$Page,$UI)
			{
				debugger;
				try {
					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
				} catch (e) {
				}
				$Gadget.$Get('$Fire')
				({
					service: '/bes.oc.subscribeinfoservice/issubscribelogin',
					target : "$Gadget.login",
					onafter : 
						function ($Gadget,$Page,$UI)
						{
							debugger;
							if ($Gadget.login.loginStatus)
							{
								//客服渠道需进行一次模拟登录
								$Controller.bes.ad.csp.common.login($Page,$Gadget.$Get('$Fire'),$Gadget,$UI,$Gadget.servNumber,$Controller.bes.oc.suspendorresume.loginSuccess,$Controller.bes.oc.suspendorresume.logingFail);
							}
							else
							{
								$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.obtainUserFailed"));
							}
						}
				},$Gadget);
			},
			
		//用户登陆
			loginSuccess : function($Page,$Fire,$Gadget,$UI)
			{
				debugger;
				try {
					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getInitFireId());
				} catch (e) {
				}
				$Fire({
						service: 'bes.oc.provide.suspendorresumeserviceimpl/init2',
						target : "$Gadget.data.suspendOrResumeData",
						onafter : function ($Gadget,$Page){
							debugger;
							$Controller.bes.oc.suspendorresume.initSubscriber($Gadget,$Page,$UI);
						}
					},$Gadget);
			},
			
			logingFail : function($Page,$Fire,$Gadget,$UI)
			{
				debugger;
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.authenticationFailed"));
			},
		//未割接号码登录时提示不能操作
		checkIfNotMigratedUser : function($Page, $Gadget){
			
			// 构造临时停机数据。
			//$Controller.bes.oc.suspendorresume.injectSuspandData($Gadget);
			
			$UI = $Gadget.$Get("$UI");
			$Fire = $Gadget.$Get("$Fire");
			debugger;
			$Gadget.$Get('$Fire')({
				service:'agentdesktop/v1/person/judgeuserloginandisdiff',
				target:'$Gadget.diffLocatedResp',
				onafter:function(){
					debugger;
					if( (($Gadget.diffLocatedResp||{}).body).migratedUser!= true ){
						$UI.msgbox.error("提示", "未割接地号码请使用'割接期间异地停开机'菜单",function(){
							if (_ysp_top.publicObject) {
								Close_tabSet();
							}
							else{
								window.close();
							}
						});
						return false;
					}
					$Controller.bes.oc.suspendorresume.initSubscriber($Gadget,$Page,$UI);
				}
				
			},$Gadget);
		},
		
		// AR.AD. InternationalBusi.001
		// 判断OM返回停复机场景中是否存在S3类型，若存在，则构造S4类型场景。（OM侧，S3和S4为相同处理接口。）
		injectSuspandData : function($Gadegt){
			debugger;
			// 组装数据 Temporary Suspension
			var cloneData;
			
			$.each($Gadegt.data.suspendOrResumeData.suspendOrResumeTypePOJOList, function(idx, element){
				if (element.actionType == 'S' && element.actionScene == '3'){
					cloneData = angular.copy(element);
					return false;
				}
			});
			
			if (cloneData){
				cloneData.actionTypeSceneKey = "S4";
				cloneData.actionTypeSceneValue = $UEE.i18n("ad.person.typeSus.TemporarySuspension");				
				$Gadegt.data.suspendOrResumeData.suspendOrResumeTypePOJOList.push(cloneData);
			}
		},
					
		querySubscriberinfo : function($Gadget, $Page, $UI){
			debugger;
			$Fire({
			    "service": "/bes.oc.provide.querysessionserviceboservice/getsubscriberinfo",
			    "target": "$Gadget.subscriberInfoPoint",
			    "onafter": function($Page, $Gadget, $UI) {
			    	debugger;
			    	if ($Gadget.subscriberInfoPoint){
			    		$Page.serviceAccountType = $Gadget.subscriberInfoPoint.serviceAccountType;
			    	}
			    }

			}, $Gadget);
		},
		
		// 初始化用户信息
		initSubscriber : function($Gadget, $Page, $UI) {
		    // 校验漫游权限 modify by tWX302759 start
		    debugger;
		    $Gadget.stopOpenTaskFlag=false;
		    $Gadget.stopOpenTaskEndDateFlag=false;
		    var params = [];
		    var resumeTypes = $Gadget.data.suspendOrResumeData.suspendOrResumeTypePOJOList || [];
		    //是否展示在执行的订单任务
		    var openStopsOrder=$Gadget.data.suspendOrResumeData.openStopsOrder;
		    if(openStopsOrder&&openStopsOrder.businessCode){
		    	$Gadget.stopOpenTaskFlag=true;
		    	$Gadget.stopOpenTask=openStopsOrder.businessCode;
		    
		    	$Gadget.startDate=openStopsOrder.beginDate;
		    	if(openStopsOrder.endDate){
		    		$Gadget.stopOpenTaskEndDateFlag=true;
		    	$Gadget.endDate=openStopsOrder.endDate;
		    	}
		    }
		    for ( var i = 0; i < resumeTypes.length; i++)
            {	
		        params[i] = {};
		        params[i].eventId = "BizRoamEvent";
		        params[i].seniorId = "BizRoamEntrance";
		        if (resumeTypes[i].actionTypeSceneKey == 'R1') {
		            params[i].businessType = "OpenSubsQZ";
                } else if (resumeTypes[i].actionTypeSceneKey == "R3") {
                    params[i].businessType = "OpenSubs";
                } else if (resumeTypes[i].actionTypeSceneKey == 'S1') {
                    params[i].businessType = "StopSubsQZ";
                } else if (resumeTypes[i].actionTypeSceneKey == 'S3') {
                    params[i].businessType = "StopSubs";
                } else if (resumeTypes[i].actionTypeSceneKey == 'S2') {
                    params[i].businessType = "StopSubsBT";
                } else if (resumeTypes[i].actionTypeSceneKey == "S4") {
                    params[i].businessType = "OpenSubs";
                } else {
                    params[i].businessType = "OpenSubsQYW";
                }
            }
		   
			
		    $Gadget.$Get('$Fire')
            ({
                service: '/bes.agentdesktop.placesauth.placesbusiauthservice/busiValidate',
                params: {"header":{},"body":{'busiAuths':params}},
                target : "$Gadget.busiValidateResp",
                onafter : function ($Gadget,$Page,$UI)
                {
                    debugger;
                    if($Gadget.busiValidateResp && $Gadget.busiValidateResp.body)
                    {
                        var resp = $Gadget.busiValidateResp.body;
                        var hasAuth = true;
                        var message;
                        if(resp.busiValidateResult)
                        {
                            //是否校验了 鉴权业务
                            for ( var i = 0; i < resp.busiValidateResult.length; i++)
                            {
                                if(resp.busiValidateResult[i].validateItemId == "201501202037000001" && resp.busiValidateResult[i].validateResult == false)
                                {
                                    message = resp.busiValidateResult[i].promptMessage;
                                    hasAuth = false;
                                }
                            }
                        }
                         
                        if(resp.retCode > 0 && !hasAuth)
                        {
                            $UI.msgbox.info($UEE.i18n("ad.person.message.information"), message, function(){
                                var menuid = $(document).scope().$Page.menuId;
                                _ysp_top.window.$BES.$Portal.tabpanel.closeTabItem(menuid);
                            });
                        }else{
                            //校验通过走下面的流程
                            debugger;
                            $Gadget.data.createOrderInfo = {};
                            dropListActionType = new UCD.Droplist($("#stopContinueType"), []);
                            dropListActionType.init(); // 必须使用初始化函数

                            dropListReason = new UCD.Droplist($("#stopContinueReson"), []);
                            dropListReason.init();
                            
                            if (!$Gadget.data.suspendOrResumeData) {
                                $UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.queryingUserFailed"));

                                return false;
                            }
                            $Controller.bes.oc.suspendorresume.initSuspendOrResumeType($Gadget,$Page);
                        }
                    } 
                }
                    
            },$Gadget);
		    $Page.businessCode = "SuspendOrResume";
		    // 校验漫游权限 modify by tWX302759 end
		    $Controller.bes.oc.suspendorresume.querySubscriberinfo($Gadget, $Page, $UI);
		},
		//查询权限.
		queryPermission: function($Gadget,func){
			$Fire = $Gadget.$Get("$Fire");
			try {
				OC.Callchain.setFireSearch($Gadget.$Page.pageId, OC.Callchain.getInitFireId());
			} catch (e) {
			}	
			$Fire({
				service : "/ucec/v1/offering/check_accountinfo_byname",
			    params : {
			        "header" : null,
			        "body" : {
			         "chargeInfoName" : "60131002501"
			        }
			    },
				target : "$Gadget.querypermission",
				onafter : function() {
					debugger;
					if (typeof func == "function") {
						func();
					}
				}
			}, $Gadget);
		},
		// 初始化停开机类型
		initSuspendOrResumeType: function($Gadget,$Page) {
			debugger;
			$Gadget.data.suspendOrResumeType = $Gadget.data.suspendOrResumeData.suspendOrResumeTypePOJOList || [];
			//有权限才显示强制全开。
			var dropListData_actionType = [];
			this.queryPermission($Gadget, function(){
				for (var i = 0; i < $Gadget.data.suspendOrResumeType.length; i++) {
					var obj = {};
					obj.value = $Gadget.data.suspendOrResumeType[i].actionTypeSceneValue;
					obj.key = $Gadget.data.suspendOrResumeType[i].actionTypeSceneKey;
					
					if (i == 0) {
						obj.selected = true;
					}
					//返回值是true，强制全开
					if ($Gadget.querypermission
							&& $Gadget.querypermission.body
							&& !$Gadget.querypermission.body.checkFlag
							&& obj.key == "R10") {
						continue;
					} else {
						dropListData_actionType.push(obj);
					}
				}
				$Gadget.data.selectedActionType = $Gadget.data.suspendOrResumeType[0];
				
				dropListActionType.setData(dropListData_actionType);
				dropListActionType.init(); // 必须使用初始化函数
			
			});
			
			
			// 页面初始化的时候只有主动开机，才存在发送短信功能。其他类型前台不展示勾选框。
//			messageService = new UCD.Checkbox($("#isNeedMessage"), $UEE.i18n("ad.person.message.SendSMS")).check();
			var selectedTypeKeyInit = dropListActionType.$input.attr('key');
			//判断是否展示预约时间
			var showExtMap={};
			for(var i=0;i<$Gadget.SusResumeDict.length;i++){
				if(selectedTypeKeyInit==$Gadget.SusResumeDict[i].itemCode){
					showExtMap=$Gadget.SusResumeDict[i].extMap;
				}
			}
			if(selectedTypeKeyInit&&selectedTypeKeyInit.substring(0,1)=="R"){
				$Gadget.ReservedTimeFlag=true;
				$Gadget.stopOpenReservedEndTimeFlag=false;
			}
			if(selectedTypeKeyInit&&selectedTypeKeyInit.substring(0,1)=="S"){
				$Gadget.ReservedTimeFlag=true;
				$Gadget.stopOpenReservedEndTimeFlag=true;
			}
				
			if ("R3" != selectedTypeKeyInit) {
				$("#isNeedMessage").hide();
			} else {
				$("#isNeedMessage").show();
			}
			//BUG初始化备注和经办人信息是否可选或必填设置 230437			
			$Controller.bes.oc.suspendorresume.initFitRemarkAndOperator($Page,selectedTypeKeyInit);
			$Gadget.ReservedTimeFlag=false;
			$Gadget.stopOpenReservedEndTimeFlag=false;
			$Gadget.showAutoResumptionTimeFlag = false;
			dropListActionType
				.setOnValueChange(function() {
					debugger;
					var selectedTypeKey = dropListActionType.$input.attr('key');
					$Gadget.ReservedTimeFlag=false;
					$Gadget.stopOpenReservedEndTimeFlag=false;
					$Gadget.showAutoResumptionTimeFlag = false;
					//选择临时停机时做的事
					if(selectedTypeKey=='S4'){ // S4为前台构造的下拉列表展示数据字典项。[AR.AD. InternationalBusi.001]
						//提交订单时传入的自动复机时间（毫秒数）
						$Gadget.autoResumptionMilliSecond = $Page.TimeUtil.localNowDateFirstSecond+(parseInt($Page.autoResumptionDays)+1)*24*60*60*1000;
						//页面展示的自动复机时间（格式：2016-07-11 00:00:00）
						$Gadget.autoResumptionTime = $(document).scope().$Get('$filter')('tz')($Gadget.autoResumptionMilliSecond, $Page.tzDateTime);						
						//将判断是否展示自动复机时间的标志置为true
						$Gadget.showAutoResumptionTimeFlag = true;
					}
					//判断是否展示预约时间
					for(var i=0;i<$Gadget.SusResumeDict.length;i++){
						if(selectedTypeKey==$Gadget.SusResumeDict[i].itemCode){
							showExtMap=$Gadget.SusResumeDict[i].extMap;
						}
					}
					if(selectedTypeKey&&showExtMap.ext1=="1"){
						$Gadget.ReservedTimeFlag=true;
						$Gadget.stopOpenReservedEndTimeFlag=false;
					}
					if(selectedTypeKey&&showExtMap.ext1=="0"){
						$Gadget.ReservedTimeFlag=true;
						$Gadget.stopOpenReservedEndTimeFlag=true;
					}

					//只有主动开机，才存在发送短信功能。其他类型前台不展示勾选框。
					if ("R3" != selectedTypeKey) {
						$("#isNeedMessage").hide();
					} else {
						$("#isNeedMessage").show();
					}

						//BUG初始化备注和经办人信息是否可选或必填设置 230437			
						$Controller.bes.oc.suspendorresume.initFitRemarkAndOperator($Page,selectedTypeKey);
					for (var j = 0; j < $Gadget.data.suspendOrResumeType.length; j++) {
						if (selectedTypeKey == $Gadget.data.suspendOrResumeType[j].actionTypeSceneKey) {
							$Gadget.data.selectedActionType = $Gadget.data.suspendOrResumeType[j];
							break;
						}
					}
					$Gadget.$Emit('$OC.queryReason', {});
				});

			$Gadget.data.suspendOrResumeReason = $Gadget.data.suspendOrResumeData.suspendOrResumeReasonPOJOList;			
			this.initSuspendOrResumeReason($Gadget);
		},
		
		//初始化设置备注和经办人信息是否必填 230437
		initFitRemarkAndOperator: function ($Page,selectedTypeKey)
		{
			$Page.essentialRemarkInfo = false;
			//备注设置-强制停机、强制开机、强制全开 必填
			if ('S1' == selectedTypeKey || 'R1' == selectedTypeKey || 'R10' == selectedTypeKey)
			{
				$Page.essentialRemarkInfo = true;
			}
			else
			{
				$Page.essentialRemarkInfo = false;
			}
			
			//经办人设置-主动停机必填  其他可选
			$Page.suspensionFlag = false;
			var $operatorGadget = adutil.getGadgetObj($(".bes-ad-operator"));
			if (('S4' == selectedTypeKey || 'S3' == selectedTypeKey) && $operatorGadget)
			{
				//经办人不能为空
				$operatorGadget.operatorInfoShowFlag = true;
				$Page.approveEmptyFlag = false;
				//必填标志-姓名
				$Page.essentialOperatorName = true;
				//必填标志-联系方式
				$Page.essentialOperatorphoneNumber = true;
	            //$Page.suspensionFlag主动停机，需要校验经办人信息必填DTS2017113013983
                $Page.suspensionFlag = true;
			}
			else
			{
				$operatorGadget.operatorInfoShowFlag = false;
				$Page.approveEmptyFlag = true;
				$Page.essentialOperatorName = false;
				$Page.essentialOperatorphoneNumber = false;
			}
		},	
		
		initSuspendOrResumeReason: function($Gadget) {
			debugger;
			var dropListDemoData_sexReason = [];

			for (var i = 0; i < $Gadget.data.suspendOrResumeReason.length; i++) {
				var obj = {};

				obj.value = $Gadget.data.suspendOrResumeReason[i].reasonValue;
				obj.key = $Gadget.data.suspendOrResumeReason[i].reasonKey;

				if (i == 0) {
					obj.selected = true;
				}

				dropListDemoData_sexReason.push(obj);
			}

			if (dropListDemoData_sexReason.length > 0) {
				dropListReason.setData(dropListDemoData_sexReason);
				dropListReason.init(); // 必须使用初始化函数
			} else {
				dropListReason.setData(dropListDemoData_sexReason);
				dropListReason.init(); // 必须使用初始化函数
				dropListReason.$input.val('');
				dropListReason.$input.attr('key', '');
			}

		},

		// 备注信息校验
		checkRemark: function($Page,$Gadget,$UI) {
			debugger;
			$Gadget.data = $Gadget.data || {};
			$Gadget.data.remark = $.trim($("#suspendOrResumeRemarkId").val());
			var len = $Gadget.data.remark.len();
			
			//增加非空校验 230437
			if ($Page.essentialRemarkInfo && 0 == len)
			{
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EnterRemarks"));
				return false;
			}
			
			// 1.检查安全性
			if (!adutil.checkInputdata($Gadget.data.remark)) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.hasInvalidCharacters"));
				return false;
			}
			// 2.检查长度
			if (len > 300) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.InputTooLong"));
				return false;
			}
			return true;

		},
		
		currentordervalidate : function($Gadget, $Page, $UI)
		{
			//如果是CSP，IVR验证
			if ($Controller.bes.ad.csp.common.isCsp())
			{
				//先判断操作员是否具有110911令牌 有就不需要进行ivr验证
				$Gadget.$Get('$Fire')({
					service : "/ucec/v1/offering/check_accountinfo_byname",
					params : {
						"header" : null,
						"body" : {
						 "chargeInfoName" : "60131001527"
						}
					},
					target : "$Gadget.querypermission",
					onafter : function() {
						debugger;
						if($Gadget.querypermission && $Gadget.querypermission.body && $Gadget.querypermission.body.checkFlag ){
							$Controller.bes.oc.suspendorresume.realcurrentordervalidate($Gadget, $Page, $UI);
						}else{
							if($Controller.bes.ad.csp.common.ivrCheck($Controller.bes.ad.csp.common.getServNumber(), $Gadget.$Get('$UI')))
							{
								$Controller.bes.oc.suspendorresume.realcurrentordervalidate($Gadget, $Page, $UI);
							}else{
								return false;
							}
						}
					}
				}, $Gadget);
			}else
			{
				$Controller.bes.oc.suspendorresume.realcurrentordervalidate($Gadget, $Page, $UI);
			}
			
		},
		
		// 点击提交，校验当前订单  
		// add begin by y00227433 US-20150731104247-1746/US-20150731104247-1747/US-20150731104247-1748[OC]江苏移动已开发业务架构重构第一期--停复机(产品变更1)
		realcurrentordervalidate : function($Gadget, $Page, $UI){
			
			$Page.businessCode = "SuspendOrResume";
			
			// 订单校验前，页面校验
			
			if (!this.beforeCreateOrder($Gadget, $Page, $UI))
		    {
				return;
		    }
			
			$Gadget.data.createOrderInfo.startTime=$Gadget.ReservedStartTime;
			//当展示自动复机时间的标志为true时，表示选择了临时停机，此时入参endTime赋值为自动复机时间（毫秒数）		
			if($Gadget.showAutoResumptionTimeFlag){
				$Gadget.data.createOrderInfo.endTime = $Gadget.autoResumptionMilliSecond;
			}else{
				$Gadget.data.createOrderInfo.endTime=$Gadget.ReservedEndTime;
			}
			
			// 调接口，校验订单
			$Fire = $Gadget.$Get('$Fire');
			if($Page.diffLocated =='Y'){
				try {
					OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getEndFireId());	
				} catch (e) {
				}				
				$Fire({
					service:"bestootherboservice/suspendorresumeordersubmit",
					params:{
						header:{},
			            body : {suspendOrResumeOrderPOJO:$Gadget.data.createOrderInfo}
					},
					target:"$Page.order_resp",
					onafter:function(){
						debugger;
						$Controller.bes.oc.suspendorresume.gotoSucessFullPage($Gadget, $Page, $UI);
					}
				},$Gadget)
				
				return ;
			}
			OC.Callchain.setFireSearch($Page.pageId, "submitbt");			
			$Fire({
		        service : '/agentdesktop/v1/person/suspendorresumebusivalidate',
		        params:{
		        	header:{},
		            body : {suspendOrResumeOrderPOJO:$Gadget.data.createOrderInfo}
		        },
		        target : '$Gadget.data.busiValidateResponse',
		        onafter : function($Gadget,$Page,$UI){
					debugger;
					if (!$Gadget.data.busiValidateResponse) {
						youCanTouchDataOfWholePage();
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SystemError"));
						$Gadget.createOrderFlag = undefined;
						return;
					}
					
					var $Page = $(document).scope().$Page;
		        	var result = ($Gadget.data.busiValidateResponse||{}).body;
		        	OC.Comm.checkBusiValidResp($Gadget, $UI, result, null, function(){
		        		debugger;
		        		$Page.serialNo = result.serialNo;
		        		$Gadget.createOrderFlag = undefined;
		        		$Controller.bes.oc.suspendorresume.ordersubmit($Gadget,$Page,$UI);
		        		//$Gadget.$Emit('$OC.busiValidate.sucess', {});
		        	}, function(){
		        		return false;
		            }, false
					,function(){
		        		return false;
		            });
					$Gadget.createOrderFlag = undefined;
		        }
			},$Gadget);
		},
		// add end by y00227433 US-20150731104247-1746/US-20150731104247-1747/US-20150731104247-1748[OC]江苏移动已开发业务架构重构第一期--停复机(产品变更1)

		// 校验前
		beforeCreateOrder: function($Gadget, $Page, $UI) {
			debugger;
			
			if (false == $Gadget.createOrderFlag) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.NotSubmitOrderRepeatedly"));
				return false;
			}
			
			// US-20180505154332-2031088280
	        /*if ($Page.noFillSMSFlag){
	        	var smsNetTypeFlag = false;
	        	$.each($Page.smsNetTypeList ||[],function(i,val){
        			if ($Page.serviceAccountType && val.itemCode && val.itemCode == $Page.serviceAccountType){
        				smsNetTypeFlag = true;
        			}
        		});
	        	if (smsNetTypeFlag){
	        		$UI.msgbox.error("提示", "非GSM用户，不容许发送免填单短信");
	        		return false;
	        	}
	        }*/

			//校验预约时间
			$Gadget.tempStartTime=$Gadget.ReservedStartTime+60*1000;
			if($Gadget.tempStartTime<$Page.TimeUtil.nowDate)
				{
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.sr.message.KSSJBXDYDQSJ"));
				return false;
				}
			
			if($Gadget.ReservedEndTime<=$Gadget.ReservedStartTime)
			{
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.EarlierEndTime"));
			return false;
			}
			// TODO 检查经办人信息有效性
			var flag = $Controller.bes.oc.operator.checkOperatorInfoBeforeSubmit($Page, $UI);

			flag = flag && this.checkRemark($Page,$Gadget, $UI);

			if (!flag) {
				return false;
			}

			if (!$Gadget.data.selectedActionType) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SelectSuspensionresumptionType"));
				return false;
			}
			$Gadget.data.createOrderInfo.actionType = $Gadget.data.selectedActionType.actionType;
			$Gadget.data.createOrderInfo.traceFlag = $Page.traceFlag;
			$Gadget.data.createOrderInfo.traceId = $Page.traceId;

			// 设置businessCode
			if ($Gadget.data.selectedActionType.actionTypeSceneKey == 'R1') {
				$Gadget.data.createOrderInfo.businessCode = "OpenSubsQZ";
			} else if ($Gadget.data.selectedActionType.actionTypeSceneKey == "R3") {
				$Gadget.data.createOrderInfo.businessCode = "OpenSubs";
			} else if ($Gadget.data.selectedActionType.actionTypeSceneKey == 'S1') {
				$Gadget.data.createOrderInfo.businessCode = "StopSubsQZ";
			} else if ($Gadget.data.selectedActionType.actionTypeSceneKey == 'S3') {
				$Gadget.data.createOrderInfo.businessCode = "StopSubs";
			} else if ($Gadget.data.selectedActionType.actionTypeSceneKey == 'S2') {
				$Gadget.data.createOrderInfo.businessCode ="StopSubsBT";
            } else if ($Gadget.data.selectedActionType.actionTypeSceneKey == 'S4') {
				$Gadget.data.createOrderInfo.businessCode = "StopSubs";
			} else {
				$Gadget.data.createOrderInfo.businessCode = "OpenSubsQYW";
			}

			$Gadget.data.createOrderInfo.actionScence = $Gadget.data.selectedActionType.actionScene;
			$Gadget.data.createOrderInfo.actionReason = dropListReason.$input.attr('key');
			
			if ('notuse' == $Gadget.data.createOrderInfo.actionReason) {
				$Gadget.data.createOrderInfo.actionReason = "";
			}

			//MODIFY 2015-06-27只有主动开机，才存在发送短信功能。其他类型默认传N
			if ("R3" == $Gadget.data.selectedActionType.actionTypeSceneKey) {
//				var isNeedMessage = $("#isNeedMessage").find("input")[0].checked;
				if ($Gadget.isNeedMessage = "1"){
					$Gadget.data.createOrderInfo.isNeedSms = "Y";
				} else {
					$Gadget.data.createOrderInfo.isNeedSms = "N";
				}
			} 
			//如果是主动停机，发送短信
			else if ("S3" == $Gadget.data.selectedActionType.actionTypeSceneKey)
			{
				$Gadget.data.createOrderInfo.isNeedSms = "Y";
			}
			else {
					$Gadget.data.createOrderInfo.isNeedSms = "N";
			}


			$Gadget.data.createOrderInfo.operatorInfo = $Page.operatorInfo;
			
			if($Page.noFillSMSFlag){
				$Gadget.data.createOrderInfo.operatorInfo.noFillSMSFlag = 'Y';
			}else{
				$Gadget.data.createOrderInfo.operatorInfo.noFillSMSFlag = 'N';
			}
			
			// MODIFY 2015-11-17 by l00289267 modify reason:停开机备注字段传入报文。
			$Gadget.data.createOrderInfo.remark = $Gadget.data.remark || "";
			$Gadget.createOrderFlag = false;
			return true;
		},

		ordersubmit: function($Gadget,$Page,$UI){
			// 订单校验前，页面校验
			if (!this.beforeCreateOrder($Gadget, $Page, $UI))
		    {
				return;
		    }
			// 调接口，组装订单
			dontTouchDataOfWholePage();
			if(_ysp_top.TabSet){
				var currMenuId = _ysp_top.TabSet.getTabItem().key
			}
			$Fire = $Gadget.$Get('$Fire');
			OC.Callchain.setFireSearch($Page.pageId, OC.Callchain.getEndFireId());		
			$Fire({
		        service : '/ucec/v1/order/order_submit',
		        params:{
		        	header:{},
		            body : {
		            	serialNo:$Page.serialNo,
		            	extInfo:{
		            		currentMenuId:currMenuId
		            	}
		            }
		        },
		        target : '$Page.order_resp',
		        onafter : function($Gadget,$Page,$UI){
					debugger;
					$Controller.bes.oc.suspendorresume.gotoSucessFullPage($Gadget, $Page, $UI);
		        },
				onerror : function()
				{
					youCanTouchDataOfWholePage();
				}
			},$Gadget);
		},

		gotoSucessFullPage: function($Gadget, $Page, $UI) {
			debugger;
			// 返回结果：$Gadget.data.createOrderResponse
			$Gadget.createOrderFlag = true;

			if (!$Page.order_resp) {
				$UI.msgbox.info($UEE.i18n("ad.person.message.information"), $UEE.i18n("ad.person.message.SystemError"));
				return;
			}
			
			debugger;
			youCanTouchDataOfWholePage();
			// 组装失败信息
			$Page.errorMsg = $UEE.i18n("ad.person.message.information");
			if ($Page.order_resp.header && $Page.order_resp.header.resultCode != "0")
			{
				$Page.errorMsg = $Page.order_resp.header.resultMessage;
			}
			else if ($Page.order_resp.body && $Page.order_resp.body.retCode != "0") 
			{
				var message;
				if($Page.order_resp.busiValidResults){
					var messageCount=0;						
					var len = $Page.order_resp.busiValidResults.length;
					for ( var i = 0; i < len; i++) {
						var validResp = busiValidResp.busiValidResults[i];
						if(validResp.promptMessage){
							var temp =  validResp.promptMessage;
							if(messageCount == 0){
								message = temp;
							}else{
								message += "\n"+ temp;
							}
							messageCount++;
						}
					}
				}

				if(!message){
					$Page.errorMsg = $Page.order_resp.body.retMessage || $Page.errorMsg;
				}else{
					$Page.errorMsg = message;
				}
				
			}
			
			///:huangyuyuan add 2016-08-26 增加处理，设置手机号码，防止成功页面手机号码不显示
			if ($Page.order_resp.body)
			{
				//手机号码为空，则设置手机号码
				if ((null == $Page.order_resp.body.phoneNumber) || ("" == $Page.order_resp.body.phoneNumber))
				{
					//设置手机号码
					$Page.order_resp.body.phoneNumber = $Page.phonenum;
				}
			}
			///:~
			
			$Page.paymentFinishStepFlagOfPromotion=true;
			$("#suspendorresume").hide();
			$("#paymentFinishStep").show();
			$("body").scrollTop(0);
		},
		subloginSuccess:function($Page,$Gadget){
			debugger;
			$("#orderauthentication").hide();
			$("#suspendorresume").show();
			$Gadget.$Emit("$OC.Suspendorresume");
		},
		
		//查询BOSS预付费或后付费接口是否隔离
		isBossIntfSolated : function($Page,$Gadget){
			debugger;
			var currMenuId = null
			if(_ysp_top.TabSet){
				currMenuId = _ysp_top.TabSet.getTabItem().key
			}
			$Fire = $Gadget.$Get('$Fire');
			$Fire({
		        service : '/isolatebossintfservice/isBossIntfListIsolated_query',
		        params:{
		        	menuId : currMenuId
		        },
		        target : '$Gadget.BossIntfIsolateResp',
		        onafter : function($Gadget,$Page){
					debugger;
					$Gadget.BossIntfIsolateResp = $Gadget.BossIntfIsolateResp || {}
					if($Gadget.BossIntfIsolateResp.bossIntfIsolateList && $Gadget.BossIntfIsolateResp.bossIntfIsolateList.length > 0){

						var isHaveIsolated = false;
						for(var i=0;i<$Gadget.BossIntfIsolateResp.bossIntfIsolateList.length;i++){
							var bossIntfIsolated = $Gadget.BossIntfIsolateResp.bossIntfIsolateList[i];
							if(bossIntfIsolated.isolated == '1'){
								isHaveIsolated = true;
								break;
							}
						}
						if(isHaveIsolated){
							$Gadget.$Get('$UI').msgbox.confirm($UEE.i18n('ad.sr.message.TS'),"因系统问题，目前无法查询用户欠费信息，请确认是否继续办理。",
									function(){
									debugger;
									//确定按钮继续操作业务
									return;
								},
								function(){
									//取消按钮 关闭当前页面
									debugger;
									if (_ysp_top.publicObject) {
										Close_tabSet();
									}
									else{
										window.close();
									}
								});
						}
					}
				}
			},$Gadget);
		},
		
		//获取自动复机天数（临时停机到自动复机的间隔天数,不包含临时停机当天）的系统参数
		getAutoResumptionDays : function($Page,$Gadget)
		{
			debugger;
			$Fire = $Gadget.$Get('$Fire');
			$Fire({
				service : 'ucec/v1/common/qrysystemparambykey',
				params : {
					key : "OC.AutoResumptionDays"
				},
				target : "$Gadget.autoResumptionDays",
				onafter : function($Gadget) {
					debugger;
					$Page.autoResumptionDays = $Gadget.autoResumptionDays;
				}
			}, $Gadget);
		},
        
		onLoginSuccess:function($Gadget, $Fire, $UI) {
			debugger;
            
            if (!$Controller.bes.ad.csp.common.isCsp())
            {
                return;
            }
            
			$("#orderauthentication").hide();
			$("#suspendorresume").show();
			$Gadget.$Emit("$OC.Suspendorresume");
		}		
});