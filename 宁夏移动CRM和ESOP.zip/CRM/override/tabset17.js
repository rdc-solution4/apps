/*
  功能：绑定Tab页根节点，在框架主工作区执行，绑定该区域并保存为top.publicObject["mainTab"]
  sOwnerId:tab页签的区域ID，在框架主工作区的一个DIV。
  fGetTabHeight:页签区域高度，忽略
  iTabWidth:页签区域宽度，忽略
  path:相对路径，忽略
  newWindowFlag:，忽略
  closeFlag:是否允许关闭该页签，忽略
 */
function TabSet(sOwnerId, fGetTabHeight, iTabWidth, path, newWindowFlag,
		closeFlag, tabStyle) {
}

TabSet.portalName = "BES";

var publicObject = {};

publicObject["mainTab"] = TabSet.prototype;

publicObject["openMenuById"] = function(menuId) {
	debugger;
	_ysp_top.openMenu(menuId);
};
try
{
	_ysp_top.publicObject["toggleSalesConsoleSpark"] = _ysp_top.toggleSalesConsoleSpark;
}
catch (e){}

/*
 * 功能：以数组形式存储每个Tab页配置
 */
function TabConfig(sTabCode, sTabName, sTabSrc, sTabIcon, oFlag) {
}

/**
 * 功能：打开Tab页 sTabCode Tab页编码 sTabName Tab页标题 sTabSrc 业务URL sTabIcon 图标，忽略 oFlag
 * 异步加载标识，忽略 showIconFlag 是否显示图标，忽略 area 打开区域，忽略 myPhoneNo 手机号码，忽略 needAuth
 * 是否鉴权，忽略
 */
TabSet.prototype.appendTab = function(sTabCode, sTabName, sTabSrc, sTabIcon,
		oFlag, showIconFlag, area, myPhoneNo, needAuth) {
	TabSet.createTabItemByConf(sTabCode, sTabName, sTabSrc, sTabCode);
};

/**
 * 功能：关闭指定编码的Tab页 sTabCode Tab页编码 flag 关闭时是否提示
 */
TabSet.prototype.removeTabByCode = function(sTabCode, flag) {
	TabSet.closeTabItem(sTabCode);
};

/**
 * 功能：关闭当前Tab页
 */
TabSet.prototype.closeCurrentTab = function() {
	TabSet.closeTabItem();
};

/**
 * 功能：使用指定URL刷新当前Tab页，如果URL为空则使用当前URL刷新
 */
TabSet.prototype.refreshCurrentTab = function(url) {
	var innerId = TabSet.prototype.getSubSelectedTabCode();
	if (undefined == innerId) {
		return;
	}
	TabSet.prototype.refresh(innerId, url);
};

/**
 * 功能：使用指定URL刷新指定Tab页，如果URL为空则使用当前URL刷新
 */
TabSet.prototype.refresh = function(sTabCode, sTabSrc) {
	var div = $('.tabcontainer').filter('[innerid="' + sTabCode + '"]');
	if (undefined == sTabSrc || null == sTabSrc || '' == sTabSrc) {
		var li = $('li').filter('[innerid="' + sTabCode + '"]');
		sTabSrc = li.data('destUrl');
	}
	sTabSrc = _ysp_top.convertSecondaryDomain(sTabSrc);
	div.children('iframe').attr('src', sTabSrc);
}

// 获取客户页签中当前打开的页签，直接返回当前页签编码即可
TabSet.prototype.getSubSelectedTabCode = function() {
	return tab.selectedItem().attr('innerid');
};

// 判断tab页是否已经打开
TabSet.prototype.hasTab = function(tabId) {
	var li = $('li').filter('[innerid="' + tabId + '"]');
	return li.length > 0;
};

// 菜单打开事件，id必须提供
function openMenuFun(menuId, name, url, https) {
	TabSet.createTabItemByConf(menuId, name, url, menuId, https);
}

TabSet.addShortCut = function(menuId, menuName, menuUrl, menuImg, httpsFlag,
		openMode, tabType) {
	var msg = {
		operation : "Add_ShortCut",
		menuId : menuId,
		menuName : menuName,
		menuUrl : menuUrl,
		menuImg : menuImg,
		httpsFlag : httpsFlag,
		openMode : openMode,
		tabType : tabType
	};

	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};

TabSet.closeAllTabItemExceptOne = function(tabId) {
	var msg = {
		operation : "Tab_CloseAll_ExceptOne",
		tabId : tabId
	};
	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};

TabSet.closeAllTabItem = function() {
	var msg = {
		operation : "Tab_CloseAll",
	};
	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};

TabSet.closeTabItem = function(tabId) {
	var msg = {
		operation : "Tab_Close",
		tabId : tabId
	};
	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};

TabSet.showTabItem = function(tabId) {
	var msg = {
		operation : "Tab_Show",
		tabId : tabId
	};

	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};


TabSet.hideTabItem = function(tabId) {
	var msg = {
		operation : "Tab_Hide",
		tabId : tabId
	};

	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};

TabSet.getTabItem = function(innerId) {
	var li = tab.selectedItem();
	if (!innerId) {
		innerId = li.attr('innerId');
	} else {
		li = _ysp_top.tab.findLiExist(innerId);
	}
	var page = $('.tabcontainer').filter('[innerid="' + innerId + '"]')[0];
	if (!page) {
		return {};
	}
	var ifr = $(page).children()[0];
	var url = $(ifr).attr('src');
	var title = li.attr('title');
	var tabItem = {
		key : innerId,
		title : title,
		url : url
	};
	return tabItem;
};

TabSet.getAllTabItems = function() {
	var lis = tab.getAllTabs();
	var tabItems = new Array();
	for ( var index = 0; index < lis.length; index++) {
		var li = $(lis[index]);
		var innerId = li.attr('innerId');
		var page = $('.tabcontainer').filter('[innerid="' + innerId + '"]')[0];
		var ifr = $(page).children()[0];
		var url = $(ifr).attr('src');
		var title = li.attr('title');
		var tabItem = {
			key : innerId,
			title : title,
			url : url
		};
		tabItems.push(tabItem);
	}
	return tabItems;
};

TabSet.createTabItem = function(item) {
	if (typeof item != "object") {
		return false;
	}
	var msg = {
		operation : "Tab_Add",
		item : item
	};
	msg = JSON.stringify(msg);
	parent.postMessage(msg, "*");
};

TabSet.createTabItemByConf = function(id, title, url, pageid, httpsFlag,
		openMode, tabType) {
	if (!pageid) {
		pageid = id;
	}
	var item = {
		title : title,
		url : url,
		id : id,
		pageid : pageid,
		httpsFlag : httpsFlag,
		openMode : openMode,
		tabType : tabType
	};
	TabSet.createTabItem(item);
};

TabSet.refreshTabItem = function(id, title, url, httpsFlag) {
    // id不填，取当前选中的
    if (!id) {
    	id = TabSet.prototype.getSubSelectedTabCode();
    	if (!id) {
    		// 当前没选中的，返回
    		return;
    	}
    }

	var div = $('.tabcontainer').filter('[innerid="' + id + '"]');
	
	// 传入的di不存在，返回
	if (!div) {
		return;
	}

	// 传入的di不存在，返回
	var li = $('li').filter('[innerid="' + id + '"]');
	if (!li) {
		return;
	}
	
	// 传入title不为空，则修改
	if (title) {
		var span = li.children('.tab-title').children();
		span.html(title);
		li.attr('title', title);
	}
	
	// 传入url为空，则取当前的url
	if (!url) {
		url = li.data('destUrl');
	}
	
	url = _ysp_top.convertSecondaryDomain(url);

	url = _ysp_top.convertSecondaryDomain(url);
	
	// 增加打开菜单的参数
	url = _ysp_top.addParamsToUrl(url);
	
	// 增加UEE的版本号
	url = _ysp_top.addUEEVersionToUrl(url);
	
	if (!httpsFlag) {
		httpsFlag = false;
	} else {
		httpsFlag = true;
	}
	
	url = _ysp_top.formatUrl(url, httpsFlag)
	
	// 强制刷新
	div.children('iframe').attr('src', url);
};




if (window.location.protocol == "http:") {
	if (_ysp_top.publicObject["openMenu"]) {
	} else {
		_ysp_top.publicObject["openMenu"] = openMenuFun;
	}
}
