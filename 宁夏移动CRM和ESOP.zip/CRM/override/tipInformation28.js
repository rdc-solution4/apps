//操作员登陆系统提示信息框隐藏
;
$(document).ready(function(){
	setTimeout("hidenTipInformation()",10000);
});

function hidenTipInformation(){
	debugger;
	$('#tip_footdiv').hide();
}

function tipHelper(){
	this.initTip = function($Scope){
		var $Fire = $Scope.$Get('$Fire');
		var $Model = $Scope.$Model;
		$Fire({
			service : "/smtipinformation/queryLastLoginTip",
			target : "$Model.tipHelperInformation"
		},$Scope).onafter(function(){
			$('#tip_footdiv').show();
			
			if(!$Model.tipHelperInformation.tipInformation){
				$Model.tipHelperInformation.tipInformation = $UEE.i18n('SM.LOGIN.TIPS.WELCOME');
			}
			
			switch($Model.tipHelperInformation.lastSuccessFlag){
			case "Y":
				$Model.tipHelperInformation.lastLoginInformation = $UEE.i18n('SM.LOGIN.TIPS.LOGINSUCCESS');
				
				break;
			case "N":
				$Model.tipHelperInformation.lastLoginInformation = $UEE.i18n('SM.LOGIN.TIPS.LOGINFAILED');
				break;
			default:
				
				$Model.tipHelperInformation.lastLoginInformation = $UEE.i18n('SM.LOGIN.TIPS.FIRSTLOGINSYSTEM');
			break;
				
			}
			//首次登陆系统时间设置为undefined
			if($Model.tipHelperInformation.lastLoginTime == 0){
				$Model.tipHelperInformation.lastLoginTime = undefined;
			}
			
		});
	}
}

var tipHelp = new tipHelper();