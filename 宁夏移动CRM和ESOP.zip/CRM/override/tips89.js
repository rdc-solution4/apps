//提示消息类 
var tips = { 

temp : {}, 
handle: {},
/*** 
* 弹出提示 
* 
* @param string msg 提示文字内容 
* @param string id 要弹出提示的目标对象的id
* @param string path 用来定位图片位置
* @param string post 提示框相对于事件源的位置(左右上下)
* @param int width 提示窗宽度,默认300
* @param int time 定时消失时间毫秒数,如果为null/0/false则不定时 
*/ 
show : function(msg,id,path,post,width,time) 
{ 
   var target = this._get(id); 
   
   //如果弹出过则移除重新弹出 
   tips.hidden(id)
   //清除定时器对象 
   if(this.handle[id]!=undefined)
   { 
	   clearTimeout(this.handle[id]);
   }
   //设置默认值 
   msg = msg || 'error'; 
   post = post || 'right';
   width = width || 200; 
   time = time ? parseInt(time) : false; 
   path = path||'../';
   
   //获取对象坐标信息 
   for(var y=0,x=0; target!=null; y+=target.offsetTop, x+=target.offsetLeft, target=target.offsetParent); 
   var textAlign = 'left'; 
   var fontSize = '12';
   var fontWeight = 'normal';
   
   //create tips Div
   var tipsDiv = this._create
  (
    {
   	 display:'block',
  	 position:'absolute',
  	 zIndex:'1001',
  	 width:(width-2)+'px',
     border: '1px solid #ff9a3b', 
  	 padding:'5px 12px',
  	 fontSize:fontSize+'px',
  	 textAlign:textAlign,
  	 fontWeight:fontWeight 
  	},
  	{  id:id+'_tips', 
  	   innerHTML:msg , 
  	   onclick:function(){tips.hidden(id);}
    }
  );
  
  //create arrowhead Div
  var bdiv= this._create
  (
    {	
      position: 'absolute',      
      width: '19px',   
      height:'19px' 
  	 },
  	 {     
  	 	id:id+'bspan'
     }
  ) ;
  
  tipsDiv.appendChild(bdiv);
  
  //弹出提示 
  document.body.appendChild(tipsDiv);
 
  if(post == '_ysp_top')
  {
  	  tipsDiv.style.left = (x+1)+'px'; 
  	  tipsDiv.style._ysp_top = (y-tipsDiv.offsetHeight-12)+'px';
  	  bdiv.style.left = (tipsDiv.offsetWidth)/5 + 'px';
  	  bdiv.style._ysp_top = tipsDiv.offsetHeight-2+'px';
	 tipsDiv.style.background= '#FFF9F5';
	 bdiv.innerHTML=this._downstyle();
	
	 
  }else if(post == 'bottom')
  {
  	 tipsDiv.style.left = (x+1)+'px'; 
  	 tipsDiv.style._ysp_top = (y+this._get(id).offsetHeight+12)+'px'; 
  	 bdiv.style.left = (tipsDiv.offsetWidth)/5 + 'px';
  	 bdiv.style._ysp_top = -bdiv.offsetHeight +'px'
	tipsDiv.style.background= '#FFF9F5';
    bdiv.innerHTML=this._topstyle();
  }else if(post == 'right')
  { 
  	 tipsDiv.style.left = (x + this._get(id).offsetWidth + 8)+'px';
  	 tipsDiv.style._ysp_top = (y + this._get(id).offsetHeight/2 -tipsDiv.offsetHeight/2 - 5)+'px';
  	 bdiv.style.left = '-19px';
  	 bdiv.style._ysp_top = tipsDiv.offsetHeight/2 - bdiv.offsetHeight/2;
	tipsDiv.style.background= '#FFF9F5';
	bdiv.innerHTML=this._leftstyle();
  }else if(post == 'left')
  {
  	 tipsDiv.style.left = (x -tipsDiv.offsetWidth - 8)+'px'; 
  	 tipsDiv.style._ysp_top = (y + this._get(id).offsetHeight/2 -tipsDiv.offsetHeight/2 - 5)+'px';
  	 bdiv.style.left = tipsDiv.offsetWidth - 2 + 'px';
  	 bdiv.style._ysp_top = tipsDiv.offsetHeight/2 - bdiv.offsetHeight/2;
	tipsDiv.style.background= '#FFF9F5';
	
	bdiv.innerHTML=this._rightstyle();
  }
  
  //resolve bug: in IE6 pop menu can not cover SELECT TAG
  var divFrame = document.createElement('iframe');
  divFrame.id = id+'frame';
  divFrame.style.width = tipsDiv.offsetWidth; 
  divFrame.style.height = tipsDiv.offsetHeight;
  divFrame.style._ysp_top = tipsDiv.style._ysp_top; 
  divFrame.style.left = tipsDiv.style.left; 
  divFrame.style.zIndex = tipsDiv.style.zIndex - 1;
  divFrame.style.display = "block"; 
  divFrame.style.position = "absolute"; 
  //document.body.appendChild(divFrame);
  var bdivFrame = document.createElement('iframe');
  bdivFrame.id = id+'bframe';
  bdivFrame.style.width = bdiv.offsetWidth; 
  bdivFrame.style.height = bdiv.offsetHeight; 
  bdivFrame.style._ysp_top = bdiv.style._ysp_top; 
  bdivFrame.style.left = bdiv.style.left; 
  bdivFrame.style.zIndex = bdiv.style.zIndex - 1;
  bdivFrame.style.filter= 'alpha(opacity=0)';
  bdivFrame.style.position = "absolute";
  //tipsDiv.appendChild(bdivFrame);
  
  //标记已经弹出 
  this.temp[id] = id; 
  
  //如果定时关闭 
  if(time) 
  { 
  	this.handle[id] = setTimeout(function(){tips.hidden(id);}, time) 
  } 
  
  return id; 
},

/*** 
* 弹出会自动隐藏的提示
* 
* @param string msg 提示文字内容 
* @param string id 要弹出提示的目标对象的id
* @param string path 用来定位图片位置
* @param string post 提示框相对于事件源的位置(左右上下)
* @param int width 提示窗宽度,默认300
* @param int time 定时消失时间毫秒数,如果为null/0/false则不定时 
*/ 
autoHidden : function(msg,id,path,time,post,width) 
{ 
  //设置默认值 
   time = time || 3000; 
   this.show(msg,id,path,post,width,time);
},
 
/*** 
* 隐藏提示 
* 
* @param string id 要隐藏提示的id,如果要隐藏所有提示id为空即可 
*/ 
hidden : function(id) 
{ 

  if(!id) { for(var i in this.temp) { this.hidden(i); } return; } 
  var t = this._get(id+'_tips');
  if(t) 
  {
	  t.parentNode.removeChild(t);
  }
  
  var tf = this._get(id+'frame');
  if(tf) 
  {
  	 tf.parentNode.removeChild(tf);
  } 
},
 
_create : function(set, attr) 
{ 
  var obj = document.createElement('div'); 

  for(var i in set) {obj.style[i] = set[i]; } 
  for(var i in attr) { obj[i] = attr[i]; } 
  return obj; 
},
 
_get : function(id) 
{ 
	//modify begin wWX383380 2017-3-29 R005C20LG1601 OR_huawei_201703_295
	var ua = navigator.userAgent;
	if(ua.indexOf("MISE8.0")>0)
	{
		return document.getElementById(id);		
	}
	else
	{
		if(document.getElementById(id) != undefined)
		{
			return document.getElementById(id);			
		}
		else
		{
			return document.getElementsByName(id)[0];
		}
	}
	// modify end wWX383380 2017-3-29 R005C20LG1601 OR_huawei_201703_295
},
_leftstyle : function() 
{ 
 return  '<div style="border-color: transparent #ff9a3b  transparent transparent;border-style: solid;border-width:  6px 6px 6px 0px;font-size: 0;line-height: 0;width: 0;height: 0; position:relative; left:12px; _ysp_top:2px;_border-_ysp_top-color: white;_border-bottom-color: white;_filter: chroma( color =white);"></div>' ; 
}, 

_downstyle : function() 
{ 
 return  '<div style="border-color: transparent #ff9a3b  transparent transparent;border-style: solid;border-width:  0px 6px 6px 0px;font-size: 0;line-height: 0;width: 0;height: 0; position:relative; _ysp_top:1px; _border-_ysp_top-color: white;_border-bottom-color: white;_filter: chroma( color =white);"></div>'+'<div style="border-color: transparent  transparent transparent #ff9a3b; border-style: solid; border-width: 0px 0px 6px 6px; font-size: 0;line-height: 0;	width: 0; height: 0; position:relative; margin:-7px 0px 0px 6px;_border-_ysp_top-color: white;_border-bottom-color: white;_filter: chroma( color =white);"></div>';  
}, 

_topstyle : function() 
{ 
  return  '<div style="border-color: transparent  #ff9a3b transparent transparent;border-style:  solid;border-width: 6px 6px 0px 0px;font-size: 0;line-height: 0;width: 0;height: 0; position:relative; _ysp_top:12px; _border-_ysp_top-color: white;_border-bottom-color: white;_filter: chroma( color =white);"></div>'+'<div style="border-color: transparent  transparent transparent #ff9a3b; border-style: solid; border-width: 6px 0px 0px 6px; font-size: 0;line-height: 0; width: 0; height: 0; position:relative; margin:5px 0px 0px 6px;_border-_ysp_top-color: white;_border-bottom-color: white;_filter: chroma( color =white);"></div>'; 

}, 

_rightstyle : function() 
{ 
  return '<div style="border-color: transparent  transparent transparent #ff9a3b;border-style: solid;border-width: 6px 0px 6px 6px;font-size: 0;line-height: 0;width: 0;height: 0; position:relative; left:0px; _ysp_top:2px; _border-_ysp_top-color: white; _border-bottom-color: white;_filter: chroma( color =white);"></div>';  
} 





}; 

