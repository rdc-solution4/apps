var adtips={
    //通用订单校验返回是否成功,通用校验场景，出现的弹出框为error型和confirm型
    checkBusiValidResp : function($Gadget, $UI, busiValidResp,
				warningConfirmCb, warningCancelCb, errorCb, dialogTitle) {
		debugger;
		var wanConfirmCb = null // error级别校验成功，但是出现warning或者info级别的校验失败时，点击confirm弹出框的确定时的回调
		var wanCancelCb = null; // 出现warning级别校验失败时，点击confirm弹出框的cancel按钮或者点击右上角叉号时的回调
		var errCb = null; // error级别校验失败，关闭error弹出框的回调
		var fontList = [ "<font color='#333'>", "<font color='#333'>",
				"<font color='#333'>", "<font color='#EC4E5C'>" ];
		if ($Gadget.saleApply) {
			if (warningConfirmCb) {
				wanConfirmCb = function() {
					$Gadget.$safeApply($Gadget,warningConfirmCb);
				};
			}
	
			if (warningCancelCb) {
				wanCancelCb = function() {
					$Gadget.$safeApply($Gadget,warningCancelCb);
				};
			}
	
			if (errorCb) {
				errCb = function() {
					$Gadget.$safeApply($Gadget,errorCb);
				};
			}
		} else {
			wanConfirmCb = warningConfirmCb;
			wanCancelCb = warningCancelCb;
			errCb = errorCb;
		}
	
		if (!busiValidResp || !busiValidResp.returnMessage) {
			//"业务校验失败", "无响应报文。"
			$UI.msgbox.error($UEE.i18n("ad.person.message.FailedVerifyBusiness"), $UEE.i18n("ad.person.message.NoResponse"), errCb, errCb, errCb);
			return false;
		}
		var returnMessage = busiValidResp.returnMessage;
		$Gadget.traceId = returnMessage.traceId;
		dialogTitle = dialogTitle || $UEE.i18n("ad.person.message.information");
		var msgList = [];
		if (returnMessage.busiValidateResult) {
			for ( var i = 0; i < returnMessage.busiValidateResult.length; i++) {
				if (returnMessage.busiValidateResult[i].promptMessage) {
					msgList.push(returnMessage.busiValidateResult[i]);
				}
	//			if(returnMessage.busiValidateResult[i].level == '2' && !returnMessage.busiValidateResult[i].validateResult){
	//				returnMessage.retCode = "1";
	//			}
			}
		}
	
		if ("0" != returnMessage.retCode) { // 出现error级别错误时的弹出框
			if (msgList.length == 0) {
				//message = returnMessage.retMessage || "校验失败，无校验提示报文";
				message = $UEE.i18n('ad.person.message.SystemErrorLaterRetry');//"系统错误，请稍后重试";
				$UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
				return false;
			} 
			//$UI.msgbox.error(dialogTitle, message, errCb, errCb, errCb);
			//pc校验失败会继续处理   目前只处理互斥情况
			if(returnMessage.returnOffering && returnMessage.returnOffering.length>0 
					&&returnMessage.returnOffering[0].actionType=='D'){
			    var retOfferingType = returnMessage.returnOffering[0].offeringType;
			    //活动 档次 奖品 互斥不继续处理
			    if(retOfferingType =='3' || retOfferingType =='4'|| retOfferingType =='5'){
			        msgList[0].promptSuggestion = $UEE.i18n("ad.person.message.handlePromError");
			        adtips.tipserror($Gadget,dialogTitle,msgList);   
			    }else{
			        adtips.tipscontinue($Gadget,dialogTitle,msgList,returnMessage.returnOffering,warningConfirmCb); 
			    }
			}else{
				adtips.tipserror($Gadget,dialogTitle,msgList);
			}	
			return false;
		} else if (msgList.length > 0) { // 出现info跟warning错误时的弹出框
		//$UI.msgbox.warning(dialogTitle, message, wanConfirmCb, wanCancelCb,
		//			wanCancelCb);
			adtips.tipswarning($Gadget,dialogTitle,msgList,warningConfirmCb);
			return false;
		} else { // 不出现弹出框，返回true
			return true;
		}
	},
	/**
	 * 自定义错误提示框
	 */
	tipserror : function($Gadget,title,msgList){
		debugger;
		$Gadget.msgList = msgList || [];
		$Gadget.$Get("$Fire")({
	        "popup":{ 'id':'tipserror','title':title,'width':'500px',height:'318px',
					  'src':'{{$Webapp}}/bes/ad/usl/popup/bes-ad-tipserror-popup.uslx',
					  resizable:false
					}
	     },$Gadget);
		/**
		var id = "tipserror";
	    var src = "$Webapp+'/bes/ad/usl/popup/bes-ad-tipserror-popup.uslx'";
	    var title = "提示";
	    var modal = true;
	    $UI.artdialog("groupproduct_btn_sure").open(id, title, src, modal);
	    **/
	},
	/**
	 * 警告提示
	 */
	tipswarning : function($Gadget,title,msgList,warningConfirmCb){
		debugger;
		$Gadget.msgList = msgList || [];
		$Gadget.warningConfirmCb = warningConfirmCb;
		$Gadget.$Get("$Fire")({
	        "popup":{ 'id':'tipswarning','title' : title,'width':'500px',height:'280px',_ysp_top:'300px',
					  'src':'{{$Webapp}}/bes/ad/usl/popup/bes-ad-tipswarning-popup.uslx',
					  resizable:false
					}
	     },$Gadget);	
	},
	/**
	* 继续处理
	*/
	tipscontinue : function($Gadget,title,msgList,returnOffering,warningConfirmCb){
	   debugger;
	   $Gadget.msgList = msgList || [];
	   $Gadget.returnOffering = returnOffering;
	   $Gadget.warningConfirmCb = warningConfirmCb;
	   $Gadget.$Get("$Fire")({
	       "popup":{ 'id':'tipsofferrelation','title' : title,'width':'500px',height:'280px',_ysp_top:'300px',
					  'src':'{{$Webapp}}/bes/ad/usl/popup/bes-ad-tipsofferrelation-popup.uslx',
					  resizable:false
					}
	    },$Gadget);
	},
	 /**
     * 拆分提示或者错误信息为offer名称与非offer名称,默认传入的是$Item
     */
    splitPromptMessage : function(data){
    	debugger;
    	var list = [];
    	data.promptMessage = adtips.repOfferName(data.promptMessage);
    	if(data.promptMessage && '' != data.promptMessage)
    	{
    		$.each(data.promptMessage.split("\"") || [],function(i,val){
    			list.push({
    				text : val,
    				indexFlag : "-1"
    			});
    		});
    		return list;
    	}
    	list.push({
    		text : data.promptMessage,
    		indexFlag : "-1"
    	});
    	return list;
    },
    /**
     * 替换提示信息中带有的<# #>为"",
     */
    repOfferName : function(data){
    	debugger;
    	
    	//DTS2016101409774  pc增加了系统参数是60108007。例如：如果系统参数是#，那么就是#商品名称#
    	if($Page.highLightKeyword) {
    		data = data.replace(new RegExp($Page.highLightKeyword, 'g'),"\"");
    	} else {
    		data = data.replace(/<#(?!>)/g,"\"");
        	data = data.replace(/(?!<)#>/g,"\"");
    	}
    	return data;
    }
};
