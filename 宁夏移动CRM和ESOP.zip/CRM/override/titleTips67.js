 var isIE = (navigator.appVersion.indexOf("MSIE") != -1) ? true : false; 
  if(isIE){
    $("body").append('<div style="display:none;border:1px solid #000;background-color:#FFFFCC;font-size:12px;position:absolute;padding:2px 5px;max-width:400px;line-height:18px;z-index:99999;" id="titleTips"></div>');
    document.body.onmousemove=titleTipsMousemove;
    document.body.onmouseover=titleTipsMouseover;
    document.body.onmouseout=titleTipsMouseout;
    var titleTips= document.getElementById("titleTips");
    var titleTipsTempalt='';
    function titleTipsMove(evn,o){     
        _bW=document.documentElement.clientWidth;     
        _left1=document.documentElement.scrollLeft+evn.clientX+10;    
        _oW=o.offsetWidth;     
        _left=((evn.clientX+_oW)>_bW)?(_left1-_oW-10):_left1;     
        if((evn.clientX+_oW)>_bW){
          _left=(_oW<evn.clientX)?(_left1-_oW-10):_left1;
        }      
        _bH=document.documentElement.clientHeight;     
        _top1=document.documentElement.scrollTop+evn.clientY+6;     
        _oH=o.offsetHeight;     
        _top=((evn.clientY+_oH)>_bH)?(_top1-_oH-6):_top1;     
        if((evn.clientY+_oH)>_bH){
          _top=(_oH<evn.clientY)?(_top1-_oH-6):_top1;
        }     
        o.style.left=_left;     
        o.style._ysp_top=_top; 
      } 
    function titleTipsMouseover(){
     if(event.srcElement.title && (event.srcElement.title!='' || (event.srcElement.title=='' && titleTipsTempalt!=''))){
      titleTips.style.display='';
      titleTipsTempalt=event.srcElement.title;
      event.srcElement.title='';
      titleTips.innerHTML=titleTipsTempalt;
      evn=event;
      titleTipsMove(event,titleTips)
     }
    }
    function titleTipsMousemove(){
     if(titleTips.style.display==''){
      evn=event;
      titleTipsMove(event,titleTips)
     }
    }
    function titleTipsMouseout(){
     event.srcElement.title=titleTipsTempalt;
     titleTipsTempalt='';
     titleTips.style.display='none';
    }
  }
