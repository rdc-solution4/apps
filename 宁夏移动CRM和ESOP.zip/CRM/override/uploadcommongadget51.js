$Controller("bes.oc.uploadcommongadget", {
	// 选择图片后触发input事件，处理文件信息，以便上传
	addFilePath : function($Gadget,file,$UI,fileId,textId,$Page) {
		debugger;	
	
		// 校验文件的类型
		if(!$Controller.bes.oc.uploadcommongadget.previewImage(file,$UI,$Gadget,$Page))
		{
			return false;
		}
		var file_up = $("#" + textId + $Gadget.id);
		file_up.val(file.value);
		file_up.attr("title",file.value);
		
		//IE浏览器下显示上传文件的真实路径
		/*if (file_up && window.navigator.userAgent.indexOf("MSIE")>=1){
			file_up.select();
			file_up.blur();
			var realpath = document.selection.createRange().text;			
			file_up.val(realpath);
			file_up.attr("title",realpath);
		}*/
		return true;	
	},
	
	// 校验文件的类型
	previewImage:function(file,$UI,$Gadget,$Page)
	{
		debugger;
		var allowExtention=".jpg,.bmp,.gif,.png";//允许上传文件的后缀名
		var extention=file.value.substring(file.value.lastIndexOf(".")+1).toLowerCase();
		if(!(allowExtention.indexOf(extention)>-1))
		{
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.imageTypeNotSupported"));
			$Gadget.fileType = false;
			return false;
		}

		$Gadget.fileType = true;
	  	return true;

	},
	
	// 点击上传后真正上传
	uploadbefore : function($Gadget,$UI,$Page,fileId) {
		debugger;
		var textVal = $("#"+'personelUpload'+$Gadget.id).val();
		if(!textVal) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.selectAFile"));
			return false;
		}
		// 校验类型
		if(!$Gadget.fileType) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.imageTypeNotSupported"));
			return false;
		}
		
		$Page.file || ($Page.file = {});
	    //UEE.setFileMeta("$Page.file",id);
		$Page.$Meta || ($Page.$Meta= {});
		$Page.$Meta.$File || ($Page.$Meta.$File = {});
		$Page.$Meta.$File["$Page.file"] = [fileId+$Gadget.id];
		
		return true;
	},
	
	//上传之后的结果处理
	uploadResult : function($Gadget,$Page,$UI) {
		debugger;
		$Gadget.$data = $Gadget.$data || {};
		if(!$Gadget.$data.result) {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.systemError"));
			return false;
		}
		
		// 删除失败
		if('0' == $Gadget.$data.result.deleteResult) {
			$UI.msgbox.error($UEE.i18n("ad.person.message.information"),"原文件删除失败，请先删除后再上传");
			return false;
		}
		
		// 删除成功后处理上传的结果
		if($Gadget.$data.result.uploadResult == 'false') {
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$Gadget.$data.result.failedReason);
			return false;
		}
		else {
			// 上传成功
			$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.uploadedSuccessfully"));
			$Gadget.fileName=$Gadget.$data.result.fileName;
			$Gadget.attachmentId = $Gadget.$data.result.attachmentId;
			$Page[$Gadget.id] = $Page[$Gadget.id] || {};
			$Page[$Gadget.id].attachmentId = $Gadget.attachmentId;
			//事件用于组件外接收后显示证件图片
			$Page[$Gadget.id].localFileName = $("#personelUpload" + $Gadget.id).val();
			var fileNameJSON = {fileId : $Gadget.id, 
					            fileName : $Page[$Gadget.id].localFileName
					            };
			$Gadget.$Emit("$bes.ad.showIcCardImg",fileNameJSON);
			
			var fileInfo = {
					attachmentId: $Page[$Gadget.id].attachmentId,
					localFileName: $Page[$Gadget.id].localFileName,
					uploadedFileName: $Gadget.fileName
				};
			window._ysp_top[$Gadget.id] = fileInfo;
			$Gadget.showDelete = true;
			$("#personelUpload" + $Gadget.id).val('');
			$("#personelUpload" + $Gadget.id).attr('title','');
			
			var realeUploadId = 'realeUpload' + $Gadget.id;
			$("#realeUpload" + $Gadget.id).replaceWith('<input type="file" class="filecover" id=' + realeUploadId + ' accept=".png,.jpg,.bmp,.gif" style="right:8px;"/>');
			
			$Gadget.uploadFlag = true;			
		}
	},
	
	// 删除文件之前处理
	deletePic : function($Gadget,$UI,$Page,$Fire) {
		debugger;
		$UI.msgbox.confirm($UEE.i18n("ad.person.message.information"),'确认要删除吗？',function(){
			debugger;
			$Fire({
				service:'bes.oc.uploadcertpicbserviceimpl/deleteorderpic',
				params:{
					"attachmentid": $Gadget.attachmentId
				},
				target: '$Gadget.deleteResult',
				onafter: function() {
					debugger;
					if(!$Gadget.deleteResult) {
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.systemError"));
						return;
					}
					
					if('0' == $Gadget.deleteResult) {
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"),$UEE.i18n("ad.person.message.failedToDelete"));
						return;
					}
					
					if('1' == $Gadget.deleteResult) {
						//事件用于组件外接收后删除证件图片
						$Page[$Gadget.id].localFileName = $("#personelUpload" + $Gadget.id).val();
						var fileNameJSON = {fileId : $Gadget.id, 
								            fileName : $Page[$Gadget.id].localFileName
								            };
						$Gadget.$Emit("$bes.ad.hideIcCardImg",fileNameJSON);
						
						$UI.msgbox.info($UEE.i18n("ad.person.message.information"),"删除成功");
						$Gadget.showDelete = false;
						$Gadget.deleteFlag = true;
						$Gadget.uploadFlag = false;
						$Gadget.attachmentId = null;
						$Page[$Gadget.id].attachmentId = null;
						return;
					}
				}
			}, $Gadget);
	    },function(){
		    return false;
	    });
	},
}

);