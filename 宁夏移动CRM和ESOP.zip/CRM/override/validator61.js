//校验提示信息
//请输入8位日期格式的数字
var VALIDATOR_DATEDIGIT = $UEE.i18n('ad.person.message.VALIDATOR_DATEDIGIT');
//无效的手机号码
var VALIDATOR_PHONE = $UEE.i18n('ad.person.message.VALIDATOR_PHONE');
//输入位数大于{0}位
var VALIDATOR_MAX_DIGIT = $UEE.i18n('ad.person.message.VALIDATOR_MAX_DIGIT');
//DTS2017120409437,输入金额位数大于{0}位
var VALIDATOR_MONEY_MAX_DIGIT = "输入金额位数大于{0}位";
//请输入{0}位数字
var VALIDATOR_DIGIT = $UEE.i18n('ad.person.message.VALIDATOR_DIGIT');
//输入字符大于{0}个
var VALIDATOR_MAX_CHAR = $UEE.i18n('ad.person.message.VALIDATOR_MAX_CHAR');
//输入字节大于{0}个
var VALIDATOR_MAX_BYTE = $UEE.i18n('ad.person.message.VALIDATOR_MAX_BYTE');
//无效的身份证号码
var VALIDATOR_IDCARD = $UEE.i18n('ad.person.message.VALIDATOR_IDCARD');
//输入金额无效
var VALIDATOR_MONEY = $UEE.i18n('ad.person.message.VALIDATOR_MONEY');
//无效的输入值
var VALIDATOR_SMALLTHAN = $UEE.i18n('ad.person.message.VALIDATOR_SMALLTHAN');
//无效的证件号码
var VALIDATOR_CARD = $UEE.i18n('ad.person.message.VALIDATOR_CARD');
//不可以包含特殊字符
var VALIDATOR_SPECIALCHAR = $UEE.i18n('ad.person.message.VALIDATOR_SPECIALCHAR');
//无效的天数
var VALIDATOR_DAYS = $UEE.i18n('ad.person.message.VALIDATOR_DAYS');
//地址至少需要16位(或8个汉字)
var VALIDATOR_IDADRESS = $UEE.i18n('ad.person.message.VALIDATOR_IDADRESS');
//您的输入含非法字段
var VALIDATOR_JSINPUT = $UEE.i18n('ad.person.message.VALIDATOR_JSINPUT');
//请输入{0}位字符
var VALIDATOR_CHAR = $UEE.i18n('ad.person.message.VALIDATOR_CHAR');
//请输入{0}位字母或数字
var VALIDATOR_ONLY_CHARANDDIGITAL = $UEE.i18n('ad.person.message.VALIDATOR_ONLY_CHARANDDIGITAL');
//请输入{0}~{1}位字母和数字
var VALIDATOR_BOTH_CHARANDDIGITAL_LENGTH_RANGE = $UEE.i18n('ad.person.message.VALIDATOR_BOTH_CHARANDDIGITAL_LENGTH_RANGE');

var VALIDATOR_ONLY_NUMBER_LENGTH_RANGE = $UEE.i18n('ad.person.message.VALIDATOR_ONLY_NUMBER_LENGTH_RANGE');
//请输入小于等于{0}的时间
var VALIDATOR_EXP_DATE = $UEE.i18n('ad.person.message.VALIDATOR_EXP_DATE');
//只能输入正整数
var VALIDATOR_NUMBER = $UEE.i18n('ad.person.message.VALIDATOR_NUMBER');
//只能输入正整数,且不能以0开头！
var VALIDATOR_POSITIVE_NUMBER = "只能输入正整数,且不能以0开头！";
//只能输入正数
var VALIDATOR_POSITIVE_NUM = "请输入正数。";
//ECUADORMOBILE
var VALIDATOR_ECUADORMOBILE = $UEE.i18n('ad.person.message.VALIDATOR_ECUADORMOBILE');
//输入字符小于{0}位
var VALIDATOR_MIN_CHAR = $UEE.i18n('ad.person.message.VALIDATOR_MIN_CHAR');
//无效的电话号码或者传真号码
var VALIDATOR_TELEPHONE = $UEE.i18n('ad.person.message.VALIDATOR_TELEPHONE');
//无效的手机号码
var VALIDATOR_ONLY_MOBILEPHONE = $UEE.i18n('ad.person.message.VALIDATOR_ONLY_MOBILEPHONE');
var VALIDATOR_TELEPHONEQSS = $UEE.i18n('ad.person.message.VALIDATOR_TELEPHONE');
//不是合法的移动手机号码
var VALIDATOR_MOBILEPHONE = $UEE.i18n('ad.person.message.VALIDATOR_MOBILEPHONE');
//不是合法的固定电话号码
var VALIDATOR_FIXLINENUMBER = $UEE.i18n('ad.person.message.VALIDATOR_FIXLINENUMBER');
//不是合法的移动小区宽带号码
var VALIDATOR_COMMUNITYBANDNUMBER = $UEE.i18n('ad.person.message.VALIDATOR_COMMUNITYBANDNUMBER');
//不是合法的移动校园宽带号码
var VALIDATOR_CPMPUSBANDNUMBER = $UEE.i18n('ad.person.message.VALIDATOR_CPMPUSBANDNUMBER');
//不是合法的移动公司号码
var VALIDATOR_CHINAMOBILE = $UEE.i18n('ad.person.message.VALIDATOR_CHINAMOBILE');
//IP地址不能填写127.0.0.1
var VALIDATOR_IPNOLOCAL = $UEE.i18n('ad.person.message.VALIDATOR_IPNOLOCAL');
//只能输入英文
var VALIDATOR_TUREEN = $UEE.i18n('ad.person.message.VALIDATOR_TUREEN');
//IP地址格式不正确。
var VALIDATOR_IPSTR = $UEE.i18n('ad.person.message.VALIDATOR_IPSTR');
//不能超过规定字符个数。请在属性名注明字符个数，例如：企业名称(100字符以内)。
var VALIDATOR_ZHSIGNLEN = "不能超过规定字符个数";
var VALIDATOR_BROADBANDNUMBER = "宽带账号必须带有@符号";
var VALIDATOR_BANDWIDTHWITHLIMIT = "带宽必须为正整数并且以M或者G结尾";
var VALIDATOR_LATER_PLEASE_CHOOSE ="请选择下拉框值";
var VALIDATOR_SHORTNUMBER_PATTERN1 ="短号必须是以2/6/7/8/9开头且长度为3-6位的数字";
var VALIDATOR_SHORTNUMBER_PATTERN2="总机号必须以5或6开头长度为3-6位的数字以5开头时第二位不能为5以6开头时第二位不能为0不能为61860"
var VALIDATOR_SHORTNUMBER_PATTERN3 ="此处短号须为非0、1、2、9开头的3-6位数字";
var VALIDATOR_PERIODTIME_PATTERN ="时段格式应为HH&HH";
var VALIDATOR_SHORTPREFIX_PATTERN ="IMSV网固话号头不能为0,1,9";
var VALIDATOR_DATEDIGIT2 = "请输入yyyy/mm/dd格式的日期";
var VALIDATOR_BEFORESTARTTIME = "结束时间应大于开始时间";
var VALIDATOR_SERVICECODEPREFIX1065096 = '请输入以1065096开头的服务代码';
var VALIDATOR_CHARDIGITALLIMIT ="请输入数字或字母";
var VALIDATOR_ZHSIGNLEN_EIGHT = "请输入3-8个汉字";
var VALIDATOR_ZHSIGNLESS = "请输入至少{0}个汉字";
var VALIDATOR_ZHSIGNLEN_ONETOEIGHT = "请输入1-8个汉字";
var VALIDATOR_ZHSIGNLEN_LISTEIGHT = "地址不少于8个汉字";
var VALIDATOR_ZHSIGNLEN_TWOTOMAX = "姓名大于等于两个汉字";
//必须为数字、字母、下划线。
var VALIDATOR_ONLY_CHARDIGITALUNDER = $UEE.i18n('ad.person.message.VALIDATOR_ONLY_CHARDIGITALUNDER');
//必须为数字、字母、下划线，且以字母开头。
var VALIDATOR_ONLY_CHARSTARTDIGITALUNDER = "必须为数字、字母、下划线，且以字母开头";
//不是合法的呼转号码
var VALIDATOR_CALLFROMAT_NUMBER = $UEE.i18n('ad.sr.title.bshfhzhm');

//3-6位数字,以77或79开头
var VALIDATOR_DIGIT_BETWEEN = $UEE.i18n('ad.person.message.VALIDATOR_DIGIT_BETWEEN');
//密码为4到15位的数字和字母组合
var VALIDATOR_NUMANDLETTERDIGIT_BETWEEN = $UEE.i18n('ad.person.message.VALIDATOR_NUMANDLETTERDIGIT_BETWEEN');
//输入位数小于{0}位
var VALIDATOR_MIN_DIGIT = $UEE.i18n('ad.person.message.VALIDATOR_MIN_DIGIT');
//以4001开头的10位数。
var VALIDATOR_NUM_START = $UEE.i18n('ad.group.tips.beginwithfour');
//请输入6位时分秒格式的数字
var VALIDATOR_TIMEDIGIT = "请输入6位时分秒格式的数字。";

//合同结束时间必须大于合同生效时间
var VALIDATOR_TIMECOMPARE = $UEE.i18n('ad.person.message.VALIDATOR_TIMECOMPARE');
//中文校验
var VALIDATOR_CHINESE_NUM="请输入1-8位的中文签名。"
//中文校验
var VALIDATOR_CHINESE_ONLY = "请输入中文签名。";
//中文校验
var VALIDATOR_CHINESE = "请输入2-4位的中文签名。";
//中文校验
var VALIDATOR_CHINESE_TWO = "姓名大于等于2个汉字。";
//中文校验
var VALIDATOR_CHINESELESS_EIGHT = "证件地址至少8个汉字。";
//英文校验
var VALIDATOR_ENGLISH = "请输入1-16位的英文签名。";
//输入姓名校验
var VALIDATOR_RALATENAME =  $UEE.i18n('ad.person.message.VALIDATOR_NAME');
//邮箱校验
var VALIDATOR_RALATEMAIL = $UEE.i18n('ad.person.message.VALIDATOR_RALATEMAIL');
//带宽速率校验，正整数，单位为M
var VALIDATOR_BANDWIDTH_RATE = "请输入正整数，并以单位M结尾。";
//只能输入正数
var VALIDATOR_NUM = "请输入非负整数。";

//输入大于零的偶数
var VALIDATOR_EVENNUM = "请输入大于0的偶数。";

// 请输入一个不小于0的数。
var VALIDATOR_NON_NEGATIVE = $UEE.i18n('ad.group.label.nonNegative');

//密码不一致。
var VALIDATOR_PASSWORD = $UEE.i18n('ad.group.label.pwdNotSame');
//请输入正确的整数或百分数
var VALIDATOR_PERCENT= $UEE.i18n('ad.person.message.VALIDATOR_PERCENT');
//nrly 国家码+号码校验
var VALIDATOR_NUMBER_NRLY="Please input correct country code and phone number.";
//发送日期不能超过当前时间
var VALIDATOR_DATE_NOTSMALL_NOW=$UEE.i18n('ad.sentandquerysms.message.VALIDATOR_DATE_NOTSMALL_NOW');
//发送邮件日期不能超过当前时间
var VALIDATOR_EMAILDATE_NOTSMALL_NOW=$UEE.i18n('ad.sentandqueryemail.message.VALIDATOR_EMAILDATE_NOTSMALL_NOW');
//发送日期不能超过当前时间
var VALIDATOR_DATE_NOTSMALL_CURDATE=$UEE.i18n('ad.error.tips.expirationDate');
//失效日期不能超过当前时间
var VALIDATOR_DATE_NOTBEFORE_CURDATE=$UEE.i18n('ad.error.tips.expirationDate');
// 集团客户注册日期不能晚于当前时间
var VALIDATOR_DATE_NOTAFTER_NOW=$UEE.i18n('ad.group.message.registerTimeNotAfterNow');

//输入值须等于或少于父群组限制值与兄弟群组限制值之和的差
var VALIDATOR_MAXGRPLIMITVALUE = $UEE.i18n('ad.group.message.maxLimitValue');
//imei格式不正确
var VALIDATOR_IMEINUMBER=$UEE.i18n('bes.ad.ctz.changehandset.message.imeiformatincorrect');
// 请输入正确的15位IMEI串号
var VALIDATOR_VALIMEINUMBER=$UEE.i18n('bes.ad.message.imeiformatincorrect');
//15位imei号码校验
var VALIDATOR_IMEINUMBERFORFIFTHING = $UEE.i18n('bes.ad.ctz.changehandset.message.imeiformat15char');
//输入值等于或者大于所有子群的限额值数量之和
var VALIDATOR_MINGRPLIMITVALUE= $UEE.i18n('ad.group.message.minLimitValue');
//输入值等于或者大于所有子群的限额值数量之和
var VALIDATOR_MINGRPLIMITVALUE= $UEE.i18n('ad.group.message.minLimitValue');
//输入值须等于或者大于群组有效或挂起的成员数
var VALIDATOR_MAXMEMAMOUNT= $UEE.i18n('ad.group.message.minMaxMemAmountValidate');
//输入手机号码为11位
var VALIDATOR_PHONENUMBER = "手机号码为11位";
//输入邮编号为6位
var VALIDATOR_ZIPCODE = "邮编号码为6位";
//折扣为0-100的整数
var VALIDATOR_DISCONTNUMBER = "输入折扣为0-100的整数";
//折扣为50-100的整数
var VALIDATOR_DISCONTNUM = "输入折扣为50-100的整数";
//Please input number between 0 and 100
var VALIDATOR_DISCONTNUMBER_EN ="The entered number must be an integer from 1 to 99.";
var VALIDATOR_ISSURE = "不能选择该值，请重新选择.";
var VALIDATOR_ISTUREZH = "请填写2-8个汉字。";
var VALIDATOR_ISTUREEN = "请填写12个以内的英文字符。";
var VALIDATOR_ISPERCENTSMAX = "请填写0-100以内的整数。";
var VALIDATOR_ISPERCENTSMIN = "折扣不能小于{0}。";
// 年月格式应为YYYYMM
var VALIDATOR_YREARMOUTH = $UEE.i18n('ad.group.message.YEARANDMOUTH');
var VALIDATOR_DUGITLIMIT = "语音专线费用阀值在1到10之间。";

//号码个数不能超过 {0} 个。
var VALIDATOR_NUMSS = $UEE.i18n("ad.person.message.numberQuantity",[10000]);
var VALIDATOR_FILTERSPECIALSIGN = "输入的信息不能含有特殊字符";
var VALIDATOR_LICENSENUM = '请填写0~50之间的整数。';
//订购用户的数量不能超过1000
var VALIDATOR_MAXTHOUSAND = "订购用户的数量不能超过1000";
//请输入100以内的数字
var VALIDATOR_MAXHOUSAND = $UEE.i18n('ad.group.message.MAXHOUSAND');
//不能超过9位数
var VALIDATOR_PureNumBer ="9位数以内纯数字"
var VALIDATOR_VALIDATESMPGROUPID = "登陆名长度必须在6~20位之间，且必须以当前地市代码开头";
//输入长度必须在6~30位之间
var VALIDATOR_ADMINIDPWDLEN = $UEE.i18n('ad.group.message.ADMINIDPWDLEN');

var VALIDATOR_VALIDATESMPGROUPLOGINNAME = "登陆名长度必须为4~6位输入值加地市缩写";
//
VALIDATOR_CHINAMOBILEZ ="不是合法的移动手机号码和固话号码";
var VALIDATOR_NUM_GREATER = "请输入大于0的数字";
var VALIDATOR_ONLYCHINESE="请输入中文";
var VALIDATOR_ONLYCHINESEORENGLISH = "姓名只能全中文或全英文";
var VALIDATOR_BEGIN_WITH = '必须以{0}开头';
var VALIDATOR_NOT_BEGIN_WITH = '不能以{0}开头';
var VALIDATOR_CHECKDNS = "请输入正确的格式";
var PURENUM=$UEE.i18n('ad.person.message.enterOnlyNumber');
var ID_NUMBER_VALIDATE_NIGERIA=$UEE.i18n('ad.grpsr.message.QSRIDNUMBER');
var VALIDATOR_CHINESE_NUM="请输入3-8位的中文签名。"
var SIXNUM="请输入6位以内数字。"
var NINENUM="请输入9位以内数字。"
var NINERNUM="请输入9位以内数字,首位不允许小于1。"

var VALIDATOR_RUC_FORMAT_4_ECUADOR = $UEE.i18n('ad.person.label.RucNumTip');
var VALIDATOR_ID_FORMAT_4_ECUADOR = $UEE.i18n('ad.person.label.IdNumTip');

// 带宽输入 ，以数字开头+G或M结尾
var VALIDATOR_BANDWIDTH_RATE1 = "请输入正确格式(以数字开头+G或M结尾)";

// 只能输入数字和小数点
var VALIDATOR_NUMBER_DECIMALS = "只能输入数字和小数"
//长度限制5位数字
var FIVENUM="长度限制5位。";
var VALIDATOR_CAPITAL = "请输入大写字母";
var POSTNUM="邮政编码为6位数字。"
//登陆密码长度必须在6~20位之间
var VALIDATOR_VALIDATELOGINPWD = "登陆密码长度必须在6~20位之间";

// 请输入100的倍数
var VALIDATOR_TIMES_OF_HUNDRED = $UEE.i18n('ad.common.message.VALIDATOR_TIMES_OF_HUNDRED');
//输入长度必须在4~64位之间
var VALIDATOR_VALIDATEAUTHNAME = "请输入长度为4～64的字符";
//输入长度必须在4~64位之间
var VALIDATOR_VALIDATEAUTHPWD = "请输入长度为8～16的字符";
//输入长度必须在0~64位之间
var VALIDATOR_VALIDATESPDESC = "输入长度不能超过64位";
//必须同时包括小写字母、大写字母、数字和特殊字符
var VALIDATOR_VALIDATESTRPWD = "密码必须同时包括小写字母、大写字母、数字和特殊字符";

var VALIDATOR_lINKMANMOBILE = "请输入移动号码";

var VALIDATOR_APNATTRENDJS = "APN属性（1115010003）值的长度不能小于4位，并且必须以.js结尾";
//机器卡APNCODE属性内容校验
var VALIDATOR_GRPAPNCODE = "请输入英文字母、数字、点“.”组合，第一个字符不能为点";
//中继线编码长度不能超过7
var VALIDATOR_VALIDATEVOICECONFIG="中继线编码长度不能超过7";
//交换机信息长度不能超过10
var VALIDATOR_VALIDATESWITCHCONF="交换机信息长度不能超过10";
//输入必须为字母和数字
var VALIDATOR_VALIDATELETTERSORMATH=$UEE.i18n('ad.common.message.VALIDATOR_LETTERSORMATH');
//QOS产品ServiceId属性内容校验
var VALIDATOR_NOCHINESE="ServiceID不能为中文。";
//哥伦比亚账户免税开始时间必须早于结束时间
var VALIDATOR_EXCLUDEDCOMPARE = "Tax Excluded Start Date Must Greater Than Tax Excluded End Date";
//add by xwx427119
var VALIDATOR_MORETHANTIME = $UEE.i18n('ad.person.label.morethantime');
//江苏禁止业务开始时间必须早于结束时间
var VALIDATOR_TIME_COMP="开始时间应该早于结束时间";
var VALIDATOR_INPUTNOTVALID = $UEE.i18n('ad.spanish.inputnotvalid');

var VALIDATOR_MONEYDECIMAL = "输入为整数并且小数点后不超过2位";
var VALIDATOR_MONEYDECIMALW = "输入整数大于等于1并且小数点后不超过2位";
var VALIDATOR_TWODECIMAL = "Please keep two decimal!";

var VALIDATOR_QUOTMONEYDECIMAL = "输入为整数并且小数点后不超过2位、小数点前不超过6位";
//集团V网类的部分产品用户名称校验
var VALIDATOR_USERNAME_NUM = "用户名称不能超过30个汉字(60个字符)的长度。"
var VALIDATOR_USERNAME = "用户名称为汉字和字母。"
//汉字、字母、数字均只能输入{0}位
var VALIDATOR_ALPHANUMERIC_CHARACTER = "汉字、字母、数字均只能输入{0}位";
var VALIDATOR_APPLICANT_CHARACTER = "超过{0}个字符的长度";
//4位数字
var	YEARNUM = "4 NUMBERS";
//请输入长度不超过50的非中文
var VALIDATOR_FAULTCHINESE="请输入长度不超过50的非中文";
//输入为1-{0}的正整数校验
var VALIDATOR_POSITIVE_INTERGERS = "输入为1-{0}的正整数";
/*
 * 业务代码(MSD开头) BizCode属性校验
 */
//只能以MSD开头
var VALIDATOR_STYLEOFBIZCODE = "只能以MSD开头的数字，总长度不能超过10位";
//经纬度
var VALIDATOR_LONGITUDE_DIMENSION = "请按XX.XX格式填写(小数点后最多6位)";
//主题必须以boss开头
var VALIDATOR_BOSS = "必须以boss开头";
var VALIDATOR_APNNAME_NUM = "本地APN名称格式为：CMIOT/cmiotXXXX.js。全网APN名称格式为：CMIOT/cmiotXXXX。XXXX为字母且不超过10位。";
var VALIDATOR_APNIP = "静态IP地址池格式如：10.32.1.1~10.32.1.10";
//添加外国人外国人永久居留证验证中文姓名    用户姓名只能包括汉字与•或·	 姓名至少2个汉字或4个字符，不超过256位     IdCardEx
var VALIDATOR_IDCARDEXZHNAME = "用户姓名只能包括汉字与•或·";
var VALIDATOR_IDCARDEXENNAME = "不能包含汉字符号和阿拉伯数字";
var VALIDATOR_IDCARDEXZHNAMELENGTH = "姓名至少2个汉字或4个字符，不超过256位";
var VALIDATOR_IDCARDEXENNAMELENGTH = "外国人永久居留证姓名至少3个字节，不超过256个字节";
var VALIDATOR_DISCONTNUMBERNBIOT = "请输入1-100的整数。"
jQuery.validator.addMethod("discontNumNBIOT", function(value, element, parm){
	debugger;
	if (/^(100|[1-9]|[1-9][0-9])$/.test($.trim(value))){
		return {
			result : true
		};
	}else{
		return {
			result : false
		}
	}
	return {
		result : true
	};
},VALIDATOR_DISCONTNUMBERNBIOT);
jQuery.validator.addMethod("styleOfBizCode", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	if(!(value == "MSD" || /^(MSD[0-9]{1,7})$/.test($.trim(value)))){
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_STYLEOFBIZCODE);
/**
 * 定额支付输入金钱，小数点后面2位，小数点前面6位
 */
jQuery.validator.addMethod("quotaMoneyDecimal", function (value, element, param){
		debugger;
		if(value==""){
			return {result : true};
		}
		if (!(/^(([1-9][0-9]{1,5})|[0-9])([.]\d{1,2})$/.test($.trim(value))||/^(([1-9][0-9]{1,5})|[0-9])$/.test($.trim(value)))){
			return {result : false}
		}
	return {result : true};
}, VALIDATOR_QUOTMONEYDECIMAL);


jQuery.validator.addMethod("MoneyDecimal", function (value, element, param){
	debugger;
	if(value==""){
		return {result : true};
	}
	if (!(/^(([1-9][0-9]*)|[0-9])([.]\d{1,2})$/.test($.trim(value))||/^(([1-9][0-9]*)|[0-9])$/.test($.trim(value)))){
		return {result : false}
	}
return {result : true};
}, VALIDATOR_MONEYDECIMAL);

jQuery.validator.addMethod("MoneyDecimalW", function (value, element, param){
	debugger;
	if(value==""){
		return {result : true};
	}
	if (!(/^(([1-9][0-9]*)|[1-9])([.]\d{1,2})$/.test($.trim(value))||/^(([1-9][0-9]*)|[1-9])$/.test($.trim(value)))){
		return {result : false}
	}
return {result : true};
}, VALIDATOR_MONEYDECIMALW);

jQuery.validator.addMethod("TwoDecimal", function (value, element, param){
	debugger;
	if(value==""){
		return {result : true};
	}
	if (!(/^(([1-9][0-9]*)|[0-9])([.]\d{1,2})$/.test($.trim(value))||/^(([1-9][0-9]*)|[0-9])$/.test($.trim(value)))){
		return {result : false}
	}
return {result : true};
}, VALIDATOR_TWODECIMAL);


jQuery.validator.addMethod("ValidatorSid", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : false
		};
	}

	if (/[\u4E00-\u9FA5]/i.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_NOCHINESE);
/**
 * 机器卡APNCODE属性校验，字母数字点组合，点不能第一位
 */
jQuery.validator.addMethod("GRPApnCode", function (value, element, param){
		debugger;
		if(value==""){
			return {result : true};
		}
		if ((/^(?=.*\d)(?=.*[a-zA-Z])(?=.*\.)[0-9a-zA-Z.]{3,}$/.test($.trim(value)))
				&& (value.indexOf(".") != 0)){
			return {result : true}
		}
	return {result : false};
}, VALIDATOR_GRPAPNCODE);

/**
 * 针对现网有linkManMobile1，linkManMobile2中的ChkMobileNumber(document.all.linkManMobile1.value)的校验
 */
jQuery.validator.addMethod("linkManMobile", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
	if (! /^158\d{8}$|182\d{8}$|183\d{8}$|170\d{8}$|172\d{8}$|178\d{8}$|184\d{8}$|152\d{8}$|188\d{8}$|151\d{8}$|134\d{8}$|135\d{8}$|136\d{8}$|137\d{8}$|138\d{8}$|139\d{8}$|159\d{8}$|150\d{8}$|147\d{8}$|157\d{8}$|187\d{8}$|198\d{8}$/.test($.trim(value)))
	{
		return {result : false};
	}
	return {result : true};
}, VALIDATOR_lINKMANMOBILE);

/**
 *  VALIDATOR_VALIDATELOGINPWD登陆密码长度必须在6~20位之间
 */
jQuery.validator.addMethod("validateLoginPwd", function(value, element, param) {
	 	debugger;
	 	if (!value) {
	 		return {
	 			result : true
	 		};
	 	}
	 	if (($.trim(value).length < 6) || ($.trim(value).length > 20))  {
	 		return {
	 			result : false
	 		};
	 	}
	 	return {
	 		result : true
	 	};
	 },  VALIDATOR_VALIDATELOGINPWD);

/**
 * 输入长度必须在6~30位之间
 */
jQuery.validator.addMethod("validateadminlen", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}


 	if (($.trim(value).length < 6) || ($.trim(value).length > 30))  {
 		return {
			result : false,
			parameters : param
		};
 	}



	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ADMINIDPWDLEN);


var VALIDATOR_CHECKSUBNET ="请输入正确的子网掩码";
/**
 * 纯数字
 */
jQuery.validator.addMethod("pureNumBer", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, PURENUM);


/**
 * 必须为数字，字母和下划线组成
 */
jQuery.validator.addMethod("idNumberValidateNigeria", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[a-zA-Z0-9_]*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, ID_NUMBER_VALIDATE_NIGERIA);
/**
 * 6位以内数字
 */
jQuery.validator.addMethod("sixNumber", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{0,6}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, SIXNUM);
/**
 * 长度限制5位
 */
jQuery.validator.addMethod("FiveNumber", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{5}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, FIVENUM);
/**
 * 9位以内数字
 */
jQuery.validator.addMethod("nineNumber", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

    var len = param[0];
    if (len && $.trim(value).length != len)
    {
		return {result : false, parameters : param};
	}

	if (!/^\d{0,9}$/.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, NINENUM);
/**
 * 邮政编码为6位数字。
 */
jQuery.validator.addMethod("postnum", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{6}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, POSTNUM);
/**
 * 年份为4位数字。
 */
jQuery.validator.addMethod("yearnum", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{4}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, YEARNUM);
/**
 * 9位以内数字必须以1开头
 */
jQuery.validator.addMethod("ninerNumber", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[1-9]\d{0,8}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, NINERNUM);
var VALIDATOR_CHECKSUBNET ="请输入正确的子网掩码";
/**
 * 当前input控件与指定input数值差不能超过1000个
 *
 * @param {id} 指定控件id
 * eg：dtNum('id')
 */
jQuery.validator.addMethod("dtNums", function (value, element, param)
{
    debugger;
    var p = [];
    p[0] = param[1] + 1;
    var v  = Number(value,10);
    var v1 = Number($("#" + param[0]).val(),10);
    var v2 = Number(param[1],10);

    var dt = v - v1;
    if (dt > v2) {
        return {result : false,parameters : p};
    }

    return {result : true};
}, VALIDATOR_NUMSS);

var VALIDATOR_FILTERSPECIALSIGN = $UEE.i18n('ad.sr.message.XMBNHYTSZF');
/**
 * 过滤特殊字符
 */
jQuery.validator.addMethod("filterspecialsign", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^([\u4e00-\u9fa5]|[a-zA-Z0-9])+$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_FILTERSPECIALSIGN);

//合同生效时间 和 合同结束时间 检验
jQuery.validator.addMethod("timeCompare", function(value, element, param) {
    debugger;
    if (value == "") {
        return {
            result : true
        };
    }
    var $Gadget = $(element).scope().$Gadget;
    var begintime;//合同生效时间
    var endtime;//合同结束时间

    var beginAttrcode;
    var endAttrcode;

    $.each($Gadget.$Attrs.model, function(i, attribute){

        $.each(attribute.attributes, function(j, val){

            //合同生效时间
            if (val.attrId == "201010002070"){
                begintime = val.newValue;
                beginAttrcode = val.attrCode;
            }

                //合同结束时间
            if (val.attrId == "201010002042"){
                endtime = val.newValue;
                endAttrcode = val.attrCode;
            }

      });
    });

    if(begintime != null && endtime != null && begintime >= endtime){

        return {
            result : false
        };
    }
    $(document).find('#TIME_INPUT_'+beginAttrcode).removeClass("uee-invalid");
    $(document).find('#TIME_INPUT_'+endAttrcode).removeClass("uee-invalid");
    return {
        result : true
    };
}, VALIDATOR_TIMECOMPARE);


//6位时分秒格式数字
jQuery.validator.addMethod("timeDigit", function(value, element, param) {
    if (value == "") {
        return {
            result : true
        };
    }
    if (!/^([0-1][0-9]|2[0-3])([0-5][0-9])([0-5][0-9])$/.test($.trim(value))) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_TIMEDIGIT);

//判断是否结束时间小于开始时间
jQuery.validator.addMethod("beforeStartTime", function(value, element, param) {
	debugger;
    if (value == "") {
        return {
            result : true
        };
    }
    var startTime = $(document.getElementById(param[0])).val();
    if (startTime > value) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_BEFORESTARTTIME);

//6位时年月格式数字
jQuery.validator.addMethod("yearMouth", function(value, element, param) {
    if (value == "") {
        return {
            result : true
        };
    }
    if (!/^([0-9]{4})(0[0-9]|1[0-2])$/.test($.trim(value))) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_YREARMOUTH);

//费用阈值配置，范围在1到10之间，支持2位小数。
jQuery.validator.addMethod("digitLimit", function(value, element, param) {
    if (value == "") {
        return {
            result : true
        };
    }
    if (!/^((([0]?[1-9])([.]\d{1,2})?)|([1][0]))$/.test($.trim(value))) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_DUGITLIMIT);

// 8位日期数字
jQuery.validator.addMethod("dateDigit", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^(?:(?!0000)[0-9]{4}(?:(?:0[1-9]|1[0-2])(?:0[1-9]|1[0-9]|2[0-8])|(?:0[13-9]|1[0-2])(?:29|30)|(?:0[13578]|1[02])31)|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)0229)$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_DATEDIGIT);

//时间格式：yyyy/mm/dd
jQuery.validator.addMethod("dateDigit2", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^((((1[6-9]|[2-9]\d)\d{2})\/(0?[13578]|1[02])\/(0?[1-9]|[12]\d|3[01]))|(((1[6-9]|[2-9]\d)\d{2})\/(0?[13456789]|1[012])\/(0?[1-9]|[12]\d|30))|(((1[6-9]|[2-9]\d)\d{2})\/0?2\/(0?[1-9]|1\d|2[0-8]))|(((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))\/0?2\/29))$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_DATEDIGIT2);

jQuery.validator.addMethod("days", function(value, element, param) {
	if (value == "") {
		return {
			result : false
		};
	}
	if (!/^[123456789]\d{0,2}$/.test($.trim(value))
			&& !/^[0]$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_DAYS);

/**
 * 截止时间校验
 */
jQuery.validator.addMethod("deadLine", function (value, element, param)
{
	if(value==""){
		return {result : true};
	}
	var $Gadget = $(element).scope().$Gadget;
	var deadLine = $Gadget.endDate;
	var expDate = $Gadget.expDate;
	var paramArray = [];
	paramArray.push(new Date(deadLine).Format('yyyy-MM-dd'));
    if (expDate > deadLine)
    {
        return {result : false,parameters:paramArray};
    }
    return {result : true};
}, VALIDATOR_EXP_DATE);

/**
 * 证件地址校验
 */
jQuery.validator.addMethod("IDadress", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if ($.trim(value).replace(/[^\x00-\xff]/g, "xx").length < 16) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_IDADRESS);
/**
 * 手机号码校验
 */
jQuery.validator.addMethod("phone", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^((1[345789]\d{9,14})|(1064\d{9,11}))$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_PHONE);
/**
 * 手机号码校验qss
 */
jQuery.validator.addMethod("phoneqss", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{10}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_PHONE);
/**
 * 呼转号码校验
 */
jQuery.validator.addMethod("callfowardphone", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^((1[345789]\d{9})|(0[1-9]\d{10,13})|(00\d{10,16}))$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_CALLFROMAT_NUMBER);

/**
 * 数字位数校验，数字不能超过指定的位数
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("maxDigit", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^\d*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MAX_DIGIT);

/**
 * 金额位数校验（包含小数点），不能超过指定的位数
 * DTS2017120409437
 * @param {number}
 *            金额位数
 */
jQuery.validator.addMethod("moneyMaxDigit", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^\d{1,9}([.]\d{1,2})?$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MONEY_MAX_DIGIT);

/**
 * 数字位数校验，数字位数必须等于指定的位数
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("digit", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).length != len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^\d*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_DIGIT);

// MODIFY 2015-11-03 by l0028967 DTS2015110203299 start
/**
 * 数字位数校验，数字位数必须等于指定的位数
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("digitPassword", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	// 如果密码没有变化，则返回true
	var passwordForCompare = param[1];
	// 如果有原始密码
	if (passwordForCompare == 'hasPassword') {
		var $scope = $(document).scope();
		var originalPassWord = $scope.$Page.attrPasswordForCompare;
		// 如果原始密码与现在输入框里的相同，则直接返回true
		if (originalPassWord == ($.trim(value))) {
			return {
				result : true,
				parameters : param
			};
		}
	}
	var len = param[0];
	if ($.trim(value).length != len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^\d*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_DIGIT);
/**
 * 数字位数校验，数字位数必须等于指定的位数  校验时包含空格
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("digitPasswordHaveTrim", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	// 如果密码没有变化，则返回true
	var passwordForCompare = param[1];
	// 如果有原始密码
	if (passwordForCompare == 'hasPassword') {
		var $scope = $(document).scope();
		var originalPassWord = $scope.$Page.attrPasswordForCompare;
		// 如果原始密码与现在输入框里的相同，则直接返回true
		if (originalPassWord == value) {
			return {
				result : true,
				parameters : param
			};
		}
	}
	var len = param[0];
	if (value.length != len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^\d*$/.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_DIGIT);
//MODIFY 2015-11-03 by l0028967 DTS2015110203299 end

/**
 * 密码校验：数字+字母，位数必须介于指定长度之间
 *
 * @param {minlen}[{'hasPassword'}]{maxlen}
 *            数字位数
 */
jQuery.validator.addMethod("digitAndCharPassword", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	var returnParam = [param[0], param[2]];

	// 如果密码没有变化，则返回true
	var passwordForCompare = param[1];
	// 如果有原始密码
	if (passwordForCompare == 'hasPassword') {
		var $scope = $(document).scope();
		var originalPassWord = $scope.$Page.attrPasswordForCompare;
		// 如果原始密码与现在输入框里的相同，则直接返回true
		if (originalPassWord == ($.trim(value))) {
			return {
				result : true,
				parameters : returnParam
			};
		}
	}
    var minlen = param[0];
    var maxlen = param[2];
    if ( !($.trim(value).length>=minlen && $.trim(value).length<=maxlen) )
    {
		return {result : false, parameters : returnParam};
	}
    //只包含数字、字母，非纯数字，非纯字母、
    if ( !/^[a-zA-Z0-9]*$/.test($.trim(value)) || /^[0-9]*$/.test($.trim(value)) || /^[a-zA-Z]*$/.test($.trim(value)) )
    {
    	return {result : false, parameters : returnParam};
    }
	return {
		result : true,
		parameters : returnParam
	};
}, VALIDATOR_BOTH_CHARANDDIGITAL_LENGTH_RANGE);


/**
 * 字符长度校验，在UTF-8下，一个汉字算3个字符；校验字符长度不超过指定长度
 *
 * @param {number}
 *            字符长度
 */
jQuery.validator.addMethod("maxChar", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).replace(/[^\x00-\xff]/g, "xxx").length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MAX_CHAR);

/**
 * 字符长度校验，一个汉字算2个字符；校验字符长度不得小于指定长度
 *
 * @param {number}
 *            字符长度
 */
jQuery.validator.addMethod("minChar", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).replace(/[^\x00-\xff]/g, "xx").length < len) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MIN_CHAR);

/**
 * 身份证校验
 */
jQuery.validator.addMethod("idCard", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var aCity = {
		11 : "北京",
		12 : "天津",
		13 : "河北",
		14 : "山西",
		15 : "内蒙古",
		21 : "辽宁",
		22 : "吉林",
		23 : "黑龙江 ",
		31 : "上海",
		32 : "江苏",
		33 : "浙江",
		34 : "安徽",
		35 : "福建",
		36 : "江西",
		37 : "山东",
		41 : "河南",
		42 : "湖北 ",
		43 : "湖南",
		44 : "广东",
		45 : "广西",
		46 : "海南",
		50 : "重庆",
		51 : "四川",
		52 : "贵州",
		53 : "云南",
		54 : "西藏 ",
		61 : "陕西",
		62 : "甘肃",
		63 : "青海",
		64 : "宁夏",
		65 : "新疆",
		71 : "台湾",
		81 : "香港",
		82 : "澳门",
		91 : "国外 "
	};
	var iSum = 0
	var info = ""
	if (!/^\d{17}(\d|x)$/i.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	value = $.trim(value).replace(/x$/i, "a");
	if (!aCity[parseInt(value.substr(0, 2))]) {
		return {
			result : false,
			parameters : param
		};
	}
	var sBirthday = value.substr(6, 4) + "-" + Number(value.substr(10, 2))
			+ "-" + Number(value.substr(12, 2));
	var d = new Date(sBirthday.replace(/-/g, "/"));
	if (sBirthday != (d.getFullYear() + "-" + (d.getMonth() + 1) + "-" + d
			.getDate())) {
		return {
			result : false,
			parameters : param
		};
	}
	for ( var i = 17; i >= 0; i--) {
		iSum += (Math.pow(2, i) % 11) * parseInt(value.charAt(17 - i), 11);
	}
	if (iSum % 11 != 1) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IDCARD);

/**
 * 金额校验，支持两位小数，支持正负；大小小于指定值
 *
 * @param {number}
 *            金额最大值（开区间），可选
 */
jQuery.validator.addMethod("money", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var max = param[0];

	if (max && (Number(value) >= Number(max))) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^(\-)?\d+\.?(\d{1,2})?$/.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MONEY);
/**
 * 正数金额校验，支持两位小数；大小小于指定值
 *
 * @param {number}
 *            金额最大值（开区间），可选
 */
jQuery.validator.addMethod("positiveMoney", function(value, element, param) {
    if (value == "") {
        return {
            result : true
        };
    }
    var max = param[0];

    if (max && (Number(value) >= Number(max))) {
        return {
            result : false,
            parameters : param
        };
    }
    if(Number(value) < 0){
        return {
            result : false,
            parameters : param
        };
    }
    if (!/^(\-)?\d+\.?(\d{1,2})?$/.test(value)) {
        return {
            result : false,
            parameters : param
        };
    }
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_MONEY);

/**
 * 当前输入框的数值小于指定输入框数值
 *
 * @param {string}
 *            指定输入框id
 */
jQuery.validator.addMethod("smallThan",
		function(value, element, param) {
			if (value == "") {
				return {
					result : true
				};
			}
			var lastIndex = param[0].lastIndexOf(".");
			var id = (lastIndex == -1) ? param[0] : param[0]
					.substring(lastIndex + 1);
			var jqArea = $(document.getElementById(id));
			var jqInput = $(":input", jqArea).add(jqArea.filter(":input"));
			var target = jqInput.unbind(".validate-smallThan").bind(
					"change.validate-smallThan", function() {
						$(element).valid();
					});
			var isExisted = (lastIndex == -1) ? false
					: target.attr("name") != param[0];
			return {
				result : isExisted || value < target.val(),
				parameters : param
			};

		}, VALIDATOR_SMALLTHAN);

/**
 * 校验证件号码，证件号码可包含数字，字母，下划线及连字符
 *
 * @param {number}
 *            指定证件号码位数，可选
 */
jQuery.validator.addMethod("card", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if (len && $.trim(value).length != len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^[\w-]+$/.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};

}, VALIDATOR_CARD);

/**
 * 校验特殊字符。
 *
 * @param {number}
 *            指定证件号码位数，可选
 */
jQuery.validator.addMethod("checkSpecialChar", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	debugger;
	var len = param[0];
	if (len && $.trim(value).length != len) {
		return {
			result : false,
			parameters : param
		};
	}
	// var keyword =
	// /\.|\`|\~|\!|\@|\#|\$|\%|\^|\+|\*|\&|\/|\?|\||\:|\.|\{|\}|\(|\)|\''|\;|\=|"/;
	//var keyword = /\$|\^|\[|\]|\{|\}|\<|\>|\+|\\|\||\、|\‘|\’|\！|\；|\×|\//;
	//xwx373692  DTS2016072605711
	var keyword = /\$|\^|\[|\]|\{|\}|\<|\>|\+|\\|\||\、|\‘|\’|\！|\；|\×/;
	if (keyword.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};

}, VALIDATOR_SPECIALCHAR);

/**
 * 校验特殊字符。
 *
 * @param {number}
 *            指定证件号码位数，可选
 */
jQuery.validator.addMethod("checkSpecialCharOrg", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	debugger;
	var len = param[0];
	//长度校验
	if (len && $.trim(value).length != len) {
		return {
			result : false,
			parameters : param
		};
	}
	//只允许输入数字或字母(除了数字和字母以外均为特殊字符)
	if (!/^[\da-zA-Z0-9]*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};

}, VALIDATOR_SPECIALCHAR);

/**
 * JS注入校验
 *
 */
jQuery.validator.addMethod("jsInput", function(value, element, param) {
	debugger;
	var value = value.toUpperCase();
	if (value.indexOf("<") >= 0 || value.indexOf(">") >= 0
			|| value.indexOf("/") >= 0 || value.indexOf("SCRIPT") >= 0) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_JSINPUT);
//ADD 2015-07-13 by l00289267
/**
 * 字符长度校验，一个汉字算2个字符；校验字符长度必须为多少位
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("char", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var len = param[0];
	if($.trim(value).replace(/[^\x00-\xff]/g, "xx").length != len)
	{
	    return {result : false, parameters : param};
	}
	return {result : true, parameters : param};
}, VALIDATOR_CHAR);

/**
 * 只能为数字或者字母
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("onlyCharAndDigital", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var len = param[0];
    if ($.trim(value).length != len)
    {
		return {result : false, parameters : param};
	}
    if (!/^[\da-zA-Z0-9]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_ONLY_CHARANDDIGITAL);


/**
 * 只能为数字或者字母
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("onlyCharAndDigit4Nigeria", function (value,element,param)
{
	debugger;
	if(value==""){
		return {result : true};
	}

    if (!/^[a-zA-Z0-9]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}
	return {result : true, parameters : param};
}, VALIDATOR_ONLY_CHARANDDIGITAL);

/**
 * 数字或者字母
 *
 */
jQuery.validator.addMethod("charDigitalLimit", function (value, element, param){
	debugger;
	if(value==""){
		return {result : true};
	}
    if (!/^[\da-zA-Z0-9]*$/.test($.trim(value))){
    	return {result : false, parameters : param};
	}
	return {result : true, parameters : param};
}, VALIDATOR_CHARDIGITALLIMIT);
/**
 * 只能为数字或者字母和下划线
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("CharDigitalUnder", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    if (!/^[\da-zA-Z0-9_]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_ONLY_CHARDIGITALUNDER);
/**
 * 校验特殊字符。
 *            DTS2017041408271
 *
 */
jQuery.validator.addMethod("verificationSpecialChar", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	debugger;
	var len = param[0];
	if (len && $.trim(value).length != len) {
		return {
			result : false,
			parameters : param
		};
	}
    var keyword =/\.|\`|\~|\!|\@|\#|\$|\%|\^|\+|\*|\&|\/|\?|\||\:|\.|\{|\}|\(|\)|\''|\;|\=|"/;
	if (keyword.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_SPECIALCHAR);

/**
 * 只能为数字或者字母和下划线，且以字母开头
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("CharStartDigitalUnder", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
	if (!/^[a-zA-Z][\w]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_ONLY_CHARSTARTDIGITALUNDER);

/**
 * 只能为数字或者字母和-
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("CharDigitalMinus", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    if (!/^[\da-zA-Z0-9-]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_SPECIALCHAR);
/**
 * 只能为数字+字母，指定长度
 *
 * @param {minlength}{maxlength} 字符长度
 */
jQuery.validator.addMethod("onlyCharAndDigitalLengthRange", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var minlen = param[0];
    var maxlen = param[1];
    if (($.trim(value).length < minlen) || ($.trim(value).length > maxlen))
    {
		return {result : false, parameters : param};
	}
   /* if (!/^[\da-zA-Z0-9]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}*/
    //非纯数字、纯字母、
    if (!/^[a-zA-Z]*$/.test($.trim(value)) && !/^[a-zA-Z]*$/.test($.trim(value)) )
    {
    	return {result : false, parameters : param};
    }

	return {result : true, parameters : param};
}, VALIDATOR_BOTH_CHARANDDIGITAL_LENGTH_RANGE);

jQuery.validator.addMethod("onlynumberLengthRange", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var minlen = param[0];
    var maxlen = param[1];
    if ( ($.trim(value).length < minlen) || ($.trim(value).length > maxlen) )
    {
		return {result : false, parameters : param};
	}
	return {result : true, parameters : param};
}, VALIDATOR_ONLY_NUMBER_LENGTH_RANGE);

/**
 * 只能为正整数
 *
 * @param {onlynumber} 字符长度
 */
jQuery.validator.addMethod("onlynumber", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var len = param[0];
    if (len && $.trim(value).length != len)
    {
		return {result : false, parameters : param};
	}
    if (!/^[1-9]\d*$/.test(value))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_NUMBER);

/**
 * 只能为数字
 *
 * @param {onlynumber} 字符长度
 */
jQuery.validator.addMethod("onlynumberandzore", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var len = param[0];
    if (len && $.trim(value).length != len)
    {
		return {result : false, parameters : param};
	}
    if (!/^[1-9]\d*$/.test($.trim(value)) && 0 != $.trim(value))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_NUM);
/**
 * 只能为数字
 *
 * @param {onlynumber} 字符长度
 */
jQuery.validator.addMethod("onlynum", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}

    if (!/^[0-9]\d*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_NUM);

/**
 * 只能为正整数
 *
 * @param {positivenumber} 字符长度
 */
jQuery.validator.addMethod("positivenumber", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var len = param[0];
    if (len && $.trim(value).length != len)
    {
		return {result : false, parameters : param};
	}
    if (!/^[0-9]*[1-9][0-9]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_NUMBER);

/**
 * 两位小数校验
 *
 * @param {positivenumber} 字符长度
 */
jQuery.validator.addMethod("ccydoublenumber", function (value, element, param)
{
			debugger;
			if(value==""){
				return {result : true};
			}
		    var len = param[0];
		    if (len && $.trim(value).length != len)
		    {
				return {result : false, parameters : param};
			}
		    if (!/^\d+\.?(\d{1,2})?$/.test($.trim(value)))
			{
		    	return {result : false, parameters : param};
			}

			return {result : true, parameters : param};
}, "只能输入两位小数");

/**
 * 只能为正整数且不能以0开头
 *
 * @param {positivenumber} 字符长度
 */
jQuery.validator.addMethod("nostartzeropositivenumber", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    var len = param[0];
    if (len && $.trim(value).length != len)
    {
		return {result : false, parameters : param};
	}
    if (!/^[1-9]*[1-9][0-9]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_POSITIVE_NUMBER);

/**
 * 只能为正数
 *
 * @param {positivenumber} 字符长度
 */
jQuery.validator.addMethod("positivenum", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}

	var num = new Number($.trim(value));
	if(!isNaN(num) && num.valueOf() > 0) {
		return {result : true};
	} else {
		return {result : false};
	}

}, VALIDATOR_POSITIVE_NUM);


/**
 * 电话号码校验
 */
jQuery.validator.addMethod("telephone", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^((0\d{2,3}\d{7,8})|(0\d{2,3}-\d{7,8})|(1[345789]\d{9})|(10648\d{8})|(10647\d{8})|(14400\d{8})|(1023\d{9})|(14401\d{8})|(14402\d{8})|(14403\d{8}))$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_TELEPHONE);

/**
 * DTS2017052700833 电话号码固话校验
 */
jQuery.validator.addMethod("telephonefixed", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	//校验手机号和固话
	if (!/^((0\d{2,3}\d{7,8})|(0\d{2,3}-\d{7,8})|(1[345789]\d{9})|(10648\d{8})|(10647\d{8})|(\d{10}))$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_TELEPHONE);

/**
 * 尼日利亚电话校验
 */
jQuery.validator.addMethod("telephoneqss", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{10}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_TELEPHONEQSS);
/**
 * 尼日利亚电话号码校验
 */
jQuery.validator.addMethod("nigeriatelephone", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d{10}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_TELEPHONE);

/**
 * 电话号码校验
 */
jQuery.validator.addMethod("onlymobilephone", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^1[345789]\d{9}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_ONLY_MOBILEPHONE);

/**
 * 电话号码校验,企业名片
 */
jQuery.validator.addMethod("busicardphone", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^158\d{8}$|182\d{8}$|183\d{8}$|152\d{8}$|188\d{8}$|151\d{8}$|134\d{8}$|135\d{8}$|136\d{8}$|137\d{8}$|138\d{8}$|139\d{8}$|159\d{8}$|150\d{8}$|147\d{8}$|157\d{8}$|187\d{8}$|198\d{8}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_TELEPHONE);

/**
 * 校验号码是否是中国移动手机号码
 */
jQuery.validator.addMethod("mobilephone", function(value, element, param)
{
	debugger;
	if (value == "")
	{
		return {result : true};
	}
	var $scope = $(document).scope();
	if ($scope.$Page.dictList)
	{
		var phonerule = $scope.$Page.dictList["MOBILEPHONE_NUMBER_RULE"];
		if (phonerule)
		{
			for (var i = 0, len = phonerule.length; i< len; i ++ )
			{
				var re = new RegExp( phonerule[i].key);
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
	}
	return {result : false};
}, VALIDATOR_MOBILEPHONE);

/**
 * 校验号码是否是合法的固定电话号码
 */
jQuery.validator.addMethod("fixlinenumber", function(value, element, param)
{
	debugger;
	if (value == "")
	{
		return {result : true};
	}

	var $scope = $(document).scope();
	if ($scope.$Page.dictList)
	{
		var phonerule = $scope.$Page.dictList["FIXLINE_NUMBER_RULE"];
		if (phonerule)
		{
			for (var i = 0, len = phonerule.length; i< len; i ++ )
			{
				var re = new RegExp(phonerule[i].itemCode);
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
	}
	return {result : false};
}, VALIDATOR_FIXLINENUMBER);

/**
 * 校验号码是否是合法的固定电话号码,095xxxxxxxx,或者手机号码
 */
jQuery.validator.addMethod("phoneandfixlinenumber", function(value, element, param)
{
	debugger;
	var msg = "";
	if (value == "")
	{
		return {result : true};
	}
	if(-1 !== value.indexOf('-'))
	{
		if (!/^095\d{1}-\d{7}$/.test($.trim(value)))
		{
			msg = "无效的固话号码,必须以059开头";
			return {result : false};
		}
	}else{
		if (!/^((1[345789]\d{9})|(10647\d{8})|(10648\d{8}))$/.test($.trim(value)))
		{
			msg = VALIDATOR_PHONE;
			return {result : false};
		}
	}
	return {result : true};
}, jQuery.validator.format("msg"));

/**
* 英文校验
*/
jQuery.validator.addMethod("checkEn", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[A-Za-z\.]+$/gi.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_TUREEN);
/**
* 英文校验,点不在第一位
*/
jQuery.validator.addMethod("checkEn2", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if ((value.indexOf(".") == 0)||(!/^[A-Za-z\.]+$/gi.test($.trim(value))) ) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_TUREEN);
/**
* 校验号码是否是带有@符号的宽带号码
*/
jQuery.validator.addMethod("bandnumberiscontainat", function(value, element, param)
{
	debugger;

	if (value == "")
	{
		return {result : true};
	}

	var $scope = $(document).scope();
	if ($scope.$Page.dictList)
	{
		// 1. 校验宽带账号是否是带有@符号
		//var reg = /.*@.*$/; //DTS2016101908547
		var reg = /^[a-zA-Z0-9.]{0,}@[a-zA-Z0-9.]{0,}$/;
		if (reg.test($.trim(value)))
		{
			return {result : true};
		}
	}
	return {result : false};
}, VALIDATOR_BROADBANDNUMBER);

/**
* 校验带宽是否是正整数加G或者M组成
*/
jQuery.validator.addMethod("bandwidthwithunit", function(value, element, param)
{
	debugger;

	if (value == "")
	{
		return {result : true};
	}

	if ((/^[0-9]*[1-9][0-9]*M$/.test($.trim(value))) || (/^[0-9]*[1-9][0-9]*G$/.test($.trim(value))))
	{
		return {result : true};
	}

	return {result : false};
}, VALIDATOR_BANDWIDTHWITHLIMIT);

/**
 * 校验号码是否合法的移动小区宽带号码
 */
jQuery.validator.addMethod("communitybandnumber", function(value, element, param)
{
	debugger;

	if (value == "")
	{
		return {result : true};
	}

	var $scope = $(document).scope();
	if ($scope.$Page.dictList)
	{
		// 1 校验是否小区宽带 例如：nj+任意数字
		var xqkdphonerule = $scope.$Page.dictList["XQKD_PREFIX"];
		if (xqkdphonerule)
		{
			for (var i = 0, len = xqkdphonerule.length; i< len; i ++ )
			{
				var re = new RegExp( xqkdphonerule[i].dictName + "[0-9]+" );
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
		// 2 校验是否铁通宽带  例如： ttnj+任意数字
		var ttrhkdphonerule = $scope.$Page.dictList["TTRHKD_PREFIX"];
		if (ttrhkdphonerule)
		{
			for (var j = 0, len = ttrhkdphonerule.length; j< len; j ++ )
			{
				var re = new RegExp( ttrhkdphonerule[j].dictName + "[0-9]+" );
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
	}
	return {result : false};
}, VALIDATOR_COMMUNITYBANDNUMBER);

/**
 * 校验号码是否合法的移动校园宽带号码
 */
jQuery.validator.addMethod("campusbandnumber", function(value, element, param)
{
	debugger;
	if (value == "")
	{
		return {result : true};
	}

	var $scope = $(document).scope();
	if ($scope.$Page.dictList)
	{
		// 1 获取中国移动号码规则
		var phonerule = $scope.$Page.dictList["MOBILEPHONE_NUMBER_RULE"];
		if(phonerule){
			var phonerulelen = phonerule.length;
		}
		// 2  校验是否校园宽带   例如：nj+手机号码
		var xqkdphonerule = $scope.$Page.dictList["XQKD_PREFIX"];
		if (xqkdphonerule)
		{
			for (var i = 0, len = xqkdphonerule.length; i< len; i ++ )
			{
				for (var j = 0; j < phonerulelen; j ++ )
				{
					var re = new RegExp( xqkdphonerule[i].dictName + phonerule[j].itemCode );
					if (re.test($.trim(value)))
					{
						return {result : true};
					}
				}

			}
		}
		// 3 校验是否铁通宽带   例如： ttnj+手机号码
		var ttrhkdphonerule = $scope.$Page.dictList["TTRHKD_PREFIX"];
		if (ttrhkdphonerule)
		{
			for (var m = 0, len = ttrhkdphonerule.length; m< len; m ++ )
			{
				for (var n = 0; n < phonerulelen; n ++ )
				{
					var re = new RegExp( ttrhkdphonerule[m].dictName + phonerule[n].itemCode );
					if (re.test($.trim(value)))
					{
						return {result : true};
					}
				}
			}
		}
	}
	return {result : false};
}, VALIDATOR_CPMPUSBANDNUMBER);

/**
 * 校验号码是否合法的移动公司号码（包括：移动手机号码、小区款带宽号码、校园宽带号码、固话号码）
 */
jQuery.validator.addMethod("chinamobilenumber", function(value, element, param)
{
	debugger;
	if (value == "")
	{
		return {result : true};
	}

	var $scope = $(document).scope();
	if ($scope.$Page.dictList)
	{
		// 1 校验是否中国移动号码
		var mobilephonerule = $scope.$Page.dictList["MOBILEPHONE_NUMBER_RULE"];
		if (mobilephonerule)
		{
			for (var i = 0, len = mobilephonerule.length; i< len; i ++ )
			{
				var re = new RegExp( mobilephonerule[i].itemCode );
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}

		// 2校验是否固话号码
		var fixlinenumrule = $scope.$Page.dictList["FIXLINE_NUMBER_RULE"];
		if (fixlinenumrule)
		{
			for (var i = 0, len = fixlinenumrule.length; i< len; i ++ )
			{
				var re = new RegExp( fixlinenumrule[i].itemCode );
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
		// 3  校验是否小区宽带 例如：nj+任意数字 (校园宽带也满足此条件)
		var xqkdphonerule = $scope.$Page.dictList["XQKD_PREFIX"];
		if (xqkdphonerule)
		{
			for (var i = 0, len = xqkdphonerule.length; i< len; i ++ )
			{
				var re = new RegExp( xqkdphonerule[i].dictName + "[0-9]+" );
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
		// 4 校验是否铁通宽带  例如： ttnj+任意数字
		var ttrhkdphonerule = $scope.$Page.dictList["TTRHKD_PREFIX"];
		if (ttrhkdphonerule)
		{
			for (var j = 0, len = ttrhkdphonerule.length; j< len; j ++ )
			{
				var re = new RegExp( ttrhkdphonerule[j].dictName + "[0-9]+" );
				if (re.test($.trim(value)))
				{
					return {result : true};
				}
			}
		}
		// 5检验bx开头的服务号码  wwx377455
		var regBroad = /^(([a-z]+[0-9]+)|([0-9]+[a-z]+)|([a-z]+\_[0-9]+)|([0-9]+\_[a-z]+))[a-z0-9]*$/i;
		if (regBroad.test($.trim(value))){
			return {result : true};
			}
	}
	return {result : false};
}, VALIDATOR_CHINAMOBILE);
/**
 * 校验号码是否合法的移动公司号码和固话号码
 */
jQuery.validator.addMethod("chinamobilenumberz", function(value, element, param)
		{
			debugger;
			if (value == "")
			{
				return {result : true};
			}

			var $scope = $(document).scope();
			if ($scope.$Page.dictList)
			{
				// 1 校验是否中国移动号码
				var mobilephonerule = $scope.$Page.dictList["MOBILEPHONE_NUMBER_RULE"];
				if (mobilephonerule)
				{
					for (var i = 0, len = mobilephonerule.length; i< len; i ++ )
					{
						var re = new RegExp( mobilephonerule[i].itemCode );
						if (re.test($.trim(value)))
						{
							return {result : true};
						}
					}
				}

				// 2校验是否固话号码
				var fixlinenumrule = $scope.$Page.dictList["FIXLINE_NUMBER_RULE"];
				if (fixlinenumrule)
				{
					for (var i = 0, len = fixlinenumrule.length; i< len; i ++ )
					{
						var re = new RegExp( fixlinenumrule[i].itemCode );
						if (re.test($.trim(value)))
						{
							return {result : true};
						}
					}
				}
			}
			return {result : false};
		}, VALIDATOR_CHINAMOBILEZ);
jQuery.validator.addMethod("ecuadormobilenumber", function(value, element, param)
		{
			debugger;
			if (value == "")
			{
				return {result : false};
			}
			var reg = /^(0|[0-9]\d*)$/;
			if(reg.test($.trim(value))){
				return {result : true};
			}
			return {result : false};
		}, VALIDATOR_ECUADORMOBILE);

/**
 * 下拉框有“请选择”，如果没选择值，报错。
 */
jQuery.validator.addMethod("hintsvalidate", function(value, element, param)
{
    debugger;
    if (value == "请选择")
    {
        return {
            result : false,
            parameters : param
        };
    }
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_LATER_PLEASE_CHOOSE);

jQuery.validator.addMethod("imspasswordcheck", function(value, element, param)
{
    debugger;
	//^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[a-zA-Z0-9.!~/@#$%^&*\/,:;""-_=+].{8,14}$
    var imspasswordcheck = RegExp('^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*([.!~/@#$%^&*,:;""-]|[\/\|\{\}‘’“” <>()\?\'_=+])).{8,14}$');
    if(imspasswordcheck.test($.trim(value)))
    {
    	return {result : true};
    }
    return {result : false};
}, "密码不符合校验规则");

/**
 * 短号必须是以6/7/8/9开头且长度为3-6位的数字
 */
jQuery.validator.addMethod("shortNumber1", function(value, element, param)
{
    debugger;
    if (!/^[26789][0-9]{2,5}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_SHORTNUMBER_PATTERN1);

/**
 * 短号录入非0、1、2、9开头的3-6位数字
 */
jQuery.validator.addMethod("shortNumber2", function(value, element, param)
{
    debugger;
    if (!/^[345678][0-9]{2,5}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_SHORTNUMBER_PATTERN3);

/**
 * 默认时段:  格式：HH&HH
 */
jQuery.validator.addMethod("periodTime", function(value, element, param)
{
    debugger;
    if (!/^[0-9]{2}[&][0-9]{2}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_PERIODTIME_PATTERN);

/**
 * IMSV网固话号头不能为0,1,9
 */
jQuery.validator.addMethod("shortPrefix", function(value, element, param)
{
    debugger;
    if (!/^[2345678]$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_SHORTPREFIX_PATTERN);

/**
 * 以1065096开头的服务代码
 */
jQuery.validator.addMethod("serviceCodePreFix1065096", function(value, element, param)
{
    debugger;
    if (!/^1065096.*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_SERVICECODEPREFIX1065096);

/**
 * 数字长度3-6位,以77或79开头
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("between", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : false
		};
	}

	if (($.trim(value).length < 3) || ($.trim(value).length > 6))  {
		return {
			result : false,
			parameters : param
		};
	}

	if ((!/^77./.test($.trim(value))) && (!/^79./.test($.trim(value)))) {
		return {
			result : false,
			parameters : param
		};
	}

	if (!/^\d*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_DIGIT_BETWEEN);

/**
 * 数字位数校验，数字不能小于指定的位数
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("minDigit", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).length < len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^\d*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MIN_DIGIT);

/**
* 密码校验
*
* @param {number}
* 数字位数
*/
jQuery.validator.addMethod("numAndLetterDigit", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
		result : true
	};
	}
	var len = param[0];
	if (value.length < len) {
		return {
			result : false,
			parameters : param
		};
	}
	if (!/^([A-Za-z]|[0-9]){4,15}$/.test(value)) {  //DTS2018060408886
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_NUMANDLETTERDIGIT_BETWEEN);

/**
 * 4001开头的10位数字
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("num400", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : false
		};
	}

	if (!/^(4001|4007)\d{6}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_NUM_START);

/**
 * param: [regExp, tips]
 */
jQuery.validator.addMethod("regValidate", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var reg = new RegExp(param[0]);
	if (reg.test(value)) {
		return {
			result : true
		};
	}
	$.validator.messages.regValidate = param[1];
	return {
		result : false
	};
});

/**
 * 判断正整数或百分数
 */
jQuery.validator.addMethod("percent", function(value, element, param) {
	debugger;
    if (!/^(100|[1-9]\d|\d)(.\d{1,2})?%$/.test(value)&&!/^[1-9]\d*$/.test(value)&&(/^[1-9]\d*$/.test(value))-1<0) {
        return { result: false, parameters: param };
    }
    return { result: true, parameters: param };
}, VALIDATOR_PERCENT);

/**
 *
 *
 */

jQuery.validator.addMethod("shortNumber2", function(value, element, param)
{
    debugger;
    if (value == "") {
        return {
            result : true
        };
    }
    if('61860'==$.trim(value)){
    	return {
			result : false,
			parameters : param
		};
    }
  if (!(/^[5][012346789][0-9]{1,4}$/.test($.trim(value)) || /^[6][1-9][0-9]{1,4}$/.test($.trim(value)))) {
		return {
			result : false,
			parameters : param
		};
	}
    return {
        result : true,
        parameters : param
    };
}, VALIDATOR_SHORTNUMBER_PATTERN2);



/**
 *nrly fn number
 */
jQuery.validator.addMethod("fnNumber", function(value, element, param)
		{
		    debugger;
		    var pNumber=/^[1][345789][0-9]{9}$/;
		    if (!/^(\(\d{3,4}\)|\d{3,4}-|\s)?\d{13,14}$/.test($.trim(value))) {
				return {
					result : false,
					parameters : param
				};
			}
		    if($.trim(value).substring(0,1)=="0"||($.trim(value).length==12)){
		    	return {
					result : false,
					parameters : param
				};

		    }
		    if($.trim(value).length==11&&!pNumber.test($.trim(value))){
		    	return {
					result : false,
					parameters : param
				};
		    }
		    if($.trim(value).length==13&&!pNumber.test($.trim(value).substring(2,13))){
		    	return {
					result : false,
					parameters : param
				};
		    }
		    if($.trim(value).length==14&&!pNumber.test($.trim(value).substring(3,14))){
		    	return {
					result : false,
					parameters : param
				};
		    }
		    return {
		        result : true,
		        parameters : param
		    };
		}, VALIDATOR_NUMBER_NRLY);
/**
 * 黑名单失效日期不能早于当前时间
 */
jQuery.validator.addMethod("dateCompareCurDate", function(value, element, param) {
	debugger;
    if (value == "") {
        return {
            result : false
        };
    }
    var newDate = value.substr(6, 4) + "/" + value.substr(3, 2) + "/" + value.substr(0, 2)
		+ " " + value.substr(11, 2) + ":" + value.substr(14, 2) + ":" + value.substr(17, 2);
    var keydate = new Date(Date.parse(newDate));
    var date =new Date();
    if (keydate < date) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_DATE_NOTSMALL_CURDATE);

/**
 * 改付费计划失效日期不能早于当前日期
 */
jQuery.validator.addMethod("dateNotBeforeCurDate", function(value, element, param) {
	debugger;
    if (value == "") {
        return {
            result : false
        };
    }
    var newDate = value.substr(0, 4) + "/" + value.substr(5, 2) + "/" + value.substr(8, 2)
	+ " " + "23:59:59";
    var keydate = new Date(Date.parse(newDate));
    var date =new Date();
    if (keydate < date) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_DATE_NOTSMALL_CURDATE);


/**
 * 校验发送时间是否超过当前时间
 */
jQuery.validator.addMethod("timeCompareCurDate", function(value, element, param) {
	debugger;
    if (value == "") {
        return {
            result : false
        };
    }
    var newDate = value.substr(6, 4) + "/" + value.substr(3, 2) + "/" + value.substr(0, 2)
		+ " " + value.substr(11, 2) + ":" + value.substr(14, 2) + ":" + value.substr(17, 2);
    var keydate = new Date(Date.parse(newDate));
    var date =new Date();
    if (keydate < date) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_DATE_NOTSMALL_NOW);
/**
 * 校验邮件发送时间是否超过当前时间
 */
jQuery.validator.addMethod("emailTimeCompareCurDate", function(value, element, param) {
	debugger;
    if (value == "") {
        return {
            result : false
        };
    }
    var newDate = value.substr(6, 4) + "/" + value.substr(3, 2) + "/" + value.substr(0, 2)
		+ " " + value.substr(11, 2) + ":" + value.substr(14, 2) + ":" + value.substr(17, 2);
    var keydate = new Date(Date.parse(newDate));
    var date =new Date();
    if (keydate < date) {
        return {
            result : false
        };
    }
    return {
        result : true
    };
}, VALIDATOR_EMAILDATE_NOTSMALL_NOW);

/**
 * 所选时间必须早于等于当前时间
 *
 */
jQuery.validator.addMethod("EalierToday", function(value, element, param) {
	debugger;
	 try {
		 if(!value){
			 return { result: true, parameters: param }
		 }
	        var thisInstance = jQuery.datetimepicker._getInst(element._calId);
	        var thisDateFormat = thisInstance._get("dateFormat");
	        var thisFormatConfig = thisInstance._getFormatConfig();
	        var thisDate = jQuery.datetimepicker.parseDate(thisDateFormat, value, thisFormatConfig);
	        var date = new Date;
	        date.setHours(0);
	        date.setMinutes(0);
	        date.setSeconds(0);
	        date.setMilliseconds(0)
	    } catch (e) {
	        return { result: false, parameters: param }
	    }
	    return { result: thisDate && thisDate <= date, parameters: param }
}, VALIDATOR_MORETHANTIME);

/**
 * 尼日利亚集团用户注册时注册时间必须早于等于当前时间
 * value格式必须是 "dd/MM/yyyy hh:mm:ss"
 */
jQuery.validator.addMethod("timeNotAfterCurDate", function(value, element, param) {
	debugger;
    if (value == "") {
        return {
            result : false
        };
    }

    var day = parseInt(value.substring(0,2));
    var month = parseInt(value.substring(3,5)) - 1;
    var year = parseInt(value.substring(6,10));
    var hour = parseInt(value.substring(11,13));
    var minute = parseInt(value.substring(14,16));
    var second = parseInt(value.substring(17,19));
    var keydate = new Date(year,month,day,hour,minute,second);

    var date = new Date();
    if (keydate <= date) {
        return {
            result : true
        };
    }
    return {
        result : false
    };
}, VALIDATOR_DATE_NOTAFTER_NOW);

/**
 * 群组（包含兄弟群组，状态为有效或挂起）的Limit Value数量等于或少于父群组的Limit Value数量。
 *
 * @param {number} 最大值
 */
jQuery.validator.addMethod("maxLimitValue", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (param[0] && ($.trim(value)>param[0])) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MAXGRPLIMITVALUE);

/**
 * 群组的Limit Value数量等于或者大于所有子群的Limit Value数量之和（包括有效和挂起状态）。
 *
 * @param {number} 最小值
 */
jQuery.validator.addMethod("minLimitValue", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (param[0] && ($.trim(value)<param[0])) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MINGRPLIMITVALUE);

/**
 * Allowed Max Group Member Amount等于或者大于群组有效或挂起的成员数量。
 *
 * @param {number} 最小值
 */
jQuery.validator.addMethod("minMaxMemAmntVali", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if (param[0] && ($.trim(value)<param[0])) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MAXMEMAMOUNT);


/**
 * param: [regExp, tips]
 */
jQuery.validator.addMethod("chineseSign", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[\u4E00-\u9FFF]{2,4}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHINESE);


/**
 * param: [regExp, tips]
 * 姓名大于等于两个汉字
 */
jQuery.validator.addMethod("chineseSignTwo", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[\u4E00-\u9FFF]{2,50}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHINESE_TWO);



/**
 * param: [regExp, tips]
 * 证件地址至少8个汉字
 */
jQuery.validator.addMethod("chineseSignEight", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[\u4E00-\u9FFF]{8,100}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHINESELESS_EIGHT);


/**
 * 不超过8个汉字检验
 */
jQuery.validator.addMethod("chineseSignNum", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[\u4E00-\u9FFF]{1,8}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHINESE_NUM);
/**
 * 不超过8个汉字检验3-8
 */
jQuery.validator.addMethod("chineseSignNum", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[\u4E00-\u9FFF]{3,8}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHINESE_NUM);
/**
 * 不能超过9位数
 */
jQuery.validator.addMethod("pureNumBer", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[0-9]\d{0,8}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_PureNumBer);


/**
 * param: [regExp, tips]
 * 输入最少中文字符
 */
jQuery.validator.addMethod("chineseSignWithLess", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len =param[0];
	if ($.trim(value).length < len)
    {
		return {result : false, parameters : param};
	}
	var name = /[\u4E00-\u9Fa5]$/;


	var cTemp = 0;
	for(var i = 0;i < len; ++i){

		if(name.test(value[i])){
			cTemp += 1;
		}
	}
	if (cTemp >= len)
	{
		return {
			result : true,
			parameters : param
		};
	}
	else
	{
		return {
			result : false,
			parameters : param
		};
	}

}, VALIDATOR_ZHSIGNLESS);

/**
 * 证件地址至少8位汉字
 */
jQuery.validator.addMethod("chineseSignlistEight", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	if (!($.trim(value).length<8))
    {
		return {result : false, parameters : param};
	}

	if (!/^[\u4E00-\u9FFF]{0,}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ZHSIGNLEN_LISTEIGHT);

/**
 * 校验1-8位汉字
 */
jQuery.validator.addMethod("chineseSignOneToEight", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	if (!($.trim(value).length>=1 && $.trim(value).length<=8))
    {
		return {result : false, parameters : param};
	}

	if (!/^[\u4E00-\u9FFF]{0,}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ZHSIGNLEN_ONETOEIGHT);

/**
 * 校验大于等于2个汉字
 */
jQuery.validator.addMethod("chineseSignTwoToMax", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	if (($.trim(value).length<=1))
    {
		return {result : false, parameters : param};
	}

	if (!/^[\u4E00-\u9FFF]{2,}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ZHSIGNLEN_TWOTOMAX);


/**
 * 输入联系人校验
 **/
jQuery.validator.addMethod("ralateName", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^([\u4e00-\u9fa5]|[a-zA-Z0-9])+$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_RALATENAME);

/**
 * 输入邮箱校验
 */
jQuery.validator.addMethod("ralatEmail", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_RALATEMAIL);
/**
 * 只能输入中文校验
 */
jQuery.validator.addMethod("chineseOnly", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[\u4E00-\u9FFF]{0,}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHINESE_ONLY);
/**
 * 英文签名校验
 */
jQuery.validator.addMethod("englishSign", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[a-zA-Z]{1,16}$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ENGLISH);

/**
 * 校验大于0的偶数
 */
jQuery.validator.addMethod("evenNum", function(value, element, param) {
	debugger;

	if (!value || value <= 0 || value % 2 != 0) {
		return {
			result : false
		};
	}

	return {
		result: true
	};
}, VALIDATOR_EVENNUM);


/**
 * 带宽速率校验，只能输入正整数，并以单位M结尾
 */
jQuery.validator.addMethod("bandWidthRate", function(value, element, param) {
	debugger;

	if (value == "") {
		return {
			result : true
		};
	}

	if (!/^[1-9]\d*M$/.test($.trim(value))) {
		return {
			result: false
		};
	}

	return {
		result: true
	};
}, VALIDATOR_BANDWIDTH_RATE);

/**
 * 校验中文或者英文字符，但总长不可超过8个字（每个英文字母算一个字）
 *
 * @param {number}
 * 字符长度
 */
jQuery.validator.addMethod("maxZhOrEnLen", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).replace(/[\u4e00-\u9fa5_a-zA-Z]/g, "x").length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ZHSIGNLEN);


/**
 * IP地址不能为127.0.0.1
 *
 */
jQuery.validator.addMethod("ipNoLocal", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	if ('127.0.0.1'==$.trim(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IPNOLOCAL);


/**
 * IP地址字符串校验不能为127.0.0.1
 *
 */
jQuery.validator.addMethod("ipStrNoLocal", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var str = $.trim(value);
	var ipStr = str.split(",");
	for(var i=0;i<ipStr.length;i++)
    {
		if (ipStr[i] == "") {
			continue;
		}
        if ('127.0.0.1'==ipStr[i])
        {
        	return {
    			result : false,
    			parameters : param
    		};
        }
    }
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IPNOLOCAL);

/**
 * IP地址字符串校验
 *
 */
jQuery.validator.addMethod("ipStr", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var str = $.trim(value);
	var ipStr = str.split(",");
	var exp=/^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
	for(var i=0;i<ipStr.length;i++)
    {
		if (ipStr[i] == "") {
			continue;
		}
        var reg = ipStr[i].match(exp);
        if(reg==null)
        {
        	return {
    			result : false,
    			parameters : param
    		};
        }
    }
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IPSTR);

/**
 * 请输入正确的子网掩码
 *
 */
jQuery.validator.addMethod("checkSubnet", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var str = $.trim(value);
	var checkSubnet = str.split(",");
	var exp=/^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/;
	for(var i=0;i<checkSubnet.length;i++)
    {
		if (checkSubnet[i] == "") {
			continue;
		}
        var reg = checkSubnet[i].match(exp);
        if(reg==null)
        {
        	return {
    			result : false,
    			parameters : param
    		};
        }
    }
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHECKSUBNET);
/**
 * 默认网关,DNS(只进行了数字+点（.）的校验)
 *
 */
jQuery.validator.addMethod("checkDNS", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var str = $.trim(value);
	var checkDNS = str.split(",");
	var exp=/^\d+.\d+.\d+.\d+$/;
	for(var i=0;i<checkDNS.length;i++)
    {
		if (checkDNS[i] == "") {
			continue;
		}
        var reg = checkDNS[i].match(exp);
        if(reg==null)
        {
        	return {
    			result : false,
    			parameters : param
    		};
        }
    }
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_CHECKDNS);
/**
 * 非负数值校验
 */
jQuery.validator.addMethod("nonNegative", function (value, element, param)
{
    debugger;
    if(value==""){
        return {result : true, parameters: param };
    }

    var num = new Number($.trim(value));
    if(!isNaN(num) && num.valueOf() >= 0) {
        return {result : true, parameters: param };
    } else {
        return {result : false, parameters: param };
    }
}, VALIDATOR_NON_NEGATIVE);

/**
 * 判断密码一致性
 *
 */
jQuery.validator.addMethod("equalPassword", function(value, element, param) {
	debugger;
	var id = param[0];
	var checkPassword = $("#"+id).val();
	if (checkPassword != value){
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
},VALIDATOR_PASSWORD);

/**
 * 输入手机号码为11位
 */
jQuery.validator.addMethod("phoneNumber" , function(value, element, parm){
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^(1\d{10})$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_PHONENUMBER);

/**
 * 输入邮编号码为6位
 */
jQuery.validator.addMethod("zipcodeNumber" , function(value, element, parm){
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^(1\d{5})$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_PHONENUMBER);

/**
 * 折扣为0-100的整数
 */
jQuery.validator.addMethod("discontNumber", function(value, element, parm){
	debugger;
	if (/^(100|[0-9]|[1-9][0-9])$/.test($.trim(value))){
		return {
			result : true
		};
	}else{
		return {
			result : false
		}
	}
	return {
		result : true
	};
},VALIDATOR_DISCONTNUMBER);
/**
 * 折扣为50-100的整数
 */
jQuery.validator.addMethod("discontNum", function(value, element, parm){
	debugger;
	if (/^(100|[5-9][0-9])$/.test($.trim(value))){
		return {
			result : true
		};
	}else{
		return {
			result : false
		}
	}
	return {
		result : true
	};
},VALIDATOR_DISCONTNUM);

/**
 * /^[1-9][0-9]{0,1}$/
 * /^(100|[0-9]|[1-9][0-9])$/
 * Please input number between 0 and 100
 */
jQuery.validator.addMethod("discontNumberEN", function(value, element, parm){
	debugger;
	if (/^[1-9][0-9]{0,1}$/.test($.trim(value))){
		return {
			result : true
		};
	}else{
		return {
			result : false
		}
	}
	return {
		result : true
	};
},VALIDATOR_DISCONTNUMBER_EN);

/**
 * 不能选择未确定
 *
 */
jQuery.validator.addMethod("isSure", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if ('未确认'==$.trim(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ISSURE);

/**
 * 校验純中文簽名
 *
 * @param {number}
 * 字符长度
 */
jQuery.validator.addMethod("isTrueZh", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var minLen = param[0];
	var exp = /[\u4e00-\u9fa5]/g;
	var trimValue = $.trim(value);
	if (trimValue.length < minLen) {
		return {
			result : false,
			parameters : param
		};
	}
	var maxLen = param[1];
	if (trimValue.length > maxLen) {
		return {
			result : false,
			parameters : param
		};
	}

	var valueStr = trimValue.match(exp);
	if(valueStr == null){
		return {
			result : false,
			parameters : param
		};
	}
	if (valueStr.length != trimValue.length){
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ISTUREZH);


/**
 * 校验純英文字符
 *
 * @param {number}
 * 字符长度
 */
jQuery.validator.addMethod("isTrueEn", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	var exp = /[a-zA-Z]/g;
	var trimValue = $.trim(value);
	if (trimValue.length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	var valueStr = trimValue.match(exp);
	if(valueStr == null){
		return {
			result : false,
			parameters : param
		};
	}
	if (valueStr.length != trimValue.length){
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};

}, VALIDATOR_ISTUREEN);

/**
 * 校验0-100的數字
 *
 * @param {number}
 * 字符长度
 */
jQuery.validator.addMethod("isPercent", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[1-9]\d*|0$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}
	var minValue = 0;

	if ($.trim(value) > 100) {
		return {
			result : false,
			parameters : param
		};
	}
	if ($.trim(value) < minValue) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ISPERCENTSMAX);

/**
 * 校验0-100的數字
 *
 * @param {number}
 * 字符长度
 */
jQuery.validator.addMethod("isLagerThan60Percent", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[1-9]\d*|0$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}
	if ($("#SELECT_DROPLIST_1116013001").children().children().attr('key')==2 || $("#SELECT_DROPLIST_1119991040").children().children().attr('key')==2){
		var minValue = param[0];

	}else{
		var minValue = 0;
	}

	if ($.trim(value) > 100) {
		return {
			result : false,
			parameters : param
		};
	}
	if ($.trim(value) < minValue) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ISPERCENTSMIN);

/**
 * 电话号码校验,本地车务通
 */
jQuery.validator.addMethod("cwtmobilephone", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^158\d{8}$|^152\d{8}$|^188\d{8}$|^151\d{8}$|^134\d{8}$|^135\d{8}$|^136\d{8}$|^137\d{8}$|^138\d{8}$|^139\d{8}$|^159\d{8}$|^150\d{8}$|^147\d{8}$|^157\d{8}$|^187\d{8}$|^198\d{8}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_PHONE);

/**
 * 字节校验
 */
jQuery.validator.addMethod("maxByte", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).replace(/[^\x00-\xff]/g, "xx").length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MAX_BYTE);

/**
 * 输入的数字只能为(0~1000的正整数)
 */
jQuery.validator.addMethod("maxthousand", function (value, element, param)
{
    debugger;
    if(value==""){
        return {result : true};
    }
    var len = param[0];
    if (len && $.trim(value).length != len)
    {
        return {result : false, parameters : param};
    }
    if (!/^(\+?[1-9]\d{0,2}|\+?1000)$/.test($.trim(value)))
    {
        return {result : false, parameters : param};
    }

    return {result : true, parameters : param};
}, VALIDATOR_MAXTHOUSAND);

/**
 * 输入的数字只能为(1~100的正整数)
 */
jQuery.validator.addMethod("maxhousand", function (value, element, param)
{
    debugger;
    if(value==""){
        return {result : true};
    }
    var len = param[0];
    if (len && $.trim(value).length != len)
    {
        return {result : false, parameters : param};
    }
    if (!/^(\+?[1-9]\d{0,1}|\+?100)$/.test($.trim(value)))
    {
        return {result : false, parameters : param};
    }

    return {result : true, parameters : param};
}, VALIDATOR_MAXHOUSAND);

/**
 * Allowed Max Group Member Amount等于或者大于群组有效或挂起的成员数量。
 * add by ywx372856
 * @param {number} 最小值
 */
 jQuery.validator.addMethod("imeiNumber", function(value, element, param)
 	{
		debugger;
		if(/^[0]{15}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}

		var imei15Valid = function(value) {
			debugger;
			var ln_r = 0;
			var ln_c = (value.toString()).length - 1;
			var ln_d = 0;
			var ln_a = 0;

			while (ln_c >= 1) {
				ln_d = parseInt(value.toString().substr(ln_c - 1, 1));
				if (ln_c % 2 == 0) {
					ln_a = ln_d * 2;
					if (ln_a > 9) {
						ln_r += (parseInt((ln_a.toString()).substr(0, 1)))
								+ (parseInt((ln_a.toString()).substr(1, 1)));
					} else {
						ln_r += ln_d * 2;
					}
				} else {
					ln_r += ln_d * 1;
				}
				ln_c--;
			}

			while (!((ln_r + ln_c) % 10 == 0)) {
				ln_c++;
			}
			debugger;
			/*console.log('The 15th IMEI number: ' + ln_c);*/

			return ln_c;
		}

		if (imei15Valid(value) != value.substr(14, 1)) {
			return {
				result : false,
				parameters : param
			}
		}

		if(/^\d{2}[0]{6}\d{7}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^\d{2}[0]{4}\d{9}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^[0]{6}\d{9}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^[0]{2}\d{13}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^[0]{8}\d{7}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		return {
			result : true,
			parameters : param
		};
 	}, VALIDATOR_IMEINUMBER);

/**
 * Allowed Max Group Member Amount等于或者大于群组有效或挂起的成员数量。
 * add by ywx372856
 * @param {number} 最小值
 */
 jQuery.validator.addMethod("valimeiNumber", function(value, element, param)
 	{
		debugger;
		if(/^[0]{15}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}

		var imei15Valid = function(value) {
			debugger;
			var ln_r = 0;
			var ln_c = (value.toString()).length - 1;
			var ln_d = 0;
			var ln_a = 0;

			while (ln_c >= 1) {
				ln_d = parseInt(value.toString().substr(ln_c - 1, 1));
				if (ln_c % 2 == 0) {
					ln_a = ln_d * 2;
					if (ln_a > 9) {
						ln_r += (parseInt((ln_a.toString()).substr(0, 1)))
								+ (parseInt((ln_a.toString()).substr(1, 1)));
					} else {
						ln_r += ln_d * 2;
					}
				} else {
					ln_r += ln_d * 1;
				}
				ln_c--;
			}

			while (!((ln_r + ln_c) % 10 == 0)) {
				ln_c++;
			}
			debugger;
			/*console.log('The 15th IMEI number: ' + ln_c);*/

			return ln_c;
		}

		if (imei15Valid(value) != value.substr(14, 1)) {
			return {
				result : false,
				parameters : param
			}
		}

		if(/^\d{2}[0]{6}\d{7}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^\d{2}[0]{4}\d{9}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^[0]{6}\d{9}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^[0]{2}\d{13}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		if(/^[0]{8}\d{7}$/.test($.trim(value))){
			return{
				result : false,
				parameters : param
			};
		}
		return {
			result : true,
			parameters : param
		};
 	}, VALIDATOR_VALIMEINUMBER);

/**
 * 校验0-100的數字
 *
 * @param {number}
 * 字符长度
 */
jQuery.validator.addMethod("is15imsinumber", function(value, element, param) {
	debugger;

	if (!/^\d{15}$/.test($.trim(value)))
	{
    	return {
    		result : false,
    		parameters : param
    	};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IMEINUMBERFORFIFTHING);
/**
  * 授权用户数:大于等于0小于等于50的整数
  */
 jQuery.validator.addMethod("licenseNum", function(value, element, param) {
    debugger;
    if (value == "") {
        return {
            result : false,
            parameters : param
        };
    }

    value = $.trim(value);

    if (!/^-?\d+$/.test(value)) {
        return {
            result : false,
            parameters : param
        };
    }

    if (value < 0 || value > 50) {
        return {
            result : false,
            parameters : param
        };
    }

    return {
        result : true,
        parameters : param
    };

}, VALIDATOR_LICENSENUM);
 /**
  * 长度6-20位,以BeId开头
  */
 /**
  * 中文校验
  *
  * @param {value}
  *            中文校验
  */
 jQuery.validator.addMethod("onlychinese", function(value, element, param) {
 	debugger;
 	if (value == "") {
 		return {
 			result : false
 		};
 	}

 	if (!/^[\u4e00-\u9fa5]+$/.test($.trim(value))) {
 		return {
 			result : false,
 			parameters : param
 		};
 	}
 	return {
 		result : true,
 		parameters : param
 	};
 }, VALIDATOR_ONLYCHINESE);

 /**
  * 姓名只能全中文或全英文
  *
  * @param {value}
  *            中文校验
  */
 jQuery.validator.addMethod("onlychineseorenglish", function(value, element, param) {
     debugger;
     if (value == "") {
         return {
             result: true
         };
     }

     if (!/^[a-zA-Z]+$|^[\u4e00-\u9fa5]+$/.test($.trim(value))) {
         return {
             result: false,
             parameters: param
         };
     }
     return {
         result: true,
         parameters: param
     };
 }, VALIDATOR_ONLYCHINESEORENGLISH);

/**
 * 通用校验器函数
 *
 * @param {value}
 */
jQuery.validator.addMethod("commoncheck", function(value, element, param) {
	debugger;

	//获取校验函数
	if (param.length < 1) {
		return;
	}
	var checkFuncParam = param[0];
	var checkFuncParamLen = checkFuncParam.length;
	if (checkFuncParamLen.length < 1) {
		return;
	}

	var checkFuncStr = checkFuncParam[checkFuncParamLen - 1];
	if (typeof(checkFuncStr) !== "string") {
		return;
	}

	//解析校验函数
	var caller = window;
	var index = checkFuncStr.lastIndexOf('.');
	if (index > -1) {
		caller = eval(checkFuncStr.substr(0, index));
		checkFuncStr = checkFuncStr.substr(index + 1);
	}
	var checkFunc = caller[checkFuncStr];
	if (typeof(checkFunc) !== "function") {
		return;
	}

	var callParam = [value];
	for (var i = 0; i < checkFuncParamLen - 1; i++) {
		if (typeof(checkFuncParam[i]) === "string"
			&& checkFuncParam[i].substr(0, 1)==='$') {
			callParam.push(eval(checkFuncParam[i]) || checkFuncParam[i]);
			continue;
		}
		callParam.push(checkFuncParam[i]);
	}
	callParam.push(param);

	//调用校验函数
	if (!checkFunc.apply(caller, callParam)) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, function(param) {
	return param[1];
});

/**
 * 通用校验器函数
 *
 * @param {value}
 */
jQuery.validator.addMethod("commoncheck1", function(value, element, param) {
	debugger;
	
	if(!value || value == ""){
		param[1] = undefined;
		return {
			result : true,
			parameters : param
		};
	}
	
	//获取校验函数
	if (param.length < 1) {
		return;
	}
	var checkFuncParam = param[0];
	var checkFuncParamLen = checkFuncParam.length;
	if (checkFuncParamLen.length < 1) {
		return;
	}

	var checkFuncStr = checkFuncParam[checkFuncParamLen - 1];
	if (typeof(checkFuncStr) !== "string") {
		return;
	}

	//解析校验函数
	var caller = window;
	var index = checkFuncStr.lastIndexOf('.');
	if (index > -1) {
		caller = eval(checkFuncStr.substr(0, index));
		checkFuncStr = checkFuncStr.substr(index + 1);
	}
	var checkFunc = caller[checkFuncStr];
	if (typeof(checkFunc) !== "function") {
		return;
	}

	var callParam = [value];
	for (var i = 0; i < checkFuncParamLen - 1; i++) {
		if (typeof(checkFuncParam[i]) === "string"
			&& checkFuncParam[i].substr(0, 1)==='$') {
			callParam.push(eval(checkFuncParam[i]) || checkFuncParam[i]);
			continue;
		}
		callParam.push(checkFuncParam[i]);
	}
	callParam.push(param);

	//调用校验函数
	if (!checkFunc.apply(caller, callParam)) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, function(param) {
	return param[1];
});

jQuery.validator.addMethod("validateRUC4Ecuador", function(value, element, param) {
	debugger;
	if(!value || value === "") {
		return {
			result : true,
			parameters : param
		}
	}

	// RUC由13位纯数字构成，不含字母和特殊字符；
	// RUC的第三位数字只能从下面的数字中取"0,1,2,3,4,5,6,9"。
	if(!/^\d{2}[01234569]{1}\d{10}$/.test($.trim(value))) {
		return{
			result : false,
			parameters : param
		};
	}

	// RUC的最后三位数字不能是000.
	var last3num = value.substring(10);
	if (last3num === '000') {
		return {
			result : false,
			parameters : param
		};
	}

	// RUC的前两位组合起来不能小于1,或者大于22，应该是介于01到22之间，包括01和22；
	var first2num = parseInt(value.substring(0, 2));
	if (first2num < 1 || first2num > 22) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_RUC_FORMAT_4_ECUADOR);

jQuery.validator.addMethod("validateID4Ecuador", function(value, element, param) {
	debugger;
	if(!value || value === "") {
		return {
			result : true,
			parameters : param
		}
	}

	// Id卡由10位纯数字构成，不含字母和特殊字符；
	// Id卡的第三位数字只能从下面的数字中取"0,1,2,3,4,5 ";
	if(!/^\d{2}[012345]{1}\d{7}$/.test($.trim(value))) {
		return{
			result : false,
			parameters : param
		};
	}

	// ID 卡的前两位组合起来不能小于1,或者大于22，应该是介于01到22之间，包括01和22；
	var first2num = parseInt(value.substring(0, 2));
	if (first2num < 1 || first2num > 22) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ID_FORMAT_4_ECUADOR);

/**
 *
 * 带宽 以数字开头+(G或M)结尾，
 */
jQuery.validator.addMethod("bandwidthwithunit", function(value, element, param) {
	debugger;
	if (value == "")
	{
		return {result : true};
	}
	if ((/^\d+(\.\d+)*M$/.test($.trim(value))) || (/^\d+(\.\d+)*G$/.test($.trim(value))))
	{
		return {result : true};
	}
	return {result : false};
 }, VALIDATOR_BANDWIDTH_RATE1);
/**
 *
 * 只能输入数字和小数
 */
jQuery.validator.addMethod("numberDecimals", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^\d+(\.\d+)?$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_NUMBER_DECIMALS);

/**
 *
 * 只能输入大写字母
 */
jQuery.validator.addMethod("capital", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[A-Z]*$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_CAPITAL);
/**
  * 长度6-20位,以BeId开头
  */
 jQuery.validator.addMethod("secondvalidatesmpGroupid", function(value, element, param) {
 	debugger;
 	var beId = $(document).scope().$Page.identityBeId;
 	if (!value) {
 		return {
 			result : true
 		};
 	}
 	if (($.trim(value).length < 6) || ($.trim(value).length > 20))  {
 		return {
 			result : false
 		};
 	}
 	if (value.indexOf(beId)!=0) {
 		return {
 			result : false
 		};
 	}
 	return {
 		result : true
 	};
 },  VALIDATOR_VALIDATESMPGROUPID);

 /**
  * 长度6-20位,以地市缩写开头
  *
  */
 jQuery.validator.addMethod("secondvalidatesmpGroupLoginName", function(value, element, param) {
	 	debugger;

	 	var beId = $(document).scope().$Page.identityBeId;
	 	if (!value) {
	 		return {
	 			result : true
	 		};
	 	}
	 	if (($.trim(value).length < 6) || ($.trim(value).length > 8)) {
	 		return {
	 			result : false
	 		};
	 	}
	 	if ((value.indexOf("sz") == 0 && beId == 11) || (value.indexOf("ha") == 0 && beId == 12)
	 		|| (value.indexOf("sq") == 0 && beId == 13) || (value.indexOf("nj") == 0 && beId == 14)
	 		|| (value.indexOf("lyg") == 0 && beId == 15) || (value.indexOf("xz") == 0 && beId == 16)
	 		|| (value.indexOf("cz") == 0 && beId == 17) || (value.indexOf("zj") == 0 && beId == 18)
	 		|| (value.indexOf("wx") == 0 && beId == 19) || (value.indexOf("nt") == 0 && beId == 20)
	 		|| (value.indexOf("tz") == 0 && beId == 21) || (value.indexOf("yc") == 0 && beId == 22)
	 		|| (value.indexOf("yz") == 0 && beId == 23) ){
	 		return {result : true};
	 	} else {
	 		return {result : false};
		};
	 },VALIDATOR_VALIDATESMPGROUPLOGINNAME);

/**
 * 数大于0的校验
 */
jQuery.validator.addMethod("numGreater", function (value, element, param)
{
    debugger;
    if(value==""){
        return {result : true, parameters: param };
    }

    var num = new Number($.trim(value));
    if(!isNaN(num) && num.valueOf() > 0) {
        return {result : true, parameters: param };
    } else {
        return {result : false, parameters: param };
    }
}, VALIDATOR_NUM_GREATER);

/**
 * 校验是100的倍数
 */
jQuery.validator.addMethod("timesOfHundred", function (value, element, param)
{
    debugger;
    if(value==""){
        return {result : true};
    }

    // 校验是否是正整数
    if (!/^[1-9]\d*$/.test($.trim(value)))
	{
    	return {result : false};
	}

    var num = new Number($.trim(value));
    if(!isNaN(num) && num.valueOf() >= 100 && num.valueOf() % 100 == 0){
    	return {result : true};
    }else{
    	return {result : false};
    }
}, VALIDATOR_TIMES_OF_HUNDRED);
/**
 * 数字位数校验，数字不能超过指定的位数(可为小数)
 *
 * @param {number}
 *            数字位数
 */
jQuery.validator.addMethod("maxDigitPhone", function(value, element, param) {
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if ($.trim(value).length > len) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_MAX_DIGIT);

/**
 * 只能为数字或者字母和下划线和-
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("CharDigitalUnderMinus", function (value, element, param)
{
	debugger;
	if(value==""){
		return {result : true};
	}
    if (!/^[\da-zA-Z0-9_]*$/.test($.trim(value)) && !/^[\da-zA-Z0-9-]*$/.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_SPECIALCHAR);

/**
 * 输入长度必须在4~64位之间
 */
jQuery.validator.addMethod("ValidateAuthNameLen", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

 	if (($.trim(value).length < 4) || ($.trim(value).length > 64))  {
 		return {
			result : false,
			parameters : param
		};
 	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_VALIDATEAUTHNAME);

/**
 * 输入长度必须在8~16位之间
 */
jQuery.validator.addMethod("ValidateAuthPwdLen", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

 	if (($.trim(value).length < 8) || ($.trim(value).length > 16))  {
 		return {
			result : false,
			parameters : param
		};
 	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_VALIDATEAUTHPWD);

/**
 * 输入长度必须在0~64位之间
 */
jQuery.validator.addMethod("ValidateSpDescLen", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

 	if (($.trim(value).length > 64))  {
 		return {
			result : false,
			parameters : param
		};
 	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_VALIDATESPDESC);

/**
 * 强密码必须同时包括小写字母、大写字母、数字和特殊字符
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("ValidateStrongPwd", function (value, element, param)
{
	debugger;
	var strongRegex = new RegExp("^(?=.{8,16})(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*\\W).*$", "g");
	if(value==""){
		return {result : true};
	}

	if (!strongRegex.test($.trim(value)))
	{
    	return {result : false, parameters : param};
	}

	return {result : true, parameters : param};
}, VALIDATOR_VALIDATESTRPWD);

/**
 * IP地址字符串校验(支持2个IP地址的输入)
 *
 */
jQuery.validator.addMethod("doubleIpStr", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var str = $.trim(value);
	var ipStr = str.split(",");
	var exp=/^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
	for(var i=0;i<ipStr.length;i++)
    {
		if (ipStr[i] == "") {
			continue;
		}
        var reg = ipStr[i].match(exp);
        if(reg==null)
        {
        	return {
    			result : false,
    			parameters : param
    		};
        }
    }
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IPSTR);

/**
 * APN属性（1115010003）值的长度不能小于4位，并且必须以.js结尾。
 *
 */
jQuery.validator.addMethod("apnAttrEndJs", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	var str = $.trim(value);
	if(((str.indexOf(".js",str.length-3) == -1) || (str.split(".js")||[]).length <= 1 ||((str.split(".js")||[])[0]||"").length < 1)){
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};

}, VALIDATOR_APNATTRENDJS);

/**
 *中继线编码长度不能超过7
 */
jQuery.validator.addMethod("validatorValidateVoiceConfig", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (($.trim(value).length > 7)) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_VALIDATEVOICECONFIG);

/**
 * 交换机信息长度不能超过10
 */
jQuery.validator.addMethod("validatorValidateSwitchConf", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (($.trim(value).length > 10)) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_VALIDATESWITCHCONF);

/**
 * 输入必须为数字字母
 */
jQuery.validator.addMethod("validateLettersOrMath", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^[0-9a-zA-Z]*$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_VALIDATELETTERSORMATH);

//哥伦比亚账户免税开始时间必须早于结束时间
jQuery.validator.addMethod("excludedCompare", function(value, element, param) {
    debugger;
    if (value == "") {
        return {
            result : true
        };
    }
    var $Gadget = $(element).scope().$Gadget;
    var begintime = $Gadget.basicAccountInfo.excludedStartdate;
    var endtime = $Gadget.basicAccountInfo.excludedEnddate;

    if(!begintime){
    	return {
            result : false
        };
    }

    if(begintime > endtime){
    	return {
            result : false
        };
    }

    return {
        result : true
    };
}, VALIDATOR_EXCLUDEDCOMPARE);

//江苏禁止业务开始时间必须早于结束时间
jQuery.validator.addMethod("timeCompareForbid", function(value, element, param) {
    debugger;
    if (value == "") {
        return {
            result : true
        };
    }
    var $Gadget = $(element).scope().$Gadget;
    var begintime = $Gadget.forbid.startDate;
    var endtime = $Gadget.forbid.endDate;

    if(!begintime){
    	return {
            result : false
        };
    }

    if(begintime-(24*3600*1000) > endtime){
    	$Gadget.forbid.endDate="";
    	return {
            result : false
        };
    }

    return {
        result : true
    };
}, VALIDATOR_TIME_COMP);

/**
 * 输入必须为数字字母
 */
jQuery.validator.addMethod("lengthIsNine", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if ($.trim(value).length < param[0]) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_INPUTNOTVALID);

/**
 * 扩展自定义校验器，能够调用任意返回值为boolean的方法。
 * 如果入参中含有$value和$element，则$value为当前控件的值value。$element为当前控件的element
 * @demo: u-validator="callback(check,'{{$Page.property}}','$value','$element'):{{'ad.fngroup.label.serviceNo'|i18n}};"
 * @param  {[type]} value   [当前控件的值]
 * @param  {[type]} element [当前控件元素]
 * @param  {[type]} params  [需要调用的方法名]
 * @return {[type]}         [description]
 */
jQuery.validator.addMethod("callback", function (value, element, params){
	debugger;
	var fn, parameters=[], result = false;
	if (params && params[0]) {
		fn = params[0];
		if (typeof fn === 'string') {
			fn = eval(fn);
		}
		//深copy参数，防止引用传递参数覆盖，并对保留字$value和$element解析
		for(var i=1, length =params.length; i<length; i++){
			var param = params[i];
			if(typeof param === 'string' && param === '$value' ){
				param = value;
			}else if(typeof param === 'string' && param === '$element'){
				param = element;
			}
			parameters.push(param);
		}
		result = fn.apply(this, parameters);
	}
	return {
		result: result,
		parameters: parameters
	};
}, VALIDATOR_INPUTNOTVALID);
/**
 * 用户名称不能超过30个汉字(60个字符)的长度。
 */
jQuery.validator.addMethod("userNameNum", function(value, element, param) {
	debugger;
	var name = /[\u4E00-\u9Fa5]$/;
	var length =value.length;
	var eTemp = 0;
	var cTemp = 0;
	if (value == "") {
		return {
			result : true
		};
	}
	for(var i = 0;i < length; ++i){
		if(name.test(value[i])){
			cTemp += 2;
		}else{
			eTemp += 1;
		}
		if(cTemp + eTemp > 60){
			element.value = element.value.substr(0,i);
			return {
				result : false,
				parameters : param
			};
		}
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_USERNAME_NUM);
/**
 * 用户名称只能为汉字和字母
 */
jQuery.validator.addMethod("userName", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/[\u4E00-\u9Fa5\a-zA-Z]$/.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_USERNAME);
/**
 * 汉字、字母、数字均只能输入{0}位
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("alphanumeric", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	if (($.trim(value).length > len)) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_ALPHANUMERIC_CHARACTER);

/**
 * 只能输入字母，数字或英文下标点符号校验
 *
 */
jQuery.validator.addMethod("faultchinese", function(value, element, param) {
	debugger;
	var keyword = /\·|\￥|\（|\）|\—|\…|\【|\】|\；|\：|\‘|\“|\”|\、|\《|\》|\，|\。|\？|\、|！/;
	var keyword1 = /[\u4E00-\u9Fa5]$/;
	var length =value.length;
	if (value == "") {
		return {
			result : true
		};
	}
	for(var i = 0;i < length; ++i){
		if((keyword.test(value[i]))||(keyword1.test(value[i]))){
		return {
			result : false,
			parameters : param
		};
		}

	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_FAULTCHINESE);
/**
 * 输入为1-{0}的正整数校验
 *
 * @param {number} 字符长度
 */
jQuery.validator.addMethod("positiveintergers", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	if (!/^[1-9]\d*$/.test(value))
	{
    	return {result : false, parameters : param};
	}

	if ($.trim(value) < 0) {
		return {
			result : false,
			parameters : param
		};
	}
	var len = param[0];

	if ($.trim(value) > len) {
		return {
			result : false,
			parameters : param
		};
	}

	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_POSITIVE_INTERGERS);
/**
 *  主题必须以boss开头
 */
jQuery.validator.addMethod("boss", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}

	if(!/^(BOSS|boss).*/.test($.trim(value))){
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_BOSS);

/**
 * 经纬度校验
 */
jQuery.validator.addMethod("checkSixDecimal", function (value, element, param){
	debugger;
	if(value==""){
		return {result : true};
	}
	if (!(/^(([1-9][0-9]*)|[0-9])([.]\d{1,6})$/.test($.trim(value))||/^(([1-9][0-9]*)|[0-9])$/.test($.trim(value)))){
		return {result : false}
	}
return {result : true};
}, VALIDATOR_LONGITUDE_DIMENSION);
/**
 * 本地APN名称格式为：CMIOTXXXX.js。全网APN名称格式为：CMIOTXXXX。XXXX为字母且不超过10位。
 */
jQuery.validator.addMethod("apnNameNum", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (/^(CMIOT|cmiot)+[a-zA-Z]+(.js)$/.test(value)) {
		if(value.length > 18){
			return {
				result : false,
				parameters : param
			};
		}
	}else if (/^(CMIOT|cmiot)+[a-zA-Z]+$/.test(value)){
		if(value.length > 15){
			return {
				result : false,
				parameters : param
			};
		}
	}else{
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_APNNAME_NUM);
/**
 * IP地址字符串校验
 *
 */
jQuery.validator.addMethod("apnIp", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	var exp=/^((\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5]))+~+((\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5]))$/;
	if (!exp.test($.trim(value))) {
		return {
			result : false,
			parameters : param
		};
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_APNIP);

/**
 * 外国人永久居留证  中文姓名校验
 *
 */
jQuery.validator.addMethod("idCardExZhName", function(value, element, param) {
	debugger;
   // var reg = /^([\u4e00-\u9fa5]|\•|\·)*$/;
    var reg = /^([\u2E80-\uFE4F]|\•|\·)*$/;
    if (!reg.test(value)) {
    	return {
			result : false,
			parameters : param
		};
    }
    return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IDCARDEXZHNAME);
//英文姓名校验
jQuery.validator.addMethod("idCardExEnName", function(value, element, param) {
	debugger;
	// var reg = /^([\u4e00-\u9fa5]|\•|\·)*$/;
	var reg = /[^\x00-\xff]/;
	if (reg.test(value)) {
		return {
			result : false,
			parameters : param
		};
	}
	var reg1 = /^[ A-Za-z,]*$/;
    if(!reg1.test(value)){
    	return {
			result : false,
			parameters : param
		};
    }
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IDCARDEXENNAME);
//中文名称长度
jQuery.validator.addMethod("idCardExZhNameLength", function(value, element, param) {
	debugger;
	var totalCount = 0;
    for ( var i = 0; i < value.length; i++) {
        var c = value.charCodeAt(i);
        if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
            totalCount++;
        } else {
            totalCount += 2;
        }
    }
	if (totalCount < 4 || totalCount > 256) {
        // 姓名至少2个汉字或4个字符，不超过256位
		return {
			result : false,
			parameters : param
		};
    }
    return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IDCARDEXZHNAMELENGTH);
//英文名称长度
jQuery.validator.addMethod("idCardExENNameLength", function(value, element, param) {
	debugger;
	var totalCount = 0;
    for ( var i = 0; i < value.length; i++) {
        var c = value.charCodeAt(i);
        if ((c >= 0x0001 && c <= 0x007e) || (0xff60 <= c && c <= 0xff9f)) {
            totalCount++;
        } else {
            totalCount += 2;
        }
    }
	if (totalCount < 3 || totalCount > 256) {
        // 不超过256位
		return {
			result : false,
			parameters : param
		};
    }
    return {
		result : true,
		parameters : param
	};
}, VALIDATOR_IDCARDEXENNAMELENGTH);
/**
 * 电话号码校验,车联网手机号码
 */
jQuery.validator.addMethod("clwmobilephone", function(value, element, param) {
	debugger;
	if (value == "") {
		return {
			result : true
		};
	}
	if (!/^158\d{8}$|^152\d{8}$|^188\d{8}$|^151\d{8}$|^134\d{8}$|^135\d{8}$|^136\d{8}$|^137\d{8}$|^138\d{8}$|^139\d{8}$|^159\d{8}$|^150\d{8}$|^147\d{8}$|^157\d{8}$|^187\d{8}$|^198\d{8}$/.test($.trim(value))) {
		return {
			result : false
		};
	}
	return {
		result : true
	};
}, VALIDATOR_PHONE);

/**
 * 用户名称不能超过{param}个汉字(param X 2个字符)的长度。
 */ 
jQuery.validator.addMethod("applicantUserNameNum", function(value, element, param) {
	debugger;
	var name = /[\u4E00-\u9Fa5]$/;
	var length =value.length;
	var eTemp = 0;
	var cTemp = 0;
	if (value == "") {
		return {
			result : true
		};
	}
	var len = param[0];
	for(var i = 0;i < length; ++i){
		if(name.test(value[i])){
			cTemp += 2;
		}else{
			eTemp += 1;
		}
		if(cTemp + eTemp > len){
			//element.value = element.value.substr(0,i);
			return {
				result : false,
				parameters : param
			};
		}
	}
	return {
		result : true,
		parameters : param
	};
}, VALIDATOR_APPLICANT_CHARACTER);


/**
 * 异步校验公共类
 * w00192492
 * @param {number} 指定证件号码位数，可选
 */
jQuery.validator.asyncValidateUtil = {
	addMethod: function (name, validateFunc) {
		jQuery.validator.addMethod(name, function (value, element, param) {
			$(element).bind("change", function (event) {
				event.stopPropagation();
				event.preventDefault();
				element.checkedResult = false;
			});

			if (element.checkedResult) {
				return element.checkedResult;
			}

			jQuery.validator.asyncValidateUtil.validator = this;
            
			validateFunc(value, element, param);

			return element.checkedResult;
		}, function (param, element) {
			return element.checkedResult.msg;
		});
	},
    
	setValidateResult: function (element, result, msg, param) {
		element.checkedResult = {
			result: result,
			parameters: param,
			msg: msg
		};
	},

	setValidateSuc: function (element, param) {
		this.setValidateResult(element, true, '', param);
        this.validator.element(element);
	},

	setValidateFail: function (element, msg, param) {
		this.setValidateResult(element, false, msg, param);
		this.validator.element(element);
	}
};

jQuery.validator.asyncValidateUtil.addMethod("checkNormalServNum", function (value, element, param) {
    if (!value) {
		jQuery.validator.asyncValidateUtil.setValidateResult(element, false, '请输入本省正常状态的用户手机号码', param);
        return;
    }
    
    jQuery.validator.asyncValidateUtil.setValidateResult(element, false, '正在校验中', param);
    
	var $scope = $(document).scope();
	$scope.$Get("$Fire")({
		service: 'bes.oc.ocquerysubscriptionbaseservice/querysubscriber',
		params: {
			"request": {
				"serviceNumber": value
			}
		},
		target: "resp",
		onafter: function (resp) {
			if (resp && resp.subscriberInfo && resp.subscriberInfo[0] && resp.subscriberInfo[0].status == 2) {
				jQuery.validator.asyncValidateUtil.setValidateSuc(element, param);
			} else {
				jQuery.validator.asyncValidateUtil.setValidateFail(element, '输入数据不合法:非本省正常状态的用户手机号码', param);
			}
		},
		onerror: function () {
			jQuery.validator.asyncValidateUtil.setValidateFail(element, '校验失败', param);
		}
	});
});