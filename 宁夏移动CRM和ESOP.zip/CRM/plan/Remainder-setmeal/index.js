(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control22_MzeUT4: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find(".tab-title").text();
    },
    doAction_uiControl14_hTODpI: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        // console.log("sdfmskd");
        ysp.appMain.backToIndex(); // $(elem).find(".tab-close").click();
      }
    },
    getTemplate_uiControl14_hTODpI: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.handle('','back');\n    }\n  },\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title=\"\u5957\u9910\u5269\u4F59\u5206\u949F\u6570\u67E5\u8BE2\">\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.handle('', 'back');\n    };\n  },\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: '\\u5957\\u9910\\u5269\\u4F59\\u5206\\u949F\\u6570\\u67E5\\u8BE2' },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },

    getData_control26_xOzNsU: function (elem) {
      if (!elem) {
        return;
      }var tab = [];var title = '',
          content = [],
          arrThs = [],
          arrTrs = [],
          ths = [],
          trs = [];$(elem).children("tbody").children("tr").map(function (i, _tr) {
        if (!$(_tr).hasClass("ng-hide") && $(_tr).css("display") != "none") {
          if ($(_tr).find("td").length == 1) {
            if (title != '') {
              arrThs.push(ths);arrTrs.push(trs);tab.push({ title: title, arrThs: arrThs, arrTrs: arrTrs });ths = [];trs = [];arrThs = [];arrTrs = [];
            }title = $(_tr).find("td").text();
          } else if ($(_tr).children('td').eq(1).hasClass('column_title')) {
            if (ths.length != 0) {
              arrThs.push(ths);arrTrs.push(trs);ths = [];trs = [];
            }$(_tr).children('td').map(function (j, _td) {
              ths.push($(_td).text());
            });
          } else {
            var tds = [];$(_tr).children('td').map(function (k, _td1) {
              tds.push({ txt: $(_td1).text().trim(), isRed: $(_td1).css('color') == 'red' });
            });trs.push(tds);
          }
        }
      });arrThs.push(ths);arrTrs.push(trs);tab.push({ title: title, arrThs: arrThs, arrTrs: arrTrs });return tab;
    },
    doAction_uiControl18_7CDviy: function (data, elem) {},
    getTemplate_uiControl18_7CDviy: function () {
      var selfTemplate = "const Tabs = AMUI2.Tabs;\nconst TodoItemTypeTwo = AMUI2.TodoItemTypeTwo;\nconst Pair = AMUI2.Pair;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      return(\n      \t<div style = {{display:\"none\"}}></div>\n      )\n    }\n    if(data[0].title == \"\u65E0\u8BB0\u5F55\"){\n         return(\n          <div className=\"t-cen\">\u6682\u65E0\u6570\u636E</div>\n         )\n      }\n    return (\n      <div className=\"wTab\">\n        <Tabs>\n        \t{data.map(function(ablum,i){\n            return(\n            \t<Tabs.Item\n                title={ablum.title}\n                key={i}\n              >\n              \t<div>\n                \t{ablum.arrTrs.map(function(trs,j){\n                    return(\n                    \t<div className=\"wTab1\">\n                      \t{trs.map(function(tr,k){\n                          return(\n                          \t<TodoItemTypeTwo\n                              key={k}\n                              title={<Pair value={<span>{tr[0].txt}</span>}/>}\n                              defaultCollapsed = {false}\n                              after={<span style={{color:\"#0090EB\"}}>{tr.pop().txt}</span>}\n                            >\n                              {tr.map((td, i) => {\n                               if(i != 0){\n                                  return <Pair key={i} name={ablum.arrThs[j][i]} value={<span style={{color:td.isRed?\"red\":\"inherit\"}}>{td.txt}</span>} />;\n                               }\n                              })}\n                            </TodoItemTypeTwo>\n                          )\n                        })}\n                      </div>\n                    )\n                  })}\n                </div>\n              </Tabs.Item>\n            )\n          })}\n        </Tabs>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar Tabs = AMUI2.Tabs;\nvar TodoItemTypeTwo = AMUI2.TodoItemTypeTwo;\nvar Pair = AMUI2.Pair;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\"div\", { style: { display: \"none\" } });\n    }\n    if (data[0].title == \"\u65E0\u8BB0\u5F55\") {\n      return React.createElement(\n        \"div\",\n        { className: \"t-cen\" },\n        \"\\u6682\\u65E0\\u6570\\u636E\"\n      );\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"wTab\" },\n      React.createElement(\n        Tabs,\n        null,\n        data.map(function (ablum, i) {\n          return React.createElement(\n            Tabs.Item,\n            {\n              title: ablum.title,\n              key: i\n            },\n            React.createElement(\n              \"div\",\n              null,\n              ablum.arrTrs.map(function (trs, j) {\n                return React.createElement(\n                  \"div\",\n                  { className: \"wTab1\" },\n                  trs.map(function (tr, k) {\n                    return React.createElement(\n                      TodoItemTypeTwo,\n                      {\n                        key: k,\n                        title: React.createElement(Pair, { value: React.createElement(\n                            \"span\",\n                            null,\n                            tr[0].txt\n                          ) }),\n                        defaultCollapsed: false,\n                        after: React.createElement(\n                          \"span\",\n                          { style: { color: \"#0090EB\" } },\n                          tr.pop().txt\n                        )\n                      },\n                      tr.map(function (td, i) {\n                        if (i != 0) {\n                          return React.createElement(Pair, { key: i, name: ablum.arrThs[j][i], value: React.createElement(\n                              \"span\",\n                              { style: { color: td.isRed ? \"red\" : \"inherit\" } },\n                              td.txt\n                            ) });\n                        }\n                      })\n                    );\n                  })\n                );\n              })\n            )\n          );\n        })\n      )\n    );\n  }\n});";
    },
    getData_control215_1oRPhW: function (elem) {
      if (!elem) {
        return;
      }var opts = [],
          $select = $(elem).find('select[name="month"]');$select.find('option').each(function (i, opt) {
        opts.push($(opt).attr('value'));
      });return { opts, selected: $select.val() };
    },
    doAction_uiControl197_7TUeh3: function (data, elem) {
      var _d = data.dataCustom;if (data.eventType === 'select') {
        $(elem).find('select[name="month"]').val(_d.value);setTimeout(function () {
          elem.querySelectorAll('table')[1].querySelector('table tbody').querySelectorAll('td')[4].querySelector('input').click();
        }, 0);
      }
    },
    getTemplate_uiControl197_7TUeh3: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { isStudio } from 'appRenderer';//{isStudio() && '_select'}\nconst Icon = AMUI2.Icon;\nconst Modal = require('ysp-custom-components').Modal;\nconst NavBar = require('ysp-custom-components').NavBar;\nmodule.exports = React.createClass({\n  getInitialState:()=>({show:false}),\n  componentDidUpdate:function(){\n    var me = this,_d = this.props.data.customData;\n  },\n  handle:function(data,eventType){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({data,eventType});\n    }\n  },\n  render: function() {\n    var _d = this.props.data.customData,\n        me = this;\n    var optCss = {padding:'.4rem',background:'#fff',textAlign:'center',\n              borderBottom:'.3rem solid #efefef'};\n    return <div>\n\t\t\t<Modal role=\"page\" isOpen={me.state.show}>\n        <NavBar title=\"\u6708\u4EFD\" lFn={()=>{\n              me.setState({...me.state,show:false});\n            }}/>\n        {_d.opts.map((opt,i)=>{\n          return <div style={optCss} onClick={()=>{\n              me.handle({idx:i,value:opt},'select');\n              me.setState({...me.state,show:false});\n            }}>{opt}</div>\n        })}\n      </Modal>\n      <div style={{display:'flex',background:'#fff',border:'1px solid #ccc'}}>\n      \t<input  style={{...optCss,width:'90%',border:'none'}} value={_d.selected} onClick={()=>{ \n              me.setState({show:true})\n           \n            }}/><Icon style={{lineHeight:'2rem',color:'#ccc'}} name=\"right-nav\" />\n      </div>\n    </div>\n  }\n});";
      return "'use strict';\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\n//{isStudio() && '_select'}\nvar Icon = AMUI2.Icon;\nvar Modal = require('ysp-custom-components').Modal;\nvar NavBar = require('ysp-custom-components').NavBar;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  getInitialState: function getInitialState() {\n    return { show: false };\n  },\n  componentDidUpdate: function componentDidUpdate() {\n    var me = this,\n        _d = this.props.data.customData;\n  },\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var _d = this.props.data.customData,\n        me = this;\n    var optCss = { padding: '.4rem', background: '#fff', textAlign: 'center',\n      borderBottom: '.3rem solid #efefef' };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        Modal,\n        { role: 'page', isOpen: me.state.show },\n        React.createElement(NavBar, { title: '\\u6708\\u4EFD', lFn: function lFn() {\n            me.setState(_extends({}, me.state, { show: false }));\n          } }),\n        _d.opts.map(function (opt, i) {\n          return React.createElement(\n            'div',\n            { style: optCss, onClick: function onClick() {\n                me.handle({ idx: i, value: opt }, 'select');\n                me.setState(_extends({}, me.state, { show: false }));\n              } },\n            opt\n          );\n        })\n      ),\n      React.createElement(\n        'div',\n        { style: { display: 'flex', background: '#fff', border: '1px solid #ccc' } },\n        React.createElement('input', { style: _extends({}, optCss, { width: '90%', border: 'none' }), value: _d.selected, onClick: function onClick() {\n            me.setState({ show: true });\n          } }),\n        React.createElement(Icon, { style: { lineHeight: '2rem', color: '#ccc' }, name: 'right-nav' })\n      )\n    );\n  }\n});";
    }
  }, "Remainder-setmeal");
})(window, ysp);