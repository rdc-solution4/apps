(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control76_nT8IgB: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find(".tab-title").text();
    },
    doAction_uiControl70_HL30Se: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.appMain.backToIndex(); // $(elem).find(".tab-close").click();
      }
    },
    getTemplate_uiControl70_HL30Se: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back('','back');\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }                       \n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back('', 'back');\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control3_K3k0Ju: function (elem) {
      if (!elem) {
        return;
      }var data = {};var rp = function (text) {
        if (text) {
          return text.trim();
        }return '';
      };$(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if ($iframe.find("#suspendorresume").css("display") == "block") {
            var arr = {},
                obj1 = $($iframe).find(".has_recommend").children().eq(0);arr.title = obj1.find(".pl_title").text();arr.lable = obj1.find(".form-group.per100").children().eq(0).text();arr.text = obj1.find("span").text();var brr = [],
                obj2 = $($iframe).find(".has_recommend").children().eq(1);obj2.find(".pl_content > .form_con").children(':not(.ng-hide)').each(function (i, d) {
              var lable = rp($(d).find(".form_label").text()),
                  ipt = $(d).find('input,textarea'); //找到包含input或textarea的元素
              if (ipt[0] && ipt[0].tagName == 'INPUT') {
                var id = $(d).find(".trigger").attr("id"),


                // span的id
                type = "input1";brr.push({ lable: lable, btnId: id, // span的id
                  type: type, value: $(d).find(".trigger").prev().val() });
              } else if (ipt[0] && ipt[0].tagName == 'TEXTAREA') {
                var type = "textarea";brr.push({ lable: lable, selector: $(d).find("textarea").attr("id"), //文本框的id
                  type: type, value: $(d).find("textarea").val() });
              }
            });var crr = [],
                title = {},
                textArray = [],
                obj3 = $($iframe).find(".has_recommend").children().eq(2);crr.push({ title: rp(obj3.find(".pl_title").text()), //获取经办人信息文本
              select: obj3.find(".pl_title").parent(".panel").hasClass("selected") });crr.push({ textArray: textArray });obj3.find(".form_row.form_con").children().each(function (i, ng) {
              var lable = rp($(ng).find(".form_label.ng-binding").text()),


              //姓名
              value = "",


              //输入框的值
              type = "",


              //看类型是input还是textarea
              id = "",


              //input/textarea的id
              ipt = $(ng).find('input,textarea');var qufen = "";if ($(ng).children().length == 2) {
                if (ipt[0] && ipt[0].tagName == 'INPUT') {
                  // type = "input";
                  id = $(ng).find("input[type='text']").attr("id") || $(ng).find(".trigger").attr("id");var span1 = $(ng).find(".btn_normal.vt_middle.ng-binding").text(),


                  //span的文本值（读取）
                  sid = $(ng).find(".btn_normal.vt_middle.ng-binding").attr("id"); //span文本值的id
                  if ($(ng).find(".trigger").length) {
                    qufen = $(ng).find("input").val();type = "input1";
                  } else {
                    qufen = $(ng).find("input").val();type = "input";
                  }textArray.push({ lable: lable, // value: $(ng).find("input").val(),
                    value: qufen, type: type, id: id, //输入框的id
                    span1: span1 || "", //span的文本值（读取）
                    sid: sid //span文本值的id
                  });
                } else if (ipt[0] && ipt[0].tagName == 'TEXTAREA') {
                  type = "textarea";id = $(ng).find(".form_textarea.ng-pristine").attr("id");if ($(ng).find(".trigger").length) {
                    qufen = $(ng).find(".form_textarea.ng-pristine").val();
                  } else {
                    qufen = $(ng).find("textarea").val();
                  }textArray.push({ lable: lable, // value: $(ng).find(".form_textarea.ng-pristine").val(),
                    value: qufen, type: type, id: id, //输入框的id
                    span1: "" });
                }
              } else if ($(ng).children().length == 3) {
                type = "textarea";id = $(ng).children().find(".form_textarea").attr("id");value = $(ng).children().find(".form_textarea").val();var span1 = rp($(ng).children().find("span").eq(0).text()),
                    span2 = rp($(ng).children().find("span").eq(1).text()),


                // sid = $(ng).children().find("span").eq(0).attr("class"),
                // sid1 = $(ng).children().find("span").eq(1).attr("class"),
                sid0 = "nomal",
                    sid1 = "copy",
                    span3 = $(ng).find(".checkbox").text(),
                    sid = $(ng).children().find(".checkbox").attr("id"); //span标签的id
                textArray.push({ lable: lable, value: value, type: type, id: id, //文本框的id
                  span1: span1, //获取span标签的文本值（常用模板）
                  span2: span2, //获取span标签的文本值（一键复制）
                  sid0: sid0, //获取span标签的（常用模板）的id
                  sid1: sid1, //获取span标签的（一键复制）的id
                  span3: span3, //获取span标签的文本值（发送免填单短信）
                  span3Type: $(ng).children().find(".checkbox").attr("class"), //class="checkbox checked"是否被选
                  sid: sid //span标签的id
                });
              }
            });var drr = {},
                obj4 = $($iframe).find(".has_recommend").children().eq(4);drr.lable = rp(obj4.find(".btn_positive").text());drr.id = obj4.find(".btn_positive").attr("id");var sss = [];$($iframe).children(".DroplistOption").each(function (i, d) {
              if ($(d).css('display') == 'block') {
                $(d).find("li").each(function (i, l) {
                  var selected = $(l).hasClass("selected") ? true : false,
                      text = $(l).text();sss.push({ selected: selected, //true/false是否被选
                    text: text //文本值
                  });
                });
              }
            });var style = $($iframe).find("#operatorInfo").css("display");data = { arr: arr, brr: brr, crr: crr, drr: drr, sss: sss, style: style };
          } // if ($(this).find("iframe").contents().find("#suspendorresume").css("display") == "block") {
          // }
        }
      });return data;
    },
    doAction_uiControl3_0xvTEE: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if (data.eventType == "ChangValue") {
            $($iframe).find("#" + data.dataCustom.id).val(data.dataCustom.value).trigger(new Event('change')).focus().blur();
          } else if (data.eventType == "selectClick") {
            var evt = document.createEvent("mouseEvents");evt.initEvent("mousedown", true, true);$($iframe).find("#" + data.dataCustom).prev("input")[0].dispatchEvent(evt);
          } else if (data.eventType == "submit") {
            $($iframe).find("#" + data.dataCustom).click();
          } else if (data.eventType == "btnClick") {
            if (data.dataCustom == "readCardId") {
              $($iframe).find("#" + data.dataCustom).click();
            } else if (data.dataCustom == "copy") {
              $($iframe).find("#inputNoFillRemark").parent("div.form_control").next("div").children("div").eq(1).find("span.btn_normal").click();
            } else if (data.dataCustom == "nomal") {
              $($iframe).find("#inputNoFillRemark").parent("div.form_control").next("div").children("div").eq(0).find("span.btn_normal").click();
            } else if (data.dataCustom == "sendNoFillSMS") {
              $($iframe).find("#" + data.dataCustom).find("ins").click();
            }
          } else if (data.eventType == "showMore") {
            $($iframe).find("#shousuoId").click();
          }
        }
      });
    },
    getTemplate_uiControl3_0xvTEE: function () {
      var selfTemplate = "const Field = AMUI2.Field;\nconst Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var me = this;\n    if(!data){\n      return(\n      \t<div style={{display:\"none\"}}></div>\n      )\n    }\n    function type(item){\n      if(item.type==\"input\"){\n        return(\n        \t<AInput type=\"text\" data-id={item.id} value = {item.value} onBlur={function(e){me.ChangeValue(e,item.id)}}></AInput>\n        )\n      }else if(item.type==\"textarea\"){\n        return(\n        \t<ATextarea style={{border:\"1px solid #ccc\",width: \"90%\"}} data-id={item.id} value = {item.value} onBlur={function(e){me.ChangeValue(e,item.id)}}></ATextarea>\n        )\n      }\n    }\n    function text(item,num){\n      if(num == 1){\n        if(item.type == \"textarea\"){\n          return(\n          \t <ATextarea data-id ={item.selector} style={{border:\"1px solid #ccc\",width: \"90%\"}} value = {item.value} onBlur={function(e){me.ChangeValue(e,item.selector)}}></ATextarea>\n          )\n         }else if(item.type == \"input1\"){\n           return(\n           \t <li className=\"am2-item\" style={{borderTopWidth:\"0\",paddingBottom:\"0\",paddingLeft:\"0\"}} data-id={item.btnId} onClick={function(){me.selectClick(item.btnId)}}>\n                <h3 className=\"am2-item-title\">{item.value}</h3>\n               <span className=\"am2-icon am2-icon-right-nav am2-item-icon\"></span>\n             </li> \n           )\n         }\n      }else if(num == 2){\n        if(item.span1 == \"\"){\n          if(item.type == \"input1\"){\n            return(\n              <li className=\"am2-item\" style={{borderTop:0,paddingLeft:\"0\"}} data-id={item.id} onClick={function(){me.selectClick(item.id)}}>\n                <h3 className=\"am2-item-title\">{item.value}</h3>\n                <span className=\"am2-icon am2-icon-right-nav am2-item-icon\"></span>\n              </li>\n            )\n          }else{\n            return(\n            \t<span>\n              \t{type(item)}\n              </span>\n            )\n          }\n        }else{\n          if(item.span2){\n            if(item.span3){\n              return(\n                <div>\n                \t{type(item)}\n                  <Button amStyle=\"primary\" data-id={item.sid0} amSize=\"xs\" onClick={function(){me.btnClick(item.sid0)}}>{item.span1}</Button>\n                  <Button amStyle=\"primary\" data-id={item.sid1} amSize=\"xs\" onClick={function(){me.btnClick(item.sid1)}}>{item.span2}</Button>\n                  <span className=\"am2-item\" data-id={item.sid}>\n                    <span className=\"am2-item-after\">\n                      <label className=\"am2-switch\">\n                        <input type=\"checkbox\" checked={item.span3Type.indexOf(\"checked\") > -1 ? true : false} />\n                        <span className=\"am2-switch-checkbox\" onClick={function(){me.btnClick(item.sid)}}></span>\n                      </label>\n                    </span>\n                    <span className=\"am2-item-title\" onClick={function(){me.btnClick(item.sid)}}>{item.span3}</span>\n                  </span>\n                </div>\n              )\n            }\n          }else if(item.span1){\n            return(\n              <span>\n                {type(item)}\n                <Button amStyle=\"primary\" data-id={item.sid} amSize=\"xs\" style={{marginLeft:\"195px\",marginBottom:\"0px\"}} onClick={function(){me.btnClick(item.sid)}}>{item.span1}</Button>\n              </span>\n            )\n          }\n          if(item.value == \"\"){\n            return(\n            \t<span>\n              \t{type(item)}\n              </span>\n            )\n          }\n        }\n      }\n    }\n    return (\n      <div className=\"w-OMG\" style={{marginBottom:\"4rem\"}}>\n        {/*\u5BA2\u6237\u4FE1\u606F*/}\n        <div className=\"w-khxx\" style={{background:\"#fff\",paddingBottom:\"1rem\"}}>\n          {data.arr && data.arr.title?<p className=\"w-tit\">{data.arr.title}</p>:\"\"}\n          <div className=\"am2-field-single am2-field-underline-part\">\n            <div className=\"am2-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{data.arr.lable}</div></div>\n            <div className=\"am2-field-wrap\" style={{marginTop:\"0.6cm\",paddingLeft: \"0\"}}>{data.arr.text}</div>\n          </div>\n        </div>\n        {/*\u505C\u590D\u673A\u7C7B\u578B*/}\n        <div className=\"w-khlx\" style={{marginTop:\"10px\",background:\"#fff\",paddingBottom:\"1rem\"}}>\n        \t{data.brr && data.brr.map(function(item,i){\n            return(\n              <div className=\"am2-field-single am2-field-underline-part\"style={{padding:\"0\",lineHeight:\"25px\"}}>\n                <div className=\"am2-field-label\" style={{margin:\"0\",width:\"25%\",border:\"0\"}}><div>{item.lable}</div></div>\n                <div className=\"am2-field-wrap\" style={{border:\"0\"}}>\n                  {text(item,1)}\n                </div>\n              </div>\n            )\n          })}\n        </div>\n        {/*\u7ECF\u529E\u4EBA\u4FE1\u606F*/}\n        <div className=\"w-khjbr\" style={{background:\"#fff\"}}>\n        \t<p className=\"w-tit\">\n          \t<span >{data.crr[0].title}</span>\n            {/*<button style={{float:\"right\",border:\"none\",marginRight:\"15px\",marginTop:\"12px\",color:\"#0E90D2\"}} id=\"w-btn\" onClick={me.showMore}>{data.crr[0].select?\"\u5C55\u5F00\":\"\u6536\u7F29\"}</button>*/}\n          </p>\n          <div id=\"ndy\">\n          \t{data.crr && data.crr[1].textArray.map(function(item,i){\n              return(\n                <div className=\"am2-field-single am2-field-underline-part\">\n                  <div className=\"am2-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{item.lable}</div></div>\n                  <div className=\"am2-field-wrap\">\n                     {text(item,2)}\n                  </div>\n                </div>\n              )\n            })}\n          </div>\n        </div>\n        {/*\u63D0\u4EA4\u6309\u94AE*/}\n        {data.drr && data.drr.lable?<Button amStyle=\"primary\" amSize=\"sm\" id={data.drr.id} style={{width:\"100%\",margin:\"0\",position:\"fixed\",bottom:\"0\",background:\"#46B7F6\",border:\"none\"}} onClick={function(){me.submit(data.drr.id)}}>{data.drr.lable}</Button>:\"\"}\n      </div>\n    )\n  },\n  ChangeValue:function(e,id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"ChangValue\",\n        data: {\n          id:id,\n          value:e.target.value\n        }\n      });   \n    }\n  },\n  selectClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"selectClick\",\n        data:id\n      });   \n    }\n  },\n  showMore:function(e){ \n    // if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.getAttribute(\"id\") == \"ndy\" && e.target.parentNode.nextSibling.style.display == \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"none\";\n    //   e.target.innerHTML = \"\u5C55\u5F00\";\n    // }else if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.style.display != \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"block\";\n    //   e.target.innerHTML = \"\u6536\u7F29\";\n    // }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"showMore\"\n      });   \n    }\n  },\n  submit:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"submit\",\n        data:id\n      });   \n    }\n  },\n  btnClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"btnClick\",\n        data:id\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nvar Field = AMUI2.Field;\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var me = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { display: \"none\" } });\n    }\n    function type(item) {\n      if (item.type == \"input\") {\n        return React.createElement(AInput, { type: \"text\", \"data-id\": item.id, value: item.value, onBlur: function onBlur(e) {\n            me.ChangeValue(e, item.id);\n          } });\n      } else if (item.type == \"textarea\") {\n        return React.createElement(ATextarea, { style: { border: \"1px solid #ccc\", width: \"90%\" }, \"data-id\": item.id, value: item.value, onBlur: function onBlur(e) {\n            me.ChangeValue(e, item.id);\n          } });\n      }\n    }\n    function text(item, num) {\n      if (num == 1) {\n        if (item.type == \"textarea\") {\n          return React.createElement(ATextarea, { \"data-id\": item.selector, style: { border: \"1px solid #ccc\", width: \"90%\" }, value: item.value, onBlur: function onBlur(e) {\n              me.ChangeValue(e, item.selector);\n            } });\n        } else if (item.type == \"input1\") {\n          return React.createElement(\n            \"li\",\n            { className: \"am2-item\", style: { borderTopWidth: \"0\", paddingBottom: \"0\", paddingLeft: \"0\" }, \"data-id\": item.btnId, onClick: function onClick() {\n                me.selectClick(item.btnId);\n              } },\n            React.createElement(\n              \"h3\",\n              { className: \"am2-item-title\" },\n              item.value\n            ),\n            React.createElement(\"span\", { className: \"am2-icon am2-icon-right-nav am2-item-icon\" })\n          );\n        }\n      } else if (num == 2) {\n        if (item.span1 == \"\") {\n          if (item.type == \"input1\") {\n            return React.createElement(\n              \"li\",\n              { className: \"am2-item\", style: { borderTop: 0, paddingLeft: \"0\" }, \"data-id\": item.id, onClick: function onClick() {\n                  me.selectClick(item.id);\n                } },\n              React.createElement(\n                \"h3\",\n                { className: \"am2-item-title\" },\n                item.value\n              ),\n              React.createElement(\"span\", { className: \"am2-icon am2-icon-right-nav am2-item-icon\" })\n            );\n          } else {\n            return React.createElement(\n              \"span\",\n              null,\n              type(item)\n            );\n          }\n        } else {\n          if (item.span2) {\n            if (item.span3) {\n              return React.createElement(\n                \"div\",\n                null,\n                type(item),\n                React.createElement(\n                  Button,\n                  { amStyle: \"primary\", \"data-id\": item.sid0, amSize: \"xs\", onClick: function onClick() {\n                      me.btnClick(item.sid0);\n                    } },\n                  item.span1\n                ),\n                React.createElement(\n                  Button,\n                  { amStyle: \"primary\", \"data-id\": item.sid1, amSize: \"xs\", onClick: function onClick() {\n                      me.btnClick(item.sid1);\n                    } },\n                  item.span2\n                ),\n                React.createElement(\n                  \"span\",\n                  { className: \"am2-item\", \"data-id\": item.sid },\n                  React.createElement(\n                    \"span\",\n                    { className: \"am2-item-after\" },\n                    React.createElement(\n                      \"label\",\n                      { className: \"am2-switch\" },\n                      React.createElement(\"input\", { type: \"checkbox\", checked: item.span3Type.indexOf(\"checked\") > -1 ? true : false }),\n                      React.createElement(\"span\", { className: \"am2-switch-checkbox\", onClick: function onClick() {\n                          me.btnClick(item.sid);\n                        } })\n                    )\n                  ),\n                  React.createElement(\n                    \"span\",\n                    { className: \"am2-item-title\", onClick: function onClick() {\n                        me.btnClick(item.sid);\n                      } },\n                    item.span3\n                  )\n                )\n              );\n            }\n          } else if (item.span1) {\n            return React.createElement(\n              \"span\",\n              null,\n              type(item),\n              React.createElement(\n                Button,\n                { amStyle: \"primary\", \"data-id\": item.sid, amSize: \"xs\", style: { marginLeft: \"195px\", marginBottom: \"0px\" }, onClick: function onClick() {\n                    me.btnClick(item.sid);\n                  } },\n                item.span1\n              )\n            );\n          }\n          if (item.value == \"\") {\n            return React.createElement(\n              \"span\",\n              null,\n              type(item)\n            );\n          }\n        }\n      }\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"w-OMG\", style: { marginBottom: \"4rem\" } },\n      React.createElement(\n        \"div\",\n        { className: \"w-khxx\", style: { background: \"#fff\", paddingBottom: \"1rem\" } },\n        data.arr && data.arr.title ? React.createElement(\n          \"p\",\n          { className: \"w-tit\" },\n          data.arr.title\n        ) : \"\",\n        React.createElement(\n          \"div\",\n          { className: \"am2-field-single am2-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { className: \"am2-field-label\", style: { margin: \"0\", width: \"25%\" } },\n            React.createElement(\n              \"div\",\n              null,\n              data.arr.lable\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"am2-field-wrap\", style: { marginTop: \"0.6cm\", paddingLeft: \"0\" } },\n            data.arr.text\n          )\n        )\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"w-khlx\", style: { marginTop: \"10px\", background: \"#fff\", paddingBottom: \"1rem\" } },\n        data.brr && data.brr.map(function (item, i) {\n          return React.createElement(\n            \"div\",\n            { className: \"am2-field-single am2-field-underline-part\", style: { padding: \"0\", lineHeight: \"25px\" } },\n            React.createElement(\n              \"div\",\n              { className: \"am2-field-label\", style: { margin: \"0\", width: \"25%\", border: \"0\" } },\n              React.createElement(\n                \"div\",\n                null,\n                item.lable\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"am2-field-wrap\", style: { border: \"0\" } },\n              text(item, 1)\n            )\n          );\n        })\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"w-khjbr\", style: { background: \"#fff\" } },\n        React.createElement(\n          \"p\",\n          { className: \"w-tit\" },\n          React.createElement(\n            \"span\",\n            null,\n            data.crr[0].title\n          )\n        ),\n        React.createElement(\n          \"div\",\n          { id: \"ndy\" },\n          data.crr && data.crr[1].textArray.map(function (item, i) {\n            return React.createElement(\n              \"div\",\n              { className: \"am2-field-single am2-field-underline-part\" },\n              React.createElement(\n                \"div\",\n                { className: \"am2-field-label\", style: { margin: \"0\", width: \"25%\" } },\n                React.createElement(\n                  \"div\",\n                  null,\n                  item.lable\n                )\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"am2-field-wrap\" },\n                text(item, 2)\n              )\n            );\n          })\n        )\n      ),\n      data.drr && data.drr.lable ? React.createElement(\n        Button,\n        { amStyle: \"primary\", amSize: \"sm\", id: data.drr.id, style: { width: \"100%\", margin: \"0\", position: \"fixed\", bottom: \"0\", background: \"#46B7F6\", border: \"none\" }, onClick: function onClick() {\n            me.submit(data.drr.id);\n          } },\n        data.drr.lable\n      ) : \"\"\n    );\n  },\n  ChangeValue: function ChangeValue(e, id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"ChangValue\",\n        data: {\n          id: id,\n          value: e.target.value\n        }\n      });\n    }\n  },\n  selectClick: function selectClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"selectClick\",\n        data: id\n      });\n    }\n  },\n  showMore: function showMore(e) {\n    // if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.getAttribute(\"id\") == \"ndy\" && e.target.parentNode.nextSibling.style.display == \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"none\";\n    //   e.target.innerHTML = \"\u5C55\u5F00\";\n    // }else if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.style.display != \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"block\";\n    //   e.target.innerHTML = \"\u6536\u7F29\";\n    // }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"showMore\"\n      });\n    }\n  },\n  submit: function submit(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"submit\",\n        data: id\n      });\n    }\n  },\n  btnClick: function btnClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"btnClick\",\n        data: id\n      });\n    }\n  }\n});";
    },
    getData_control4_q6pgcE: function (elem) {
      if (!elem) {
        return;
      }var data = {};$(elem).children("div").map(function () {
        if ($(this).css("display") == "block") {
          var $iframe = $(this).find("iframe").contents();var select = {},
              _select = $iframe.find(".DroplistOption[style*='block']").eq(0) || null,
              a = 0;select.arr = [];select.index = null;$iframe.find(".DroplistOption").each(function (i, el) {
            if ($(this)[0].style.display == "block") {
              _select = el;select.index = i;a++;
            }
          });if (!!_select) {
            if (a < 2) {
              $(_select).find(".dropItem").each(function (i, el) {
                var text = $(this).text(),
                    id = $(this)[0].id;select.arr.push({ text: text, id: id });
              });
            }
          }
        }data = { select: select };
      });return data;
    },
    doAction_uiControl4_4vMPQv: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();var d = data.dataCustom,
              document = elem.ownerDocument;if (data.eventType === 'liClick') {
            $iframe.find("#" + d).mousedown().click();
          }if (data.eventType === 'closeSelect') {
            $iframe.find(".DroplistOption").css("display", "none");
          }
        }
      });
    },
    getTemplate_uiControl4_4vMPQv: function () {
      var selfTemplate = "const Modal = AMUI2.Modal;\nconst NavBar = AMUI2.NavBar;\nmodule.exports = React.createClass({\n  liClick:function(id){                                \n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:id,\n        eventType:'liClick'                         \n      })\n    }\n  },\n  closeSelect:function(index){\n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:index,\n        eventType:'closeSelect'                         \n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this;\n    \n    \tvar data = this.props.data.customData,\n        me=this;   \n    \tvar alert,window;   \n    \n      return (\n        <div>\n          <div className=\"am2-modal\">\n            <ul className=\"am2-list\" style={{margin:\"0\",maxHeight:\"300px\",overflow:\"auto\"}}>\n              {data.select.arr.map(function(el,i){\n                return(\n                  <li className=\"am2-item\" style={{textAlign:\"left\"}} onClick={function(){me.liClick(el.id)}}><h3 className=\"am2-item-title\">{el.text}</h3></li>\n                )\n              })}\n            </ul>\n          </div>\n          <div className={!!data.select.arr.length>0?\"am2-modal-backdrop backdrop-zIndex\":\"\"} onClick={function(){me.closeSelect(data.select.index)}}></div>\n          {alert}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar Modal = AMUI2.Modal;\nvar NavBar = AMUI2.NavBar;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  liClick: function liClick(id) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: id,\n        eventType: 'liClick'\n      });\n    }\n  },\n  closeSelect: function closeSelect(index) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: index,\n        eventType: 'closeSelect'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this;\n\n    var data = this.props.data.customData,\n        me = this;\n    var alert, window;\n\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        'div',\n        { className: 'am2-modal' },\n        React.createElement(\n          'ul',\n          { className: 'am2-list', style: { margin: \"0\", maxHeight: \"300px\", overflow: \"auto\" } },\n          data.select.arr.map(function (el, i) {\n            return React.createElement(\n              'li',\n              { className: 'am2-item', style: { textAlign: \"left\" }, onClick: function onClick() {\n                  me.liClick(el.id);\n                } },\n              React.createElement(\n                'h3',\n                { className: 'am2-item-title' },\n                el.text\n              )\n            );\n          })\n        )\n      ),\n      React.createElement('div', { className: !!data.select.arr.length > 0 ? \"am2-modal-backdrop backdrop-zIndex\" : \"\", onClick: function onClick() {\n          me.closeSelect(data.select.index);\n        } }),\n      alert\n    );\n  }\n});";
    },
    getData_control6_C1hMMA: function (elem) {
      if (!elem) {
        return;
      }var _select = null,
          a = 0;var popWin = {},
          popAlert = {};$(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if ($iframe.find(".popwin").size() > 0) {
            var $popMid = $iframe.find(".popwin");if ($popMid.last().attr("id").indexOf("winmsg") > -1) {
              $popLastAlert = $popMid.last();popAlert.text = $popLastAlert.find(".popwin_alert,.popwin_content").text();popAlert.title = $popLastAlert.find("#popwin_top").text();
            }var popId = $iframe.find(".popwin").eq(0).attr("id");popWin.title = $iframe.find(".popwin").eq(0).find("#popwin_top").text();if (popId.indexOf("winmsg") > -1) {
              popWin.popType = "winmsg";
            } else if (popId.indexOf("win") > -1) {
              popWin.popType = "win";
            }var $popMid = $iframe.find(".popwin").eq(0);if ($iframe.find(".popwin").size() > 1) {
              popAlert.text = $iframe.find(".popwin").eq(1).find(".popwin_alert").text();
            }if (popWin.title == "提示") {
              popWin.text = $popMid.find(".popwin_alert,.popwin_content").text();
            }if (popWin.title == "常用免填单备注") {
              popWin.arr = [], popWin.btn = [];$popMid.find(".wb_opt").prev("div").find("label").map(function () {
                popWin.arr.push({ "cls": $(this).attr("class"), "txt": $(this).find("span").text() });
              });$popMid.find(".wb_opt").children("span").map(function () {
                popWin.btn.push({ id: $(this).attr("id"), txt: $(this).text().trim() });
              });
            }
          }
        }
      });return { popWin: popWin, popAlert: popAlert };
    },
    doAction_uiControl5_erkfWy: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if (data.eventType == "clickRadio") {
            $($iframe).find(".popwin").eq(0).find(".wb_opt").prev("div").find("label").eq(data.dataCustom).find("ins").click();
          } else if (data.eventType === 'clickBtn') {
            // $($iframe).find(".popwin").eq(0).find(".wb_opt").prev("div").find("label.checked").click();
            $iframe.find("#" + data.dataCustom).click();
          } else if (data.eventType === 'closeAlert') {
            $iframe.find(".popwin .popwin_btn_group .uee-msgbox-ok").click();
          }
        }
      });
    },
    getTemplate_uiControl5_erkfWy: function () {
      var selfTemplate = "const Modal = require('ysp-custom-components').Modal;\nconst NavBar = AMUI2.NavBar;\nconst Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.data.customData,\n        _this = this;\n    \tconst special={\n        display:\"inline-block\",\n        fontSize:\"14px\",\n        margin:\"0 .5rem\",\n        border:\"none\",\n        padding:\"0\"\n      }\n      const span ={\n        verticalAlign: 'middle',\n        height: '40px',\n        lineHeight: '45px',\n        display: 'inline-block',\n      }\n    \tvar alert,window;\n    \tif(data.popWin.title == \"\u5E38\u7528\u514D\u586B\u5355\u5907\u6CE8\"){\n        window = <div className=\"w-tip\">\n        <ul className=\"w-content\">\n          {data.popWin.arr.map(function(item,i){\n            return(\n              <li className=\"am2-item\" onClick={function(){_this.clickRadio(i)}} style={special}>\n                <span className=\"am2-item-after\" style={span} onClick={function(){_this.clickRadio(i)}}>\n                  <label className=\"am2-switch\">\n                    <input type=\"checkbox\" checked={item.cls.indexOf(\"checked\") > -1 ? true : false} />\n                    <span className=\"am2-switch-checkbox\"></span>\n                  </label>\n                </span>\n                <span className=\"am2-item-title\" style={span}>{item.txt}</span>\n              </li>\n            )\n          })}\n        </ul>\n        <div>\n        \t{data.popWin.btn.map(function(item,i){\n            if(i == 0){\n              return(\n                <Button amStyle=\"primary\" rounded id= {item.id} style={{width:\"45%\",marginRight:\"5%\"}} onClick={function(){_this.clickBtn(item.id)}}>{item.txt}</Button>\n              )\n            }else{\n              return(\n                <Button amStyle=\"warning\" rounded id= {item.id} style={{width:\"45%\",marginRight:\"5%\"}} onClick={function(){_this.clickBtn(item.id)}}>{item.txt}</Button>\n              )\n            }\n          })}\n        </div>\n      </div>\n      }\n    if(data.popWin.popType == \"winmsg\" || !!data.popAlert.text){\n        alert = <div>\n              <div className=\"am2-modal am2-modal-alert\">\n                <div className=\"am2-modal-inner\">\n                  <div className=\"am2-modal-dialog\">\n                    <div className=\"am2-modal-header\"><h4 className=\"am2-modal-title\">{data.popWin.title}</h4></div>\n                    <div className=\"am2-modal-body\">{data.popWin.text}{data.popAlert.text}</div>\n                    <div className=\"am2-modal-footer\">\n                      <span className=\"am2-modal-btn\" onClick={_this.closeAlert}>\u786E\u5B9A</span>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            <div className={!!data.popWin.text || !!data.popAlert.text?\"am2-modal-backdrop\":\"\"}></div>\n          </div>\n      }\n      return (\n        <div>\n          {alert}\n          <Modal\n          ref=\"modal\"\n          role=\"modal\"\n          isOpen={data.popWin.popType == \"win\"?true:false}\n          title={data.popWin.title}\n          >\n            {window}\n        \t</Modal>\n      </div>\n    )\n  },\n  clickBtn:function(id){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\"clickBtn\",\n        data:id\n      })\n    }\n  },\n  clickRadio:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\"clickRadio\",\n        data:i\n      })\n    }\n  },\n    closeAlert:function(){                                \n    var callBack = this.props.customHandler;\n    if(callBack) {                                    \n      callBack({\n        eventType:'closeAlert'  \n      })\n    }\n  }\n});";
      return "\"use strict\";\n\nvar Modal = require('ysp-custom-components').Modal;\nvar NavBar = AMUI2.NavBar;\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData,\n        _this = this;\n    var special = {\n      display: \"inline-block\",\n      fontSize: \"14px\",\n      margin: \"0 .5rem\",\n      border: \"none\",\n      padding: \"0\"\n    };\n    var span = {\n      verticalAlign: 'middle',\n      height: '40px',\n      lineHeight: '45px',\n      display: 'inline-block'\n    };\n    var alert, window;\n    if (data.popWin.title == \"\u5E38\u7528\u514D\u586B\u5355\u5907\u6CE8\") {\n      window = React.createElement(\n        \"div\",\n        { className: \"w-tip\" },\n        React.createElement(\n          \"ul\",\n          { className: \"w-content\" },\n          data.popWin.arr.map(function (item, i) {\n            return React.createElement(\n              \"li\",\n              { className: \"am2-item\", onClick: function onClick() {\n                  _this.clickRadio(i);\n                }, style: special },\n              React.createElement(\n                \"span\",\n                { className: \"am2-item-after\", style: span, onClick: function onClick() {\n                    _this.clickRadio(i);\n                  } },\n                React.createElement(\n                  \"label\",\n                  { className: \"am2-switch\" },\n                  React.createElement(\"input\", { type: \"checkbox\", checked: item.cls.indexOf(\"checked\") > -1 ? true : false }),\n                  React.createElement(\"span\", { className: \"am2-switch-checkbox\" })\n                )\n              ),\n              React.createElement(\n                \"span\",\n                { className: \"am2-item-title\", style: span },\n                item.txt\n              )\n            );\n          })\n        ),\n        React.createElement(\n          \"div\",\n          null,\n          data.popWin.btn.map(function (item, i) {\n            if (i == 0) {\n              return React.createElement(\n                Button,\n                { amStyle: \"primary\", rounded: true, id: item.id, style: { width: \"45%\", marginRight: \"5%\" }, onClick: function onClick() {\n                    _this.clickBtn(item.id);\n                  } },\n                item.txt\n              );\n            } else {\n              return React.createElement(\n                Button,\n                { amStyle: \"warning\", rounded: true, id: item.id, style: { width: \"45%\", marginRight: \"5%\" }, onClick: function onClick() {\n                    _this.clickBtn(item.id);\n                  } },\n                item.txt\n              );\n            }\n          })\n        )\n      );\n    }\n    if (data.popWin.popType == \"winmsg\" || !!data.popAlert.text) {\n      alert = React.createElement(\n        \"div\",\n        null,\n        React.createElement(\n          \"div\",\n          { className: \"am2-modal am2-modal-alert\" },\n          React.createElement(\n            \"div\",\n            { className: \"am2-modal-inner\" },\n            React.createElement(\n              \"div\",\n              { className: \"am2-modal-dialog\" },\n              React.createElement(\n                \"div\",\n                { className: \"am2-modal-header\" },\n                React.createElement(\n                  \"h4\",\n                  { className: \"am2-modal-title\" },\n                  data.popWin.title\n                )\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"am2-modal-body\" },\n                data.popWin.text,\n                data.popAlert.text\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"am2-modal-footer\" },\n                React.createElement(\n                  \"span\",\n                  { className: \"am2-modal-btn\", onClick: _this.closeAlert },\n                  \"\\u786E\\u5B9A\"\n                )\n              )\n            )\n          )\n        ),\n        React.createElement(\"div\", { className: !!data.popWin.text || !!data.popAlert.text ? \"am2-modal-backdrop\" : \"\" })\n      );\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      alert,\n      React.createElement(\n        Modal,\n        {\n          ref: \"modal\",\n          role: \"modal\",\n          isOpen: data.popWin.popType == \"win\" ? true : false,\n          title: data.popWin.title\n        },\n        window\n      )\n    );\n  },\n  clickBtn: function clickBtn(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"clickBtn\",\n        data: id\n      });\n    }\n  },\n  clickRadio: function clickRadio(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"clickRadio\",\n        data: i\n      });\n    }\n  },\n  closeAlert: function closeAlert() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'closeAlert'\n      });\n    }\n  }\n});";
    },
    getData_control82_QBHh5z: function (elem) {
      if (!elem) {
        return;
      }var $elem = $(elem),
          reserveOrderId = $elem.find("#reserveOrderId").text(),
          cellphoneNumber = $elem.find("#cellphoneNumber").text(),
          SESBtn = $elem.find("#signElectronicACKSlip_btn").text().trim();return { reserveOrderId, cellphoneNumber, SESBtn };
    },
    doAction_uiControl76_cvHNf8: function (data, elem) {},
    getTemplate_uiControl76_cvHNf8: function () {
      var selfTemplate = "module.exports = React.createClass({\n  getInitialState(){\n    return {show:false};\n  },\n  toggleState(){\n    this.setState({show:!this.state.show});\n  },\n  handle(data,eventType){                                \n    var callBack = this.props.customHandler,\n        me = this;          \n    if(callBack) {                                    \n      callBack({data,eventType})\n    }\n    me.toggleState();\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        state = me.state,\n        window;\n    if(!data){\n      return(<span></span>)\n    }\n    const itemLeft = {\n      title: \"\u5173\u95ED\",\n      onClick: () => me.toggleState(),\n    };\n    const dataAll = {\n      title: !!data.obj?data.obj.template[0].templateName:\"\",\n      leftNav: [{...itemLeft, icon: 'left-nav'}]\n    };\n    return (\n      <div>\n      \t<ul style={{textAlign:\"center\",paddingBottom:\"1rem\"}}>\n          <li>\u8BA2\u5355\u53F7\uFF1A{data.reserveOrderId}</li>\n          <li>\u624B\u673A\u53F7\uFF1A{data.cellphoneNumber}</li>\n          {/*<li><button className=\"am2-btn am2-btn-xs am2-btn-success\" onClick={()=>{me.handle({id:data.reserveOrderId,num:data.cellphoneNumber},\"click\")}}>{data.SESBtn}</button></li>*/}\n        </ul>\n      </div>\n      \n    )\n  }\n});";
      return "\"use strict\";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  getInitialState: function getInitialState() {\n    return { show: false };\n  },\n  toggleState: function toggleState() {\n    this.setState({ show: !this.state.show });\n  },\n  handle: function handle(data, eventType) {\n    var callBack = this.props.customHandler,\n        me = this;\n    if (callBack) {\n      callBack({ data: data, eventType: eventType });\n    }\n    me.toggleState();\n  },\n\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        state = me.state,\n        window;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    var itemLeft = {\n      title: \"\u5173\u95ED\",\n      onClick: function onClick() {\n        return me.toggleState();\n      }\n    };\n    var dataAll = {\n      title: !!data.obj ? data.obj.template[0].templateName : \"\",\n      leftNav: [_extends({}, itemLeft, { icon: 'left-nav' })]\n    };\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"ul\",\n        { style: { textAlign: \"center\", paddingBottom: \"1rem\" } },\n        React.createElement(\n          \"li\",\n          null,\n          \"\\u8BA2\\u5355\\u53F7\\uFF1A\",\n          data.reserveOrderId\n        ),\n        React.createElement(\n          \"li\",\n          null,\n          \"\\u624B\\u673A\\u53F7\\uFF1A\",\n          data.cellphoneNumber\n        )\n      )\n    );\n  }\n});";
    },
    getData_control95_6BoUuk: function (elem) {
      if (!elem) {
        return;
      }var data = {};var rp = function (text) {
        if (text) {
          return text.trim();
        }return '';
      };$(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if ($iframe.find("#suspendorresume").css("display") == "block") {
            var arr = {},
                obj1 = $($iframe).find(".has_recommend").children().eq(0);arr.title = obj1.find(".pl_title").text();arr.lable = obj1.find(".form-group.per100").children().eq(0).text();arr.text = obj1.find("span").text();var brr = [],
                obj2 = $($iframe).find(".has_recommend").children().eq(1);obj2.find(".pl_content > .form_con").children(':not(.ng-hide)').each(function (i, d) {
              var lable = rp($(d).find(".form_label").text()),
                  ipt = $(d).find('input,textarea'); //找到包含input或textarea的元素
              if (ipt[0] && ipt[0].tagName == 'INPUT') {
                var id = $(d).find(".trigger").attr("id"),
                    // span的id
                type = "input1";brr.push({ lable: lable, btnId: id, // span的id
                  type: type, value: $(d).find(".trigger").prev().val() });
              } else if (ipt[0] && ipt[0].tagName == 'TEXTAREA') {
                var type = "textarea";brr.push({ lable: lable, selector: $(d).find("textarea").attr("id"), //文本框的id
                  type: type, value: $(d).find("textarea").val() });
              }
            });var crr = [],
                title = {},
                textArray = [],
                obj3 = $($iframe).find(".has_recommend").children().eq(2);crr.push({ title: rp(obj3.find(".pl_title").text()), //获取经办人信息文本
              select: obj3.find(".pl_title").parent(".panel").hasClass("selected") });crr.push({ textArray: textArray });obj3.find(".form_row.form_con").children().each(function (i, ng) {
              var lable = rp($(ng).find(".form_label.ng-binding").text()),
                  //姓名
              value = "",
                  //输入框的值
              type = "",
                  //看类型是input还是textarea
              id = "",
                  //input/textarea的id
              ipt = $(ng).find('input,textarea');var qufen = "";if ($(ng).children().length == 2) {
                if (ipt[0] && ipt[0].tagName == 'INPUT') {
                  // type = "input";
                  id = $(ng).find("input[type='text']").attr("id") || $(ng).find(".trigger").attr("id");var span1 = $(ng).find(".btn_normal.vt_middle.ng-binding").text(),
                      //span的文本值（读取）
                  sid = $(ng).find(".btn_normal.vt_middle.ng-binding").attr("id"); //span文本值的id
                  if ($(ng).find(".trigger").length) {
                    qufen = $(ng).find("input").val();type = "input1";
                  } else {
                    qufen = $(ng).find("input").val();type = "input";
                  }textArray.push({ lable: lable, // value: $(ng).find("input").val(),
                    value: qufen, type: type, id: id, //输入框的id
                    span1: span1 || "", //span的文本值（读取）
                    sid: sid //span文本值的id
                  });
                } else if (ipt[0] && ipt[0].tagName == 'TEXTAREA') {
                  type = "textarea";id = $(ng).find(".form_textarea.ng-pristine").attr("id");if ($(ng).find(".trigger").length) {
                    qufen = $(ng).find(".form_textarea.ng-pristine").val();
                  } else {
                    qufen = $(ng).find("textarea").val();
                  }textArray.push({ lable: lable, // value: $(ng).find(".form_textarea.ng-pristine").val(),
                    value: qufen, type: type, id: id, //输入框的id
                    span1: "" });
                }
              } else if ($(ng).children().length == 3) {
                type = "textarea";id = $(ng).children().find(".form_textarea").attr("id");value = $(ng).children().find(".form_textarea").val();var span1 = rp($(ng).children().find("span").eq(0).text()),
                    span2 = rp($(ng).children().find("span").eq(1).text()),
                    // sid = $(ng).children().find("span").eq(0).attr("class"),
                // sid1 = $(ng).children().find("span").eq(1).attr("class"),
                sid0 = "nomal",
                    sid1 = "copy",
                    span3 = $(ng).find(".checkbox").text(),
                    sid = $(ng).children().find(".checkbox").attr("id"); //span标签的id
                textArray.push({ lable: lable, value: value, type: type, id: id, //文本框的id
                  span1: span1, //获取span标签的文本值（常用模板）
                  span2: span2, //获取span标签的文本值（一键复制）
                  sid0: sid0, //获取span标签的（常用模板）的id
                  sid1: sid1, //获取span标签的（一键复制）的id
                  span3: span3, //获取span标签的文本值（发送免填单短信）
                  span3Type: $(ng).children().find(".checkbox").attr("class"), //class="checkbox checked"是否被选
                  sid: sid //span标签的id
                });
              }
            });var drr = {},
                obj4 = $($iframe).find(".has_recommend").children().eq(4);rp(obj4.find(".btn_positive").text()) != "提交" && (drr.lable = rp(obj4.find(".btn_positive").text()));drr.id = obj4.find(".btn_positive").attr("id");var sss = [];$($iframe).children(".DroplistOption").each(function (i, d) {
              if ($(d).css('display') == 'block') {
                $(d).find("li").each(function (i, l) {
                  var selected = $(l).hasClass("selected") ? true : false,
                      text = $(l).text();sss.push({ selected: selected, //true/false是否被选
                    text: text });
                });
              }
            });var style = $($iframe).find("#operatorInfo").css("display");data = { arr: arr, brr: brr, crr: crr, drr: drr, sss: sss, style: style };
          } // if ($(this).find("iframe").contents().find("#suspendorresume").css("display") == "block") {
          // }
        }
      });return data;
    },
    doAction_uiControl86_P30RV4: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if (data.eventType == "ChangValue") {
            $($iframe).find("#" + data.dataCustom.id).val(data.dataCustom.value).trigger(new Event('change')).focus().blur();
          } else if (data.eventType == "selectClick") {
            var evt = document.createEvent("mouseEvents");evt.initEvent("mousedown", true, true);$($iframe).find("#" + data.dataCustom).prev("input")[0].dispatchEvent(evt);
          } else if (data.eventType == "submit") {
            $($iframe).find("#" + data.dataCustom).click();
          } else if (data.eventType == "btnClick") {
            if (data.dataCustom == "readCardId") {
              $($iframe).find("#" + data.dataCustom).click();
            } else if (data.dataCustom == "copy") {
              $($iframe).find("#inputNoFillRemark").parent("div.form_control").next("div").children("div").eq(1).find("span.btn_normal").click();
            } else if (data.dataCustom == "nomal") {
              $($iframe).find("#inputNoFillRemark").parent("div.form_control").next("div").children("div").eq(0).find("span.btn_normal").click();
            } else if (data.dataCustom == "sendNoFillSMS") {
              $($iframe).find("#" + data.dataCustom).find("ins").click();
            }
          } else if (data.eventType == "showMore") {
            $($iframe).find("#shousuoId").click();
          }
        }
      });
    },
    getTemplate_uiControl86_P30RV4: function () {
      var selfTemplate = "const Field = AMUI2.Field;\nconst Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var me = this;\n    if(!data || !data.arr){\n      return(\n      \t<div style={{display:\"none\"}}></div>\n      )\n    }\n    function type(item){\n      if(item.type==\"input\"){\n        return(\n        \t<AInput type=\"text\" data-id={item.id} value = {item.value} onBlur={function(e){me.ChangeValue(e,item.id)}}></AInput>\n        )\n      }else if(item.type==\"textarea\"){\n        return(\n        \t<ATextarea style={{border:\"1px solid #ccc\",width: \"90%\"}} data-id={item.id} value = {item.value} onBlur={function(e){me.ChangeValue(e,item.id)}}></ATextarea>\n        )\n      }\n    }\n    function text(item,num){\n      if(num == 1){\n        if(item.type == \"textarea\"){\n          return(\n          \t <ATextarea data-id ={item.selector} style={{border:\"1px solid #ccc\",width: \"90%\"}} value = {item.value} onBlur={function(e){me.ChangeValue(e,item.selector)}}></ATextarea>\n          )\n         }else if(item.type == \"input1\"){\n           return(\n           \t <li className=\"am2-item\" style={{borderTopWidth:\"0\",paddingBottom:\"0\",paddingLeft:\"0\"}} data-id={item.btnId} onClick={function(){me.selectClick(item.btnId)}}>\n                <h3 className=\"am2-item-title\">{item.value}</h3>\n               <span className=\"am2-icon am2-icon-right-nav am2-item-icon\"></span>\n             </li> \n           )\n         }\n      }else if(num == 2){\n        if(item.span1 == \"\"){\n          if(item.type == \"input1\"){\n            return(\n              <li className=\"am2-item\" style={{borderTop:0,paddingLeft:\"0\"}} data-id={item.id} onClick={function(){me.selectClick(item.id)}}>\n                <h3 className=\"am2-item-title\">{item.value}</h3>\n                <span className=\"am2-icon am2-icon-right-nav am2-item-icon\"></span>\n              </li>\n            )\n          }else{\n            return(\n            \t<span>\n              \t{type(item)}\n              </span>\n            )\n          }\n        }else{\n          if(item.span2){\n            if(item.span3){\n              return(\n                <div>\n                \t{type(item)}\n                  <Button amStyle=\"primary\" data-id={item.sid0} amSize=\"xs\" onClick={function(){me.btnClick(item.sid0)}}>{item.span1}</Button>\n                  <Button amStyle=\"primary\" data-id={item.sid1} amSize=\"xs\" onClick={function(){me.btnClick(item.sid1)}}>{item.span2}</Button>\n                  <span className=\"am2-item\" data-id={item.sid}>\n                    <span className=\"am2-item-after\">\n                      <label className=\"am2-switch\">\n                        <input type=\"checkbox\" checked={item.span3Type.indexOf(\"checked\") > -1 ? true : false} />\n                        <span className=\"am2-switch-checkbox\" onClick={function(){me.btnClick(item.sid)}}></span>\n                      </label>\n                    </span>\n                    <span className=\"am2-item-title\" onClick={function(){me.btnClick(item.sid)}}>{item.span3}</span>\n                  </span>\n                </div>\n              )\n            }\n          }else if(item.span1){\n            return(\n              <span>\n                {type(item)}\n                <Button amStyle=\"primary\" data-id={item.sid} amSize=\"xs\" style={{marginLeft:\"195px\",marginBottom:\"0px\"}} onClick={function(){me.btnClick(item.sid)}}>{item.span1}</Button>\n              </span>\n            )\n          }\n          if(item.value == \"\"){\n            return(\n            \t<span>\n              \t{type(item)}\n              </span>\n            )\n          }\n        }\n      }\n    }\n    var btn = [];\n    if(data.drr.label){\n       btn.push(\n       \t<Button amStyle=\"primary\" amSize=\"sm\" id={data.drr.id} style={{width:\"100%\",margin:\"0\",position:\"fixed\",bottom:\"0\",background:\"#46B7F6\",border:\"none\"}} onClick={function(){me.submit(data.drr.id)}}>{data.drr.lable}</Button>\n       )\n    }\n    return (\n      <div className=\"w-OMG\" style={{marginBottom:\"4rem\"}}>\n        {/*\u5BA2\u6237\u4FE1\u606F*/}\n        <div className=\"w-khxx\" style={{background:\"#fff\",paddingBottom:\"1rem\"}}>\n        \t<p className=\"w-tit\">{data.arr.title}</p>\n          <div className=\"am2-field-single am2-field-underline-part\">\n            <div className=\"am2-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{data.arr.lable}</div></div>\n            <div className=\"am2-field-wrap\" style={{marginTop:\"0.6cm\",paddingLeft: \"0\"}}>{data.arr.text}</div>\n          </div>\n        </div>\n        {/*\u505C\u590D\u673A\u7C7B\u578B*/}\n        <div className=\"w-khlx\" style={{marginTop:\"10px\",background:\"#fff\",paddingBottom:\"1rem\"}}>\n        \t{data.brr.map(function(item,i){\n            return(\n              <div className=\"am2-field-single am2-field-underline-part\"style={{padding:\"0\",lineHeight:\"25px\"}}>\n                <div className=\"am2-field-label\" style={{margin:\"0\",width:\"25%\",border:\"0\"}}><div>{item.lable}</div></div>\n                <div className=\"am2-field-wrap\" style={{border:\"0\"}}>\n                  {text(item,1)}\n                </div>\n              </div>\n            )\n          })}\n        </div>\n        {/*\u7ECF\u529E\u4EBA\u4FE1\u606F*/}\n        <div className=\"w-khjbr\" style={{background:\"#fff\"}}>\n        \t<p className=\"w-tit\">\n          \t<span >{data.crr[0].title}</span>\n            {/*<button style={{float:\"right\",border:\"none\",marginRight:\"15px\",marginTop:\"12px\",color:\"#0E90D2\"}} id=\"w-btn\" onClick={me.showMore}>{data.crr[0].select?\"\u5C55\u5F00\":\"\u6536\u7F29\"}</button>*/}\n          </p>\n          <div id=\"ndy\">\n          \t{data.crr[1].textArray.map(function(item,i){\n              return(\n                <div className=\"am2-field-single am2-field-underline-part\">\n                  <div className=\"am2-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{item.lable}</div></div>\n                  <div className=\"am2-field-wrap\">\n                     {text(item,2)}\n                  </div>\n                </div>\n              )\n            })}\n          </div>\n        </div>\n        {/*\u63D0\u4EA4\u6309\u94AE*/}\n        { btn }\n      </div>\n    )\n  },\n  ChangeValue:function(e,id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"ChangValue\",\n        data: {\n          id:id,\n          value:e.target.value\n        }\n      });   \n    }\n  },\n  selectClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"selectClick\",\n        data:id\n      });   \n    }\n  },\n  showMore:function(e){ \n    // if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.getAttribute(\"id\") == \"ndy\" && e.target.parentNode.nextSibling.style.display == \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"none\";\n    //   e.target.innerHTML = \"\u5C55\u5F00\";\n    // }else if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.style.display != \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"block\";\n    //   e.target.innerHTML = \"\u6536\u7F29\";\n    // }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"showMore\"\n      });   \n    }\n  },\n  submit:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"submit\",\n        data:id\n      });   \n    }\n  },\n  btnClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"btnClick\",\n        data:id\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nvar Field = AMUI2.Field;\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var me = this;\n    if (!data || !data.arr) {\n      return React.createElement(\"div\", { style: { display: \"none\" } });\n    }\n    function type(item) {\n      if (item.type == \"input\") {\n        return React.createElement(AInput, { type: \"text\", \"data-id\": item.id, value: item.value, onBlur: function onBlur(e) {\n            me.ChangeValue(e, item.id);\n          } });\n      } else if (item.type == \"textarea\") {\n        return React.createElement(ATextarea, { style: { border: \"1px solid #ccc\", width: \"90%\" }, \"data-id\": item.id, value: item.value, onBlur: function onBlur(e) {\n            me.ChangeValue(e, item.id);\n          } });\n      }\n    }\n    function text(item, num) {\n      if (num == 1) {\n        if (item.type == \"textarea\") {\n          return React.createElement(ATextarea, { \"data-id\": item.selector, style: { border: \"1px solid #ccc\", width: \"90%\" }, value: item.value, onBlur: function onBlur(e) {\n              me.ChangeValue(e, item.selector);\n            } });\n        } else if (item.type == \"input1\") {\n          return React.createElement(\n            \"li\",\n            { className: \"am2-item\", style: { borderTopWidth: \"0\", paddingBottom: \"0\", paddingLeft: \"0\" }, \"data-id\": item.btnId, onClick: function onClick() {\n                me.selectClick(item.btnId);\n              } },\n            React.createElement(\n              \"h3\",\n              { className: \"am2-item-title\" },\n              item.value\n            ),\n            React.createElement(\"span\", { className: \"am2-icon am2-icon-right-nav am2-item-icon\" })\n          );\n        }\n      } else if (num == 2) {\n        if (item.span1 == \"\") {\n          if (item.type == \"input1\") {\n            return React.createElement(\n              \"li\",\n              { className: \"am2-item\", style: { borderTop: 0, paddingLeft: \"0\" }, \"data-id\": item.id, onClick: function onClick() {\n                  me.selectClick(item.id);\n                } },\n              React.createElement(\n                \"h3\",\n                { className: \"am2-item-title\" },\n                item.value\n              ),\n              React.createElement(\"span\", { className: \"am2-icon am2-icon-right-nav am2-item-icon\" })\n            );\n          } else {\n            return React.createElement(\n              \"span\",\n              null,\n              type(item)\n            );\n          }\n        } else {\n          if (item.span2) {\n            if (item.span3) {\n              return React.createElement(\n                \"div\",\n                null,\n                type(item),\n                React.createElement(\n                  Button,\n                  { amStyle: \"primary\", \"data-id\": item.sid0, amSize: \"xs\", onClick: function onClick() {\n                      me.btnClick(item.sid0);\n                    } },\n                  item.span1\n                ),\n                React.createElement(\n                  Button,\n                  { amStyle: \"primary\", \"data-id\": item.sid1, amSize: \"xs\", onClick: function onClick() {\n                      me.btnClick(item.sid1);\n                    } },\n                  item.span2\n                ),\n                React.createElement(\n                  \"span\",\n                  { className: \"am2-item\", \"data-id\": item.sid },\n                  React.createElement(\n                    \"span\",\n                    { className: \"am2-item-after\" },\n                    React.createElement(\n                      \"label\",\n                      { className: \"am2-switch\" },\n                      React.createElement(\"input\", { type: \"checkbox\", checked: item.span3Type.indexOf(\"checked\") > -1 ? true : false }),\n                      React.createElement(\"span\", { className: \"am2-switch-checkbox\", onClick: function onClick() {\n                          me.btnClick(item.sid);\n                        } })\n                    )\n                  ),\n                  React.createElement(\n                    \"span\",\n                    { className: \"am2-item-title\", onClick: function onClick() {\n                        me.btnClick(item.sid);\n                      } },\n                    item.span3\n                  )\n                )\n              );\n            }\n          } else if (item.span1) {\n            return React.createElement(\n              \"span\",\n              null,\n              type(item),\n              React.createElement(\n                Button,\n                { amStyle: \"primary\", \"data-id\": item.sid, amSize: \"xs\", style: { marginLeft: \"195px\", marginBottom: \"0px\" }, onClick: function onClick() {\n                    me.btnClick(item.sid);\n                  } },\n                item.span1\n              )\n            );\n          }\n          if (item.value == \"\") {\n            return React.createElement(\n              \"span\",\n              null,\n              type(item)\n            );\n          }\n        }\n      }\n    }\n    var btn = [];\n    if (data.drr.label) {\n      btn.push(React.createElement(\n        Button,\n        { amStyle: \"primary\", amSize: \"sm\", id: data.drr.id, style: { width: \"100%\", margin: \"0\", position: \"fixed\", bottom: \"0\", background: \"#46B7F6\", border: \"none\" }, onClick: function onClick() {\n            me.submit(data.drr.id);\n          } },\n        data.drr.lable\n      ));\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"w-OMG\", style: { marginBottom: \"4rem\" } },\n      React.createElement(\n        \"div\",\n        { className: \"w-khxx\", style: { background: \"#fff\", paddingBottom: \"1rem\" } },\n        React.createElement(\n          \"p\",\n          { className: \"w-tit\" },\n          data.arr.title\n        ),\n        React.createElement(\n          \"div\",\n          { className: \"am2-field-single am2-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { className: \"am2-field-label\", style: { margin: \"0\", width: \"25%\" } },\n            React.createElement(\n              \"div\",\n              null,\n              data.arr.lable\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"am2-field-wrap\", style: { marginTop: \"0.6cm\", paddingLeft: \"0\" } },\n            data.arr.text\n          )\n        )\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"w-khlx\", style: { marginTop: \"10px\", background: \"#fff\", paddingBottom: \"1rem\" } },\n        data.brr.map(function (item, i) {\n          return React.createElement(\n            \"div\",\n            { className: \"am2-field-single am2-field-underline-part\", style: { padding: \"0\", lineHeight: \"25px\" } },\n            React.createElement(\n              \"div\",\n              { className: \"am2-field-label\", style: { margin: \"0\", width: \"25%\", border: \"0\" } },\n              React.createElement(\n                \"div\",\n                null,\n                item.lable\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"am2-field-wrap\", style: { border: \"0\" } },\n              text(item, 1)\n            )\n          );\n        })\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"w-khjbr\", style: { background: \"#fff\" } },\n        React.createElement(\n          \"p\",\n          { className: \"w-tit\" },\n          React.createElement(\n            \"span\",\n            null,\n            data.crr[0].title\n          )\n        ),\n        React.createElement(\n          \"div\",\n          { id: \"ndy\" },\n          data.crr[1].textArray.map(function (item, i) {\n            return React.createElement(\n              \"div\",\n              { className: \"am2-field-single am2-field-underline-part\" },\n              React.createElement(\n                \"div\",\n                { className: \"am2-field-label\", style: { margin: \"0\", width: \"25%\" } },\n                React.createElement(\n                  \"div\",\n                  null,\n                  item.lable\n                )\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"am2-field-wrap\" },\n                text(item, 2)\n              )\n            );\n          })\n        )\n      ),\n      btn\n    );\n  },\n  ChangeValue: function ChangeValue(e, id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"ChangValue\",\n        data: {\n          id: id,\n          value: e.target.value\n        }\n      });\n    }\n  },\n  selectClick: function selectClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"selectClick\",\n        data: id\n      });\n    }\n  },\n  showMore: function showMore(e) {\n    // if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.getAttribute(\"id\") == \"ndy\" && e.target.parentNode.nextSibling.style.display == \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"none\";\n    //   e.target.innerHTML = \"\u5C55\u5F00\";\n    // }else if(e.target.nodeName == \"BUTTON\" && e.target.parentNode.nextSibling.style.display != \"block\"){\n    //   e.target.parentNode.nextSibling.style.display = \"block\";\n    //   e.target.innerHTML = \"\u6536\u7F29\";\n    // }\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"showMore\"\n      });\n    }\n  },\n  submit: function submit(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"submit\",\n        data: id\n      });\n    }\n  },\n  btnClick: function btnClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"btnClick\",\n        data: id\n      });\n    }\n  }\n});";
    },
    getData_control96_EI3BBG: function (elem) {
      if (!elem) {
        return;
      }var _select = null,
          a = 0;var popWin = {},
          popAlert = {};$(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if ($iframe.find(".popwin").size() > 0) {
            var $popMid = $iframe.find(".popwin");if ($popMid.last().attr("id").indexOf("winmsg") > -1) {
              $popLastAlert = $popMid.last();popAlert.text = $popLastAlert.find(".popwin_alert,.popwin_content").text();popAlert.title = $popLastAlert.find("#popwin_top").text();
            }var popId = $iframe.find(".popwin").eq(0).attr("id");popWin.title = $iframe.find(".popwin").eq(0).find("#popwin_top").text();if (popId.indexOf("winmsg") > -1) {
              popWin.popType = "winmsg";
            } else if (popId.indexOf("win") > -1) {
              popWin.popType = "win";
            }var $popMid = $iframe.find(".popwin").eq(0);if ($iframe.find(".popwin").size() > 1) {
              popAlert.text = $iframe.find(".popwin").eq(1).find(".popwin_alert").text();
            }if (popWin.title == "提示") {
              popWin.text = $popMid.find(".popwin_alert,.popwin_content").text();
            }if (popWin.title == "常用免填单备注") {
              popWin.arr = [], popWin.btn = [];$popMid.find(".wb_opt").prev("div").find("label").map(function () {
                popWin.arr.push({ "cls": $(this).attr("class"), "txt": $(this).find("span").text() });
              });$popMid.find(".wb_opt").children("span").map(function () {
                popWin.btn.push({ id: $(this).attr("id"), txt: $(this).text().trim() });
              });
            }
          }
        }
      });return { popWin: popWin.title == '提示' ? {} : popWin, popAlert: popAlert };
    },
    doAction_uiControl87_crdEky: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();if (data.eventType == "clickRadio") {
            $($iframe).find(".popwin").eq(0).find(".wb_opt").prev("div").find("label").eq(data.dataCustom).find("ins").click();
          } else if (data.eventType === 'clickBtn') {
            // $($iframe).find(".popwin").eq(0).find(".wb_opt").prev("div").find("label.checked").click();
            $iframe.find("#" + data.dataCustom).click();
          } else if (data.eventType === 'closeAlert') {
            $iframe.find(".popwin .popwin_btn_group .uee-msgbox-ok").click();
          }
        }
      });
    },
    getTemplate_uiControl87_crdEky: function () {
      var selfTemplate = "const Modal = require('ysp-custom-components').Modal;\nconst NavBar = AMUI2.NavBar;\nconst Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.data.customData,\n        _this = this;\n    \tconst special={\n        display:\"inline-block\",\n        fontSize:\"14px\",\n        margin:\"0 .5rem\",\n        border:\"none\",\n        padding:\"0\"\n      }\n      const span ={\n        verticalAlign: 'middle',\n        height: '40px',\n        lineHeight: '45px',\n        display: 'inline-block',\n      }\n    \tvar alert,window;\n    \tif(data.popWin.title == \"\u5E38\u7528\u514D\u586B\u5355\u5907\u6CE8\"){\n        window = <div className=\"w-tip\">\n        <ul className=\"w-content\">\n          {data.popWin.arr.map(function(item,i){\n            return(\n              <li className=\"am2-item\" onClick={function(){_this.clickRadio(i)}} style={special}>\n                <span className=\"am2-item-after\" style={span} onClick={function(){_this.clickRadio(i)}}>\n                  <label className=\"am2-switch\">\n                    <input type=\"checkbox\" checked={item.cls.indexOf(\"checked\") > -1 ? true : false} />\n                    <span className=\"am2-switch-checkbox\"></span>\n                  </label>\n                </span>\n                <span className=\"am2-item-title\" style={span}>{item.txt}</span>\n              </li>\n            )\n          })}\n        </ul>\n        <div>\n        \t{data.popWin.btn.map(function(item,i){\n            if(i == 0){\n              return(\n                <Button amStyle=\"primary\" rounded id= {item.id} style={{width:\"45%\",marginRight:\"5%\"}} onClick={function(){_this.clickBtn(item.id)}}>{item.txt}</Button>\n              )\n            }else{\n              return(\n                <Button amStyle=\"warning\" rounded id= {item.id} style={{width:\"45%\",marginRight:\"5%\"}} onClick={function(){_this.clickBtn(item.id)}}>{item.txt}</Button>\n              )\n            }\n          })}\n        </div>\n      </div>\n      }\n    if(data.popWin.popType == \"winmsg\" || !!data.popAlert.text){\n        alert = <div>\n              <div className=\"am2-modal am2-modal-alert\">\n                <div className=\"am2-modal-inner\">\n                  <div className=\"am2-modal-dialog\">\n                    <div className=\"am2-modal-header\"><h4 className=\"am2-modal-title\">{data.popWin.title}</h4></div>\n                    <div className=\"am2-modal-body\">{data.popWin.text}{data.popAlert.text}</div>\n                    <div className=\"am2-modal-footer\">\n                      <span className=\"am2-modal-btn\" onClick={_this.closeAlert}>\u786E\u5B9A</span>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            <div className={!!data.popWin.text || !!data.popAlert.text?\"am2-modal-backdrop\":\"\"}></div>\n          </div>\n      }\n      return (\n        <div>\n          {alert}\n          <Modal\n          ref=\"modal\"\n          role=\"modal\"\n          isOpen={data.popWin.popType == \"win\"?true:false}\n          title={data.popWin.title}\n          >\n            {window}\n        \t</Modal>\n      </div>\n    )\n  },\n  clickBtn:function(id){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\"clickBtn\",\n        data:id\n      })\n    }\n  },\n  clickRadio:function(i){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:\"clickRadio\",\n        data:i\n      })\n    }\n  },\n    closeAlert:function(){                                \n    var callBack = this.props.customHandler;\n    if(callBack) {                                    \n      callBack({\n        eventType:'closeAlert'  \n      })\n    }\n  }\n});";
      return "\"use strict\";\n\nvar Modal = require('ysp-custom-components').Modal;\nvar NavBar = AMUI2.NavBar;\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.data.customData,\n        _this = this;\n    var special = {\n      display: \"inline-block\",\n      fontSize: \"14px\",\n      margin: \"0 .5rem\",\n      border: \"none\",\n      padding: \"0\"\n    };\n    var span = {\n      verticalAlign: 'middle',\n      height: '40px',\n      lineHeight: '45px',\n      display: 'inline-block'\n    };\n    var alert, window;\n    if (data.popWin.title == \"\u5E38\u7528\u514D\u586B\u5355\u5907\u6CE8\") {\n      window = React.createElement(\n        \"div\",\n        { className: \"w-tip\" },\n        React.createElement(\n          \"ul\",\n          { className: \"w-content\" },\n          data.popWin.arr.map(function (item, i) {\n            return React.createElement(\n              \"li\",\n              { className: \"am2-item\", onClick: function onClick() {\n                  _this.clickRadio(i);\n                }, style: special },\n              React.createElement(\n                \"span\",\n                { className: \"am2-item-after\", style: span, onClick: function onClick() {\n                    _this.clickRadio(i);\n                  } },\n                React.createElement(\n                  \"label\",\n                  { className: \"am2-switch\" },\n                  React.createElement(\"input\", { type: \"checkbox\", checked: item.cls.indexOf(\"checked\") > -1 ? true : false }),\n                  React.createElement(\"span\", { className: \"am2-switch-checkbox\" })\n                )\n              ),\n              React.createElement(\n                \"span\",\n                { className: \"am2-item-title\", style: span },\n                item.txt\n              )\n            );\n          })\n        ),\n        React.createElement(\n          \"div\",\n          null,\n          data.popWin.btn.map(function (item, i) {\n            if (i == 0) {\n              return React.createElement(\n                Button,\n                { amStyle: \"primary\", rounded: true, id: item.id, style: { width: \"45%\", marginRight: \"5%\" }, onClick: function onClick() {\n                    _this.clickBtn(item.id);\n                  } },\n                item.txt\n              );\n            } else {\n              return React.createElement(\n                Button,\n                { amStyle: \"warning\", rounded: true, id: item.id, style: { width: \"45%\", marginRight: \"5%\" }, onClick: function onClick() {\n                    _this.clickBtn(item.id);\n                  } },\n                item.txt\n              );\n            }\n          })\n        )\n      );\n    }\n    if (data.popWin.popType == \"winmsg\" || !!data.popAlert.text) {\n      alert = React.createElement(\n        \"div\",\n        null,\n        React.createElement(\n          \"div\",\n          { className: \"am2-modal am2-modal-alert\" },\n          React.createElement(\n            \"div\",\n            { className: \"am2-modal-inner\" },\n            React.createElement(\n              \"div\",\n              { className: \"am2-modal-dialog\" },\n              React.createElement(\n                \"div\",\n                { className: \"am2-modal-header\" },\n                React.createElement(\n                  \"h4\",\n                  { className: \"am2-modal-title\" },\n                  data.popWin.title\n                )\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"am2-modal-body\" },\n                data.popWin.text,\n                data.popAlert.text\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"am2-modal-footer\" },\n                React.createElement(\n                  \"span\",\n                  { className: \"am2-modal-btn\", onClick: _this.closeAlert },\n                  \"\\u786E\\u5B9A\"\n                )\n              )\n            )\n          )\n        ),\n        React.createElement(\"div\", { className: !!data.popWin.text || !!data.popAlert.text ? \"am2-modal-backdrop\" : \"\" })\n      );\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      alert,\n      React.createElement(\n        Modal,\n        {\n          ref: \"modal\",\n          role: \"modal\",\n          isOpen: data.popWin.popType == \"win\" ? true : false,\n          title: data.popWin.title\n        },\n        window\n      )\n    );\n  },\n  clickBtn: function clickBtn(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"clickBtn\",\n        data: id\n      });\n    }\n  },\n  clickRadio: function clickRadio(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"clickRadio\",\n        data: i\n      });\n    }\n  },\n  closeAlert: function closeAlert() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'closeAlert'\n      });\n    }\n  }\n});";
    },
    getData_control97_eByhAf: function (elem) {
      if (!elem) {
        return;
      }var data = {},
          select = {};$(elem).children("div").map(function () {
        if ($(this).css("display") == "block") {
          var $iframe = $(this).find("iframe").contents();var _select = null,
              a = 0;select.arr = [];select.index = null;$iframe.find(".DroplistOption").each(function (i, el) {
            if ($(this)[0].style.display == "block") {
              _select = el;select.index = i;a++;
            }
          });if (!!_select) {
            if (a < 2) {
              $(_select).find(".dropItem").each(function (i, el) {
                var text = $(this).text(),
                    id = $(this)[0].id;select.arr.push({ text: text, id: id });
              });
            }
          }
        }data = { select: select };
      });return data;
    },
    doAction_uiControl88_S9V1Q0: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();var d = data.dataCustom,
              document = elem.ownerDocument;if (data.eventType === 'liClick') {
            $iframe.find("#" + d).mousedown().click();
          }if (data.eventType === 'closeSelect') {
            $iframe.find(".DroplistOption").css("display", "none");
          }
        }
      });
    },
    getTemplate_uiControl88_S9V1Q0: function () {
      var selfTemplate = "const Modal = AMUI2.Modal;\nconst NavBar = AMUI2.NavBar;\nmodule.exports = React.createClass({\n  liClick:function(id){                                \n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:id,\n        eventType:'liClick'                         \n      })\n    }\n  },\n  closeSelect:function(index){\n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:index,\n        eventType:'closeSelect'                         \n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this;\n    \n    \tvar data = this.props.data.customData,\n        me=this;   \n    \tvar alert,window;   \n    \n      return (\n        <div>\n          <div className=\"am2-modal\">\n            <ul className=\"am2-list\" style={{margin:\"0\",maxHeight:\"300px\",overflow:\"auto\"}}>\n              {data.select.arr.map(function(el,i){\n                return(\n                  <li className=\"am2-item\" style={{textAlign:\"left\"}} onClick={function(){me.liClick(el.id)}}><h3 className=\"am2-item-title\">{el.text}</h3></li>\n                )\n              })}\n            </ul>\n          </div>\n          <div className={!!data.select.arr.length>0?\"am2-modal-backdrop backdrop-zIndex\":\"\"} onClick={function(){me.closeSelect(data.select.index)}}></div>\n          {alert}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar Modal = AMUI2.Modal;\nvar NavBar = AMUI2.NavBar;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  liClick: function liClick(id) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: id,\n        eventType: 'liClick'\n      });\n    }\n  },\n  closeSelect: function closeSelect(index) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: index,\n        eventType: 'closeSelect'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this;\n\n    var data = this.props.data.customData,\n        me = this;\n    var alert, window;\n\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        'div',\n        { className: 'am2-modal' },\n        React.createElement(\n          'ul',\n          { className: 'am2-list', style: { margin: \"0\", maxHeight: \"300px\", overflow: \"auto\" } },\n          data.select.arr.map(function (el, i) {\n            return React.createElement(\n              'li',\n              { className: 'am2-item', style: { textAlign: \"left\" }, onClick: function onClick() {\n                  me.liClick(el.id);\n                } },\n              React.createElement(\n                'h3',\n                { className: 'am2-item-title' },\n                el.text\n              )\n            );\n          })\n        )\n      ),\n      React.createElement('div', { className: !!data.select.arr.length > 0 ? \"am2-modal-backdrop backdrop-zIndex\" : \"\", onClick: function onClick() {\n          me.closeSelect(data.select.index);\n        } }),\n      alert\n    );\n  }\n});";
    },
    getData_control208_5PbP1m: function (elem) {
      if (!elem) {
        return;
      }var $elem = $(elem),
          reserveOrderId = $elem.find("#reserveOrderId").text(),
          cellphoneNumber = $elem.find("#cellphoneNumber").text(),
          SESBtn = $elem.find("#signElectronicACKSlip_btn").text().trim();return { reserveOrderId, cellphoneNumber, SESBtn };
    },
    doAction_uiControl208_PWLkwC: function (data, elem) {},
    getTemplate_uiControl208_PWLkwC: function () {
      var selfTemplate = "module.exports = React.createClass({\n  getInitialState(){\n    return {show:false};\n  },\n  toggleState(){\n    this.setState({show:!this.state.show});\n  },\n  handle(data,eventType){                                \n    var callBack = this.props.customHandler,\n        me = this;          \n    if(callBack) {                                    \n      callBack({data,eventType})\n    }\n    me.toggleState();\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        state = me.state,\n        window;\n    if(!data){\n      return(<span></span>)\n    }\n    const itemLeft = {\n      title: \"\u5173\u95ED\",\n      onClick: () => me.toggleState(),\n    };\n    const dataAll = {\n      title: !!data.obj?data.obj.template[0].templateName:\"\",\n      leftNav: [{...itemLeft, icon: 'left-nav'}]\n    };\n    return (\n      <div>\n      \t<ul style={{textAlign:\"center\",paddingBottom:\"1rem\"}}>\n          <li>\u8BA2\u5355\u53F7\uFF1A{data.reserveOrderId}</li>\n          <li>\u624B\u673A\u53F7\uFF1A{data.cellphoneNumber}</li>\n          {/*<li><button className=\"am2-btn am2-btn-xs am2-btn-success\" onClick={()=>{me.handle({id:data.reserveOrderId,num:data.cellphoneNumber},\"click\")}}>{data.SESBtn}</button></li>*/}\n        </ul>\n      </div>\n      \n    )\n  }\n});";
      return "\"use strict\";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  getInitialState: function getInitialState() {\n    return { show: false };\n  },\n  toggleState: function toggleState() {\n    this.setState({ show: !this.state.show });\n  },\n  handle: function handle(data, eventType) {\n    var callBack = this.props.customHandler,\n        me = this;\n    if (callBack) {\n      callBack({ data: data, eventType: eventType });\n    }\n    me.toggleState();\n  },\n\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        state = me.state,\n        window;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    var itemLeft = {\n      title: \"\u5173\u95ED\",\n      onClick: function onClick() {\n        return me.toggleState();\n      }\n    };\n    var dataAll = {\n      title: !!data.obj ? data.obj.template[0].templateName : \"\",\n      leftNav: [_extends({}, itemLeft, { icon: 'left-nav' })]\n    };\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"ul\",\n        { style: { textAlign: \"center\", paddingBottom: \"1rem\" } },\n        React.createElement(\n          \"li\",\n          null,\n          \"\\u8BA2\\u5355\\u53F7\\uFF1A\",\n          data.reserveOrderId\n        ),\n        React.createElement(\n          \"li\",\n          null,\n          \"\\u624B\\u673A\\u53F7\\uFF1A\",\n          data.cellphoneNumber\n        )\n      )\n    );\n  }\n});";
    },
    getData_control209_wDGT0U: function (elem) {
      if ($(elem).parents("body").find('.main-right .tabcontainer[style*="block"]').find('iframe').contents().find("#a_paymentFinishClose").length && $(elem).parents("body").find('.main-right .tabcontainer[style*="block"]').find('iframe').contents().find("#modifyPwdresult").css("display") != "none") {
        return "关闭当前页";
      }
    },
    doAction_uiControl209_Lfwqhu: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.appMain.showLoading();$(elem).find("li.selected").find(".tab-close").click();ysp.appMain.backToIndex();
      }
    },
    getTemplate_uiControl209_Lfwqhu: function () {
      var selfTemplate = "const Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  back:function(e){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"back\"\n      });   \n    } \n  },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){return(<p style={{display:\"none\"}}></p>)}\n    return (\n      <div>\n        <Button amStyle=\"success\" style={{width:\"100%\"}} onClick={_this.back}>\u5173\u95ED\u5F53\u524D\u9875</Button>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  back: function back(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"back\"\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        Button,\n        { amStyle: \"success\", style: { width: \"100%\" }, onClick: _this.back },\n        \"\\u5173\\u95ED\\u5F53\\u524D\\u9875\"\n      )\n    );\n  }\n});";
    }
  });
})(window, ysp);