(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control28_g91MTb: function (elem) {},
    doAction_uiControl20_TMRtNc: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.appMain.showLoading();ysp.appMain.backToIndex();$(elem).find(".tab-close").click();
      }
    },
    getTemplate_uiControl20_TMRtNc: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.handle('','back');\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title=\"\u4E2A\u4EBA\u7528\u6237\u8D26\u5355\u67E5\u8BE2\">\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={()=>{me.handle('','back')}}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  },\n  handle:function(data,eventType){\n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({data,eventType})\n    }\n  },\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.handle('', 'back');\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: '\\u4E2A\\u4EBA\\u7528\\u6237\\u8D26\\u5355\\u67E5\\u8BE2' },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: function onClick() {\n                me.handle('', 'back');\n              } },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  },\n  handle: function handle(data, eventType) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({ data: data, eventType: eventType });\n    }\n  }\n});";
    },
    getData_control31_TWOGa0: function (elem) {
      if (!elem) {
        return;
      }var data = { "title": [], "right": [] };$elem = $(elem.ownerDocument).find('.main-right .tabcontainer[style*="block"]').find('iframe').contents();var $tbody = $elem.find("#qryPanel_content").find("tbody"),
          $el = $tbody.eq(0);if ($elem.find("#qryPanel_content").find("tbody").length > 1) {
        $el = $tbody.eq(1);
      }$el.find("tr").eq(1).find("td").map(function () {
        if ($(this).children("div").css("display") != "none" && $(this).find(".bc_field_body").length) {
          data.title.push($(this).find(".bc_field_label").eq(0).text().replace(/\*|\：/g, ""));if ($(this).find(".bc_field_body").find("input").length) {
            data.right.push({ "id": $(this).find(".bc_field_body").find("input").attr("id"), "val": $(this).find(".bc_field_body").find("input").val() });
          } else {
            var option = [];$(this).find(".bc_field_body").find("select").find("option").map(function () {
              option.push($(this).text());
            });data.right.push({ "id": $(this).find(".bc_field_body").find("select").attr("id"), "value": $(this).find(".bc_field_body").find("select")[0].selectedIndex, "option": option });
          }
        }
      });return data;
    },
    doAction_uiControl22_3ypnGg: function (data, elem) {
      $elem = $(elem.ownerDocument).find('.main-right .tabcontainer[style*="block"]').find('iframe').contents();var $tbody = $elem.find("#qryPanel_content").find("tbody"),
          $el = $tbody.eq(0);if ($elem.find("#qryPanel_content").find("tbody").length > 1) {
        $el = $tbody.eq(1);
      }if (data.eventType == "blur") {
        $el.find("#" + data.dataCustom.index).val(data.dataCustom.value);
      } else if (data.eventType == "change") {
        var $select = $el.find("#" + data.dataCustom.index);$select[0].selectedIndex = Number(data.dataCustom.value);$select.change();
      }
    },
    getTemplate_uiControl22_3ypnGg: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(data){\n      return (\n        <div className=\"search\">\n          <ul>\n\t\t\t\t\t\t{data.title.map(function(item,i){\n              if(data.right[i].option){\n                return(\n                  <li>\n                    <label>\n                      <span>{item}\uFF1A</span>\n                    </label>\n                    <select id={data.right[i].id} onChange = {function(e){\n                        _this.onChange(e,data.right[i].id,e.target.value)}\n                      } value={data.right[i].value}>\n                      {data.right[i].option.map(function(item,i){\n                        return(\n                          <option value={i}>{item}</option>\n                        )\n                      })}\n                    </select>\n                  </li>\n                )\n              }else{\n                return(\n                  <li>\n                    <label>\n                      <span>{item}\uFF1A</span>\n                    </label>\n                    <AInput id={data.right[i].id} value={data.right[i].val}  onBlur = {function(e){_this.onBlur(e,data.right[i].id)}} required=\"required\"></AInput>\n                  </li>\n                )\n              }\n            })}\n          </ul>\n        </div>\n      )\n    }else{\n      return (\n        <div style={{\"dispaly\":\"none\"}}></div>\n      )\n    }\n  },\n  onBlur:function(e,id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"blur\",\n        data: {\n          index:id,\n          value:e.target.value\n        }\n      });   \n    }\n  },\n  onChange:function(e,id,val){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"change\",\n        data: {\n          index:id,\n          value:val\n        }\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (data) {\n      return React.createElement(\n        \"div\",\n        { className: \"search\" },\n        React.createElement(\n          \"ul\",\n          null,\n          data.title.map(function (item, i) {\n            if (data.right[i].option) {\n              return React.createElement(\n                \"li\",\n                null,\n                React.createElement(\n                  \"label\",\n                  null,\n                  React.createElement(\n                    \"span\",\n                    null,\n                    item,\n                    \"\\uFF1A\"\n                  )\n                ),\n                React.createElement(\n                  \"select\",\n                  { id: data.right[i].id, onChange: function onChange(e) {\n                      _this.onChange(e, data.right[i].id, e.target.value);\n                    }, value: data.right[i].value },\n                  data.right[i].option.map(function (item, i) {\n                    return React.createElement(\n                      \"option\",\n                      { value: i },\n                      item\n                    );\n                  })\n                )\n              );\n            } else {\n              return React.createElement(\n                \"li\",\n                null,\n                React.createElement(\n                  \"label\",\n                  null,\n                  React.createElement(\n                    \"span\",\n                    null,\n                    item,\n                    \"\\uFF1A\"\n                  )\n                ),\n                React.createElement(AInput, { id: data.right[i].id, value: data.right[i].val, onBlur: function onBlur(e) {\n                    _this.onBlur(e, data.right[i].id);\n                  }, required: \"required\" })\n              );\n            }\n          })\n        )\n      );\n    } else {\n      return React.createElement(\"div\", { style: { \"dispaly\": \"none\" } });\n    }\n  },\n  onBlur: function onBlur(e, id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"blur\",\n        data: {\n          index: id,\n          value: e.target.value\n        }\n      });\n    }\n  },\n  onChange: function onChange(e, id, val) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"change\",\n        data: {\n          index: id,\n          value: val\n        }\n      });\n    }\n  }\n});";
    },
    getData_control32_PipXe6: function (elem) {
      if (!elem) {
        return;
      }var rp = ysp.customHelper.replaceSpace;var data = {};var doc = $(elem).children("#qryPanel").next("div").next("div").children('div'),
          index;var tab = [],


      //顶部年份tab切换
      name = [],


      //客户名称、手机号码、当前额度等信息
      ExpenseItem = {},


      //费用信息---》费用项目的表格
      special = {},


      //时有时无的账户信息表格
      special1 = {},


      //时有时无的积分信息表格
      beizhu = "",


      //感谢您使用中国移动客户账单....等描述信息
      feiyong = [],


      //中国移动业务费用下的表格
      txlMingxi = {},


      //通信量使用信息明细
      llMingxi = [],


      //流量使用明细
      lilaingfei = [],


      //套餐外流量费
      xianjin = [],


      //    现金账户
      xieyi = [],
          tuijian = []; //套餐推荐
      function table(_all, thead, tbody, txt, state) {
        if (!state) {
          //     费用信息
          var data = { thead: [], tbody: [] };thead.find("th").map(function (i) {
            if (i < 2) {
              data.thead.push($(this).find("label").text());
            }
          });tbody.find("tr").map(function () {
            var trl = [],
                trr = [];$(this).find("td").map(function (i) {
              if ($(this).attr("colspan")) {
                trl.push({ "txt": $(this).text().trim(), "colspan": $(this).attr("colspan") });
              } else {
                if (i < 2) {
                  trl.push($(this).text().split('\t')[0].trim());
                } else {
                  trr.push($(this).text().split('\t')[0].trim());
                }
              }
            });data.tbody.push(trl);data.tbody.push(trr);
          });return { title: txt.text(), data: data };
        } else {
          // 含有title的表格
          var data = { thead: [], tbody: [], title: [] };thead.find("th").map(function (i) {
            if (i != 0) {
              data.thead.push($(this).find("label").text());
            }
          });tbody.find("tr").map(function () {
            var tr = [];$(this).find("td").map(function (i) {
              if ($(this).attr("colspan")) {
                tr.push({ "txt": $(this).text().trim(), "colspan": $(this).attr("colspan") });
              } else {
                if (i != 0) {
                  tr.push($(this).text().trim());
                } else {
                  data.title.push($(this).text().trim());
                }
              }
            });data.tbody.push(tr);
          });return { title: txt.text(), data: data };
        }
      }doc.each(function (i, _all) {
        // 顶部年份tab切换
        if ($(_all).find("#bundletab_head").length) {
          $(_all).find("#bundletab_head").find("#bundletab_items").find("li").map(function () {
            tab.push({ id: $(this).attr("id"), class: $(this).attr("class") && $(this).attr("class").trim(), txt: $(this).text() && $(this).text().trim() });
          });
        } //  客户名称、手机号码、当前额度等信息
        if (i == 2) {
          $(_all).find(".bc_grid_databody").map(function () {
            $(this).find("tr").map(function () {
              if ($(this).text().trim() != "") {
                name.push({ thead: $(this).find("td").eq(0).prop('firstChild').nodeValue.trim(), tbody: $(this).find("td").eq(1).prop('firstChild').nodeValue.trim() || $(this).find("td").eq(1).text().trim() });
              }
            });
          });
        } else if (i == 3) {
          //   费用信息---》费用项目的表格
          var data3 = { thead: [], tbody: [] };$(_all).find("thead").eq(0).find("th").map(function () {
            data3.thead.push($(this).text());
          });$(_all).find(".bc_panel_content").find("tbody").eq(3).map(function () {
            $(this).find("tr").map(function () {
              if ($(this).text().trim() != "") {
                var tr = [];$(this).find("td").map(function () {
                  if ($(this).attr("colspan")) {
                    tr.push({ "txt": $(this).text().trim(), "colspan": $(this).attr("colspan") });
                  } else {
                    tr.push($(this).text().trim());
                  }
                });data3.tbody.push(tr);
              }
            });
          });$(_all).find(".bc_panel_content").find("tbody").eq(4).map(function () {
            $(this).find("tr").map(function () {
              if ($(this).text().trim() != "") {
                var tr = [];$(this).find("td").map(function () {
                  tr.push($(this).text().trim());
                });data3.tbody.push(tr);
              }
            });
          });ExpenseItem = { title: $(_all).find(".bc_panel_title").text(), data: data3 };
        } //   感谢您使用中国移动客户账单....等描述信息
        if ($(_all).find("label.font_style_1").length && $(_all).find("label.font_style_1").text().indexOf("感谢") > -1) {
          beizhu = $(_all).find("label.font_style_1").text();
        } //重点区域
        var txt = $(_all).find(".bc_panel_title").eq(0).text();if (txt && txt.indexOf("中国移动业务费用") > -1) {
          var tds = $(_all).find("tbody").eq(1).find("td");var len = tds.length;var first = [];var second = [];for (var i = 0; i < len; i++) {
            tds[i] = tds.eq(i).prop('firstChild').nodeValue.trim();if (tds[i] != "") {
              if (i % 4 == 0) first.push(tds[i]);if (i % 4 == 1) first.push(tds[i]);if (i % 4 == 2) second.push(tds[i]);if (i % 4 == 3) second.push(tds[i]);
            }
          }tds = [];tds = first.concat(second);feiyong = tds;
        }if (txt && txt.indexOf("账户信息") > -1) {
          var datas = { thead: [], tbody: [] };$(_all).find("thead").eq(0).find("th").map(function () {
            datas.thead.push($(this).text() && $(this).text().trim());
          });$(_all).find("tbody").last().find("tr").map(function (index, tr) {
            var tds = [];$(tr).find("td").map(function () {
              tds.push(rp($(this).text()));
            });datas.tbody.push(tds);
          });special1 = { title: txt, data: datas };
        }if (txt && txt.indexOf("积分信息") > -1) {
          var datas = { thead: [], tbody: [] };$(_all).find(".bc_grid_table").map(function (index, trs) {
            if (index != 0) {
              $(trs).find("td").map(function () {
                datas.tbody.push($(this).text() && $(this).text().trim());
              });
            } else {
              $(trs).find("th").map(function () {
                datas.thead.push($(this).text() && $(this).text().trim());
              });
            }
          });special = { title: txt, data: datas };
        }txt = $(_all).children(".bc_label.bc").eq(0).text();if (txt && txt.indexOf("通信量使用信息明细") > -1) {
          //   通信量使用信息明细
          txlMingxi = table($(_all), $(_all).find("thead").eq(0), $(_all).find("tbody").eq(0), $(_all).children(".bc_label.bc").eq(0), true);
        }if (txt && txt.indexOf("流量使用明细") > -1) {
          llMingxi = table($(_all), $(_all).find("thead").eq(0), $(_all).find("tbody").eq(0), $(_all).children(".bc_label.bc").eq(0), true);
        }txt = $(_all).find("label.bc_label.bc").eq(1).text();if (txt && txt.indexOf("套餐外流量费") > -1) {
          lilaingfei = table($(_all), $(_all).find("#flowOutPackageListDatagrid_head").find("thead").eq(0), $(_all).find(".bc_grid_client").find("tbody").eq(1), $(_all).children("label.bc_label.bc").eq(1), true);
        }txt = $(_all).find("label.bc_label.bc").eq(0).text();if (txt && txt.indexOf("现金账本入账明细") > -1) {
          var data = { thead: [], tbody: [] };$(_all).find("#inUseFlowLogDatagrid_head").find("thead").eq(0).find("th").map(function (i) {
            data.thead.push($(this).find("label").text());
          });$(_all).find(".bc_grid_client").find("tbody").eq(0).find("tr").map(function () {
            var trl = [];$(this).find("td").map(function (i) {
              if ($(this).attr("colspan")) {
                trl.push({ "txt": $(this).text().trim(), "colspan": $(this).attr("colspan") });
              } else {
                trl.push($(this).text().split('\t')[0].trim());
              }
            });data.tbody.push(trl);
          });xianjin = { title: $(_all).find("label.bc_label.bc").eq(0).text(), data: data };
        }txt = $(_all).find("label.bc_label.bc").eq(1).text();if (txt && txt.indexOf("协议款账本入账明细") > -1) {
          var data = { thead: [], tbody: [] };$(_all).find("#contractFlowLogDatagrid_head").find("thead").eq(0).find("th").map(function (i) {
            data.thead.push($(this).find("label").text());
          });$(_all).find(".bc_grid_client").find("tbody").eq(1).find("tr").map(function () {
            var trl = [];$(this).find("td").map(function (i) {
              if ($(this).attr("colspan")) {
                trl.push({ "txt": $(this).text().trim(), "colspan": $(this).attr("colspan") });
              } else {
                trl.push($(this).text().split('\t')[0].trim());
              }
            });data.tbody.push(trl);
          });xieyi = { title: $(_all).find("label.bc_label.bc").eq(1).text(), data: data };
        }
      });if ($(elem).children("#qryPanel").next("div").next("div").children('div').length && $(elem).children("#qryPanel").next("div").next("div").css("display") != "none") {
        data = { tab: tab, name: name, ExpenseItem: ExpenseItem, special1: '', special: special, beizhu: '', feiyong: feiyong, txlMingxi: '', llMingxi: '', lilaingfei: '', xianjin: xianjin, xieyi: xieyi, tuijian: tuijian };
      } else {
        data = { tab: tab }; //<p className="t-cen">暂无账单</p>
      }return data;
    },
    doAction_uiControl23_bR2TpO: function (data, elem) {
      var doc = $(elem).children("#qryPanel").next("div").next("div").children("div");doc.find("#bundletab_head").find("#bundletab_items").find("#" + data.dataCustom).click();
    },
    getTemplate_uiControl23_bR2TpO: function () {
      var selfTemplate = "var Modal = require('ysp-custom-components').Modal;\nvar NavBar = require('ysp-custom-components').NavBar;\nconst Pair = AMUI2.Pair;\nmodule.exports = React.createClass({\n  componentDidMount:function(){\n    const me = this;\n    window.__ysp_Wstate = function(){\n      me.setState({\n        isOpen: !me.state.isOpen\n      })\n    }\n  },\n  componentDidUpdate: function(){\n    const me = this, _d = this.props.data.customData;\n    if(!me.state.isOpen && window.__ysp_page_back_bak){\n      window.__ysp_page_back = window.__ysp_page_back_bak;\n      window.__ysp_page_back_bak = undefined;\n    }else if(me.state.isOpen && !window.__ysp_page_back_bak){\n      window.__ysp_page_back_bak = window.__ysp_page_back;\n      window.__ysp_page_back = function(){\n        me.setState({\n          isOpen: !me.state.isOpen\n        })\n      }\n    }\n  },\n  getInitialState: function(){\n    return {isOpen: false}\n  },\n  renderAll: function(){\n    var data = this.props.customData;\n    var _this = this;\n\t\tfunction repeat(dataArray){\n      return(\n      \t<div>\n        \t<p className=\"w-tit\">{dataArray.title}</p>\n            {dataArray.data.tbody.map(function(item,j){\n              return(\n                <div className=\"table-list\">\n                  <p className=\"table-tit\">{dataArray.data.title[j]}</p>\n                  <table>\n                    <thead>\n                      <tr>\n                        {dataArray.data.thead.map(function(item,i){\n                          return(\n                            <th>{item}</th>\n                          )\n                        })}\n                      </tr>\n                    </thead>\n                    <tbody>\n                      <tr>\n                        {item.map(function(item,i){\n                          if(item.colspan){\n                            return(\n                              <td className=\"colspan\" colSpan={item.colspan}>{item.txt}</td>\n                            )\n                          }else{\n                            return(\n                              <td>{item}</td>\n                            )\n                          }\n                        })}\n                      </tr>\n                    </tbody>\n                  </table>\n                </div>\n              )\n            })}\n        </div>\n      )\n    }\n    function repeat1(dataArray){\n      return(<div>\n          <p className=\"w-tit\">{dataArray.title}</p>\n\t\t\t\t\t<div className=\"over\">\n          \t<table>\n              <thead>\n                <tr>\n                  {dataArray.data.thead.map(function(item,i){\n                    return(\n                      <th>{item}</th>\n                    )\n                  })}\n                </tr>\n              </thead>\n              <tbody>\n                {dataArray.data.tbody.map(function(item,i){\n                  if(item[0] != \"\"){\n                    return(\n                      <tr>\n                        {item.map(function(item,i){\n                          if(item.colspan){\n                            return(\n                              <td className=\"colspan\" colSpan={item.colspan}>{item.txt}</td>\n                            )\n                          }else{\n                            return(\n                              <td>{item}</td>\n                            )\n                          }\n                        })}\n                      </tr>\n                    )\n                  }\n                })}\n              </tbody>\n            </table>\n          </div>\n        </div>\n      )\n    }\n    if(data.tab && data.tab.length){\n      if(!data.name){\n        return(\n        \t<div>\n          \t{data.tab?<div className=\"w-x-tab\">\n            <ul className=\"am2-tabs-nav\" style={{padding:\"0\"}}>\n              {data.tab.map(function(item,i){\n                return(\n                  <li className={item.class.indexOf(\"selected\") > -1 ? \"am2-tabs-nav-item active\" : \"am2-tabs-nav-item\"} onClick={function(){_this.click(item.id)}}>{item.txt}</li>\n                )\n              })}\n            </ul>\n          </div>:''}\n        \t<p className=\"t-cen\">\u6682\u65E0\u8D26\u5355</p>\n          </div>\n        )\n      }\n      return(\n        <div className=\"Wmodal\">\n          {/*\u9009\u9879\u5361*/}\n        \t{data.tab?<div className=\"w-x-tab\">\n            <ul className=\"am2-tabs-nav\" style={{padding:\"0\"}}>\n              {data.tab.map(function(item,i){\n                return(\n                  <li className={item.class.indexOf(\"selected\") > -1 ? \"am2-tabs-nav-item active\" : \"am2-tabs-nav-item\"} onClick={function(){_this.click(item.id)}}>{item.txt}</li>\n                )\n              })}\n            </ul>\n          </div>:''}\n          {/*\u5BA2\u6237\u540D\u79F0*/}\n          {data.name ? <div className=\"w-x-list1\" style={{borderBottom:\".5rem solid #f5f5f5\"}}>\n            <ul>\n              {data.name.map(function(item,i){\n                return(\n                  <Pair key={i} name={item.thead} value={item.tbody} />\n                )\n              })}\n            </ul>\n          </div>:\"\"}\n          \n          {/*\u8D39\u7528\u4FE1\u606F*/}\n          {data.ExpenseItem && data.ExpenseItem.data ? <div style={{borderBottom:\".5rem solid #f5f5f5\",paddingBottom:\"1rem\"}} className=\"w-table ndy\">\n            {repeat1(data.ExpenseItem)}\n          </div> : \"\"}\n          {/*\u65F6\u6709\u65F6\u65E0\u7684\u672A\u77E5\u8868\u683C*/}{/*\u5E10\u6237\u4FE1\u606F\u3002\u79EF\u5206\u4FE1\u606F*/}\n          {data.special1 && data.special1.data ? <div style={{borderBottom:\".5rem solid #f5f5f5\",paddingBottom:\"1rem\"}} className=\"w-table\">\n           {repeat1(data.special1)}\n          </div> : \"\"}\n          {data.special && data.special.data ? <div style={{borderBottom:\".5rem solid #f5f5f5\",paddingBottom:\"1rem\"}}>\n            <div className=\"w-table\">\n              <p className=\"w-tit\">{data.special.title}</p>\n              <div style={{display:\"flex\",flexWrap:\"nowrap\",overflowX:\"auto\"}}>\n              \t<table  style={{width:\"120%\",maxWidth:\"150%\"}}>\n                <thead>\n                  <tr>\n                    {data.special.data.thead.map(function(item,i){\n                      return(\n                        <th>{item}</th>\n                      )\n                    })}\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr>\n                    {data.special.data.tbody.map(function(item,i){\n                    return(\n                      <td>{item}</td>\n                    )\n                  })}\n                  </tr>\n                </tbody>\n              </table>\n              </div>\n            </div>\n          </div> : \"\"}\n          {/*\u611F\u8C22\u60A8\u4F7F\u7528\u4E2D\u56FD\u79FB\u52A8\u5BA2\u6237\u8D26\u5355....\u7B49\u63CF\u8FF0\u4FE1\u606F*/}\n          {data.beizhu ? <p className=\"beizhu\">{data.beizhu}</p>:\"\"}\n          {/*\u9644\u5F55*/}\n          <p className=\"w-tit\">\u9644\u5F55\uFF1A\u8D39\u7528\u3001\u901A\u4FE1\u91CF\u3001\u8D26\u6237\u660E\u7EC6</p>\n          {/*\u4E2D\u56FD\u79FB\u52A8\u4E1A\u52A1\u8D39\u7528\u4E0B\u7684\u8868\u683C*/}\n          {data.feiyong && data.feiyong.data  ? <div className=\"w-table\">\n          {repeat1(data.feiyong)}\n        </div> : \"\"}\n          {/*\u901A\u4FE1\u91CF\u4F7F\u7528\u4FE1\u606F\u660E\u7EC6*/}\n          {data.txlMingxi && data.txlMingxi.data  ? <div className=\"w-table\">\n            {repeat(data.txlMingxi)}\n          </div> : \"\"}\n          {/*\u6D41\u91CF\u4F7F\u7528\u660E\u7EC6*/}\n          {data.llMingxi && data.llMingxi.data ? <div className=\"w-table\">\n            {repeat(data.llMingxi)}\n          </div> : \"\"}\n          {/*\u5957\u9910\u5916\u6D41\u91CF\u8D39*/}\n          {/*{data.lilaingfei && data.lilaingfei.data ? <div className=\"w-table\">\n          \t{repeat(data.lilaingfei)}\n        \t</div>:\"\"}*/}\n          {data.feiyong.length >0 ?<div className=\"w-table\">\n          \t<table>\n            \t<thead>\n              \t<th>\u8D39\u7528\u9879\u76EE</th>\n                <th>\u91D1\u989D</th>\n              </thead>\n              <tbody>\n              \t{data.feiyong.map(function(item,i){\n                  if(i % 2){\n                    return(\n                    \t<tr>\n                      \t<td>{data.feiyong[i-1]}</td>\n                        <td>{item}</td>\n                      </tr>\n                    )\n                  }\n                })}\n              </tbody>\n            </table>\n          </div>:\"\"}\n          {/*\u8D26\u6237\u660E\u7EC6*/}\n          {data.xianjin && data.xianjin.data ? <p className=\"w-tit\">\u8D26\u6237\u660E\u7EC6</p>:\"\"}\n          {data.xianjin && data.xianjin.data ? <div className=\"w-table\">\n            {repeat1(data.xianjin)}\n          </div>:\"\"}\n          {data.xieyi && data.xieyi.data ? <div className=\"w-table\">\n            {repeat1(data.xieyi)}\n          </div>:\"\"}\n          {/*\u5957\u9910\u63A8\u8350*/}\n        </div>\n       )\n    }\n  },\n  render: function() {\n    var me = this, data = me.props.customData, state = me.state;\n    if(!data){\n      return(\n        <p style={{display:\"none\"}}></p>\n      )\n    }\n    return (\n      <Modal isOpen={state.isOpen && data.tab.length > 0} role=\"page\">\n        <NavBar title=\"\u4E2D\u56FD\u79FB\u52A8\u901A\u4FE1\u5BA2\u6237\u8D26\u5355\"  lFn={()=>{\n            me.setState({isOpen : false})\n          }}  />\n        {me.renderAll()}\n      </Modal>\n    )\n  },\n  click:function(id){\n  \tvar handler = this.props.customHandler;\n   \tif (handler) {\n      handler({\n        data: id\n      });   \n    }\n  }\n});";
      return "'use strict';\n\nvar Modal = require('ysp-custom-components').Modal;\nvar NavBar = require('ysp-custom-components').NavBar;\nvar Pair = AMUI2.Pair;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_Wstate = function () {\n      me.setState({\n        isOpen: !me.state.isOpen\n      });\n    };\n  },\n  componentDidUpdate: function componentDidUpdate() {\n    var me = this,\n        _d = this.props.data.customData;\n    if (!me.state.isOpen && window.__ysp_page_back_bak) {\n      window.__ysp_page_back = window.__ysp_page_back_bak;\n      window.__ysp_page_back_bak = undefined;\n    } else if (me.state.isOpen && !window.__ysp_page_back_bak) {\n      window.__ysp_page_back_bak = window.__ysp_page_back;\n      window.__ysp_page_back = function () {\n        me.setState({\n          isOpen: !me.state.isOpen\n        });\n      };\n    }\n  },\n  getInitialState: function getInitialState() {\n    return { isOpen: false };\n  },\n  renderAll: function renderAll() {\n    var data = this.props.customData;\n    var _this = this;\n    function repeat(dataArray) {\n      return React.createElement(\n        'div',\n        null,\n        React.createElement(\n          'p',\n          { className: 'w-tit' },\n          dataArray.title\n        ),\n        dataArray.data.tbody.map(function (item, j) {\n          return React.createElement(\n            'div',\n            { className: 'table-list' },\n            React.createElement(\n              'p',\n              { className: 'table-tit' },\n              dataArray.data.title[j]\n            ),\n            React.createElement(\n              'table',\n              null,\n              React.createElement(\n                'thead',\n                null,\n                React.createElement(\n                  'tr',\n                  null,\n                  dataArray.data.thead.map(function (item, i) {\n                    return React.createElement(\n                      'th',\n                      null,\n                      item\n                    );\n                  })\n                )\n              ),\n              React.createElement(\n                'tbody',\n                null,\n                React.createElement(\n                  'tr',\n                  null,\n                  item.map(function (item, i) {\n                    if (item.colspan) {\n                      return React.createElement(\n                        'td',\n                        { className: 'colspan', colSpan: item.colspan },\n                        item.txt\n                      );\n                    } else {\n                      return React.createElement(\n                        'td',\n                        null,\n                        item\n                      );\n                    }\n                  })\n                )\n              )\n            )\n          );\n        })\n      );\n    }\n    function repeat1(dataArray) {\n      return React.createElement(\n        'div',\n        null,\n        React.createElement(\n          'p',\n          { className: 'w-tit' },\n          dataArray.title\n        ),\n        React.createElement(\n          'div',\n          { className: 'over' },\n          React.createElement(\n            'table',\n            null,\n            React.createElement(\n              'thead',\n              null,\n              React.createElement(\n                'tr',\n                null,\n                dataArray.data.thead.map(function (item, i) {\n                  return React.createElement(\n                    'th',\n                    null,\n                    item\n                  );\n                })\n              )\n            ),\n            React.createElement(\n              'tbody',\n              null,\n              dataArray.data.tbody.map(function (item, i) {\n                if (item[0] != \"\") {\n                  return React.createElement(\n                    'tr',\n                    null,\n                    item.map(function (item, i) {\n                      if (item.colspan) {\n                        return React.createElement(\n                          'td',\n                          { className: 'colspan', colSpan: item.colspan },\n                          item.txt\n                        );\n                      } else {\n                        return React.createElement(\n                          'td',\n                          null,\n                          item\n                        );\n                      }\n                    })\n                  );\n                }\n              })\n            )\n          )\n        )\n      );\n    }\n    if (data.tab && data.tab.length) {\n      if (!data.name) {\n        return React.createElement(\n          'div',\n          null,\n          data.tab ? React.createElement(\n            'div',\n            { className: 'w-x-tab' },\n            React.createElement(\n              'ul',\n              { className: 'am2-tabs-nav', style: { padding: \"0\" } },\n              data.tab.map(function (item, i) {\n                return React.createElement(\n                  'li',\n                  { className: item.class.indexOf(\"selected\") > -1 ? \"am2-tabs-nav-item active\" : \"am2-tabs-nav-item\", onClick: function onClick() {\n                      _this.click(item.id);\n                    } },\n                  item.txt\n                );\n              })\n            )\n          ) : '',\n          React.createElement(\n            'p',\n            { className: 't-cen' },\n            '\\u6682\\u65E0\\u8D26\\u5355'\n          )\n        );\n      }\n      return React.createElement(\n        'div',\n        { className: 'Wmodal' },\n        data.tab ? React.createElement(\n          'div',\n          { className: 'w-x-tab' },\n          React.createElement(\n            'ul',\n            { className: 'am2-tabs-nav', style: { padding: \"0\" } },\n            data.tab.map(function (item, i) {\n              return React.createElement(\n                'li',\n                { className: item.class.indexOf(\"selected\") > -1 ? \"am2-tabs-nav-item active\" : \"am2-tabs-nav-item\", onClick: function onClick() {\n                    _this.click(item.id);\n                  } },\n                item.txt\n              );\n            })\n          )\n        ) : '',\n        data.name ? React.createElement(\n          'div',\n          { className: 'w-x-list1', style: { borderBottom: \".5rem solid #f5f5f5\" } },\n          React.createElement(\n            'ul',\n            null,\n            data.name.map(function (item, i) {\n              return React.createElement(Pair, { key: i, name: item.thead, value: item.tbody });\n            })\n          )\n        ) : \"\",\n        data.ExpenseItem && data.ExpenseItem.data ? React.createElement(\n          'div',\n          { style: { borderBottom: \".5rem solid #f5f5f5\", paddingBottom: \"1rem\" }, className: 'w-table ndy' },\n          repeat1(data.ExpenseItem)\n        ) : \"\",\n        data.special1 && data.special1.data ? React.createElement(\n          'div',\n          { style: { borderBottom: \".5rem solid #f5f5f5\", paddingBottom: \"1rem\" }, className: 'w-table' },\n          repeat1(data.special1)\n        ) : \"\",\n        data.special && data.special.data ? React.createElement(\n          'div',\n          { style: { borderBottom: \".5rem solid #f5f5f5\", paddingBottom: \"1rem\" } },\n          React.createElement(\n            'div',\n            { className: 'w-table' },\n            React.createElement(\n              'p',\n              { className: 'w-tit' },\n              data.special.title\n            ),\n            React.createElement(\n              'div',\n              { style: { display: \"flex\", flexWrap: \"nowrap\", overflowX: \"auto\" } },\n              React.createElement(\n                'table',\n                { style: { width: \"120%\", maxWidth: \"150%\" } },\n                React.createElement(\n                  'thead',\n                  null,\n                  React.createElement(\n                    'tr',\n                    null,\n                    data.special.data.thead.map(function (item, i) {\n                      return React.createElement(\n                        'th',\n                        null,\n                        item\n                      );\n                    })\n                  )\n                ),\n                React.createElement(\n                  'tbody',\n                  null,\n                  React.createElement(\n                    'tr',\n                    null,\n                    data.special.data.tbody.map(function (item, i) {\n                      return React.createElement(\n                        'td',\n                        null,\n                        item\n                      );\n                    })\n                  )\n                )\n              )\n            )\n          )\n        ) : \"\",\n        data.beizhu ? React.createElement(\n          'p',\n          { className: 'beizhu' },\n          data.beizhu\n        ) : \"\",\n        React.createElement(\n          'p',\n          { className: 'w-tit' },\n          '\\u9644\\u5F55\\uFF1A\\u8D39\\u7528\\u3001\\u901A\\u4FE1\\u91CF\\u3001\\u8D26\\u6237\\u660E\\u7EC6'\n        ),\n        data.feiyong && data.feiyong.data ? React.createElement(\n          'div',\n          { className: 'w-table' },\n          repeat1(data.feiyong)\n        ) : \"\",\n        data.txlMingxi && data.txlMingxi.data ? React.createElement(\n          'div',\n          { className: 'w-table' },\n          repeat(data.txlMingxi)\n        ) : \"\",\n        data.llMingxi && data.llMingxi.data ? React.createElement(\n          'div',\n          { className: 'w-table' },\n          repeat(data.llMingxi)\n        ) : \"\",\n        data.feiyong.length > 0 ? React.createElement(\n          'div',\n          { className: 'w-table' },\n          React.createElement(\n            'table',\n            null,\n            React.createElement(\n              'thead',\n              null,\n              React.createElement(\n                'th',\n                null,\n                '\\u8D39\\u7528\\u9879\\u76EE'\n              ),\n              React.createElement(\n                'th',\n                null,\n                '\\u91D1\\u989D'\n              )\n            ),\n            React.createElement(\n              'tbody',\n              null,\n              data.feiyong.map(function (item, i) {\n                if (i % 2) {\n                  return React.createElement(\n                    'tr',\n                    null,\n                    React.createElement(\n                      'td',\n                      null,\n                      data.feiyong[i - 1]\n                    ),\n                    React.createElement(\n                      'td',\n                      null,\n                      item\n                    )\n                  );\n                }\n              })\n            )\n          )\n        ) : \"\",\n        data.xianjin && data.xianjin.data ? React.createElement(\n          'p',\n          { className: 'w-tit' },\n          '\\u8D26\\u6237\\u660E\\u7EC6'\n        ) : \"\",\n        data.xianjin && data.xianjin.data ? React.createElement(\n          'div',\n          { className: 'w-table' },\n          repeat1(data.xianjin)\n        ) : \"\",\n        data.xieyi && data.xieyi.data ? React.createElement(\n          'div',\n          { className: 'w-table' },\n          repeat1(data.xieyi)\n        ) : \"\"\n      );\n    }\n  },\n  render: function render() {\n    var me = this,\n        data = me.props.customData,\n        state = me.state;\n    if (!data) {\n      return React.createElement('p', { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      Modal,\n      { isOpen: state.isOpen && data.tab.length > 0, role: 'page' },\n      React.createElement(NavBar, { title: '\\u4E2D\\u56FD\\u79FB\\u52A8\\u901A\\u4FE1\\u5BA2\\u6237\\u8D26\\u5355', lFn: function lFn() {\n          me.setState({ isOpen: false });\n        } }),\n      me.renderAll()\n    );\n  },\n  click: function click(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: id\n      });\n    }\n  }\n});";
    },
    getData_control3_gwXDmu: function (elem) {},
    doAction_uiControl3_y5mLqa: function (data, elem) {
      if (data.eventType == 'click') {
        $(elem).click();ysp.appMain.showLoading();setTimeout(function () {
          ysp.appMain.hideLoading();
        }, 4000);
      } else {}
    },
    getTemplate_uiControl3_y5mLqa: function () {
      var selfTemplate = "const Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  // componentDidMount:function(){\n  //   const me = this;\n  //   me.handle('','');\n  // },\n  render: function() {\n    const me = this;\n    return (\n      <div style={{height:'100%',paddingBottom:'400px'}}>\n       <Button amStyle=\"success\" style={{display:\"block\",width:\"100%\"}} onClick={()=>{\n            me.handle('','click');\n            window.__ysp_Wstate();\n          }}>\u67E5\u8BE2</Button>\n      </div>\n    )\n  },\n  handle:function(data,eventType){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({data,eventType});   \n    } \n  }\n});";
      return "'use strict';\n\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  // componentDidMount:function(){\n  //   const me = this;\n  //   me.handle('','');\n  // },\n  render: function render() {\n    var me = this;\n    return React.createElement(\n      'div',\n      { style: { height: '100%', paddingBottom: '400px' } },\n      React.createElement(\n        Button,\n        { amStyle: 'success', style: { display: \"block\", width: \"100%\" }, onClick: function onClick() {\n            me.handle('', 'click');\n            window.__ysp_Wstate();\n          } },\n        '\\u67E5\\u8BE2'\n      )\n    );\n  },\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  }\n});";
    }
  }, "billingInquiries");
})(window, ysp);