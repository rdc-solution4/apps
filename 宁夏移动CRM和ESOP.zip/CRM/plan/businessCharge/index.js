(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control15_GOX7aI: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find(".tab-title").text();
    },
    doAction_uiControl9_N9Bn5F: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        $(elem).find(".tab-close").click();ysp.appMain.backToIndex();
      }
    },
    getTemplate_uiControl9_N9Bn5F: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back('','back');\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }                       \n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back('', 'back');\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control18_3NWOcR: function (elem) {
      // 用于收费iCRM
      if (!elem) {
        return;
      }var obj = { tabs: [] },
          $pgHeader = $(elem).find('.pgHeader.menu_btn') /* 搜索框*/; //
      /*获取当前显示的内容的顶层div ----------begin----*/var navLis = $(elem).find('.navigatorBar .tab .floatCon.toLeft').find('li'),
          navTitle = '',
          selectIdx = '';for (var i = 0, len = navLis.length; i < len; i++) {
        var navLi = $(navLis[i]),
            liT = navLi.attr('title');obj.tabs.push(liT);if (navLi.attr('class').indexOf('selected') > -1) {
          selectIdx = i;if (liT == '我的工作台' || liT == '收费（iCRM）' || liT == '余额查询') {
            navTitle = liT;
          } else if (!isNaN(liT)) {
            navTitle = '360视图';
          }
        }
      }var tabContainer = $(elem).find('.main-right').children('.tabcontainer'),
          nowTab = $(tabContainer[selectIdx]); //
      /*获取当前显示的内容的顶层div ----------end------*/ //
      if (navTitle == '收费（iCRM）') {
        var rp = ysp.customHelper.replaceSpace;var getPureText = function ($dom) {
          return $dom && $dom[0] && $dom[0].childNodes ? $dom[0].childNodes[0].nodeValue : "";
        };var getTable = function ($dom, pureTr) {
          var $ths = $dom.find('.bc_grid_head thead th'),
              ths = [],
              $trs = $dom.find('.bc_grid_body tbody tr'),
              trs = [],
              removeIdx = ',';for (var i = 0, l = $ths.length; i < l; i++) {
            var th = rp($($ths[i]).text());if (th != '') {
              ths.push(th);
            } else {
              removeIdx += i + ',';
            }
          }for (var i = 0, l = $trs.length; i < l; i++) {
            var $tds = $($trs[i]).find('td'),
                tds = [];for (var j = 0, len = $tds.length; j < len; j++) {
              if (removeIdx.indexOf(',' + j + ',') == -1) {
                if (pureTr.idx == j) {
                  tds.push(getPureText($($tds[j]).find(pureTr.selector)));
                } else {
                  tds.push(rp($($tds[j]).text()));
                }
              }
            }trs.push(tds);
          }return { ths: ths, trs: trs };
        };$(elem).find('#commitBtn').removeAttr('disable');obj = { billList: {}, //chargeBillList
          balanceList: {}, //subjectBalanceList
          privilegeList: {}, //subsPrivilegeList
          factpay: {}, tabBtns: [], take: {}, info: {}, chargeType: {}, custInfo: {}, shouldPay: {}, tabLink: [], numberLabel: {}, showCharge: true, commitBtn: { text: "提交", selector: '#commitBtn' }, previewBtn: { text: "票据预览", selector: '#previewBtn' }, account: {}, verifyCode: {}, /**  更多选择*/clickBtn: {}, /**  付费方式*/pay: {}, /**  发票号码*/invoice: {}, /**  连缴*/evenpay: {}, /**  加载中...*/loading: {} };var $html = nowTab.children("iframe").contents(); /* 获取当前显示的下拉列表  ------begin*/var $chargeType = $html.find("#queryType").parent().parent(),
            $numberLabel = $html.find("#numberLabel"),
            $account = $html.find("#selectAccountDiv"),
            $info = $html.find("#_blurInfoFireDiv_").parent().parent(),
            $factPay = $html.find("#factPay"),
            $take = $html.find("#takeCash").parent().parent(),
            $tabLink = $html.find("#custDetailBtn").parent().children('a'),
            $tabBtns = $html.find("#custDetailBtn").parent().children('span'),
            $custInfo = $html.find("#custInfoDiv"),
            $custTrs = $custInfo.find("#custInfoDiv_content table table").find('tr'),
            $shouldPay = $html.find("#shouldPayDiv"),
            $shouldTrs = $shouldPay.find("#shouldPayDiv_content table table").find('tr'),
            $verifyCode = $html.find("#verifyCode"),
            $codeInput = $verifyCode.find('.bc_field_body input'),
            $codeImg = $verifyCode.find('#verifyCoderPic'),
            $paying = $html.find("#payTypeList").parent(),
            $invoice = $html.find("#moreChooseDiv").children().eq(2).find('td'),
            $evenpay = $html.find("#linkChargeTableList").parent().parent().parent(),
            $clickBtn = $html.find("#moreChoose_container"),
            $loading = $html.find("#bme_monitor");obj.balanceList = getTable($html.find('#subjectBalanceList'), { idx: 8, selector: 'span' });obj.privilegeList = getTable($html.find('#subsPrivilegeList'), { idx: -1 });obj.billList = getTable($html.find('#chargeBillList'), { idx: 6, selector: 'span' });obj.verifyCode = { input: { value: $codeInput.value, selector: '#' + $codeInput.attr('id') }, img: { src: $codeImg.attr('data-src'), selector: '#' + $codeImg.attr('id') } };obj.shouldPay = { title: rp($shouldPay.find("#shouldPayDiv_titlebar").text()), trs: function () {
            var trs = [];for (var i = 0, l = $shouldTrs.length; i < l; i++) {
              if ($($shouldTrs[i]).css("display") != 'none') {
                var $tds = $($shouldTrs[i]).find('td'),
                    tds = [];for (var j = 0, len = $tds.length; j < len; j++) {
                  var labelT = $($tds[j]).find('.bc_field_label').text();if (labelT) {
                    tds.push({ label: labelT, value: $($tds[j]).find('.bc_field_body').text().trim() });
                  }
                }trs.push(tds);
              }
            }return trs;
          }() };obj.custInfo = { title: rp($custInfo.find("#custInfoDiv_titlebar").text()), trs: function () {
            var trs = [];for (var i = 0, l = $custTrs.length; i < l; i++) {
              if ($($custTrs[i]).css("display") != 'none') {
                var $tds = $($custTrs[i]).find('td'),
                    tds = [];for (var j = 0, len = $tds.length; j < len; j++) {
                  var labelT = $($tds[j]).find('.bc_field_label').text();if (labelT) {
                    tds.push({ label: labelT, value: rp($($tds[j]).find('.bc_field_body').text()) });
                  }
                }trs.push(tds);
              }
            }return trs;
          }() };obj.tabBtns = function () {
          var tabs = [];for (var i = 0, l = $tabBtns.length; i < l; i++) {
            tabs.push({ text: getPureText($($tabBtns[i]).find('.bc_btn_right')), selector: '#' + $($tabBtns[i]).attr('id') });
          }return tabs;
        }();obj.tabLink = function () {
          var tabs = [];for (var i = 0, l = $tabLink.length; i < l; i++) {
            tabs.push({ text: getPureText($($tabLink[i]).children('span')), selector: '#' + $($tabLink[i]).attr('id') });
          }return tabs;
        }();obj.factpay = { label: $factPay.find('.bc_field_label').text(), input: { value: $factPay.find('.bc_field_body input').val(), selector: '#' + $factPay.find('.bc_field_body input').attr('id'), errMsg: $factPay.find('.bc_field_body input').attr('bmevmsg') } };obj.take = { label: $take.find('.bc_field_label').text(), input: { value: $take.find('.bc_field_body input').val(), selector: '#' + $take.find('.bc_field_body input').attr('id') } };obj.info = { label: $info.find('.bc_field_label').text(), trs: function () {
            var $labels = $info.find('.bc_field_append > label'),
                _trs = [],
                _tr = {};for (var i = 0, l = $labels.length; i < l; i++) {
              var text = $($labels[i]).text();if (text == '|') {} else if (_tr.label) {
                _tr.value = text;_trs.push(_tr);_tr = {};
              } else {
                _tr.label = text;
              }
            }return _trs;
          }() };obj.account = { label: $account.find('.bc_field_label').text(), select: { value: $account.find("option").filter(function (idx) {
              return $(this).prop('selected') === true;
            }).text(), selector: '#' + $account.find('.bc_field_body select').attr('id'), options: function () {
              var opts = [],
                  $options = $account.find("option");for (var i = 0, l = $options.length; i < l; i++) {
                opts.push({ text: $($options[i]).text(), value: $($options[i]).val() });
              }return opts;
            }() }, btn: { text: getPureText($account.find('#multiChargeBtn .bc_btn_right')), selector: '#multiChargeBtn' } };obj.numberLabel = { label: $numberLabel.find('.bc_field_label').text(), input: { value: $numberLabel.find('.bc_field_body input').val(), selector: '#' + $numberLabel.find('.bc_field_body input').attr('id') }, btn: { text: function () {
              var _o = $numberLabel.find('#queryBtn .bc_btn_right').clone();return getPureText(_o);
            }(), selector: '#queryBtn' } };obj.chargeType = { label: $chargeType.find('.bc_field_label').text(), radios: function () {
            var $dom = $chargeType.find('#queryType_container label'),
                $radio = $chargeType.find('#queryType_container input[type="radio"]'),
                _arr = [];for (var i = 0, l = $dom.length; i < l; i++) {
              var _a = $($radio[i]);_arr.push({ label: $($dom[i]).text(), selector: '#' + _a.attr('id'), isChecked: _a.prop('checked') });
            }return _arr;
          }() };obj.clickBtn = { text: $clickBtn.find("label").text(), selector: "#" + $clickBtn.find("input").attr("id") };obj.loading = { textArray: function () {
            var arr = [];$loading.find(".bc_monitor_box").children().each(function (i, el) {
              if ($(el).css('display') != "none") {
                arr.push({ text: $(el).find("label").text() });
              }
            });return arr;
          }() };obj.pay = { // title: $paying.html().find(".bc_field_label").html(),$html.find("#AID_37251")
          title: $paying.prev().text(), textArray: function () {
            var $text,
                $id = "",
                $classType = "",
                $selected = "",
                textList = $paying.find("#payTypeList_0"),
                _arr = [];textList.children().each(function (i, el) {
              if (i == 0) {
                $classType = "option";$id = "#" + $(el).find("#payTypeDictItemList_0_select").attr("id");$text = [];$(el).find("option").each(function (g, ng) {
                  $text.push({ selected: $(ng).prop("selected") ? true : false, text: $(ng).text(), value: $(ng).val() });
                });
              } else if (i == 1) {
                $classType = "input";$id = "#" + $(el).find("#fee_0_value").attr("id");$text = [];$text.push({ text: $(el).find("#fee_0_value").text() || "", value: $(el).find("#fee_0_value").val() });
              } else {
                $classType = "input";$id = "#" + $(el).attr("id");$text = [];$text.push({ text: $(el).text().trim() || "" });
              }_arr.push({ lable: $paying.find("th").eq(i).text(), classType: $classType, selector: $id, text: $text });
            });return _arr;
          }() };obj.invoice = { btn: { text: function () {
              var _o = $invoice.find('.bc_btn.bc_ui_ele.bc_submit .bc_btn_right').clone();return getPureText(_o);
            }(), selector: $invoice.find(".bc_btn.bc_ui_ele.bc_submit").attr("id") }, subjectBtn: { text: function () {
              var _o = $invoice.find('.bc_border.bc_ps_input .bc_toggleable').attr("title");return _o;
            }(), selector: $invoice.find(".bc_ps_select.bc_toggleable").attr("id") }, arr: function () {
            var _brr = [],
                text;$invoice.each(function (i, el) {
              if (i != 2 && i != 3 && i != 4) {
                var $type = "",
                    $id = "",
                    $text = "",
                    $value = "",
                    $checked = "",
                    classType = "";if ($(el).find("input").hasClass("input_text_normal")) {
                  classType = "input_text_normal";text = {};text = { selector: "#" + $(el).find("input").attr("id"), value: $(el).find("input").val(),
                    text: $(el).find("input").text(), subjectId: $(el).find("input").prev().attr("id") || "" };
                } else if ($(el).find("input").hasClass("cbme_clear")) {
                  classType = "radio";text = [];$(el).find(".bc_checkradio_list").children().each(function (g, ng) {
                    text.push({ selector: "#" + $(ng).find("input").attr("id"), text: $(ng).find("input").next().text(), checked: $(ng).find("input").prop("checked") ? true : false });
                  });
                } else if ($(el).find("textarea").hasClass("textarea_normal")) {
                  classType = "textarea_normal";text = {};text = { selector: "#" + $(el).find("textarea").attr("id"), value: $(el).find("textarea").val() || "",
                    text: $(el).find("textarea").text() };
                }_brr.push({ lable: $(el).find(".bc_field_label").text(), classType: classType, text: text });
              }
            });return _brr;
          }() };obj.evenpay = { spBtn: function () {
            var data = [];$evenpay.find("#linkChargeTableList_databody").find("tr").each(function (i, el) {
              var btn = [];$(el).find("td").last().children().children("span").each(function (s, sp) {
                var btnCroup = {};if (s == 0) {
                  btnCroup.selector = "#" + $(sp).attr("id");btnCroup.txt = "修改";btn.push(btnCroup);
                } else {
                  // var btnCroup = {};
                  btnCroup.selector = "#" + $(sp).attr("id");btnCroup.txt = "删除";btn.push(btnCroup);
                }
              });data.push({ "spanbtn": btn });
            });return data;
          }(), arr: function () {
            var data = [];$evenpay.find("#linkChargeTableList_databody").find("tr").each(function (i, el) {
              if (i < 2) {
                var tr = [];$(el).find("td").each(function (g, ng) {
                  var properties = [];tr.push(properties);properties.push($evenpay.find("#linkChargeTableList_head").find("th").eq(g).text());properties.push($(ng).text().trim());
                });tr.pop();data.push({ "properties": tr });
              } else if (i > 1) {
                var tr = [],
                    btn = [];$(el).find("td").each(function (g, ng) {
                  if (g != 4) {
                    var properties = [];tr.push(properties);properties.push($evenpay.find("#linkChargeTableList_head").find("th").eq(g).text());properties.push($(ng).text().trim());
                  }data.push({ "properties": tr, "btn": "123" });
                });data.push({ "properties": tr });
              }
            });return data;
          }(), btn: { text: function () {
              var _o = $evenpay.find('.margin_left_5.bc_btn_blue.bc .bc_btn_right').clone();return getPureText(_o);
            }(), selector: "#" + $evenpay.find(".margin_left_5.bc_btn_blue.bc").attr("id") }, brr: function () {
            var data = [],
                textArray;$evenpay.children().eq(2).find("td").each(function (i, el) {
              var lable = "",
                  classType = "",
                  selector = "",
                  value = "",
                  text = "",
                  textArray = {};if (i != 0) {
                if (i == 1) {
                  // lable: $(el).find(".bc_field_label").text() || "";
                  // classType: "input";
                  textArray = { selector: "#" + $(el).find("input").attr("id"), value: $(el).find("input").val(), text: $(el).find("input").text() };data.push({ lable: $(el).find(".bc_field_label").text() || "", classType: "input", textArray: textArray });
                } else if (i == 3) {
                  // lable: $(el).find(".bc_field_label").text() || "";
                  // classType: "input";
                  textArray = { selector: "#" + $(el).find("input").attr("id"), value: $(el).find("input").val(), text: $(el).find("input").text() };data.push({ lable: $(el).find(".bc_field_label").text() || "", classType: "input", textArray: textArray });
                } else if (i == 2) {
                  textArray = { lable: $(el).find(".bc_field_label").text() || "", classType: "text", text: $(el).find(".bc_label.bc").text() };data.push(textArray);
                }
              }
            });return data;
          }() };
      }return obj;
    },
    doAction_uiControl11_N7URbO: function (data, elem) {
      // 用于收费iCRM
      /*获取当前显示的内容的顶层div ----------begin----*/ //
      var navLis = $(elem).find('.navigatorBar .tab .floatCon.toLeft').find('li'),
          tabContainer = $(elem).find('.main-right').children('.tabcontainer'),
          nowTab = '';for (var i = 0, len = navLis.length; i < len; i++) {
        var navLi = $(navLis[i]),
            liT = navLi.attr('title');if (navLi.attr('class').indexOf('selected') > -1) {
          nowTab = $(tabContainer[i]);
        }
      } //
      /*获取当前显示的内容的顶层div ----------end------*/ //
      var _d = data.customData,
          $html = nowTab.children("iframe").contents();switch (data.eventType) {case "click":
          $html.find(_d.selector).click();0;break;case "clickbtn":
          $html.find(_d.selector).click();0;break;case "tijiaoclick":
          $html.find(_d.selector).click();ysp.appMain.showLoading();setTimeout(function () {
            ysp.appMain.hideLoading();
          }, 5000);0;break;case "inputChange":
          // ysp.customHelper.fireKeyEvent($input[0], 'keydown', '13');
          // $input[0].dispatchEvent(new Event('change'));
          var $input = $html.find(_d.selector);$input.focus().val(_d.value);$input[0].dispatchEvent(new Event('change'));$input.blur();setTimeout(function () {// ysp.customHelper.fireKeyEvent($input[0], 'keydown', '13');
          }, 500);break;default:
          break;}
    },
    getTemplate_uiControl11_N7URbO: function () {
      var selfTemplate = "// \u7528\u4E8E\u6536\u8D39iCRM\nconst {Container,Button,Title,TodoItemTypeOne,TodoItemTypeTwo,Pair,Tabs,Field,Card,Choose}= AMUI2;\nconst {Modal,TopCondition,NavBar,PageBar} = require('ysp-custom-components');\n\nimport { back } from 'appRenderer';\nimport { Table } from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  getInitialState: ()=>({}),\n  handle:function(data,eventType){\n    var callback = this.props.customHandler;\n    if(callback){\n      callback({\n        data:data,\n        eventType:eventType\n      });\n    }\n    if(eventType == \"clickbtn\"){\n      this.toggleState()\n    }\n  },\n   toggleState:function(event){\n    this.setState({showCondition:!this.state.showCondition});\n  },\n  render: function() {\n    const me = this, _d = this.props.data.customData,\n          {chargeType,custInfo,shouldPay,tabBtns,tabLink,factpay,verifyCode:vCode,\n           take,info,account,numberLabel,showCharge,pay,invoice,clickBtn,evenpay} = _d, \n          state = me.state;\n    let dom = '';\n\t\tif(!chargeType.label){\n      return <div></div>;\n    }\n    if(_d.showCharge){\n      \n      dom = <div className=\"chargeIcrm\" style={{padding:\"1rem\"}}>\n        \n      \t<div className=\"chargeType\" style={{position:\"relative\",marginBottom:\"1rem\"}}>\n          <div style={{display:\"inline-block\",height:\"40px\",lineHeight:\"40px\",width:\"5rem\",position:\"absolute\",left:\"0\",fontSize:\"14px\"}}>{chargeType.label}</div>\n          <div style={{display:\"inline-block\",height:\"40px\",lineHeight:\"40px\",borderBottom:\"1px solid #eee\",marginLeft:\"4.6rem\",width: \"81%\"}}>\n          \t {chargeType.radios.map((radio,i)=>{\n              return (\n            \t\t<span class=\"am2-item\" onClick={()=>{me.handle(radio,'click');}} style={{border:\"none\",padding:\"0\",margin:\"0 .5rem\",display:'inline'}}>\n                  <span class=\"am2-item-after\">\n                    <span class=\"am2-switch\">\n                      <input type=\"checkbox\" checked={radio.isChecked?true:''} value=\"on\"></input>\n                      <span class=\"am2-switch-radio\"></span>\n                    </span>\n                  </span>\n                  <span class=\"am2-item-title\" style={{marginLeft:\"5px\",display:'inline'}}>{radio.label}</span>\n                </span>\n              )\n            })}\n          </div>\n        </div>\n          {numberLabel.label? <div className=\"w-style numberLabel\">\n        \t<div>{numberLabel.label}</div>\n          <div className=\"first\">\n          \t<AInput type=\"text\" value={numberLabel.input.value} onBlur={(e)=>{\n              me.handle({...numberLabel.input,value:e.target.value},\n                        'inputChange');\n            }}/>\n          <Button onClick={()=>{\n                me.handle(numberLabel.btn,'click');\n              }} amStyle=\"primary\" rounded>{numberLabel.btn?numberLabel.btn.text:''}</Button>\n          </div>\n        </div>:''}\n        {account.label? <div className=\"w-style account\">\n          <div>{account.label}</div>\n          <div className=\"first\">\n            <select onChange={(e)=>{\n              me.handle({\n                selector:account.select.selector,\n                value:e.target.value\n              },'inputChange');\n            }}>\n            {account.select.options.map((option,i)=>{\n              return <option value={option.value}>{option.text}</option>\n            })}\n          </select>\n            {account.btn.text?<Button onClick={()=>{\n                me.handle(account.btn,'click');\n              }} amStyle=\"primary\" rounded>{account.btn.text}</Button>:''}\n          \n          </div>\n        </div>:''}\n          {factpay.label? <div className=\"w-style factpay\" style={{flexFlow:\"row wrap\"}}>\n          <div>{factpay.label}</div>\n          \t<AInput type=\"text\" value={factpay.input.value} onFocus={()=>{\n              me.setState({...state,showTake:false});\n            }} onBlur={(e)=>{\n              me.handle({...factpay.input,value:e.target.value},\n                        'inputChange');\n              me.setState({...state,showTake:true});\n            }}/>\n        \t\t{factpay.input.errMsg? <i style={{flex:'0 0 50%',color:'red'}}>{factpay.input.errMsg}</i>:''}\n        </div>:''}\n          {take.label && state.showTake? <div className=\"w-style take\">\n          <div>{take.label}</div>\n          <AInput readonly={true} type=\"text\" value={take.input.value} onBlur={(e)=>{\n              if(take.input.value >= factpay.input.value){\n                \n                me.handle({...take.input,value:e.target.value}, 'inputChange');\n              }\n            }}/>\n        </div>:''}\n          \n           {/** \u4ED8\u8D39\u65B9\u5F0F  */}        \n          \n         {/**\n          {clickBtn && clickBtn.text?<Button block amStyle=\"secondary\" amSize=\"xs\" onClick={()=>{\n                me.handle(clickBtn,'clickbtn');\n              }}>{clickBtn.text}</Button>:''}\n         */}\n      \n          <div className=\"\" style={{marginTop:\"1px\",display:me.state.showCondition?\"block\":\"none\"}}>\n          <Title amStyle=\"primary\">{pay.title}</Title>\n\t\t\t\t\t<div className=\"chargeCard\">\n          \t{pay.textArray.map(function(item,i){\n            var html;\n              if( item.classType == \"option\"){\n\t\t\t\t\t\t\t\thtml = <select onChange={(e)=>{\n                          me.handle({\n                            selector:item.selector,\n                            value:e.target.value\n                          },'inputChange');\n                        }}>\n                        {item.text.map((option,i)=>{\n                          return <option value={option.value}>{option.text}</option>\n                        })}\n                      </select>\n              } else if( item.classType == \"input\" ){\n                html = <AInput type=\"text\" value={item.text.value} onBlur={(e)=>{\n                     \n              me.handle({...item,value:e.target.value},\n                        'inputChange');\n            }}/>\n              }\n            return(\n              <span className=\"am2-item\" >\n                  <div className=\"am2-field-label\"><div>{item.lable}</div></div>\n                  <div className=\"am2-field-wrap\">\n                    {html}\n                  </div>\n\t\t\t\t\t\t </span>\n             )\n          })}\n          </div>\n          \n          \t{invoice.arr.map(function(item,i){\n              var html;\n              if( item.classType == \"input_text_normal\" ){\n                if( i==3 ){\n                  html = <div>\n                  <AInput type=\"text\" value={item.text.value} onBlur={(e)=>{\n                      \n              me.handle({...item.text,value:e.target.value},\n                        'inputChange');\n            }}/>\n                  {/**\n                  <Button onClick={()=>{\n                me.handle(invoice.subjectBtn,'click');\n              }} amStyle=\"primary\" rounded>{invoice.subjectBtn?invoice.subjectBtn.text:''}</Button>\n                  */}  \n                  </div>\n                } else if( i==5 ){\n                  html = <div>\n                  <AInput type=\"text\" value={item.text.value} onBlur={(e)=>{\n                     \n              me.handle({...item.text,value:e.target.value},\n                        'inputChange');\n            }}/>\n                    \n                  <Button onClick={()=>{\n                me.handle(invoice.btn,'click');\n              }} amStyle=\"primary\" rounded>{invoice.btn?invoice.btn.text:''}</Button></div>\n                } else {\n                  html = <AInput type=\"text\" value={item.text.value} onBlur={(e)=>{\n                     \n              me.handle({...item.text,value:e.target.value},\n                        'inputChange');\n            }}/>\n                }\n              } else if( item.classType == \"radio\" ){\n                html =  <div style={{display:\"inline-block\",height:\"40px\",lineHeight:\"40px\",borderBottom:\"1px solid #eee\",marginLeft:\"4.6rem\",width: \"81%\"}}>\n          \t {item.text.map((radio,i)=>{\n              return (\n            \t\t<span class=\"am2-item\" onClick={()=>{me.handle(radio,'click');}} style={{border:\"none\",padding:\"0\",margin:\"0 .5rem\",display:'inline'}}>\n                  <span class=\"am2-item-after\">\n                    <span class=\"am2-switch\">\n                      <input type=\"checkbox\" checked={radio.checked?true:''} value=\"on\"></input>\n                      <span class=\"am2-switch-radio\"></span>\n                    </span>\n                  </span>\n                  <span class=\"am2-item-title\" style={{marginLeft:\"5px\",display:'inline'}}>{radio.text}</span>\n                </span>\n              )\n            })}\n          </div>\n              } else if( item.classType == \"textarea_normal\" ){\n                html = <ATextarea value={item.text.value} onBlur={(e)=>{\n                       \n              me.handle({...item.text,value:e.target.value},\n                        'inputChange');\n            }}></ATextarea>\n              }\n            return(\n              <span className=\"am2-item\" >\n                  <div className=\"am2-field-label\"><div>{item.lable}</div></div>\n                  <div className=\"am2-field-wrap\">\n                    {html}\n                  </div>\n\t\t\t\t\t\t </span>\n             )\n          })}\n             \n          </div>\n          \n          {/** \u8FDE\u7F34 */}  \n          <div>\n          \t{evenpay.arr.map((item, index) => {\n                const { properties } = item;\n           \t\t\tconst topProperties = [];\n               return(\n                  <TodoItemTypeTwo\n                  key={index}\n                  defaultCollapsed ={false}\n                  subtitle={topProperties.map((p, i) => {\n                    return <Pair key={i} name={p[0]} value={p[1]} />;\n                  })}\n                  style={{background:\"#F6F6F6\",margin:\"1rem\"}}\n                >\n\t\t\t\t\t\t\t\t\t{properties.map((p, i) => {\n                  return <Pair key={i} name={p[0]} value={p[1]} />;\n                \t})}\n                  \n                   <div className=\"am2-g\">\n                \t\t{evenpay.spBtn[index].spanbtn.map(function(item, i){\n                       return(\n                      <div id={item.id} onClick={()=>{me.handle(item,'click');}} style={{height:\"40px\",lineHeight:\"50px\",textAlign:\"center\",borderTop:\"1px solid #fff\",fontSize:\"14px\",display:\"inline-block\"}} className=\"am2-col\">{item.txt}</div>\n                    )\n                     })}\n                \t </div>\n                </TodoItemTypeTwo>\n              );\n            })}\n          \n            {evenpay.brr.map(function(item, i){\n              var html;\n              if( i==0 ){\n                html =<div>\n                  <AInput type=\"text\" value={item.textArray.value} onBlur={(e)=>{\n                     \n              me.handle({...item.textArray,value:e.target.value},\n                        'inputChange');\n            }}/>\n                    \n                  <Button onClick={()=>{\n                me.handle(evenpay.btn,'click');\n              }} amStyle=\"primary\" rounded>{evenpay.btn?evenpay.btn.text:''}</Button></div>\n              } else if( i==1 ){\n                html = <span>{item.text}</span>\n              } else if( i==2 ){\n                html = <AInput type=\"text\" value={item.textArray.value} onBlur={(e)=>{\n                     \n              me.handle({...item.textArray,value:e.target.value},\n                        'inputChange');\n            }}/>\n              }\n               return(\n              <span className=\"am2-item\" >\n                  <div className=\"am2-field-label\"><div>{item.lable}</div></div>\n                  <div className=\"am2-field-wrap\">\n                    {html}\n                  </div>\n\t\t\t\t\t\t </span>\n             )\n            })}\n          </div>\n          {/**        */}  \n          {vCode.img.src? <div style={{display:\"flex\",margin:\"1rem\"}}>\n          <span style={{flex:\"0 0 25%\"}}>\u9A8C\u8BC1\u7801\uFF1A</span>\n          <img style={{flex:\"0 0 25%\",margin:'0 3%'}} src={vCode.img.src} \n            onClick={()=>{me.handle(vCode.img,'click');}} />\n          <div><AInput style={{width:\"6rem\",border:'1px solid #eee',padding:'.3rem .5rem'}} \n                 onBlur={(e)=>{me.handle({...vCode.input,value:e.target.value},'inputChange');}} />\n          </div>\n        </div>:''}\n        <div className=\"chargeInfo\">\n          <Title amStyle=\"primary\">{info.label}</Title>\n\t\t\t\t\t<div className=\"chargeCard\">\n          \t{info.trs.map((tr,i)=>{\n              return <Pair key={i} name={tr.label} value={tr.value}/>\n            })}\n          </div>\n        </div>\n        \t{tabBtns[0]?<div className=\"bottomBtnDiv am2-g\" style={{width:\"100%\"}}>\n        \t  <Button className=\"bottomBtn am2-col\" amStyle=\"primary\" onClick={()=>{\n              me.handle(_d.previewBtn,'click');\n            }} style={{border:\"none\",borderRadius:\"inherit\",color:\"#fff\",background:\"#70CB5D\",margin:\"0\",    padding: \"0\"}}>{_d.previewBtn.text}</Button>\n        \t  <Button className=\"bottomBtn am2-col\" amStyle=\"primary\" onClick={()=>{\n              me.handle(_d.commitBtn,'tijiaoclick');\n            }} style={{border:\"none\",borderRadius:\"inherit\",color:\"#fff\",background:\"#46B7F6\",margin:\"0\"}}>{_d.commitBtn.text}</Button>\n        </div>:''}  \n        </div>\n    }\n    // <NavBar title=\"\u6536\u8D39iCRM\" lFn={back} />\n    return (\n      <div style={{background:'#fff'}}>{dom}</div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar _appRenderer = require('appRenderer');\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\n// \u7528\u4E8E\u6536\u8D39iCRM\nvar _AMUI = AMUI2,\n    Container = _AMUI.Container,\n    Button = _AMUI.Button,\n    Title = _AMUI.Title,\n    TodoItemTypeOne = _AMUI.TodoItemTypeOne,\n    TodoItemTypeTwo = _AMUI.TodoItemTypeTwo,\n    Pair = _AMUI.Pair,\n    Tabs = _AMUI.Tabs,\n    Field = _AMUI.Field,\n    Card = _AMUI.Card,\n    Choose = _AMUI.Choose;\n\nvar _require = require('ysp-custom-components'),\n    Modal = _require.Modal,\n    TopCondition = _require.TopCondition,\n    NavBar = _require.NavBar,\n    PageBar = _require.PageBar;\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  getInitialState: function getInitialState() {\n    return {};\n  },\n  handle: function handle(data, eventType) {\n    var callback = this.props.customHandler;\n    if (callback) {\n      callback({\n        data: data,\n        eventType: eventType\n      });\n    }\n    if (eventType == \"clickbtn\") {\n      this.toggleState();\n    }\n  },\n  toggleState: function toggleState(event) {\n    this.setState({ showCondition: !this.state.showCondition });\n  },\n  render: function render() {\n    var me = this,\n        _d = this.props.data.customData,\n        chargeType = _d.chargeType,\n        custInfo = _d.custInfo,\n        shouldPay = _d.shouldPay,\n        tabBtns = _d.tabBtns,\n        tabLink = _d.tabLink,\n        factpay = _d.factpay,\n        vCode = _d.verifyCode,\n        take = _d.take,\n        info = _d.info,\n        account = _d.account,\n        numberLabel = _d.numberLabel,\n        showCharge = _d.showCharge,\n        pay = _d.pay,\n        invoice = _d.invoice,\n        clickBtn = _d.clickBtn,\n        evenpay = _d.evenpay,\n        state = me.state;\n    var dom = '';\n    if (!chargeType.label) {\n      return React.createElement('div', null);\n    }\n    if (_d.showCharge) {\n\n      dom = React.createElement(\n        'div',\n        { className: 'chargeIcrm', style: { padding: \"1rem\" } },\n        React.createElement(\n          'div',\n          { className: 'chargeType', style: { position: \"relative\", marginBottom: \"1rem\" } },\n          React.createElement(\n            'div',\n            { style: { display: \"inline-block\", height: \"40px\", lineHeight: \"40px\", width: \"5rem\", position: \"absolute\", left: \"0\", fontSize: \"14px\" } },\n            chargeType.label\n          ),\n          React.createElement(\n            'div',\n            { style: { display: \"inline-block\", height: \"40px\", lineHeight: \"40px\", borderBottom: \"1px solid #eee\", marginLeft: \"4.6rem\", width: \"81%\" } },\n            chargeType.radios.map(function (radio, i) {\n              return React.createElement(\n                'span',\n                { 'class': 'am2-item', onClick: function onClick() {\n                    me.handle(radio, 'click');\n                  }, style: { border: \"none\", padding: \"0\", margin: \"0 .5rem\", display: 'inline' } },\n                React.createElement(\n                  'span',\n                  { 'class': 'am2-item-after' },\n                  React.createElement(\n                    'span',\n                    { 'class': 'am2-switch' },\n                    React.createElement('input', { type: 'checkbox', checked: radio.isChecked ? true : '', value: 'on' }),\n                    React.createElement('span', { 'class': 'am2-switch-radio' })\n                  )\n                ),\n                React.createElement(\n                  'span',\n                  { 'class': 'am2-item-title', style: { marginLeft: \"5px\", display: 'inline' } },\n                  radio.label\n                )\n              );\n            })\n          )\n        ),\n        numberLabel.label ? React.createElement(\n          'div',\n          { className: 'w-style numberLabel' },\n          React.createElement(\n            'div',\n            null,\n            numberLabel.label\n          ),\n          React.createElement(\n            'div',\n            { className: 'first' },\n            React.createElement(AInput, { type: 'text', value: numberLabel.input.value, onBlur: function onBlur(e) {\n                me.handle(_extends({}, numberLabel.input, { value: e.target.value }), 'inputChange');\n              } }),\n            React.createElement(\n              Button,\n              { onClick: function onClick() {\n                  me.handle(numberLabel.btn, 'click');\n                }, amStyle: 'primary', rounded: true },\n              numberLabel.btn ? numberLabel.btn.text : ''\n            )\n          )\n        ) : '',\n        account.label ? React.createElement(\n          'div',\n          { className: 'w-style account' },\n          React.createElement(\n            'div',\n            null,\n            account.label\n          ),\n          React.createElement(\n            'div',\n            { className: 'first' },\n            React.createElement(\n              'select',\n              { onChange: function onChange(e) {\n                  me.handle({\n                    selector: account.select.selector,\n                    value: e.target.value\n                  }, 'inputChange');\n                } },\n              account.select.options.map(function (option, i) {\n                return React.createElement(\n                  'option',\n                  { value: option.value },\n                  option.text\n                );\n              })\n            ),\n            account.btn.text ? React.createElement(\n              Button,\n              { onClick: function onClick() {\n                  me.handle(account.btn, 'click');\n                }, amStyle: 'primary', rounded: true },\n              account.btn.text\n            ) : ''\n          )\n        ) : '',\n        factpay.label ? React.createElement(\n          'div',\n          { className: 'w-style factpay', style: { flexFlow: \"row wrap\" } },\n          React.createElement(\n            'div',\n            null,\n            factpay.label\n          ),\n          React.createElement(AInput, { type: 'text', value: factpay.input.value, onFocus: function onFocus() {\n              me.setState(_extends({}, state, { showTake: false }));\n            }, onBlur: function onBlur(e) {\n              me.handle(_extends({}, factpay.input, { value: e.target.value }), 'inputChange');\n              me.setState(_extends({}, state, { showTake: true }));\n            } }),\n          factpay.input.errMsg ? React.createElement(\n            'i',\n            { style: { flex: '0 0 50%', color: 'red' } },\n            factpay.input.errMsg\n          ) : ''\n        ) : '',\n        take.label && state.showTake ? React.createElement(\n          'div',\n          { className: 'w-style take' },\n          React.createElement(\n            'div',\n            null,\n            take.label\n          ),\n          React.createElement(AInput, { readonly: true, type: 'text', value: take.input.value, onBlur: function onBlur(e) {\n              if (take.input.value >= factpay.input.value) {\n\n                me.handle(_extends({}, take.input, { value: e.target.value }), 'inputChange');\n              }\n            } })\n        ) : '',\n        React.createElement(\n          'div',\n          { className: '', style: { marginTop: \"1px\", display: me.state.showCondition ? \"block\" : \"none\" } },\n          React.createElement(\n            Title,\n            { amStyle: 'primary' },\n            pay.title\n          ),\n          React.createElement(\n            'div',\n            { className: 'chargeCard' },\n            pay.textArray.map(function (item, i) {\n              var html;\n              if (item.classType == \"option\") {\n                html = React.createElement(\n                  'select',\n                  { onChange: function onChange(e) {\n                      me.handle({\n                        selector: item.selector,\n                        value: e.target.value\n                      }, 'inputChange');\n                    } },\n                  item.text.map(function (option, i) {\n                    return React.createElement(\n                      'option',\n                      { value: option.value },\n                      option.text\n                    );\n                  })\n                );\n              } else if (item.classType == \"input\") {\n                html = React.createElement(AInput, { type: 'text', value: item.text.value, onBlur: function onBlur(e) {\n\n                    me.handle(_extends({}, item, { value: e.target.value }), 'inputChange');\n                  } });\n              }\n              return React.createElement(\n                'span',\n                { className: 'am2-item' },\n                React.createElement(\n                  'div',\n                  { className: 'am2-field-label' },\n                  React.createElement(\n                    'div',\n                    null,\n                    item.lable\n                  )\n                ),\n                React.createElement(\n                  'div',\n                  { className: 'am2-field-wrap' },\n                  html\n                )\n              );\n            })\n          ),\n          invoice.arr.map(function (item, i) {\n            var html;\n            if (item.classType == \"input_text_normal\") {\n              if (i == 3) {\n                html = React.createElement(\n                  'div',\n                  null,\n                  React.createElement(AInput, { type: 'text', value: item.text.value, onBlur: function onBlur(e) {\n\n                      me.handle(_extends({}, item.text, { value: e.target.value }), 'inputChange');\n                    } })\n                );\n              } else if (i == 5) {\n                html = React.createElement(\n                  'div',\n                  null,\n                  React.createElement(AInput, { type: 'text', value: item.text.value, onBlur: function onBlur(e) {\n\n                      me.handle(_extends({}, item.text, { value: e.target.value }), 'inputChange');\n                    } }),\n                  React.createElement(\n                    Button,\n                    { onClick: function onClick() {\n                        me.handle(invoice.btn, 'click');\n                      }, amStyle: 'primary', rounded: true },\n                    invoice.btn ? invoice.btn.text : ''\n                  )\n                );\n              } else {\n                html = React.createElement(AInput, { type: 'text', value: item.text.value, onBlur: function onBlur(e) {\n\n                    me.handle(_extends({}, item.text, { value: e.target.value }), 'inputChange');\n                  } });\n              }\n            } else if (item.classType == \"radio\") {\n              html = React.createElement(\n                'div',\n                { style: { display: \"inline-block\", height: \"40px\", lineHeight: \"40px\", borderBottom: \"1px solid #eee\", marginLeft: \"4.6rem\", width: \"81%\" } },\n                item.text.map(function (radio, i) {\n                  return React.createElement(\n                    'span',\n                    { 'class': 'am2-item', onClick: function onClick() {\n                        me.handle(radio, 'click');\n                      }, style: { border: \"none\", padding: \"0\", margin: \"0 .5rem\", display: 'inline' } },\n                    React.createElement(\n                      'span',\n                      { 'class': 'am2-item-after' },\n                      React.createElement(\n                        'span',\n                        { 'class': 'am2-switch' },\n                        React.createElement('input', { type: 'checkbox', checked: radio.checked ? true : '', value: 'on' }),\n                        React.createElement('span', { 'class': 'am2-switch-radio' })\n                      )\n                    ),\n                    React.createElement(\n                      'span',\n                      { 'class': 'am2-item-title', style: { marginLeft: \"5px\", display: 'inline' } },\n                      radio.text\n                    )\n                  );\n                })\n              );\n            } else if (item.classType == \"textarea_normal\") {\n              html = React.createElement(ATextarea, { value: item.text.value, onBlur: function onBlur(e) {\n\n                  me.handle(_extends({}, item.text, { value: e.target.value }), 'inputChange');\n                } });\n            }\n            return React.createElement(\n              'span',\n              { className: 'am2-item' },\n              React.createElement(\n                'div',\n                { className: 'am2-field-label' },\n                React.createElement(\n                  'div',\n                  null,\n                  item.lable\n                )\n              ),\n              React.createElement(\n                'div',\n                { className: 'am2-field-wrap' },\n                html\n              )\n            );\n          })\n        ),\n        React.createElement(\n          'div',\n          null,\n          evenpay.arr.map(function (item, index) {\n            var properties = item.properties;\n\n            var topProperties = [];\n            return React.createElement(\n              TodoItemTypeTwo,\n              {\n                key: index,\n                defaultCollapsed: false,\n                subtitle: topProperties.map(function (p, i) {\n                  return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n                }),\n                style: { background: \"#F6F6F6\", margin: \"1rem\" }\n              },\n              properties.map(function (p, i) {\n                return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n              }),\n              React.createElement(\n                'div',\n                { className: 'am2-g' },\n                evenpay.spBtn[index].spanbtn.map(function (item, i) {\n                  return React.createElement(\n                    'div',\n                    { id: item.id, onClick: function onClick() {\n                        me.handle(item, 'click');\n                      }, style: { height: \"40px\", lineHeight: \"50px\", textAlign: \"center\", borderTop: \"1px solid #fff\", fontSize: \"14px\", display: \"inline-block\" }, className: 'am2-col' },\n                    item.txt\n                  );\n                })\n              )\n            );\n          }),\n          evenpay.brr.map(function (item, i) {\n            var html;\n            if (i == 0) {\n              html = React.createElement(\n                'div',\n                null,\n                React.createElement(AInput, { type: 'text', value: item.textArray.value, onBlur: function onBlur(e) {\n\n                    me.handle(_extends({}, item.textArray, { value: e.target.value }), 'inputChange');\n                  } }),\n                React.createElement(\n                  Button,\n                  { onClick: function onClick() {\n                      me.handle(evenpay.btn, 'click');\n                    }, amStyle: 'primary', rounded: true },\n                  evenpay.btn ? evenpay.btn.text : ''\n                )\n              );\n            } else if (i == 1) {\n              html = React.createElement(\n                'span',\n                null,\n                item.text\n              );\n            } else if (i == 2) {\n              html = React.createElement(AInput, { type: 'text', value: item.textArray.value, onBlur: function onBlur(e) {\n\n                  me.handle(_extends({}, item.textArray, { value: e.target.value }), 'inputChange');\n                } });\n            }\n            return React.createElement(\n              'span',\n              { className: 'am2-item' },\n              React.createElement(\n                'div',\n                { className: 'am2-field-label' },\n                React.createElement(\n                  'div',\n                  null,\n                  item.lable\n                )\n              ),\n              React.createElement(\n                'div',\n                { className: 'am2-field-wrap' },\n                html\n              )\n            );\n          })\n        ),\n        vCode.img.src ? React.createElement(\n          'div',\n          { style: { display: \"flex\", margin: \"1rem\" } },\n          React.createElement(\n            'span',\n            { style: { flex: \"0 0 25%\" } },\n            '\\u9A8C\\u8BC1\\u7801\\uFF1A'\n          ),\n          React.createElement('img', { style: { flex: \"0 0 25%\", margin: '0 3%' }, src: vCode.img.src,\n            onClick: function onClick() {\n              me.handle(vCode.img, 'click');\n            } }),\n          React.createElement(\n            'div',\n            null,\n            React.createElement(AInput, { style: { width: \"6rem\", border: '1px solid #eee', padding: '.3rem .5rem' },\n              onBlur: function onBlur(e) {\n                me.handle(_extends({}, vCode.input, { value: e.target.value }), 'inputChange');\n              } })\n          )\n        ) : '',\n        React.createElement(\n          'div',\n          { className: 'chargeInfo' },\n          React.createElement(\n            Title,\n            { amStyle: 'primary' },\n            info.label\n          ),\n          React.createElement(\n            'div',\n            { className: 'chargeCard' },\n            info.trs.map(function (tr, i) {\n              return React.createElement(Pair, { key: i, name: tr.label, value: tr.value });\n            })\n          )\n        ),\n        tabBtns[0] ? React.createElement(\n          'div',\n          { className: 'bottomBtnDiv am2-g', style: { width: \"100%\" } },\n          React.createElement(\n            Button,\n            { className: 'bottomBtn am2-col', amStyle: 'primary', onClick: function onClick() {\n                me.handle(_d.previewBtn, 'click');\n              }, style: { border: \"none\", borderRadius: \"inherit\", color: \"#fff\", background: \"#70CB5D\", margin: \"0\", padding: \"0\" } },\n            _d.previewBtn.text\n          ),\n          React.createElement(\n            Button,\n            { className: 'bottomBtn am2-col', amStyle: 'primary', onClick: function onClick() {\n                me.handle(_d.commitBtn, 'tijiaoclick');\n              }, style: { border: \"none\", borderRadius: \"inherit\", color: \"#fff\", background: \"#46B7F6\", margin: \"0\" } },\n            _d.commitBtn.text\n          )\n        ) : ''\n      );\n    }\n    // <NavBar title=\"\u6536\u8D39iCRM\" lFn={back} />\n    return React.createElement(\n      'div',\n      { style: { background: '#fff' } },\n      dom\n    );\n  }\n});";
    },
    getData_control22_PpVdVh: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find("#cs_subsShoppingItemDatagrid_databody").find("tr").each(function (i, el) {
        var tr = [];$(el).find("td").each(function (t, tds) {
          if (t != 3) {
            var properties = [];properties.push($(elem).find(".bc_grid_column_title").eq(t).text().trim());properties.push($(tds).text().trim());tr.push(properties);
          }
        });data.push({ properties: tr });
      });return data;
    },
    doAction_uiControl15_BRwuaX: function (data, elem) {},
    getTemplate_uiControl15_BRwuaX: function () {
      var selfTemplate = "const TodoItemTypeTwo = AMUI2.TodoItemTypeTwo;\nconst Pair = AMUI2.Pair;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if(!data){\n      return(\n      \t<div></div>\n      )\n    }\n    if( data ){\n      return (\n        <div className=\"w-rz-list\" style={{background:\"#f5f5f5\",paddingBottom:\"0.1rem\"}}>\n        {data.map((item, index) => {\n            const { properties } = item;\n            return(\n                  <div style={{background:\"#f5f5f5\",margin:\"1rem\",textAlign:'center'}}>\n                    {properties.map((p, i) => {\n                    return <Pair key={i} name={p[0]} value={p[1]} />;\n                    })}\n                  </div>\n              );\n          })}\n        </div>\n      )\n    }\n  }\n});";
      return "\"use strict\";\n\nvar TodoItemTypeTwo = AMUI2.TodoItemTypeTwo;\nvar Pair = AMUI2.Pair;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    if (data) {\n      return React.createElement(\n        \"div\",\n        { className: \"w-rz-list\", style: { background: \"#f5f5f5\", paddingBottom: \"0.1rem\" } },\n        data.map(function (item, index) {\n          var properties = item.properties;\n\n          return React.createElement(\n            \"div\",\n            { style: { background: \"#f5f5f5\", margin: \"1rem\", textAlign: 'center' } },\n            properties.map(function (p, i) {\n              return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n            })\n          );\n        })\n      );\n    }\n  }\n});";
    }
  }, "businessCharge");
})(window, ysp);