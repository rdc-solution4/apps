(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control84_IeOKWs: function (elem) {
      if (!elem) {
        return;
      }return $(elem).text().trim();
    },
    doAction_uiControl75_TZiO6G: function (data, elem) {
      var _d = data.customData;$(elem).find('.tab-close').click();
    },
    getTemplate_uiControl75_TZiO6G: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  handle:function(data,eventType){\n    const handler = this.props.customHandler;\n    if(handler){\n      handler({data,eventType});\n    }\n  },\n  render: function() {\n    const me = this, _d = me.props.customData;\n    return (\n      <Header amStyle=\"primary\" title={_d}>\n        <HeaderLeft>\n          <AMUI.Button amStyle=\"primary\" onClick={()=>{me.handle('','back');}} style={{marginBottom:0}}><span className=\"icon icon-left-nav\"></span>\u8FD4\u56DE</AMUI.Button>\n        </HeaderLeft>\n      </Header>\n    )\n  }\n});";
      return '\'use strict\';\n\nvar _yspInteriorComponents = require(\'ysp-interior-components\');\n\nvar _appRenderer = require(\'appRenderer\');\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var me = this,\n        _d = me.props.customData;\n    return React.createElement(\n      _yspInteriorComponents.Header,\n      { amStyle: \'primary\', title: _d },\n      React.createElement(\n        _yspInteriorComponents.HeaderLeft,\n        null,\n        React.createElement(\n          AMUI.Button,\n          { amStyle: \'primary\', onClick: function onClick() {\n              me.handle(\'\', \'back\');\n            }, style: { marginBottom: 0 } },\n          React.createElement(\'span\', { className: \'icon icon-left-nav\' }),\n          \'\\u8FD4\\u56DE\'\n        )\n      )\n    );\n  }\n});';
    },
    getData_control85_5K3HFC: function (elem) {
      if (!elem) {
        return;
      }var $html = $(elem).find('[innerid*="oclogintemp"]').contents();var listId = '',
          dropList = [];var queryDropList = function (list) {
        if (list.length > 0 && list.css('display') != 'none') {
          listId = list.attr('data-uuid');list.find('li').each(function (j, li) {
            if (["固话短信验证码", "短信验证码", "密码+证件", "服务密码+短信验证码", "本人身份证件+短信验证码", "本人身份证件+店长鉴权", "密码+证件+店长鉴权", "本人身份证件+短信验证码+店长鉴权"].indexOf(li.textContent) == -1) {
              dropList.push({ text: li.textContent, idx: j });
            }
          });
        } else {
          var _list = list.next('.DroplistOption');if (_list.length > 0) {
            queryDropList(_list);
          }
        }
      };queryDropList($html.find('body').next('.DroplistOption'));var title = $html.find('.Droplist[data-uuid="' + listId + '"]').parent().prev().text();return { list: dropList, listId: listId, title: title ? title.replace('：', '') : '' };
    },
    doAction_uiControl76_cqCxKi: function (data, elem) {
      var _d = data.customData;var $html = $(elem).find('[innerid*="oclogintemp"]').contents();switch (data.eventType) {case "selectChange":
          var trs = $html.find('.DroplistOption[data-uuid="' + _d.listId + '"]').find('li.dropItem');$(trs[_d.idx]).mousedown().click();break;case "clickBack":
          $html.find('body').mousedown();break;default:
          break;}
    },
    getTemplate_uiControl76_cqCxKi: function () {
      var selfTemplate = '// select\u4E0B\u62C9\u7EC4\u4EF6\nconst Modal = require(\'ysp-custom-components\').Modal;\nconst NavBar = require(\'ysp-custom-components\').NavBar;\nmodule.exports = React.createClass({\n  handle:function(data,eventType){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({data,eventType});\n    }\n  },\n  render: function() {\n    const me = this, _d = this.props.data.customData, state = me.state;\n\t\tif(!_d){\n      return <div></div>;\n    }\n    return <div style={{background:\'#eee\'}}>\n      <Modal isOpen={_d.title} role="page">\n        <NavBar title={_d.title} lFn={()=>{\n            me.handle(\'\',\'clickBack\');\n          }}/>\n        <div>\n          {_d.list.map((li,i)=>{\n            return <div style={{background:\'#fff\',padding:\'.6rem 1rem\',marginBottom:\'.4rem\'}}\n                     onClick={()=>{me.handle({listId:_d.listId,idx:li.idx},\'selectChange\');}}>\n            \t{li.text}\n            </div>;\n          })}\n        </div>\n      </Modal>\n    </div>;\n  }\n});';
      return "'use strict';\n\n// select\u4E0B\u62C9\u7EC4\u4EF6\nvar Modal = require('ysp-custom-components').Modal;\nvar NavBar = require('ysp-custom-components').NavBar;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var me = this,\n        _d = this.props.data.customData,\n        state = me.state;\n    if (!_d) {\n      return React.createElement('div', null);\n    }\n    return React.createElement(\n      'div',\n      { style: { background: '#eee' } },\n      React.createElement(\n        Modal,\n        { isOpen: _d.title, role: 'page' },\n        React.createElement(NavBar, { title: _d.title, lFn: function lFn() {\n            me.handle('', 'clickBack');\n          } }),\n        React.createElement(\n          'div',\n          null,\n          _d.list.map(function (li, i) {\n            return React.createElement(\n              'div',\n              { style: { background: '#fff', padding: '.6rem 1rem', marginBottom: '.4rem' },\n                onClick: function onClick() {\n                  me.handle({ listId: _d.listId, idx: li.idx }, 'selectChange');\n                } },\n              li.text\n            );\n          })\n        )\n      )\n    );\n  }\n});";
    },
    getData_control86_fULmpN: function (elem) {
      // 用于登录页
      if (!elem) {
        return;
      }var obj = { tabs: [] };var $html = $(elem).find('[innerid*="oclogintemp"]').contents();var list = [];$html.find('.changePayment_login > #mcmc > ul').find('li').each(function (i, li) {
        if (li.style.display != 'none') {
          var ipt = $(li).find('input'),
              o = { label: $(li).find('div.label').text().replace('：', ''), value: ipt.val(), inputId: ipt.attr('id') ? ipt.attr('id') : $(li).find('div.form-control').attr('id'), type: 'text' // readonly: ipt.attr('readonly')
          };if (o.label == '鉴权方式' && !o.value) {
            o.value = '请选择';
          }if (ipt.next().attr('class') == 'trigger') {
            o.type = 'select';o.btnId = ipt.next().attr('id');
          } else if (li.id == 'verifyCode') {
            o.type = 'code';var btn = ipt.next();o.btn = { id: ipt.next().attr('id'), text: ipt.next().val() };
          } else if (li.id == 'cartNumber') {
            o.type = 'card';o.readonly = 'readonly';o.btns = [];$(li).find('.btn_normal.vt_middle').each(function (i, btn) {
              o.btns.push({ id: btn.id, text: $(btn).text().trim() });
            });
          }list.push(o);
        }
      });return { loginBtnId: $html.find('.changePayment_login [x-autoid="loginbtn"]').attr('id'), list: list };
    },
    doAction_uiControl77_hXLaTF: function (data, elem) {
      var _d = data.customData;var $html = $(elem).find('[innerid*="oclogintemp"]').contents();switch (data.eventType) {case "textChange":
          $html.find('#' + _d.inputId).val(_d.value);break;case "idClick":
          var $btn = $html.find("#" + _d.id);$btn.mousedown().click();break;case "loginClick":
          ysp.appMain.showLoading();var doc = ysp.appMain.getActiveWindow().document;var _time = 0;var intervalId = setInterval(function () {
            if (_time++ > 20) {
              //最迟两秒后关闭定时
              clearInterval(intervalId);
            }if ($(doc).find('#dvMsgBox').length > 0 || $html.find('[id*="winmsg"]').length > 0) {
              clearInterval(intervalId);ysp.appMain.hideLoading();
            }
          }, 100); // 每0.1秒检查一次
          $html.find("#" + _d.btnId).click();break; // case "jump":
        //   var doc = ysp.appMain.getActiveWindow().document;
        //   ysp.customHelper.jump(doc, _d);
        //   break;
        default:
          break;}
    },
    getTemplate_uiControl77_hXLaTF: function () {
      var selfTemplate = "const Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  getInitialState: ()=>({}),\n  handle:function(data,eventType){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({data,eventType});\n    }\n  },\n  render: function() {\n    const me = this, _d = this.props.data.customData, state = me.state;\n\n    return <div className=\"user_login\" style={{background:'#fff'}}>\n        <div className=\"logo\"></div>\n        {_d.list.map((a, i)=>{\n          var labelLogo = 'login1',\n              holder='';\n          if(a.label=='\u670D\u52A1\u53F7\u7801'){\n          }else if(a.label=='\u9274\u6743\u65B9\u5F0F'){\n            labelLogo = 'login2';\n          }else if(a.label=='\u8BC1\u4EF6\u7F16\u53F7'||a.label=='\u77ED\u4FE1\u9A8C\u8BC1\u7801'||a.label=='\u670D\u52A1\u5BC6\u7801'){\n            labelLogo = 'login3';\n          }\n          if(a.type == 'text'){\n            return <div className=\"field-group\">\n                    <span className={labelLogo}></span>\n                    <AInput type={a.inputId=='password'?'password':'text'} \n                      className=\"field\"\n                      placeholder={a.label} onBlur={(e)=>{\n                      me.handle({...a, value: e.target.value}, 'textChange');\n                    }}/>\n                  </div>;\n          }else if(a.type == 'card'){\n            return <div>\n            \t<div className=\"field-group\">\n                <span className={labelLogo}></span>\n                <AInput type=\"text\" className=\"field\" value={a.value} readonly={a.readonly}\n                  placeholder={a.label} onBlur={(e)=>{\n                  me.handle({...a, value: e.target.value}, 'textChange');\n                }}/>\n              </div>\n              <div style={{textAlign:'center'}}>\n              \t{a.btns.map((btn,i)=>{\n                  return <Button amStyle=\"primary\" style={{margin:'0 .5rem 0 0',borderRadius:'1rem',\n                      \t\tpadding:'.4rem 1rem',fontSize:'.75rem'}} onClick={(e)=>{\n                        me.handle(btn, \"idClick\");\n                    }}>{btn.text}</Button>\n                })}\n              </div>\n            </div>;\n          }else if(a.type == 'code'){\n\t\t\t\t\t\treturn <div className=\"field-group\">\n                    <span className={labelLogo}></span>\n              \t\t\t<AInput type=\"number\" className=\"field code_field\" \n                      placeholder={a.label} onBlur={(e)=>{\n                      me.handle({...a, value: e.target.value}, 'textChange');\n                    }}/>\n                    <span className=\"am2-btn code_btn\" onClick={(e)=>{\n                        me.handle(a.btn, \"idClick\");\n                    }}>{a.btn.text}</span>\n                  </div>;\n          }else if(a.type == 'select'){\n            return <div className=\"field-group\">\n                    <span className={labelLogo}></span>\n                    <span className=\"field\" onClick={(e)=>{\n                        me.setState(a);\n                        me.handle({id:a.btnId}, \"idClick\");\n                    }}>{a.value}</span>\n                    <span className=\"am2-icon am2-icon-right-nav am2-item-icon\"></span>\n                  </div>;\n          }\n        })}\n        <div style={{marginTop:'1rem'}}>\n          <a className=\"loginBtn\" href=\"javascript:void(0);\" onClick={(e) => {\n              \t// me.handle(window.__ysp_jump_next_obj, 'jump');\n                me.handle({btnId: _d.loginBtnId}, \"loginClick\");\n            }}>\u767B\u5F55</a>\n      \t</div>\n      </div>;\n  }\n});";
      return '"use strict";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: "exports",\n\n  getInitialState: function getInitialState() {\n    return {};\n  },\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var me = this,\n        _d = this.props.data.customData,\n        state = me.state;\n\n    return React.createElement(\n      "div",\n      { className: "user_login", style: { background: \'#fff\' } },\n      React.createElement("div", { className: "logo" }),\n      _d.list.map(function (a, i) {\n        var labelLogo = \'login1\',\n            holder = \'\';\n        if (a.label == \'\u670D\u52A1\u53F7\u7801\') {} else if (a.label == \'\u9274\u6743\u65B9\u5F0F\') {\n          labelLogo = \'login2\';\n        } else if (a.label == \'\u8BC1\u4EF6\u7F16\u53F7\' || a.label == \'\u77ED\u4FE1\u9A8C\u8BC1\u7801\' || a.label == \'\u670D\u52A1\u5BC6\u7801\') {\n          labelLogo = \'login3\';\n        }\n        if (a.type == \'text\') {\n          return React.createElement(\n            "div",\n            { className: "field-group" },\n            React.createElement("span", { className: labelLogo }),\n            React.createElement(AInput, { type: a.inputId == \'password\' ? \'password\' : \'text\',\n              className: "field",\n              placeholder: a.label, onBlur: function onBlur(e) {\n                me.handle(_extends({}, a, { value: e.target.value }), \'textChange\');\n              } })\n          );\n        } else if (a.type == \'card\') {\n          return React.createElement(\n            "div",\n            null,\n            React.createElement(\n              "div",\n              { className: "field-group" },\n              React.createElement("span", { className: labelLogo }),\n              React.createElement(AInput, { type: "text", className: "field", value: a.value, readonly: a.readonly,\n                placeholder: a.label, onBlur: function onBlur(e) {\n                  me.handle(_extends({}, a, { value: e.target.value }), \'textChange\');\n                } })\n            ),\n            React.createElement(\n              "div",\n              { style: { textAlign: \'center\' } },\n              a.btns.map(function (btn, i) {\n                return React.createElement(\n                  Button,\n                  { amStyle: "primary", style: { margin: \'0 .5rem 0 0\', borderRadius: \'1rem\',\n                      padding: \'.4rem 1rem\', fontSize: \'.75rem\' }, onClick: function onClick(e) {\n                      me.handle(btn, "idClick");\n                    } },\n                  btn.text\n                );\n              })\n            )\n          );\n        } else if (a.type == \'code\') {\n          return React.createElement(\n            "div",\n            { className: "field-group" },\n            React.createElement("span", { className: labelLogo }),\n            React.createElement(AInput, { type: "number", className: "field code_field",\n              placeholder: a.label, onBlur: function onBlur(e) {\n                me.handle(_extends({}, a, { value: e.target.value }), \'textChange\');\n              } }),\n            React.createElement(\n              "span",\n              { className: "am2-btn code_btn", onClick: function onClick(e) {\n                  me.handle(a.btn, "idClick");\n                } },\n              a.btn.text\n            )\n          );\n        } else if (a.type == \'select\') {\n          return React.createElement(\n            "div",\n            { className: "field-group" },\n            React.createElement("span", { className: labelLogo }),\n            React.createElement(\n              "span",\n              { className: "field", onClick: function onClick(e) {\n                  me.setState(a);\n                  me.handle({ id: a.btnId }, "idClick");\n                } },\n              a.value\n            ),\n            React.createElement("span", { className: "am2-icon am2-icon-right-nav am2-item-icon" })\n          );\n        }\n      }),\n      React.createElement(\n        "div",\n        { style: { marginTop: \'1rem\' } },\n        React.createElement(\n          "a",\n          { className: "loginBtn", href: "javascript:void(0);", onClick: function onClick(e) {\n              // me.handle(window.__ysp_jump_next_obj, \'jump\');\n              me.handle({ btnId: _d.loginBtnId }, "loginClick");\n            } },\n          "\\u767B\\u5F55"\n        )\n      )\n    );\n  }\n});';
    }
  });
})(window, ysp);