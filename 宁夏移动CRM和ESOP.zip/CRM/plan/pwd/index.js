(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control43_dEkCLv: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find(".tab-title").text();
    },
    doAction_uiControl33_A2TOQ2: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.appMain.backToIndex(); // $(elem).find(".tab-close").click();
      }
    },
    getTemplate_uiControl33_A2TOQ2: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back('','back');\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }                       \n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back('', 'back');\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control44_w7Cr0e: function (elem) {
      if (!elem) {
        return;
      }var data = {};$(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $frame = $(this).find("iframe").contents();var Array = [],
              BtnGroup = [];if ($frame.find("#modifyPwdPage").css("display") != "none") {
            $($frame).find(".wrap").find(".cl-content").find(".form-group").map(function () {
              if (!$(this).hasClass("ng-hide")) {
                var group = {};group = { label: $(this).find(".control-label").text(), ControlType: $(this).find(".form-control").find("input").attr('type'), ControlID: $(this).find(".form-control").find("input").attr('id'), ControlValue: $(this).find(".form-control").find("input").val() }; // if (group.label != '原密码') {
                Array.push(group); // }
              }
            });$frame.find(".wrap").find(".submitwrap").children("span").map(function () {
              BtnGroup.push({ txt: $(this).text().trim(), BtnID: $(this).attr("id") });
            });data = { tit: $($frame).find(".wrap").find(".cl-title").text(), Array: Array, BtnGroup: BtnGroup };
          }
        }
      });return data;
    },
    doAction_uiControl34_FNLEQG: function (data, elem) {
      $(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $frame = $(this).find("iframe").contents();if (data.eventType === "blur") {
            $($frame).find("#" + data.dataCustom.id).val(data.dataCustom.value).focus().blur();data.dataCustom.id == "confirmPwd" ? $($frame).find("#" + data.dataCustom.id).focus().blur() : '';
          } else if (data.eventType === "BtnClick") {
            $($frame).find("#" + data.dataCustom).click();
          }
        }
      });
    },
    getTemplate_uiControl34_FNLEQG: function () {
      var selfTemplate = "const Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){\n      return(\n\t\t\t\t<div style={{display:\"none\"}}></div>      \n      )\n    }\n    return (\n      <div style={{background:\"#fff\"}} className=\"PassWord\">\n        {data.tit?<p className=\"w-tit\">{data.tit}</p>:<p style={{display:\"none\"}}></p>}\n        <div>\n        \t{data.Array && data.Array.length>0 && data.Array.map(function(item,i){\n            return(\n            \t<label class=\"am2-field-single am2-field-underline-part\">\n                <div class=\"am2-field-label\" style={{width:\"5rem\"}}>\n                  <div>{item.label}</div>\n                </div>\n                <div class=\"am2-field-wrap\">\n                  <AInput class=\"am2-field\" type={item.ControlType} id={item.ControlID} value={item.ControlValue} onBlur={function(e){_this.blur(e,item.ControlID)}}></AInput>\n                </div>\n              </label>\n            )\n          })}\n        </div>\n        <div className=\"w-btn am2-g\" style={{position:'static',marginTop:'5rem',paddingBottom:'400px'}}>\n        \t{data.BtnGroup && data.BtnGroup.length && data.BtnGroup.map(function(item,i){\n            return(\n            \t<Button id={item.BtnID} className=\"am2-col\" onClick={function(){_this.BtnClick(item.BtnID)}}>{item.txt}</Button>\n            )\n          })}\n        </div>\n      </div>\n    )\n  },\n  blur:function(e,id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"blur\",\n        data: {\n          id:id,\n          value:e.target.value\n        }\n      });   \n    }\n  },\n  BtnClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"BtnClick\",\n        data: id\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { style: { background: \"#fff\" }, className: \"PassWord\" },\n      data.tit ? React.createElement(\n        \"p\",\n        { className: \"w-tit\" },\n        data.tit\n      ) : React.createElement(\"p\", { style: { display: \"none\" } }),\n      React.createElement(\n        \"div\",\n        null,\n        data.Array && data.Array.length > 0 && data.Array.map(function (item, i) {\n          return React.createElement(\n            \"label\",\n            { \"class\": \"am2-field-single am2-field-underline-part\" },\n            React.createElement(\n              \"div\",\n              { \"class\": \"am2-field-label\", style: { width: \"5rem\" } },\n              React.createElement(\n                \"div\",\n                null,\n                item.label\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { \"class\": \"am2-field-wrap\" },\n              React.createElement(AInput, { \"class\": \"am2-field\", type: item.ControlType, id: item.ControlID, value: item.ControlValue, onBlur: function onBlur(e) {\n                  _this.blur(e, item.ControlID);\n                } })\n            )\n          );\n        })\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"w-btn am2-g\", style: { position: 'static', marginTop: '5rem', paddingBottom: '400px' } },\n        data.BtnGroup && data.BtnGroup.length && data.BtnGroup.map(function (item, i) {\n          return React.createElement(\n            Button,\n            { id: item.BtnID, className: \"am2-col\", onClick: function onClick() {\n                _this.BtnClick(item.BtnID);\n              } },\n            item.txt\n          );\n        })\n      )\n    );\n  },\n  blur: function blur(e, id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"blur\",\n        data: {\n          id: id,\n          value: e.target.value\n        }\n      });\n    }\n  },\n  BtnClick: function BtnClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"BtnClick\",\n        data: id\n      });\n    }\n  }\n});";
    },
    getData_control51_JoLZau: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).children("div").map(function () {
        if ($(this).css("display") != "none") {
          var $iframe = $(this).find("iframe").contents();$($iframe).find(".checkoutFinish").find("label").map(function () {
            data.push({ label: $(this).text() && $(this).text().trim(), num: $(this).next().text() });
          });
        }
      });return data; // <li style={{lineHeight:"40px",textAlign:"center"}}>订单号：{data.reserveOrderId}</li>
      //         <li style={{lineHeight:"40px",textAlign:"center"}}>手机号：{data.cellphoneNumber}</li>
      //         <li><button className="am2-btn am2-btn-xs am2-btn-success" onClick={function(){me.click(data.reserveOrderId,data.cellphoneNumber)}} style={{display:"block",margin:"1rem auto"}}>{data.SESBtn}</button></li>
    },
    doAction_uiControl41_cQEXka: function (data, elem) {// var d = data.dataCustom,
      //     aWin = elem.ownerDocument.defaultView;
      // $(elem).children("div").map(function () {
      //   if ($(this).css("display") != "none") {
      //     var $iframe = $(this).find("iframe").contents();
      //     if (data.eventType === 'click') {
      //       $($iframe).find("#signElectronicACKSlip_btn").click();
      //       var eInvoiceInfo = aWin.$Page.eInvoiceInfo;
      //       var obj = {
      //         orderNumber: d.id,
      //         phoneNums: d.num,
      //         image: ["fs.readFileSync('title.png')"],
      //         positionId: eInvoiceInfo[0].beId,
      //         template: []
      //       };
      //       $.each(eInvoiceInfo, function (i, el) {
      //         var temp = {};
      //         temp.templateName = el.cellFileName;
      //         $.each(el.printCellInfoList, function (j, item) {
      //           temp[item.itemId + ''] = item.protocolContent;
      //         });
      //         obj.template.push(temp);
      //       });
      //       alert(obj);
      //     }
      //   }
      // });
    },
    getTemplate_uiControl41_cQEXka: function () {
      var selfTemplate = "module.exports = React.createClass({\n  click:function(id,num){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:{\n          id:id,\n          num:num\n        },\n        eventType:'click'\n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this;\n    if(!data){\n      return(<span style={{display:\"none\"}}></span>)\n    }\n    return (\n      <ul style={{padding:\"0\"}}>\n        {data.map(function(item,i){\n          return(\n          \t<li className=\"am2-g\"style={{lineHeight:\"40px\"}}>\n            \t<span className=\"am2-col\" style={{textAlign:\"right\"}}>{item.label}</span>\n              <span className=\"am2-col\" style={{textAlign:\"left\"}}>{item.num}</span>\n            </li>\n          )\n        })}\n      </ul>\n    ) \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  click: function click(id, num) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: {\n          id: id,\n          num: num\n        },\n        eventType: 'click'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"span\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"ul\",\n      { style: { padding: \"0\" } },\n      data.map(function (item, i) {\n        return React.createElement(\n          \"li\",\n          { className: \"am2-g\", style: { lineHeight: \"40px\" } },\n          React.createElement(\n            \"span\",\n            { className: \"am2-col\", style: { textAlign: \"right\" } },\n            item.label\n          ),\n          React.createElement(\n            \"span\",\n            { className: \"am2-col\", style: { textAlign: \"left\" } },\n            item.num\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control52_6IyEQt: function (elem) {
      if (!elem) {
        return "";
      }return elem.textContent.trim();
    },
    doAction_uiControl42_UpUZel: function (data, elem) {
      elem.click();setTimeout(function () {
        ysp.appMain.backToIndex();
      }, 200);
    },
    getTemplate_uiControl42_UpUZel: function () {
      var selfTemplate = "const Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  handle:function(data,eventType){\n    var callBack = this.props.customHandler;\n    if(callBack) {                                    \n      callBack({data,eventType})\n    }\n  },\n  render: function() {\n    var _d = this.props.customData;\n    if(!_d){\n      return <div></div>\n    }\n    return (\n      <div>\n        <Button amStyle=\"success\" style={{width:'100%'}}\n          onClick={()=>{\n            this.handle('','close');\n          }}>{_d}</Button>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar Button = AMUI2.Button;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  handle: function handle(data, eventType) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var _this = this;\n\n    var _d = this.props.customData;\n    if (!_d) {\n      return React.createElement('div', null);\n    }\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        Button,\n        { amStyle: 'success', style: { width: '100%' },\n          onClick: function onClick() {\n            _this.handle('', 'close');\n          } },\n        _d\n      )\n    );\n  }\n});";
    }
  });
})(window, ysp);