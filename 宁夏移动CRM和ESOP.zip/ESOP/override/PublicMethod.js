var IE11 = navigator.userAgent.toLowerCase().indexOf("trident") > -1 && navigator.userAgent.indexOf("rv") > -1;
function getTopWindow() {
    var topObj = null ;
    if (window.dialogArguments) {
        var parentWin = window.dialogArguments;
        if (parentWin.dialogArguments) {
            parentWin = parentWin.dialogArguments;
            if (parentWin.length && parentWin.length > 3) {
                parentWin = parentWin[3]
            }
        }
        topObj = parentWin.top
    } else {
        if (window.opener && window.opener.top) {
            topObj = window.opener.top
        } else {
            if (window.parent && window.parent.top) {
                topObj = window.parent.top
            } else {
                if (top) {
                    topObj = top
                }
            }
        }
    }
    return topObj
}
function getContextPath(pathStr) {
    var rtnContextPath = "/" + pathStr;
    var topWin = getTopWindow();
    if (topWin) {
        if (topWin.getCrmWebContext) {
            rtnContextPath = topWin.getCrmWebContext(pathStr)
        }
    }
    return rtnContextPath
}
function toReset(formObj) {
    for (i = 0; i < formObj.length; i++) {
        if (formObj[i].type == "text" || formObj[i].type == "textarea") {
            formObj[i].value = ""
        } else {
            if (formObj[i].type == "select-one" || formObj[i].type == "select") {
                if (formObj[i][0].value == "" || formObj[i][0].value == "0" || formObj[i][0].value == "NULL") {
                    formObj[i][0].selected = true
                } else {
                    formObj[i][formObj[i].length - 1].selected = true
                }
            } else {
                if (formObj[i].type == "checkbox") {
                    formObj[i].checked = false
                }
            }
        }
    }
}
function formToString(form) {
    var buffer = "";
    var elements = form.elements;
    for (var i = 0; i < elements.length; i++) {
        if (elements[i].name != "undefined" && elements[i].type != "button") {
            buffer += "&" + elements[i].name + "=" + elements[i].value
        }
    }
    return buffer
}
function HttpRequestString(url) {
    var requestObject = new ActiveXObject("Microsoft.XMLHTTP");
    requestObject.open("POST", url, false);
    requestObject.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    requestObject.send();
    try {
        return eval(requestObject.responsetext)
    } catch (e) {
        alert("web service �������!");
        return null 
    }
}
function HttpRequestForm(formObj) {
    var url = formToString(form);
    url = formObj.action + "?" + url;
    return HttpRequestString(url)
}
function removeItem(fromSelect, toSelect) {
    if (fromSelect.selectedIndex != -1) {
        for (i = 0; i < fromSelect.options.length; i++) {
            if (fromSelect.options(i).selected) {
                var oOption = document.createElement("OPTION");
                oOption.text = fromSelect.options[i].text;
                oOption.value = fromSelect.options[i].value;
                toSelect.add(oOption)
            }
        }
        for (i = fromSelect.options.length - 1; i >= 0; i--) {
            if (fromSelect.options(i).selected) {
                fromSelect.remove(i)
            }
        }
        fromSelect.blur;
        toSelect.blur
    }
}
function refous(obj) {
    document.all(obj).focus()
}
function removeAllItem(fromSelect, toSelect) {
    for (i = 0; i < fromSelect.options.length; i++) {
        var oOption = document.createElement("OPTION");
        oOption.text = fromSelect.options[i].text;
        oOption.value = fromSelect.options[i].value;
        toSelect.add(oOption)
    }
    for (i = fromSelect.options.length - 1; i >= 0; i--) {
        fromSelect.remove(i)
    }
    fromSelect.blur;
    toSelect.blur
}
function trim(str) {
    while (str.charAt(str.length - 1) == " ") {
        str = str.substring(0, str.length - 1)
    }
    while (str.charAt(0) == " ") {
        str = str.substring(1, str.length)
    }
    return str
}
function isNull(controlName) {
    if (document.all[controlName] == null ) {
        return true
    }
    if (trim(document.all[controlName].value).length == 0) {
        return true
    }
    return false
}
function isEmpty(controlName) {
    if (controlName == null ) {
        return true
    }
    if (trim(controlName.value).length == 0) {
        return true
    }
    return false
}
function boxCheck(controlName) {
    if (document.all[controlName] == null ) {
        return false
    }
    if (document.all[controlName].length != null ) {
        count = document.all[controlName].length;
        if (document.all[controlName][0].type != "checkbox") {
            return false
        }
        while (count-- > 0) {
            if (document.all[controlName][count].checked) {
                return true
            }
        }
    } else {
        if (document.all[controlName].type != "checkbox") {
            return false
        }
        if (document.all[controlName].checked) {
            return true
        }
    }
    return false
}
function boxCheck2(controlName) {
    if (document.all[controlName] == null ) {
        return false
    }
    if (document.all[controlName].length != null ) {
        count = document.all[controlName].length;
        if (document.all[controlName][0].type != "checkbox") {
            return false
        }
        i = 0;
        while (count-- > 0) {
            if (document.all[controlName][count].checked) {
                i++
            }
        }
        if (i == 1) {
            return true
        } else {
            return false
        }
    } else {
        if (document.all[controlName].type != "checkbox") {
            return false
        }
        if (document.all[controlName].checked) {
            return true
        }
    }
    return false
}
function radioCheck(controlName) {
    if (document.all[controlName] == null ) {
        return false
    }
    if (document.all[controlName].length != null ) {
        count = document.all[controlName].length;
        if (document.all[controlName][0].type != "radio") {
            return false
        }
        i = 0;
        while (count-- > 0) {
            if (document.all[controlName][count].checked) {
                i++
            }
        }
        if (i == 1) {
            return true
        } else {
            return false
        }
    } else {
        if (document.all[controlName].type != "radio") {
            return false
        }
        if (document.all[controlName].checked) {
            return true
        }
    }
    return false
}
function validateLength(name, minLength, maxLength) {
    if (trim(document.all[name].value).length < minLength || trim(document.all[name].value).length > maxLength) {
        return false
    }
    return true
}
function validateLength2(name, maxLength) {
    if (pangu_getStrLen(document.getElementById("fileName").getAttribute("name")) > maxLength) {
        return false
    }
    return true
}
function validateDate(controlName) {
    var d = document.all[controlName].value;
    var reg = /^[1-2]\d{3}[-][0-1]\d[-][0-3]\d$/;
    return reg.test(d)
}
function validateDateTime(controlName) {
    var t = document.all[controlName].value;
    var reg = /^[1-2]\d{3}[-][0-1]\d[-][0-3]\d\s[0-2]\d[:][0-5]\d[:][0-5]\d$/;
    return reg.test(t)
}
function validateTime(controlName) {
    var t = document.all[controlName].value;
    var reg = /^[0-2]\d[:][0-5]\d[:][0-5]\d$/;
    return reg.test(t)
}
function validateTime_HM(controlName) {
    var t = document.all[controlName].value;
    var reg = /^[0-2]\d[:][0-5]\d$/;
    return reg.test(t)
}
function validateNumber(controlName) {
    var n = document.all[controlName].value;
    var reg1 = /^\d[.]\d+$/;
    var reg2 = /^\d{1}$/;
    var reg3 = /^[1-9]\d*[.]?\d+$/;
    return ( reg1.test(n) || reg2.test(n) || reg3.test(n)) 
}
function validateInteger(controlName) {
    var n = document.all[controlName].value;
    var reg = /^[0-9]\d*$/;
    return reg.test(n)
}
function isInteger(n) {
    var reg = /^[0-9]\d*$/;
    return reg.test(n)
}
function validateInteger2(value) {
    var reg = /^[1-9]\d*$/;
    return reg.test(value)
}
function validateMoney(controlName) {
    var n = document.all[controlName].value;
    var reg1 = /^\d{1}$/;
    var reg2 = /^\d[.]\d\d?$/;
    var reg3 = /^[1-9]\d*[.]?\d\d?$/;
    return reg1.test(n) || reg2.test(n) || reg3.test(n)
}
function validateChar(controlName) {
    var n = document.all[controlName].value;
    var reg = /^[0-9a-zA-Z]+$/;
    return ( reg.test(n)) 
}
function validatePhone(controlName) {
    var n = document.all[controlName];
    var reg = /^([0,2-9]\d{2,3}[-]?)?[0,2-9]\d{6,7}([-]?\d{1,4})?$/;
    var reg1 = /^13\d{9}$/;
    var reg2 = /^15\d{9}$/;
    var reg3 = /^18\d{9}$/;
    var reg4 = /^147\d{8}$/;
    var reg5 = /^17\d{9}$/;
    if (n.length == undefined) {
        var nu = n.value;
        if (validateConfigServnum(nu)) {
            return true
        }
        return reg.test(nu) || reg1.test(nu) || reg2.test(nu) || reg3.test(nu) || reg4.test(nu) || reg5.test(nu)
    } else {
        for (var i = 0; i < n.length; i++) {
            var nn = n[i].value;
            if (nn != "") {
                if (validateConfigServnum(nn)) {
                    return true
                }
                if (!reg.test(nn) && !reg1.test(nn) && !reg2.test(nn) && !reg3.test(nn) && !reg4.test(nn) && !reg5.test(nn)) {
                    return false
                }
            }
        }
        return true
    }
}
function validatePhone2(controlName) {
    var n = document.all[controlName];
    var reg = /^([0,2-9]\d{2,3}[-]?)?[0,2-9]\d{6,}[-]?\d*$/;
    var reg1 = /^13\d{9}$/;
    var reg2 = /^15\d{9}$/;
    var reg3 = /^18\d{9}$/;
    var reg4 = /^147\d{8}$/;
    var reg5 = /^[0-9]\d{1,}$/;
    var reg6 = /^17\d{9}$/;
    if (n.length == undefined) {
        var nu = n.value;
        if (validateConfigServnum(nu)) {
            return true
        }
        return reg.test(nu) || reg1.test(nu) || reg2.test(nu) || reg3.test(nu) || reg4.test(nu) || reg5.test(nu) || reg6.test(nu)
    } else {
        for (var i = 0; i < n.length; i++) {
            var nn = n[i].value;
            if (nn != "") {
                if (validateConfigServnum(nn)) {
                    return true
                }
                if (!reg.test(nn) && !reg1.test(nn) && !reg2.test(nn) && !reg3.test(nn) && !reg4.test(nn) && !reg5.test(nn) && !reg6.test(nn)) {
                    return false
                }
            }
        }
        return true
    }
}
function validateImmobile(controlName) {
    var n = document.all[controlName].value;
    var reg = /^(\d{4}[-]?)?\d{7,}\d*$/;
    return reg.test(n)
}
function isImmobile(controlName) {
    var reg = /^(\d{3,4}[-]?)?\d{7,}\d*$/;
    return reg.test(controlName)
}
function validateMobile(controlName) {
    var n = document.all[controlName].value;
    var reg = /^13\d{9}$/;
    var reg1 = /^15\d{9}$/;
    var reg2 = /^18\d{9}$/;
    var reg3 = /^147\d{8}$/;
    var reg4 = /^17\d{9}$/;
    if (validateConfigServnum(n)) {
        return true
    }
    return reg.test(n) || reg1.test(n) || reg2.test(n) || reg3.test(n) || reg4.test(n)
}
function validateCMMobile(controlName) {
    var n = document.all[controlName].value;
    var reg = /^13[4-9]\d{8}$/;
    var reg1 = /^15[0189]\d{8}$/;
    return reg.test(n) || reg1.test(n)
}
function validateCUMobile(controlName) {
    var n = document.all[controlName].value;
    var reg = /^(130|131|132|133|153|156)(\d){8}$/;
    return reg.test(n)
}
function validateEmail(controlName) {
    var n = document.all[controlName].value;
    var re1 = /^\w+@\w+(\.\w+)+$/;
    return re1.test(n)
}
function validatePercent(controlName) {
    var n = document.all[controlName].value;
    var re1 = /^\d+(.?\d+)?%$/;
    return re1.test(n)
}
function isPhoneNum(str) {
    var re1 = /^(\d{3,4}-?)?\d{7,8}$/;
    return re1.test(str)
}
function isEmail(str) {
    var re1 = /^\s*[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+\s*$/;
    return re1.test(str)
}
function isInvalid(control) {
    var invalid = ",'\"=|&;\\!<>";
    for (var i = 0; i < control.value.length; i++) {
        if (invalid.indexOf(control.value.charAt(i)) != -1) {
            return true
        }
    }
    return false
}
function inputCheck(s) {
    var invalid = "$\\";
    for (var i = 0; i < s.length; i++) {
        if (invalid.indexOf(s.charAt(i)) != -1) {
            return true
        }
    }
    return false
}
function isIdCardNo(num) {
    var len = num.length, re;
    if (len == 15) {
        re = new RegExp(/^(\d{6})()?(\d{2})(\d{2})(\d{2})(\d{3})$/)
    } else {
        if (len == 18) {
            re = new RegExp(/^(\d{6})()?(\d{4})(\d{2})(\d{2})(\d{3})(\w)$/)
        } else {
            alert("����������֤��λ��Ϊ" + len + "λ�����֤��λ��λ�����ԣ�ӦΪ15λ��18λ��");
            return false
        }
    }
    var a = num.match(re);
    if (a != null ) {
        if (len == 15) {
            var D = new Date("19" + a[3] + "/" + a[4] + "/" + a[5]);
            var B = D.getYear() == a[3] && (D.getMonth() + 1) == a[4] && D.getDate() == a[5]
        } else {
            var D = new Date(a[3] + "/" + a[4] + "/" + a[5]);
            var B = D.getFullYear() == a[3] && (D.getMonth() + 1) == a[4] && D.getDate() == a[5]
        }
        if (!B) {
            alert("��������֤�� " + a[0] + " ��������ڲ��ԣ�");
            return false
        }
    }
    return true
}
function isSelected(control) {
    if (isEmpty(control) || control.value == "0") {
        return false
    }
    return true
}
function enableAll(processID) {
    controls = document.all.namedItem(processID);
    for (i = 0; i < controls.length; i++) {
        if (controls[i].name.indexOf(processID) != -1) {
            document.disabled = false
        }
    }
}
function enableControl(processID, itemID) {
    document.all[processID + "_" + itemID].disabled = false
}
function disableAll(processID) {
    controls = document.all.namedItem(processID);
    for (i = 0; i < controls.length; i++) {
        if (controls[i].name.indexOf(processID) != -1) {
            document.disabled = true
        }
    }
}
function disableControl(processID, itemID) {
    document.all[processID + "_" + itemID].disabled = true
}
function clearAll(processID) {
    controls = document.all.namedItem(processID);
    for (i = 0; i < controls.length; i++) {
        controls[i].value = ""
    }
}
function clearControl(processID, itemID) {
    document.all[processID + "_" + itemID].value = ""
}
function loadSubSelect(id, array, parentValue) {
    subSelect = document.all[id];
    while (subSelect.length > 1) {
        subSelect.remove(1)
    }
    if (parentValue != "0") {
        for (i = 0; i < array.length - 1; i++) {
            if (array[i][0].indexOf(parentValue) == 0) {
                option = document.createElement("option");
                option.value = array[i][0];
                option.text = array[i][1];
                subSelect.add(option)
            }
        }
    }
    subSelect.selectedIndex = 0
}
function judgeRepeat(path) {
    var responseValue = getResponse(path);
    return responseValue
}
function setStaffIsNull(controlName) {
    document.all[controlName].options.length = 0;
    document.all[controlName].add(document.createElement("OPTION"));
    document.all[controlName].options[0].value = "NULL";
    document.all[controlName].options[0].text = "--\u8bf7\u9009\u62e9--"
}
function isAllNumber(num) {
    var reg = /^[1-9]\d*$/;
    return reg.test(num)
}
function isMobileNum(num) {
    if (!isAllNumber(num) || num.length != 11) {
        return false
    }
    return true
}
function isChinaMobileNum(num) {
    if (!isMobileNum(num)) {
        return false
    }
    var prefix = num.substring(0, 3);
    var chinaMobileNums = new Array("134","135","136","137","138","139","150","151","152","157","158","159","188");
    for (i = 0; i < chinaMobileNums.length; i++) {
        if (prefix == chinaMobileNums[i]) {
            return true
        }
    }
    return false
}
function isChinaMobileNumber(num, chinaMobileNum) {
    if (!isMobileNum(num)) {
        return false
    }
    var prefix = num.substring(0, 3);
    prefix = "PS" + prefix;
    var chinaMobileNums = chinaMobileNum.split(",");
    for (i = 0; i < chinaMobileNums.length; i++) {
        if (prefix == chinaMobileNums[i]) {
            return true
        }
    }
    return false
}
function isChinaUnitNum(num) {
    if (!isMobileNum(num)) {
        return false
    }
    var prefix = num.substring(0, 3);
    var chinaUnitNums = new Array("130","131","132","133");
    for (i = 0; i < chinaUnitNums.length; i++) {
        if (prefix == chinaUnitNums[i]) {
            return true
        }
    }
    return false
}
function encodeUrl(url) {
    for (i = 0; i < url.length; i++) {
        url = url.replace("/", "%2F");
        url = url.replace("?", "%3F");
        url = url.replace("&", "%26");
        url = url.replace("=", "%3D");
        url = url.replace(":", "%3A")
    }
    return url
}
function validateChargeLength(ctlName) {
    var ctl = document.all[ctlName].value;
    if (ctl.indexOf(".") != -1) {
        ctl = ctl.substring(0, ctl.indexOf("."))
    }
    if (ctl.length > 8) {
        return false
    }
    return true
}
function pangu_getStrLen(s) {
    var count = 0;
    var lenByte = s.length;
    for (i = 0; i < lenByte; i++) {
        if (s.charCodeAt(i) > 256) {
            count = count + 2
        } else {
            count = count + 1
        }
    }
    return count
}
function chineseDataLength(fData) {
    var intLength = 0;
    for (var i = 0; i < fData.length; i++) {
        var word = fData.substring(i, i + 1);
        if (/[^\x00-\xff]/g.test(word) == true) {
            intLength = intLength + 1
        }
    }
    return intLength
}
function pangu_isnulls(controlName) {
    var contr = document.all.item(controlName);
    if (contr.value == "NULL") {
        return true
    }
    if (contr.multiple == true) {
        var options = contr.options;
        for (var i = 0; i < options.length; i++) {
            if (options[i].selected == true && options[i].value != "NULL") {
                return false
            }
        }
        return true
    }
    return false
}
function showObj(obj) {
    alert(Json.stringify(obj))
}
function closeWin() {
    window.opener.OnFreshWindow();
    window.close()
}
function validateField(fieldLabel, fieldName, maxLength, numFlag) {
    if (isNull(fieldName)) {
        alert(fieldLabel + "����Ϊ�գ�");
        refous(fieldName);
        return false
    }
    if (numFlag == "1") {
        if (document.all[fieldName].value.length > maxLength) {
            alert(fieldLabel + "�������ݲ��ܳ���" + maxLength + "λ��");
            refous(fieldName);
            return false
        }
    } else {
        if (!validateLength2(fieldName, maxLength)) {
            alert(fieldLabel + "�������ݲ��ܳ���" + maxLength + "���ֽڣ�");
            refous(fieldName);
            return false
        }
    }
    return true
}
function validateField2(fieldLabel, fieldName, maxLength) {
    if (!validateLength2(fieldName, maxLength)) {
        alert(fieldLabel + "�������ݲ��ܳ���" + maxLength + "���ֽڣ�");
        refous(fieldName);
        return false
    }
    return true
}
function compareDateTime(startTime, endTime, simple) {
    var startDate = startTime.split("-");
    var sYear = parseInt(startDate[0], 10);
    var sMonth = parseInt(startDate[1], 10);
    var sDay = parseInt(startDate[2], 10);
    var endDate = endTime.split("-");
    var eYear = parseInt(endDate[0], 10);
    var eMonth = parseInt(endDate[1], 10);
    var eDay = parseInt(endDate[2], 10);
    if ("1" == simple) {
        if (sYear > eYear) {
            return false
        } else {
            if ((sYear == eYear) && (sMonth > eMonth)) {
                return false
            } else {
                if ((sYear == eYear) && (sMonth == eMonth) && (sDay > eDay)) {
                    return false
                }
            }
        }
    } else {
        if ("2" == simple) {
            if (sYear < eYear) {
                return false
            } else {
                if ((sYear == eYear) && (sMonth < eMonth)) {
                    return false
                } else {
                    if ((sYear == eYear) && (sMonth == eMonth) && (sDay <= eDay)) {
                        return false
                    }
                }
            }
        }
    }
    return true
}
function deleteRows(controlName, tableName, rownum) {
    if (document.all[controlName] == null ) {
        return false
    }
    if (document.all[controlName].length != null ) {
        count = document.all[controlName].length;
        flag = count;
        for (var i = count - 1; i >= 0; i--) {
            if (document.all[controlName][i].checked) {
                document.all[tableName].deleteRow(i + rownum);
                flag--
            }
        }
        if (flag < count) {
            return true
        }
    } else {
        if (document.all[controlName].checked) {
            document.all[tableName].deleteRow(rownum);
            return true
        }
    }
    return false
}
function dyniframesize(iframename) {
    var pTar = null ;
    if (document.getElementById) {
        pTar = document.getElementById(iframename)
    } else {
        eval("pTar = " + iframename + ";")
    }
    if (pTar && !window.opera) {
        pTar.style.display = "block";
        if (IE11) {
            var frame = document.getElementById(iframename);
            var children = frame.contentWindow.document.body ? frame.contentWindow.document.body.children : [];
            var height = 0;
            for (var i = 0; i < children.length; i++) {
                if (children[i].nodeName != "script" && children[i].nodeName != "SCRIPT") {
                    height += children[i].scrollHeight
                }
            }
            frame.height = height
        } else {
            if (pTar.Document && pTar.Document.body.scrollHeight) {
                pTar.height = pTar.Document.body.scrollHeight
            }
        }
    }
}
function openSuitWin(url, title, scale_w, scale_h, resizeFlag) {
    if (undefined != url && url.indexOf("?") > 0) {
        url = url + "&ngcrm_reserved1=1"
    } else {
        url = url + "?ngcrm_reserved1=1"
    }
    var width = window.screen.width * scale_w;
    var height = window.screen.height * scale_h;
    var topheight = (window.screen.height - height) / 2;
    var topleft = (window.screen.width - width) / 2;
    var feature = "toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, status=no,left=" + topleft + ",top=" + topheight + ",width=" + width + ",height=" + height;
    if (resizeFlag == 0) {
        feature = "toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, status=no,left=" + topleft + ",top=" + topheight + ",width=" + width + ",height=" + height
    }
    _ysp_top.win = window.open(url, title, feature)
}
function openWinsSuitWin(url, title, scale_w, scale_h, resizeFlag) {
    if (undefined != url && url.indexOf("?") > 0) {
        url = url + "&ngcrm_reserved1=1"
    } else {
        url = url + "?ngcrm_reserved1=1"
    }
    var width = this.screen.width * scale_w;
    var height = this.screen.height * scale_h;
    var topheight = (this.screen.height - height) / 2;
    var topleft = (this.screen.width - width) / 2;
    var feature = "toolbar=no, menubar=no, scrollbars=yes, resizable=yes, location=no, status=no,left=" + topleft + ",top=" + topheight + ",width=" + width + ",height=" + height;
    if (resizeFlag == 0) {
        feature = "toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, status=no,left=" + topleft + ",top=" + topheight + ",width=" + width + ",height=" + height
    }
    _ysp_top.win = this.open(url, title, feature)
}
function openSuitDialog(url, title, scale_w, scale_h, resizeFlag) {
    if (undefined != url && url.indexOf("?") > 0) {
        url = url + "&ngcrm_reserved1=1"
    } else {
        url = url + "?ngcrm_reserved1=1"
    }
    var width = window.screen.width * scale_w;
    var height = window.screen.height * scale_h;
    var feature = "dialogHeight:'" + height + "px';dialogWidth:'" + width + "px';status:'no';help:no;resizable:yes";
    if (resizeFlag == 0) {
        feature = "dialogHeight:'" + height + "px';dialogWidth:'" + width + "px';status:'no';help:no;"
    }
    return window.showModalDialog(url, window, feature)
}
function validateCUMobile(mobile, url) {
    if (mobile.length == 0) {
        return true
    }
    if (mobile.length != 11) {
        alert("�ֻ����볤�Ȳ���11λ��");
        return false
    }
    var reg = /^(\d){11}$/;
    var a = reg.test(mobile);
    if (reg.test(mobile) == true) {
        if (execService(url, "") == "true") {
            return true
        } else {
            alert("�ֻ����벻���ƶ����룡");
            return false
        }
    } else {
        alert("�ֻ����������������");
        return false
    }
}
function validateCUMobileNum(mobile, url) {
    if (mobile.length == 0) {
        return true
    }
    if (mobile.length != 11) {
        return false
    }
    var reg = /^(\d){11}$/;
    var a = reg.test(mobile);
    if (reg.test(mobile) == true) {
        if (execService(url, "") == "true") {
            return true
        } else {
            return false
        }
    } else {
        return false
    }
}
function validateConfigServnum(servNumber) {
    try {
        var flag = execService(getContextPath("ngmarket") + "/crm/validateAllServnum.action?servNumber=" + servNumber);
        if ("true" == flag) {
            return true
        }
    } catch (e) {}
    return false
}
function validateMobileNo(MobileNo) {
    if (validateConfigServnum(MobileNo)) {
        return true
    }
    var n = trim(MobileNo);
    var reg = /^13\d{9}$/;
    var reg1 = /^15\d{9}$/;
    var reg2 = /^18\d{9}$/;
    var reg3 = /^14\d{9}$/;
    var reg4 = /^17\d{9}$/;
    var reg5 = /^[2-9]\d{1,2}\d{7,8}$/;
    var reg6 = /^(0\d{2,3}[-]?)?\d{7,8}$/;
    return reg.test(n) || reg1.test(n) || reg2.test(n) || reg3.test(n) || reg4.test(n) || reg5.test(n) || reg6.test(n)
}
function ValidateZip(str) {
    var reg = /^\d{6}$/g;
    if (reg.test(str)) {
        return true
    }
    return false
}
Date.prototype.format = function(format) {
    var o = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "H+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S": this.getMilliseconds()
    };
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length))
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length))
        }
    }
    return format
}
;
function viewTrack(path, orderid, oid, supportid, region, step) {
    var param = "orderid=" + orderid;
    if (arguments.length > 2) {
        if (undefined != oid && "" != oid) {
            param = param + "&oid=" + oid
        }
        if (undefined != supportid && "" != supportid) {
            param = param + "&supportid=" + supportid
        }
        if (undefined != region && "null" != region) {
            param = param + "&region=" + region
        }
        if (undefined != step && "" != step) {
            param = param + "&step=" + step
        }
    }
    var url = path + "/salemgt/common/queryTrack.action?" + param;
    openSuitWin(url, "", 2 / 3, 2 / 3, 1)
}
function confirmFullNumber(contextPath, number, input) {
    var fullNumber = execService(contextPath + "/crm/getFullNumber.action?servNumber=" + number);
    if (number != fullNumber && null  != fullNumber && "" != fullNumber) {
        if (confirm("������ĺ��벹ȫ����:" + fullNumber + "��ȷ���Ƿ���ȷ.")) {
            document.getElementById(input).value = fullNumber;
            return true
        } else {
            return false
        }
    }
    return true
}
function loadFormField(contextPath, modul, tabelid, column) {
    if (arguments.length < 3) {
        alert(" ��������ȷ�����֤�� ");
        return
    }
    var colsCount = 3;
    if (arguments.length == 4) {
        colsCount = column
    }
    var url = contextPath + "/crm/dynFormField.action?date=" + new Date();
    var param = "modul=" + modul + "&tableid=" + tabelid + "&cols=" + colsCount;
    var html = execService(url, param);
    if (html.charAt(0) == "1") {
        html = html.substr(1)
    }
    var trs = html.split("@_@");
    var table = document.getElementById(tabelid);
    var className = "";
    for (var i = 0; i < trs.length; i++) {
        var tds = trs[i].split("_@_");
        var cols = tds.length;
        var targetObj = table.rows(table.rows.length - 1);
        table.insertRow(table.rows.length);
        for (var j = 0; j < cols; j++) {
            if (j % 2 != 0) {
                className = "td_input_width"
            } else {
                className = "td_text_width"
            }
            var tr = table.rows(table.rows.length - 1);
            tr.insertCell(j);
            tr.cells(j).setAttribute("class", className);
            if (cols != colsCount * 2 && j == cols - 1) {
                tr.cells(j).setAttribute("colspan", colsCount * 2 + 1 - cols)
            }
            tr.cells(j).innerHTML = tds[j]
        }
    }
}
function openSuitWinSingle(url, title, scale_w, scale_h) {
    if (undefined != url && url.indexOf("?") > 0) {
        url = url + "&ngcrm_reserved1=1"
    } else {
        url = url + "?ngcrm_reserved1=1"
    }
    var width = window.screen.width * scale_w;
    var height = window.screen.height * scale_h;
    var topheight = (window.screen.height - height) / 2;
    var topleft = (window.screen.width - width) / 2;
    var feature = "toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, status=no,left=" + topleft + ",top=" + topheight + ",width=" + width + ",height=" + height;
    if (title != "") {
        window.open(url, title, feature).focus()
    } else {
        window.open(url, "��ϸ��Ϣҳ��", feature).focus()
    }
}
function openSuitWinBlank(url, title, scale_w, scale_h, bstartdate, estartdate, benddate, eenddate) {
    if (undefined != url && url.indexOf("?") > 0) {
        url = url + "&ngcrm_reserved1=1"
    } else {
        url = url + "?ngcrm_reserved1=1"
    }
    var width = window.screen.width * scale_w;
    var height = window.screen.height * scale_h;
    var topheight = (window.screen.height - height) / 2;
    var topleft = (window.screen.width - width) / 2;
    var feature = "toolbar=no, menubar=no, scrollbars=yes, resizable=no, location=no, status=no,left=" + topleft + ",top=" + topheight + ",width=" + width + ",height=" + height;
    var startdate = bstartdate + " " + estartdate;
    var enddate = benddate + " " + eenddate;
    url = url.replace("startdate", startdate).replace("enddate", enddate);
    _ysp_top.win = window.open(url, title, feature)
}
cityArray = new Array();
cityArray[0] = new Array("100","����");
cityArray[1] = new Array("200","÷��|��ɽ|��Դ|����|��β|��ͷ|�ع�|����|ï��|����|����|��Զ|�Ƹ�|��|�麣|տ��|��ɽ|��ݸ|����|����|����");
cityArray[2] = new Array("210","�Ϻ�");
cityArray[3] = new Array("220","���");
cityArray[4] = new Array("230","����");
cityArray[5] = new Array("240","��ɽ|����|����|Ӫ��|����|����|����|����|����|�̽�|��˳|����|��Ϫ|��«��");
cityArray[6] = new Array("250","�Ͼ�|��|����|��ͨ|����|�γ�|����|���Ƹ�|����|����|��Ǩ|̩��|����");
cityArray[7] = new Array("270","����|ʮ��|����|��ʩ|��ʯ|����|�人|�差|����|Т��|�Ƹ�|����|����|�˲�");
cityArray[8] = new Array("290","ͭ��|����|μ��|����|�Ӱ�|����|����|����|����|����");
cityArray[9] = new Array("311","�ȷ�|�żҿ�|����|����|�ػʵ�|ʯ��ׯ|��ɽ|�е�|����|��ˮ|��̨");
cityArray[10] = new Array("351","����|�ٷ�|����|̫ԭ|˷��|�˳�|����|����|��Ȫ|��ͬ|����");
cityArray[11] = new Array("371","���|����|����Ͽ|����|����|ƽ��ɽ|����|�ױ�|���|פ���|����|����|���|֣��|����|����|�ܿ�");
cityArray[12] = new Array("431","��Դ|����|÷�ӿ�|��ԭ|��ƽ|����|��ɽ|ͨ��|�Ӽ�|�׳�|����");
cityArray[13] = new Array("451","�׸�|����|˫Ѽɽ|�ں�|�������|������|��ľ˹|���˰���|����|�绯|��̨��|����|ĵ����");
cityArray[14] = new Array("471","����������|���ֺ���|��ʤ|����|��ͺ���|�ں�|������|��ͷ|ͨ��|�ٺ�|��������|���");
cityArray[15] = new Array("531","�Ͳ�|̩��|����|����|��Ӫ|����|�ൺ|����|��̨|Ϋ��|����|����|����|��ׯ|����|�ĳ�|����");
cityArray[16] = new Array("551","ͭ��|����|�Ϸ�|����|����|����|��ɽ|����|����|���|����|�ߺ�|����|����|��ɽ|����");
cityArray[17] = new Array("571","̨��|����|����|����|����|��ˮ|����|��|����|��ɽ|����");
cityArray[18] = new Array("591","����|����|��ƽ|����|����|����|����|Ȫ��|����");
cityArray[19] = new Array("731","����|�żҽ�|��ɳ|��̶|����|����|¦��|����|����|����|����|����|����|����");
cityArray[20] = new Array("771","���Ǹ�|�ӳ�|��ɫ|����|����|����|����|����|����|����");
cityArray[21] = new Array("791","�˴�|�ϲ�|������|Ƽ��|����|����|����|����|�Ž�|ӥ̶|����");
cityArray[22] = new Array("851","����|����|����|����ˮ|�Ͻ�|ͭ��|����|����|��˳");
cityArray[23] = new Array("871","����|��Ϫ|º��|����|����|��ɽ(ŭ��)|˼é|�е�|��ͨ|�ٲ�|����|����|��ɽ|����|����|����|����");
cityArray[24] = new Array("891","��|����|����|ɽ��|��¡|����|����|����|����|�Ｊ|����|����|������|����|��ľ|����|����|����|����|��֥|����|����|��ˮ|��ľ|���|â��|�߰�|����|�տ���|����|����|��¡����|����|£��|�˿���|ī��|�ʲ�|˫��|����|�ξ�|����|����|����");
cityArray[25] = new Array("898","����");
cityArray[26] = new Array("931","����|����|��Ҵ|����|���|����|�䶼|����|��Ȫ|��ˮ|ƽ��|����");
cityArray[27] = new Array("951","ʯ��ɽ|����|����|��ԭ|����");
cityArray[28] = new Array("971","���|����|����|����|����|��Դ|���ľ|����|���|���Ͽ|����|�ζ�|����Ͽ|ͬ��|�����|����|ͬ��|����|�ƶ�|����|����|���|����|�ʵ�|��ǫ|�Ӷ�|ã��|���|���|����|�����|����|����");
cityArray[29] = new Array("991","��³��|������|����|��³ľ��|����|����|����|����|��ͼʲ|����|����̩|��������|ʯ����|�����|��ʲ|����");
cityArray[30] = new Array("280","�˱�|����|����|�ɶ�|����|��ɽ|����|����|�Ű�|����|��֦��|�ϳ�|�ﴨ|�ڽ�|����|�Թ�|�㰲|��ɽ|��Ԫ");
function getCity(currProvince, city) {
    var i, j;
    document.getElementById(city).length = 0;
    for (i = 0; i < cityArray.length; i++) {
        if (cityArray[i][0] == currProvince.options[currProvince.selectedIndex].value) {
            tmpcityArray = cityArray[i][1].split("|");
            for (j = 0; j < tmpcityArray.length; j++) {
                document.getElementById(city).options[j] = new Option(tmpcityArray[j],tmpcityArray[j])
            }
        }
    }
}
function getDetail(source, destination) {
    document.getElementById(destination).value = source.value
}
function jsonDecode(data) {
    return (new Function("return " + data + ";"))()
}
function disabedAllBut(arg, tagname, typevalue, flag) {
    var elements;
    var typeFlag = false;
    if (tagname == undefined || tagname == "") {
        tagname = "INPUT"
    }
    if (typevalue == undefined || typevalue == "") {
        typeFlag = true
    }
    if (flag == undefined) {
        flag = true
    }
    if (arg == undefined || arg == "") {
        elements = document.getElementsByTagName(tagname)
    } else {
        elements = arg.getElementsByTagName(tagname)
    }
    for (var i = 0; i < elements.length; i++) {
        if (typeFlag || elements[i].type == typevalue.toLowerCase()) {
            elements[i].disabled = flag
        }
    }
}
function checkSpecialCharacter(inputvalue, inputname) {
    var str = inputvalue.value;
    var SPECIAL_STR = "&<>\\";
    for (i = 0; i < str.length; i++) {
        if (SPECIAL_STR.indexOf(str.charAt(i)) != -1) {
            alert("��" + inputname + "���в�������д�Ƿ��ַ�(" + str.charAt(i) + ")��");
            try {
                inputvalue.focus()
            } catch (e) {}
            return false
        }
    }
    return true
}
function toUniformView(groupId, custId, region) {
    var url = getContextPath("ngesop") + "/uniformViewIndex.action?custId=" + custId + "&groupId=" + groupId + "&region=" + region;
    var title = "���ſͻ�ͳһ��ͼ";
    var menuId = "esop_uniformView";
    try {
        var oTab = _ysp_top.publicObject["mainTab"];
        if (oTab.hasTab(menuId)) {
            if (confirmVB("���ſͻ�ͳһ��ͼTabҳ�Ѵ򿪣��Ƿ�ˢ��?")) {
                oTab.removeTabByCode(menuId)
            }
        }
    } catch (e) {
        openSuitWinSingle(url, title, 3 / 4, 2 / 3);
        return
    }
    var openMenu = _ysp_top.publicObject["openMenu"];
    openMenu(menuId, title, url)
}
function initExportProcess(exportButton, servNum, recType, groupId, secChkFlag) {
    if (document.all[exportButton]) {
        document.all[exportButton].onclick = function() {
            var servNo = "";
            if (servNum != "") {
                try {
                    servNo = document.all[servNum].value
                } catch (e) {}
            }
            var groupNo = "";
            if (groupId != "") {
                try {
                    groupNo = document.all[groupId].value
                } catch (e) {}
            }
            if (!authCheck(servNo, recType, groupNo)) {
                return
            }
            if (secChkFlag == "true") {
                var goldAuthSN = "";
                var goldAuthToken = "";
                if (document.getElementById("goldAuthSN") && document.getElementById("goldAuthToken")) {
                    goldAuthSN = document.getElementById("goldAuthSN").value;
                    goldAuthToken = document.getElementById("goldAuthToken").value
                }
                var funcArr = exportFromTable_exportButton.toString().split(".action?");
                var func = funcArr[0] + ".action?goldAuthSN=" + goldAuthSN + "&goldAuthToken=" + goldAuthToken + "&" + funcArr[1];
                var temp = func.split("exportFromTable_exportButton(){")[1];
                var funcBody = temp.substring(0, temp.length - 1);
                eval(funcBody)
            } else {
                eval("exportFromTable_" + exportButton + "()")
            }
        }
    }
}
function isHaveRight(rightId, contextPath) {
    var url = contextPath + "/crm/applyparam/isHaveRight.action?rightId=" + rightId;
    var isHaveRightret = execService(url, "");
    return isHaveRightret
}
function radioGetChcedValue(controlName) {
    var radios = document.getElementsByName(controlName);
    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            return radios[i].value
        }
    }
    return "noChoose"
}
function validFuncs() {
    this.funcs = new Array()
}
validFuncs.prototype = {
    clear: function() {
        this.funcs.length = 0
    },
    length: function(obj) {
        return this.funcs.length
    },
    push: function(_funcId, _func) {
        if (typeof (_func) == "function") {
            var _f = new Object();
            _f.id = _funcId;
            _f.content = _func;
            this.funcs.push(_f)
        }
    },
    remove: function(_funcId) {
        for (var i = 0; i < this.length(); i++) {
            if (this.funcs[i].id == _funcId) {
                return this.funcs.splice(i, 1)
            }
        }
    },
    get: function(index) {
        if (index < this.length()) {
            return this.funcs[index].content
        }
        return null 
    },
    gain: function(_funcId) {
        for (var i = 0; i < this.length(); i++) {
            if (this.funcs[i].id == _funcId) {
                return this.get(i)
            }
        }
        return null 
    },
    valid: function() {
        for (var i = 0; i < this.length(); i++) {
            if (false === this.get(i)()) {
                return false
            }
        }
        return true
    }
};
function showBank(operCode, contextPath, objName, isExistForm) {
    var resultValue = execService(contextPath + "/crm/cofferSceneManageAction.action?appSceneConfigVO.operCode=" + operCode, "");
    var resultArray = resultValue.split("@_@");
    if (resultArray.length > 1) {
        var iWidth = 700;
        var iHeight = 450;
        var iTop = (window.screen.height - iHeight - 100) / 2;
        var iLeft = (window.screen.width - iWidth) / 2;
        var obj = new Object();
        obj.appCode = resultArray[0];
        obj.operContent = resultArray[1];
        obj.sessionId = resultArray[2];
        obj.serverIp = resultArray[3];
        obj.serverPort = resultArray[4];
        obj.subLoginName = resultArray[5];
        obj.operCode = resultArray[6];
        obj.loginName = resultArray[7];
        obj.mainLoginName = "";
        obj.svcNum = "";
        var returnValue = window.showModalDialog(contextPath + "/crm/to4AApprovePage.action", obj, "dialogHeight:" + iHeight + "px;dialogWidth:" + iWidth + "px;toolbar:no;menubar:no;titlebar:no;scrollbars:yes;resizable:no;location:no;status:no;left:" + iLeft + "px;top:" + iTop + "px;").split("#");
        if (isExistForm) {
            if ((document.forms[0].action).indexOf("?") == -1) {
                document.forms[0].action += "?"
            } else {
                document.forms[0].action += "&"
            }
            document.forms[0].action += objName + ".bankFlag=" + returnValue[0] + "&" + objName + ".bankApprove=" + operCode + "@_@" + returnValue[1]
        }
        if (returnValue[0] != 1 && returnValue[0] != 2 && returnValue[0] != 5 && returnValue[0] != -3 && returnValue[0] != -2) {
            alert("���ģʽ��֤��ͨ����������ҵ��������ʣ�");
            return false
        }
    }
    return true
}
function isNullValue(validataV) {
    if ("null" == validataV || "NULL" == validataV || "" == validataV || "undefined" == validataV || null  == validataV) {
        return true
    } else {
        return false
    }
}
function openTabMenu(itemId, itemName, itemUrl) {
    try {
        var oTab = _ysp_top.publicObject["mainTab"];
        if (oTab.hasTab(itemId)) {
            if (confirmVB(itemName + "Tabҳ�Ѵ򿪣��Ƿ�ˢ��?")) {
                oTab.removeTabByCode(itemId)
            }
        }
        var openMenu = _ysp_top.publicObject["openMenu"];
        openMenu(itemId, itemName, itemUrl)
    } catch (e) {
        alert(e.message)
    }
}
function checkAllBox(boxName, isChecked) {
    if (boxName) {
        var cbArr = document.getElementsByName(boxName);
        var len = cbArr.length;
        for (var i = 0; i < len; i++) {
            cbArr[i].checked = isChecked
        }
    }
}
function exportGoldAuthCheck(exportButton, servNum, recType, groupId) {
    var servNo = "";
    if (servNum != "") {
        try {
            servNo = document.all[servNum].value
        } catch (e) {}
    }
    var groupNo = "";
    if (groupId != "") {
        try {
            groupNo = document.all[groupId].value
        } catch (e) {}
    }
    var goldAuthData = goldAuthCheck(servNo, recType, groupNo);
    if (goldAuthData.authChkResult) {
        var goldRecOid = goldAuthData.goldOid;
        crmSessionProxyHandler.setSessionP("tab", "goldRecOid", goldRecOid, function() {})
    } else {
        return false
    }
}
function exportButtonGoldAuthCheck(exportButton, servNum, recType, groupId) {
    if (document.all[exportButton]) {
        document.all[exportButton].onclick = function() {
            var servNo = "";
            if (servNum != "") {
                try {
                    servNo = document.all[servNum].value
                } catch (e) {}
            }
            var groupNo = "";
            if (groupId != "") {
                try {
                    groupNo = document.all[groupId].value
                } catch (e) {}
            }
            var goldAuthData = goldAuthCheck(servNo, recType, groupNo);
            if (goldAuthData.authChkResult) {
                var goldRecOid = goldAuthData.goldOid;
                crmSessionProxyHandler.setSessionP("tab", "goldRecOid", goldRecOid, function() {})
            } else {
                return false
            }
            try {
                eval("exportFromTable_" + exportButton + "()")
            } catch (e) {}
        }
    }
}
function newGoldAuthCheck(exportButton, servNum, recType, groupId, recDefId, notes, contextPath) {
    if (document.all[exportButton]) {
        document.all[exportButton].onclick = function() {
            var servNo = "";
            if (servNum != "") {
                try {
                    servNo = document.all[servNum].value
                } catch (e) {}
            }
            var groupNo = "";
            if (groupId != "") {
                try {
                    groupNo = document.all[groupId].value
                } catch (e) {}
            }
            var goldAuthData = goldAuthCheck(servNo, recType, groupNo);
            if (goldAuthData.authChkResult) {
                var goldRecOid = goldAuthData.goldOid;
                jQuery.ajax({
                    type: "POST",
                    url: contextPath + "/crm/crmWriteReception.action",
                    data: encodeURI(encodeURI("tcmReceptionVO.entityType=" + recType + "&tcmReceptionVO.recDefId=" + recDefId + "&tcmReceptionVO.goldRecOid=" + goldRecOid + "&tcmReceptionVO.notes=" + notes))
                })
            } else {
                return false
            }
            try {
                eval("exportFromTable_" + exportButton + "()")
            } catch (e) {}
        }
    }
}
function repeatExec(func, interval) {
    var inFunc;
    if (!interval) {
        interval = 3000
    }
    var ti;
    if (typeof func == "string") {
        inFunc = function() {
            if (eval(func)) {
                window.clearInterval(ti)
            }
        }
    } else {
        if (typeof func == "function") {
            inFunc = function() {
                if (func()) {
                    window.clearInterval(ti)
                }
            }
        } else {
            inFunc = function() {}
        }
    }
    ti = window.setInterval(inFunc, interval)
}
function showIframeHiddenColumn(id, contextPath, iFrameId) {
    var iframeDocument = document.getElementById(iFrameId).contentWindow.document;
    var iconObj = document.getElementById("columnIcon" + id);
    var divObj = iframeDocument.getElementById("columnDiv" + id);
    if (divObj.style.display == "none") {
        iconObj.src = contextPath + "/skins/iCRM/images/title_arrow_top.gif";
        divObj.style.display = "block"
    } else {
        iconObj.src = contextPath + "/skins/iCRM/images/title_arrow_down.gif";
        divObj.style.display = "none"
    }
}
function encodeURIComponent4MenuJump(encodeStr) {
    if ("" != encodeStr) {
        if (encodeStr.toLowerCase().indexOf("menujump") >= 0) {
            var idx = encodeStr.indexOf("=");
            var tIdx = "";
            var eIdx = "";
            if (idx > 0) {
                tIdx = encodeStr.substring(0, idx + 1);
                eIdx = encodeStr.substring(idx + 1, encodeStr.length);
                encodeStr = tIdx + encodeURIComponent(eIdx)
            }
        }
    }
    return encodeStr
}
function publicShowFullName(value) {
    var width = 250;
    var height = 100;
    var topheight = (window.screen.height - height) / 2;
    var topleft = (window.screen.width - width) / 2;
    var sFeatures = "dialogWidth: " + width + "px;dialogHeight: " + height + "px; dialogTop:" + topheight + "; dialogLeft: " + topleft + ";status:no; help:no;";
    var url = getContextPath("ngmarket") + "/crm/verifyCoderPage.action";
    var returnMessage = showWindow(url, "", sFeatures);
    if ("failure" == returnMessage) {
        alert("У������������")
    }
    if ("success" == returnMessage) {
        try {
            var wurl = getContextPath("ngmarket") + "/crm/verifyWrtiteBusiness.action?key=" + value;
            execService(wurl, "")
        } catch (e) {}
        window.location = window.location.href
    }
};