

<meta http-equiv="Content-Type" content="text/html; charset=GBK">

<SCRIPT LANGUAGE="JavaScript">
<!--

    alert("��½��ʱ�������µ�½");
    // SessionTimeout
    


function getCookie(name)       
{
    var arr = document.cookie.match(new RegExp("(^| )"+name+"=([^;]*)(;|$)"));
    if(arr != null) 
    {
        return unescape(arr[2]);
    } 
    
    return null;
}

function isBesInner()
{
    var bes_portal_id = getCookie('bes_portal_id');
    return (null != bes_portal_id);
}



function obtainTopWindowByWin(winObj)
{
    try
    {
        if (winObj.dialogArguments && !winObj.dialogArguments.closed && winObj.dialogArguments.top && !winObj.dialogArguments._ysp_top.closed)
        {
            return obtainTopWindowByWin(winObj.dialogArguments.top);
        }
        else if (winObj.opener && !winObj.opener.closed && winObj.opener.top && !winObj.opener._ysp_top.closed)
        {
            return obtainTopWindowByWin(winObj.opener.top);
        }
    }
    catch (e)
    {
    }
    return winObj;
}

if(!isBesInner())
{
    
    
    
    var topWin = obtainTopWindowByWin(window.top);
    var success = topWin.systemInvaildLogout();
    if (success)
    {
        // modify begin by ������ gKF52347 OR_huawei_201307_553 ICRM��ϸ���--ҵ��ʱ��ת 
        var ngcrmContextPath = "";
        try
        {
        ngcrmContextPath = topWin.publicObject["ngcrmContextPath"];
        }
        catch(e)
        {
        }
        
        window.close();
        if(undefined != ngcrmContextPath && "" != ngcrmContextPath)
        {
            topWin.document.location = ngcrmContextPath + "/bsf/index.action";
        }
        else
        {
            topWin.document.location = "/ngcrm/bsf/index.action";
        }
        // modify end by ������ gKF52347 OR_huawei_201307_553 ICRM��ϸ���--ҵ��ʱ��ת 
    }
    
}
//-->
</SCRIPT>