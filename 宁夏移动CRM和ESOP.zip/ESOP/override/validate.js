String.prototype.trim = function() {
	return this.replace(/^\s\s*/, "").replace(/\s\s*$/, "")
};
String.prototype.ltrim = function() {
	return this.replace(/^\s\s*/, "")
};
String.prototype.rtrim = function() {
	return this.replace(/\s\s*$/, "")
};
var Validator = function(b, a) {
	setMaxDigits(512);
	Validator.prototype.key = new RSAKeyPair(b, "", a)
};
Validator.prototype.generateKey = function(b, c) {
	var d = this.getDiskSerial() + ";" + this.getCPUSerial() + ";" + this.getIPMAC();
	var a = encryptedString(this.key, encodeURIComponent(d));
	return a
};
// var locator = new ActiveXObject("WbemScripting.SWbemLocator");
// var service = locator.ConnectServer(".");
// Validator.prototype.getDiskSerial = function() {
// 	var a = service.ExecQuery("SELECT SerialNumber FROM Win32_PhysicalMedia");
// 	var d = new Enumerator(a);
// 	var b = "";
// 	for(; !d.atEnd(); d.moveNext()) {
// 		var c = d.item();
// 		b = c.SerialNumber;
// 		break
// 	}
// 	if(b == null) {
// 		b = ""
// 	} else {
// 		b = b.trim()
// 	}
// 	d = null;
// 	a = null;
// 	return b
// };
// Validator.prototype.getIPMAC = function() {
// 	var b = service.ExecQuery("SELECT MACAddress FROM Win32_NetworkAdapter WHERE ((MACAddress Is Not NULL) AND (Manufacturer <> 'Microsoft')) AND (NetConnectionStatus=2 OR NetConnectionStatus=9)");
// 	var f = new Enumerator(b);
// 	var c = "";
// 	var h = "";
// 	for(; !f.atEnd(); f.moveNext()) {
// 		var d = f.item();
// 		h = "" + d.MACAddress;
// 		break
// 	}
// 	if(h == null) {
// 		c = "";
// 		g = ""
// 	} else {
// 		if(h != "") {
// 			b = service.ExecQuery("SELECT IPAddress,MACAddress FROM Win32_NetworkAdapterConfiguration");
// 			f = new Enumerator(b);
// 			for(; !f.atEnd(); f.moveNext()) {
// 				var d = f.item();
// 				var g = "" + d.IPAddress(0);
// 				var a = "" + d.MACAddress;
// 				if(g != "" && g != "0.0.0.0" && a == h) {
// 					c = g;
// 					break
// 				}
// 			}
// 			c = h.replace(/:/g, "-") + ";" + c
// 		}
// 	}
// 	if(c.indexOf(";") <= 0) {
// 		c = c + ";"
// 	}
// 	f = null;
// 	b = null;
// 	return c
// };
// Validator.prototype.getCPUSerial = function() {
// 	var a = service.ExecQuery("SELECT ProcessorId FROM Win32_Processor");
// 	var d = new Enumerator(a);
// 	var b = "";
// 	for(; !d.atEnd(); d.moveNext()) {
// 		var c = d.item();
// 		b = c.ProcessorId;
// 		break
// 	}
// 	if(null == b) {
// 		b = ""
// 	}
// 	d = null;
// 	a = null;
// 	return b
// };