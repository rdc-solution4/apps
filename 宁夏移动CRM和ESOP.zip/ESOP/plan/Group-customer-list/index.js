(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control53_94DePn: function (elem) {
      return "集团客户列表";
    },
    doAction_uiControl54_QuPIAg: function (data, elem) {
      ysp.appMain.back();
    },
    getTemplate_uiControl54_QuPIAg: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back();\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back();\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },

    getData_control44_hFqCmM: function (elem) {
      if (!elem) {
        return "";
      }var tit = [],
          content = [];var len = $(elem).find("#columnDiv1").find("#theTable").find("tbody").find("tr").length;$(elem).find("#columnDiv1").find("#theTable").find("tbody").find("tr").each(function (j) {
        if (j == 0) {
          $(this).find("td").map(function (i) {
            if (i != 1) {
              tit.push($(this).text().trim());
            }
          });
        } else if (j < len) {
          var row = [];$(this).find("td").map(function (i) {
            if (i == 1) {
              row.push($(this).find("input")[0].checked);
            } else {
              row.push($(this).text().trim());
            }
          });content.push(row);
        }
      });return { tit: tit, content: content };return elem.innerHTML;
    },
    doAction_uiControl42_Jb0iLz: function (data, elem) {
      var index = data.dataCustom * 1 + 1;$(elem).find("#columnDiv1").find("#theTable").find("tbody").find("tr").eq(index).find("input[type='radio']").click();
    },
    getTemplate_uiControl42_Jb0iLz: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData,_this = this;\n    var style1 = {\n      \"margin-right\":\"1rem\",\n      \"color\":\"#888\"\n    };\n    return (\n      <div class=\"listWrapper\">\n        {data&&data.content&&data.content.length ? <div class=\"navTitle\">\u96C6\u56E2\u8D26\u6237\u4FE1\u606F\u5217\u8868</div> :\"\"}\n        {data&&data.content&&data.content.map((item,i)=>{\n          if(item.length==0){\n            return (<div class=\"noData\">\n                {item}</div>)\n          }else{\n            const status = item[1]==true ? \"selected\" :\"\";\n            return(<ul>\n                    <li><font>{item[0]}</font><b><span style={{\"margin-right\":\"1rem\"}}>{data.tit[1]}</span>{item[2]}</b><i class={status}  onClick={_this.onClick} data-index={i}>more</i></li>     \n                <li><span style={style1}>{data.tit[2]}</span><span>{item[3]}</span></li>\n                <li><span style={style1}>{data.tit[3]}</span><span>{item[4]}</span></li>\n                  <li style={{\"flex\":\"0.5\"}}><span style={style1}>{data.tit[4]}</span><span>{item[5]}</span></li>\n              </ul>)\n          }\n        })}\n      </div>\n    )\n  },\n  onClick:function(e){\n    if(e.target.tagName==\"I\"){\n      var handler = this.props.customHandler;\n      if(handler){\n        handler({\n          data:e.target.getAttribute(\"data-index\")\n        })\n      }\n    }\n  \t\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData,\n        _this = this;\n    var style1 = {\n      \"margin-right\": \"1rem\",\n      \"color\": \"#888\"\n    };\n    return React.createElement(\n      \"div\",\n      { \"class\": \"listWrapper\" },\n      data && data.content && data.content.length ? React.createElement(\n        \"div\",\n        { \"class\": \"navTitle\" },\n        \"\\u96C6\\u56E2\\u8D26\\u6237\\u4FE1\\u606F\\u5217\\u8868\"\n      ) : \"\",\n      data && data.content && data.content.map(function (item, i) {\n        if (item.length == 0) {\n          return React.createElement(\n            \"div\",\n            { \"class\": \"noData\" },\n            item\n          );\n        } else {\n          var status = item[1] == true ? \"selected\" : \"\";\n          return React.createElement(\n            \"ul\",\n            null,\n            React.createElement(\n              \"li\",\n              null,\n              React.createElement(\n                \"font\",\n                null,\n                item[0]\n              ),\n              React.createElement(\n                \"b\",\n                null,\n                React.createElement(\n                  \"span\",\n                  { style: { \"margin-right\": \"1rem\" } },\n                  data.tit[1]\n                ),\n                item[2]\n              ),\n              React.createElement(\n                \"i\",\n                { \"class\": status, onClick: _this.onClick, \"data-index\": i },\n                \"more\"\n              )\n            ),\n            React.createElement(\n              \"li\",\n              null,\n              React.createElement(\n                \"span\",\n                { style: style1 },\n                data.tit[2]\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                item[3]\n              )\n            ),\n            React.createElement(\n              \"li\",\n              null,\n              React.createElement(\n                \"span\",\n                { style: style1 },\n                data.tit[3]\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                item[4]\n              )\n            ),\n            React.createElement(\n              \"li\",\n              { style: { \"flex\": \"0.5\" } },\n              React.createElement(\n                \"span\",\n                { style: style1 },\n                data.tit[4]\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                item[5]\n              )\n            )\n          );\n        }\n      })\n    );\n  },\n  onClick: function onClick(e) {\n    if (e.target.tagName == \"I\") {\n      var handler = this.props.customHandler;\n      if (handler) {\n        handler({\n          data: e.target.getAttribute(\"data-index\")\n        });\n      }\n    }\n  }\n});";
    }
  }, "Group-customer-list");
})(window, ysp);