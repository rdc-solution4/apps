(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control295_HCaxSg: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li.selected").find(".tab-title").text();
    },
    doAction_uiControl312_hoicRo: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        $(elem).parent().find("#popwin_close").eq(0).click();
      }
    },
    getTemplate_uiControl312_hoicRo: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  show:function(){\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title=\"\u96C6\u56E2\u7528\u6237\u5217\u8868\">\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  show: function show() {\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: '\\u96C6\\u56E2\\u7528\\u6237\\u5217\\u8868' },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control299_Pdwkb2: function (elem) {
      ; //选页
      if (!elem) {
        return;
      }var data = { "cls": [], "txt": [], "prev": [], "next": [] };data.prev.push($(elem).find(".prev").attr("class"));$(elem).find(".ctrl").find("span").map(function () {
        data.cls.push($(this).attr("class"));data.txt.push($(this).text());
      });data.next.push($(elem).find(".next").attr("class"));return data;
    },
    doAction_uiControl318_GMTPgy: function (data, elem) {
      if (data.dataCustom.name == "div") {
        $(elem).find("." + data.dataCustom.index).click();
      } else if (data.dataCustom.name == "span") {
        $(elem).find(".ctrl").children("span").eq(data.dataCustom.index).click();
      }
    },
    getTemplate_uiControl318_GMTPgy: function () {
      var selfTemplate = "module.exports = require('ysp-custom-components').Pagenation;";
      return "'use strict';\n\nmodule.exports = require('ysp-custom-components').Pagenation;";
    },
    getData_control283_KRvH0O: function (elem) {
      //select 弹窗
      if (!elem) {
        return;
      }var rp = ysp.customHelper.replaceSpace;var select = {},
          tabcontainer = $(elem).find(".tabcontainer[style*='block']"),
          $iframe = tabcontainer.find("iframe").contents();_select = $iframe.find(".DroplistOption[style*='block']").eq(0) || null;select.arr = [];if (!!_select) {
        $(_select).find(".dropItem").each(function (i, el) {
          var text = $(this).text(),
              id = $(this)[0].id;select.arr.push({ text: text, id: id });
        });
      }return { select: select };
    },
    doAction_uiControl295_EQzwhN: function (data, elem) {
      var d = data.dataCustom,
          tabcontainer = $(elem).find(".tabcontainer[style*='block']"),
          $iframe = tabcontainer.find("iframe").contents(),
          document = elem.ownerDocument;if (data.eventType === 'liClick') {
        $iframe.find("#" + d).mousedown().click();
      }
    },
    getTemplate_uiControl295_EQzwhN: function () {
      var selfTemplate = "// const Modal = AMUI2.Modal;\nconst Modal = require('ysp-custom-components').Modal;\nconst NavBar = AMUITouch2.NavBar;\nconst Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  handle:function(data,eventType){\n    var handler = this.props.customHandler;\n    if(handler){\n      handler({data,eventType});\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this;\n      const itemLeft = {\n        title: \"\u5173\u95ED\",\n        onClick: () => me.handle(data.popWin.closeId,\"liClick\"),\n      };\n      const itemRight = {\n        title: '\u786E\u5B9A'\n        ,onClick: () => me.handle({id:data.popWin.sureId,tips:data.tips},\"openModal\"),\n      };\n      const dataAll = {\n        leftNav: [{...itemLeft, icon: 'left-nav'}],\n      };\n    \n    \tvar alert,window;\n      return (\n        <div>\n          <div className=\"amt-modal\">\n            <ul className=\"amt-list\" style={{margin:\"0\",maxHeight:\"300px\",overflow:\"auto\"}}>\n              {data.select.arr.map(function(el,i){\n                return(\n                  <li className=\"amt-item\" style={{textAlign:\"left\"}} onClick={()=>{me.handle(el.id,\"liClick\")}}><h3 className=\"amt-item-title\">{el.text}</h3></li>\n                )\n              })}\n            </ul>\n          </div>\n          <div className={!!data.select.arr.length>0?\"amt-modal-backdrop backdrop-zIndex\":\"\"} onClick={()=>{me.handle(data.select.index,\"closeSelect\")}}></div>\n          \n          {alert}\n          <Modal\n          ref=\"modal\"\n          role=\"page\"\n          header={<NavBar {...dataAll} style={{background:\"#fff\"}} />}\n          >\n            {window}\n        \t</Modal>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\n// const Modal = AMUI2.Modal;\nvar Modal = require('ysp-custom-components').Modal;\nvar NavBar = AMUITouch2.NavBar;\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this;\n    var itemLeft = {\n      title: \"\u5173\u95ED\",\n      onClick: function onClick() {\n        return me.handle(data.popWin.closeId, \"liClick\");\n      }\n    };\n    var itemRight = {\n      title: '\u786E\u5B9A',\n      onClick: function onClick() {\n        return me.handle({ id: data.popWin.sureId, tips: data.tips }, \"openModal\");\n      }\n    };\n    var dataAll = {\n      leftNav: [_extends({}, itemLeft, { icon: 'left-nav' })]\n    };\n\n    var alert, window;\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"div\",\n        { className: \"amt-modal\" },\n        React.createElement(\n          \"ul\",\n          { className: \"amt-list\", style: { margin: \"0\", maxHeight: \"300px\", overflow: \"auto\" } },\n          data.select.arr.map(function (el, i) {\n            return React.createElement(\n              \"li\",\n              { className: \"amt-item\", style: { textAlign: \"left\" }, onClick: function onClick() {\n                  me.handle(el.id, \"liClick\");\n                } },\n              React.createElement(\n                \"h3\",\n                { className: \"amt-item-title\" },\n                el.text\n              )\n            );\n          })\n        )\n      ),\n      React.createElement(\"div\", { className: !!data.select.arr.length > 0 ? \"amt-modal-backdrop backdrop-zIndex\" : \"\", onClick: function onClick() {\n          me.handle(data.select.index, \"closeSelect\");\n        } }),\n      alert,\n      React.createElement(\n        Modal,\n        {\n          ref: \"modal\",\n          role: \"page\",\n          header: React.createElement(NavBar, _extends({}, dataAll, { style: { background: \"#fff\" } }))\n        },\n        window\n      )\n    );\n  }\n});";
    },
    getData_control296_mpsEmC: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".form_group").map(function (i, group) {
        if ($(group).find(".Droplist").length) {
          data.push({ type: "Droplist", txt: $(group).find(".form_label,.pl_title").text() && $(group).find(".form_label,.pl_title").text().replace(/\s/g, ""), val: $(group).find("input").val() });
        } else if ($(group).find(".form_control").length) {
          data.push({ type: "control", txt: $(group).find(".form_label,label").text() && $(group).find(".form_label,label").text().replace(/\s/g, ""), val: $(group).find("input").val(), id: $(group).find("input").attr("id"), right: $(group).find(".form_control").text() && $(group).find(".form_control").text().replace(/\s/g, "") });
        } else {
          data.push({ type: "btn", val: $(group).find(".btn_normal_green").text() && $(group).find(".btn_normal_green").text().replace(/\s/g, ""), id: $(group).find(".btn_normal_green").attr("id") });
        }
      });return data;
    },
    doAction_uiControl315_lzND4r: function (data, elem) {
      var d = data.dataCustom,
          document = elem.ownerDocument;if (data.eventType === 'selectClick') {
        $(elem).find(".trigger").click();
      } else if (data.eventType === 'inputChange') {
        $(elem).find(".form_group").eq(d.i).find("input").val(d.val).change();
      } else if (data.eventType === 'BtnClick') {
        $(elem).find("#" + d).click();
      }
    },
    getTemplate_uiControl315_lzND4r: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nconst Icon = AMUITouch2.Icon;\nmodule.exports = React.createClass({\n  render: function() {\n   var data = this.props.customData;\n   var _this = this;\n    function text(item,i){\n      if(item.type == \"Droplist\"){\n\t\t\t\treturn(\n          <li className=\"amt-item\" style={{borderTop:0,border:\"none\"}} onClick={_this.selectClick}>\n            <h3 className=\"amt-item-title\">{item.val}</h3>\n            <Icon name=\"right\"></Icon>\n          </li>\n        )\n      }else if(item.type == \"control\"){\n        return(\n          <AInput type=\"text\" value={item.val} onBlur={function(e){_this.inputChange(e,i)}}/>\n        )\n      }else if(item.type == \"btn\"){\n\t\t\t\treturn(\n        \t<Button id={item.id} amStyle=\"primary\" style={{width:\"100%\",marginTop:\"1rem\"}}  onClick={_this.BtnClick}>{item.val}</Button>\n        )\n      }\n    }\n    if(!data){\n      return(<p style={{display:\"none\"}}></p>)\n    }\n    return (\n      <div className=\"w-list\" style={{padding:\"1rem\",background:\"#fff\"}}>\n        {data.map(function(item,i){\n          if(item.txt){\n            return(\n              <div className=\"amt-field-single amt-field-underline-part\" style={{margin:\"0\"}}>\n                <div className=\"amt-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{item.txt}</div></div>\n                <div className=\"amt-field-wrap\">\n                  {text(item,i)}\n                </div>\n              </div>\n            )\n          }else{\n            return(\n            \t<div>\n              \t{text(item)}\n              </div>\n            )\n          }\n        })}\n      </div>\n    )\n  },\n  selectClick:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'selectClick'                         \n      })\n    }\n  },\n  inputChange:function(e,i){                              \n    var callBack = this.props.customHandler;     \n    if(callBack) {                                    \n      callBack({\n        data:{\n          val:e.target.value,\n          i:i\n        },\n        eventType:'inputChange'                         \n      })\n    }\n  },\n  BtnClick:function(e){                              \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:e.target.getAttribute(\"id\"),\n        eventType:'BtnClick'                         \n      })\n    }\n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nvar Icon = AMUITouch2.Icon;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    function text(item, i) {\n      if (item.type == \"Droplist\") {\n        return React.createElement(\n          \"li\",\n          { className: \"amt-item\", style: { borderTop: 0, border: \"none\" }, onClick: _this.selectClick },\n          React.createElement(\n            \"h3\",\n            { className: \"amt-item-title\" },\n            item.val\n          ),\n          React.createElement(Icon, { name: \"right\" })\n        );\n      } else if (item.type == \"control\") {\n        return React.createElement(AInput, { type: \"text\", value: item.val, onBlur: function onBlur(e) {\n            _this.inputChange(e, i);\n          } });\n      } else if (item.type == \"btn\") {\n        return React.createElement(\n          Button,\n          { id: item.id, amStyle: \"primary\", style: { width: \"100%\", marginTop: \"1rem\" }, onClick: _this.BtnClick },\n          item.val\n        );\n      }\n    }\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"w-list\", style: { padding: \"1rem\", background: \"#fff\" } },\n      data.map(function (item, i) {\n        if (item.txt) {\n          return React.createElement(\n            \"div\",\n            { className: \"amt-field-single amt-field-underline-part\", style: { margin: \"0\" } },\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-label\", style: { margin: \"0\", width: \"25%\" } },\n              React.createElement(\n                \"div\",\n                null,\n                item.txt\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-wrap\" },\n              text(item, i)\n            )\n          );\n        } else {\n          return React.createElement(\n            \"div\",\n            null,\n            text(item)\n          );\n        }\n      })\n    );\n  },\n  selectClick: function selectClick() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'selectClick'\n      });\n    }\n  },\n  inputChange: function inputChange(e, i) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: {\n          val: e.target.value,\n          i: i\n        },\n        eventType: 'inputChange'\n      });\n    }\n  },\n  BtnClick: function BtnClick(e) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: e.target.getAttribute(\"id\"),\n        eventType: 'BtnClick'\n      });\n    }\n  }\n});";
    },
    getData_control286_wUprZ5: function (elem) {
      ;if (!elem) {
        return "";
      }var data = [],
          checked = [];$(elem).parent().find("table.grid").find("tbody").find("tr").map(function (i) {
        var tr = [],
            check = [];$(this).find("td").map(function (j) {
          if (j > 0 && j != $(elem).parent().find("table.grid").find("thead").find("th").length - 1) {
            var properties = [];properties.push($(elem).parent().find("table.grid").find("thead").find("th").eq(j).text());properties.push($(this).text());tr.push(properties);
          } else if (j == 0) {
            data.push({ "title": $(this).text(), // $(elem).parent().find("table.grid").find("thead").find("th").eq(0).text() + " " + 
              "properties": tr });
          } else if (j == $(elem).parent().find("table.grid").find("thead").find("th").length - 1) {
            $(this).children("span").map(function () {
              check.push({ "id": $(this).attr("id"), "txt": $(this).text() && $(this).text().trim() });
            });
          }
        });checked.push(check);
      });return { data1: data, checked: checked };
    },
    doAction_uiControl297_qPb43U: function (data, elem) {
      $(elem).parent().find("table.grid").find("#" + data.dataCustom).click();
    },
    getTemplate_uiControl297_qPb43U: function () {
      var selfTemplate = "const TodoItemTypeOne = AMUITouch2.TodoItemTypeOne;\nconst Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  render: function() {\n    var data =this.props.customData;\n    var _this = this;\n    if(!data){return(<div style={{\"display\":\"none\"}}></div>)}\n    if(data.data1.length){\n      return (\n        <div className=\"w-rz-list\" style={{background:\"#fff\"}}>\n          {data.data1.map((item, index) => {\n            const { properties, status, ...others } = item;\n            return (\n              <TodoItemTypeOne\n                key={index}\n                {...others}\n              >\n                {properties.map((p, i) => {\n                  return <Pair key={i} name={p[0]} value={p[1]} />;\n                })}\n          \t\t\t<div className=\"amt-g\">\n                \t{data.checked[index].map(function(el,k){\n                    return(\n                    \t<p className=\"amt-col\" id={el.id} style={{textAlign:\"center\",borderTop:\"1px solid #fff\",height:\"40px\",lineHeight:\"40px\",margin:\"0\",padding:\"0\"}} onClick={function(){_this.BtnClick(el.id)}}>{el.txt}</p>\n                    )\n                  })}\n                </div>\n              </TodoItemTypeOne>\n            );\n          })}\n        </div>\n      )\n    }else{\n      return(\n        <div className=\"noData\">\u6682\u65E0\u6570\u636E</div>\n      )\n    }\n  },\n  BtnClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"BtnClick\",\n        data: id\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nfunction _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }\n\nvar TodoItemTypeOne = AMUITouch2.TodoItemTypeOne;\nvar Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { \"display\": \"none\" } });\n    }\n    if (data.data1.length) {\n      return React.createElement(\n        \"div\",\n        { className: \"w-rz-list\", style: { background: \"#fff\" } },\n        data.data1.map(function (item, index) {\n          var properties = item.properties,\n              status = item.status,\n              others = _objectWithoutProperties(item, [\"properties\", \"status\"]);\n\n          return React.createElement(\n            TodoItemTypeOne,\n            _extends({\n              key: index\n            }, others),\n            properties.map(function (p, i) {\n              return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n            }),\n            React.createElement(\n              \"div\",\n              { className: \"amt-g\" },\n              data.checked[index].map(function (el, k) {\n                return React.createElement(\n                  \"p\",\n                  { className: \"amt-col\", id: el.id, style: { textAlign: \"center\", borderTop: \"1px solid #fff\", height: \"40px\", lineHeight: \"40px\", margin: \"0\", padding: \"0\" }, onClick: function onClick() {\n                      _this.BtnClick(el.id);\n                    } },\n                  el.txt\n                );\n              })\n            )\n          );\n        })\n      );\n    } else {\n      return React.createElement(\n        \"div\",\n        { className: \"noData\" },\n        \"\\u6682\\u65E0\\u6570\\u636E\"\n      );\n    }\n  },\n  BtnClick: function BtnClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"BtnClick\",\n        data: id\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);