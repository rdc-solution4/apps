(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control57_Hprng0: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li.selected").eq(0).find(".tab-title").text();
    },
    doAction_uiControl55_XnZMGQ: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.customHelper.indexTabIndex = "2";
        $(elem).find("li.selected").eq(0).find(".tab-close").click();
      }
    },
    getTemplate_uiControl55_XnZMGQ: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  show:function(){\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n          <HeaderRight>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.show}></AMUI.Button>\n          </HeaderRight>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  show: function show() {\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        ),\n        React.createElement(\n          _yspInteriorComponents.HeaderRight,\n          null,\n          React.createElement(AMUI.Button, { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.show })\n        )\n      )\n    );\n  }\n});";
    },
    getData_control91_e1rzoK: function (elem) {
      "use strict";
      ;if (!elem) {
        return;
      }var data = {};data.totalsize = $(elem).children("span").attr("totalsize"); //列表总数
      data.pagesize = $(elem).children("span").attr("pagesize"); //每页显示条数
      data.totalpage = $(elem).children("span").attr("totalpage"); //总页数
      data.currentpage = $(elem).children("span").attr("currentpage"); //当前页码
      return data;
    },
    doAction_uiControl95_Voqqbz: function (data, elem) {
      "use strict";
      if ($(elem).find("img").eq(data.dataCustom).parent("a").length) {
        $(elem).find("img").eq(data.dataCustom).parent("a").click();
      }
    },
    getTemplate_uiControl95_Voqqbz: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){\n      return(\n      \t<p style={{display:\"none\"}}></p>\n      )\n    }\n    return (\n      <div className=\"w-page\" style={{marginBottom:\"1rem\"}}>\n        <div style={{fontSize:\"14px\",textAlign:\"center\",hright:\"40px\",lineHeight:\"40px\"}}>\n        \t<span>\u5171<span>{data.totalsize}</span>\u6761\uFF0C</span>\t\n          <span>\u6BCF\u9875\u663E\u793A<span>{data.pagesize}</span>\u6761\uFF0C</span>\t\n          <span>\u5171<span>{data.totalpage}</span>\u9875\uFF0C</span>\t\n          <span>\u5F53\u524D\u662F\u7B2C<span>{data.currentpage}</span>\u9875\u3002</span>\t\n        </div>\n        <div onClick={_this.PageClick} className=\"goto amt-g\">\n        \t<span className=\"amt-col\" index = \"0\">\u9996\u9875</span>\n        \t<span className=\"amt-col\" index = \"1\">\u4E0A\u4E00\u9875</span>\n        \t<span className=\"amt-col\" index = \"2\">\u4E0B\u4E00\u9875</span>\n        \t<span className=\"amt-col\" index = \"3\">\u5C3E\u9875</span>\n        </div>\n      </div>\n    )\n  },\n  PageClick:function(e){\n    var handler = this.props.customHandler;\n    var index ;\n    if(e.target.nodeName == \"SPAN\" && e.target.parentNode.getAttribute(\"class\").indexOf(\"goto\") > -1){\n      index = e.target.getAttribute(\"index\");\n    }\n    if (handler) {\n      handler({\n        data: index\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"w-page\", style: { marginBottom: \"1rem\" } },\n      React.createElement(\n        \"div\",\n        { style: { fontSize: \"14px\", textAlign: \"center\", hright: \"40px\", lineHeight: \"40px\" } },\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u5171\",\n          React.createElement(\n            \"span\",\n            null,\n            data.totalsize\n          ),\n          \"\\u6761\\uFF0C\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u6BCF\\u9875\\u663E\\u793A\",\n          React.createElement(\n            \"span\",\n            null,\n            data.pagesize\n          ),\n          \"\\u6761\\uFF0C\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u5171\",\n          React.createElement(\n            \"span\",\n            null,\n            data.totalpage\n          ),\n          \"\\u9875\\uFF0C\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u5F53\\u524D\\u662F\\u7B2C\",\n          React.createElement(\n            \"span\",\n            null,\n            data.currentpage\n          ),\n          \"\\u9875\\u3002\"\n        )\n      ),\n      React.createElement(\n        \"div\",\n        { onClick: _this.PageClick, className: \"goto amt-g\" },\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"0\" },\n          \"\\u9996\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"1\" },\n          \"\\u4E0A\\u4E00\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"2\" },\n          \"\\u4E0B\\u4E00\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"3\" },\n          \"\\u5C3E\\u9875\"\n        )\n      )\n    );\n  },\n  PageClick: function PageClick(e) {\n    var handler = this.props.customHandler;\n    var index;\n    if (e.target.nodeName == \"SPAN\" && e.target.parentNode.getAttribute(\"class\").indexOf(\"goto\") > -1) {\n      index = e.target.getAttribute(\"index\");\n    }\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});";
    },
    getData_control92_LfkhEp: function (elem) {
      if (!elem) {
        return "";
      }var data = [],
          checked = [];if ($(elem).find("tbody").find("tr").last().css("display") == "none") {
        $(elem).find("tbody").find("tr").map(function (i) {
          if ($(this).css("display") != "none") {
            var tr = [],
                trChecked = [];$(this).find("td").map(function (j) {
              if (j != 0 && j != $(elem).find("thead").find("td").length - 1) {
                var properties = [];properties.push($(elem).find("thead").find("td").eq(j).text().trim());properties.push($(this).text().trim());tr.push(properties);
              } else if (j == 0) {
                data.push({ "title": $(elem).find("thead").find("td").eq(0).text().trim() + " " + $(this).text().trim(), "properties": tr });
              } else if (j == $(elem).find("thead").find("td").length - 1) {
                $(this).find("img").map(function () {
                  trChecked.push($(this).attr("title"));
                });
              }
            });checked.push(trChecked);
          }
        });return { data1: data, checked: checked };
      } else {
        data.push({ noData: "暂无数据" });return { data1: data };
      }
    },
    doAction_uiControl96_Q4lSrN: function (data, elem) {
      if (data.eventType === "click") {
        $(elem).find("tbody").find("tr").eq(data.dataCustom.index).find("td").last().find("img").eq(data.dataCustom.i).click();
      }
    },
    getTemplate_uiControl96_Q4lSrN: function () {
      var selfTemplate = "const TodoItemTypeOne = AMUITouch2.TodoItemTypeOne;\nconst Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  render: function() {\n    var data =this.props.customData;\n    var _this = this;\n    if(!data){return(<div style={{\"display\":\"none\"}}></div>)}\n    if(!data.data1[0].noData){\n      return (\n        <div className=\"w-rz-list\" style={{background:\"#fff\"}}>\n          {data.data1.map((item, index) => {\n            const { properties, status, ...others } = item;\n            return (\n              <TodoItemTypeOne\n                key={index}\n                title=\"<Pair key={i} name={p[0]} value={p[1]} />\"\n                {...others}\n              >\n                {properties.map((p, i) => {\n                  return <Pair key={i} name={p[0]} value={p[1]} />;\n                })}\n                <div className=\"amt-g\" style={{borderTop:\"1px solid #fff\",paddingTop:\".5rem\"}}>\n                  {data.checked[index].map(function(item,i){\n                    return(\n                      <span className=\"amt-col\" onClick={function(){_this.click(index,i)}} style={{textAlign:\"center\"}}>{item}</span>\n                    )\n                  })}\n                </div>\n              </TodoItemTypeOne>\n            );\n          })}\n        </div>\n      )\n    }else{\n      return(\n        <div className=\"noData\">{data.data1[0].noData}</div>\n      )\n    }\n  },\n  click:function(index,i){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"click\",\n        data: {\n          index:index,\n          i:i\n        }\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nfunction _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }\n\nvar TodoItemTypeOne = AMUITouch2.TodoItemTypeOne;\nvar Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { \"display\": \"none\" } });\n    }\n    if (!data.data1[0].noData) {\n      return React.createElement(\n        \"div\",\n        { className: \"w-rz-list\", style: { background: \"#fff\" } },\n        data.data1.map(function (item, index) {\n          var properties = item.properties,\n              status = item.status,\n              others = _objectWithoutProperties(item, [\"properties\", \"status\"]);\n\n          return React.createElement(\n            TodoItemTypeOne,\n            _extends({\n              key: index,\n              title: \"<Pair key={i} name={p[0]} value={p[1]} />\"\n            }, others),\n            properties.map(function (p, i) {\n              return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n            }),\n            React.createElement(\n              \"div\",\n              { className: \"amt-g\", style: { borderTop: \"1px solid #fff\", paddingTop: \".5rem\" } },\n              data.checked[index].map(function (item, i) {\n                return React.createElement(\n                  \"span\",\n                  { className: \"amt-col\", onClick: function onClick() {\n                      _this.click(index, i);\n                    }, style: { textAlign: \"center\" } },\n                  item\n                );\n              })\n            )\n          );\n        })\n      );\n    } else {\n      return React.createElement(\n        \"div\",\n        { className: \"noData\" },\n        data.data1[0].noData\n      );\n    }\n  },\n  click: function click(index, i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"click\",\n        data: {\n          index: index,\n          i: i\n        }\n      });\n    }\n  }\n});";
    },

    getData_control150_TNiAKl: function (elem) {
      'use strict';

      if (!elem) {
        return;
      }var data = [];$(elem).find('input[type="button"]').map(function () {
        data.push($(this).val());
      });return data;
    },
    doAction_uiControl154_VTBPlf: function (data, elem) {
      'use strict';

      $(elem).find('input[type="button"]').eq(data.dataCustom).click();
    },
    getTemplate_uiControl154_VTBPlf: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){return(<p style={{display:\"none\"}}></p>)}\n    return (\n      <div className=\"amt-g w-threeBtn\" style={{padding:\"1rem\"}}>\n       {data.map(function(item,i){\n          return(\n          \t<Button className=\"amt-col\" onClick={function(){_this.onClick(i)}} rounded>{item}</Button>\n          )\n        })}\n      </div>\n    )\n  },\n  onClick:function(i){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"amt-g w-threeBtn\", style: { padding: \"1rem\" } },\n      data.map(function (item, i) {\n        return React.createElement(\n          Button,\n          { className: \"amt-col\", onClick: function onClick() {\n              _this.onClick(i);\n            }, rounded: true },\n          item\n        );\n      })\n    );\n  },\n  onClick: function onClick(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });\n    }\n  }\n});";
    }
  }, "InformationMaintenance");
})(window, ysp);