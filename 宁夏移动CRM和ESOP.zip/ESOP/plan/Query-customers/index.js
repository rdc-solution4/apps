(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control46_3T9rp4: function (elem) {
      return elem.textContent;
    },
    doAction_uiControl45_GeUn9L: function (data, elem) {
      ysp.appMain.back();
    },
    getTemplate_uiControl45_GeUn9L: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back();\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back();\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control47_otG9a6: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".list02_title").map(function () {
        if ($(this).text().trim() != "" && $(this).parent("tr").css("display") != "none") {
          var input = [];$(this).next("td").find("input").map(function () {
            input.push({ "name": $(this).attr("name"), "value": $(this).attr("onclick") ? $(this).val().replace(/ /g, "T") : $(this).val(), "type": $(this).attr("onclick") ? "datetime-local" : "text" });
          });data.push({ "txt": $(this).text().trim(), "input": input });
        }
      });return data;
    },
    doAction_uiControl46_KexzMz: function (data, elem) {
      if (data.eventType === "InputBlur") {
        var val = data.dataCustom.value;val.indexOf("T") > -1 ? val = val.replace(/T/g, ' ') + ':00' : val;$(elem).find("input[name=" + data.dataCustom.name + "]").val(val);
      }
    },
    getTemplate_uiControl46_KexzMz: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){\n      return(\n      \t<div style={{display:\"none\"}}></div>\n      )\n    }\n    return (\n      <div class=\"w-searchBox\">\n        <ul class='searchC'>\n          {data.map(function(el,i){\n            return(\n              <li>\n                <span>{el.txt}</span>\n                <div>\n                  {el.input.map(function(element,k){\n                    return(\n                      <AInput type = {element.type} value={element.value} name={element.name} onBlur={function(e){_this.InputBlur(e,element.name)}} ></AInput>\n                    )\n                  })}\n                </div>\n              </li>\n            )\n          })}\n          </ul>\n      </div>\n    )\n  },\n  InputBlur:function(e,name){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n       \"eventType\":\"InputBlur\",\n        data: {\n          name:name,\n          value:e.target.value\n        }\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { \"class\": \"w-searchBox\" },\n      React.createElement(\n        \"ul\",\n        { \"class\": \"searchC\" },\n        data.map(function (el, i) {\n          return React.createElement(\n            \"li\",\n            null,\n            React.createElement(\n              \"span\",\n              null,\n              el.txt\n            ),\n            React.createElement(\n              \"div\",\n              null,\n              el.input.map(function (element, k) {\n                return React.createElement(AInput, { type: element.type, value: element.value, name: element.name, onBlur: function onBlur(e) {\n                    _this.InputBlur(e, element.name);\n                  } });\n              })\n            )\n          );\n        })\n      )\n    );\n  },\n  InputBlur: function InputBlur(e, name) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"eventType\": \"InputBlur\",\n        data: {\n          name: name,\n          value: e.target.value\n        }\n      });\n    }\n  }\n});";
    }
  }, "Query-customers");
})(window, ysp);