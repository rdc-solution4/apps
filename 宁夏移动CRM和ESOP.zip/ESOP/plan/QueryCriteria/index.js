(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control151_cgfHeb: function (elem) {
      "use strict";

      ;
    },
    doAction_uiControl155_A29ns7: function (data, elem) {
      "use strict";
    },
    getTemplate_uiControl155_A29ns7: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nexport default () =>\n<Header amStyle=\"primary\" title=\"\u5BA1\u6279\u4EBA\">\n  <HeaderLeft>\n    <AMUI.Button amStyle=\"primary\" onClick={back}><AMUI.Icon name='left-nav'></AMUI.Icon>\u8FD4\u56DE</AMUI.Button>\n  </HeaderLeft>\n</Header>;";
      return "'use strict';\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nexports.default = function () {\n  return React.createElement(\n    _yspInteriorComponents.Header,\n    { amStyle: 'primary', title: '\\u5BA1\\u6279\\u4EBA' },\n    React.createElement(\n      _yspInteriorComponents.HeaderLeft,\n      null,\n      React.createElement(\n        AMUI.Button,\n        { amStyle: 'primary', onClick: _appRenderer.back },\n        React.createElement(AMUI.Icon, { name: 'left-nav' }),\n        '\\u8FD4\\u56DE'\n      )\n    )\n  );\n};";
    },

    getData_control159_s4mOT9: function (elem) {
      "use strict";

      ;if (!elem) {
        return;
      }var data = { tit: ["工号", "姓名"], content: [] };$(elem).find("input").map(function () {
        data.content.push({ id: $(this).attr("id"), val: $(this).val() });
      });return data;
    },
    doAction_uiControl165_73borH: function (data, elem) {
      "use strict";

      $(elem).find("#" + data.dataCustom.id).val(data.dataCustom.val);
    },
    getTemplate_uiControl165_73borH: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    return (\n      <div>\n        {data.content.map(function(item,i){\n          return(\n          \t<label class=\"amt-field-single amt-field-underline-part\">\n              <div class=\"amt-field-label\">\n                <div>{data.tit[i]}\uFF1A</div>\n              </div>\n              <div class=\"amt-field-wrap\">\n                <AInput type=\"text\" class=\"amt-field\" value={item.val} onBlur={function(e){_this.blur(e,item.id)}}/>\n              </div>\n            </label>\n          )\n        })}\n      </div>\n    )\n  },\n  blur:function(e,id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          id:id,\n          val:e.target.value\n        }\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    return React.createElement(\n      \"div\",\n      null,\n      data.content.map(function (item, i) {\n        return React.createElement(\n          \"label\",\n          { \"class\": \"amt-field-single amt-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { \"class\": \"amt-field-label\" },\n            React.createElement(\n              \"div\",\n              null,\n              data.tit[i],\n              \"\\uFF1A\"\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { \"class\": \"amt-field-wrap\" },\n            React.createElement(AInput, { type: \"text\", \"class\": \"amt-field\", value: item.val, onBlur: function onBlur(e) {\n                _this.blur(e, item.id);\n              } })\n          )\n        );\n      })\n    );\n  },\n  blur: function blur(e, id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: {\n          id: id,\n          val: e.target.value\n        }\n      });\n    }\n  }\n});";
    },
    getData_undefined: function (elem) {
      "use strict";

      ;
    },
    doAction_: function (data, elem) {
      "use strict";
    },
    getTemplate_: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    },
    getData_control160_TPJygM: function (elem) {
      "use strict";

      ;if (!elem) {
        return "";
      }var data = [],
          checked = [];if ($(elem).find("tbody").find("tr").last().css("display") == "none") {
        $(elem).find("tbody").find("tr").map(function (i) {
          var tr = [];checked.push({ "id": $(this).find("td").eq(0).children("input").attr("id"), "class": $(this).find("td").eq(0).children("input").is(":checked") });$(this).find("td").map(function (j) {
            if (j > 1) {
              var properties = [];properties.push($(elem).find("thead").find("td").eq(j).text().trim());properties.push($(this).text().trim());tr.push(properties);
            } else if (j == 1) {
              data.push({ "title1": $(elem).find("thead").find("td").eq(1).text().trim() + " " + $(this).text().trim(), "properties": tr });
            }
          });
        });return { data1: data, checked: checked };
      } else {
        data.push({ noData: "暂无数据" });return { data1: data };
      }
    },
    doAction_uiControl166_5RF0gm: function (data, elem) {
      "use strict";

      if (data.eventType === "title") {
        $(elem).find("#" + data.dataCustom).click();
      }
    },
    getTemplate_uiControl166_5RF0gm: function () {
      var selfTemplate = "const TodoItemTypeOne = AMUITouch2.TodoItemTypeOne;\nconst Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  render: function() {\n    var data =this.props.customData;\n    var _this = this;\n    if(!data){return(<div style={{\"display\":\"none\"}}></div>)}\n    if(!data.data1[0].noData){\n      return (\n        <div className=\"w-rz-list\" style={{background:\"#fff\"}}>\n          {data.data1.map((item, index) => {\n           item.onTitleClick=()=>{_this.TitleClick(data.checked[index].id)}\n           item.title=<div className=\"amt-item\" style={{padding: \"0\",height: \"30px\",minHeight: \"30px\"}}>\n                <span className=\"amt-item-after\" style={{float: \"right\"}}>\n                  <label className=\"amt-switch\" id={data.checked[index].id} style={{margin:\"0 5px 0 0\"}} onTitleClick={function(){_this.TitleClick(index,data.checked[index].id)}}>\n                    <input type=\"checkbox\" checked={data.checked[index].class} style={{verticalAlign:\"middle\"}}/>\n                    <span className=\"amt-switch-checkbox\"></span>\n                  </label>\n                </span>\n                <span className=\"amt-item-title\" style={{height: \"35px\",lineHeight: \"35px\",color:\"#0F91E9\"}}>{item.title1}</span>\n              </div>\n            const { properties, status, ...others } = item;\n            return (\n              <TodoItemTypeOne\n                key={index}\n                {...others}\n              >\n                {properties.map((p, i) => {\n                  return <Pair key={i} name={p[0]} value={p[1]} />;\n                })}\n              </TodoItemTypeOne>\n            );\n          })}\n        </div>\n      )\n    }else{\n      return(\n        <div className=\"noData\">{data.data1[0].noData}</div>\n      )\n    }\n  },\n  TitleClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"title\",\n        data: id\n      });   \n    }\n  }\n});";
      return "\"use strict\";\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nfunction _objectWithoutProperties(obj, keys) { var target = {}; for (var i in obj) { if (keys.indexOf(i) >= 0) continue; if (!Object.prototype.hasOwnProperty.call(obj, i)) continue; target[i] = obj[i]; } return target; }\n\nvar TodoItemTypeOne = AMUITouch2.TodoItemTypeOne;\nvar Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { \"display\": \"none\" } });\n    }\n    if (!data.data1[0].noData) {\n      return React.createElement(\n        \"div\",\n        { className: \"w-rz-list\", style: { background: \"#fff\" } },\n        data.data1.map(function (item, index) {\n          item.onTitleClick = function () {\n            _this.TitleClick(data.checked[index].id);\n          };\n          item.title = React.createElement(\n            \"div\",\n            { className: \"amt-item\", style: { padding: \"0\", height: \"30px\", minHeight: \"30px\" } },\n            React.createElement(\n              \"span\",\n              { className: \"amt-item-after\", style: { float: \"right\" } },\n              React.createElement(\n                \"label\",\n                { className: \"amt-switch\", id: data.checked[index].id, style: { margin: \"0 5px 0 0\" }, onTitleClick: function onTitleClick() {\n                    _this.TitleClick(index, data.checked[index].id);\n                  } },\n                React.createElement(\"input\", { type: \"checkbox\", checked: data.checked[index].class, style: { verticalAlign: \"middle\" } }),\n                React.createElement(\"span\", { className: \"amt-switch-checkbox\" })\n              )\n            ),\n            React.createElement(\n              \"span\",\n              { className: \"amt-item-title\", style: { height: \"35px\", lineHeight: \"35px\", color: \"#0F91E9\" } },\n              item.title1\n            )\n          );\n\n          var properties = item.properties,\n              status = item.status,\n              others = _objectWithoutProperties(item, [\"properties\", \"status\"]);\n\n          return React.createElement(\n            TodoItemTypeOne,\n            _extends({\n              key: index\n            }, others),\n            properties.map(function (p, i) {\n              return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n            })\n          );\n        })\n      );\n    } else {\n      return React.createElement(\n        \"div\",\n        { className: \"noData\" },\n        data.data1[0].noData\n      );\n    }\n  },\n  TitleClick: function TitleClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"title\",\n        data: id\n      });\n    }\n  }\n});";
    },
    getData_control156_ZU09Ar: function (elem) {
      "use strict";
      ;if (!elem) {
        return;
      }var data = {};data.totalsize = $(elem).children("span").attr("totalsize"); //列表总数
      data.pagesize = $(elem).children("span").attr("pagesize"); //每页显示条数
      data.totalpage = $(elem).children("span").attr("totalpage"); //总页数
      data.currentpage = $(elem).children("span").attr("currentpage"); //当前页码
      return data;
    },
    doAction_uiControl162_I7sM7o: function (data, elem) {
      "use strict";
      if ($(elem).find("img").eq(data.dataCustom).parent("a").length) {
        $(elem).find("img").eq(data.dataCustom).parent("a").click();
      }
    },
    getTemplate_uiControl162_I7sM7o: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){\n      return(<p style={{display:\"none\"}}></p>)\n    }\n    return (\n      <div className=\"w-page\" style={{paddingBottom:\"1rem\"}}>\n        <div style={{fontSize:\"14px\",textAlign:\"center\",hright:\"40px\",lineHeight:\"40px\"}}>\n        \t<span>\u5171<span>{data.totalsize}</span>\u6761\uFF0C</span>\t\n          <span>\u6BCF\u9875\u663E\u793A<span>{data.pagesize}</span>\u6761\uFF0C</span>\t\n          <span>\u5171<span>{data.totalpage}</span>\u9875\uFF0C</span>\t\n          <span>\u5F53\u524D\u662F\u7B2C<span>{data.currentpage}</span>\u9875\u3002</span>\t\n        </div>\n        <div onClick={_this.PageClick} className=\"goto amt-g\">\n        \t<span className=\"amt-col\" index = \"0\">\u9996\u9875</span>\n        \t<span className=\"amt-col\" index = \"1\">\u4E0A\u4E00\u9875</span>\n        \t<span className=\"amt-col\" index = \"2\">\u4E0B\u4E00\u9875</span>\n        \t<span className=\"amt-col\" index = \"3\">\u5C3E\u9875</span>\n        </div>\n      </div>\n    )\n  },\n  PageClick:function(e){\n    var handler = this.props.customHandler;\n    var index ;\n    if(e.target.nodeName == \"SPAN\" && e.target.parentNode.getAttribute(\"class\").indexOf(\"goto\") > -1){\n      index = e.target.getAttribute(\"index\");\n    }\n    if (handler) {\n      handler({\n        data: index\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"w-page\", style: { paddingBottom: \"1rem\" } },\n      React.createElement(\n        \"div\",\n        { style: { fontSize: \"14px\", textAlign: \"center\", hright: \"40px\", lineHeight: \"40px\" } },\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u5171\",\n          React.createElement(\n            \"span\",\n            null,\n            data.totalsize\n          ),\n          \"\\u6761\\uFF0C\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u6BCF\\u9875\\u663E\\u793A\",\n          React.createElement(\n            \"span\",\n            null,\n            data.pagesize\n          ),\n          \"\\u6761\\uFF0C\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u5171\",\n          React.createElement(\n            \"span\",\n            null,\n            data.totalpage\n          ),\n          \"\\u9875\\uFF0C\"\n        ),\n        React.createElement(\n          \"span\",\n          null,\n          \"\\u5F53\\u524D\\u662F\\u7B2C\",\n          React.createElement(\n            \"span\",\n            null,\n            data.currentpage\n          ),\n          \"\\u9875\\u3002\"\n        )\n      ),\n      React.createElement(\n        \"div\",\n        { onClick: _this.PageClick, className: \"goto amt-g\" },\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"0\" },\n          \"\\u9996\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"1\" },\n          \"\\u4E0A\\u4E00\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"2\" },\n          \"\\u4E0B\\u4E00\\u9875\"\n        ),\n        React.createElement(\n          \"span\",\n          { className: \"amt-col\", index: \"3\" },\n          \"\\u5C3E\\u9875\"\n        )\n      )\n    );\n  },\n  PageClick: function PageClick(e) {\n    var handler = this.props.customHandler;\n    var index;\n    if (e.target.nodeName == \"SPAN\" && e.target.parentNode.getAttribute(\"class\").indexOf(\"goto\") > -1) {\n      index = e.target.getAttribute(\"index\");\n    }\n    if (handler) {\n      handler({\n        data: index\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);