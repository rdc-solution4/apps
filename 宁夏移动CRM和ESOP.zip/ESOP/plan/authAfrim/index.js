(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control66_EgMWMf: function (elem) {
      return "授权认证";
    },
    doAction_uiControl66_0NDAo6: function (data, elem) {
      ysp.appMain.back();
    },
    getTemplate_uiControl66_0NDAo6: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData||\"\u8BA4\u8BC1\u6210\u529F\",\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.data.customData || \"\u8BA4\u8BC1\u6210\u529F\",\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n});";
    },
    getData_control67_Ih9MFh: function (elem) {
      if (!elem) {
        return '';
      }var data = [];$(elem).find("tr").each(function () {
        if ($(this).css("display") != "none" && $(this).find(".td_text_width").length) {
          var con,
              tar = $(this).find(".td_text_width").next().children();switch (tar[0].tagName) {case 'INPUT':
              if (tar[0].type == "text") {
                con = { 'tag': 'ip', 'val': tar.val() };
              } else if (tar[0].type == "radio") {
                con = [];tar.each(function (i) {
                  debugger;con.push({ 'tag': 'radio', 'val': $(this).val(), 'txt': $(this).parent().text().trim(), 'checked': $(this)[0].checked });
                });
              } else {}break;case "TEXTAREA":
              con = { 'tag': 'textarea', 'val': tar.val() };break;case "SELECT":
              con = { 'tag': 'select', 'val': tar.html() };break;default:
              con = { 'tag': 'date', 'val': tar.find("input").val().replace(/\s/g, 'T') };break;}data.push({ tit: $(this).find(".td_text_width").text(), con: con });
        }
      });return data;
    },
    doAction_uiControl67_DREXGg: function (data, elem) {
      var evt = data.eventType;var d = data.dataCustom;switch (evt) {case "txt":
          if (d.type == "datetime-local") {
            d.val = d.val.replace(/T/g, ' ');$(elem).find(".td_text_width").eq(d.ind).next().find("input").val(d.val);
          } else {
            d.tag == "INPUT" ? $(elem).find("input#operId").val(d.val) : $(elem).find("textarea#note").val(d.val);
          }break;case "change":
          $(elem).find(".td_text_width").eq(d.ind).next().find("select")[0].selectedIndex = d.val;break;case "check":
          $(elem).find("input[type='radio']").each(function () {
            $(this).attr("value") == d.val ? $(this).click() : '';
          });}
    },
    getTemplate_uiControl67_DREXGg: function () {
      var selfTemplate = "module.exports = React.createClass({\n  renderDom: function(data){\n    return{__html:data};\n  },\n  renderCon:function(data,that,i){\n    switch(data.con.tag||data.con[0].tag){\n      case \"textarea\":\n        return(<li><span>{data.tit}</span><ATextarea value={data.con.val} onBlur = {that.onBlur} /></li>);\n        break;\n      case \"ip\":\n        return(<li><span>{data.tit}</span><AInput value={data.con.val} onBlur = {that.onBlur} /></li>);\n        break;\n      case \"radio\":\n        return(<li><span>{data.tit}</span>{data.con.map((v)=>{\n             return(<p><AInput type='radio' checked={v.checked} value={v.val} onClick = {that.onClick} />{v.txt}</p>) \n            })}</li>);\n        break;\n      case \"select\":\n        return(<li><span>{data.tit}</span><select dangerouslySetInnerHTML={that.renderDom(data.con.val)} onChange = {that.onChange} data-index = {i} /></li>);\n        break;\n      case \"date\":\n        return(<li><span>{data.tit}</span><AInput type=\"datetime-local\" value={data.con.val} data-index={i} onBlur = {that.onBlur} /></li>);\n        break;\n   }\n  },\n  render: function() {\n    var data = this.props.customData,_this = this;\n    return (\n      <div>\n        {data&&data.length ? <div class='searchCondition authSearch'>{data.map((item,i)=>{\n              return(<ul class=\"searchC\">{_this.renderCon(item,_this,i)}</ul>)\n            })}</div> : ''}\n      </div>\n    )\n  },\n  onBlur: function(e){\n    const handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'txt',\n        data:{\n          tag:e.target.tagName,\n          val:e.target.value,\n          ind:e.target.getAttribute(\"data-index\")||'',\n          type:e.target.type\n        }\n      })\n    }\n  },\n  onChange: function(e){\n    var handler = this.props.customHandler;\n   \tif (handler) {\n      handler({\n        eventType: 'change',\n        data: {\n          ind:e.target.getAttribute(\"data-index\"),\n          val:e.target.selectedIndex\n        }\n      });\n  \t}\n  },\n  onClick: function(e){\n    var handler = this.props.customHandler;\n   \tif (handler) {\n      handler({\n        eventType: 'check',\n        data: {\n          val:e.target.getAttribute(\"value\")\n        }\n      });\n  \t}\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  renderDom: function renderDom(data) {\n    return { __html: data };\n  },\n  renderCon: function renderCon(data, that, i) {\n    switch (data.con.tag || data.con[0].tag) {\n      case \"textarea\":\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          React.createElement(ATextarea, { value: data.con.val, onBlur: that.onBlur })\n        );\n        break;\n      case \"ip\":\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          React.createElement(AInput, { value: data.con.val, onBlur: that.onBlur })\n        );\n        break;\n      case \"radio\":\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          data.con.map(function (v) {\n            return React.createElement(\n              \"p\",\n              null,\n              React.createElement(AInput, { type: \"radio\", checked: v.checked, value: v.val, onClick: that.onClick }),\n              v.txt\n            );\n          })\n        );\n        break;\n      case \"select\":\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          React.createElement(\"select\", { dangerouslySetInnerHTML: that.renderDom(data.con.val), onChange: that.onChange, \"data-index\": i })\n        );\n        break;\n      case \"date\":\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          React.createElement(AInput, { type: \"datetime-local\", value: data.con.val, \"data-index\": i, onBlur: that.onBlur })\n        );\n        break;\n    }\n  },\n  render: function render() {\n    var data = this.props.customData,\n        _this = this;\n    return React.createElement(\n      \"div\",\n      null,\n      data && data.length ? React.createElement(\n        \"div\",\n        { \"class\": \"searchCondition authSearch\" },\n        data.map(function (item, i) {\n          return React.createElement(\n            \"ul\",\n            { \"class\": \"searchC\" },\n            _this.renderCon(item, _this, i)\n          );\n        })\n      ) : ''\n    );\n  },\n  onBlur: function onBlur(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'txt',\n        data: {\n          tag: e.target.tagName,\n          val: e.target.value,\n          ind: e.target.getAttribute(\"data-index\") || '',\n          type: e.target.type\n        }\n      });\n    }\n  },\n  onChange: function onChange(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'change',\n        data: {\n          ind: e.target.getAttribute(\"data-index\"),\n          val: e.target.selectedIndex\n        }\n      });\n    }\n  },\n  onClick: function onClick(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'check',\n        data: {\n          val: e.target.getAttribute(\"value\")\n        }\n      });\n    }\n  }\n});";
    },
    getData_control72_npgzSD: function (elem) {
      if (!elem) {
        return '';
      }var data = [];$(elem).find("tr").each(function () {
        if ($(this).css("display") != "none" && $(this).find(".td_text_width").length) {
          var con,
              tarN,
              tar = $(this).find(".td_text_width").next();tarN = tar.find("input").length ? 'INPUT' : '';switch (tarN) {case 'INPUT':
              con = { 'tag': 'ip', 'val': tar.find("input").val() };break;default:
              con = { 'tag': 'nor', 'val': tar.text() };break;}data.push({ tit: $(this).find(".td_text_width").text(), con: con });
        }
      });return data;
    },
    doAction_uiControl73_ciqZAT: function (data, elem) {
      $(elem).find("input#accountPass").val(data.dataCustom.val);
    },
    getTemplate_uiControl73_ciqZAT: function () {
      var selfTemplate = "module.exports = React.createClass({\n  renderDom: function(data){\n    return{__html:data};\n  },\n  renderCon:function(data,that,i){\n    switch(data.con.tag||data.con[0].tag){\n      case \"ip\":\n        return(<li><span>{data.tit}</span><AInput type=\"password\" value={data.con.val} onBlur = {that.onBlur} /></li>);\n        break;\n      default:\n        return(<li><span>{data.tit}</span><div>{data.con.val}</div></li>);\n        break;\n   }\n  },\n  render: function() {\n    var data = this.props.customData,_this = this;\n    return (\n      <div>\n        {data&&data.length ? <div class='searchCondition authSearch'>{data.map((item,i)=>{\n              return(<ul class=\"searchC\">{_this.renderCon(item,_this,i)}</ul>)\n            })}</div> : ''}\n      </div>\n    )\n  },\n  onBlur: function(e){\n    const handler = this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'txt',\n        data:{\n          val:e.target.value\n        }\n      })\n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  renderDom: function renderDom(data) {\n    return { __html: data };\n  },\n  renderCon: function renderCon(data, that, i) {\n    switch (data.con.tag || data.con[0].tag) {\n      case \"ip\":\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          React.createElement(AInput, { type: \"password\", value: data.con.val, onBlur: that.onBlur })\n        );\n        break;\n      default:\n        return React.createElement(\n          \"li\",\n          null,\n          React.createElement(\n            \"span\",\n            null,\n            data.tit\n          ),\n          React.createElement(\n            \"div\",\n            null,\n            data.con.val\n          )\n        );\n        break;\n    }\n  },\n  render: function render() {\n    var data = this.props.customData,\n        _this = this;\n    return React.createElement(\n      \"div\",\n      null,\n      data && data.length ? React.createElement(\n        \"div\",\n        { \"class\": \"searchCondition authSearch\" },\n        data.map(function (item, i) {\n          return React.createElement(\n            \"ul\",\n            { \"class\": \"searchC\" },\n            _this.renderCon(item, _this, i)\n          );\n        })\n      ) : ''\n    );\n  },\n  onBlur: function onBlur(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'txt',\n        data: {\n          val: e.target.value\n        }\n      });\n    }\n  }\n});";
    },
    getData_control451_GBIdQx: function (elem) {
      if (!elem) {
        return;
      }var $table = $(elem);if ($table.css('display') == 'none') {
        $table = $table.prev();
      }var btns = [];$table.find('input[type="button"]').each(function (i, btn) {
        btns.push({ text: $(btn).val(), selector: 'input[type="button"]' });
      });return { btns: btns, tableId: '#' + $table.attr('id') };
    },
    doAction_uiControl72_QUFnvw: function (data, elem) {
      var _d = data.customData;if (data.eventType == 'click') {
        $(elem).parent().find(_d.id).find(_d.selector).eq(_d.idx).click();
      }
    },
    getTemplate_uiControl72_QUFnvw: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  handle: function(data,eventType){\n    var handler = this.props.customHandler;\n   \tif (handler) {\n      handler({data,eventType});\n  \t}\n  },\n  render: function() {\n    var me = this, _d = me.props.customData;\n    return (\n      <div style={{display:'flex'}}>\n        {_d.btns.map((btn,i)=>{\n          return <Button style={{flex:'auto'}} amStyle={i==0?'primary':''} onClick={()=>{\n              me.handle({...btn,idx:i,id:_d.tableId},'click');\n            }}>{btn.text}</Button>\n        })}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  handle: function handle(data, eventType) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var me = this,\n        _d = me.props.customData;\n    return React.createElement(\n      'div',\n      { style: { display: 'flex' } },\n      _d.btns.map(function (btn, i) {\n        return React.createElement(\n          Button,\n          { style: { flex: 'auto' }, amStyle: i == 0 ? 'primary' : '', onClick: function onClick() {\n              me.handle(_extends({}, btn, { idx: i, id: _d.tableId }), 'click');\n            } },\n          btn.text\n        );\n      })\n    );\n  }\n});";
    }
  }, "authAfrim");
})(window, ysp);