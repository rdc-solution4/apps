(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control273_h0CL6M: function (elem) {},
    doAction_uiControl285_N1EXw8: function (data, elem) {},
    getTemplate_uiControl285_N1EXw8: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nexport default () =>\n<Header amStyle=\"primary\" title=\"\u529E\u7406\u5931\u8D25\">\n  <HeaderLeft>\n    <AMUI.Button amStyle=\"primary\" onClick={back}><AMUI.Icon name='left-nav'></AMUI.Icon>\u8FD4\u56DE</AMUI.Button>\n  </HeaderLeft>\n</Header>;";
      return "'use strict';\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nexports.default = function () {\n  return React.createElement(\n    _yspInteriorComponents.Header,\n    { amStyle: 'primary', title: '\\u529E\\u7406\\u5931\\u8D25' },\n    React.createElement(\n      _yspInteriorComponents.HeaderLeft,\n      null,\n      React.createElement(\n        AMUI.Button,\n        { amStyle: 'primary', onClick: _appRenderer.back },\n        React.createElement(AMUI.Icon, { name: 'left-nav' }),\n        '\\u8FD4\\u56DE'\n      )\n    )\n  );\n};";
    },
    getData_control277_nwQ1pp: function (elem) {
      ;if (!elem) {
        return;
      }var data = [];$(elem).find('input[type="button"],input[type="reset"],a').map(function () {
        data.push($(this).val() || $(this).text());
      });return data;
    },
    doAction_uiControl289_36ApC6: function (data, elem) {
      $(elem).find('input[type="button"],input[type="reset"],a').eq(data.dataCustom).click();
    },
    getTemplate_uiControl289_36ApC6: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){return(<p style={{display:\"none\"}}></p>)}\n    return (\n      <div className=\"amt-g w-threeBtn\" style={{padding:\"1rem\",textAlign:\"center\"}}>\n       {data.map(function(item,i){\n          return(\n          \t<Button className=\"amt-col\" onClick={function(){_this.onClick(i)}} rounded>{item}</Button>\n          )\n        })}\n      </div>\n    )\n  },\n  onClick:function(i){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"amt-g w-threeBtn\", style: { padding: \"1rem\", textAlign: \"center\" } },\n      data.map(function (item, i) {\n        return React.createElement(\n          Button,\n          { className: \"amt-col\", onClick: function onClick() {\n              _this.onClick(i);\n            }, rounded: true },\n          item\n        );\n      })\n    );\n  },\n  onClick: function onClick(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });\n    }\n  }\n});";
    }
  });
})(window, ysp);