(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control195_gOkiRx: function (elem) {
      ;
    },
    doAction_uiControl205_lwUfQo: function (data, elem) {
      "use strict";
    },
    getTemplate_uiControl205_lwUfQo: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nexport default () =>\n<Header amStyle=\"primary\" title=\"\u7EC4\u7EC7\u673A\u6784\">\n  <HeaderLeft>\n    <AMUI.Button amStyle=\"primary\" onClick={back}><AMUI.Icon name='left-nav'></AMUI.Icon>\u8FD4\u56DE</AMUI.Button>\n  </HeaderLeft>\n</Header>;";
      return "'use strict';\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nexports.default = function () {\n  return React.createElement(\n    _yspInteriorComponents.Header,\n    { amStyle: 'primary', title: '\\u7EC4\\u7EC7\\u673A\\u6784' },\n    React.createElement(\n      _yspInteriorComponents.HeaderLeft,\n      null,\n      React.createElement(\n        AMUI.Button,\n        { amStyle: 'primary', onClick: _appRenderer.back },\n        React.createElement(AMUI.Icon, { name: 'left-nav' }),\n        '\\u8FD4\\u56DE'\n      )\n    )\n  );\n};";
    },
    getData_control196_3ohZ7E: function (elem) {
      if (!elem) {
        return '';
      }function getData(curNode, arr) {
        curNode.children(".wti").each(function () {
          arr.push({ txt: $(this).find(".WTicon-and-label").eq(0).text(), id: $(this).find("a").attr("id"), status: $(this).find("button").eq(0).attr("class").indexOf("rootPlusIcon") > -1 || $(this).find("button").eq(0).attr("class").indexOf("tPlusIcon") > -1 ? true : false, children: [] });if ($(this).children(".wtc").length && $(this).children(".wtc")[0].style.display != "none") {
            var curNode = $(this).children(".wtc");getData(curNode, arr[arr.length - 1].children);
          }
        });
      }data = [];var root = $(elem);getData(root, data);return { data: data };
    },
    doAction_uiControl206_CisGES: function (data, elem) {
      $(elem).find(".wti").each(function () {
        if ($(this).find("a").attr("id") == data.dataCustom) {
          if (data.eventType == "click") {
            $(this).find("button").eq(0).mousedown();
          } else if (data.eventType == "radio") {
            $(this).find("button").eq(1).mousedown();
          }
        }
      });
    },
    getTemplate_uiControl206_CisGES: function () {
      var selfTemplate = "module.exports = React.createClass({\n  renderTree:function(data,me){\n    return(\n      <ul>{data.map((item,i)=>{\n          return(\n            <li className={item.status ? 'close' : 'open'} >\n              <span onClick={(e)=>{\n                  const target = e.target;\n                  me.handle(target,item.id,'click')\n                }}>\n                <i></i>\n                <input type=\"radio\" name=\"1\" onClick={(e)=>{\n                  const target = e.target;\n                  me.handle(target,item.id,'radio')\n                }}/>\n                <font>{item.txt}</font>\n              </span>\n              {item.children.length ? <div>{me.renderTree(item.children,me)}</div> : ''}\n            </li>\n          )\n        })}\n      </ul>)\n  },\n  render: function() {\n  \tvar data = this.props.customData,\n  \t\t\tme = this;\n    if(!data){\n      return(\n      \t<p style={{display:\"none\"}}></p>\n      )\n    }\n    return (\n      <div style={{background:'#fff'}} class='w-jsTree'>\n        {data&&data.tit ? <div class='w-tit'>{data.tit}</div> : ''}\n        {data.data&&data.data.length ? <div class='w-treeBody'>{me.renderTree(data.data,me)}</div> : ''}\n      </div>\n    )\n},\n\thandle:function(target,id,type){\n    var handler = this.props.customHandler;\n    if(target.nodeName == \"SPAN\" || target.nodeName == \"I\"){\n      if(target.parentNode.getAttribute(\"class\") == \"open\"){\n        target.nextSibling.style.display = \"none\";\n        target.parentNode.getElementsByTagName(\"font\")[0].classList.add(\"select\");\n      }else{\n        target.nextSibling.style.display = \"inline-block\";\n        target.parentNode.getElementsByTagName(\"font\")[0].classList.remove(\"select\");\n      }\n    }\n    if(handler){\n      handler({\n        eventType:type,\n        data:id\n      })\n    }\n\t}\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  renderTree: function renderTree(data, me) {\n    return React.createElement(\n      'ul',\n      null,\n      data.map(function (item, i) {\n        return React.createElement(\n          'li',\n          { className: item.status ? 'close' : 'open' },\n          React.createElement(\n            'span',\n            { onClick: function onClick(e) {\n                var target = e.target;\n                me.handle(target, item.id, 'click');\n              } },\n            React.createElement('i', null),\n            React.createElement('input', { type: 'radio', name: '1', onClick: function onClick(e) {\n                var target = e.target;\n                me.handle(target, item.id, 'radio');\n              } }),\n            React.createElement(\n              'font',\n              null,\n              item.txt\n            )\n          ),\n          item.children.length ? React.createElement(\n            'div',\n            null,\n            me.renderTree(item.children, me)\n          ) : ''\n        );\n      })\n    );\n  },\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement('p', { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      'div',\n      { style: { background: '#fff' }, 'class': 'w-jsTree' },\n      data && data.tit ? React.createElement(\n        'div',\n        { 'class': 'w-tit' },\n        data.tit\n      ) : '',\n      data.data && data.data.length ? React.createElement(\n        'div',\n        { 'class': 'w-treeBody' },\n        me.renderTree(data.data, me)\n      ) : ''\n    );\n  },\n  handle: function handle(target, id, type) {\n    var handler = this.props.customHandler;\n    if (target.nodeName == \"SPAN\" || target.nodeName == \"I\") {\n      if (target.parentNode.getAttribute(\"class\") == \"open\") {\n        target.nextSibling.style.display = \"none\";\n        target.parentNode.getElementsByTagName(\"font\")[0].classList.add(\"select\");\n      } else {\n        target.nextSibling.style.display = \"inline-block\";\n        target.parentNode.getElementsByTagName(\"font\")[0].classList.remove(\"select\");\n      }\n    }\n    if (handler) {\n      handler({\n        eventType: type,\n        data: id\n      });\n    }\n  }\n});";
    },
    getData_control197_WpEUrH: function (elem) {
      if (!elem) {
        return '';
      }function getData(curNode, arr) {
        curNode.children(".dTreeNode").each(function () {
          arr.push({ txt: $(this).find("a").eq(0).text(), id: $(this).find("a").eq(0).attr("id"), children: [] });if ($(this).next(".clip").length && $(this).next(".clip")[0].style.display != "none") {
            var curNode = $(this).next(".clip");getData(curNode, arr[arr.length - 1].children);
          }
        });
      }data = [];var root = $(elem).find("td").eq(0).children(".dtree");getData(root, data);return { data: data };
    },
    doAction_uiControl207_mhHw93: function (data, elem) {
      console.log("data.dataCustom:::" + data.dataCustom); // $(elem).find(".wti").each(function () {
      //   if ($(this).find("a").attr("id") == data.dataCustom) {
      //     if(data.eventType == "click"){
      //       $(this).find("button").eq(0).mousedown();
      //     }else if(data.eventType == "radio"){
      //       $(this).find('input[type="radio"]').eq(0).click();
      //     }
      //   }
      // });
      $(elem).find("#" + data.dataCustom).find('input[type="radio"]').eq(0).click();
    },
    getTemplate_uiControl207_mhHw93: function () {
      var selfTemplate = "module.exports = React.createClass({\n  renderTree:function(data,me){\n    return(\n      <ul>{data.map((item,i)=>{\n          return(\n            <li className={item.status ? 'close' : 'open'} >\n              <span onClick={(e)=>{\n                  const target = e.target;\n                  me.handle(target,item.id,'click')\n                }}>\n                <input type=\"radio\" name=\"1\" onClick={(e)=>{\n                  const target = e.target;\n                  me.handle(target,item.id,'radio')\n                }}/>\n                <font>{item.txt}</font>\n              </span>\n              {item.children.length ? <div>{me.renderTree(item.children,me)}</div> : ''}\n            </li>\n          )\n        })}\n      </ul>)\n  },\n  render: function() {\n  \tvar data = this.props.customData,\n  \t\t\tme = this;\n    if(!data){\n      return(\n      \t<p style={{display:\"none\"}}></p>\n      )\n    }\n    return (\n      <div style={{background:'#fff'}} class='w-jsTree'>\n        {data&&data.tit ? <div class='w-tit'>{data.tit}</div> : ''}\n        {data.data&&data.data.length ? <div class='w-treeBody'>{me.renderTree(data.data,me)}</div> : ''}\n      </div>\n    )\n},\n\thandle:function(target,id,type){\n    var handler = this.props.customHandler;\n    if(target.nodeName == \"SPAN\"){\n      if(target.parentNode.getAttribute(\"class\") == \"open\"){\n        target.nextSibling.style.display = \"none\";\n        target.getElementsByTagName(\"font\")[0].classList.add(\"select\");\n      }else{\n        target.nextSibling.style.display = \"block\";\n        target.getElementsByTagName(\"font\")[0].classList.remove(\"select\");\n      }\n    }\n    if(handler){\n      handler({\n        eventType:type,\n        data:id\n      })\n    }\n\t}\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  renderTree: function renderTree(data, me) {\n    return React.createElement(\n      'ul',\n      null,\n      data.map(function (item, i) {\n        return React.createElement(\n          'li',\n          { className: item.status ? 'close' : 'open' },\n          React.createElement(\n            'span',\n            { onClick: function onClick(e) {\n                var target = e.target;\n                me.handle(target, item.id, 'click');\n              } },\n            React.createElement('input', { type: 'radio', name: '1', onClick: function onClick(e) {\n                var target = e.target;\n                me.handle(target, item.id, 'radio');\n              } }),\n            React.createElement(\n              'font',\n              null,\n              item.txt\n            )\n          ),\n          item.children.length ? React.createElement(\n            'div',\n            null,\n            me.renderTree(item.children, me)\n          ) : ''\n        );\n      })\n    );\n  },\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement('p', { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      'div',\n      { style: { background: '#fff' }, 'class': 'w-jsTree' },\n      data && data.tit ? React.createElement(\n        'div',\n        { 'class': 'w-tit' },\n        data.tit\n      ) : '',\n      data.data && data.data.length ? React.createElement(\n        'div',\n        { 'class': 'w-treeBody' },\n        me.renderTree(data.data, me)\n      ) : ''\n    );\n  },\n  handle: function handle(target, id, type) {\n    var handler = this.props.customHandler;\n    if (target.nodeName == \"SPAN\") {\n      if (target.parentNode.getAttribute(\"class\") == \"open\") {\n        target.nextSibling.style.display = \"none\";\n        target.getElementsByTagName(\"font\")[0].classList.add(\"select\");\n      } else {\n        target.nextSibling.style.display = \"block\";\n        target.getElementsByTagName(\"font\")[0].classList.remove(\"select\");\n      }\n    }\n    if (handler) {\n      handler({\n        eventType: type,\n        data: id\n      });\n    }\n  }\n});";
    }
  }, "framework");
})(window, ysp);