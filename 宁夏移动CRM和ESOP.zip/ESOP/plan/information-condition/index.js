(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control91_0oRqwt: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li.selected").find(".tab-title").text();
    },
    doAction_uiControl94_h7w9bU: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.customHelper.indexTabIndex = "1";$(elem).find("li.selected").eq(0).find(".tab-close").click();
      }
    },
    getTemplate_uiControl94_h7w9bU: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  show:function(){\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n          <HeaderRight>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.show}></AMUI.Button>\n          </HeaderRight>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  show: function show() {\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        ),\n        React.createElement(\n          _yspInteriorComponents.HeaderRight,\n          null,\n          React.createElement(AMUI.Button, { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.show })\n        )\n      )\n    );\n  }\n});";
    },
    getData_control93_l2hEKl: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".td_text_width").next("td").each(function (i, el) {
        if (i != $(elem).find(".td_text_width").length - 1) {
          var classType = "",
              option = [],
              id = "";if ($(el).hasClass("checkbox_width")) {
            classType = "checked";$(el).find("input").each(function (g, ng) {
              option.push({ label: $(el).find("label").eq(g).text().trim(), id: $(ng).attr("id"), checked: $(ng).is(":checked") });
            });
          } else if ($(el).children("input").hasClass("mw_field_text")) {
            classType = "input";option.push({ id: $(el).find("input").attr("id"), value: $(el).find("input").val() });
          } else {
            classType = "select";id = $(el).find("select").attr("id");$(el).find("option").each(function (o, op) {
              option.push({ text: $(op).text(), value: $(op).val(), selected: $(op).prop("selected") ? true : false });
            });
          }data.push({ label: $(elem).find(".td_text_width").eq(i).text().trim(), classType: classType, id: id || "", option: option });
        }
      });return data;
    },
    doAction_uiControl97_Vsc9wW: function (data, elem) {
      var d = data.customData;if (data.eventType == "inputChange") {
        $(elem).find(".td_text_width").next("td").eq(d.id).find("input").val(d.value);
      }if (data.eventType == "selectChange") {
        $(elem).find("#" + d.id)[0].selectedIndex = d.selected;
      }if (data.eventType == "clickChange") {
        $(elem).find("#" + d.id).click();
      }
    },
    getTemplate_uiControl97_Vsc9wW: function () {
      var selfTemplate = "\nmodule.exports = React.createClass({\n  handle(data,eventType){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb({data,eventType})\n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if( !data ){\n      return(<div></div>)\n    }\n    return (\n      <div style={{background:\"#fff\"}}>\n        {data.map((item, index) => {\n          var html;\n          if( item.classType == \"input\" ){\n            html = <AInput type=\"text\" id={item.option[0].id} value={item.option[0].value} onBlur={(e)=>{me.handle({id:index,value:e.target.value},\"inputChange\")}}/>\n           \n          } else if( item.classType == \"select\" ){\n            html = <select style={{height:\"50px\",lineHeight:\"20px\",marginBottom:\"0px\"}} id={item.id}  onChange={(e)=>{me.handle({id:item.id,selected:e.target.selectedIndex},\"selectChange\")}}>\n                        {item.option.map((option,i)=>{\n                          return <option selected={option.selected} value={option.value}>{option.text}</option>\n                        })}\n                      </select>\n          } else if( item.classType == \"checked\" ){\n            html = <div>\n              \t{item.option.map(function(option, op){\n                  return(\n                    <div>\n                        <label className=\"amt-switch\">\n                          <input type=\"checkbox\" checked={option.checked} onChange={(e)=>{me.handle({id:option.id},\"clickChange\")}}/>\n                          <span className=\"amt-switch-checkbox\"></span>\n                        </label>\n                      \t<span className=\"amt-item-title\">{option.label}</span>\n                    </div>\n                  )\n                    })}\n              </div>\n          }\n          return(\n            <label className=\"amt-field-single amt-field-underline-part\" >\n              <div className=\"amt-field-label\"><div>{item.label}</div></div>\n              <div className=\"amt-field-wrap\">{html}</div>\n            </label>      \n         )\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  handle: function handle(data, eventType) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb({ data: data, eventType: eventType });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { style: { background: \"#fff\" } },\n      data.map(function (item, index) {\n        var html;\n        if (item.classType == \"input\") {\n          html = React.createElement(AInput, { type: \"text\", id: item.option[0].id, value: item.option[0].value, onBlur: function onBlur(e) {\n              me.handle({ id: index, value: e.target.value }, \"inputChange\");\n            } });\n        } else if (item.classType == \"select\") {\n          html = React.createElement(\n            \"select\",\n            { style: { height: \"50px\", lineHeight: \"20px\", marginBottom: \"0px\" }, id: item.id, onChange: function onChange(e) {\n                me.handle({ id: item.id, selected: e.target.selectedIndex }, \"selectChange\");\n              } },\n            item.option.map(function (option, i) {\n              return React.createElement(\n                \"option\",\n                { selected: option.selected, value: option.value },\n                option.text\n              );\n            })\n          );\n        } else if (item.classType == \"checked\") {\n          html = React.createElement(\n            \"div\",\n            null,\n            item.option.map(function (option, op) {\n              return React.createElement(\n                \"div\",\n                null,\n                React.createElement(\n                  \"label\",\n                  { className: \"amt-switch\" },\n                  React.createElement(\"input\", { type: \"checkbox\", checked: option.checked, onChange: function onChange(e) {\n                      me.handle({ id: option.id }, \"clickChange\");\n                    } }),\n                  React.createElement(\"span\", { className: \"amt-switch-checkbox\" })\n                ),\n                React.createElement(\n                  \"span\",\n                  { className: \"amt-item-title\" },\n                  option.label\n                )\n              );\n            })\n          );\n        }\n        return React.createElement(\n          \"label\",\n          { className: \"amt-field-single amt-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-label\" },\n            React.createElement(\n              \"div\",\n              null,\n              item.label\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-wrap\" },\n            html\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control138_0GtsCD: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".mw_message").each(function (i, el) {
        data.push({ font: $(elem).find("font").eq(i).text(), span: $(el).text() });
      });return data;
    },
    doAction_uiControl150_vhqgmV: function (data, elem) {},
    getTemplate_uiControl150_vhqgmV: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      return(<div></div>)\n    }\n    return (\n      <div>\n        {data.map((item, index) => {\n          return(\n\t\t\t\t\t\t<div align=\"center\" fontSize=\"12px\" lineHeight=\"150%\">\n            \t<font color=\"#cc6633\">{item.font}</font>\n              <span>{item.span}</span>\n            </div>\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      data.map(function (item, index) {\n        return React.createElement(\n          \"div\",\n          { align: \"center\", fontSize: \"12px\", lineHeight: \"150%\" },\n          React.createElement(\n            \"font\",\n            { color: \"#cc6633\" },\n            item.font\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            item.span\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_undefined: function (elem) {},
    doAction_: function (data, elem) {},
    getTemplate_: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    }
  }, "information-condition");
})(window, ysp);