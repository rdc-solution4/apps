(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control79_tdC5Hw: function (elem) {
      if (!elem) {
        return "";
      }var data = []; // data.push({
      //   tit: $(elem).find(".mw_message").text()
      // })
      $(elem).find(".td_input_width").each(function (i, el) {
        var option = [],
            classType = "",
            id = "";var btn = [];if (i == 0 || i == 1) {
          classType = "select";
          id = $(el).find("select").attr("id");$(el).find("option").each(function (o, op) {
            option.push({ text: $(op).text(), value: $(op).attr("value") });
          });
        } else if (i == 2) {
          classType = "input";var idd = "",
              type = "",
              value = "";idd = $(el).find(".mw_field_text").attr("id");type = $(el).find(".mw_field_text").attr("type");value = $(el).find(".mw_field_text").val();option.push({ idd: idd, type: type, value: value });btn.push({ id: $(elem).find("#chooseMgr").attr("id"), text: "选择" });
        } else if ($(el).children("textarea")) {
          classType = "textarea";option.push({ idd: $(el).find("textarea").attr("id"), type: type, value: $(el).find("textarea").val() });
        }data.push({ label: $(elem).find(".td_text_width").eq(i).text().trim(), classType: classType, id: id, option: option, btn: btn });
      }); // data.push({
      //   type: $(elem).find(".button_61px").attr("type"),
      //   value: $(elem).find(".button_61px").val()
      // });
      // var btn = [];
      // btn.push({
      //   id: $(elem).find("#chooseMgr").attr("id"),
      //   text: "选择"
      // });
      // data.push({
      //   btn: btn
      // });
      return data;
    },
    doAction_uiControl82_aithzH: function (data, elem) {
      var d = data.customData;if (data.eventType == "selectChange") {
        $(elem).find(".td_text_width").eq(d.id).next("td").find("select")[0].selectedIndex = d.selected;
      }if (data.eventType == "inputChange") {
        $(elem).find(".td_text_width").eq(d.id).next("td").find("input,textarea").val(d.value);
      }if (data.eventType == "click") {
        $(elem).find("#" + d.id).click();
      }
    },
    getTemplate_uiControl82_aithzH: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  handle(data,eventType){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb({data,eventType})\n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if( !data ){\n      return (<div></div>);\n    }\n    return(\n    \t<div style={{background:\"#fff\"}}>\n      \t{data.map((item,i) => {\n          var html;\n          if( item.classType == \"select\" ){\n\t\t\t\t\t\thtml = <select style={{height:\"50px\",lineHeight:\"20px\",marginBottom:\"0px\"}} onChange={(e)=>{me.handle({id:i,selected:e.target.selectedIndex},\"selectChange\")}}>\n                        {item.option.map((option,i)=>{\n                          return <option value={option.value} >{option.text}</option>\n                        })}\n                      </select>\n          } else if( item.classType == \"input\" ){\n\t\t\t\t\t\thtml = <div className=\"amt-item\">\n              <AInput type=\"text\" id={item.option[0].idd} value={item.option[0].value} onBlur={(e)=>{me.handle({id:i,value:e.target.value},\"inputChange\")}}/>\n              <button className=\"amt-btn-xs amt-btn-primary\" style={{width:\"30%\"}} onClick={()=>{me.handle({id:item.btn[0].id},'click');}}>\u9009\u62E9</button>\n              </div>\n          } else if( item.classType == \"textarea\" ){\n\t\t\t\t\t\thtml = <ATextarea value={item.option[0].value} onBlur={(e)=>{me.handle({id:i,value:e.target.value},\"inputChange\")}}></ATextarea>\n          } \n\t\t\t\t\t\t\n          return(\n              <label className=\"amt-field-single amt-field-underline-part\">\n                <div className=\"amt-field-label\" style={{width:\"20%\"}} ><div>{item.label}</div></div>\n                <div className=\"amt-field-wrap\" >{html}</div>\n              </label>\n          )\n        })}\n      \t\n      </div>\n    \n    )\n    \n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  handle: function handle(data, eventType) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb({ data: data, eventType: eventType });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { style: { background: \"#fff\" } },\n      data.map(function (item, i) {\n        var html;\n        if (item.classType == \"select\") {\n          html = React.createElement(\n            \"select\",\n            { style: { height: \"50px\", lineHeight: \"20px\", marginBottom: \"0px\" }, onChange: function onChange(e) {\n                me.handle({ id: i, selected: e.target.selectedIndex }, \"selectChange\");\n              } },\n            item.option.map(function (option, i) {\n              return React.createElement(\n                \"option\",\n                { value: option.value },\n                option.text\n              );\n            })\n          );\n        } else if (item.classType == \"input\") {\n          html = React.createElement(\n            \"div\",\n            { className: \"amt-item\" },\n            React.createElement(AInput, { type: \"text\", id: item.option[0].idd, value: item.option[0].value, onBlur: function onBlur(e) {\n                me.handle({ id: i, value: e.target.value }, \"inputChange\");\n              } }),\n            React.createElement(\n              \"button\",\n              { className: \"amt-btn-xs amt-btn-primary\", style: { width: \"30%\" }, onClick: function onClick() {\n                  me.handle({ id: item.btn[0].id }, 'click');\n                } },\n              \"\\u9009\\u62E9\"\n            )\n          );\n        } else if (item.classType == \"textarea\") {\n          html = React.createElement(ATextarea, { value: item.option[0].value, onBlur: function onBlur(e) {\n              me.handle({ id: i, value: e.target.value }, \"inputChange\");\n            } });\n        }\n\n        return React.createElement(\n          \"label\",\n          { className: \"amt-field-single amt-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-label\", style: { width: \"20%\" } },\n            React.createElement(\n              \"div\",\n              null,\n              item.label\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-wrap\" },\n            html\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control81_0c3xQ6: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li.selected").find(".tab-title").text();
    },
    doAction_uiControl84_RJDtOQ: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.customHelper.indexTabIndex = "1";$(elem).find("li.selected").eq(0).find(".tab-close").click();
      }
    },
    getTemplate_uiControl84_RJDtOQ: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  show:function(){\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n          <HeaderRight>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.show}></AMUI.Button>\n          </HeaderRight>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  show: function show() {\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        ),\n        React.createElement(\n          _yspInteriorComponents.HeaderRight,\n          null,\n          React.createElement(AMUI.Button, { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.show })\n        )\n      )\n    );\n  }\n});";
    },

    getData_undefined: function (elem) {},
    doAction_: function (data, elem) {},
    getTemplate_: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    },

    getData_control85_FobcmV: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".list_tr_bg1color").each(function (i, el) {
        if ($(el).css('display') != 'none') {
          var tr = [],
              btns = [],
              buttons = [];$(el).find("td").each(function (t, tds) {
            if (t != 0) {
              var properties = [];
              tr.push(properties);properties.push($(elem).find(".list_title").find("td").eq(t).find("label").text());properties.push($(tds).find("label").text());
            }
          });var btnGroup = {};btnGroup.value = $(elem).find(".alignleft").children().val();btns.push(btnGroup);buttons.push(btns);data.push({ "properties": tr, "btn": buttons });
        }
      });return data;
    },
    doAction_uiControl88_HmTOCK: function (data, elem) {
      if (data.eventType == "click") {
        $(elem).find(".list_tr_bg1color").find(".mw_radiobutton").click();$(elem).find(".alignleft").find(".button_61px").click();
      }
    },
    getTemplate_uiControl88_HmTOCK: function () {
      var selfTemplate = "\nconst TodoItemTypeTwo = AMUITouch2.TodoItemTypeTwo;\nconst Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n   BtnClick:function(id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType:\"click\",\n        data: id\n      });   \n    } \n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if(!data){return(<div style={{\"display\":\"none\"}}></div>)}\n    if( data.length ){\n      return (\n        <div className=\"w-rz-list\" style={{background:\"#fff\",paddingBottom:\"0.1rem\"}}>\n          {data.map((item, index) => {\n            const { properties } = item;\n           \tconst topProperties = [];\n            return(\n            \t <TodoItemTypeTwo\n                  key={index}\n                  defaultCollapsed ={false}\n                  subtitle={topProperties.map((p, i) => {\n                    return <Pair key={i} name={p[0]} value={p[1]} />;\n                  })}\n                  style={{background:\"#F6F6F6\",margin:\"1rem\"}}\n                >\n\t\t\t\t\t\t\t\t\t{properties.map((p, i) => {\n                  return <Pair key={i} name={p[0]} value={p[1]} />;\n                \t})}\n                <div className=\"am2-g\">\n                  {item.btn.map(function(bt, i){\n                     return(\n                        <div onClick={function(){me.BtnClick(i)}} style={{height:\"40px\",lineHeight:\"50px\",textAlign:\"center\",borderTop:\"1px solid #fff\",fontSize:\"14px\",display:\"inline-block\",width:\"100%\"}} className=\"am2-col\">{bt[0].value}</div>\n                     )\n                  })}\n               </div>\n                </TodoItemTypeTwo>\n            )\n          })}\n        </div>\n      )\n    } else{\n      return(\n        <div style={{background:\"#fff\"}}>\n          <div className=\"t-cen\">\u6CA1\u6709\u7B26\u5408\u6761\u4EF6\u7684\u6570\u636E</div>\n        </div>\n      )\n    }\n  }\n});";
      return "\"use strict\";\n\nvar TodoItemTypeTwo = AMUITouch2.TodoItemTypeTwo;\nvar Pair = AMUITouch2.Pair;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  BtnClick: function BtnClick(id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \"click\",\n        data: id\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", { style: { \"display\": \"none\" } });\n    }\n    if (data.length) {\n      return React.createElement(\n        \"div\",\n        { className: \"w-rz-list\", style: { background: \"#fff\", paddingBottom: \"0.1rem\" } },\n        data.map(function (item, index) {\n          var properties = item.properties;\n\n          var topProperties = [];\n          return React.createElement(\n            TodoItemTypeTwo,\n            {\n              key: index,\n              defaultCollapsed: false,\n              subtitle: topProperties.map(function (p, i) {\n                return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n              }),\n              style: { background: \"#F6F6F6\", margin: \"1rem\" }\n            },\n            properties.map(function (p, i) {\n              return React.createElement(Pair, { key: i, name: p[0], value: p[1] });\n            }),\n            React.createElement(\n              \"div\",\n              { className: \"am2-g\" },\n              item.btn.map(function (bt, i) {\n                return React.createElement(\n                  \"div\",\n                  { onClick: function onClick() {\n                      me.BtnClick(i);\n                    }, style: { height: \"40px\", lineHeight: \"50px\", textAlign: \"center\", borderTop: \"1px solid #fff\", fontSize: \"14px\", display: \"inline-block\", width: \"100%\" }, className: \"am2-col\" },\n                  bt[0].value\n                );\n              })\n            )\n          );\n        })\n      );\n    } else {\n      return React.createElement(\n        \"div\",\n        { style: { background: \"#fff\" } },\n        React.createElement(\n          \"div\",\n          { className: \"t-cen\" },\n          \"\\u6CA1\\u6709\\u7B26\\u5408\\u6761\\u4EF6\\u7684\\u6570\\u636E\"\n        )\n      );\n    }\n  }\n});";
    }
  }, "marketing-channel-information");
})(window, ysp);