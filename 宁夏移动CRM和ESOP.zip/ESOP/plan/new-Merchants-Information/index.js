(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control33_3Ok3HZ: function (elem) {
      if (!elem) {
        return "";
      }var data = [];var label = "",
          id = "",
          type = "",
          value = "",
          txt = "";$(elem).find(".td_text_width").each(function (i, el) {
        if (i != 11) {
          label = $(el).text().trim();if ($(el).next().hasClass("td_input_width")) {
            type = $(el).next().find("input").attr("type");value = $(el).next().find("input").val();txt = $(el).next().find("input").text();id = $(el).next().find("input").attr("id");
          } else {
            type = "textarea";value = $(el).next().find("textarea").val();txt = $(el).next().find("input").text();id = $(el).next().find("textarea").attr("id");
          }data.push({ label: label, type: type, value: value, txt: txt, id: id });
        }
      });return data;
    }, doAction_uiControl33_1kzg2k: function (data, elem) {
      if (data.eventType == "blur") {
        $(elem).find("#" + data.dataCustom.id).val(data.dataCustom.value);
      }
    }, getTemplate_uiControl33_1kzg2k: function () {
      var selfTemplate = "module.exports = React.createClass({\n   Blur:function(e,id){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"eventType\":\"blur\",\n        data: {\n          id:id,\n          value:e.target.value\n        }\n      });   \n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if( !data ){\n      return(<div></div>)\n    }\n   return(\n   \t<div style={{background:\"#fff\"}}>\n    \t{data.map(function(item, i){\n         var html;\n         if( item.type == \"text\" ){\n           if( i==9 || i==10 ){\n             \thtml = <AInput type=\"date\" id={item.id} value={item.value} onBlur={function(e){me.Blur(e,item.id)}}/>\n           } else if( i==0 ){\n           \t\thtml = <AInput type=\"text\" id={item.id} value={item.value} readonly=\"true\" />\n           } else {\n             \thtml = <AInput type=\"text\" id={item.id} value={item.value} onBlur={function(e){me.Blur(e,item.id)}} />         \n             }\n         } else {\n  \t\t\t\t html = <ATextarea value={item.value} id={item.id} onBlur={function(e){me.Blur(e,item.id)}}></ATextarea>        \n         }\n         return(\n            <label className=\"amt-field-single amt-field-underline-part\">\n              <div className=\"amt-field-label\" style={{width:\"20%\"}} ><div>{item.label}</div></div>\n              <div className=\"amt-field-wrap\">{html}</div>\n            </label>   \n         )\n       })} \n    </div>\n   )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  Blur: function Blur(e, id) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        \"eventType\": \"blur\",\n        data: {\n          id: id,\n          value: e.target.value\n        }\n      });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { style: { background: \"#fff\" } },\n      data.map(function (item, i) {\n        var html;\n        if (item.type == \"text\") {\n          if (i == 9 || i == 10) {\n            html = React.createElement(AInput, { type: \"date\", id: item.id, value: item.value, onBlur: function onBlur(e) {\n                me.Blur(e, item.id);\n              } });\n          } else if (i == 0) {\n            html = React.createElement(AInput, { type: \"text\", id: item.id, value: item.value, readonly: \"true\" });\n          } else {\n            html = React.createElement(AInput, { type: \"text\", id: item.id, value: item.value, onBlur: function onBlur(e) {\n                me.Blur(e, item.id);\n              } });\n          }\n        } else {\n          html = React.createElement(ATextarea, { value: item.value, id: item.id, onBlur: function onBlur(e) {\n              me.Blur(e, item.id);\n            } });\n        }\n        return React.createElement(\n          \"label\",\n          { className: \"amt-field-single amt-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-label\", style: { width: \"20%\" } },\n            React.createElement(\n              \"div\",\n              null,\n              item.label\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-wrap\" },\n            html\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control134_mGxgLk: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".mw_message").each(function (i, el) {
        data.push({ font: $(elem).find("font").eq(i).text(), span: $(el).text() });
      });return data;
    },
    doAction_uiControl146_iTJunT: function (data, elem) {},
    getTemplate_uiControl146_iTJunT: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      return(<div></div>)\n    }\n    return (\n      <div>\n        {data.map((item, index) => {\n          return(\n\t\t\t\t\t\t<div align=\"center\" fontSize=\"12px\" lineHeight=\"150%\">\n            \t<font color=\"#cc6633\">{item.font}</font>\n              <span>{item.span}</span>\n            </div>\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      data.map(function (item, index) {\n        return React.createElement(\n          \"div\",\n          { align: \"center\", fontSize: \"12px\", lineHeight: \"150%\" },\n          React.createElement(\n            \"font\",\n            { color: \"#cc6633\" },\n            item.font\n          ),\n          React.createElement(\n            \"span\",\n            null,\n            item.span\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control141_of9vIT: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li.selected").find(".tab-title").text();
    },
    doAction_uiControl154_ABq4Sw: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.customHelper.indexTabIndex = "1";$(elem).find("li.selected").eq(0).find(".tab-close").click();
      }
    },
    getTemplate_uiControl154_ABq4Sw: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  show:function(){\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n          <HeaderRight>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.show}></AMUI.Button>\n          </HeaderRight>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  show: function show() {\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        ),\n        React.createElement(\n          _yspInteriorComponents.HeaderRight,\n          null,\n          React.createElement(AMUI.Button, { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.show })\n        )\n      )\n    );\n  }\n});";
    }
  }, "new-Merchants-Information");
})(window, ysp);