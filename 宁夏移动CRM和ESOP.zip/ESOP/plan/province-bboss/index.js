(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control76_6hFV7J: function (elem) {
      if (!elem) {
        return "";
      }var data = []; /** BBOSS上传资料维护*/ // data.push({
      //   tit: $(elem).find(".title_boldtext").text().trim()
      // });
      // data.push({
      //   type: $(elem).find(".button_61px").attr("type"),
      //   text: $(elem).find(".button_61px").val(),
      //   id: $(elem).find(".button_61px").attr("onclick")
      // }); /** */
      $(elem).find(".table_listoutline").find(".td_input_width").each(function (i, el) {
        var id = "",
            classType = "",
            option = [],
            btn = [];if (i == 0) {
          classType = "select";id = $(el).find("select").attr("id");$(el).find("option").each(function (o, op) {
            option.push({ text: $(op).text(), value: $(op).attr("value") });
          });
        } else {
          var value = "",
              type = "";classType = "input";$(el).find("input").each(function (g, ng) {
            if ($(ng).attr("type") == "text") {
              type = $(ng).attr("type");id = $(ng).attr("id");value = $(ng).val();option.push({ type: type, id: id, value: value });
            } else if ($(ng).attr("type") == "button") {
              type = $(ng).attr("type");value = $(ng).val();id = g - 1;btn.push({ type: type, value: value, id: id });
            }
          });
        }data.push({ label: $(elem).find(".td_text_width").eq(i).text().trim(), classType: classType, id: id, option: option, btn: btn });
      }); /** 保存*/return data;
    }, doAction_uiControl79_HQI4tP: function (data, elem) {
      var d = data.customData;if (data.eventType == "selectChange") {
        $(elem).find("#" + d.id)[0].selectedIndex = d.selected;
      }if (data.eventType == "inputChange") {
        $(elem).find("#" + d.id).focus().val(d.value);$(elem).find("#" + d.id)[0].dispatchEvent(new Event('change'));$(elem).find("#" + d.id).blur();
      }if (data.eventType == "click") {
        // alert($(elem).find(".button_61px").eq(d).val());
        $(elem).find(".button_61px").eq(d).click();
      }
    },
    getTemplate_uiControl79_HQI4tP: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  handle(data,eventType){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb({data,eventType})\n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if(!data){\n      return (<div></div>)\n    }\n    return (\n      <div style={{background:\"#fff\"}}>\n      {data.map(function(item, i){\n          var html;\n          if( item.classType ==\"select\" ){\n            html = <select style={{height:\"50px\",lineHeight:\"20px\",marginBottom:\"0px\"}} onChange={(e)=>{me.handle({id:item.id,selected:e.target.selectedIndex},\"selectChange\")}}>\n                        {item.option.map((option,i)=>{\n                          return <option value={option.value}>{option.text}</option>\n                        })}\n                      </select>\n          } else if( item.classType ==\"input\" ){\n             if( !item.btn.length ){\n               html = <AInput type=\"text\" id={item.id} value={item.option[0].value} onBlur={(e)=>{me.handle({id:item.id,value:e.target.value},\"inputChange\")}}/>\n             } else {\n               html = <div>\n                 <AInput type=\"text\" id={item.id} value={item.option[0].value} onBlur={(e)=>{me.handle({id:item.id,value:e.target.value},\"inputChange\")}} />\n                  {item.btn.map(function(btn, j){\n                     return(\n                     <button className=\"amt-btn amt-btn-xs amt-btn-primary\" rounded onClick={(e)=>{me.handle(btn.id,\"click\")}}>{btn.value}</button> \n                       )\n                   })}\n                 </div>\n             }\n          }\n        \n          return(\n            <label className=\"amt-field-single amt-field-underline-part\">\n              <div className=\"amt-field-label\" style={{width:\"25%\"}} ><div>{item.label}</div></div>\n              <div className=\"amt-field-wrap\">{html}</div>\n            </label> \n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  handle: function handle(data, eventType) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb({ data: data, eventType: eventType });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      { style: { background: \"#fff\" } },\n      data.map(function (item, i) {\n        var html;\n        if (item.classType == \"select\") {\n          html = React.createElement(\n            \"select\",\n            { style: { height: \"50px\", lineHeight: \"20px\", marginBottom: \"0px\" }, onChange: function onChange(e) {\n                me.handle({ id: item.id, selected: e.target.selectedIndex }, \"selectChange\");\n              } },\n            item.option.map(function (option, i) {\n              return React.createElement(\n                \"option\",\n                { value: option.value },\n                option.text\n              );\n            })\n          );\n        } else if (item.classType == \"input\") {\n          if (!item.btn.length) {\n            html = React.createElement(AInput, { type: \"text\", id: item.id, value: item.option[0].value, onBlur: function onBlur(e) {\n                me.handle({ id: item.id, value: e.target.value }, \"inputChange\");\n              } });\n          } else {\n            html = React.createElement(\n              \"div\",\n              null,\n              React.createElement(AInput, { type: \"text\", id: item.id, value: item.option[0].value, onBlur: function onBlur(e) {\n                  me.handle({ id: item.id, value: e.target.value }, \"inputChange\");\n                } }),\n              item.btn.map(function (btn, j) {\n                return React.createElement(\n                  \"button\",\n                  { className: \"amt-btn amt-btn-xs amt-btn-primary\", rounded: true, onClick: function onClick(e) {\n                      me.handle(btn.id, \"click\");\n                    } },\n                  btn.value\n                );\n              })\n            );\n          }\n        }\n\n        return React.createElement(\n          \"label\",\n          { className: \"amt-field-single amt-field-underline-part\" },\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-label\", style: { width: \"25%\" } },\n            React.createElement(\n              \"div\",\n              null,\n              item.label\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-wrap\" },\n            html\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control78_Tnd6ED: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li.selected").find(".tab-title").text();
    },
    doAction_uiControl81_xzQz8J: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.customHelper.indexTabIndex = "1";$(elem).find("li.selected").eq(0).find(".tab-close").click();
      }
    },
    getTemplate_uiControl81_xzQz8J: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  show:function(){\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n          <HeaderRight>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.show}></AMUI.Button>\n          </HeaderRight>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  show: function show() {\n    ysp.customHelper.showMenu == true ? ysp.customHelper.showMenu = false : ysp.customHelper.showMenu = true;\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        ),\n        React.createElement(\n          _yspInteriorComponents.HeaderRight,\n          null,\n          React.createElement(AMUI.Button, { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.show })\n        )\n      )\n    );\n  }\n});";
    },
    getData_control351_gPdJRl: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find("span").each(function (i, el) {
        data.push({ span: $(elem).find("font").text(), text: $(el).text() });
      });return data;
    },
    doAction_uiControl374_svzTTC: function (data, elem) {},
    getTemplate_uiControl374_svzTTC: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    },
    getData_control350_Q0lLFP: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find("font").parent().next("td").each(function (i, el) {
        data.push({ span: $(elem).find("font").text(), text: $(el).text().trim() });
      });return data;
    },
    doAction_uiControl371_gFlLlt: function (data, elem) {},
    getTemplate_uiControl371_gFlLlt: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      return(<div></div>)\n    }\n    if(data){\n      return (\n        <div>\n          {data.map(function(item, index){\n            return(\n            \t<div style={{background:\"#fff\"}}>\n                <span className=\"amt-field-single amt-field-underline-part\">\n                  <div className=\"amt-field-label\" style={{width:\"20%\"}} ><font color=\"#cc6633\">{item.span}</font>></div>\n                  <div className=\"amt-field-wrap\"><span>{item.text}</span></div>\n                </span>      \n          </div>\n            )\n          })}\n        </div>\n      )\n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    if (data) {\n      return React.createElement(\n        \"div\",\n        null,\n        data.map(function (item, index) {\n          return React.createElement(\n            \"div\",\n            { style: { background: \"#fff\" } },\n            React.createElement(\n              \"span\",\n              { className: \"amt-field-single amt-field-underline-part\" },\n              React.createElement(\n                \"div\",\n                { className: \"amt-field-label\", style: { width: \"20%\" } },\n                React.createElement(\n                  \"font\",\n                  { color: \"#cc6633\" },\n                  item.span\n                ),\n                \">\"\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"amt-field-wrap\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  item.text\n                )\n              )\n            )\n          );\n        })\n      );\n    }\n  }\n});";
    },
    getData_control351_qZ3G7m: function (elem) {
      ;if (!elem) {
        return;
      }var data = [];$(elem).find("span").map(function () {
        data.push($(this).text());
      });return data;
    },
    doAction_uiControl372_Ma46mP: function (data, elem) {
      $(elem).find("span").eq(data.dataCustom).click();
    },
    getTemplate_uiControl372_Ma46mP: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){return(<p style={{display:\"none\"}}></p>)}\n    return (\n      <div className=\"amt-g w-threeBtn\" style={{padding:\"1rem\",textAlign:\"center\"}}>\n       {data.map(function(item,i){\n          return(\n          \t<Button className=\"amt-col\" onClick={function(){_this.onClick(i)}} rounded>{item}</Button>\n          )\n        })}\n      </div>\n    )\n  },\n  onClick:function(i){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"amt-g w-threeBtn\", style: { padding: \"1rem\", textAlign: \"center\" } },\n      data.map(function (item, i) {\n        return React.createElement(\n          Button,\n          { className: \"amt-col\", onClick: function onClick() {\n              _this.onClick(i);\n            }, rounded: true },\n          item\n        );\n      })\n    );\n  },\n  onClick: function onClick(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });\n    }\n  }\n});";
    },
    getData_control353_I9WAd2: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find("span").each(function (i, el) {
        data.push({ span: $(elem).find("font").text(), text: $(el).text() });
      });return data;
    },
    doAction_uiControl374_ShVDmc: function (data, elem) {},
    getTemplate_uiControl374_ShVDmc: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    if(!data){\n      return(<div></div>)\n    }\n    if(data){\n      return (\n        <div>\n          {data.map(function(item, index){\n            return(\n            \t<div style={{background:\"#fff\"}}>\n                <span className=\"amt-field-single amt-field-underline-part\">\n                  <div className=\"amt-field-label\" style={{width:\"20%\"}} ><font color=\"#cc6633\">{item.span}</font>></div>\n                  <div className=\"amt-field-wrap\"><span>{item.text}</span></div>\n                </span>      \n          </div>\n            )\n          })}\n        </div>\n      )\n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    if (data) {\n      return React.createElement(\n        \"div\",\n        null,\n        data.map(function (item, index) {\n          return React.createElement(\n            \"div\",\n            { style: { background: \"#fff\" } },\n            React.createElement(\n              \"span\",\n              { className: \"amt-field-single amt-field-underline-part\" },\n              React.createElement(\n                \"div\",\n                { className: \"amt-field-label\", style: { width: \"20%\" } },\n                React.createElement(\n                  \"font\",\n                  { color: \"#cc6633\" },\n                  item.span\n                ),\n                \">\"\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"amt-field-wrap\" },\n                React.createElement(\n                  \"span\",\n                  null,\n                  item.text\n                )\n              )\n            )\n          );\n        })\n      );\n    }\n  }\n});";
    },
    getData_control354_v02kEz: function (elem) {
      ;if (!elem) {
        return;
      }var data = [];$(elem).find("span").map(function () {
        data.push($(this).text());
      });return data;
    },
    doAction_uiControl375_gEbK5X: function (data, elem) {
      $(elem).find("span").eq(data.dataCustom).click();
    },
    getTemplate_uiControl375_gEbK5X: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(!data){return(<p style={{display:\"none\"}}></p>)}\n    return (\n      <div className=\"amt-g w-threeBtn\" style={{padding:\"1rem\",textAlign:\"center\"}}>\n       {data.map(function(item,i){\n          return(\n          \t<Button className=\"amt-col\" onClick={function(){_this.onClick(i)}} rounded>{item}</Button>\n          )\n        })}\n      </div>\n    )\n  },\n  onClick:function(i){\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });   \n    } \n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (!data) {\n      return React.createElement(\"p\", { style: { display: \"none\" } });\n    }\n    return React.createElement(\n      \"div\",\n      { className: \"amt-g w-threeBtn\", style: { padding: \"1rem\", textAlign: \"center\" } },\n      data.map(function (item, i) {\n        return React.createElement(\n          Button,\n          { className: \"amt-col\", onClick: function onClick() {\n              _this.onClick(i);\n            }, rounded: true },\n          item\n        );\n      })\n    );\n  },\n  onClick: function onClick(i) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        data: i\n      });\n    }\n  }\n});";
    }
  }, "province-bboss");
})(window, ysp);