(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control146_ei0wPT: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find("tr").each(function (i, el) {
        if (i != 3 && i != 4) {
          if ($(el).find("textarea").hasClass("mw_field_textarea")) {
            data.push({ label: $(el).find("td").eq(0).text().trim(), type: "textarea", id: $(el).find("textarea").attr("id"), value: $(el).find("textarea").val() });
          } else if ($(el).find("input").hasClass("mw_field_text")) {
            var btn = [];btn.push({ type: $(el).find("input").eq(1).attr("type"), id: $(el).find("input").eq(1).attr("id"), value: $(el).find("input").eq(1).val() });data.push({ label: $(elem).find("td").eq(0).text().trim(), type: $(el).find("input").eq(0).attr("type"), id: $(el).find("input").eq(0).attr("id"), value: $(el).find("input").eq(0).val(), btn: btn });
          } else {
            var option = [];$(el).find("option").each(function (o, op) {
              option.push({ value: $(op).val(), text: $(op).text(), selected: $(op).prop("selected") ? true : false });
            });data.push({ label: $(elem).find("td").eq(0).text().trim(), type: "select", id: $(el).find("select").attr("id"), option: option });
          }
        }
      });return data;
    }, doAction_uiControl159_Azomf2: function (data, elem) {
      var d = data.customData;if (data.eventType == "selectChange") {
        $(elem).find("#" + d.id)[0].selectedIndex = d.selected;
      }if (data.eventType == "inputChange") {
        $(elem).find("#" + d.id).val(d.value);
      }if (data.eventType == "click") {
        $(elem).find("#" + d.id).click();
      }
    },
    getTemplate_uiControl159_Azomf2: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n   handle(data,eventType){\n     console.log(data);\n    var cb = this.props.customHandler;\n    if(cb){\n      cb({data,eventType})\n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if(!data){\n      return(<div></div>)\n    }\n    return (\n      <div>\n       {data.map((item, i) => {\n          var html;\n          if( item.type == \"select\"){\n            html = <select style={{height:\"50px\",lineHeight:\"20px\",marginBottom:\"0px\"}} onChange={(e)=>{me.handle({id: item.id,selected:e.target.selectedIndex},\"selectChange\")}}>\n                      {item.option.map((option,i)=>{\n                        return <option selected={option.selected} value={option.text}>{option.text}</option>\n                      })}\n                    </select>\n          } else if( item.type == \"textarea\" ){\n           html = <ATextarea value={item.value}  onBlur={(e)=>{me.handle({id:item.id,value:e.target.value},\"inputChange\")}}></ATextarea>\n          } else if( item.type == \"text\" ){\n            html = <div>\n                 \t\t\t<AInput type=\"text\" id={item.id} value={item.value} onBlur={(e)=>{me.handle({id:item.id,value:e.target.value},\"inputChange\")}} />\n                   \t\t<button className=\"amt-btn amt-btn-primary\" onClick={(e)=>{me.handle({id:item.btn[0].id},\"click\")}}>\u4E0A\u4F20</button>\n                 </div>\n          }\n          \n          return(\n          \t<div style={{background:\"#fff\"}}>\n                <div style={{marginTop:\"1px\",background:\"#fff\"}}  class=\"code-run\">\n                    <span className=\"amt-field-single\" style={{paddingTop:\"5px\"}}>\n                      <div className=\"amt-field-label\" style={{width:\"20%\"}}><div>{item.label}</div></div>\n                      <div className=\"amt-field-wrap\">{html}</div>\n                    </span>      \n                </div>\n            </div>\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  handle: function handle(data, eventType) {\n    console.log(data);\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb({ data: data, eventType: eventType });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      data.map(function (item, i) {\n        var html;\n        if (item.type == \"select\") {\n          html = React.createElement(\n            \"select\",\n            { style: { height: \"50px\", lineHeight: \"20px\", marginBottom: \"0px\" }, onChange: function onChange(e) {\n                me.handle({ id: item.id, selected: e.target.selectedIndex }, \"selectChange\");\n              } },\n            item.option.map(function (option, i) {\n              return React.createElement(\n                \"option\",\n                { selected: option.selected, value: option.text },\n                option.text\n              );\n            })\n          );\n        } else if (item.type == \"textarea\") {\n          html = React.createElement(ATextarea, { value: item.value, onBlur: function onBlur(e) {\n              me.handle({ id: item.id, value: e.target.value }, \"inputChange\");\n            } });\n        } else if (item.type == \"text\") {\n          html = React.createElement(\n            \"div\",\n            null,\n            React.createElement(AInput, { type: \"text\", id: item.id, value: item.value, onBlur: function onBlur(e) {\n                me.handle({ id: item.id, value: e.target.value }, \"inputChange\");\n              } }),\n            React.createElement(\n              \"button\",\n              { className: \"amt-btn amt-btn-primary\", onClick: function onClick(e) {\n                  me.handle({ id: item.btn[0].id }, \"click\");\n                } },\n              \"\\u4E0A\\u4F20\"\n            )\n          );\n        }\n\n        return React.createElement(\n          \"div\",\n          { style: { background: \"#fff\" } },\n          React.createElement(\n            \"div\",\n            { style: { marginTop: \"1px\", background: \"#fff\" }, \"class\": \"code-run\" },\n            React.createElement(\n              \"span\",\n              { className: \"amt-field-single\", style: { paddingTop: \"5px\" } },\n              React.createElement(\n                \"div\",\n                { className: \"amt-field-label\", style: { width: \"20%\" } },\n                React.createElement(\n                  \"div\",\n                  null,\n                  item.label\n                )\n              ),\n              React.createElement(\n                \"div\",\n                { className: \"amt-field-wrap\" },\n                html\n              )\n            )\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control151_TIcV9f: function (elem) {
      return elem.innerHTML;
    },
    doAction_uiControl165_ForVLm: function (data, elem) {},
    getTemplate_uiControl165_ForVLm: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    return (\n\t\t\t<span><font color=\"blue\">{data}</font></span>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      \"span\",\n      null,\n      React.createElement(\n        \"font\",\n        { color: \"blue\" },\n        data\n      )\n    );\n  }\n});";
    },
    getData_control152_Gdplpr: function (elem) {
      return elem.innerHTML;
    },
    doAction_uiControl166_e6AIw5: function (data, elem) {},
    getTemplate_uiControl166_e6AIw5: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    return (\n      <span><font color=\"blue\">1\u3001\u6587\u4EF6\u5927\u5C0F\u4E0D\u80FD\u8D85\u8FC720000K\u3002</font></span>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      \"span\",\n      null,\n      React.createElement(\n        \"font\",\n        { color: \"blue\" },\n        \"1\\u3001\\u6587\\u4EF6\\u5927\\u5C0F\\u4E0D\\u80FD\\u8D85\\u8FC720000K\\u3002\"\n      )\n    );\n  }\n});";
    },
    getData_control393_cHZ4K9: function (elem) {
      ;
    },
    doAction_uiControl418_lF3CfX: function (data, elem) {
      "use strict";
    },
    getTemplate_uiControl418_lF3CfX: function () {
      var selfTemplate = "import { Header, HeaderLeft } from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nexport default () =>\n<Header amStyle=\"primary\" title=\"\u975E\u7ED3\u6784\u5316\u4FE1\u606F\">\n  <HeaderLeft>\n    <AMUI.Button amStyle=\"primary\" onClick={back}><AMUI.Icon name='left-nav'></AMUI.Icon>\u8FD4\u56DE</AMUI.Button>\n  </HeaderLeft>\n</Header>;";
      return "'use strict';\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nexports.default = function () {\n  return React.createElement(\n    _yspInteriorComponents.Header,\n    { amStyle: 'primary', title: '\\u975E\\u7ED3\\u6784\\u5316\\u4FE1\\u606F' },\n    React.createElement(\n      _yspInteriorComponents.HeaderLeft,\n      null,\n      React.createElement(\n        AMUI.Button,\n        { amStyle: 'primary', onClick: _appRenderer.back },\n        React.createElement(AMUI.Icon, { name: 'left-nav' }),\n        '\\u8FD4\\u56DE'\n      )\n    )\n  );\n};";
    }
  }, "unstructured-file");
})(window, ysp);