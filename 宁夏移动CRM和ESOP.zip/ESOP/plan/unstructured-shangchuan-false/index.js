(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control379_O2ORom: function (elem) {
      if (!elem) {
        return;
      }var data = {};$(elem).find("tr").each(function (i, el) {
        $(el).find("font").each(function (j, fo) {
          data.font = $(fo).text().trim();data.txt = $(fo).parent().next("td").text().trim();
        });
      });return data;
    },
    doAction_uiControl404_EI6lqk: function (data, elem) {},
    getTemplate_uiControl404_EI6lqk: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    return (\n      <div>\n        \u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7528\u6765\u9002\u914D\u57FA\u672C\u7EC4\u4EF6\u65E0\u6CD5\u9002\u914D\u7684\u9875\u9762\u5143\u7D20\uFF0C\u60A8\u53EF\u4EE5\u901A\u8FC7\u53F3\u952E\u6253\u5F00\u8BE5\u81EA\u5B9A\u4E49\u7EC4\u4EF6\u7F16\u8F91\u5668\u8FDB\u884C\u7F16\u8F91\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    return React.createElement(\n      \"div\",\n      null,\n      \"\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7528\\u6765\\u9002\\u914D\\u57FA\\u672C\\u7EC4\\u4EF6\\u65E0\\u6CD5\\u9002\\u914D\\u7684\\u9875\\u9762\\u5143\\u7D20\\uFF0C\\u60A8\\u53EF\\u4EE5\\u901A\\u8FC7\\u53F3\\u952E\\u6253\\u5F00\\u8BE5\\u81EA\\u5B9A\\u4E49\\u7EC4\\u4EF6\\u7F16\\u8F91\\u5668\\u8FDB\\u884C\\u7F16\\u8F91\"\n    );\n  }\n});";
    },
    getData_control385_FuZ3Ha: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find("tr").each(function (i, el) {
        data.push({ font: $(el).find("font").text().trim(), text: $(el).find("td").last().text().trim() });
      });return data;
    },
    doAction_uiControl410_QVD6Tm: function (data, elem) {},
    getTemplate_uiControl410_QVD6Tm: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    return (\n      <div>\n        {data.map((item, index) => {\n          return(\n            <div className=\"amt-field-single amt-field-underline-part\" style={{margin:\"0\"}}>\n                  <div className=\"amt-field-label\" style={{color:\"#CC6633\"}} ><div>{item.font}</div></div>\n                  <div className=\"amt-field-wrap\" style={{marginTop:\"10px\"}}>\n                    {item.text}\n                  </div>\n                </div>\n          )\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      \"div\",\n      null,\n      data.map(function (item, index) {\n        return React.createElement(\n          \"div\",\n          { className: \"amt-field-single amt-field-underline-part\", style: { margin: \"0\" } },\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-label\", style: { color: \"#CC6633\" } },\n            React.createElement(\n              \"div\",\n              null,\n              item.font\n            )\n          ),\n          React.createElement(\n            \"div\",\n            { className: \"amt-field-wrap\", style: { marginTop: \"10px\" } },\n            item.text\n          )\n        );\n      })\n    );\n  }\n});";
    }
  });
})(window, ysp);