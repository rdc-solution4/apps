(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control149_xThSbn: function (elem) {
      if (!elem) {
        return;
      }var data = [];$(elem).find(".td_text_width").next("td").each(function (i, el) {
        if ($(el).children().hasClass("mw_fileupload_span")) {
          data.push({ label: $(elem).find(".td_text_width").eq(i).text().trim(), id: $(el).find("span").find("input").attr("id"), value: $(el).find("span").find("input").val(), type: $(el).find("span").find("input").attr("type") });
        } else if ($(el).children().hasClass("mw_field_text")) {
          data.push({ label: $(elem).find(".td_text_width").eq(i).text().trim(), id: $(el).find("input").attr("id"), value: $(el).find("input").val(), type: $(el).find("input").attr("type") });
        } else if ($(el).children().hasClass("mw_field_textarea")) {
          data.push({ label: $(elem).find(".td_text_width").eq(i).text().trim(), id: $(el).find("textarea").attr("id"), value: $(el).find("textarea").val(), type: "textarea" });
        }
      });return data;
    },
    doAction_uiControl163_01QEuJ: function (data, elem) {
      var d = data.customData;if (data.eventType == "inputChange") {
        $(elem).find("#" + d.id).val(d.value);
      }if (data.eventType == "click") {
        $(elem).find("#" + d.id).click();
      }
    },
    getTemplate_uiControl163_01QEuJ: function () {
      var selfTemplate = "module.exports = React.createClass({\n  handle(data,eventType){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb({data,eventType})\n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if(!data){\n      return(<div></div>)\n    }\n    return (\n      <div>\n        {data.map((item, i) => {\n          var html;\n          if(item.type == \"file\"){\n            // html = <AInput type=\"file\"  id={item.id} onClick={(e)=>{me.handle({id:item.id},\"click\")}}></AInput>\n            html = <button className=\"amt-btn am2-btn-block\" onClick={(e)=>{me.handle({id:item.id},\"click\")}}>\u8BF7\u9009\u62E9</button>\n          } else if( item.type == \"text\" ){\n            html = <AInput type=\"text\" value={item.value} id={item.id} onBlur={(e)=>{me.handle({id:item.id,value:e.target.value},\"inputChange\")}}/>\n          } else if( item.type == \"textarea\" ){\n            html = <ATextarea id={item.id} value={item.value} onBlur={(e)=>{me.handle({id:item.id,value:e.target.value},\"inputChange\")}}></ATextarea>\n          }\n\t\t\t\t\t\n          return(\n          \t<div style={{background:\"#fff\"}}>\n\t\t\t\t      <span class=\"amt-field-single amt-field-underline-part\">\n              \t<div class=\"amt-field-label\" style={{width:\"20%\"}}><div>{item.label}</div></div>\n                <div class=\"amt-field-wrap\"><div>{html}</div></div>\n              </span>\n            </div>\n          )\n\n        })}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  handle: function handle(data, eventType) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb({ data: data, eventType: eventType });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      data.map(function (item, i) {\n        var html;\n        if (item.type == \"file\") {\n          // html = <AInput type=\"file\"  id={item.id} onClick={(e)=>{me.handle({id:item.id},\"click\")}}></AInput>\n          html = React.createElement(\n            \"button\",\n            { className: \"amt-btn am2-btn-block\", onClick: function onClick(e) {\n                me.handle({ id: item.id }, \"click\");\n              } },\n            \"\\u8BF7\\u9009\\u62E9\"\n          );\n        } else if (item.type == \"text\") {\n          html = React.createElement(AInput, { type: \"text\", value: item.value, id: item.id, onBlur: function onBlur(e) {\n              me.handle({ id: item.id, value: e.target.value }, \"inputChange\");\n            } });\n        } else if (item.type == \"textarea\") {\n          html = React.createElement(ATextarea, { id: item.id, value: item.value, onBlur: function onBlur(e) {\n              me.handle({ id: item.id, value: e.target.value }, \"inputChange\");\n            } });\n        }\n\n        return React.createElement(\n          \"div\",\n          { style: { background: \"#fff\" } },\n          React.createElement(\n            \"span\",\n            { \"class\": \"amt-field-single amt-field-underline-part\" },\n            React.createElement(\n              \"div\",\n              { \"class\": \"amt-field-label\", style: { width: \"20%\" } },\n              React.createElement(\n                \"div\",\n                null,\n                item.label\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { \"class\": \"amt-field-wrap\" },\n              React.createElement(\n                \"div\",\n                null,\n                html\n              )\n            )\n          )\n        );\n      })\n    );\n  }\n});";
    },
    getData_control308_m7HTxV: function (elem) {
      if (!elem) {
        return;
      }var data = {};data.text = $(elem).find("input").val();data.id = $(elem).find("input").attr("id");return data;
    },
    doAction_uiControl168_ZktrIT: function (data, elem) {
      var d = data.customData,
          aWin = elem.ownerDocument.defaultView;if (data.eventType == "click") {
        $(elem).find("#" + d.id).click(); // aWin.closeWin();
      }
    },
    getTemplate_uiControl168_ZktrIT: function () {
      var selfTemplate = "module.exports = React.createClass({\n  handle(data,eventType){\n    var cb = this.props.customHandler;\n    if(cb){\n      cb({data,eventType})\n    }\n  },\n  render: function() {\n    var data = this.props.customData,\n        me = this;\n    if(!data){\n      return(<div></div>)\n    }\n    return (\n      <div>\n        <button className=\"amt-btn amt-btn-primary\" style={{width:\"100%\"}} onClick={()=>{\n                me.handle({id:data.id},'click');\n              }}>{data.text}</button>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n  handle: function handle(data, eventType) {\n    var cb = this.props.customHandler;\n    if (cb) {\n      cb({ data: data, eventType: eventType });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.customData,\n        me = this;\n    if (!data) {\n      return React.createElement(\"div\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"button\",\n        { className: \"amt-btn amt-btn-primary\", style: { width: \"100%\" }, onClick: function onClick() {\n            me.handle({ id: data.id }, 'click');\n          } },\n        data.text\n      )\n    );\n  }\n});";
    }
  });
})(window, ysp);