(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control50_yUTocT: function (elem) {
      if (!elem) {
        return;
      }return $(elem).find("li").eq(1).find(".tab-title").text();
    },
    doAction_uiControl48_zbK6DI: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        $(elem).parents("body").find("#search_info_text").val("");ysp.customHelper.indexTabIndex = "1";$(elem).find("li").eq(1).find(".tab-close").click();
      }
    },
    getTemplate_uiControl48_zbK6DI: function () {
      var selfTemplate = "import { Header, HeaderLeft ,HeaderRight} from 'ysp-interior-components';\nimport { back } from 'appRenderer';\nmodule.exports = React.createClass({\n  back:function(){                                \n    var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back();\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n          <HeaderRight>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.show}></AMUI.Button>\n          </HeaderRight>\n        </Header>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nvar _appRenderer = require('appRenderer');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back();\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        ),\n        React.createElement(\n          _yspInteriorComponents.HeaderRight,\n          null,\n          React.createElement(AMUI.Button, { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.show })\n        )\n      )\n    );\n  }\n});";
    },
    getData_control54_BmOdhd: function (elem) {
      if (!elem) {
        ysp.appMain.showLoading();return;
      }var rp = ysp.customHelper.replaceSpace;var $elem = $(elem),
          radio = [],
          check = [],
          inputValue = $elem.find(".list02_content input[name='num']").val();$elem.find("input[name='validMode']").each(function (i, el) {
        var checked = $(this)[0].checked,
            value = $(this).val(),
            text = $(this).next("label").text() || rp($(this).parent().text().split(/\n\t/g)[(i + 1) * 2]);radio.push({ checked: checked, value: value, text: text });
      });check.push({ tit: '是否为跨省集团业务', checked: $elem.find("input[type='checkbox']")[0].checked });return { radio: radio, inputValue: inputValue, check: check };
    },
    doAction_uiControl51_dKmZbN: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'selectClick') {
        var evt = document.createEvent("mouseEvents");evt.initEvent("mousedown", true, true);$(elem).find("input[name='" + d + "']")[0].dispatchEvent(evt);$(elem).find("input[name='" + d + "']")[0].click();
      }if (data.eventType === 'checkClick') {
        if (d == "checkbox") {
          $(elem).find("input[type='checkbox']")[0].click();
        } else {
          $(elem).find("input[value=" + d + "]")[0].click();
        }
      }if (data.eventType === 'inputChange') {
        $(elem).find("input[name='" + d.id + "']").val(d.value);$(elem).find("input[name='" + d.id + "']")[0].dispatchEvent(new Event('change'));
      }
    },
    getTemplate_uiControl51_dKmZbN: function () {
      var selfTemplate = "module.exports = React.createClass({\n   \n  inputChange:function(e,id){                                \n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        data:{\n          value:e.target.value,\n          id:id\n        },\n        eventType:'inputChange'                         \n      })\n    }\n  },\n  checkClick:function(id){\n      var callBack = this.props.customHandler;   \n    if(callBack) {                                    \n      callBack({\n        data:id,\n        eventType:'checkClick'                         \n      })\n    }\n  },\n  \n  render: function() {\n    var data = this.props.data.customData;\n    var but = \"subBt\",\n        me = this;\n    if(data != undefined){\n    return (\n       <div class='wrapper'>\n       <div  style={{ display: 'flex'}}>   \n        {data.radio.map(function(el,i){\n          return(\n            <div style={{ display: 'flex', margin: '5px 25px 5px 0px' }}>  \n            <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{el.text}</span>\n              <label className = \"radio1\">\n           \t\t\t<div className=\"amt-item-after\" style={{display:\"inline-block\",margin:\"0 5px 0 15px\"}} onClick={function(){me.checkClick(el.value)}}>\n                  <label className=\"amt-switch amt-select-item-switch\" style={{margin:\"0\"}}>\n                    <input type=\"checkbox\" checked={el.checked} />\n                    <span className=\"amt-switch-radio\"></span>\n                  </label>\n                </div>\n              </label>\n            </div>\n          )\n        })}\n        </div>\n        <label className=\"amt-field-single amt-field-underline-part searchInp\">\n          <div className=\"amt-field-wrap\">\n              <AInput value={data.inputValue} type=\"text\" className=\"amt-field\" onBlur={function(e){me.inputChange(e,\"num\")}} placeholder=\"\u8BF7\u8F93\u5165\u67E5\u8BE2\u4FE1\u606F\" id=\"queryLoading\" />\n          </div>\n        </label>\n        <label>\n          <span>{data.check[0].tit}</span><input type=\"checkbox\"  checked={data.check[0].checked} onClick={function(){me.checkClick(\"checkbox\")}} />\n        </label>\n      </div>\n    )\n  }else{\n    return( <div style={{\"style\":\"none\"}}></div>)\n  }\n    }\n});\n\n";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n\n  inputChange: function inputChange(e, id) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: {\n          value: e.target.value,\n          id: id\n        },\n        eventType: 'inputChange'\n      });\n    }\n  },\n  checkClick: function checkClick(id) {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        data: id,\n        eventType: 'checkClick'\n      });\n    }\n  },\n\n  render: function render() {\n    var data = this.props.data.customData;\n    var but = \"subBt\",\n        me = this;\n    if (data != undefined) {\n      return React.createElement(\n        'div',\n        { 'class': 'wrapper' },\n        React.createElement(\n          'div',\n          { style: { display: 'flex' } },\n          data.radio.map(function (el, i) {\n            return React.createElement(\n              'div',\n              { style: { display: 'flex', margin: '5px 25px 5px 0px' } },\n              React.createElement(\n                'span',\n                { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },\n                el.text\n              ),\n              React.createElement(\n                'label',\n                { className: 'radio1' },\n                React.createElement(\n                  'div',\n                  { className: 'amt-item-after', style: { display: \"inline-block\", margin: \"0 5px 0 15px\" }, onClick: function onClick() {\n                      me.checkClick(el.value);\n                    } },\n                  React.createElement(\n                    'label',\n                    { className: 'amt-switch amt-select-item-switch', style: { margin: \"0\" } },\n                    React.createElement('input', { type: 'checkbox', checked: el.checked }),\n                    React.createElement('span', { className: 'amt-switch-radio' })\n                  )\n                )\n              )\n            );\n          })\n        ),\n        React.createElement(\n          'label',\n          { className: 'amt-field-single amt-field-underline-part searchInp' },\n          React.createElement(\n            'div',\n            { className: 'amt-field-wrap' },\n            React.createElement(AInput, { value: data.inputValue, type: 'text', className: 'amt-field', onBlur: function onBlur(e) {\n                me.inputChange(e, \"num\");\n              }, placeholder: '\\u8BF7\\u8F93\\u5165\\u67E5\\u8BE2\\u4FE1\\u606F', id: 'queryLoading' })\n          )\n        ),\n        React.createElement(\n          'label',\n          null,\n          React.createElement(\n            'span',\n            null,\n            data.check[0].tit\n          ),\n          React.createElement('input', { type: 'checkbox', checked: data.check[0].checked, onClick: function onClick() {\n              me.checkClick(\"checkbox\");\n            } })\n        )\n      );\n    } else {\n      return React.createElement('div', { style: { \"style\": \"none\" } });\n    }\n  }\n});";
    },
    getData_control59_EAKPkK: function (elem) {
      if (elem) {
        var cloneElem = elem.cloneNode(true);var pData1 = [];var pData2 = [];var ad = cloneElem.querySelectorAll("tr");for (var i = 0; i < ad.length; i++) {
          if (ad[i].style.display == "none") {
            ad[i].remove();
          }
        }var trs = cloneElem.querySelectorAll('td');var trsLen = trs.length;for (var i = 0; i < trsLen; i++) {
          if (trs[i].textContent.trim() != "" && trs[1].textContent.trim() != "") {
            pData1.push(trs[i].textContent.trim());pData2.push(trs[i + 1].textContent.trim());i++;
          }
        }return { pData1: pData1, pData2: pData2 };
      }return;
    },
    doAction_uiControl59_uhJq64: function (data, elem) {},
    getTemplate_uiControl59_uhJq64: function () {
      var selfTemplate = "module.exports = React.createClass({\n  componentDidMount:function(){\n    ysp.appMain.hideLoading();\n  },\n  componentDidUpdate:function(){\n    ysp.appMain.hideLoading();\n  },\n  render: function() {\n    var title = this.props.data.customData&&this.props.data.customData.pData1;\n    var customData = this.props.data.customData&&this.props.data.customData.pData2;\n    var status = customData&&customData.length==0 ? \"block\" : \"none\";\n    {/*\u5B9A\u4E49\u5DE6\u8FB9\u6807\u9898\u6837\u5F0F*/}\n    var style = {\n      \"margin-right\":\"1rem\",\n      \"color\":\"#888\"\n    };\n   if(customData){\n      return (\n        <div class=\"feeList\">\n          <div class=\"navTitle\">\u96C6\u56E2\u5BA2\u6237\u4FE1\u606F</div>\n           <ul class=\"listWrapper\">\n              {customData.map((content, i) => (\n               \n                <li key={i}>\n                  <span style={style}>{title[i]}</span>\n                  <span>{content}</span>\n                </li>\n              ))}\n             <div class=\"noData\" style={{\"display\":status}}>\u5F53\u524D\u6682\u65E0\u5BA2\u6237\u4FE1\u606F</div>\n            </ul> \n        </div>\n      )\n   }else{\n     return(\n     \t<div style={{\"display\":\"none\"}}></div>\n     )\n   }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  componentDidMount: function componentDidMount() {\n    ysp.appMain.hideLoading();\n  },\n  componentDidUpdate: function componentDidUpdate() {\n    ysp.appMain.hideLoading();\n  },\n  render: function render() {\n    var title = this.props.data.customData && this.props.data.customData.pData1;\n    var customData = this.props.data.customData && this.props.data.customData.pData2;\n    var status = customData && customData.length == 0 ? \"block\" : \"none\";\n    {/*\u5B9A\u4E49\u5DE6\u8FB9\u6807\u9898\u6837\u5F0F*/}\n    var style = {\n      \"margin-right\": \"1rem\",\n      \"color\": \"#888\"\n    };\n    if (customData) {\n      return React.createElement(\n        \"div\",\n        { \"class\": \"feeList\" },\n        React.createElement(\n          \"div\",\n          { \"class\": \"navTitle\" },\n          \"\\u96C6\\u56E2\\u5BA2\\u6237\\u4FE1\\u606F\"\n        ),\n        React.createElement(\n          \"ul\",\n          { \"class\": \"listWrapper\" },\n          customData.map(function (content, i) {\n            return React.createElement(\n              \"li\",\n              { key: i },\n              React.createElement(\n                \"span\",\n                { style: style },\n                title[i]\n              ),\n              React.createElement(\n                \"span\",\n                null,\n                content\n              )\n            );\n          }),\n          React.createElement(\n            \"div\",\n            { \"class\": \"noData\", style: { \"display\": status } },\n            \"\\u5F53\\u524D\\u6682\\u65E0\\u5BA2\\u6237\\u4FE1\\u606F\"\n          )\n        )\n      );\n    } else {\n      return React.createElement(\"div\", { style: { \"display\": \"none\" } });\n    }\n  }\n});";
    },
    getData_control60_NVU8JU: function (elem) {
      if (!elem) {
        return "";
      }var data = [];$(elem).find(".list02_title").each(function () {
        if ($(this).text().trim() != "") {
          var i = $(this).next().find("select")[0].selectedIndex;$(this).next().find("select").find("option").eq(i).attr("selected", "selected");data.push({ title: $(this).text().trim(), content: $(this).next().find("select").html() });
        }
      });return data;
    },
    doAction_uiControl60_hePTk0: function (data, elem) {
      if (data.eventType == "click") {
        $(elem).find("input[name='qryBt']").click();
      } else {
        $(elem).find(".list02_title").eq(data.dataCustom.ind).next().find("select")[0].selectedIndex = data.dataCustom.val;
      }
    },
    getTemplate_uiControl60_hePTk0: function () {
      var selfTemplate = "module.exports = React.createClass({\n  renderDom: function(data){\n    return{__html:data};\n  },\n  render: function() {\n    var data = this.props.customData,_this = this;\n    return (\n    <div class=\"searchDate\">\n        {data&&data.length ? <div class=\"navTitle\">\u8D39\u7528\u660E\u7EC6\u67E5\u8BE2</div> :''}\n      <ul>\n        {data&&data.length&&data.map((item,i)=>{\n         return( \n           <li>\n             <span>{item.title}</span>\n             <select class={i==0 ? \"arrow\" : \"\"} dangerouslySetInnerHTML={_this.renderDom(item.content)} onChange = {_this.onChange} data-index = {i} />\n           </li>)\n        })}\n      </ul>\n        {data&&data.length ? <div data-type=\"cardFooter\">\n          <button class=\"btn search\" onClick = {_this.onClick}>\u67E5\u8BE2</button>\n        </div> :''}\n    </div>\n    )\n  },\n  onChange: function(e){\n    var handler = this.props.customHandler;\n   \tif (handler) {\n      handler({\n        eventType: 'change',\n        data: {\n          ind:e.target.getAttribute(\"data-index\"),\n          val:e.target.selectedIndex\n        }\n      });\n  \t}\n  },\n  onClick:function(e){\n    var judge = e.target.parentElement.parentElement.querySelector(\"select\");\n    judge.value!=\"nullSub\" ? ysp.appMain.showLoading() : '';\n    var handler = this.props.customHandler;\n   \tif (handler) {\n      handler({\n        eventType: 'click'\n      });\n  \t}\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  renderDom: function renderDom(data) {\n    return { __html: data };\n  },\n  render: function render() {\n    var data = this.props.customData,\n        _this = this;\n    return React.createElement(\n      \"div\",\n      { \"class\": \"searchDate\" },\n      data && data.length ? React.createElement(\n        \"div\",\n        { \"class\": \"navTitle\" },\n        \"\\u8D39\\u7528\\u660E\\u7EC6\\u67E5\\u8BE2\"\n      ) : '',\n      React.createElement(\n        \"ul\",\n        null,\n        data && data.length && data.map(function (item, i) {\n          return React.createElement(\n            \"li\",\n            null,\n            React.createElement(\n              \"span\",\n              null,\n              item.title\n            ),\n            React.createElement(\"select\", { \"class\": i == 0 ? \"arrow\" : \"\", dangerouslySetInnerHTML: _this.renderDom(item.content), onChange: _this.onChange, \"data-index\": i })\n          );\n        })\n      ),\n      data && data.length ? React.createElement(\n        \"div\",\n        { \"data-type\": \"cardFooter\" },\n        React.createElement(\n          \"button\",\n          { \"class\": \"btn search\", onClick: _this.onClick },\n          \"\\u67E5\\u8BE2\"\n        )\n      ) : ''\n    );\n  },\n  onChange: function onChange(e) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'change',\n        data: {\n          ind: e.target.getAttribute(\"data-index\"),\n          val: e.target.selectedIndex\n        }\n      });\n    }\n  },\n  onClick: function onClick(e) {\n    var judge = e.target.parentElement.parentElement.querySelector(\"select\");\n    judge.value != \"nullSub\" ? ysp.appMain.showLoading() : '';\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: 'click'\n      });\n    }\n  }\n});";
    },
    getData_control61_OCfSWr: function (elem) {
      if (!elem) {
        return "";
      }var content = [],
          btn = [],
          img = "",
          more = "",
          moreMsg = moreMsg;img = $(elem).find("img").attr("src");$(elem).find(".list_title").find("a").each(function () {
        btn.push($(this).text());
      });$(elem).find(".list02_title").each(function (i) {
        if (i < 2) content.push({ tit: $(this).text().trim(), con: $(elem).find(".list02_content").eq(i).text().trim() });
      });more = $(elem).find("#showDetailA").html();moreMsg = $(elem).find("#messagedetail").css("display") == "block" ? $(elem).find("#messagedetail").text().trim() : '';return { img: img, btn: btn, content: content, more: more, moreMsg: moreMsg };
    },
    doAction_uiControl61_1ul5OM: function (data, elem) {
      if (data.dataCustom == 2) {
        $(elem).find("#showDetailA").click();
      } else {
        var body = elem.ownerDocument.defaultView.parent.document;$(body).find("#search_info_text").val("");ysp.customHelper.indexTabIndex = "1";$(elem).find(".list_title").find("a").eq(data.dataCustom).click();
      }
    },
    getTemplate_uiControl61_1ul5OM: function () {
      var selfTemplate = "module.exports = React.createClass({\n  renderDom: function(data){\n    return{__html:data};\n  },\n  // componentDidMount:function(){\n  //   ysp.appMain.hideLoading();\n  // },\n  // componentDidUpdate:function(){\n  //   ysp.appMain.hideLoading();\n  // },\n  render: function() {\n    var data = this.props.customData;\n    var _this = this;\n    if(data){\n      return (\n        <div class=\"errMsg\">\n          <img src={data.img} />\n          <div>\n            <button onClick={()=>{_this.handle(0,\"click\");}}>{data.btn[0]}</button>\n            <button onClick={()=>{_this.handle(1,\"click\");}}>{data.btn[1]}</button>\n          </div>\n          <ul>\n            <li><span>{data.content[0].tit}</span><span>{data.content[0].con}</span></li>\n            <li><span>{data.content[1].tit}</span><span>{data.content[1].con}</span></li>\n          </ul>\n          <div  dangerouslySetInnerHTML={_this.renderDom(data.more)} onClick = {()=>{_this.handle(2,\"click\");}} />\n          {data.moreMsg!=\"\" ? <p>{data.moreMsg}</p> : \"\"}\n        </div>\n      )\n    }else{\n      return(<div style={{\"display\":\"none\"}}></div>)\n    }\n    \n  },\n  handle:function(ind,type){\n    var handler = this.props.customHandler;\n    if(handler){\n       handler({\n         eventType:type,\n         data:ind\n       })\n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  renderDom: function renderDom(data) {\n    return { __html: data };\n  },\n  // componentDidMount:function(){\n  //   ysp.appMain.hideLoading();\n  // },\n  // componentDidUpdate:function(){\n  //   ysp.appMain.hideLoading();\n  // },\n  render: function render() {\n    var data = this.props.customData;\n    var _this = this;\n    if (data) {\n      return React.createElement(\n        \"div\",\n        { \"class\": \"errMsg\" },\n        React.createElement(\"img\", { src: data.img }),\n        React.createElement(\n          \"div\",\n          null,\n          React.createElement(\n            \"button\",\n            { onClick: function onClick() {\n                _this.handle(0, \"click\");\n              } },\n            data.btn[0]\n          ),\n          React.createElement(\n            \"button\",\n            { onClick: function onClick() {\n                _this.handle(1, \"click\");\n              } },\n            data.btn[1]\n          )\n        ),\n        React.createElement(\n          \"ul\",\n          null,\n          React.createElement(\n            \"li\",\n            null,\n            React.createElement(\n              \"span\",\n              null,\n              data.content[0].tit\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              data.content[0].con\n            )\n          ),\n          React.createElement(\n            \"li\",\n            null,\n            React.createElement(\n              \"span\",\n              null,\n              data.content[1].tit\n            ),\n            React.createElement(\n              \"span\",\n              null,\n              data.content[1].con\n            )\n          )\n        ),\n        React.createElement(\"div\", { dangerouslySetInnerHTML: _this.renderDom(data.more), onClick: function onClick() {\n            _this.handle(2, \"click\");\n          } }),\n        data.moreMsg != \"\" ? React.createElement(\n          \"p\",\n          null,\n          data.moreMsg\n        ) : \"\"\n      );\n    } else {\n      return React.createElement(\"div\", { style: { \"display\": \"none\" } });\n    }\n  },\n  handle: function handle(ind, type) {\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: type,\n        data: ind\n      });\n    }\n  }\n});";
    },
    getData_control62_VEvfK4: function (elem) {
      if (!elem) {
        return '';
      }var tit = $(elem).find("h2").text(),
          table = $(elem).find("#AccTable"),
          content = [],
          tab = [],
          data = [];table.find("td").each(function () {
        content.push($(this).text());
      });$(elem).find("table[id*='TAB']").each(function () {
        var ad = [],
            at = [];$(this).find("td").each(function () {
          $(this).text().trim() != "" ? ad.push($(this).text()) : '';
        });$(this).next("table").find("tr").each(function () {
          var con = [];$(this).find("td").each(function () {
            con.push($(this).text().replace(/,/g, ''));
          });at.push(con);
        });tab.push(ad);data.push(at);
      });return { tit: tit, content: content, tab: tab, data: data };
    },
    doAction_uiControl62_Mg9FtE: function (data, elem) {},
    getTemplate_uiControl62_Mg9FtE: function () {
      var selfTemplate = "module.exports = React.createClass({\n  componentDidMount:function(){\n    ysp.appMain.hideLoading();\n  },\n  componentDidUpdate:function(){\n    ysp.appMain.hideLoading();\n  },\n  render: function() {\n    var data = this.props.customData\n    return (\n      <div class='userList'>\n        {data&&data.tit ? <span class='navTitle'>{data.tit}</span> :''}\n        {data&&data.content ? <ul>\n          {data.content.map((item)=>{\n            return(<li>{item}</li>)\n          })}\n        </ul> :''}\n        {data&&data.tab ? <div class=\"extra\">{data.tab.map((item,i)=>{\n             return(<ul>{item.map((v,j)=>{\n                   return(<li>{v}</li>)\n                 })}<div><table><tbody>{data.data[i].map((val,k)=>{\n                   return(<tr>{val.map((va)=>{\n                         return(<td>{va}</td>)\n                       })}</tr>) \n                 })}</tbody></table></div></ul>)\n            })}</div> : ''}\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  componentDidMount: function componentDidMount() {\n    ysp.appMain.hideLoading();\n  },\n  componentDidUpdate: function componentDidUpdate() {\n    ysp.appMain.hideLoading();\n  },\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      'div',\n      { 'class': 'userList' },\n      data && data.tit ? React.createElement(\n        'span',\n        { 'class': 'navTitle' },\n        data.tit\n      ) : '',\n      data && data.content ? React.createElement(\n        'ul',\n        null,\n        data.content.map(function (item) {\n          return React.createElement(\n            'li',\n            null,\n            item\n          );\n        })\n      ) : '',\n      data && data.tab ? React.createElement(\n        'div',\n        { 'class': 'extra' },\n        data.tab.map(function (item, i) {\n          return React.createElement(\n            'ul',\n            null,\n            item.map(function (v, j) {\n              return React.createElement(\n                'li',\n                null,\n                v\n              );\n            }),\n            React.createElement(\n              'div',\n              null,\n              React.createElement(\n                'table',\n                null,\n                React.createElement(\n                  'tbody',\n                  null,\n                  data.data[i].map(function (val, k) {\n                    return React.createElement(\n                      'tr',\n                      null,\n                      val.map(function (va) {\n                        return React.createElement(\n                          'td',\n                          null,\n                          va\n                        );\n                      })\n                    );\n                  })\n                )\n              )\n            )\n          );\n        })\n      ) : ''\n    );\n  }\n});";
    },
    getData_control74_4QcERf: function (elem) {
      if (!elem) {
        return '';
      } else {
        return elem.value;
      }
    },
    doAction_uiControl75_2nXdqM: function (data, elem) {
      elem.click();
    },
    getTemplate_uiControl75_2nXdqM: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    return (\n      <div>{data ? <input class='btn asure' type='button' value = {data} onClick={this.onClick} /> : ''}</div>\n    )\n  },\n  onClick:function(e){\n    var judge = e.target.ownerDocument.querySelector(\"#queryLoading\");\n    judge.value!=\"\" ? ysp.appMain.showLoading() : '';\n    var handler = this.props.customHandler;\n  \tif(handler){\n      handler({})\n    }\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      'div',\n      null,\n      data ? React.createElement('input', { 'class': 'btn asure', type: 'button', value: data, onClick: this.onClick }) : ''\n    );\n  },\n  onClick: function onClick(e) {\n    var judge = e.target.ownerDocument.querySelector(\"#queryLoading\");\n    judge.value != \"\" ? ysp.appMain.showLoading() : '';\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({});\n    }\n  }\n});";
    },
    getData_control75_sI5N3Q: function (elem) {
      if (!elem) {
        return '';
      } else {
        return elem.value;
      }
    },
    doAction_uiControl76_DpMLBb: function (data, elem) {
      elem.click();
    },
    getTemplate_uiControl76_DpMLBb: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    var data = this.props.customData;\n    return (\n      <div style={{display:'none'}}>{data ? <input class='btn search' type='button' value = {data} onClick={this.onClick} /> : ''}</div>\n    )\n  },\n  onClick:function(){\n    ysp.appMain.showLoading();\n    var handler = this.props.customHandler;\n  \tif(handler){\n      handler({})\n    }\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  render: function render() {\n    var data = this.props.customData;\n    return React.createElement(\n      'div',\n      { style: { display: 'none' } },\n      data ? React.createElement('input', { 'class': 'btn search', type: 'button', value: data, onClick: this.onClick }) : ''\n    );\n  },\n  onClick: function onClick() {\n    ysp.appMain.showLoading();\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({});\n    }\n  }\n});";
    }
  }, "userFee");
})(window, ysp);