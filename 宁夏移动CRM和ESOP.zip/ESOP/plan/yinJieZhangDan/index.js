(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control394_erp35D: function (elem) {
      if (!elem) {
        return;
      }return $(elem).text();
    },
    doAction_uiControl341_GPNMAW: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        $(elem).parents().find("[name='exit']").eq(0).click();
      }
    },
    getTemplate_uiControl341_GPNMAW: function () {
      var selfTemplate = "//\u5934\u90E8\nimport { Header, HeaderLeft } from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  back:function(){                                \n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back();\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }                       \n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back();\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n}); //\u5934\u90E8";
    },
    getData_control395_mU5H0Z: function (elem) {
      if (!elem) {
        return;
      }var data = { title: [], infos: [] };$(elem).find(".list_title").find("td").each(function (i, el) {
        data.title.push($(el).text());
      });$(elem).find(".border_RightBottom5").each(function (i, tr) {
        var list = [];$(tr).find("td").each(function (j, td) {
          list.push($(td).text().trim());
        });data.infos.push(list);
      });return data;
    },
    doAction_uiControl419_RwJwhc: function (data, elem) {},
    getTemplate_uiControl419_RwJwhc: function () {
      var selfTemplate = "module.exports = React.createClass({\n  handle: function(data,eventType) {\n    var c=this.props.customHandler;\n    if(c){c({data,eventType})}\n  },\n  render: function() {\n    var data = this.props.customData;\n    var me = this;\n    if(!data){\n      return(<span></span>)\n    }\n    var list = data.infos.map(function(d,i){\n      var text = d.map(function(dd,j){\n          return(\n            <div style={{marginTop:\"1px\"}}>\n              <div className=\"am2-field-single am2-field-underline-part\" style={{marginTop:\"5px\",fontSize:\"14px\"}}>\n                <span style={{paddingRight:\"10px\"}}>{data.title[j]}</span>\n             \t\t<span style={{color:\"rgb(65, 78, 121)\"}}>{dd}</span>\n              </div>\n          \t</div>\n          )\n    \t});\n      return(\n        <div>\n          <div style={{backgroundColor:\"#eee\",width:\"\",margin:\"1rem\",paddingTop:\"10px\",paddingLeft:\"20px\"}}>\n            <div>\n              {text}\n            </div>\n          </div>\n        </div>\n      )\n    });\n    \n    return (\n      <div>\n        {list}\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  handle: function handle(data, eventType) {\n    var c = this.props.customHandler;\n    if (c) {\n      c({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var me = this;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    var list = data.infos.map(function (d, i) {\n      var text = d.map(function (dd, j) {\n        return React.createElement(\n          \"div\",\n          { style: { marginTop: \"1px\" } },\n          React.createElement(\n            \"div\",\n            { className: \"am2-field-single am2-field-underline-part\", style: { marginTop: \"5px\", fontSize: \"14px\" } },\n            React.createElement(\n              \"span\",\n              { style: { paddingRight: \"10px\" } },\n              data.title[j]\n            ),\n            React.createElement(\n              \"span\",\n              { style: { color: \"rgb(65, 78, 121)\" } },\n              dd\n            )\n          )\n        );\n      });\n      return React.createElement(\n        \"div\",\n        null,\n        React.createElement(\n          \"div\",\n          { style: { backgroundColor: \"#eee\", width: \"\", margin: \"1rem\", paddingTop: \"10px\", paddingLeft: \"20px\" } },\n          React.createElement(\n            \"div\",\n            null,\n            text\n          )\n        )\n      );\n    });\n\n    return React.createElement(\n      \"div\",\n      null,\n      list\n    );\n  }\n});";
    }
  });
})(window, ysp);