(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control408_n5EPnI: function (elem) {
      if (!elem) {
        return;
      }return "查看";
    },
    doAction_uiControl433_pyKm7a: function (data, elem) {
      var d = data.dataCustom;if (data.eventType === 'back') {
        ysp.appMain.back();
      }
    },
    getTemplate_uiControl433_pyKm7a: function () {
      var selfTemplate = "//\u5934\u90E8\nimport { Header, HeaderLeft } from 'ysp-interior-components';\nmodule.exports = React.createClass({\n  back:function(){                                \n      var callBack = this.props.customHandler;          \n    if(callBack) {                                    \n      callBack({\n        eventType:'back'                         \n      })\n    }\n  },\n  componentDidMount: function(){\n    const me = this;\n    window.__ysp_page_back = function(){\n      me.back();\n    }\n  },\n  render: function() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle={padding:0};\n    return (\n      <div>\n        <Header amStyle=\"primary\" style={backStyle} title={data}>\n          <HeaderLeft>\n            <AMUI.Button amStyle=\"primary\" style={{margin:\"0\"}} onClick={me.back}><span className=\"icon icon-left-nav icon-back\"></span>\u8FD4\u56DE</AMUI.Button>\n          </HeaderLeft>\n        </Header>\n      </div>\n    )\n  }                       \n});";
      return "'use strict';\n\nvar _yspInteriorComponents = require('ysp-interior-components');\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  back: function back() {\n    var callBack = this.props.customHandler;\n    if (callBack) {\n      callBack({\n        eventType: 'back'\n      });\n    }\n  },\n  componentDidMount: function componentDidMount() {\n    var me = this;\n    window.__ysp_page_back = function () {\n      me.back();\n    };\n  },\n  render: function render() {\n    var data = this.props.data.customData,\n        me = this,\n        backStyle = { padding: 0 };\n    return React.createElement(\n      'div',\n      null,\n      React.createElement(\n        _yspInteriorComponents.Header,\n        { amStyle: 'primary', style: backStyle, title: data },\n        React.createElement(\n          _yspInteriorComponents.HeaderLeft,\n          null,\n          React.createElement(\n            AMUI.Button,\n            { amStyle: 'primary', style: { margin: \"0\" }, onClick: me.back },\n            React.createElement('span', { className: 'icon icon-left-nav icon-back' }),\n            '\\u8FD4\\u56DE'\n          )\n        )\n      )\n    );\n  }\n}); //\u5934\u90E8";
    },
    getData_control409_HKxqbR: function (elem) {
      if (!elem) {
        return;
      }var data = { title: "知识信息", labels: [], infos: [] };$(elem).find(".list02_title").each(function (i, el) {
        data.labels.push($(el).text().trim());var content = $(el).next();if (content.find("input").length > 0) {
          data.infos.push(content.find("input").val());
        } else if (content.find("select").length > 0) {
          content.find("option").each(function (j, opt) {
            if ($(opt).is(":checked")) {
              data.infos.push($(opt).text());
            }
          });
        }
      });return data;
    },
    doAction_uiControl434_LmwGoJ: function (data, elem) {
      var type = data.eventType;if (data.dataCustom) var d = data.dataCustom;switch (type) {case "inputChange":
          break;}
    },
    getTemplate_uiControl434_LmwGoJ: function () {
      var selfTemplate = "\nmodule.exports = React.createClass({\n  handle: function(data,eventType) {\n    var c=this.props.customHandler;\n    if(c){c({data,eventType})}\n  },\n  render: function() {\n    var data = this.props.customData;\n    var me = this;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div>\n        <header className=\"amt-title amt-title-primary\">\n          <div className=\"amt-title-left\">\n            <span className=\"amt-title-left-icon\"></span>\n            <h3 className=\"amt-title-left-text\"  style={{color:\"#333\"}}>{data.title}</h3>\n          </div>\n        </header>\n        <div>\n        \t{data.labels.map(function(d,i){\n            return(\n            \t<div className=\"amt-field-single amt-field-underline-part\">\n                <div className=\"amt-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{d}</div></div>\n                <div className=\"amt-field-wrap\" style={{fontSize:\"14px\",paddingTop:\"10px\"}}>\n                  {data.infos[i]}\n                </div>\n              </div>\n            )\n          })}\n        </div>\n      </div>\n    )\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  handle: function handle(data, eventType) {\n    var c = this.props.customHandler;\n    if (c) {\n      c({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var me = this;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"header\",\n        { className: \"amt-title amt-title-primary\" },\n        React.createElement(\n          \"div\",\n          { className: \"amt-title-left\" },\n          React.createElement(\"span\", { className: \"amt-title-left-icon\" }),\n          React.createElement(\n            \"h3\",\n            { className: \"amt-title-left-text\", style: { color: \"#333\" } },\n            data.title\n          )\n        )\n      ),\n      React.createElement(\n        \"div\",\n        null,\n        data.labels.map(function (d, i) {\n          return React.createElement(\n            \"div\",\n            { className: \"amt-field-single amt-field-underline-part\" },\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-label\", style: { margin: \"0\", width: \"25%\" } },\n              React.createElement(\n                \"div\",\n                null,\n                d\n              )\n            ),\n            React.createElement(\n              \"div\",\n              { className: \"amt-field-wrap\", style: { fontSize: \"14px\", paddingTop: \"10px\" } },\n              data.infos[i]\n            )\n          );\n        })\n      )\n    );\n  }\n});";
    },
    getData_control410_pgH4qs: function (elem) {
      if (!elem) {
        return;
      }var data = { title: "附件信息", label: $(elem).find("td").eq(0).text().trim(), info: $(elem).find("td").eq(1).find("input").val(), btn: { id: $(elem).find("td").eq(2).find("input").attr("id"), val: $(elem).find("td").eq(2).find("input").val() } };return data;
    },
    doAction_uiControl436_KTQbzf: function (data, elem) {
      var type = data.eventType;if (data.dataCustom) var d = data.dataCustom;switch (type) {case "idClick":
          $(elem).find("#" + d).click();break;}
    },
    getTemplate_uiControl436_KTQbzf: function () {
      var selfTemplate = "const Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  handle: function(data,eventType) {\n    var c=this.props.customHandler;\n    if(c){c({data,eventType})}\n  },\n  render: function() {\n    var data = this.props.customData;\n    var me = this;\n    if(!data){\n      return(<span></span>)\n    }\n    return (\n      <div>\n\t\t\t\t<header className=\"amt-title amt-title-primary\">\n          <div className=\"amt-title-left\">\n            <span className=\"amt-title-left-icon\"></span>\n            <h3 className=\"amt-title-left-text\"  style={{color:\"#333\"}}>{data.title}</h3>\n          </div>\n        </header>\n        <div className=\"amt-field-single amt-field-underline-part\">\n          <div className=\"amt-field-label\" style={{margin:\"0\",width:\"25%\"}}><div>{data.label}</div></div>\n          <div className=\"amt-field-wrap\" style={{fontSize:\"14px\",paddingTop:\"10px\"}}>\n            {data.info}\n          </div>\n        </div>\n        <Button block amSize=\"xs\" amStyle=\"primary\" onClick={(e)=>{me.handle(data.btn.id,\"idClick\")}}>{data.btn.val}</Button>\n      </div>\n    )\n  }\n});\n";
      return "\"use strict\";\n\nvar Button = AMUITouch2.Button;\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  handle: function handle(data, eventType) {\n    var c = this.props.customHandler;\n    if (c) {\n      c({ data: data, eventType: eventType });\n    }\n  },\n  render: function render() {\n    var data = this.props.customData;\n    var me = this;\n    if (!data) {\n      return React.createElement(\"span\", null);\n    }\n    return React.createElement(\n      \"div\",\n      null,\n      React.createElement(\n        \"header\",\n        { className: \"amt-title amt-title-primary\" },\n        React.createElement(\n          \"div\",\n          { className: \"amt-title-left\" },\n          React.createElement(\"span\", { className: \"amt-title-left-icon\" }),\n          React.createElement(\n            \"h3\",\n            { className: \"amt-title-left-text\", style: { color: \"#333\" } },\n            data.title\n          )\n        )\n      ),\n      React.createElement(\n        \"div\",\n        { className: \"amt-field-single amt-field-underline-part\" },\n        React.createElement(\n          \"div\",\n          { className: \"amt-field-label\", style: { margin: \"0\", width: \"25%\" } },\n          React.createElement(\n            \"div\",\n            null,\n            data.label\n          )\n        ),\n        React.createElement(\n          \"div\",\n          { className: \"amt-field-wrap\", style: { fontSize: \"14px\", paddingTop: \"10px\" } },\n          data.info\n        )\n      ),\n      React.createElement(\n        Button,\n        { block: true, amSize: \"xs\", amStyle: \"primary\", onClick: function onClick(e) {\n            me.handle(data.btn.id, \"idClick\");\n          } },\n        data.btn.val\n      )\n    );\n  }\n});";
    }
  });
})(window, ysp);